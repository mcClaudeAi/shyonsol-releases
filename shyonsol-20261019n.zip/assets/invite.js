//MC 2026-10-19 the Invite and earn page: pulls the player's link, deal numbers and invite list from
//   api/referrals.php and draws them. Signed-out or unnamed visitors get the play-first card instead.
//   2026-10-19 later: the community goal counts up with its lanterns, tapping the bar answers with what is
//   left, and sharing goes to X as well as Telegram with the player's own profile card shown first.
//   Third pass: the hero carries the live deal numbers, the invites read as steppers, and the card tilts
//   under a fine pointer (all motion behind prefers-reduced-motion).
(function () {
  "use strict";
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  var pid = "", key = "";
  try { pid = localStorage.getItem("shy-lb-pid") || ""; key = localStorage.getItem("shy-lb-key") || ""; } catch (e) {}
  var noMove = false;
  try { noMove = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t));
    if (s < 3600) return Math.max(1, Math.floor(s / 60)) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    return Math.floor(s / 86400) + "d ago";
  }
  function steps(r) {
    var st = [["Joined", true], ["Played", !!r.played], ["Minted", !!r.minted], ["Dojo buys", !!r.bought]];
    return '<div class="iv-steps" aria-hidden="true">' + st.map(function (x) {
      return '<span class="iv-st' + (x[1] ? " on" : "") + '"><i></i><em>' + x[0] + "</em></span>";
    }).join("") + "</div>";
  }
  // the goal number counts up from zero, so the bar feels alive the moment the page opens
  function countUp(el, to, suffix) {
    if (noMove || to < 2) { el.textContent = fmt(to) + suffix; return; }
    var t0 = performance.now(), ms = Math.min(1400, 400 + to * 12);
    function step(t) {
      var k = Math.min(1, (t - t0) / ms); k = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(Math.round(to * k)) + suffix;
      if (k < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  // ten lanterns over the bar: one lights for every tenth of the goal the community has filled
  function lanterns(total, gate) {
    var lans = $("iv-lans"); if (!lans) return;
    var lit = gate > 0 ? Math.min(10, Math.floor(total / gate * 10)) : 10, h = "";
    for (var i = 0; i < 10; i++) h += '<i class="iv-lan' + (i < lit ? " lit" : "") + '" style="animation-delay:' + (i * 0.35) + 's"></i>';
    lans.innerHTML = h;
  }
  function goalTap(total, gate, done) {
    var bar = $("iv-goal-tap"); if (!bar) return;
    bar.classList.add("iv-can-tap");
    bar.addEventListener("click", function () {
      bar.classList.remove("pulse"); void bar.offsetWidth; bar.classList.add("pulse");
      var n = $("iv-goal-n");
      if (done) { n.textContent = fmt(total) + " invites and counting"; return; }
      var left = Math.max(0, gate - total);
      n.textContent = left === 1 ? "1 to go. It could be yours." : fmt(left) + " to go. Your link below moves it.";
      setTimeout(function () { n.textContent = fmt(total) + " of " + fmt(gate) + " invites"; }, 2600);
    });
  }
  function openShare(to) {
    var W = window.Telegram && window.Telegram.WebApp;
    if (W && W.openLink && W.initData) { W.openLink(to); return true; }
    return false;
  }
  async function load() {
    var j = null;
    if (pid && key) {
      try { j = await (await fetch("/api/referrals.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, key: key }) })).json(); } catch (e) {}
    }
    if (j && j.ok && j.deal) {
      if ($("iv-h-k")) $("iv-h-k").textContent = fmt(j.deal.k);
      if ($("iv-h-cut")) $("iv-h-cut").textContent = j.deal.cut + "%";
      if ($("iv-h-usd")) $("iv-h-usd").textContent = "$" + fmt(j.deal.usd);
      $("iv-d-k").textContent = fmt(j.deal.k) + " Koban";
      $("iv-d-mint").textContent = fmt(j.deal.mint) + " Koban";
      $("iv-d-cut").textContent = j.deal.cut + "% cut";
      //MC 2026-10-19 the $SHY per invite waits behind the community goal: locked shows the goal bar, open shows the $
      var usd = "$" + fmt(j.deal.usd) + " in $SHY";
      $("iv-d-usd").textContent = usd; $("iv-d-usd2").textContent = usd;
      if (j.deal.usd > 0 && j.deal.usdOn) {
        $("iv-d-usd-x").hidden = false;
        $("iv-d-usd-note").textContent = "The $SHY is sent by the team to your connected wallet.";
        if (j.deal.gate > 0) {
          $("iv-goal").hidden = false;
          $("iv-goal-h").textContent = "The community goal is done";
          countUp($("iv-goal-n"), j.deal.total, " invites and counting");
          $("iv-goal-fill").style.width = "100%";
          lanterns(1, 1);
          goalTap(j.deal.total, j.deal.gate, true);
          $("iv-goal-p").innerHTML = "You did it together: every invite now also pays <b>" + esc(usd) + "</b>, sent by the team to the inviter's connected wallet.";
        }
      } else if (j.deal.usd > 0 && j.deal.gate > 0) {
        $("iv-goal").hidden = false;
        countUp($("iv-goal-n"), j.deal.total, " of " + fmt(j.deal.gate) + " invites");
        lanterns(j.deal.total, j.deal.gate);
        goalTap(j.deal.total, j.deal.gate, false);
        var w = Math.min(100, Math.round(j.deal.total / j.deal.gate * 1000) / 10);
        if (noMove) $("iv-goal-fill").style.width = w + "%";
        else { $("iv-goal-fill").style.width = "0%"; setTimeout(function () { $("iv-goal-fill").style.width = w + "%"; }, 150); }
      }
    }
    if (!j || !j.ok || !j.named || !j.link) { $("iv-nolink").hidden = false; return; }
    $("iv-link-card").hidden = false;
    $("iv-link").textContent = j.link;
    //MC 2026-10-19 the share row: the player's own profile card first, then X and Telegram with it attached
    var text = "I run with the Shilluminati. Come play a hand with me, free, in your browser, and my link comes with a welcome gift.";
    var xTo = "https://x.com/intent/tweet?text=" + encodeURIComponent(text + " $SHY\n" + j.link);
    var tgTo = "https://t.me/share/url?url=" + encodeURIComponent(j.link) + "&text=" + encodeURIComponent(text);
    $("iv-x").href = xTo; $("iv-tg").href = tgTo;
    $("iv-x").addEventListener("click", function (e) { if (openShare(xTo)) e.preventDefault(); });
    $("iv-tg").addEventListener("click", function (e) { if (openShare(tgTo)) e.preventDefault(); });
    if (j.card) {
      var im = $("iv-card-img");
      im.addEventListener("error", function () { $("iv-share").hidden = true; $("iv-link-card").classList.remove("has-card"); });
      im.src = j.card;
      $("iv-share").hidden = false;
      $("iv-link-card").classList.add("has-card");
      var tilt = $("iv-card-tilt"), fine = false;
      try { fine = matchMedia("(pointer: fine)").matches; } catch (e) {}
      if (tilt && fine && !noMove) {
        tilt.addEventListener("mousemove", function (ev) {
          var b = tilt.getBoundingClientRect();
          var x = (ev.clientX - b.left) / b.width - 0.5, y = (ev.clientY - b.top) / b.height - 0.5;
          tilt.style.transform = "perspective(700px) rotateY(" + (x * 9).toFixed(2) + "deg) rotateX(" + (-y * 7).toFixed(2) + "deg)";
        });
        tilt.addEventListener("mouseleave", function () { tilt.style.transform = ""; });
      }
    }
    $("iv-copy").addEventListener("click", function () {
      var done = function () { $("iv-copy").textContent = "Copied"; setTimeout(function () { $("iv-copy").textContent = "Copy"; }, 1500); };
      try { navigator.clipboard.writeText(j.link).then(done, function () { window.prompt("Copy your link", j.link); }); } catch (e) { window.prompt("Copy your link", j.link); }
    });
    var tot = [];
    tot.push("<span><small>Invites</small><b>" + fmt(j.rows.length) + "</b></span>");
    tot.push("<span><small>Koban earned</small><b>" + fmt(j.koban) + "</b></span>");
    if (j.usdPend > 0 || (j.deal && j.deal.usdOn)) tot.push('<span><small>$SHY pending</small><b>$' + fmt(j.usdPend) + "</b></span>");
    if (j.usdPaid > 0) tot.push('<span><small>$SHY paid out</small><b>$' + fmt(j.usdPaid) + "</b></span>");
    if (j.deal && j.deal.cap) tot.push("<span><small>This week</small><b>" + fmt(j.week) + " of " + fmt(j.deal.cap) + "</b></span>");
    $("iv-tot").innerHTML = tot.join("");
    if (j.rows.length) {
      $("iv-list-wrap").hidden = false;
      if ($("iv-list-n")) $("iv-list-n").textContent = j.rows.length === 1 ? "1 so far" : j.rows.length + " so far";
      $("iv-list").innerHTML = j.rows.map(function (r) {
        var ch = esc((String(r.name || "?").trim()[0] || "?").toUpperCase());
        return '<div class="iv-row"><span class="iv-av" aria-hidden="true">' + ch + '</span><div class="iv-who"><b data-i18n-skip>' + esc(r.name) + "</b><small>joined " + ago(r.t) + " &middot; " + fmt(r.g) + (r.g === 1 ? " game" : " games") + "</small></div>" +
          steps(r) +
          '<div class="iv-earn">' + (r.k > 0 ? "+" + fmt(r.k) + " Koban" + (r.cutK > 0 ? '<small>' + fmt(r.cutK) + " from their buys</small>" : "") : '<small>nothing yet</small>') + "</div></div>";
      }).join("");
    }
  }
  load();
})();
