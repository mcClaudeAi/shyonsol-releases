// The live mint tracker under the NFTs hero (api/mints.php).
// Left: the Shadow Wall, all 1,335 Shadows as a wall of tiles in number order. The minted ones light up in their Aura
// colour and flicker like lanterns, the newest send out a ripple, and the wall swells under your mouse or finger like
// a lens. Point at a tile to see that Shadow, click (or tap twice) to see it up close, find any number, or pick an Aura
// to light only those. Under it a gold rail with the milestones, and the numbers.
// Right: the newest mints sliding in as they happen (a flash and a pop-up when one lands while you watch). Below: the
// Auras minted so far, mints per day for two weeks, and the biggest collectors.
// Asks again every 20 seconds while the tracker is on screen and the tab is open.
//MC 2026-10-15 first version
//MC 2026-10-15 the ring on the left looked empty at a few percent (a thin arc in a big circle). Replaced it with the
//   Shadow Wall, which shows every Shadow and is something to play with, in the game's lacquer and gold.
(function () {
  "use strict";
  var box = document.getElementById("mint-live");
  if (!box) return;
  var API = "/api/mints.php", TOTAL = 1335, MILES = [100, 250, 500, 1000, 1335];
  var AV = (document.querySelector('script[src*="minttrack.js"]') || {}).src || "";
  AV = /\?v=([^&]+)/.exec(AV); AV = AV ? "?v=" + AV[1] : "";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var touchy = matchMedia("(hover: none)").matches;
  var phone = matchMedia("(max-width: 640px)").matches;
  var AURA = { "crimson glow": ["crimson", "#ff3b5c"], "electric cyan": ["cyan", "#4cc9f0"], "lightning aura": ["lightning", "#ffe066"], "money aura": ["money", "#f2c35b"], "btc aura": ["btc", "#f7931a"] };
  var SKIN = { crimson: "skin_crimson", cyan: "skin_cyan", lightning: "skin_storm", money: "skin_gold", btc: "skin_btc", none: "skin_void" };
  function au(name) { return AURA[String(name || "").toLowerCase()] || ["none", "#a78bfa"]; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function ago(t) {
    if (!t) return "before tracking";
    var s = Math.max(1, Math.round(Date.now() / 1000 - t));
    return s < 60 ? "just now" : s < 3600 ? Math.round(s / 60) + "m ago" : s < 86400 ? Math.round(s / 3600) + "h ago" : Math.round(s / 86400) + "d ago";
  }
  function fallback(x) { return "/assets/art/skins/" + SKIN[au(x.aura)[0]] + ".svg" + AV; }
  function $(s) { return box.querySelector(s); }
  var D = null, seenTop = null, timer = 0, lastOk = 0, onScreen = true;

  function countTo(el, to) {
    if (!el) return;
    var from = +(el.dataset.v || 0); el.dataset.v = to;
    if (reduce || from === to) { el.textContent = fmt(to); return; }
    var t0 = performance.now(), dur = from ? 700 : 1400;
    (function step(now) { var k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(from + (to - from) * e)); if (k < 1) requestAnimationFrame(step); })(t0);
    //MC 2026-10-15 animation frames can be paused (a background tab, some app views); the count still lands on the number
    setTimeout(function () { if (+el.dataset.v === to) el.textContent = fmt(to); }, dur + 200);
  }

  // ---------- one Shadow, fetched when you point at it (kept for the visit) ----------
  var ONE = {};
  function one(n) {
    if (!ONE[n]) ONE[n] = fetch(API + "?a=one&n=" + n).then(function (r) { return r.json(); }).catch(function () { delete ONE[n]; return null; });
    return ONE[n];
  }

  // =====================================================================================================================
  // the Shadow Wall
  // =====================================================================================================================
  var wallEl = $("[data-mt=wall]"), cv = wallEl.querySelector("canvas"), ctx = cv.getContext("2d"), tip = wallEl.querySelector(".mt-tip");
  var W = { cols: 45, rows: 30, cell: 12, w: 0, h: 0, dpr: 1, lit: {}, order: [], born: {}, cols8: [], glow: [], hx: -1, hy: -1, lens: 0, lensTo: 0, filter: -1, find: 0, sel: 0, intro: false, raf: 0, last: 0, dirty: true };

  function wallSize() {
    var cs = getComputedStyle(wallEl), w = Math.floor(wallEl.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight)); if (!(w > 0)) return;
    var cols = w >= 560 ? 45 : w >= 420 ? 40 : 35;
    W.cols = cols; W.rows = Math.ceil(TOTAL / cols); W.cell = w / cols; W.w = w; W.h = Math.ceil(W.rows * W.cell);
    W.dpr = Math.min(phone ? 1.5 : 2, window.devicePixelRatio || 1);
    cv.width = Math.round(w * W.dpr); cv.height = Math.round(W.h * W.dpr);
    cv.style.width = w + "px"; cv.style.height = W.h + "px";
    makeGlows(); W.dirty = true;
  }
  // a soft glow per Aura colour, drawn once and stamped behind every lit tile
  function makeGlows() {
    W.glow = W.cols8.map(function (c) {
      var g = document.createElement("canvas"), r = Math.ceil(W.cell * 1.6 * W.dpr); g.width = g.height = r * 2;
      var x = g.getContext("2d"), gr = x.createRadialGradient(r, r, 0, r, r, r);
      gr.addColorStop(0, hexA(c, .55)); gr.addColorStop(.45, hexA(c, .18)); gr.addColorStop(1, hexA(c, 0));
      x.fillStyle = gr; x.fillRect(0, 0, r * 2, r * 2); return g;
    });
  }
  function hexA(h, a) { var n = parseInt(h.slice(1), 16); return "rgba(" + (n >> 16) + "," + (n >> 8 & 255) + "," + (n & 255) + "," + a + ")"; }
  function cellXY(n) { var i = n - 1; return [(i % W.cols + .5) * W.cell, (Math.floor(i / W.cols) + .5) * W.cell]; }
  function cellAt(x, y) {
    var c = Math.floor(x / W.cell), r = Math.floor(y / W.cell);
    if (c < 0 || c >= W.cols || r < 0) return 0;
    var n = r * W.cols + c + 1; return n >= 1 && n <= TOTAL ? n : 0;
  }
  function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }

  function wallDraw(now) {
    var c = W.cell, d = W.dpr, R = c * 5.5, lens = W.lens, hx = W.hx, hy = W.hy;
    ctx.setTransform(d, 0, 0, d, 0, 0);
    ctx.clearRect(0, 0, W.w, W.h);
    var big = [], rip = [];
    var newest = {}; for (var k = 0; k < Math.min(3, W.order.length); k++) newest[W.order[k]] = k + 1;
    // pass 1: glows (added light), pass 2: tiles
    ctx.globalCompositeOperation = "lighter";
    for (var n = 1; n <= TOTAL; n++) {
      var ai = W.lit[n]; if (ai === undefined) continue;
      if (W.filter >= 0 && ai !== W.filter) continue;
      var p = born(n, now); if (p <= 0) continue;
      var xy = warp(n, now), fl = reduce ? 1 : .75 + .25 * Math.sin(now / 700 + n * 1.73);
      var g = W.glow[ai]; if (!g) continue;
      var gs = g.width / d * xy[2] * (0.6 + 0.4 * p);
      ctx.globalAlpha = fl * p; ctx.drawImage(g, xy[0] - gs / 2, xy[1] - gs / 2, gs, gs);
    }
    ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1;
    for (n = 1; n <= TOTAL; n++) {
      xy = warp(n, now);
      if (xy[2] > 1.15) { big.push(n); continue; }
      tile(n, xy, now, newest);
    }
    // the swollen ones on top, smallest first
    big.sort(function (a, b) { return warp(a, now)[2] - warp(b, now)[2]; });
    for (k = 0; k < big.length; k++) tile(big[k], warp(big[k], now), now, newest);
    // ripples from the newest mints
    if (!reduce) for (var m in newest) {
      xy = warp(+m, now); var ph = ((now / 2400) + newest[m] * .33) % 1, ci = W.cols8[W.lit[m]] || "#fff";
      ctx.strokeStyle = hexA(ci, (1 - ph) * .8); ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(xy[0], xy[1], c * (.5 + ph * 2.6), 0, 6.283); ctx.stroke();
    }
    // the Shadow you found
    if (W.find) {
      xy = warp(W.find, now); var pu = reduce ? .5 : (Math.sin(now / 260) + 1) / 2;
      ctx.strokeStyle = "rgba(255,226,154," + (.55 + .45 * pu) + ")"; ctx.lineWidth = 2;
      rr(xy[0] - c * xy[2] * .62 - 3, xy[1] - c * xy[2] * .62 - 3, c * xy[2] * 1.24 + 6, c * xy[2] * 1.24 + 6, 4); ctx.stroke();
    }
  }
  function tile(n, xy, now, newest) {
    var c = W.cell, s = c * .74 * xy[2], ai = W.lit[n], x = xy[0] - s / 2, y = xy[1] - s / 2;
    var dim = W.filter >= 0 && ai !== W.filter;
    if (ai === undefined || born(n, now) <= 0) {
      ctx.fillStyle = n === W.sel ? "rgba(255,255,255,.28)" : xy[2] > 1.15 ? "rgba(255,255,255,.12)" : "rgba(255,255,255,.055)";
      rr(x, y, s, s, Math.max(1.5, s * .22)); ctx.fill();
      return;
    }
    var p = born(n, now), col = W.cols8[ai] || "#a78bfa";
    if (p < 1) { var k = 1 + .6 * Math.sin(p * Math.PI); s *= k; x = xy[0] - s / 2; y = xy[1] - s / 2; }
    ctx.globalAlpha = dim ? .16 : 1;
    ctx.fillStyle = col; rr(x, y, s, s, Math.max(1.5, s * .22)); ctx.fill();
    // a little shine on the top edge, the way the game's tiles catch the light
    if (s > 5) { ctx.fillStyle = "rgba(255,255,255," + (dim ? .05 : .38) + ")"; rr(x + s * .16, y + s * .12, s * .68, Math.max(1, s * .16), s * .08); ctx.fill(); }
    if (n === W.sel || (xy[2] > 1.6 && !dim)) { ctx.strokeStyle = "rgba(255,255,255,.9)"; ctx.lineWidth = 1.5; rr(x - 1.5, y - 1.5, s + 3, s + 3, Math.max(2, s * .26)); ctx.stroke(); }
    ctx.globalAlpha = 1;
  }
  // the lens: tiles near the pointer swell and push outwards
  var warpCache = { t: -1, m: {} };
  function warp(n, now) {
    if (warpCache.t !== now) { warpCache.t = now; warpCache.m = {}; }
    var w = warpCache.m[n]; if (w) return w;
    var xy = cellXY(n), s = 1;
    if (W.lens > .01) {
      var dx = xy[0] - W.hx, dy = xy[1] - W.hy, dd = Math.sqrt(dx * dx + dy * dy), R = W.cell * 5.5;
      if (dd < R) { var f = 1 - dd / R; f = f * f * (3 - 2 * f); s = 1 + 1.25 * f * W.lens; xy = [xy[0] + dx * f * .45 * W.lens, xy[1] + dy * f * .45 * W.lens]; }
    }
    return (warpCache.m[n] = [xy[0], xy[1], s]);
  }
  // how far a tile is into lighting up (0 dark, 1 lit)
  function born(n, now) { var b = W.born[n]; if (b === undefined) return 1; return Math.max(0, Math.min(1, (now - b) / 520)); }

  function wallData(first) {
    var lit = {}, order = [];
    W.cols8 = (D.wa || []).map(function (a) { return au(a)[1]; });
    (D.wall || []).forEach(function (r) { lit[r[0]] = r[1]; order.push(r[0]); });
    var now = performance.now();
    if (first || !W.intro) {
      // lanterns lighting in mint order, oldest first, over about a second and a half
      W.born = {}; var len = order.length, span = reduce ? 0 : Math.min(1600, 30 * len);
      for (var i = 0; i < len; i++) W.born[order[i]] = now + 250 + span * ((len - 1 - i) / Math.max(1, len - 1));
      W.intro = true;
    } else {
      order.forEach(function (n) { if (W.lit[n] === undefined) W.born[n] = now; });
    }
    W.lit = lit; W.order = order;
    makeGlows(); W.dirty = true; legend(); kick();
    // the same for the wall: if no frame came, draw it as it ends up
    setTimeout(function () { if (D) wallDraw(performance.now() + 5000); }, 2400);
  }

  // ---------- the loop: about 30 frames a second while it's on screen (20 on phones), still when nothing moves ----------
  function kick() { if (!W.raf) W.raf = requestAnimationFrame(frame); }
  function frame(now) {
    W.raf = 0;
    var step = phone ? 50 : 33;
    W.lens += (W.lensTo - W.lens) * .22; if (Math.abs(W.lensTo - W.lens) < .005) W.lens = W.lensTo;
    var busy = !reduce || W.lens !== W.lensTo || anyBorn(now);
    if (now - W.last >= step || W.dirty) { W.last = now; W.dirty = false; if (D) wallDraw(now); }
    if (onScreen && !document.hidden && (busy || W.find)) W.raf = requestAnimationFrame(frame);
  }
  function anyBorn(now) { for (var n in W.born) if (now - W.born[n] < 560) return true; return false; }

  // ---------- pointing, tapping, finding ----------
  function pos(e) { var r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  function showTip(n) {
    if (!n) { tip.hidden = true; return; }
    var ai = W.lit[n], xy = cellXY(n), lit = ai !== undefined;
    var aura = lit ? (D.wa[ai] || "") : "";
    tip.style.setProperty("--mt-c", lit ? W.cols8[ai] : "#5b5470");
    tip.innerHTML = '<span class="mt-tip-art">' + (lit ? '<i class="mt-tip-sk"></i>' : '<em>?</em>') + '</span><span class="mt-tip-t"><b data-i18n-skip>#' + n + '</b>' +
      (lit ? '<small><i></i><span data-i18n-skip>' + esc(aura) + '</span></small><small class="mt-tip-go">' + (touchy ? "Tap again to see it" : "Click to see it") + '</small>' : '<small>Not minted yet</small>') + '</span>';
    tip.hidden = false;
    var tw = tip.offsetWidth, th = tip.offsetHeight, x = xy[0] - tw / 2, y = xy[1] - th - W.cell * 2.2;
    if (y < 4) y = xy[1] + W.cell * 2.2;
    tip.style.transform = "translate(" + Math.round(Math.max(4, Math.min(W.w - tw - 4, x))) + "px," + Math.round(y) + "px)";
    if (lit) one(n).then(function (x) {
      if (!x || !x.minted || tip.hidden || W.sel !== n) return;
      var a = tip.querySelector(".mt-tip-art"); if (!a) return;
      a.innerHTML = '<img src="' + esc(x.img || fallback(x)) + '" alt="" onerror="this.onerror=null;this.src=\'' + fallback(x) + '\'">';
      var r = tip.querySelector(".mt-tip-t"); if (r && x.rank) r.insertAdjacentHTML("beforeend", '<small class="mt-tip-r">Rarity <b data-i18n-skip>' + esc(String(x.rank).replace(/^#?/, "#")) + '</b></small>');
    });
  }
  function point(x, y) {
    W.hx = x; W.hy = y; W.lensTo = 1;
    var n = cellAt(x, y);
    if (n !== W.sel) { W.sel = n; showTip(n); }
    W.dirty = true; kick();
  }
  function leave() { W.lensTo = 0; W.sel = 0; showTip(0); W.dirty = true; kick(); }
  cv.addEventListener("pointermove", function (e) { if (e.pointerType === "mouse") { var p = pos(e); point(p[0], p[1]); } });
  cv.addEventListener("pointerleave", function (e) { if (e.pointerType === "mouse") leave(); });
  cv.addEventListener("click", function (e) {
    var p = pos(e), n = cellAt(p[0], p[1]); if (!n) return;
    W.find = 0;
    // a mouse opens it straight away; a finger first looks, then opens on a second tap of the same tile
    if (!touchy || n === W.sel) { if (W.lit[n] !== undefined) openN(n); else point(p[0], p[1]); return; }
    point(p[0], p[1]);
  });
  document.addEventListener("pointerdown", function (e) { if (touchy && W.sel && !wallEl.contains(e.target)) leave(); }, { passive: true });

  var findF = $("[data-mt=find]");
  findF.addEventListener("submit", function (e) {
    e.preventDefault();
    var inp = findF.querySelector("input"), n = parseInt(String(inp.value).replace(/\D/g, ""), 10);
    if (!(n >= 1 && n <= TOTAL)) { findF.classList.remove("bad"); void findF.offsetWidth; findF.classList.add("bad"); return; }
    W.find = n; var xy = cellXY(n); point(xy[0], xy[1]);
    wallEl.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" });
  });

  // ---------- Aura chips: pick one to light only those ----------
  function legend() {
    var el = $("[data-mt=legend]"); if (!el || !D) return;
    var counts = {}; (D.auras || []).forEach(function (x) { counts[x.a] = x.n; });
    el.innerHTML = (D.wa || []).map(function (a, i) {
      if (/^unknown$/i.test(a)) return "";   // a Shadow whose details Solana hasn't served yet
      var label = /^no aura$/i.test(a) ? a : String(a).replace(/ Aura$/i, "");
      return '<button type="button" class="mt-chip' + (W.filter === i ? " on" : "") + '" data-mt-f="' + i + '" style="--mt-c:' + W.cols8[i] + '" aria-pressed="' + (W.filter === i) + '"><i></i><span data-i18n-skip>' + esc(label) + '</span><b data-i18n-skip>' + fmt(counts[a] || 0) + '</b></button>';
    }).join("");
    box.classList.toggle("mt-filtered", W.filter >= 0);
  }
  box.addEventListener("click", function (e) {
    var f = e.target.closest("[data-mt-f]"); if (!f) return;
    var i = +f.dataset.mtF; W.filter = W.filter === i ? -1 : i; legend(); W.dirty = true; kick();
  });

  // ---------- the rail and the numbers ----------
  function rail() {
    var pct = D.minted / D.total;
    var fill = $(".mt-rail-fill"); if (fill) fill.style.width = (pct * 100).toFixed(2) + "%";
    box.querySelectorAll(".mt-rail-mk").forEach(function (m) { m.classList.toggle("hit", D.minted >= +m.dataset.at); });
    var next = MILES.filter(function (m) { return m > D.minted; })[0];
    $("[data-mt=next]").textContent = next ? (next === TOTAL ? "Next: sold out, " : "Next: " + fmt(next) + " minted, ") + fmt(next - D.minted) + " to go" : "Every Shadow is out";
  }

  function draw(first) {
    var pct = D.minted / D.total;
    countTo($("[data-mt=minted]"), D.minted);
    countTo($("[data-mt=left]"), D.left);
    countTo($("[data-mt=holders]"), D.holders);
    countTo($("[data-mt=last24]"), D.last24);
    $("[data-mt=pct]").textContent = (Math.floor(pct * 1000) / 10) + "%";
    $("[data-mt=leftline]").textContent = D.left > 0 ? "Only " + fmt(D.left) + " Shadows left" : "Sold out";
    setTimeout(rail, first ? 150 : 0);
    if (first) wallSize();
    wallData(first);
    // the newest mints
    var feed = $("[data-mt=feed]");
    var fresh = seenTop === null ? [] : D.recent.filter(function (x) { return seenTop.indexOf(x.n) < 0; });
    feed.innerHTML = D.recent.slice(0, 16).map(function (x, i) {
      var a = au(x.aura), isNew = fresh.some(function (f) { return f.n === x.n; });
      return '<button type="button" class="mt-m' + (isNew ? " new" : "") + '" data-mt-i="' + i + '" style="--mt-c:' + a[1] + '">' +
        '<span class="mt-mi"><img src="' + esc(x.img || fallback(x)) + '" alt="" loading="lazy" onerror="this.onerror=null;this.src=\'' + fallback(x) + '\'"></span>' +
        '<span class="mt-mt"><b data-i18n-skip>#' + esc(x.n) + '</b><small><i></i>' + esc(x.aura || "Aura") + '</small></span>' +
        '<span class="mt-mw"><small>' + ago(x.t) + '</small><small class="mt-own" data-i18n-skip>' + esc(x.owner) + '</small></span></button>';
    }).join("");
    if (fresh.length && seenTop !== null) toast(fresh[0]);
    seenTop = D.recent.map(function (x) { return x.n; });
    // Auras minted so far
    var max = Math.max.apply(null, D.auras.map(function (x) { return x.n; }).concat([1]));
    $("[data-mt=auras]").innerHTML = D.auras.slice(0, 6).map(function (x) {
      var a = au(x.a), p = D.minted ? Math.round(x.n / D.minted * 1000) / 10 : 0, i = (D.wa || []).indexOf(x.a);
      return '<li style="--mt-c:' + a[1] + '" tabindex="0" role="button"' + (i >= 0 ? ' data-mt-f="' + i + '"' : "") + ' title="Light only these on the wall"><span class="mt-an"><i></i>' + esc(x.a) + '</span><span class="mt-ab"><i style="width:' + Math.max(3, Math.round(x.n / max * 100)) + '%"></i></span><b>' + fmt(x.n) + '</b><small>' + p + '%</small></li>';
    }).join("");
    // mints per day
    var dm = Math.max.apply(null, D.days.map(function (x) { return x.n; }).concat([1]));
    var any = D.days.some(function (x) { return x.n > 0; });
    $("[data-mt=days]").innerHTML = any ? D.days.map(function (x) {
      var d = new Date(x.d + "T12:00:00Z"), lbl = d.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" });
      return '<span class="mt-d" title="' + esc(lbl + ": " + x.n + (x.n === 1 ? " mint" : " mints")) + '"><i style="height:' + Math.max(4, Math.round(x.n / dm * 100)) + '%"></i><small>' + x.n + '</small></span>';
    }).join("") : '<p class="mt-empty">Mints per day show here from the first day of tracking.</p>';
    // collectors
    $("[data-mt=top]").innerHTML = D.top.map(function (x, i) { return '<li><span>' + (i + 1) + '</span><b data-i18n-skip>' + esc(x.w) + '</b><em>' + fmt(x.n) + '</em></li>'; }).join("");
    lastOk = Date.now(); stamp();
  }
  function stamp() { var s = $("[data-mt=at]"); if (s && lastOk) { var k = Math.round((Date.now() - lastOk) / 1000); s.textContent = k < 5 ? "Updated just now" : "Updated " + k + "s ago"; } }
  function toast(x) {
    var t = document.createElement("div"); var a = au(x.aura);
    t.className = "mt-toast"; t.style.setProperty("--mt-c", a[1]);
    t.innerHTML = '<img src="' + esc(x.img || fallback(x)) + '" alt="" onerror="this.onerror=null;this.src=\'' + fallback(x) + '\'"><span><b>Just minted</b><small data-i18n-skip>#' + esc(x.n) + (x.aura ? " · " + esc(x.aura) : "") + '</small></span>';
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add("in"); });
    setTimeout(function () { t.classList.remove("in"); setTimeout(function () { t.remove(); }, 500); }, 4200);
  }

  // ---------- a Shadow up close ----------
  function openN(n) {
    var r = D.recent.filter(function (x) { return x.n === n; })[0];
    if (r) return open(r);
    one(n).then(function (x) { if (x && x.minted) open(x); });
  }
  function open(x) {
    if (!x) return;
    var a = au(x.aura), src = x.img || fallback(x);
    var o = document.createElement("div"); o.className = "mt-ov"; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true"); o.style.setProperty("--mt-c", a[1]);
    o.innerHTML = '<div class="mt-ov-in"><button type="button" class="mt-x" aria-label="Close">&times;</button><div class="mt-ov-art">' +
      (window.ShyLiving ? ShyLiving.html(src, { aura: a[0], cls: "enter", size: "min(64vw,260px)", alt: "Shytoshi Shadow #" + x.n, fb: fallback(x) }) : '<img src="' + esc(src) + '" alt="">') +
      '</div><span class="mt-k">Shytoshi Shadow</span><h3 data-i18n-skip>#' + esc(x.n) + '</h3><div class="mt-chips"><span><i></i>' + esc(x.aura || "Aura") + '</span>' + (x.rank ? '<span><small>Rarity</small> <b data-i18n-skip>' + esc(String(x.rank).replace(/^#?/, "#")) + '</b></span>' : "") + '</div>' +
      '<p class="mt-ov-l"><span>Minted ' + ago(x.t) + '</span> · <span data-i18n-skip>' + esc(x.owner) + '</span></p>' +
      '<div class="mt-ov-b">' + (x.asset ? '<a class="btn btn-line btn-sm" href="https://solscan.io/token/' + esc(x.asset) + '" target="_blank" rel="noopener">See it on Solana</a>' : "") + '<a class="btn btn-red btn-sm" href="https://launchmynft.io/mint/shyshadows" target="_blank" rel="noopener">Mint yours</a></div></div>';
    document.body.appendChild(o);
    var close = function () { o.remove(); document.removeEventListener("keydown", key); };
    var key = function (e) { if (e.key === "Escape") close(); };
    o.addEventListener("click", function (e) { if (e.target === o || e.target.closest(".mt-x")) close(); });
    document.addEventListener("keydown", key);
    o.querySelector(".mt-x").focus();
  }
  //MC 2026-10-15 the site's tap ripple (app.js) changes the row between mouse down and up, and the browser then sends the
//   click to the list instead of the row; so when that happens, the row under the pointer is the one
box.addEventListener("click", function (e) {
    var b = e.target.closest("[data-mt-i]");
    if (!b && e.target.closest("[data-mt=feed]") && e.clientX) { var u = document.elementFromPoint(e.clientX, e.clientY); b = u && u.closest("[data-mt-i]"); }
    if (b) open(D.recent[+b.dataset.mtI]);
  });
  box.addEventListener("keydown", function (e) { var f = e.target.closest("li[data-mt-f]"); if (f && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); f.click(); } });

  // ---------- asking for news ----------
  function load(first) {
    fetch(API + "?a=stats", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok) { if (first) box.classList.add("mt-off"); return; }
      box.classList.remove("mt-off", "mt-wait"); D = j; draw(first);
    }).catch(function () { if (first) box.classList.add("mt-off"); });
  }
  function loop() { clearTimeout(timer); timer = setTimeout(function () { if (!document.hidden && onScreen) load(false); loop(); }, 20000); }
  if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { onScreen = es[0].isIntersecting; if (onScreen) kick(); }).observe(box);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) kick(); });
  var rz = 0; window.addEventListener("resize", function () { clearTimeout(rz); rz = setTimeout(function () { if (D) { phone = matchMedia("(max-width: 640px)").matches; wallSize(); leave(); } }, 150); });
  setInterval(stamp, 5000);
  load(true); loop();
})();
