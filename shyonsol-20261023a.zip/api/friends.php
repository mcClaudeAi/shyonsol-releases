<?php
// Friends, live challenges and Duels for players.
// POST {a, pid, key, ...}
//   poll                        -> keeps "online" fresh; unread notices and counts (the site calls it every minute or so)
//   list                        -> friends, requests, Duels, the Friends board
//   who {id}                    -> the player an invite link points to
//   add {who}                   -> a friend request by player name, 6-letter id or invite link
//   accept|decline|cancel|remove|block|unblock {id}   (id = the other player's 6-letter id)
//   seen {ids}                  -> notices read
//   live {to, code}             -> challenge a friend to the private room you're hosting
//   duel {to}                   -> start a Duel: you play first, then they get the same deal
//   duel-decline {id}
//   push-key | push-on {endpoint, ua} | push-off {endpoint}
// POST {a: push-pull, endpoint}  -> the service worker asks what to show (no profile key in a service worker)

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/friendslib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 4000) fail('too large');
$body = json_decode($raw, true) ?: [];
$a = (string)($body['a'] ?? '');

// how a notice reads, for the site and for browser notifications
function notice_text($n, $players) {
    $who = fr_name($players, $n['from']);
    switch ($n['k']) {
        case 'req': return [$who . ' wants to be friends', 'Accept to challenge each other and see each other online.'];
        case 'acc': return [$who . ' accepted your friend request', 'Challenge them to a live match or a Duel.'];
        case 'house': return ['Welcome to ' . ($n['d']['house'] ?? 'your House'), $who . ' let you in. Your weekly points now count for the House.'];
        case 'ref':
            $w9 = $n['d']['why'] ?? '';
            return $w9 === 'holder' ? ['+' . number_format($n['d']['k']) . ' Koban: ' . $who . ' holds $SHY', 'Your invite bonus is in your Koban.']
                : ($w9 === 'mint' ? ['+' . number_format($n['d']['k']) . ' Koban: ' . $who . ' minted a Shadow', 'Your invite reward is in your Koban.']
                : ($w9 === 'cut' ? ['+' . number_format($n['d']['k']) . ' Koban: your cut of ' . $who . "'s Dojo buy", 'Your invites pay you a cut of every Koban they buy.']
                : ['+' . number_format($n['d']['k']) . ' Koban for your invite', $who . ' joined with your link and played their first game.']));
        case 'live': return [$who . ' is calling you out', 'Live match, room ' . $n['d']['code'] . '. Join in the next few minutes.'];
        case 'later': return [$who . ' will join after their game', 'They are finishing a game and lined up your room ' . $n['d']['code'] . ' as their next match. Hold the room and they will be right in.'];
        case 'liveno': return [$who . " can't make it this time", 'They had lined up your room ' . $n['d']['code'] . ' but called it off. Start with bots, or try a Duel.'];
        case 'duel': return [$who . ' challenged you to a Duel', 'Same deal, one shot each. Beat ' . $n['d']['g'] . ' ' . ($n['d']['g'] === 1 ? 'Region' : 'Regions') . '.'];
        case 'duelno': return [$who . ' passed on your Duel', 'Try another one, or a live match.'];
        case 'duelres':
            $w = $n['d']['w'];
            return ['Duel with ' . $who . ' is done', ($w === 'me' ? 'You won, ' : ($w === 'tie' ? "It's a tie, " : $who . ' won, ')) . ($w === 'them' ? $n['d']['theirs'] . ' to ' . $n['d']['mine'] : $n['d']['mine'] . ' to ' . $n['d']['theirs']) . '.'];
        //MC 2026-10-18 the cron notifications (api/pushbc.php): short, worth the knock, in the site's own voice
        case 'expback': return ['Your Shadow is back', ((int)$n['d']['k'] > 0 ? number_format((int)$n['d']['k']) . ' Koban came home with it. ' : 'The expedition is done. ') . 'Tap to collect.'];
        case 'daily': return ['Daily Challenge #' . (int)$n['d']['no'] . ' is live', 'Same deck for everyone, one run each, and it counts for the Weekly League.'];
        case 'weekly': return ['A fresh week in the League', 'The weekly board reset. Every game from here counts for your rank and your House.'];
        case 'shopnew':
            $nm = (array)($n['d']['names'] ?? []);
            return [count($nm) === 1 ? 'New in the Dojo: ' . $nm[0] : 'New in the Dojo', count($nm) === 1 ? 'Just arrived. See it before everyone else wears it.' : implode(', ', $nm) . ' just arrived in the shop.'];
        case 'shopend': return ['Last call: ' . $n['d']['name'], 'It leaves the Dojo within two days. After that, it is gone.'];
        case 'ping': return ['Notifications are on', 'This is how a knock from Shilluminati Online lands on this device. The important things only.'];
    }
    return [$who, ''];
}
function notice_url($n, $players) {
    switch ($n['k']) {
        case 'house': return '/houses';
        case 'live': return '/play?room=' . $n['d']['code'];
        case 'later': case 'liveno': return '/play';
        case 'duel': return '/play?duel=' . $n['d']['id'];
        case 'duelres': return '/play?duelvs=' . fr_tag($n['from']);
        case 'expback': return '/play#g-exp';
        case 'daily': return '/play?daily=1';
        case 'weekly': return '/play#game';
        case 'shopnew': case 'shopend': return '/play#shop';
    }
    return '/play?friends=1';
}
function notice_out($n, $players) {
    [$t, $b] = notice_text($n, $players);
    return ['id' => $n['id'], 'k' => $n['k'], 'from' => fr_tag($n['from']), 'name' => fr_name($players, $n['from']), 'd' => $n['d'], 'ts' => $n['ts'], 'seen' => $n['seen'], 'title' => $t, 'body' => $b, 'url' => notice_url($n, $players)];
}

if ($a === 'push-pull') {
    $e = (string)($body['endpoint'] ?? '');
    if (!preg_match('#^https://#', $e) && empty(shy_config()['push_test'])) fail('bad endpoint');
    $pid = with_lock(fn() => push_owner($e));
    if (!$pid) fail('unknown', 404);
    $players = load(PLAYERS);
    $list = array_values(array_filter(fr_notices_live(load(NOTICES)[$pid] ?? []), fn($n) => !$n['seen']));
    if (!$list) out(['ok' => true, 'title' => 'Shilluminati Online', 'body' => 'Something new is waiting for you.', 'url' => '/play?friends=1', 'n' => 0]);
    $o = notice_out($list[0], $players);
    //MC 2026-10-18 re: a rival at the door buzzes again (renotify), the morning call and shop news never double-buzz
    out(['ok' => true, 'title' => $o['title'], 'body' => $o['body'], 'url' => $o['url'], 'tag' => $o['k'] . '-' . $o['from'],
        're' => in_array($o['k'], ['live', 'duel', 'req', 'later', 'ping'], true) ? 1 : 0, 'n' => count($list)]);
}

$pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
if (function_exists('seen_mark') && key_ok($pid, $kh)) seen_mark($pid);   //MC 2026-10-19 the invite farm gate's network and device stamp: only for the key's real owner, throttled inside

function limit_or_fail($what, $max, $window) {
    $ok = with_lock(function () use ($what, $max, $window) { $l = load(LIMITS); $ok = rate_ok($l, $what, $max, $window); save(LIMITS, $l); return $ok; });
    if (!$ok) fail('Slow down a little and try again.', 429);
}
limit_or_fail('fr:' . client_ip(), 240, 600);

// run fn with the lock held, after checking the key. fn gets the players file; returns ['err'=>..] to fail.
function act($fn) {
    global $pid, $kh;
    $r = with_lock(function () use ($fn, $pid, $kh) {
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        return $fn($players);
    });
    if (isset($r['err'])) { $c = $r['code'] ?? 400; unset($r['code']); out(['ok' => false, 'error' => $r['err']] + array_diff_key($r, ['err' => 1]), $c); }
    return $r;
}
// the other player from a 6-letter id: someone already connected to me first, then anyone with a name
function other($players, $mine, $tag) {
    $tag = strtolower((string)$tag);
    if (!preg_match('/^[a-f0-9]{6}$/', $tag)) return null;
    foreach (['f', 'in', 'out', 'bl'] as $k) foreach ($mine[$k] as $p => $_) if (fr_tag($p) === $tag) return $p;
    foreach ($players as $p => $x) if (fr_tag($p) === $tag && !empty($x['name'])) return $p;
    return null;
}
function need_name($players, $pid) { return empty($players[$pid]['name']) ? ['err' => 'Pick a player name first: play a game and save your score, or set it on your profile.', 'code' => 400, 'needName' => true] : null; }

// ---------------------------------------------------------------- reads
if ($a === 'poll') {
    $r = act(function ($players) use ($pid) {
        //MC 2026-10-19 the poll runs on every page, so it is the first place a combined-away pid's device hears
        //   where its profile went (friends.js swaps the stored id and reloads)
        if (function_exists('pid_moved') && ($mv = pid_moved($pid, $players))) return ['moved' => $mv, 'name' => (string)($players[$mv]['name'] ?? '')];
        $pres = load(PRESENCE);
        if (!empty($players[$pid]['hideon'])) { if (isset($pres[$pid])) { unset($pres[$pid]); save(PRESENCE, $pres); } }
        elseif (time() - (int)($pres[$pid] ?? 0) > 45) { $pres[$pid] = time(); if (count($pres) > 5000) { arsort($pres); $pres = array_slice($pres, 0, 4000, true); } save(PRESENCE, $pres); }
        // everyone else online, for the "players online now" strip in the lobby
        $on = fr_online_list($pres, $players);
        track_max('peak_online', count($on));   //MC 2026-10-09 most players online at once, for the daily report
        unset($on[$pid]);
        $faces = array_map(fn($p) => ['name' => fr_name($players, $p), 'img' => !empty($players[$p]['avatar']) && !empty($players[$p]['holder']) ? shadow_img($players[$p]['avatar']) : ''], array_slice(array_keys($on), 0, 4));
        $mine = fr_of(fr_all(), $pid);
        $notes = fr_notices_live(load(NOTICES)[$pid] ?? []);
        $duels = duels_tidy();
        $turn = 0;
        foreach ($duels as $x) if ($x['b'] === $pid && $x['st'] === 'open' && !$x['rb']) $turn++;
        return ['online' => count(array_filter(array_keys($mine['f']), fn($f) => fr_online($pres, $f))), 'all' => count($on), 'faces' => $faces, 'hidden' => !empty($players[$pid]['hideon']), 'friends' => count($mine['f']), 'requests' => count($mine['in']), 'duels' => $turn,
            'notices' => array_map(fn($n) => notice_out($n, $players), array_values(array_filter($notes, fn($n) => !$n['seen'])))];
    });
    out(['ok' => true] + $r);
}

if ($a === 'list') {
    $r = act(function ($players) use ($pid) {
        $all = fr_all(); $mine = fr_of($all, $pid); $pres = load(PRESENCE); $duels = duels_tidy();
        $wk = week_key();
        $eco = load(ECO); $hol = load(HOLDERS);
        $row = function ($p, $extra = []) use ($players, $pres, $pid, $duels, $wk, &$eco, $hol) {
            $x = $players[$p] ?? [];
            $skin = isset($eco[$p]) ? (eco_public(eco_get($eco, $p), holder_tier($hol[$p] ?? null))['skin'] ?? '') : '';
            [$w, $l, $t] = duel_record($duels, $pid, $p);
            return ['id' => fr_tag($p), 'name' => fr_name($players, $p), 'avatar' => $x['avatar'] ?? '', 'img' => !empty($x['avatar']) ? shadow_img($x['avatar']) : '', 'holder' => !empty($x['holder']),
                'skin' => $skin, 'aura' => !empty($x['avatar']) && !empty($x['holder']) ? shadow_aura($x['avatar']) : '', 'halo' => !empty($x['avatar']) && !empty($x['holder']) && isset($eco[$p]) ? (eco_public(eco_get($eco, $p), holder_tier($hol[$p] ?? null))['halo'] ?? '') : '', 'online' => fr_online($pres, $p), 'seen' => (int)($pres[$p] ?? ($x['last'] ?? 0)), 'wpts' => ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0, 'x' => $x['xu'] ?? '',
                'tier' => holder_tier($hol[$p] ?? null), 'rec' => [$w, $l, $t],
                'pfr' => isset($eco[$p]) ? (eco_public(eco_get($eco, $p), holder_tier($hol[$p] ?? null))['pfr'] ?? '') : ''] + $extra;   //MC 2026-10-10 Profile Studio portrait frame
        };
        $friends = array_map(fn($p) => $row($p, ['since' => $mine['f'][$p]]), array_keys($mine['f']));
        usort($friends, fn($x, $y) => [$y['online'], $y['seen']] <=> [$x['online'], $x['seen']]);
        $ds = [];
        foreach ($duels as $id => $x) if ($x['a'] === $pid || $x['b'] === $pid) { if ($x['st'] === 'new' && $x['b'] === $pid) continue; $ds[] = duel_view($x, $id, $pid, $players); }
        usort($ds, fn($x, $y) => [$y['turn'], $y['ts']] <=> [$x['turn'], $x['ts']]);
        $tg = tg_user_of($pid);
        return ['me' => ['id' => fr_tag($pid), 'name' => $players[$pid]['name'] ?? '', 'tg' => (bool)$tg, 'tgdm' => $tg && !empty($tg['dm']) && !empty(tg_notes($tg)['friends']),
                'push' => count(load(PUSHSUBS)[$pid] ?? []), 'hidden' => !empty($players[$pid]['hideon'])], 'ref' => ref_summary($pid),
            'friends' => $friends, 'in' => array_map(fn($p) => $row($p), array_keys($mine['in'])), 'out' => array_map(fn($p) => $row($p), array_keys($mine['out'])),
            'blocked' => array_map(fn($p) => ['id' => fr_tag($p), 'name' => fr_name($players, $p)], array_keys($mine['bl'])),
            'duels' => array_slice($ds, 0, 30), 'board' => array_map(fn($b) => ['id' => fr_tag($b['pid']), 'name' => $b['name'], 'pts' => $b['pts'], 'me' => $b['me'], 'holder' => $b['holder']], fr_board($pid)),
            'tgBot' => tg_cfg()['bot'] ?? ''];
    });
    out(['ok' => true] + $r);
}

//MC 2026-10-09 Online now: who else has the site open right now, friends first, so anyone can invite them straight into
//a live match. Blocked players (either way) are left out.
if ($a === 'online') {
    $r = act(function ($players) use ($pid) {
        $all = fr_all(); $mine = fr_of($all, $pid); $pres = load(PRESENCE); $wk = week_key();
        $eco = load(ECO); $hol = load(HOLDERS);
        $on = fr_online_list($pres, $players); unset($on[$pid]);
        $rows = [];
        foreach ($on as $p => $ts) {
            if (isset($mine['bl'][$p]) || isset(fr_of($all, $p)['bl'][$pid])) continue;
            $x = $players[$p]; $tr = holder_tier($hol[$p] ?? null);
            $pub = isset($eco[$p]) ? eco_public(eco_get($eco, $p), $tr) : [];
            $sh = !empty($x['avatar']) && !empty($x['holder']);
            $rows[] = ['id' => fr_tag($p), 'name' => fr_name($players, $p), 'img' => $sh ? shadow_img($x['avatar']) : '', 'holder' => !empty($x['holder']),
                'skin' => $pub['skin'] ?? '', 'aura' => $sh ? shadow_aura($x['avatar']) : '', 'halo' => $sh ? ($pub['halo'] ?? '') : '', 'tier' => $tr, 'pfr' => $pub['pfr'] ?? '',
                'wpts' => ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0, 'games' => (int)($x['games'] ?? 0),
                'friend' => isset($mine['f'][$p]), 'pending' => isset($mine['out'][$p]), 'asked' => isset($mine['in'][$p])];
            if (count($rows) >= 120) break;
        }
        usort($rows, fn($x, $y) => [$y['friend'], $y['wpts']] <=> [$x['friend'], $x['wpts']]);
        return ['players' => $rows, 'hidden' => !empty($players[$pid]['hideon']), 'named' => !empty($players[$pid]['name'])];
    });
    out(['ok' => true] + $r);
}
//MC 2026-10-09 Find players: browse everyone with a player name, 10 to a page, with a search and a few ways to sort.
//  f: all (online first, then most recently active) | online | week (points this week) | top (all-time points) | holders
//  q: part of a name, or a 6-letter player id
const FIND_PER = 10;
if ($a === 'find') {
    $r = act(function ($players) use ($pid, $body) {
        $f = in_array($body['f'] ?? 'all', ['all', 'online', 'week', 'top', 'holders'], true) ? ($body['f'] ?? 'all') : 'all';   //MC 2026-10-11 no warning when f is left out
        $q = mb_strtolower(trim(mb_substr((string)($body['q'] ?? ''), 0, 40)));
        $page = max(1, (int)($body['page'] ?? 1));
        $all = fr_all(); $mine = fr_of($all, $pid); $pres = load(PRESENCE); $wk = week_key();
        $on = fr_online_list($pres, $players);
        $hit = [];
        foreach ($players as $p => $x) {
            if ($p === $pid || empty($x['name']) || isset($mine['bl'][$p])) continue;
            if ($q !== '' && strpos(mb_strtolower($x['name']), $q) === false && fr_tag($p) !== $q) continue;
            $o = isset($on[$p]); $w = ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0;
            if ($f === 'online' && !$o) continue;
            if ($f === 'week' && !$w) continue;
            if ($f === 'holders' && empty($x['holder'])) continue;
            if (($f === 'top' || $f === 'holders') && empty($x['games'])) continue;
            $last = max((int)($x['last'] ?? 0), (int)($pres[$p] ?? 0));
            $key = $f === 'week' ? [$w, $last] : ($f === 'top' || $f === 'holders' ? [(int)($x['points'] ?? 0), $last] : [(int)$o, $last]);
            // an exact name or id match goes to the top of a search
            if ($q !== '' && (mb_strtolower($x['name']) === $q || fr_tag($p) === $q)) array_unshift($key, 1); else array_unshift($key, 0);
            $hit[$p] = $key;
        }
        // drop anyone who blocked me (checked only for the matches, it's cheaper)
        foreach ($hit as $p => $_) if (isset(fr_of($all, $p)['bl'][$pid])) unset($hit[$p]);
        uasort($hit, fn($x, $y) => $y <=> $x);
        $total = count($hit); $pages = max(1, (int)ceil($total / FIND_PER)); $page = min($page, $pages);
        $eco = load(ECO); $hol = load(HOLDERS); $rows = [];
        foreach (array_slice(array_keys($hit), ($page - 1) * FIND_PER, FIND_PER) as $p) {
            $x = $players[$p]; $tr = holder_tier($hol[$p] ?? null);
            $pub = isset($eco[$p]) ? eco_public(eco_get($eco, $p), $tr) : [];
            $sh = !empty($x['avatar']) && !empty($x['holder']);
            $rows[] = ['id' => fr_tag($p), 'name' => $x['name'], 'img' => $sh ? shadow_img($x['avatar']) : '', 'holder' => !empty($x['holder']),
                'skin' => $pub['skin'] ?? '', 'aura' => $sh ? shadow_aura($x['avatar']) : '', 'halo' => $sh ? ($pub['halo'] ?? '') : '', 'tier' => $tr, 'pfr' => $pub['pfr'] ?? '',
                'online' => isset($on[$p]), 'seen' => max((int)($x['last'] ?? 0), (int)($pres[$p] ?? 0)), 'wpts' => ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0,
                'points' => (int)($x['points'] ?? 0), 'games' => (int)($x['games'] ?? 0), 'house' => house_tag_of($p),
                'friend' => isset($mine['f'][$p]), 'pending' => isset($mine['out'][$p]), 'asked' => isset($mine['in'][$p])];
        }
        return ['players' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'per' => FIND_PER, 'f' => $f, 'q' => $q,
            'online' => count($on) - (isset($on[$pid]) ? 1 : 0), 'hidden' => !empty($players[$pid]['hideon']), 'named' => !empty($players[$pid]['name'])];
    });
    out(['ok' => true] + $r);
}
// "Show me as online": off hides the green dot everywhere and keeps you off the Online now list
if ($a === 'hide') {
    $r = act(function ($players) use ($pid, $body) {
        if (empty($players[$pid])) return ['err' => 'Play a game first, then you can choose this.', 'code' => 400];
        $hide = !empty($body['hide']);
        if ($hide) $players[$pid]['hideon'] = 1; else unset($players[$pid]['hideon']);
        save(PLAYERS, $players);
        $pres = load(PRESENCE);
        if ($hide) unset($pres[$pid]); else $pres[$pid] = time();
        save(PRESENCE, $pres);
        return ['hidden' => $hide];
    });
    out(['ok' => true] + $r);
}
// the tab or app closed: drop the green dot now instead of waiting for it to run out
if ($a === 'bye') {
    ignore_user_abort(true);   // the page is going away; finish even if the browser stops listening
    act(function ($players) use ($pid) { $pres = load(PRESENCE); if (isset($pres[$pid])) { unset($pres[$pid]); save(PRESENCE, $pres); } return []; });
    out(['ok' => true]);
}

// ---------------------------------------------------------------- friends
// who an invite link points to, before adding them
if ($a === 'who') {
    $r = act(function ($players) use ($pid, $body) {
        $to = fr_find($players, (string)($body['id'] ?? ''));
        if (!$to) return ['err' => "We couldn't find that player.", 'code' => 404];
        $x = $players[$to]; $mine = fr_of(fr_all(), $pid);
        return ['id' => fr_tag($to), 'name' => fr_name($players, $to), 'img' => !empty($x['avatar']) ? shadow_img($x['avatar']) : '', 'self' => $to === $pid,
            'friend' => isset($mine['f'][$to]), 'pending' => isset($mine['out'][$to]), 'asked' => isset($mine['in'][$to])];
    });
    out(['ok' => true] + $r);
}
// someone opened an invite link (/play?friend=abc123): remember who invited them, for the invite reward
if ($a === 'ref') {
    limit_or_fail('ref:' . client_ip(), 6, 86400);
    $r = act(function ($players) use ($pid, $kh, $body) {
        $by = fr_find($players, (string)($body['id'] ?? ''));
        if (!$by) return ['err' => 'not found', 'code' => 404];
        key_add($pid, $kh);
        return ['why' => ref_record($pid, $by)];
    });
    out(['ok' => true, 'counted' => ($r['why'] ?? 'x') === '']);
}

if ($a === 'add') {
    limit_or_fail('fradd:' . $pid, 30, 3600);
    $r = act(function ($players) use ($pid, $kh, $body) {
        if ($e = need_name($players, $pid)) return $e;
        $to = fr_find($players, (string)($body['who'] ?? ''));
        if (!$to) return ['err' => "We couldn't find that player. Check the name, or ask for their invite link.", 'code' => 404];
        if ($to === $pid) return ['err' => "That's you."];
        $all = fr_all(); $me = fr_of($all, $pid); $them = fr_of($all, $to);
        $name = fr_name($players, $to);
        if (isset($me['f'][$to])) return ['err' => "You're already friends with $name."];
        if (isset($them['bl'][$pid])) return ['err' => "You can't add $name."];
        if (isset($me['bl'][$to])) unset($me['bl'][$to]);
        if (count($me['f']) >= FR_MAX) return ['err' => 'You have ' . FR_MAX . ' friends, the most there can be.'];
        key_add($pid, $kh);
        // they already asked me: that's a yes from both sides
        if (isset($me['in'][$to])) {
            unset($me['in'][$to], $them['out'][$pid]);
            $me['f'][$to] = $them['f'][$pid] = time();
            $all[$pid] = $me; $all[$to] = $them; save(FRIENDS, $all);
            fr_notify($to, 'acc', $pid, [], ['🤝 <b>' . tg_h(fr_name($players, $pid)) . '</b> is now your friend in Shilluminati Online.', tg_kb('⚔️ Challenge them', 'duelvs_' . fr_tag($pid))], ['url' => '/play?friends=1']);
            return ['friends' => true, 'name' => $name];
        }
        if (isset($me['out'][$to])) return ['sent' => true, 'name' => $name, 'again' => true];
        if (count($me['out']) >= 50) return ['err' => 'You have 50 requests waiting. Cancel some first.'];
        $me['out'][$to] = $them['in'][$pid] = time();
        $all[$pid] = $me; $all[$to] = $them; save(FRIENDS, $all);
        track('fr_req');
        fr_notify($to, 'req', $pid, [], ['👋 <b>' . tg_h(fr_name($players, $pid)) . '</b> wants to be friends in Shilluminati Online. Friends can challenge each other to live matches and Duels.', tg_kb('Open friends', 'friends')], ['url' => '/play?friends=1']);
        return ['sent' => true, 'name' => $name];
    });
    out(['ok' => true] + $r);
}

if (in_array($a, ['accept', 'decline', 'cancel', 'remove', 'block', 'unblock'], true)) {
    $r = act(function ($players) use ($pid, $kh, $a, $body) {
        $all = fr_all(); $me = fr_of($all, $pid);
        $to = other($players, $me, $body['id'] ?? '');
        if (!$to) return ['err' => 'That player is gone.', 'code' => 404];
        $them = fr_of($all, $to);
        $name = fr_name($players, $to);
        if ($a === 'accept') {
            if (!isset($me['in'][$to])) return ['err' => 'That request was withdrawn.'];
            if ($e = need_name($players, $pid)) return $e;
            if (count($me['f']) >= FR_MAX) return ['err' => 'You have ' . FR_MAX . ' friends, the most there can be.'];
            key_add($pid, $kh);
            unset($me['in'][$to], $them['out'][$pid]);
            $me['f'][$to] = $them['f'][$pid] = time();
            track('fr_acc');
            fr_notify($to, 'acc', $pid, [], ['🤝 <b>' . tg_h(fr_name($players, $pid)) . '</b> accepted your friend request.', tg_kb('⚔️ Challenge them', 'duelvs_' . fr_tag($pid))], ['url' => '/play?friends=1']);
        }
        if ($a === 'decline') unset($me['in'][$to], $them['out'][$pid]);
        if ($a === 'cancel') unset($me['out'][$to], $them['in'][$pid]);
        if ($a === 'remove' || $a === 'block') duels_cancel($pid, $to);
        if ($a === 'remove' || $a === 'block') unset($me['f'][$to], $them['f'][$pid], $me['in'][$to], $them['out'][$pid], $me['out'][$to], $them['in'][$pid]);
        if ($a === 'block') $me['bl'][$to] = time();
        if ($a === 'unblock') unset($me['bl'][$to]);
        // a removed or blocked friend's waiting challenges go too
        if ($a === 'remove' || $a === 'block' || $a === 'decline') {
            $n = load(NOTICES);
            $n[$pid] = array_values(array_filter($n[$pid] ?? [], fn($x) => $x['from'] !== $to));
            save(NOTICES, $n);
        }
        $all[$pid] = $me; $all[$to] = $them;
        save(FRIENDS, array_filter($all, fn($x) => $x['f'] || $x['in'] || $x['out'] || $x['bl']));
        return ['done' => $a, 'name' => $name];
    });
    out(['ok' => true] + $r);
}

if ($a === 'seen') {
    $ids = array_slice(array_filter((array)($body['ids'] ?? []), 'is_string'), 0, 40);
    act(function () use ($pid, $ids) {
        $n = load(NOTICES);
        foreach ($n[$pid] ?? [] as $i => $x) if (!$ids || in_array($x['id'], $ids, true)) $n[$pid][$i]['seen'] = true;
        save(NOTICES, $n);
        return [];
    });
    out(['ok' => true]);
}

// ---------------------------------------------------------------- challenges
if ($a === 'live') {
    limit_or_fail('frlive:' . $pid, 12, 3600);
    $code = strtoupper((string)($body['code'] ?? ''));
    if (!preg_match('/^[A-Z2-9]{5}$/', $code)) fail('Open a private room first.');
    $r = act(function ($players) use ($pid, $body, $code) {
        $all = fr_all(); $me = fr_of($all, $pid);
        $to = other($players, $me, $body['to'] ?? '');
        if (!$to || $to === $pid) return ['err' => "We couldn't find that player.", 'code' => 404];
        //MC 2026-10-09 friends can be called in any time; anyone else only while they're online (they can hide that, or block)
        if (!isset($me['f'][$to])) {
            if ($e = need_name($players, $pid)) return $e;
            if (isset($me['bl'][$to]) || isset(fr_of($all, $to)['bl'][$pid])) return ['err' => "You can't invite that player.", 'code' => 403];
            if (!isset(fr_online_list(load(PRESENCE), $players)[$to])) return ['err' => fr_name($players, $to) . " isn't online any more. Add them as a friend to call them in any time.", 'code' => 409];
        }
        $room = load(DATA_DIR . '/rooms/' . $code . '.php');
        //MC 2026-10-15 anyone seated in a room that's still filling can call someone in, not only the host of a private room:
        //   a guest inviting from someone else's lobby used to get a new room of their own (and leave the one they were in)
        $seated = false; foreach (($room['seats'] ?? []) as $st) if (($st['pid'] ?? '') === $pid && !empty($st['human'])) $seated = true;
        if (!$room || !$seated || !empty($room['tourney'])) return ['err' => 'Open a room first.'];
        if ($room['status'] !== 'waiting') return ['err' => 'That match already started.'];
        $cap = function_exists('room_size') ? room_size($room) : ((int)($room['size'] ?? 4) === 2 ? 2 : 4);   //MC 2026-10-18 a 1v1 room holds two
        if (count($room['seats'] ?? []) >= $cap) return ['err' => 'Your room is full.'];
        $l = load(LIMITS);
        if (!rate_ok($l, 'frlive2:' . $pid . ':' . $to, 4, 3600)) { save(LIMITS, $l); return ['err' => fr_name($players, $to) . ' has had a few challenges from you already. Try a Duel.', 'code' => 429]; }
        save(LIMITS, $l);
        $who = fr_name($players, $pid);
        track('fr_live');
        fr_notify($to, 'live', $pid, ['code' => $code],
            ['⚔️ <b>' . tg_h($who) . '</b> is calling you out to a live match in Shilluminati Online. Room <b>' . $code . '</b>, join in the next few minutes.', tg_kb('⚔️ Join the match', 'join_' . $code)],
            ['url' => '/play?room=' . $code . '&go=1']);   //MC 2026-10-10 a challenge joins on arrival
        return ['sent' => true, 'name' => fr_name($players, $to), 'online' => isset(fr_online_list(load(PRESENCE), $players)[$to])];
    });
    out(['ok' => true] + $r);
}

//MC 2026-10-09 "Join after this game": the player was mid-game when the challenge came in and lined it up for when their
//   game ends. The challenger hears about it so they hold the room; 'live-no' tells them if it gets called off.
//   Only for a live challenge this player really got from that person, so it can't be used to message anyone.
if ($a === 'live-later' || $a === 'live-no') {
    limit_or_fail('frlater:' . $pid, 20, 3600);
    $code = strtoupper((string)($body['code'] ?? ''));
    if (!preg_match('/^[A-Z2-9]{5}$/', $code)) fail('That room code looks wrong.');
    $r = act(function ($players) use ($pid, $body, $code, $a) {
        $from = null;
        foreach (fr_notices_live(load(NOTICES)[$pid] ?? []) as $n) if ($n['k'] === 'live' && ($n['d']['code'] ?? '') === $code && fr_tag($n['from']) === strtolower((string)($body['to'] ?? ''))) $from = $n['from'];
        if (!$from) return ['err' => 'That challenge has run out.', 'code' => 404];
        $me = fr_name($players, $pid);
        if ($a === 'live-later') fr_notify($from, 'later', $pid, ['code' => $code], ['⏳ <b>' . tg_h($me) . '</b> is finishing a game and will join your room <b>' . $code . '</b> next. Hold the room.', null]);
        else fr_notify($from, 'liveno', $pid, ['code' => $code]);
        return ['name' => fr_name($players, $from)];
    });
    out(['ok' => true] + $r);
}

if ($a === 'duel') {
    limit_or_fail('frduel:' . $pid, 30, 3600);
    $r = act(function ($players) use ($pid, $body) {
        if ($e = need_name($players, $pid)) return $e;
        $all = fr_all(); $me = fr_of($all, $pid);
        $to = other($players, $me, $body['to'] ?? '');
        if (!$to || !isset($me['f'][$to])) return ['err' => 'You can only Duel friends.', 'code' => 403];
        $d = duels_tidy();
        // one Duel waiting between the two of you at a time
        foreach ($d as $id => $x) {
            if ($x['a'] === $pid && $x['b'] === $to && $x['st'] === 'new') return ['id' => $id, 'name' => fr_name($players, $to), 'resume' => true];
            if ((($x['a'] === $pid && $x['b'] === $to) || ($x['a'] === $to && $x['b'] === $pid)) && $x['st'] === 'open')
                return ['err' => $x['a'] === $pid ? 'Your Duel with ' . fr_name($players, $to) . ' is waiting for them to play.' : fr_name($players, $to) . ' already sent you a Duel. Play that one first.', 'code' => 409, 'duel' => $id, 'mine' => $x['b'] === $pid];
        }
        $open = count(array_filter($d, fn($x) => $x['a'] === $pid && in_array($x['st'], ['new', 'open'], true)));
        if ($open >= DUEL_OPEN_MAX) return ['err' => 'You have ' . DUEL_OPEN_MAX . ' Duels waiting. Let some finish first.', 'code' => 429];
        $id = bin2hex(random_bytes(5));
        $d[$id] = ['a' => $pid, 'b' => $to, 'seed' => duel_seed(), 'deck' => season_deck_at(), 'ts' => time(), 'st' => 'new', 'ra' => null, 'rb' => null];
        save(DUELS, $d);
        track('duels');
        return ['id' => $id, 'name' => fr_name($players, $to)];
    });
    out(['ok' => true] + $r);
}

if ($a === 'duel-decline') {
    $id = (string)($body['id'] ?? '');
    $r = act(function ($players) use ($pid, $id) {
        $d = duels_tidy(); $x = $d[$id] ?? null;
        if (!$x || $x['b'] !== $pid || $x['st'] !== 'open' || $x['rb']) return ['err' => 'That Duel is over.'];
        $d[$id]['st'] = 'declined'; $d[$id]['end'] = time(); save(DUELS, $d);
        fr_notify($x['a'], 'duelno', $pid, ['id' => $id]);
        return ['done' => true];
    });
    out(['ok' => true] + $r);
}

// ---------------------------------------------------------------- browser notifications
if ($a === 'push-key') {
    if (!push_ready()) fail("Notifications aren't available on this server.", 503);
    $k = with_lock(fn() => push_keys());
    if (!$k) fail("Notifications aren't available on this server.", 503);
    out(['ok' => true, 'key' => $k['pub']]);
}
if ($a === 'push-on' || $a === 'push-off') {
    $e = (string)($body['endpoint'] ?? '');
    if (strlen($e) > 800 || (!push_host_ok($e) && empty(shy_config()['push_test']))) fail("That browser didn't give a valid address for notifications.");
    $ua = mb_substr(preg_replace('/[^\w .-]/', '', (string)($body['ua'] ?? '')), 0, 30);
    act(function () use ($pid, $kh, $e, $ua, $a) { key_add($pid, $kh); if ($a === 'push-on') push_save($pid, $e, $ua); else push_forget($pid, $e); return []; });
    out(['ok' => true]);
}
//MC 2026-10-18 the proof in the hand: a test knock to every device this player turned on, so anyone (iPhones above
//   all, where Home Screen setup is easy to get wrong) can see a real notification land within seconds
if ($a === 'push-ping') {
    limit_or_fail('push-ping:' . $pid, 3, 3600);
    act(function () use ($pid, $kh) {
        key_add($pid, $kh);
        if (empty(load(PUSHSUBS)[$pid])) return ['err' => 'Turn notifications on first, then send the test.'];
        fr_notify($pid, 'ping', '', [], null, ['url' => '/play?friends=1']);
        return [];
    });
    out(['ok' => true]);
}

fail('unknown action');
