<?php
// Provably fair: the Daily's deal and every live match's opening deal are sealed before anyone plays, and opened after.
//
// Daily Challenge: each day's seed comes from a server secret (HMAC-SHA256 of the day). A week ahead, the site shows a
// seal for every day: sha256("shy-daily|<day>|<proof>"), where the proof is that day's full HMAC. Once a day is over its
// proof is shown, so anyone can hash it, see it matches the seal published days before, and take the seed from it
// (its first 8 hex digits). The seal can't be faked after the fact and the proof can't be guessed before.
//
// Live matches and the Shogun: the deal (the shuffled Region deck, the shuffled Chaos deck and who goes first) comes
// from a fresh random seed. Every seat sees sha256("shy-live|<seed>|<salt>") the moment the match starts. When it
// ends, the seed and salt are shown, and the browser rebuilds the opening deal from them with the same game engine.
//
//MC 2026-10-15 this file is new on purpose: engine.php on the live server has refused deploys since Oct 14, so the
//   Daily's secret seed never went live there (every Daily still deals from crc32 of the date, which anyone can work
//   out). This takes over the Daily seed from a file the deploys can write, starting tomorrow so today's Daily keeps the
//   deal everyone already played.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('FAIR_SECRET', DATA_DIR . '/fair-secret.php');   // ['k' => hex secret, 'since' => first day it deals, 'made' => ts]
define('FAIR_LIVE', DATA_DIR . '/fair-live.php');       // match id => sealed record (kept 45 days, newest 3,000)
const FAIR_AHEAD = 7;        // days of Daily seals shown ahead
const FAIR_LIVE_KEEP = 45 * 86400;

// the secret, made once. Returns null only if the data folder can't be written.
function fair_secret() {
    static $s = null;
    if ($s !== null) return $s ?: null;
    $ok = fn($x) => is_array($x) && isset($x['k'], $x['since']) && is_string($x['k']) && strlen($x['k']) === 64 && is_string($x['since']);
    $cur = is_file(FAIR_SECRET) ? load(FAIR_SECRET) : [];
    if (!$ok($cur)) {
        $new = ['k' => bin2hex(random_bytes(32)), 'since' => gmdate('Y-m-d', time() + 86400), 'made' => time()];
        $tmp = FAIR_SECRET . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (@file_put_contents($tmp, GUARD . json_encode($new)) !== false) {
            // first writer wins; a corrupt file is replaced (same pattern as the old daily secret)
            if (!@link($tmp, FAIR_SECRET)) { clearstatcache(); if (!$ok(is_file(FAIR_SECRET) ? load(FAIR_SECRET) : [])) @rename($tmp, FAIR_SECRET); }
            @unlink($tmp);
        }
        clearstatcache();
        $cur = is_file(FAIR_SECRET) ? load(FAIR_SECRET) : [];
    }
    $s = $ok($cur) ? $cur : false;
    return $s ?: null;
}
// the day's proof (64 hex) or null for a day before the sealed deals began
function fair_daily_proof($day) {
    $s = fair_secret();
    if (!$s || strcmp($day, $s['since']) < 0) return null;
    return hash_hmac('sha256', 'shy-daily-' . $day, $s['k']);
}
function fair_daily_seal($proof, $day) { return hash('sha256', 'shy-daily|' . $day . '|' . $proof); }
function fair_seed_of($proof) { return (int)hexdec(substr($proof, 0, 8)); }
// the seed a Daily deals from. Sealed days use the proof; days before that keep what they always used.
function fair_daily_seed($day) {
    $p = fair_daily_proof($day);
    if ($p !== null) return fair_seed_of($p);
    return function_exists('daily_seed') ? daily_seed($day) : (int)sprintf('%u', crc32('shy-daily-' . $day));
}
// what the Fair page shows: past days opened, today and the week ahead sealed
function fair_daily_list($back = 14) {
    $s = fair_secret();
    $today = today(); $out = [];
    for ($i = -$back; $i <= FAIR_AHEAD; $i++) {
        $day = gmdate('Y-m-d', strtotime($today . ' 00:00:00 UTC') + $i * 86400);
        $p = fair_daily_proof($day);
        if ($p === null) continue;
        $row = ['day' => $day, 'no' => (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1, 'seal' => fair_daily_seal($p, $day)];
        if (strcmp($day, $today) < 0) { $row['proof'] = $p; $row['seed'] = fair_seed_of($p); }
        $out[] = $row;
    }
    return ['since' => $s ? $s['since'] : null, 'today' => $today, 'days' => $out];
}

// ---------- live matches ----------
// called by start_game: seeds the engine for the deal only, then hands randomness back to random_int
function fair_live_begin() {
    $seed = random_int(1, 0xffffffff); $salt = bin2hex(random_bytes(8));
    rnd_seed($seed);
    return ['seed' => $seed, 'salt' => $salt, 'seal' => hash('sha256', 'shy-live|' . $seed . '|' . $salt), 't' => time()];
}
function fair_live_id($room) { return strtolower($room['code']) . '-' . (int)($room['fair']['t'] ?? 0); }
// the record that outlives the room: kept when the match ends, opened to everyone
function fair_live_keep($room) {
    if (empty($room['fair']['seal'])) return;
    $f = $room['fair'];
    $id = fair_live_id($room);
    with_lock(function () use ($id, $f, $room) {
        $all = load(FAIR_LIVE);
        $cut = time() - FAIR_LIVE_KEEP;
        $all = array_filter($all, fn($r) => ($r['t'] ?? 0) > $cut);
        $all[$id] = ['t' => $f['t'], 'seal' => $f['seal'], 'seed' => $f['seed'], 'salt' => $f['salt'], 'names' => $f['names'], 'styles' => $f['styles'],
            'season' => $f['season'], 'edge' => $f['edge'], 'boss' => !empty($room['boss']), 'end' => time()];
        if (count($all) > 3000) { uasort($all, fn($a, $b) => $b['t'] <=> $a['t']); $all = array_slice($all, 0, 3000, true); }
        save(FAIR_LIVE, $all);
    });
}
// what a seat sees: the seal from the start, the seed and salt once the match is over
function fair_live_view($room) {
    if (empty($room['fair']['seal'])) return null;
    $f = $room['fair'];
    $v = ['seal' => $f['seal'], 'id' => fair_live_id($room)];
    if (($room['status'] ?? '') === 'over' || !empty($room['g']['over'])) $v += ['seed' => $f['seed'], 'salt' => $f['salt'], 'names' => $f['names'], 'styles' => $f['styles'], 'season' => $f['season'], 'edge' => $f['edge']];
    return $v;
}
