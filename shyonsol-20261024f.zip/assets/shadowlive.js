//MC 2026-10-24 Living Shadows, part 3: the Shadow is present for the whole game, not just the cut-in. On a wide screen
//   a holder's Shadow stands at their seat under the log, breathing, its head turning toward the pointer and toward
//   whoever's turn it is, taking a Region loss with a flinch and a gain with a nod, and flaring when a reaction is
//   thrown. Every Shadow has a voice: short lines in its Aura's tone on big moments (a cut-in, a Region taken or lost,
//   the lead changing hands, the win), shown in a bubble by the figure, or at a rival's tile for theirs. While the
//   leader plays as a Shadow, the table carries that Aura's weather. play.js calls in here; everything degrades to
//   nothing on phones (no room for a figure there, the voice still shows), with Reduce Motion, or with Shadow plays off.
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches, wide = matchMedia("(min-width:900px)");
  function SP() { return window.ShyShadowPlay; }
  var VOICE = {
    lightning: { big: ["Feel that.", "Strike first.", "Static in the air."], take: ["Mine now.", "Lights out over there."], lose: ["Tch.", "Grounded. For now."], lead: ["The storm has a name.", "Everyone else is weather."], win: ["Thunder keeps the last word."], hit: ["Sparks. Nothing more."] },
    crimson: { big: ["Burn it down.", "Red means go.", "Watch it catch."], take: ["Ash where that was.", "Warmer already."], lose: ["Embers. I'll relight."], lead: ["The glow spreads.", "Everything's kindling."], win: ["Only ash left standing."], hit: ["Is that heat? Cute."] },
    money: { big: ["Invoice sent.", "Compound that.", "Pay up."], take: ["Acquired.", "Another line on the books."], lose: ["A write-off."], lead: ["Up and to the right.", "Portfolio's looking good."], win: ["Settled in full."], hit: ["Cost of doing business."] },
    btc: { big: ["Few understand.", "Block confirmed.", "Number go up."], take: ["Hodl that? Didn't think so.", "Mined."], lose: ["Dip. Buying."], lead: ["Halving your chances.", "Diamond hands."], win: ["Final block mined."], hit: ["Volatility. Expected."] },
    cyan: { big: ["Calculated.", "Signal locked.", "Clean line."], take: ["Noted. Taken.", "Rerouted to me."], lose: ["Recalculating."], lead: ["Ahead by design.", "The grid is mine."], win: ["Solved."], hit: ["Static. Ignored."] },
    none: { big: ["Watch this.", "My move."], take: ["Mine.", "Taken."], lose: ["Noted."], lead: ["I'll take it from here."], win: ["Shadows win quiet."], hit: ["Hm."] }
  };
  var said = {}, lastSaid = 0;
  function line(au, kind) { var v = VOICE[au] || VOICE.none, pool = v[kind] || VOICE.none[kind] || []; if (!pool.length) return ""; var k = au + kind, i = ((said[k] || 0) + 1) % pool.length; said[k] = i; return pool[i]; }
  // ---- the figure at your seat
  var dock = null, fig = null, tilt = { x: 0, y: 0 }, aim = { x: 0, y: 0 }, raf = 0, mood = 0, moodT = 0, hostRoot = null;
  function mount(root, n, au) {
    unmount();
    if (reduce || !wide.matches || !SP() || !SP().on()) return;
    var side = root.querySelector(".g-side"); if (!side) return;
    hostRoot = root;
    SP().info(n).then(function (cut) {
      if (!cut || !document.contains(side)) return;
      var H = 170, W = Math.round(H * cut.ar);
      var g; try { g = SP().fig(cut, W, H); } catch (e) { g = null; } if (!g) return;
      dock = document.createElement("div"); dock.className = "sl-dock"; dock.style.cssText = "--au:" + (SP().AURA[au] || SP().AURA.none) + ";--w:" + W + "px;--h:" + H + "px";
      dock.innerHTML = '<div class="sl-fig"><i class="sl-aura"></i><div class="sl-lay sl-rim" style="-webkit-mask-image:url(' + cut.src + ');mask-image:url(' + cut.src + ')"></div></div><small>Your Shadow #' + n + '</small>';
      dock.querySelector(".sl-fig").insertBefore(g.el, dock.querySelector(".sl-rim"));
      side.appendChild(dock); fig = g;
      var t0 = performance.now();
      (function tick(now) {
        if (!dock || !document.contains(dock)) { unmount(); return; }
        var b = Math.sin((now - t0) / 1500);
        tilt.x += (aim.x - tilt.x) * .08; tilt.y += (aim.y - tilt.y) * .08;
        var m = mood ? Math.max(0, 1 - (now - moodT) / 700) : 0;
        g.tilt(tilt.x + (mood === 1 ? -.9 * m : 0), tilt.y + b * .05 + (mood === 2 ? .5 * m * Math.sin(m * 12) : 0)); g.draw();
        dock.querySelector(".sl-fig").style.transform = "translateY(" + (b * -2) + "px) rotate(" + (tilt.x * 2 + (mood === 1 ? -3 * m : 0)) + "deg)";
        raf = requestAnimationFrame(tick);
      })(t0);
    });
  }
  function unmount() { if (dock && dock.parentNode) dock.parentNode.removeChild(dock); if (fig) try { fig.stop(); } catch (e) {} dock = null; fig = null; cancelAnimationFrame(raf); }
  // eye contact: the head follows the pointer across the game, and looks at whichever seat has the turn
  document.addEventListener("pointermove", function (e) {
    if (!dock) return; var b = dock.getBoundingClientRect();
    aim.x = Math.max(-1, Math.min(1, (e.clientX - (b.left + b.width / 2)) / 420)); aim.y = Math.max(-.6, Math.min(.6, (e.clientY - (b.top + b.height * .4)) / 500));
  }, { passive: true });
  function lookAt(el) { if (!dock || !el) return; var a = el.getBoundingClientRect(), b = dock.getBoundingClientRect(); if (!a.width) return; aim.x = Math.max(-1, Math.min(1, (a.left + a.width / 2 - (b.left + b.width / 2)) / 420)); aim.y = Math.max(-.6, Math.min(.3, (a.top + a.height / 2 - (b.top + b.height * .4)) / 500)); }
  function react(kind) {
    if (!dock) return;
    var rim = dock.querySelector(".sl-rim");
    if (kind === "hit") { mood = 1; moodT = performance.now(); rim.style.background = "linear-gradient(100deg,transparent 40%,rgba(255,80,90,.7) 75%,#fff)"; rim.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 700, fill: "forwards" }); }
    else if (kind === "gain") { mood = 2; moodT = performance.now(); rim.style.background = "linear-gradient(100deg,transparent 40%,var(--au) 75%,#fff)"; rim.animate([{ opacity: .9 }, { opacity: 0 }], { duration: 600, fill: "forwards" }); }
    else { rim.style.background = "linear-gradient(180deg,transparent 30%,rgba(255,255,255,.75) 38%,transparent 46%)"; rim.animate([{ opacity: 0 }, { opacity: 1, offset: .3 }, { opacity: 0 }], { duration: 450, fill: "forwards" }); }
  }
  // ---- the voice
  function say(au, kind, anchor, root) {
    var now = Date.now(); if (now - lastSaid < 2500) return ""; var t = line(au, kind); if (!t) return ""; lastSaid = now;
    var el = document.createElement("div"); el.className = "sl-say"; el.textContent = t; el.style.setProperty("--au", SP().AURA[au] || SP().AURA.none);
    var host = dock && anchor === dock ? dock : (root || document.body);
    host.appendChild(el);
    //MC 2026-10-24 the bubble was centred on the seat, so a seat near the screen edge pushed half the line off screen
    //   (phones, left tile). Now the bubble is kept fully inside the screen and only its tail points back at the seat.
    if (host !== dock && anchor) {
      var a = anchor.getBoundingClientRect(), b = host.getBoundingClientRect(), w = el.offsetWidth, cx = a.left + a.width / 2;
      var lo = Math.max(b.left, 0) + 8 + w / 2, hi = Math.min(b.right, innerWidth) - 8 - w / 2;
      var c = hi < lo ? (lo + hi) / 2 : Math.max(lo, Math.min(hi, cx));
      el.style.left = (c - b.left) + "px"; el.style.top = (a.bottom - b.top + host.scrollTop + 6) + "px"; el.classList.add("at");
      el.style.setProperty("--tx", Math.max(14 - w / 2, Math.min(w / 2 - 14, cx - c)) + "px");
    }
    el.animate([{ opacity: 0, transform: "translate(-50%,6px) scale(.9)" }, { opacity: 1, transform: "translate(-50%,0) scale(1)" }], { duration: 220, fill: "forwards", easing: "cubic-bezier(.2,.9,.3,1.2)" });
    setTimeout(function () { el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, fill: "forwards" }); setTimeout(function () { el.remove(); }, 320); }, 2600);
    return t;
  }
  // ---- the weather: the leader's Aura over the table
  var weather = "";
  function setWeather(root, au) {
    au = au || "";
    if (au === weather) return;
    if (weather) root.classList.remove("sw-" + weather);
    weather = au; if (au) root.classList.add("sw-" + au);
    var w = root.querySelector(":scope > .g-weather");
    if (au && !w) { w = document.createElement("div"); w.className = "g-weather"; w.setAttribute("aria-hidden", "true"); w.innerHTML = "<i></i><i></i><i></i>"; root.insertBefore(w, root.firstChild); }
    if (!au && w) w.remove();
  }
  window.ShyShadowLive = { mount: mount, unmount: unmount, react: react, lookAt: lookAt, say: say, dockEl: function () { return dock; }, setWeather: setWeather, line: line };
})();
