// Shilluminati Online: solo screen, turns, bots, daily challenge, badges and leaderboard
(function () {
  "use strict";
  var G = window.ShyGame;
  var root = document.getElementById("game");
  //MC 2026-10-09 flag the game while a full overlay (results, start, rules...) is open, so CSS can stop the game behind it
  //   from scrolling and hide it. Done here as well as with :has() so older iPhones get it too.
  if (root && window.MutationObserver) new MutationObserver(function () {
    var open = !!root.querySelector(":scope > .g-overlay:not(.g-quit):not([hidden])");
    if (open !== root.classList.contains("g-ov")) { root.classList.toggle("g-ov", open); if (open) root.scrollTop = 0; }
  }).observe(root, { attributes: true, subtree: true, attributeFilter: ["hidden"], childList: true });
  if (!G || !root) return;

  var API = "api/lb.php";
  var COLORS = ["#ff5d73", "#8b5cf6", "#2ef0b0", "#ff9f43"];
  var LABEL = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", passive: "Reaction", trick: "Trick" };
  var STYLES = { hawk: "The Hawk", builder: "The Builder", wild: "The Wildcard", live: "Live player", away: "Away, bot covering" };
  var DAILY_EPOCH = Date.UTC(2026, 9, 6);
  var SHADOWS = (root.dataset.nfts || "").split("|").filter(Boolean).map(function (x) {
    var i = x.indexOf(":"); return { n: x.slice(0, i), src: x.slice(i + 1) };
  });
  var $ = function (id) { return document.getElementById(id); };
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  var g = null, sel = -1, busy = true, shown = 0, prevCounts = null, token = null, submitted = false;
  var selAt = 0;   //MC 2026-10-13 when the selected card was picked, for the charge-up on attack cards
  var avatars = [], tip = null, tipKey = "", ff = false, newCard = -1, drawAnim = false, lastMode = "quick", pendingResult = null;
  var track = null; // per-game numbers for badges and the share grid

  // ---------- storage ----------
  function store(k, v) {
    try {
      if (v === undefined) return localStorage.getItem(k);
      localStorage.setItem(k, v);
    } catch (e) { return null; }
  }
  function hex(n) {
    var a = new Uint8Array(n);
    try { crypto.getRandomValues(a); } catch (e) { for (var i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256); }
    return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  var me = {
    pid: store("shy-lb-pid") || (function () { var v = hex(8); store("shy-lb-pid", v); return v; })(),
    key: store("shy-lb-key") || (function () { var v = hex(16); store("shy-lb-key", v); return v; })(),
    name: store("shy-lb-name") || "",
    avatar: store("shy-avatar") || "",
    mode: store("shy-mode") || "easy",
    speed: store("shy-speed") || "chill",
    hints: store("shy-hints") !== "off",
    sound: store("shy-sound") !== "off"
  };
  var stats = (function () {
    var s = null;
    try { s = JSON.parse(store("shy-stats") || "null"); } catch (e) {}
    if (!s) s = { games: parseInt(store("shy-lite-plays") || "0", 10), wins: parseInt(store("shy-lite-wins") || "0", 10), streak: 0, bestStreak: 0, best: 0, dailies: 0, cards: {}, badges: {}, daily: {} };
    s.cards = s.cards || {}; s.badges = s.badges || {}; s.daily = s.daily || {};
    return s;
  })();
  function saveStats() { store("shy-stats", JSON.stringify(stats)); }

  // ---------- helpers ----------
  function wait(ms) {
    var k = ff ? 0.12 : (me.speed === "fast" ? 0.5 : 1);
    return new Promise(function (r) { setTimeout(r, ms * k); });
  }
  // cosmetics from the shop (shop.js fills window.ShyEco)
  function eco() { return window.ShyEco || { eq: {}, pub: {}, reacts: [0, 1, 2, 3, 4, 5] }; }
  // card finishes and mastery: yours from the shop, a rival's from what the table shows of them
  function finOf(pi, id) {
    if (pi === 0) return (eco().veq || {})[id] || "";
    var p = g && g.players[pi];
    return p && p.cos && p.cos.vf ? p.cos.vf[id] || "" : "";
  }
  function mlOf(pi, id) {
    if (pi === 0) { var e = window.ShyEco; return e && e.mastery ? e.mastery(id) : 0; }
    var p = g && g.players[pi];
    return p && p.cos && p.cos.ml ? +p.cos.ml[id] || 0 : 0;
  }
  function backOf(pi) {
    if (pi === 0) { var b = eco().eq.back; return b ? b.replace("back_", "") : "ink"; }
    var p = g && g.players[pi];
    return p && p.cos && p.cos.back ? p.cos.back : "ink";
  }
  function frameCls(pi) {
    var f = "";
    if (pi === 0) { var e = eco().eq.frame; f = e ? e.replace("frame_", "") : ""; }
    else if (g && g.players[pi] && g.players[pi].cos) f = g.players[pi].cos.frame || "";
    return f ? " fr-" + f : "";
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function buzz(ms) {
    try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(ms); } catch (e) {}
  }
  // engine messages are third person; fix them when the subject is "You"
  //MC 2026-10-11 rewritten. The old one only fixed "You" at the very start of a line, with a lazy (\w+?)s that turned
  //   "You goes first" into "You goe first" (every live match where your seat starts) and "studies" into "studie". Its
  //   "and Xs" rule also ate the s off the next word ("and Glass Fox gains 1" became "and Glas Fox"). Now each sentence
  //   is fixed on its own: a sentence that starts with You gets its verbs and their/they turned to second person; a You
  //   further in ("and You draws 2", "until You plays again", "with You") becomes "you" with the verb after and/until fixed.
  //   "X loses 0 Regions." (an attack on a player with none) reads "X has no Regions to lose." The engine's own text is
  //   untouched, so the server's copy (engine.php) and replays don't change.
  var YOU_IRR = { is: "are", has: "have", goes: "go", does: "do", was: "were" };
  function deconj(v) {
    if (YOU_IRR[v]) return YOU_IRR[v];
    if (/[^aeiou]ies$/.test(v)) return v.slice(0, -3) + "y";
    if (/(ss|sh|ch|x|z)es$/.test(v)) return v.slice(0, -2);
    if (/[^su]s$/.test(v) && v.length > 2) return v.slice(0, -1);
    return v;
  }
  function youSentence(s) {
    if (/^You /.test(s)) {
      s = s.replace(/^You (\w+)/, function (m, v) { return "You " + deconj(v); })
        .replace(/ and (gains|draws|loses|rests|takes|keeps|steals|skips)\b/g, function (m, v) { return " and " + deconj(v); })
        .replace(/\btheir\b/g, "your").replace(/\bthey\b/g, "you");
    }
    return s.replace(/\b(and|until|but|then) You (\w+)/g, function (m, w, v) { return w + " you " + deconj(v); })
      .replace(/(\S\s)Your\b/g, "$1your").replace(/(\S\s)You\b/g, "$1you");
  }
  //MC 2026-10-11 the translations were made from what the old helper showed, slips included ("You studie the deck..."
  //   has a German line, "You study the deck..." doesn't yet). Until the corrected lines are translated, a line whose new
  //   English has no translation but whose old English does is shown the old way, so other languages don't fall back to
  //   English. English always gets the corrected line.
  function youOld(t) {
    if (t.indexOf("You") < 0) return t;
    t = t.replace(/\bYou's\b/g, "Your").replace(/ (on|from) You\b/g, " $1 you").replace(/You will skip their/g, "You will skip your")
      .replace(/until Your next/g, "until your next").replace(/\. You loses\b/g, ". You lose");
    if (/^You /.test(t)) {
      t = t.replace(/^You is\b/, "You are").replace(/^You has\b/, "You have")
        .replace(/^You (\w+?)s\b/, function (m, v) { return v === "i" || v === "ha" || /s$/.test(v) ? m : "You " + v; })
        .replace(/^(You .*?) and (\w+?)s\b/, "$1 and $2");
    }
    return t;
  }
  function youShown(t) {
    var s = you(t), I = window.SHYI18N;
    if (!I || I.lang === "en" || !I.T || I.T(s) !== s) return s;
    var o = youOld(t);
    return o !== s && I.T(o) !== o ? o : s;
  }
  function you(t) {
    t = t.replace(/(^|\.\s)([^.]+?) loses 0 Regions\./g, "$1$2 has no Regions to lose.");
    if (t.indexOf("You") < 0) return t;
    var parts = t.replace(/\bYou's\b/g, "Your").split(/(\.\s+)/);
    for (var i = 0; i < parts.length; i += 2) parts[i] = youSentence(parts[i]);
    return parts.join("");
  }
  // ---------- who looks like what ----------
  // every image carries the site version, so a new release never shows a stale cached picture
  var AV = (function () { var sc = document.currentScript || document.querySelector('script[src*="play.js"]'); var m = sc && /[?&]v=([\w.-]+)/.exec(sc.src); return m ? "?v=" + m[1] : ""; })();
  var UNBOUND = "assets/art/masks/unbound.svg" + AV;
  var BOTS = [["Neon Ronin", "ronin"], ["Iron Monk", "monk"], ["Paper Tiger", "tiger"], ["Night Crane", "crane"], ["Jade Fox", "kitsune"], ["Silent Oni", "oni"]];
  var NFTIMG = {};   // Shadow number -> image, learned from the server
  var holder = (function () { try { return JSON.parse(store("shy-holder") || "null"); } catch (e) { return null; } })() || { linked: false, holder: false, shadows: [] };
  (holder.shadows || []).forEach(function (x) { if (x.img) NFTIMG[x.n] = x.img; });
  //MC 2026-10-09 Try a Shadow: a player without one can pick any Shadow in the lobby (or follow ?try=1 from the NFTs
  //page) and play their next solo game as it. Looks only: the score is saved as Unbound, nothing is sent as theirs,
  //and it never applies to live matches, so nobody at a table sees a Shadow the player doesn't own.
  var trial = (function () { try { var t = JSON.parse(sessionStorage.getItem("shy-try") || "null"); return t && t.n && t.src ? t : null; } catch (e) { return null; } })();
  function setTrial(n) {
    var x = n ? SHADOWS.filter(function (s) { return s.n === String(n); })[0] : null;
    trial = x ? { n: x.n, src: x.src } : null;
    try { if (trial) sessionStorage.setItem("shy-try", JSON.stringify(trial)); else sessionStorage.removeItem("shy-try"); } catch (e) {}
    renderPicker();
  }
  function tryRandom() {
    if (!SHADOWS.length) return null;
    var pool = SHADOWS.filter(function (s) { return !trial || s.n !== trial.n; });
    setTrial(pool[Math.floor(Math.random() * pool.length)].n);
    return trial;
  }
  // Holders celebrate wins with their Shadow's Aura trait
  var AURAS = {
    "lightning aura": { name: "Lightning strike", fx: "lightning" },
    "electric cyan": { name: "Cyan surge", fx: "cyan" },
    "money aura": { name: "Gold rain", fx: "money" },
    "btc aura": { name: "Bitcoin rain", fx: "btc" },
    "crimson glow": { name: "Crimson blossoms", fx: "crimson" },
    "no aura": { name: "Confetti", fx: "confetti" }
  };
  function ownedNums() { return (holder.shadows || []).map(function (x) { return String(x.n); }); }
  // the Shadow you play as: one you hold, or none (Unbound)
  function myAvatar() { var own = ownedNums(); if (!own.length) return ""; return own.indexOf(String(me.avatar)) >= 0 ? String(me.avatar) : own[0]; }
  function shadowSrc(n) {
    if (!n) return "";
    if (NFTIMG[n]) return NFTIMG[n];
    for (var i = 0; i < SHADOWS.length; i++) if (SHADOWS[i].n === String(n)) return SHADOWS[i].src;
    return "";
  }
  function maskSrc(name) {
    var clean = String(name || "").replace(/ \((bot|left)\)$/, "");
    var ps = G.persona && G.persona(clean); if (ps) return "assets/art/masks/" + ps[1] + ".svg" + AV;
    for (var i = 0; i < BOTS.length; i++) if (BOTS[i][0] === clean) return "assets/art/masks/" + BOTS[i][1] + ".svg" + AV;
    var h = 0; for (var k = 0; k < clean.length; k++) h = (h * 31 + clean.charCodeAt(k)) >>> 0;
    return "assets/art/masks/" + BOTS[h % BOTS.length][1] + ".svg" + AV;
  }
  // a real Shadow first; a player without one shows their Shadow skin if they wear one, otherwise the Unbound hood
  function skinSrc(k) { return /^[a-z]+$/.test(k || "") ? "assets/art/skins/skin_" + k + ".svg" + AV : ""; }
  function mySkin() { var id = eco().eq.skin || ""; return /^skin_[a-z]+$/.test(id) ? skinSrc(id.slice(5)) : ""; }
  // a holder's verified Shadow glows in its Aura trait colour, and wears a Halo if they bought one
  var AURA_KEY = { "electric cyan": "cyan", "crimson glow": "crimson", "lightning aura": "lightning", "money aura": "money", "btc aura": "btc" };
  function auraKey(raw) { return AURA_KEY[String(raw || "").toLowerCase()] || "none"; }
  // a $SHY holder's tier, as a small badge next to the name
  //MC 2026-10-10 the $SHY Army Ranks: at the table a rank is its emblem alone (the name is on hover), names are long
  var TIERS = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King/Queen", supreme: "Shytoshi Supreme" };
  var RANKS = { bronze: "Bronze", silver: "Silver", gold: "Gold", jade: "Jade", shogun: "Shogun" };
  function tierB(cos) {
    var t = cos && cos.tier, r = cos && cos.rank;
    //MC 2026-10-15 the Seeker badge: owns a Solana Seeker phone
    return (cos && cos.sk ? '<em class="sk-b" title="Owns a Solana Seeker phone">Seeker</em>' : "") + (RANKS[r] ? '<em class="rank-b r-' + r + '" title="Ranked ' + RANKS[r] + ' this season">' + RANKS[r] + '</em>' : "") + (TIERS[t] ? '<em class="tier-b rk ico t-' + t + '" title="' + TIERS[t] + '" data-i18n-skip><img src="/assets/ranks/' + t + '-64.webp" alt="' + TIERS[t] + '" width="18" height="18"></em>' : "");
  }
  // ranked: what this match did to the player's Rank Points, under the end-screen title
  function rankLine(rk) {
    var el = $("g-rank");
    if (!rk) { if (el) el.hidden = true; return; }
    if (!el) { el = document.createElement("div"); el.id = "g-rank"; el.className = "g-rank"; var sub = $("g-end-sub"); sub.parentNode.insertBefore(el, sub.nextSibling); }
    el.hidden = false;
    var nx = rk.next ? '<small>' + (rk.next.at - rk.rp) + ' RP to ' + RANKS[rk.next.tier] + '</small>' : '<small>Top tier this season</small>';
    el.className = "g-rank r-" + rk.tier + (rk.up ? " up" : rk.down ? " down" : "");
    //MC 2026-10-11 a loss at 0 RP showed "0 RP +0", which read like the match didn't count; it says why nothing came off
    var floor = rk.d === 0 && rk.rp === 0;
    el.innerHTML = '<span class="g-rank-b">' + (rk.up ? "Promoted: " : rk.down ? "Down to " : "Ranked ") + RANKS[rk.tier] + '</span><b>' + rk.rp + ' RP <em class="' + (floor ? "neg" : rk.d >= 0 ? "pos" : "neg") + '">' + (floor ? "Already at 0" : (rk.d >= 0 ? "+" : "") + rk.d) + '</em></b>' + nx;
    if (rk.up) { try { fxRun("money"); } catch (e) {} }
  }
  function lookCls(aura, halo) { return aura ? " av-aura au-" + aura + (/^[a-z]+$/.test(halo || "") ? " hl-" + halo : "") : ""; }
  function myLook() { var x = myShadow(); if (!x) return ""; var h = (eco().eq.halo || "").slice(5); return lookCls(auraKey(x.aura), h); }
  function avatarSrc(avatar, name, human, cos) { return shadowSrc(avatar) || (human ? skinSrc(cos && cos.skin) || UNBOUND : maskSrc(name)); }
  //MC 2026-10-09 seat reactions: what happened to whom, and when, so a redraw keeps the animation going
  var RX = {}, RXMS = { gain: 900, hit: 700, cast: 700, block: 800 };
  function react(i, kind) {
    if (reduce || ff || i == null || i < 0 || !RXMS[kind]) return;
    if (i === 0 && window.ShyShadowLive) ShyShadowLive.react(kind);   //MC 2026-10-24 the Shadow at your seat reacts too
    RX[i] = [kind, Date.now()];
    var el = i === 0 ? root.querySelector("#g-me-av .g-av") : root.querySelector("#g-riv-" + i + " .g-av");
    if (!el) return;
    //MC 2026-10-11 restarted the animation with void el.offsetWidth, a forced layout on every reaction (about 1s of a
    //   70s phone profile). A seat with no reaction running just gets the class; one already reacting is swapped for a
    //   fresh copy, which starts its animation from the top without the browser laying out the page first.
    var busyRx = /\brx-/.test(el.className);
    if (busyRx) { var c = el.cloneNode(true); el.parentNode.replaceChild(c, el); el = c; el.classList.remove("rx-gain", "rx-hit", "rx-cast", "rx-block"); }
    el.style.setProperty("--rxd", "0ms");
    el.classList.add("rx-" + kind);
  }
  //MC 2026-10-11 bot personality (audit/game.md improvement 7). After a big play a bot sometimes says a short line in its
  //   own style (The Hawk, The Builder, The Wildcard), and a bot that just got hit sometimes pulls a face (an emoji that
  //   pops on its avatar, like the live reactions). Rate-limited so it stays a treat: at most one line every other round, 5 a game, never two voices
  //   within 2.5s, and a coin flip on top. Games run on this device only (solo, Daily, Duel): in a live match the bots
  //   are the server's and every screen would invent different lines, so they stay quiet there, and in replays. Nothing
  //   here touches g.rnd (the Daily and Duel deals must replay the same), so it uses Math.random. Skipping ahead mutes
  //   it. With reduced motion the line still shows, it just doesn't move (style.css stops every animation).
  var VOICE = {
    hawk: { hit: ["Nothing personal. Just conquest.", "The blade was drawn long ago.", "Your borders were a suggestion."],
      gain: ["Another flag for the war room.", "The map bends. As it should.", "More land, more targets."],
      ouch: ["\u{1F624}", "\u{1F4A2}"] },
    builder: { hit: ["Consider it urban renewal.", "I build. You made me break.", "Patience ran out. So did your land."],
      gain: ["Brick by brick, the world is mine.", "The empire grows in silence.", "Slow hands, full map."],
      ouch: ["\u{1F631}", "\u{1F62C}"] },
    wild: { hit: ["Chaos chose you. Not me.", "Oops. Was that your continent?", "The dice said yes."],
      gain: ["I have no plan. It's working.", "Even the Council didn't see that.", "The prophecy was a coin flip."],
      ouch: ["\u{1F92F}", "\u{1F643}"] }
  };
  var voice = { g: null };
  function voiceReady(gap) {
    if (!g || isLive() || g.replay || ff || g.over) return false;
    if (voice.g !== g) voice = { g: g, at: 0, round: -9, n: 0, ouch: {} };
    return Date.now() - voice.at >= gap;
  }
  function pickLine(list) { return list[Math.floor(Math.random() * list.length)]; }
  // a bot's play just landed: before = everyone's Region counts before it
  function botVoice(bi, before) {
    var p = g && g.players[bi], v = p && VOICE[p.style];
    if (!v || !voiceReady(2500) || voice.n >= 5 || g.round - voice.round < 2) return;
    var d = g.players.map(function (x, i) { return x.regions.length - before[i]; });
    var hurt = d.some(function (x, i) { return i !== bi && (x <= -2 || (i === 0 && x < 0)); });
    var kind = hurt ? "hit" : d[bi] >= 2 ? "gain" : "";
    if (!kind || Math.random() < 0.4) return;
    voice.at = Date.now(); voice.round = g.round; voice.n++;
    talk(bi, pickLine(v[kind]));
  }
  // a bot lost Regions to someone else's card
  function botOuch(i) {
    var p = g && g.players[i], v = p && p.bot && VOICE[p.style];
    if (!v || g.turn === i || !voiceReady(2500) || voice.ouch[i] === g.round || Math.random() < 0.5) return;
    voice.at = Date.now(); voice.ouch[i] = g.round;
    var e = pickLine(v.ouch);
    //   The face pops on the bot's avatar and stays inside its tile. Tried the live reaction bubble first: it floats up
    //   out of the tile, and on phones (tiles at the top) it went over the turn pill and the sound / exit buttons.
    if (!reduce) requestAnimationFrame(function () {
      var av = g && g.players[i] === p && root.querySelector("#g-riv-" + i + " .g-av");
      if (!av || !av.getClientRects().length) return;
      var a = av.getBoundingClientRect(), b = root.getBoundingClientRect(), el = document.createElement("span");
      el.className = "g-ouch"; el.setAttribute("aria-hidden", "true"); el.textContent = e;
      el.style.left = (a.left - b.left + a.width / 2) + "px"; el.style.top = (a.top - b.top + root.scrollTop + a.height / 2) + "px";
      root.appendChild(el);
      setTimeout(function () { el.remove(); }, 1700);
    });
  }
  // the line itself: a bubble under the bot's seat tile (above it if that would reach the hand). Placed in the next frame,
  //   after render()'s writes, so reading the tile's position doesn't force an extra layout.
  function talk(i, text, ms) {
    var el = document.createElement("div");   // a block of its own, so the translator looks the line up whole
    el.className = "g-taunt"; el.setAttribute("aria-hidden", "true"); el.textContent = text;
    el.style.setProperty("--tc", COLORS[i]);
    requestAnimationFrame(function () {
      var a = $("g-riv-" + i), hw = root.querySelector(".g-hand-wrap");
      if (!a || !a.getClientRects().length) return;
      var r = a.getBoundingClientRect(), b = root.getBoundingClientRect(), maxW = Math.min(240, b.width * 0.7);
      var top = r.bottom + 6, handTop = hw && hw.getClientRects().length ? hw.getBoundingClientRect().top : Infinity;
      if (top + 64 > handTop) { top = r.top - 58; el.classList.add("up"); }
      var cx = r.left - b.left + r.width / 2, x = Math.max(maxW / 2 + 6, Math.min(b.width - maxW / 2 - 6, cx));
      el.style.maxWidth = maxW + "px";
      el.style.left = x + "px";
      el.style.setProperty("--tx", Math.max(-60, Math.min(60, cx - x)) + "px");   // the tail still points at the speaker's tile
      el.style.top = (top - b.top + root.scrollTop) + "px";
      root.appendChild(el);
      setTimeout(function () { el.remove(); }, ms || 2900);
    });
  }
  // the seat you play from: your own Shadow, a Shadow you're trying (solo only), your skin, or Unbound
  function meSeat(solo) {
    var n = myAvatar();
    if (n) { var x = myShadow(); return { src: shadowSrc(n) || UNBOUND, look: myLook(), n: n, au: auraKey(x && x.aura) }; }
    if (solo && trial) return { src: trial.src, look: lookCls("none"), n: trial.n, au: "none", trial: true };
    return { src: mySkin() || UNBOUND, look: "" };
  }
  // a Living Shadow (living.js) for a seat that has one
  function living(i, cls, size) {
    var a = avatars[i];
    if (!a || !a.n || !a.src || !window.ShyLiving) return "";
    return ShyLiving.html(a.src, { aura: a.au || "none", cls: cls, size: size, alt: "Shadow #" + a.n, fb: UNBOUND });
  }
  // the match intro: every Shadow at the table walks in. Returns false when there's no Shadow to show.
  function intro(done) {
    var seats = [];
    avatars.forEach(function (a, i) { if (a && a.n && a.src) seats.push(i); });
    if (!seats.length || ff || reduce || !window.ShyLiving) return false;
    var old = root.querySelector(".g-intro"); if (old) old.remove();
    var size = seats.length === 1 ? "clamp(150px,42vw,220px)" : seats.length === 2 ? "clamp(110px,30vw,170px)" : "clamp(84px,22vw,140px)";
    var el = document.createElement("div");
    el.className = "g-intro";
    el.innerHTML = '<span class="gi-k">' + (seats.length === 1 ? (seats[0] === 0 ? "Your Shadow enters" : "A Shadow enters") : "Shadows at the table") + '</span><div class="gi-row">' +
      seats.map(function (i) { var a = avatars[i]; return '<div class="gi-seat au-' + esc(a.au || "none") + '">' + living(i, "enter", size) + '<div><b data-i18n-skip>' + esc(i === 0 && !(live && live.watch) ? (me.name || "You") : a.label) + '</b><small>Shadow #' + esc(a.n) + (a.trial ? " · Trying it" : "") + '</small></div></div>'; }).join("") +
      '</div><span class="gi-skip">Tap to start</span>';
    root.appendChild(el);
    var gone = false;
    function hide() { if (gone) return; gone = true; clearTimeout(t); el.classList.add("out"); setTimeout(function () { el.remove(); }, 340); if (done) done(); }
    var t = setTimeout(hide, 2100);
    el.addEventListener("click", hide);
    return true;
  }
  // the colour shift that makes rivals sharing mask art look different (game.js PERSONAS)
  function hashStr(t) { var h = 2166136261; for (var i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function maskHue(name) { var ps = G.persona && G.persona(name); return ps && ps[2] ? ps[2] : 0; }
  function avHTML(i, cls) {
    var a = avatars[i];
    var fallback = '<span class="g-av-txt">' + (a && a.label ? a.label.charAt(0) : "?") + '</span>';
    var rx = RX[i], rxc = "", rxs = "";
    if (rx && Date.now() - rx[1] < RXMS[rx[0]]) { rxc = " rx-" + rx[0]; rxs = ";--rxd:-" + (Date.now() - rx[1]) + "ms"; }
    return '<span class="g-av ' + (cls || "") + (a && a.look ? a.look : "") + rxc + '" style="background:' + COLORS[i] + rxs + '">' +
      (a && a.src ? '<img src="' + a.src + '" alt="" onerror="this.remove()"' + (a.hue ? ' style="filter:hue-rotate(' + (+a.hue) + 'deg)"' : "") + '>' : "") + fallback + (a && a.look ? '<i class="g-av-sh" aria-hidden="true"></i>' : "") + (a && a.look && !a.trial ? '<i class="av-ok" aria-hidden="true">✓</i>' : "") + '</span>';
  }
  function cardArt(id) { return "assets/cards/" + id + ".webp" + AV; }   //MC 2026-10-09 pre-drawn WebP: the SVG paper filters were the biggest cost of a hand redraw on phones
  function dayKey(d) { d = d || new Date(); return d.toISOString().slice(0, 10); }
  function dailyNo() { return Math.floor((Date.parse(dayKey() + "T00:00:00Z") - DAILY_EPOCH) / 864e5) + 1; }
  // small seeded random generator so everyone gets the same Daily
  function seeded(str) {
    var h = 1779033703 ^ str.length;
    for (var i = 0; i < str.length; i++) { h = Math.imul(h ^ str.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; }
    var a = h >>> 0;
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      var t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function isDaily() { return g && g.daily; }
  function isLive() { return !!(g && g.online); }
  function hintsOn() { return me.hints && !isDaily() && !isLive() && !isDuel(); }
  function isDuel() { return !!(g && g.duel); }

  // ---------- sound ----------
  var A = window.ShyAudio || { play: function () {}, setSfx: function () {}, setMusic: function () {}, prefs: { sfx: false, music: false } };
  var SFX_MAP = { select: "tap" };
  //MC 2026-10-11 after a reload into a live match, sounds fired before any tap and Chrome logged "The AudioContext was not
  //   allowed to start" each time. They couldn't play anyway, so nothing is sent until the page has had a tap or a key.
  function sfx(n) { if (navigator.userActivation && !navigator.userActivation.hasBeenActive) return; A.play(SFX_MAP[n] || n); }

  // ---------- badges ----------
  var BADGES = [
    { id: "initiated", icon: "\u{1F311}", name: "Initiated", desc: "Finish your first game." },
    { id: "leader", icon: "\u{1F451}", name: "World Leader", desc: "Win a game." },
    { id: "normal", icon: "\u{1F525}", name: "No Training Wheels", desc: "Win on Normal with hints off." },
    { id: "daily", icon: "\u{1F4C5}", name: "Daily Ritual", desc: "Play a Daily Challenge." },
    { id: "chosen", icon: "✨", name: "Chosen One", desc: "Win a Daily Challenge." },
    { id: "empire", icon: "\u{1F30D}", name: "Empire", desc: "End a game with 10 or more Regions." },
    { id: "shadowempire", icon: "\u{1F30C}", name: "Shadow Empire", desc: "End a game with 13 or more Regions." },
    { id: "untouchable", icon: "\u{1F6E1}️", name: "Untouchable", desc: "Block 2 attacks in one game." },
    { id: "comeback", icon: "\u{1F504}", name: "Comeback Kid", desc: "Win after being in last place from round 5 on." },
    { id: "flawless", icon: "\u{1F48E}", name: "Flawless", desc: "Win without losing a single Region." },
    { id: "landslide", icon: "⚡", name: "Landslide", desc: "Win by 5 or more Regions." },
    { id: "onfire", icon: "\u{1F680}", name: "On Fire", desc: "Win 3 games in a row." },
    { id: "collector", icon: "\u{1F0CF}", name: "Card Collector", desc: "Play 12 different cards over time." },
    { id: "regular", icon: "\u{1F3C6}", name: "Regular", desc: "Play 25 games." },
    { id: "duelist", icon: "\u2694\uFE0F", name: "Duelist", desc: "Win a live match against another real player." },
    { id: "crew", icon: "\u{1F91D}", name: "Crew", desc: "Finish a private match with friends." }
  ];
  function badgeCount() { return Object.keys(stats.badges).length; }
  function renderProfile() {
    var rate = stats.games ? Math.round(stats.wins / stats.games * 100) : 0;
    var st = $("g-stats");
    if (st) st.innerHTML = [["Games", stats.games], ["Wins", stats.wins], ["Win rate", rate + "%"], ["Streak", stats.streak], ["Best", stats.best]]
      .map(function (x) { return '<div><b>' + x[1] + '</b><small>' + x[0] + '</small></div>'; }).join("");
    var bg = $("g-badges");
    if (bg) bg.innerHTML = BADGES.map(function (b) {
      var got = !!stats.badges[b.id];
      return '<button class="g-badge' + (got ? " got" : "") + '" data-b="' + b.id + '" title="' + esc(b.name + ": " + b.desc) + '"><span>' + b.icon + '</span></button>';
    }).join("");
    var bc = $("g-badge-count"); if (bc) bc.textContent = badgeCount() + "/" + BADGES.length + " badges";
  }
  function toast(html) {
    var t = $("g-toast");
    // with the shop or Friends open on top, the game's own toast spot is hidden behind them: float it over everything
    var over = document.documentElement.classList.contains("shop-open") || !!document.querySelector(".fr.in");
    if (!toast.home) toast.home = t.parentNode;
    if (over && t.parentNode !== document.body) document.body.appendChild(t);
    else if (!over && t.parentNode !== toast.home) toast.home.appendChild(t);
    t.classList.toggle("float", over);
    t.innerHTML = html; t.hidden = false; t.classList.remove("out");
    clearTimeout(toast.tm);
    toast.tm = setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.hidden = true; }, 300); }, 2600);
  }

  // ---------- render ----------
  //MC 2026-10-09 render() runs many times a turn and rebuilt the hand, the rivals and the counters each time, so the
  //   browser re-laid them out and re-decoded their pictures even when nothing had changed (most of a phone's frame
  //   budget during a game). A part is only rewritten when its markup actually differs from what's on screen.
  function put(el, html) { if (el && el.__html !== html) { el.innerHTML = html; el.__html = html; } }
  var narrowTurn = matchMedia("(max-width:760px)");
  //MC 2026-10-11 the same for the plain labels render() sets every time (turn pill, counts, Claim / Play): writing the
  //   same text again still swaps the text node and sends the browser back to layout. The i18n translator can change
  //   what's shown, so the last value we wrote is what's compared, not what's on screen.
  function txt(el, s) { if (el && el.__txt !== s) { el.textContent = s; el.__txt = s; } }
  function render() {
    document.documentElement.classList.toggle("g-playing", !!(g && !g.over));   // lets the page rest its decorations while a game is on
    if (!g) return;
    if (map3dLazy) mapMode(map3dOn, true);   //MC 2026-10-18 first match on screen: now the 3D table is worth loading
    var human = g.players[0], current = g.players[g.turn];
    var myTurn = g.turn === 0 && !busy && !g.over;
    var left = g.regionDeck.length, nP = g.players.length;
    //MC 2026-10-12 the round limit is shown once it's close. A player filmed losing to the Shogun at "Tur 30" with no
    //   warning the clock even existed: the Shogun had learned to sit on a lead until time ran out (see api/bosslib.php).
    var roundsLeft = (G.MAX_ROUNDS || 30) - g.round;
    var cap = roundsLeft <= 5 && !g.over ? ' <small class="lv-hot">' + (roundsLeft <= 0 ? "last round" : roundsLeft + (roundsLeft === 1 ? " round to the time limit" : " rounds to the time limit")) + '</small>' : "";
    //MC 2026-10-23 phones: Regions left and the round out of the limit, both in full (the turn pill steps aside there, see style.css)
    put($("g-round"), '<span class="g-rnd">Round ' + g.round + '<i> of ' + (G.MAX_ROUNDS || 30) + '</i></span><small class="' + (left <= nP ? "lv-hot" : left <= nP * 2 ? "lv-warm" : "") + '">' + (left ? left + (left === 1 ? " Region left" : " Regions left") : "No Regions left") + '</small>' + cap);
    endgameAlert();
    //MC 2026-10-11 phones: "Your turn · play again" wrapped to two lines and widened the pill; "Play again" alone there
    txt($("g-turn"), g.over ? "Game over" : (g.turn === 0 ? (g.played && g.plays > 0 ? (narrowTurn.matches ? "Play again" : "Your turn · play again") : "Your turn") + (isLive() ? timerText() : "") : current.name.replace("Shadow ", "").replace(" (bot)", "") + (isLive() && current.style === "live" ? "'s move" + timerText() : " is thinking")));
    var tcl = "g-turn" + (g.turn === 0 && !g.over ? " mine" : "");
    if ($("g-turn").className !== tcl) $("g-turn").className = tcl;
    root.classList.toggle("my-turn", myTurn);
    var tb = (eco().eq.table || "").replace("table_", "");
    if (root.dataset.table !== tb) { if (root.dataset.table) root.classList.remove("tb-" + root.dataset.table); if (tb) root.classList.add("tb-" + tb); root.dataset.table = tb; }
    //MC 2026-10-10 Animated tables get their moving layer, and your turn aura wraps your hand while it's your turn
    if (window.ShyFx2) ShyFx2.table(root, tb);
    mapLook();   //MC 2026-10-14 the 3D table wears what the Dojo sold: felt, land, air, and every seat's pieces
    var tu = live && live.watch ? "" : (eco().eq.turn || "").replace("turn_", ""), hw = root.querySelector(".g-hand-wrap");
    if (hw && hw.dataset.tu !== tu) { hw.dataset.tu = tu; var old = hw.querySelector(":scope > .tu-fx"); if (old) old.remove(); hw.classList.toggle("has-tu", !!tu); if (tu && window.ShyFx2) hw.insertAdjacentHTML("afterbegin", ShyFx2.turnHTML(tu)); }

    // world control bar
    var total = G.REGIONS.length, held = g.players.map(function (p) { return p.regions.length; });
    put($("g-world-bar"), held.map(function (n, i) {
      return n ? '<i style="flex:' + n + ';background:' + COLORS[i] + '" title="' + esc(i === 0 ? "You" : g.players[i].name) + ': ' + n + '"></i>' : "";
    }).join("") + (g.regionDeck.length ? '<i class="left" style="flex:' + g.regionDeck.length + '" title="Unclaimed: ' + g.regionDeck.length + '"></i>' : "") +
      (g.regionDiscard.length ? '<i class="gone" style="flex:' + g.regionDiscard.length + '" title="Destroyed: ' + g.regionDiscard.length + '"></i>' : ""));
    put($("g-deck"), '<i class="sw sw-open"></i>' + g.regionDeck.length + ' unclaimed <i class="sw sw-gone"></i>' + g.regionDiscard.length + ' destroyed');

    //MC 2026-10-09 rival hand size. It was only the "· 5 cards" text at the end of the style line, which phones hide
    //   (the 3-across tiles have no room for that line) and which got cut off by the ellipsis on short desktop screens.
    //   Now it's a chip: card backs with the number. Desktop keeps it on the style line (the chip can't be cut off, the
    //   style name gives way first); 899px and under get a second copy up by the avatar, since that line isn't there.
    //   Only the count is shown, never what's in the hand. Live matches send rivals' hands as a count already
    //   (hand = Array(n) of "x"), so p.hand.length is right for both.
    var pv = preview(myTurn);   //MC 2026-10-11 what the picked card would do (ghost counts on the seats, see preview())
    put($("g-rivals"), g.players.slice(1).map(function (p, k) {
      var i = k + 1, n = p.hand.length;
      var rtu = p.cos && p.cos.turn && window.ShyFx2 ? String(p.cos.turn).replace(/[^a-z]/g, "") : "";   //MC 2026-10-10 a rival's turn aura shows on their tile while it's their turn
      return '<div class="g-rival' + (g.turn === i && !g.over ? " active" : "") + (rtu ? " has-tu" : "") + '" id="g-riv-' + i + '">' + (rtu ? ShyFx2.turnHTML(rtu) : "") + avHTML(i) + handChip(i, n, false) +
        '<div class="g-rn"><b' + (p.cos && p.cos.ring ? ' class="ring-' + esc(p.cos.ring) + '"' : "") + '>' + esc(p.name) + '</b>' + (p.cos && p.cos.imp > 0 && p.cos.imp < 5 ? '<i class="imp-cr c' + (p.cos.imp | 0) + '" title="Imperial crest"></i>' : "") + (p.cos && p.cos.title ? '<em class="g-title' + (p.cos.tim ? " imp" : "") + '">' + esc(p.cos.title) + '</em>' : "") + tierB(p.cos) + '<span class="g-rsl"><i class="g-rs">' + (STYLES[p.style] || "") + '</i>' + handChip(i, n, true) + '</span></div>' +
        '<div class="g-rc"><b>' + p.regions.length + '</b><small>Regions</small></div>' +
        //MC 2026-10-11 a second copy of the Rank and tier badges for phones, in the badge row, so the name line is all name
        '<div class="g-badges">' + (p.cos && (p.cos.rank || p.cos.tier || p.cos.sk) ? '<span class="g-rkm">' + tierB(p.cos) + '</span>' : "") + statusBadges(p) + '</div><span class="g-dots"><i></i><i></i><i></i></span></div>';
    }).join(""));

    //MC 2026-10-09 replaces fan(). wide = the desktop copy with up to 6 backs fanned out; the phone copy has one back.
    //   An empty hand shows an outlined back with 0 so the chip doesn't vanish. The label is "{0} cards" / "{0} card"
    //   so the translator picks it up (title and aria-label both go through i18n.js).
    function handChip(pi, n, wide) {
      var kb = esc(backOf(pi)), h = "", lab = n === 1 ? "1 card" : n + " cards";
      for (var j = 0; j < Math.min(n, wide ? 6 : 1); j++) h += '<i class="cb cb-' + kb + '"></i>';
      if (!n) h = '<i class="cb g-hc-none"></i>';
      return '<small class="g-hc' + (wide ? " g-hc-w" : " g-hc-top") + '" role="img" aria-label="' + lab + '" title="' + lab + '"><span class="g-hc-b">' + h + '</span><strong class="g-hc-n">' + n + '</strong></small>';
    }
    put($("g-me-av"), avHTML(0, "big"));
    var wl = root.querySelector(".g-me-lab-w"); if (wl) txt(wl, root.classList.contains("is-watch") ? human.name + "'s Regions" : "");
    txt($("g-my-count"), String(human.regions.length));
    pvShow(pv);
    put($("g-my-status"), statusBadges(human));
    put($("g-my-regions"), human.regions.map(function (r) { return '<span>' + esc(r) + '</span>'; }).join("") || '<em>No Regions yet</em>');

    // best move, worked out once per turn
    if (myTurn && hintsOn()) {
      var k = g.round + ":" + g.turn + ":" + human.hand.join(",");
      if (k !== tipKey) { tipKey = k; tip = G.suggest(g, 0, 40, 90) || { pass: true }; }
    } else tip = null;
    var tipHand = tip && !tip.pass ? tip.hand : -1;

    txt($("g-hand-n"), String(human.hand.length));
    put($("g-hand"), human.hand.map(function (id, i) {
      var c = G.CARDS[id];
      var vf = finOf(0, id), ml = mlOf(0, id), gm = "";
      if (ml) { gm = '<span class="gm l' + ml + '" title="Mastery ' + ml + ' of 5">'; for (var q = 0; q < ml; q++) gm += '<i></i>'; gm += '</span>'; }
      return '<button class="gc k-' + c.kind + frameCls(0) + (i === sel ? " sel" : "") + (i === tipHand ? " tip" : "") + (i === newCard && drawAnim ? " fresh" : "") + '" data-i="' + i + '"' + (myTurn ? "" : " disabled") + '>' +
        (i === newCard && drawAnim ? '<i class="cb gc-back cb-' + esc(backOf(0)) + '" aria-hidden="true"></i>' : "") +
        '<span class="gc-key">' + (i < 9 ? i + 1 : "") + '</span>' +
        '<span class="gc-art cf' + (vf ? " vf-" + vf : "") + '"><img src="' + cardArt(id) + '" alt="" loading="lazy">' + gm + '</span>' +
        '<span class="gc-body"><span class="gc-k">' + LABEL[c.kind] + (c.season ? ' <em class="gc-season" title="Season ' + c.season + ' card">S' + c.season + '</em>' : '') + (i === tipHand ? ' <i>Best move</i>' : '') + (i === newCard ? ' <u>New</u>' : '') + '</span><b>' + esc(c.name) + '</b><span class="gc-t" title="' + esc(c.text) + '">' + esc(c.text) + '</span></span></button>';   //MC 2026-10-10 title: card text is cut at 4 lines on desktop now (game-layout.css), hover shows all of it
    }).join(""));
    drawAnim = false;   // the flip and slide-in play once, on the draw; later redraws of the hand keep the card face up

    var playBtn = $("g-play"), passBtn = $("g-pass"), pff = false, pdis = true, ptx = "Waiting...";
    if (myTurn && sel >= 0) {
      var id = human.hand[sel], ok = G.canPlay(id);
      pdis = !ok; ptx = ok ? "Play " + G.CARDS[id].name : "Works automatically";
    } else if (myTurn) {
      ptx = "Pick a card";
    } else if (!g.over && busy && isLive()) {
      ptx = g.turn === 0 ? "Sending..." : "Waiting for " + current.name.replace(" (bot)", "");
    } else if (!g.over && busy) {
      pdis = ff; ptx = ff ? "Skipping ahead..." : "Skip ahead"; pff = true;
    }
    if (playBtn.disabled !== pdis) playBtn.disabled = pdis;
    playBtn.classList.toggle("ff", pff);
    txt(playBtn, ptx);
    if (passBtn.disabled !== !myTurn) passBtn.disabled = !myTurn;
    passBtn.classList.toggle("tip", !!(tip && tip.pass));
    var claimNow = g.regionDeck.length > 0 && (!myTurn || !g.played);
    var lastOne = claimNow && g.regionDeck.length === 1;
    txt(passBtn, (lastOne ? "Claim the last Region" : claimNow ? "Claim a Region" : "End turn") + (tip && tip.pass ? " (best move)" : ""));
    var ptl = lastOne ? "Claiming the last Region ends the game" : claimNow ? "End your turn without playing and claim a Region" : "End your turn";
    if (passBtn.__title !== ptl) { passBtn.title = ptl; passBtn.__title = ptl; }

    // region change pops
    var counts = g.players.map(function (p) { return p.regions.length; });
    if (prevCounts) counts.forEach(function (c, i) {
      var d = c - prevCounts[i];
      if (d) { floatNum(i === 0 ? $("g-me-count-wrap") : $("g-riv-" + i), d); react(i, d > 0 ? "gain" : "hit"); if (Math.abs(d) >= 2 || Math.random() < .35) spSay(i, d > 0 ? "take" : "lose"); if (i === 0 && d > 0) bountyCloser(c); if (d > 0) capFx(i); if (d < 0 && i > 0) botOuch(i); }
      if (i === 0 && d < 0 && track) track.lost = true;
    });
    prevCounts = counts;
    spRender();

    var feed = $("g-log");
    if (g.log.length > shown) {
      for (var j = shown; j < g.log.length; j++) {
        var e = g.log[j], li = document.createElement("li");
        if (e.kind === "block" && e.who === 0 && track) track.blocks++;
        li.className = "new lk-" + e.kind;
        li.innerHTML = '<i style="background:' + (e.who != null && e.who >= 0 ? COLORS[e.who] : "#fff") + '"></i>' + esc(youShown(e.text));
        feed.insertBefore(li, feed.firstChild);
      }
      shown = g.log.length;
      while (feed.children.length > 8) feed.removeChild(feed.lastChild);
    }
    fitLog();
    mapSync();
  }
  //MC 2026-10-08 on desktop the log only gets the height left under the rivals, and the bottom line was chopped in
  //   half at the panel edge. Lines that don't fully fit are hidden now (the CSS fade alone still left a sliver on
  //   short screens).
  //MC 2026-10-09 the 10-08 version hid every line on phones and tablets: .g-side is display:contents under 900px, so
  //   its rect is all zeros and nothing "fit". Now a side with no box is ignored. It also measured new lines mid
  //   slide-in (logIn starts 10px up), so a line could pass the check and then slide down into the cut. Now it takes
  //   the live transform off and checks again when the slide ends, and a ResizeObserver catches the panel changing
  //   height between renders (rival cards growing, fonts landing).
  //MC 2026-10-11 lag (#9): this ran at the end of every render(), straight after the DOM writes, and each line cleared its
  //   visibility and then measured itself, so every render forced a full synchronous layout (getClientRects was 2.6s
  //   of a 70s phone profile at 4x CPU). Now: phones and tablets under 900px skip it (their log is the fixed CSS ticker,
  //   lines show by nth-child and never overflow), and desktop runs it once per frame with all the reads first and the
  //   writes after. Visibility doesn't move anything, so measuring before clearing it gives the same answer.
  var logWide = matchMedia("(min-width:900px)"), fitQ = 0;
  function fitLog() { if (!fitQ) fitQ = requestAnimationFrame(fitLogNow); }
  function fitLogNow() {
    fitQ = 0;
    var feed = $("g-log"); if (!feed) return;
    var kids = feed.children, n = kids.length, k, hide = [];
    if (!logWide.matches) { for (k = 0; k < n; k++) if (kids[k].style.visibility) kids[k].style.visibility = ""; return; }
    var side = feed.closest(".g-side");
    var sb = side && side.getClientRects().length ? side.getBoundingClientRect().bottom : Infinity;
    var lb = Math.min(feed.getBoundingClientRect().bottom, sb);
    for (k = 0; k < n; k++) {
      var li = kids[k], dy = 0;
      try { var tf = getComputedStyle(li).transform; if (tf && tf !== "none") dy = new DOMMatrixReadOnly(tf).m42; } catch (e) {}
      hide.push(li.getBoundingClientRect().bottom - dy > lb + 0.5);
    }
    for (k = 0; k < n; k++) { var v = hide[k] ? "hidden" : ""; if (kids[k].style.visibility !== v) kids[k].style.visibility = v; }
  }
  var fitT = 0;
  addEventListener("resize", function () { fitLog(); clearTimeout(fitT); fitT = setTimeout(fitLog, 350); });
  if (logWide.addEventListener) logWide.addEventListener("change", fitLog);
  $("g-log").addEventListener("animationend", fitLog);
  if (window.ResizeObserver) new ResizeObserver(function () { fitLog(); }).observe($("g-log"));

  // what's about to end the game, in plain words
  function endgameAlert() {
    var el = $("g-alert"); if (!el) return;
    var msgs = [], left = g.regionDeck.length, nP = g.players.length, cls = "";
    if (!g.over) {
      g.players.forEach(function (p, i) {
        var n = p.regions.length;
        if (n >= G.WIN_AT - 3) msgs.push(i === 0 ? "You hold " + n + ". Reach " + G.WIN_AT + " and you win on the spot." : esc(p.name) + " holds " + n + ". At " + G.WIN_AT + " they win on the spot.");
      });
      if (msgs.length) cls = "lv-hot";
      if (left && left <= nP) { msgs.push("Last " + (left === 1 ? "Region" : left + " Regions") + ". The game ends when they're gone. Ties go to most cards in hand."); cls = "lv-hot"; }
      else if (left && left <= nP * 2) { msgs.push("Endgame. " + left + " Regions left to claim."); cls = cls || "lv-warm"; }
    }
    //MC 2026-10-11 stakes in the last rounds (improvement 6): at "Last N Regions" the alert carries a mini scoreboard,
    //   every seat's Regions and cards in standings order, since a Regions tie goes to cards (5 of 12 audit games ended on
    //   that tie-break and nobody saw it coming), and the table takes a faint red edge (CSS .g-final). The alert floats
    //   over the map (absolute), so the map keeps its size. The scoreboard is part of the alert's markup, so a change in
    //   anyone's count brings the alert back to full strength on phones (it fades back after 4s, #15).
    var fin = !g.over && left > 0 && left <= nP;
    root.classList.toggle("g-final", fin);
    var sb = "";
    if (fin) {
      var rows = g.players.map(function (p, i) { return { i: i, r: p.regions.length, c: p.hand.length }; })
        .sort(function (a, b) { return b.r - a.r || b.c - a.c || a.i - b.i; });
      //   Each name and each "5 cards" is its own block (div): i18n.js looks a run of inline text up whole, so spans here
      //   would have joined the alert's sentence into one unknown key and left the alert in English in every language.
      sb = '<div class="g-sb">' + rows.map(function (x) {
        var lead = x.r === rows[0].r && x.c === rows[0].c, nm = x.i === 0 ? "You" : g.players[x.i].name.replace("Shadow ", "").replace(" (bot)", "");
        return '<div class="g-sb-p' + (lead ? " lead" : "") + (x.i === 0 ? " me" : "") + '"><i style="background:' + COLORS[x.i] + '"></i><div class="g-sb-n">' + esc(nm) + '</div><b>' + x.r + '</b><div class="g-sb-c">' + (x.c === 1 ? "1 card" : x.c + " cards") + '</div></div>';
      }).join("") + '</div>';
    }
    if (el.hidden !== !msgs.length) el.hidden = !msgs.length;
    root.classList.toggle("has-alert", !!msgs.length);
    if (el.className !== "g-alert " + cls) el.className = "g-alert " + cls;
    var was = el.__html;
    put(el, msgs.join("<br>") + sb);   //MC 2026-10-11 was rewritten on every render even when nothing changed
    //MC 2026-10-11 #15 on phones it fades back (CSS .dim) a few seconds after it changes, so the south of the map shows
    if (el.__html !== was) { el.classList.remove("dim"); clearTimeout(endgameAlert.t); if (msgs.length) endgameAlert.t = setTimeout(function () { el.classList.add("dim"); }, 4000); }
  }
  function tied(rows, x) { return rows.filter(function (y) { return y.regions === x.regions; }).length > 1; }
  function endReason(deckLeft, topRegions, topName) {
    if (topRegions >= G.WIN_AT) return topName + " reached " + G.WIN_AT + " Regions.";
    if (!deckLeft) return "The unclaimed Regions ran out.";
    return "The round limit was reached.";
  }
  function tieNote(rows) {
    // rows sorted best first; explain the cards-in-hand tiebreak when it decided first place
    if (rows.length > 1 && rows[0].regions === rows[1].regions) {
      return rows[0].hand === rows[1].hand ? " Tied on Regions and cards, so the world is shared." : " Tied on Regions, decided by cards in hand (" + rows[0].hand + " to " + rows[1].hand + ").";
    }
    return "";
  }
  function statusBadges(p) {
    var b = "";
    if (p.holder && p.bot) b += '<span class="gb gb-holder">Holder</span>';
    if (isLive() && p.bot) b += p.style === "live" ? '<span class="gb gb-human">Player</span>' : p.style === "away" ? '<span class="gb gb-bot">Away</span>' : '<span class="gb gb-bot">Bot</span>';
    if (p.shield > 0) b += '<span class="gb gb-shield">Bunker</span>';
    if (p.skip) b += '<span class="gb gb-skip">' + (p.skip > 1 ? "Skips " + p.skip : "Skips next") + '</span>';
    if (p.lone) b += '<span class="gb gb-shield">Lone Survivor</span>';
    if (p.paper) b += '<span class="gb gb-shield">Paper Fortress</span>';
    if (p.harvest) b += '<span class="gb gb-gain">Harvest next turn</span>';
    if (g && g.truce >= 0 && g.players[g.truce] === p) b += '<span class="gb gb-coup">Truce: no attacks</span>';
    if (p.hand.indexOf("failedcoup") >= 0 && !p.bot) b += '<span class="gb gb-coup">Coup ready</span>';
    return b;
  }
  function floatNum(el, delta) {
    if (!el || !delta) return;
    var f = document.createElement("span");
    f.className = "g-float " + (delta > 0 ? "up" : "down");
    f.textContent = (delta > 0 ? "+" : "") + delta;
    el.appendChild(f);
    setTimeout(function () { f.remove(); }, 1200);
  }
  //MC 2026-10-10 a Region claim effect from the shop: yours from what you wear, a rival's from what the table shows of them.
  //   It's drawn over the seat's Region count (yours) or their tile (rivals). Bots have none.
  function capFx(i) {
    if (ff || reduce || !window.ShyFx2) return;
    var k = i === 0 ? (live && live.watch ? "" : (eco().eq.cap || "").replace("cap_", "")) : (g.players[i] && g.players[i].cos && g.players[i].cos.cap) || "";
    if (!k) return;
    var el = i === 0 ? $("g-me-count-wrap") : root.querySelector("#g-riv-" + i + " .g-av");
    if (el && el.getClientRects().length) ShyFx2.cap(root, el, String(k).replace(/[^a-z]/g, ""));
  }
  function scrollToCard(i) {
    var h = $("g-hand"), c = h.children[i];
    if (!c || h.scrollWidth <= h.clientWidth) return;
    h.scrollTo({ left: c.offsetLeft - (h.clientWidth - c.offsetWidth) / 2, behavior: reduce ? "auto" : "smooth" });
  }

  //MC 2026-10-11 preview before you commit (audit/game.md improvement 2). A picked card shows what it will do: a ghost
  //   "+1" / "-2" by each seat's Region count and a glow on the land that's at risk. The engine is pure, so the card is
  //   played on a copy of the table (never the real game, never g.rnd: a Daily or a Duel must replay the same). The copy
  //   only holds what you can see: rivals' hands and both Chaos decks are blank filler cards, so a Failed Coup or Eclipse
  //   in a rival's hand isn't given away, and a live match (which only sends public state) works the same way. It's played
  //   6 times with different random draws; a seat whose count comes out different between runs (a random leader, an
  //   Extinction) shows "?" (titled Random) instead of a number. Which Regions a loss takes is always random, so the glow
  //   is on all of that seat's land, not on single pins. False Memory needs the last card's effect, which a live match
  //   doesn't send, so it has no preview there. pvPlay is the engine's own play(): kept from load time so a test hook on
  //   ShyGame.play (qa2/audit_game_test.py counts out-of-turn plays) only ever sees real moves.
  //   Tried first: G.suggest's determinize(), but it isn't exported and it reshuffles the Region deck from real data.
  var pvPlay = G.play, pvMemo = { k: "", v: null }, PV_FILL = "double", PV_RUNS = 6;
  // the public table as JSON, made once per preview and parsed fresh for each run
  function pvBase() {
    var fill = function (n) { var a = []; for (var k = 0; k < n; k++) a.push(PV_FILL); return a; };
    return JSON.stringify({ round: g.round, start: g.start, plays: Math.max(1, g.plays || 0), played: !!g.played,
      noDraw: g.noDraw == null ? -1 : g.noDraw, truce: g.truce == null ? -1 : g.truce, snap: isLive() ? null : g.snap || null,
      regionDeck: g.regionDeck, regionDiscard: g.regionDiscard,
      players: g.players.map(function (p, i) { return { name: p.name, regions: p.regions, hand: i === 0 ? p.hand : fill(p.hand.length), shield: p.shield || 0, skip: p.skip || 0, lone: !!p.lone, paper: !!p.paper, harvest: p.harvest || 0 }; }),
      chaosDeck: fill(g.chaosDeck ? g.chaosDeck.length : 40), chaosDiscard: fill(g.chaosDiscard ? g.chaosDiscard.length : 0) });
  }
  function pvCopy(base, seed) {
    var c = JSON.parse(base);
    c.turn = 0; c.log = []; c.over = false; c.blocks = 0; c.extraTurn = false; c.rnd = G.seeded(seed);
    return c;
  }
  // each seat's Region change: a number, or null when it isn't the same every run. null overall: the engine refused it.
  function pvRun(base, hi, t) {
    var seen = g.players.map(function () { return {}; });
    for (var s = 0; s < PV_RUNS; s++) {
      var c = pvCopy(base, 9973 * (s + 1));
      try { if (!pvPlay(c, 0, hi, t)) return null; } catch (e) { return null; }
      c.players.forEach(function (p, i) { seen[i][p.regions.length - g.players[i].regions.length] = 1; });
    }
    return seen.map(function (m) { var k = Object.keys(m); return k.length === 1 ? +k[0] : null; });
  }
  // what the preview depends on, or null when there's nothing to preview
  function pvKey(myTurn) {
    if (!myTurn || sel < 0 || !g || g.over || g.replay || (live && live.watch)) return null;
    var id = g.players[0].hand[sel], c = G.CARDS[id];
    if (!c || !G.canPlay(id) || (id === "falsememory" && isLive())) return null;
    return [sel, id, g.log.length, g.round, g.plays, g.truce, g.regionDeck.length, g.regionDiscard.length, g.players.map(function (p) {
      return p.regions.length + "/" + p.hand.length + "/" + (p.shield || 0) + (p.lone ? "l" : "") + (p.paper ? "p" : ""); }).join(",")].join("|");
  }
  //   The runs happen after the frame that shows the picked card, not inside the tap's render(): measured on a 4x
  //   throttled phone, working it out in the tap added about 20ms to the median tap-to-picked-card time (and up to 140ms
  //   on a global card). render() shows no ghost until the answer is in, then pvLate() puts it on screen by itself.
  var pvQ = 0;
  function preview(myTurn) {
    var key = pvKey(myTurn);
    if (!key) return null;
    if (pvMemo.k === key) return pvMemo.v;
    if (!pvQ) pvQ = requestAnimationFrame(function () { pvQ = 0; setTimeout(pvLate, 0); });
    return null;
  }
  function pvLate() {
    var key = g && pvKey(g.turn === 0 && !busy && !g.over);
    if (!key || pvMemo.k === key) return;
    var c = G.CARDS[g.players[0].hand[sel]];
    var v = { pick: c.target === "pick", by: {}, all: null };
    var base = pvBase();
    if (v.pick) g.players.forEach(function (p, t) { if (t > 0 && !(p.shield > 0)) v.by[t] = pvRun(base, sel, t); });
    else v.all = pvRun(base, sel, null);
    pvMemo = { k: key, v: v };
    pvShow(v);
  }
  // the change to show for a seat: a number (0 = nothing), null = random, undefined = no preview
  function pvSeat(v, i) {
    if (!v) return undefined;
    if (!v.pick) return v.all ? v.all[i] : undefined;
    if (i > 0) return v.by[i] ? v.by[i][i] : undefined;
    // your own change from a "pick a rival" card: shown when it's the same whichever rival you pick (a steal is +1)
    var ds = Object.keys(v.by).map(function (t) { return v.by[t] ? v.by[t][0] : undefined; });
    return ds.length && ds.every(function (d) { return d === ds[0]; }) ? ds[0] : undefined;
  }
  function pvTag(d) {
    if (d === undefined || d === 0) return "";
    if (d === null) return '<i class="g-pv rnd" title="Random" aria-label="Random">?</i>';
    return '<i class="g-pv ' + (d > 0 ? "up" : "dn") + '" aria-hidden="true">' + (d > 0 ? "+" : "") + d + '</i>';
  }
  function pvShow(v) {
    // rivals: a ghost in each tile's count box. Kept out of the tiles' markup in render(): there, picking a card rewrote
    //   all three tiles (pictures, turn auras, a running reaction); here only the little ghost changes. A tile rewritten
    //   for another reason loses it and gets it back in the same render, since this runs right after.
    for (var i = 1; i < g.players.length; i++) {
      var rc = root.querySelector("#g-riv-" + i + " .g-rc"); if (!rc) continue;
      var gh = rc.querySelector(":scope > .g-pv-r"), html = pvTag(pvSeat(v, i));
      if (!gh) { if (!html) continue; gh = document.createElement("span"); gh.className = "g-pv-r"; rc.insertBefore(gh, rc.querySelector(":scope > small")); }
      put(gh, html);
    }
    // your count: a ghost next to it in the map header
    var w = $("g-me-count-wrap"), el = w && w.querySelector(":scope > .g-pv-me");
    if (w && !el) { el = document.createElement("span"); el.className = "g-pv-me"; w.appendChild(el); }
    if (el) { put(el, pvTag(pvSeat(v, 0))); w.parentNode.classList.toggle("pv-on", !!el.firstChild); }   // the ghost takes the "Your Regions" label's place while it shows
    // land at risk: every seat whose count goes down (or might) glows on the map. A "pick a rival" card leaves that to
    // the target picking (the rivals' land already pulses there)
    if (!mapSvg) return;
    var risk = [];
    if (v && !v.pick && v.all) v.all.forEach(function (d, i) { if (d === null || d < 0) risk.push(i); });
    var rk = risk.join(" ");
    if ((mapSvg.getAttribute("data-pvl") || "") !== rk) { if (rk) mapSvg.setAttribute("data-pvl", rk); else mapSvg.removeAttribute("data-pvl"); }
  }

  //MC 2026-10-11 target picking on the map (improvement 1). While "Who's the target?" is up, the table dims and each rival
  //   you can hit pulses: their seat tile and their land, and a tap on either picks them. The sheet stays (keyboard,
  //   screen readers, and the Cancel button) and works exactly as before. The state lives on #g-rivals (data-pick) and a
  //   class on the table, not in the tiles' markup, so render() rewriting the tiles can't lose it, and one observer on the
  //   sheet's hidden attribute catches every way it closes (Cancel, Esc, Claim, a play, a new turn, the end of the game).
  //   Esc used to leave the map in picking mode; this fixes that too.
  function pickSync() {
    var sh = $("g-targets"), on = !!(g && !g.over && !sh.hidden);
    root.classList.toggle("g-picking", on);
    var ts = on ? [].map.call(sh.querySelectorAll(".g-tgt:not([disabled])"), function (b) { return b.dataset.t; }).join(" ") : "";
    var rv = $("g-rivals");
    if ((rv.getAttribute("data-pick") || "") !== ts) { if (ts) rv.setAttribute("data-pick", ts); else rv.removeAttribute("data-pick"); }
    mapSync();
  }
  if (window.MutationObserver) new MutationObserver(pickSync).observe($("g-targets"), { attributes: true, attributeFilter: ["hidden"] });
  function pickSeat(t) {
    if (!root.classList.contains("g-picking")) return false;
    var btn = document.querySelector('#g-targets .g-tgt[data-t="' + t + '"]');
    if (!btn || btn.disabled) return false;
    btn.click();
    return true;
  }
  $("g-rivals").addEventListener("click", function (e) {
    var r = e.target.closest && e.target.closest(".g-rival");
    if (r) pickSeat(parseInt(r.id.replace("g-riv-", ""), 10));
  });

  //MC 2026-10-24 the end: the winning Shadow takes its moment on the table, and if you lost as a Shadow, yours turns away
  function spEnd(won, winner) {
    if (!window.ShyShadowPlay || !ShyShadowPlay.on()) return;
    var wi = won ? 0 : winner, wa = wi >= 0 ? avatars[wi] : null;
    setTimeout(function () {
      if (wa && wa.n && !wa.trial) { ShyShadowPlay.play({ root: root, n: wa.n, au: wa.au, kind: "win", mirror: wi !== 0, name: wi === 0 ? "You win" : (g && g.players[wi] ? g.players[wi].name + " wins" : "Winner") }); if (won) spSay(0, "win"); }
      else if (!won && avatars[0] && avatars[0].n && !avatars[0].trial) ShyShadowPlay.play({ root: root, n: avatars[0].n, au: avatars[0].au, kind: "lose", mirror: false, name: "Next time" });
    }, 900);
  }
  function spPrep() {
    if (window.ShyShadowPlay) avatars.forEach(function (a) { if (a && a.n && !a.trial) ShyShadowPlay.prep(a.n); });
    //MC 2026-10-24 your Shadow stands at your seat on wide screens (assets/shadowlive.js); the leader's Aura is the table's weather
    if (window.ShyShadowLive) { var me0 = avatars[0]; if (me0 && me0.n && !me0.trial) ShyShadowLive.mount(root, me0.n, me0.au || "none"); else ShyShadowLive.unmount(); }
    spLeader = -1;
  }
  var spLeader = -1, spTurnSeen = -1;
  function spAura(i) { var a = avatars[i]; return a && a.n && !a.trial ? (a.au || "none") : ""; }
  function spRender() {
    if (!window.ShyShadowLive || !g) return;
    // the weather follows whoever leads on Regions, if they play as a Shadow (no leader, no weather)
    var best = -1, bn = -1, tie = false;
    g.players.forEach(function (p, i) { var n = p.regions.length; if (n > bn) { bn = n; best = i; tie = false; } else if (n === bn) tie = true; });
    var lead = !tie && best >= 0 && spAura(best) ? best : -1;
    ShyShadowLive.setWeather(root, lead >= 0 ? spAura(lead) : "");
    if (lead !== spLeader) { if (lead >= 0 && spLeader !== -1 && !g.over) spSay(lead, "lead"); spLeader = lead; }
    // the figure looks at whoever has the turn
    if (g.turn !== spTurnSeen) { spTurnSeen = g.turn; ShyShadowLive.lookAt(g.turn === 0 ? root.querySelector(".g-hand-wrap") : $("g-riv-" + g.turn)); }
  }
  // a Shadow speaks: by your figure on wide screens, by your avatar on phones, at a rival's tile for theirs
  function spSay(i, kind) {
    var au = spAura(i); if (!au || !window.ShyShadowLive || !window.ShyShadowPlay || !ShyShadowPlay.on()) return;
    var anchor = i === 0 ? (ShyShadowLive.dockEl() || root.querySelector("#g-me-av")) : $("g-riv-" + i);
    ShyShadowLive.say(au, kind, anchor, root);
  }
  //MC 2026-10-24 which plays earn a cut-in, so it never gets old: every seat's first play of a game, every Global, and
  //   otherwise one Attack or Defense in three. "Big moments only" keeps the first play and Globals.
  var spSeen = {};
  function spWorthy(pi, c) {
    var m = ShyShadowPlay.mode(), first = !spSeen[pi]; spSeen[pi] = 1;
    if (first || c.kind === "global") return true;
    return m === "on" && Math.random() < .34;
  }
  // the card lands on the real table: the 3D table pulses and kicks, the flat map flashes with a ring where it hit
  function spHit(p, col) {
    try { if (m3d && m3d.pulse) m3d.pulse(col); } catch (e) {}
    var mp = $("g-map"); if (!mp) return;
    mp.classList.remove("sp-hit"); void mp.offsetWidth; mp.classList.add("sp-hit");
    var r = mp.getBoundingClientRect(), s = document.createElement("i"); s.className = "sp-maphit"; s.style.setProperty("--c", col);
    s.style.left = "50%"; s.style.top = "50%"; s.style.width = s.style.height = Math.min(r.width, r.height) * .9 + "px";
    mp.appendChild(s); setTimeout(function () { s.remove(); }, 800);
  }
  // a line in the log with a replay button, and a line for the share text
  var spLast = "";
  function spNote(pi, n, cardName) {
    var feed = $("g-log"); if (!feed) return;
    var li = document.createElement("li"); li.className = "new lk-sp";
    li.innerHTML = '<i style="background:' + COLORS[pi] + '"></i>' + esc((pi === 0 ? "Your" : g.players[pi].name + "'s") + " Shadow #" + n + " played " + cardName) + '<button type="button" data-sp-replay>Replay</button>' + (pi === 0 && window.MediaRecorder ? '<button type="button" data-sp-clip>Clip</button>' : "");
    feed.insertBefore(li, feed.firstChild); while (feed.children.length > 8) feed.removeChild(feed.lastChild);
    if (pi === 0) spLast = "My Shadow #" + n + " played " + cardName + " itself.";
  }
  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-sp-replay]") && window.ShyShadowPlay) ShyShadowPlay.replay();
    //MC 2026-10-24 a three second clip of the cut-in, shared through the phone's share sheet or saved
    var cb = e.target.closest("[data-sp-clip]");
    if (cb && window.ShyShadowPlay && ShyShadowPlay.last()) {
      cb.disabled = true; cb.textContent = "Making clip";
      ShyShadowPlay.clip(ShyShadowPlay.last()).then(function (r) {
        cb.textContent = "Clip"; cb.disabled = false;
        if (!r) { toast("This browser can't record the clip."); return; }
        var f = new File([r.blob], "shadow-" + ShyShadowPlay.last().n + "." + r.ext, { type: r.blob.type });
        if (navigator.canShare && navigator.canShare({ files: [f] })) { navigator.share({ files: [f], text: "My Shadow #" + ShyShadowPlay.last().n + " in Shilluminati Online. shyonsol.io/play $SHY" }).catch(function () {}); }
        else { var u = URL.createObjectURL(r.blob), a = document.createElement("a"); a.href = u; a.download = f.name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 5000); toast("Clip saved. Attach it to your post."); }
      });
    }
  });
  // big card flash when anyone plays
  async function flash(pi, id) {
    var c = G.CARDS[id], el = $("g-flash");
    sfx(c.kind === "global" ? "global" : "play");
    if (ff) return;
    var vf = finOf(pi, id), ml = mlOf(pi, id), MN = ["", "Novice", "Adept", "Veteran", "Master", "Grandmaster"];
    //MC 2026-10-24 a seat playing as its own verified Shadow: the Shadow steps off its picture and plays Attack, Defense
    //   and Global cards itself before the big card shows (assets/shadowplay.js). A tap skips it.
    var spA = avatars[pi], spDid = false;
    if (window.ShyShadowPlay && spA && spA.n && !spA.trial && /^(attack|defense|global)$/.test(c.kind) && spWorthy(pi, c)) {
      //MC 2026-10-24 in a duel the other seat's Shadow takes an Attack on its side; the landing hits the real table
      var foe = null; if (c.kind === "attack" && g.players.length === 2) { var fa = avatars[1 - pi]; if (fa && fa.n && !fa.trial) foe = { n: fa.n, au: fa.au }; }
      var spOpts = { root: root, n: spA.n, au: spA.au, kind: c.kind, card: cardArt(id), name: c.name, mirror: pi !== 0, target: $("g-map"), foe: foe, onHit: spHit,
        shake: function () { root.classList.remove("fx2-shake"); void root.offsetWidth; root.classList.add("fx2-shake"); setTimeout(function () { root.classList.remove("fx2-shake"); }, 450); } };
      spDid = await ShyShadowPlay.play(spOpts);
      if (ff) return;
      if (spDid) { spNote(pi, spA.n, c.name); spSay(pi, "big"); }
    }
    el.innerHTML = '<div class="g-flash-card k-' + c.kind + frameCls(pi) + '"><span class="cf' + (vf ? " vf-" + vf : "") + '"><img src="' + cardArt(id) + '" alt=""></span><div class="g-flash-who">' + avHTML(pi) +
      '<span>' + esc(pi === 0 ? "You play" : g.players[pi].name + " plays") + '</span></div><b>' + esc(c.name) + '</b>' + (ml >= 3 ? '<span class="gm-t">' + MN[ml] + '</span>' : "") + '<p>' + esc(c.text) + '</p></div>';
    el.hidden = false;
    el.classList.remove("out");
    await wait(spDid ? 700 : pi === 0 ? 850 : 1100);
    el.classList.add("out");
    await wait(200);
    el.hidden = true;
  }
  async function banner(text, cls) {
    if (ff) return;
    var b = $("g-banner");
    b.className = "g-banner " + (cls || ""); b.textContent = text; b.hidden = false;
    await wait(950);
    b.hidden = true;
  }
  // sound for whatever just happened in the log
  function sfxFor(from) {
    var entries = g.log.slice(from), kinds = entries.map(function (e) { return e.kind; });
    entries.forEach(function (e) { if (e.kind === "play") react(e.who, "cast"); else if (e.kind === "block") react(e.who, "block"); });
    if (kinds.indexOf("block") >= 0) sfx("block");
    else if (entries.some(function (e) { return /skip their next turn/.test(e.text); })) sfx("skip");
    else if (kinds.indexOf("hit") >= 0) sfx("hit");
    else if (kinds.indexOf("gain") >= 0 || kinds.indexOf("claim") >= 0) sfx("gain");
  }

  // ---------- war table map ----------
  var SVGNS = "http://www.w3.org/2000/svg";
  var MAP = null, mapSvg = null, mapPrev = null, ML = { region: {}, pin: {} };
  var mapEl = $("g-map");
  //MC 2026-10-14 the 3D war table (assets/map3d.js) sits beside the flat map and shows instead of it when a player has
  //   it on (shy-map3d, on by default where WebGL exists). Every paint, turn and highlight goes to both, so flipping
  //   the switch is instant and the flat map is always current underneath. No WebGL, a failed load or a lost GPU
  //   context all land back on the flat map, which is why it is never torn down.
  //MC 2026-10-14 the table is the default on every visit where it can draw; picking 2D is remembered for the
  //   session only (sessionStorage), so a player who tried the flat map once is not stuck on it next time
  var m3d = null, map3dOn = true, map3dBad = false, map3dLazy = false, coarsePtr = matchMedia("(pointer: coarse)").matches;
  try { map3dOn = sessionStorage.getItem("shy-map3d") !== "off"; } catch (e) {}
  (function () {
    var v = (document.querySelector('script[src*="play.js"]') || {}).src || "";
    fetch("assets/map.json?" + (v.split("?")[1] || "")).then(function (r) { return r.json(); })
      .then(function (m) {
        MAP = m; buildMap(); root.classList.add("has-map"); mapPrev = null;
        mapUiBuild(); mapMode(map3dOn, true);
        $("g-me-count-wrap").parentNode.appendChild($("g-deck")); // counts sit in the map header
        $("g-board").appendChild($("g-coach"));                    // tips float over the map instead of pushing the hand down
        //MC 2026-10-10 the endgame alert ("Endgame. 8 Regions left to claim.") floats on the map itself now. On phones it was
        //   a strip above the rivals and took its height straight out of the map, which also gave way to every log line and
        //   rival badge row, so the world shrank all game (330px wide at the start, 149px by the end at 360x740). Desktop
        //   already floated it over the map from the grid (release q); living inside the map it floats the same on every
        //   screen. Without a map (map.json failed) it stays where it was.
        mapEl.appendChild($("g-alert"));
        if (g) mapSync();
      })
      .catch(function () { root.classList.add("no-map"); });
  })();
  function sv(tag, attrs, parent) {
    var e = document.createElementNS(SVGNS, tag);
    for (var k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function buildMap() {
    mapSvg = sv("svg", { viewBox: "0 0 " + MAP.w + " " + MAP.h, class: "g-map-svg", role: "img" });
    var defs = sv("defs", {}, mapSvg);
    defs.innerHTML =
      '<pattern id="mp-open" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="9" height="9" fill="#2b2266"/><rect width="3.5" height="9" fill="#3a2f84"/></pattern>' +
      '<radialGradient id="mp-sea" cx="50%" cy="40%" r="75%"><stop offset="0" stop-color="#2a1f6b"/><stop offset=".6" stop-color="#170f43"/><stop offset="1" stop-color="#0b0724"/></radialGradient>' +
      '<radialGradient id="mp-flash"><stop offset="0" stop-color="#fff6d5"/><stop offset=".35" stop-color="#ffd166"/><stop offset=".7" stop-color="#ff5d73" stop-opacity=".7"/><stop offset="1" stop-color="#ff5d73" stop-opacity="0"/></radialGradient>' +
      '<filter id="mp-glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>';
    sv("rect", { width: MAP.w, height: MAP.h, fill: "url(#mp-sea)" }, mapSvg);
    sv("path", { d: MAP.grat, class: "mp-grat" }, mapSvg);
    var land = sv("g", { class: "mp-land" }, mapSvg);
    var pins = sv("g", { class: "mp-pins" }, mapSvg);
    ML.fx = sv("g", { class: "mp-fx" }, mapSvg);
    G.REGIONS.forEach(function (name) {
      var r = MAP.regions[name]; if (!r) return;
      ML.region[name] = sv("path", { d: r.d, class: "mp-r open", "data-r": name }, land);
      var pin = sv("g", { class: "mp-pin", transform: "translate(" + r.c[0] + " " + r.c[1] + ")" }, pins);
      var inner = sv("g", { class: "mp-pin-in" }, pin);
      var span = Math.min(r.b[1][0] - r.b[0][0], r.b[1][1] - r.b[0][1]), pr = Math.max(9, Math.min(15, span / 4.5));
      sv("circle", { r: pr, class: "mp-pin-ring" }, inner);
      sv("circle", { r: pr * 0.62, class: "mp-pin-dot" }, inner);
      ML.pin[name] = pin;
    });
    mapEl.appendChild(mapSvg);
    // tap or hover a Region to see who holds it
    var tipEl = $("g-map-tip"), tipTimer = null;
    //MC 2026-10-14 the tip itself takes a Region name and a point, so the 3D table can ask for the same tip
    function tipFor(n, cx, cy, ptr) {
      var o = mapPrev && mapPrev[n];
      if (!n || !g) { tipEl.hidden = true; return; }
      var who = typeof o === "number" ? (o === 0 ? "You" : g.players[o].name) : o === "gone" ? "Destroyed" : "Unclaimed";
      tipEl.innerHTML = "<b>" + esc(n) + "</b><span" + (typeof o === "number" ? ' style="color:' + COLORS[o] + '"' : "") + ">" + esc(who) + "</span>";
      var b = $("g-board").getBoundingClientRect();
      tipEl.style.left = Math.min(Math.max(cx - b.left, 70), b.width - 70) + "px";
      tipEl.style.top = Math.max(cy - b.top - 12, 30) + "px";
      tipEl.hidden = false;
      clearTimeout(tipTimer);
      if (ptr !== "mouse") tipTimer = setTimeout(function () { tipEl.hidden = true; }, 1800);
    }
    function showTip(e) {
      var p = e.target.closest && e.target.closest(".mp-r");
      if (!p || !g) { tipEl.hidden = true; return; }
      //MC 2026-10-11 picking a target by tapping a rival's land moved to the click listener below: on pointerdown a
      //   finger that only meant to scroll the table (short screens scroll) could fire the card
      tipFor(p.getAttribute("data-r"), e.clientX, e.clientY, e.pointerType);
    }
    mapTip = tipFor; mapTipHide = function () { tipEl.hidden = true; };
    mapSvg.addEventListener("pointermove", function (e) { if (e.pointerType === "mouse") showTip(e); });
    mapSvg.addEventListener("pointerdown", showTip);
    mapSvg.addEventListener("pointerleave", function () { tipEl.hidden = true; });
    // picking a target: a tap (not a scroll) on a rival's land picks that rival
    mapSvg.addEventListener("click", function (e) {
      var p = e.target.closest && e.target.closest(".mp-r");
      if (p) mapTapPick(p.getAttribute("data-r"));
    });
  }
  var mapTip = null, mapTipHide = null;
  function mapTapPick(n) {
    var o = n && mapPrev ? mapPrev[n] : null;
    if (typeof o === "number" && o > 0 && pickSeat(o) && mapTipHide) mapTipHide();
  }
  //MC 2026-10-14 ---- the 3D table: the switch, the view buttons and the hint, over the map's bottom edge
  function mapUiBuild() {
    if ($("g-map-ui")) return;
    var box = document.createElement("div"); box.className = "g-map3d"; box.id = "g-map3d"; mapEl.appendChild(box);
    var ui = document.createElement("div"); ui.className = "g-map-ui"; ui.id = "g-map-ui";
    //MC 2026-10-14 premium pass: the views are icon pills (overview, my regions, cinematic), the one in use is lit,
    //   and the table carries its own eyebrow and vignette so it reads like a war room and not a widget
    var ICO = { overview: '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6.2"/><path d="M1.8 8h12.4M8 1.8c2.4 2.2 2.4 10.2 0 12.4M8 1.8c-2.4 2.2-2.4 10.2 0 12.4"/></svg>',
                mine: '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 14.5v-12M3.5 2.5h8.5l-2 3 2 3H3.5"/></svg>',
                cinematic: '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="1.8" y="3.3" width="12.4" height="9.4" rx="1.4"/><path d="M1.8 6.2h12.4M1.8 9.8h12.4M5 3.3v9.4M11 3.3v9.4"/></svg>' };
    ui.innerHTML = '<button type="button" class="gmu-mode" id="gmu-mode" data-i18n-skip></button>' +
      '<span class="gmu-views">' + ["overview", "mine", "cinematic"].map(function (v) {
        return '<button type="button" data-map-view="' + v + '">' + ICO[v] + '<span>' + (v === "overview" ? "Overview" : v === "mine" ? "My regions" : "Cinematic") + '</span></button>';
      }).join("") + '</span>' +
      '<span class="gmu-hint">' + (coarsePtr ? "Drag to orbit · Pinch to zoom" : "Drag to orbit · Scroll to zoom") + '</span>';
    mapEl.appendChild(ui);
    var eye = document.createElement("div"); eye.className = "g-map-eyebrow"; eye.id = "g-map-eyebrow";
    eye.innerHTML = '<b>Global command table</b><span>Live territory control</span>';
    mapEl.appendChild(eye);
    // a narrow table (a phone, or a tight desktop window) keeps the icons and drops the labels and the hint
    var narrow = function () { mapEl.classList.toggle("is-narrow", mapEl.clientWidth < 700); };
    if (window.ResizeObserver) new ResizeObserver(narrow).observe(mapEl); narrow();
    ui.addEventListener("click", function (e) {
      var v = e.target.closest("[data-map-view]"); if (v) { if (m3d) m3d.view(v.getAttribute("data-map-view")); return; }
      if (e.target.closest("#gmu-mode") && !map3dBad) mapMode(!map3dOn);
    });
    mapUiDraw();
  }
  // the war table cosmetics, sent to the 3D table only when something changed (every render passes through here)
  var mapLookKey = "";
  function mapLook() {
    if (!m3d) return;
    var eq = eco().eq || {}, pieces = {}, mine = live && live.watch ? "" : (eq.piece || "").replace("piece_", "");
    if (g) g.players.forEach(function (p, i) { pieces[i] = i === 0 ? mine : (p.cos && p.cos.piece) || ""; }); else pieces[0] = mine;
    var key = [eq.felt || "", eq.land || "", eq.air || "", JSON.stringify(pieces)].join("|");
    if (key === mapLookKey) return;
    mapLookKey = key;
    m3d.setLook({ felt: (eq.felt || "").replace("felt_", ""), land: (eq.land || "").replace("land_", ""), air: (eq.air || "").replace("air_", ""), pieces: pieces });
  }
  function mapViewMark(name) {
    var ui = $("g-map-ui"); if (!ui) return;
    ui.querySelectorAll("[data-map-view]").forEach(function (b) { b.classList.toggle("is-on", b.getAttribute("data-map-view") === name); });
  }
  function mapUiDraw() {
    var b = $("gmu-mode"); if (!b) return;
    b.textContent = map3dOn ? "2D" : "3D";
    b.title = map3dBad ? "3D map isn't supported on this device" : (map3dOn ? "Switch to the flat map" : "Switch to the 3D table");
    b.disabled = map3dBad;
    mapEl.classList.toggle("map3d", map3dOn);
  }
  function mapMode(on, first) {
    map3dOn = !!on && !map3dBad;
    if (!first) { try { sessionStorage.setItem("shy-map3d", map3dOn ? "on" : "off"); } catch (e) {} }
    mapUiDraw();
    if (!map3dOn) { if (m3d) { try { m3d.dispose(); } catch (e) {} m3d = null; } return; }
    if (m3d || !MAP) return;
    //MC 2026-10-18 the 3D table (710KB of three.js) used to load the moment the Play page opened, menu or not; most of a
    //   phone's lag on this page. Now it loads when the first match actually draws (render() below picks it up)
    if (first && !g) { map3dLazy = true; return; }
    map3dLazy = false;
    var fall = function (why) { try { console.warn("3D table off:", why && why.message || why); } catch (e2) {} map3dBad = true; map3dOn = false; if (m3d) { try { m3d.dispose(); } catch (e) {} m3d = null; } mapUiDraw(); };
    if (!window.ShyMap3D || !ShyMap3D.supported()) { fall("no webgl"); return; }
    ShyMap3D.load("assets/vendor/three-map.js" + AV).then(function () {
      if (!map3dOn || m3d) return;
      try {
        m3d = ShyMap3D.mount({ el: $("g-map3d"), map: MAP, regions: G.REGIONS, colors: COLORS, reduce: reduce, me: 0,
          hooks: { tip: function (n, x, y, p) { if (mapTip) mapTip(n, x, y, p); }, leave: function () { if (mapTipHide) mapTipHide(); }, tap: mapTapPick, fail: fall, view: mapViewMark } });
        mapLookKey = ""; mapLook();
        if (g && mapPrev) { G.REGIONS.forEach(function (n) { paintRegion(n, mapPrev[n]); }); m3d.setTurn(g.over ? null : g.turn); m3d.setPicking(picking); }
      } catch (e) { fall(e); }
    }).catch(fall);
  }
  function ownersNow() {
    var o = {};
    G.REGIONS.forEach(function (n) { o[n] = "open"; });
    (g.regionDiscard || []).forEach(function (n) { if (typeof n === "string") o[n] = "gone"; });
    g.players.forEach(function (p, i) { p.regions.forEach(function (n) { o[n] = i; }); });
    return o;
  }
  function paintRegion(n, is) {
    var p = ML.region[n], pin = ML.pin[n];
    if (!p) return;
    var own = typeof is === "number", pl = own && g ? g.players[is] : null;
    var cls = "mp-r " + (own ? "own o" + is : is) + (pl && pl.shield > 0 ? " shielded" : "") + (pl && pl.skip ? " skipping" : "") +
      (own && is > 0 && picking && !(pl && pl.shield > 0) ? " pickable" : "");
    //MC 2026-10-11 render() repaints all 40 Regions every time; only touch the ones that changed (each write sent the
    //   map back to style and paint)
    var fill = own ? COLORS[is] : "", pcl = "mp-pin" + (own ? " on" : "");
    if (p.getAttribute("class") !== cls) p.setAttribute("class", cls);
    if (p.__fill !== fill) { p.style.fill = fill; p.__fill = fill; }
    if (pin.getAttribute("class") !== pcl) pin.setAttribute("class", pcl);
    if (pin.__fill !== fill) { pin.querySelector(".mp-pin-dot").style.fill = fill; pin.__fill = fill; }
    //MC 2026-10-14 the 3D table gets the same state: owner, shield, skip and whether it can be picked right now
    if (m3d) m3d.paint(n, is, fill, { shield: !!(pl && pl.shield > 0), skip: !!(pl && pl.skip), pickable: own && is > 0 && picking && !(pl && pl.shield > 0) });
  }
  var picking = false;
  function mapSync() {
    if (!MAP || !mapSvg || !g) return;
    picking = !$("g-targets").hidden;
    mapSvg.classList.toggle("picking", picking);
    var now = ownersNow(), first = !mapPrev, changes = [];
    G.REGIONS.forEach(function (n) {
      var was = mapPrev ? mapPrev[n] : "open", is = now[n];
      if (!first && was !== is) changes.push({ n: n, was: was, is: is });
      else paintRegion(n, is);
    });
    var before = mapPrev;
    mapPrev = now;
    var dt = g.over ? "" : String(g.turn);
    if (mapSvg.getAttribute("data-turn") !== dt) mapSvg.setAttribute("data-turn", dt);
    if (m3d) { m3d.setTurn(g.over ? null : g.turn); m3d.setPicking(picking); }   //MC 2026-10-14 the 3D table breathes and picks too
    if (first) { introPins(now); return; }
    if (reduce) { changes.forEach(function (c) { paintRegion(c.n, c.is); }); return; }
    var big = false;
    changes.forEach(function (c, k) {
      if (c.is === "gone" || (typeof c.was === "number" && typeof c.is === "number")) big = true;
      setTimeout(function () { animateChange(c, before); }, k * 160);
    });
    if (big) setTimeout(shake, 120);
  }
  function introPins(now) {
    if (reduce) return;
    var k = 0;
    G.REGIONS.forEach(function (n) {
      if (typeof now[n] !== "number") return;
      var inner = ML.pin[n].firstChild;
      inner.animate([{ transform: "translateY(-40px) scale(.4)", opacity: 0 }, { transform: "none", opacity: 1 }],
        { duration: 520, delay: 200 + k++ * 70, easing: "cubic-bezier(.2,1.6,.4,1)", fill: "backwards" });
    });
  }
  function centroid(n) { var r = MAP.regions[n]; return r ? r.c : [MAP.w / 2, MAP.h / 2]; }
  // where an attack or steal comes from: the attacker's nearest Region, or their side of the table
  function sourceFor(owner, target, owners) {
    var t = centroid(target), best = null, bd = 1e9;
    Object.keys(owners || {}).forEach(function (n) {
      if (owners[n] !== owner || n === target) return;
      var c = centroid(n), d = (c[0] - t[0]) * (c[0] - t[0]) + (c[1] - t[1]) * (c[1] - t[1]);
      if (d < bd) { bd = d; best = c; }
    });
    return best || [owner === 0 ? MAP.w / 2 : MAP.w * owner / 4, owner === 0 ? MAP.h + 30 : -30];
  }
  function animateChange(c, before) {
    var xy = centroid(c.n), own = typeof c.is === "number";
    if (own && c.was === "open") {               // claimed from the deck
      paintRegion(c.n, c.is); fillFlash(c.n); ripple(xy, COLORS[c.is]); pinDrop(c.n);
    } else if (own && typeof c.was === "number") { // stolen
      beam(sourceFor(c.is, c.n, before), xy, COLORS[c.is], function () {
        paintRegion(c.n, c.is); fillFlash(c.n); ripple(xy, COLORS[c.is]); pinDrop(c.n);
      });
    } else if (own && c.was === "gone") {        // rebuilt from the ruins
      paintRegion(c.n, c.is); fillFlash(c.n); ripple(xy, "#2ef0b0"); sparkle(xy); pinDrop(c.n);
    } else if (c.is === "gone") {                // destroyed
      explode(xy); setTimeout(function () { paintRegion(c.n, "gone"); }, 140);
    } else paintRegion(c.n, c.is);
  }
  function fx(tag, attrs) { return sv(tag, attrs, ML.fx); }
  function ripple(xy, color) {
    var c = fx("circle", { cx: xy[0], cy: xy[1], r: 42, fill: "none", stroke: color, "stroke-width": 5, class: "mp-fxo" });
    c.animate([{ transform: "scale(.15)", opacity: 1 }, { transform: "scale(1.5)", opacity: 0 }], { duration: 750, easing: "cubic-bezier(.2,.8,.3,1)" }).onfinish = function () { c.remove(); };
  }
  function fillFlash(n) {
    var p = ML.region[n];
    p.animate([{ filter: "brightness(2.2) saturate(1.4)" }, { filter: "none" }], { duration: 650, easing: "ease-out" });
  }
  function pinDrop(n) {
    var inner = ML.pin[n] && ML.pin[n].firstChild; if (!inner) return;
    inner.animate([{ transform: "translateY(-46px) scale(.5)", opacity: 0 }, { transform: "translateY(4px) scale(1.1)", opacity: 1, offset: .7 }, { transform: "none", opacity: 1 }],
      { duration: 560, easing: "cubic-bezier(.3,1.2,.5,1)" });
  }
  function beam(a, b, color, done) {
    var mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2 - Math.max(40, Math.hypot(b[0] - a[0], b[1] - a[1]) * 0.35);
    var p = fx("path", { d: "M" + a[0] + " " + a[1] + " Q" + mx + " " + my + " " + b[0] + " " + b[1], fill: "none", stroke: color, "stroke-width": 5, "stroke-linecap": "round", filter: "url(#mp-glow)" });
    var len = p.getTotalLength();
    p.style.strokeDasharray = len; p.style.strokeDashoffset = len;
    p.animate([{ strokeDashoffset: len }, { strokeDashoffset: 0 }], { duration: 480, easing: "cubic-bezier(.5,0,.3,1)", fill: "forwards" }).onfinish = function () {
      if (done) done();
      p.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 380, fill: "forwards" }).onfinish = function () { p.remove(); };
    };
  }
  function explode(xy) {
    var flash = fx("circle", { cx: xy[0], cy: xy[1], r: 46, fill: "url(#mp-flash)", class: "mp-fxo" });
    flash.animate([{ transform: "scale(.2)", opacity: 1 }, { transform: "scale(1.3)", opacity: .9, offset: .3 }, { transform: "scale(1.7)", opacity: 0 }], { duration: 700, easing: "ease-out" }).onfinish = function () { flash.remove(); };
    var ring = fx("circle", { cx: xy[0], cy: xy[1], r: 50, fill: "none", stroke: "#ff5d73", "stroke-width": 4, class: "mp-fxo" });
    ring.animate([{ transform: "scale(.2)", opacity: 1 }, { transform: "scale(1.8)", opacity: 0 }], { duration: 800, easing: "cubic-bezier(.2,.8,.3,1)" }).onfinish = function () { ring.remove(); };
    for (var i = 0; i < 10; i++) {
      var ang = Math.PI * 2 * i / 10 + Math.random() * 0.5, dist = 30 + Math.random() * 40;
      var d = fx("circle", { cx: xy[0], cy: xy[1], r: 2.5 + Math.random() * 3, fill: i % 2 ? "#ffd166" : "#ff8a5c" });
      d.animate([{ transform: "translate(0,0)", opacity: 1 }, { transform: "translate(" + Math.cos(ang) * dist + "px," + Math.sin(ang) * dist + "px)", opacity: 0 }],
        { duration: 600 + Math.random() * 300, easing: "cubic-bezier(.1,.8,.3,1)" }).onfinish = (function (el) { return function () { el.remove(); }; })(d);
    }
  }
  function sparkle(xy) {
    for (var i = 0; i < 8; i++) {
      var s2 = fx("circle", { cx: xy[0] + (Math.random() - .5) * 40, cy: xy[1] + (Math.random() - .5) * 30, r: 2.5, fill: "#bfffe9" });
      s2.animate([{ opacity: 0, transform: "translateY(6px)" }, { opacity: 1, offset: .4 }, { opacity: 0, transform: "translateY(-14px)" }],
        { duration: 800, delay: i * 60, easing: "ease-out", fill: "backwards" }).onfinish = (function (el) { return function () { el.remove(); }; })(s2);
    }
  }
  function shake() {
    var b = $("g-board");
    b.animate([{ transform: "translate(0,0)" }, { transform: "translate(-5px,2px)" }, { transform: "translate(4px,-3px)" }, { transform: "translate(-3px,1px)" }, { transform: "translate(0,0)" }], { duration: 320, easing: "ease-out" });
  }
  // hover a rival (or a target in the picker) to light up their land
  function mapHighlight(rel) { if (mapSvg) { if (rel == null) mapSvg.removeAttribute("data-hl"); else mapSvg.setAttribute("data-hl", String(rel)); } if (m3d) m3d.setHl(rel == null ? null : rel); }
  $("g-rivals").addEventListener("pointerover", function (e) { var r = e.target.closest(".g-rival"); mapHighlight(r ? parseInt(r.id.replace("g-riv-", ""), 10) : null); });
  $("g-rivals").addEventListener("pointerleave", function () { mapHighlight(null); });
  var hlTimer = null;
  $("g-rivals").addEventListener("pointerdown", function (e) {
    if (e.pointerType === "mouse") return;
    var r = e.target.closest(".g-rival"); if (!r) return;
    mapHighlight(parseInt(r.id.replace("g-riv-", ""), 10));
    clearTimeout(hlTimer); hlTimer = setTimeout(function () { mapHighlight(null); }, 1600);
  });
  $("g-targets").addEventListener("pointerover", function (e) { var t = e.target.closest(".g-tgt"); mapHighlight(t ? parseInt(t.dataset.t, 10) : null); });
  $("g-targets").addEventListener("pointerleave", function () { mapHighlight(null); });

  // the final world, shown on the end screen
  function endMap() {
    var box = $("g-end-map");
    if (!box) return;
    box.innerHTML = "";
    if (!mapSvg) { box.hidden = true; return; }
    //MC 2026-10-17 the table map paints each change a moment after the last one (160ms apart, a steal after its beam
    //   lands), and this copy was taken in the same instant the final result came in. Whatever changed in the last update
    //   wasn't painted yet, so the Final World could miss Regions: a player beat the Shogun 10 to 10 on cards and the end
    //   map showed the Shogun with 6. Every Region is painted to the final owners first, then the map is copied.
    if (g) { var fin = ownersNow(); G.REGIONS.forEach(function (n) { paintRegion(n, fin[n]); }); }
    var c = mapSvg.cloneNode(true);
    c.removeAttribute("data-turn"); c.removeAttribute("data-hl"); c.classList.remove("picking");
    var fxl = c.querySelector(".mp-fx"); if (fxl) fxl.innerHTML = "";
    c.querySelectorAll("defs").forEach(function (d) { d.remove(); });
    box.appendChild(c);
    box.hidden = false;
  }
  // under the result: a mint nudge for Unbound players, a career line for holders
  function shadowNote() {
    var el = $("g-shadow-note"); if (!el) return;
    var a = myAvatar();
    //MC 2026-10-09 the line sits in its own span so it gets translated (with the tick in front it never matched).
    //Players without a Shadow get the card below instead of a line here.
    el.innerHTML = a ? '<span class="g-ver">\u2713</span> <span>Added to <b>Shadow #' + esc(a) + '</b>\'s career record. It stays with this Shadow forever.</span>' : "";
  }
  //MC 2026-10-09 the results screen: the winner's Shadow in a victory pose, or yours dimmed when someone without one
  //won. A player without a Shadow gets a card to try one in the next game or mint one; after a trial game the card
  //names the Shadow they just played as, and the trial ends there.
  function shadowEnd(wi) {
    //MC 2026-10-09 "Leave this game?" left open when the game ended sat on top of the results; it goes with the game
    var qd = $("g-quit"); if (qd) qd.hidden = true;
    var pose = $("g-pose"), cta = $("g-shcta"), watching = !!(live && live.watch);
    var big = matchMedia("(min-width:700px)").matches ? "190px" : "clamp(130px,40vw,160px)";
    var at = avatars[wi] && avatars[wi].n ? wi : (!watching && avatars[0] && avatars[0].n ? 0 : -1);
    if (pose) {
      if (at >= 0 && window.ShyLiving) {
        var a = avatars[at], win = at === wi;
        pose.className = "g-pose au-" + (a.au || "none");
        pose.innerHTML = living(at, (win ? "win" : "lose") + " enter", win ? big : "110px") + '<span class="gp-k">Shadow #' + esc(a.n) + (a.trial ? " · Trying it" : "") + '</span>';
        pose.hidden = false;
      } else { pose.hidden = true; pose.innerHTML = ""; }
    }
    if (!cta) return;
    var tried = avatars[0] && avatars[0].trial ? avatars[0] : null;
    if (watching || myAvatar() || !SHADOWS.length) { cta.hidden = true; cta.innerHTML = ""; }
    else {
      var pic = tried ? { src: tried.src, n: tried.n } : SHADOWS[Math.floor(Math.random() * SHADOWS.length)];
      cta.className = "g-shcta au-none";
      cta.innerHTML = (window.ShyLiving ? ShyLiving.html(pic.src, { alt: "Shadow #" + pic.n }) : "") + '<div>' +
        (tried ? '<b>You played as Shadow #' + esc(tried.n) + '</b><p>Like it? Mint your own Shytoshi Shadow and play as it everywhere, live matches included, with its Aura on every win and a career record that stays with it.</p>'
          : '<b>Play as a Shytoshi Shadow</b><p>Holders play as their Shadow in every game, and everyone at the table sees it. Try one free in your next game.</p>') +
        '<div class="gs-btns"><a class="btn btn-red" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint a Shadow</a><button class="btn btn-line" data-try-go>' + (tried ? "Try another" : "Try one free") + '</button></div></div>';
      cta.hidden = false;
    }
    if (tried) setTrial(null);
  }
  root.addEventListener("click", function (e) {
    if (!e.target.closest("[data-try-go]")) return;
    tryRandom(); sfx("select");
    var b = document.querySelector('[data-game-start="quick"]'); if (b) b.click();
  });
  // ---------- coach tips for the first game ----------
  var COACH = [
    "These are your cards. The gold glow is the best move. Tap a card to pick it, tap it again to play it. Or skip playing and press Claim a Region to grow instead.",
    "The map shows who controls the world. Your land has a white outline, striped land is unclaimed, dark land is destroyed. Tap any Region to see its name.",
    "When the unclaimed Regions run out, the most Regions wins. Rivals can't hit you while you're in a Bunker, and a Failed Coup blocks one attack by itself."
  ];
  var coachStep = parseInt(store("shy-coach") || "0", 10);
  function coach() {
    var box = $("g-coach");
    if (coachStep >= COACH.length || !g || g.turn !== 0 || busy || isLive()) { box.hidden = true; return; }
    var text = COACH[coachStep];
    if (coachStep === 0 && !hintsOn()) text = text.replace(" The gold glow is the best move.", "");
    $("g-coach-text").textContent = text;
    box.hidden = false;
  }
  $("g-coach-ok").addEventListener("click", function () {
    coachStep++; store("shy-coach", String(coachStep)); coach();
  });

  // ---------- turns ----------
  //MC 2026-10-11 every step of a game's turn loop now carries the game it belongs to (my) and stops as soon as another
  //   game has replaced it. Starting the Daily or a live match from Missions during a rival's turn left the old loop
  //   running against the new game: turns skipped (startTurn twice in a row), plays made out of turn, a score that no
  //   longer verified, and a TypeError when the new game was live (g = null). The old loop read the global g after every
  //   await. A page reload like "Leave and join now" was the other option; this keeps the new game instant.
  function sheetOff() { var t = $("g-targets"); if (t && !t.hidden) { t.hidden = true; mapSync(); } }
  async function nextTurn(my) {
    if (!my || my !== g || my.stopped) return;
    if (g.over) return finish();
    if (g.round !== track.lastRound) {
      track.lastRound = g.round;
      roundSnapshot();
    }
    if (!g.endgame && g.regionDeck.length <= g.players.length * 2 && g.regionDeck.length > g.players.length) { g.endgame = true; await banner("Endgame: " + g.regionDeck.length + " Regions left", "final"); if (g !== my) return; }
    if (!g.finalRound && g.regionDeck.length && g.regionDeck.length <= g.players.length) { g.finalRound = g.endgame = true; await banner(g.regionDeck.length === 1 ? "Last Region" : "Last " + g.regionDeck.length + " Regions", "final"); if (g !== my) return; }
    var handBefore = g.players[g.turn].hand.length, logAt = g.log.length;
    var r = G.startTurn(g);
    busy = g.players[g.turn].bot || r.skipped;
    sel = -1; newCard = -1;
    sheetOff();   //MC 2026-10-11 a target sheet still up from the last turn goes with it
    if (g.turn === 0 && !r.skipped && g.players[0].hand.length > handBefore) { newCard = g.players[0].hand.length - 1; drawAnim = true; }
    render();
    if (r.skipped) { sfx("skip"); await wait(900); if (g !== my) return; G.endTurn(g); return nextTurn(my); }
    if (g.players[g.turn].bot) {
      await wait(650);
      if (g !== my) return;
      var bi = g.turn, guard = 0;
      // same loop as G.botTurn, with a card flash for every play
      while (g.plays > 0 && !g.over && guard++ < 8) {
        var ch = G.botChoose(g, bi);
        if (!ch) break;
        var id = g.players[bi].hand[ch.hand];
        await flash(bi, id);
        if (g !== my) return;
        logAt = g.log.length;
        var cb = g.players.map(function (x) { return x.regions.length; });
        G.play(g, bi, ch.hand, ch.target);
        botVoice(bi, cb);   //MC 2026-10-11 a short line from the bot now and then after a big play (before render(), so it wins over a hit rival's face)
        sfxFor(logAt);
        render();
        if (g.plays > 0 && !g.over) { await wait(500); if (g !== my) return; }
      }
      render();
      await wait(700);
      if (g !== my) return;
      G.endTurn(g);
      return nextTurn(my);
    }
    // a Daily replay plays the recorded moves itself
    if (g.replay) return replayTurn(my);
    // your turn
    ff = false;
    busy = false;
    sfx("turn"); buzz(10);
    if (newCard >= 0) setTimeout(function () { sfx("draw"); }, 260);
    render();
    if (hintsOn() && tip && !tip.pass) scrollToCard(tip.hand); else if (newCard >= 0) scrollToCard(newCard);
    coach();
  }
  function roundSnapshot() {
    var mine = g.players[0].regions.length;
    track.rounds.push(mine);
    var s = G.standings(g), last = s[s.length - 1].regions;
    if (g.round >= 5 && mine === last && s.filter(function (x) { return x.regions === last; }).length === 1) track.wasLast = true;
  }

  async function doPlay(target) {
    var human = g.players[0];
    if (sel < 0 || sel >= human.hand.length) return;
    if (isLive()) { var lid = g && g.players[0].hand[sel]; if (G.CARDS[lid] && G.CARDS[lid].kind === "attack" && Date.now() - selAt > 900) { document.body.classList.add("pw-burst"); setTimeout(function () { document.body.classList.remove("pw-burst"); }, 1000); } return liveAct({ hand: sel, target: target == null ? null : liveAbs(target) }); }
    if (busy || g.turn !== 0 || g.over) return;   //MC 2026-10-11 a target tap that lands after the turn ended (stale sheet) does nothing
    var my = g;
    busy = true;
    $("g-targets").hidden = true;
    $("g-coach").hidden = true;
    var id = human.hand[sel], before = human.regions.length;
    //MC 2026-10-13 a held attack lands harder: pick an attack card, let it charge for a second, and the play flashes the
    //   screen. Looks only, the cards never change. The aura while waiting is pure CSS on .gc.sel.k-attack.
    if (G.CARDS[id] && G.CARDS[id].kind === "attack" && Date.now() - selAt > 900) { document.body.classList.add("pw-burst"); setTimeout(function () { document.body.classList.remove("pw-burst"); }, 1000); }
    track.played[id] = 1;
    track.moves.push({ h: sel, t: target == null ? null : target });
    dailyBegun();
    render();
    await flash(0, id);
    if (g !== my) return;
    var logAt = g.log.length;
    G.play(g, 0, sel, target);
    sel = -1; newCard = -1;
    sfxFor(logAt);
    buzz(human.regions.length > before ? [12, 40, 12] : 15);
    render();
    if (coachStep === 0) { coachStep = 1; store("shy-coach", "1"); }
    if (G.morePlays(g, 0)) {
      // Double Disaster, Blitz Tactics: the turn keeps going until you end it or run out of plays
      busy = false;
      render();
      toast("<b>Play again</b> " + g.plays + (g.plays > 1 ? " more cards" : " more card") + " this turn, or end your turn.");
      return;
    }
    await wait(550);
    if (g !== my) return;
    G.endTurn(g);
    nextTurn(my);
  }

  function tryPlay() {
    if (!g) return;
    if (busy && !g.over) { if (!isLive()) { ff = true; render(); } return; } // skip ahead during rival turns
    if (sel < 0) return;
    var id = g.players[0].hand[sel];
    if (!G.canPlay(id)) return;
    if (G.CARDS[id].target === "pick") askTarget(); else doPlay(null);
  }
  //MC 2026-10-13 the training arc: three straight defeats, then a win, and the end screen says so and celebrates harder.
  //   The run is counted in this browser only, so it never touches the server.
  function eggEnd(result) {
    var n = 0; try { n = +localStorage.getItem("shy-lossrun") || 0; } catch (e) {}
    if (result === "win") {
      if (n >= 3) {
        setTimeout(function () { try { fxRun("confetti"); } catch (e) {} }, 1100);
        var se = $("g-end-sub");
        if (se) se.innerHTML += ' <span class="egg-back">Three defeats, then this. You came back stronger.</span>';
      }
      n = 0;
    } else if (result === "loss") n = n + 1;
    try { localStorage.setItem("shy-lossrun", String(n)); } catch (e) {}
  }
  function pass() {
    if (!g || busy || g.over || g.turn !== 0) return;
    if (isLive()) return liveAct({ pass: true });
    busy = true; sel = -1; newCard = -1;
    track.moves.push({ h: -1 });
    dailyBegun();
    if (g.played || !g.regionDeck.length) g.log.push({ who: 0, text: "You end your turn.", kind: "info" });
    $("g-coach").hidden = true;
    //MC 2026-10-11 Claim with the target sheet open left the sheet up through the rivals' turns and into the next one,
    //   with old Region counts and taps that did nothing (sel was -1). Any action closes it now.
    $("g-targets").hidden = true;
    var logAt = g.log.length;
    G.endTurn(g);
    sfxFor(logAt);
    render();
    var my = g;
    setTimeout(function () { nextTurn(my); }, 450);
  }
  function selectCard(i) {
    if (!g) return;
    var human = g.players[0];
    if (busy || g.over || g.turn !== 0 || i < 0 || i >= human.hand.length) return;
    if (sel === i) { tryPlay(); return; }
    sheetOff();   //MC 2026-10-11 picking another card closes a sheet opened for the last one (a target tap would have played the new card)
    sel = i; selAt = Date.now();
    sfx("select"); buzz(8);
    render();
    scrollToCard(i);
  }

  function askTarget() {
    var sheet = $("g-targets");
    $("g-coach").hidden = true;
    var bestT = tip && !tip.pass && tip.hand === sel ? tip.target : -1;
    sheet.querySelector(".g-tgt-list").innerHTML = g.players.map(function (p, i) {
      if (i === 0) return "";
      var blocked = p.shield > 0;
      return '<button class="g-tgt' + (i === bestT ? " tip" : "") + '" data-t="' + i + '"' + (blocked ? " disabled" : "") + '><span class="g-tgt-key">' + i + '</span>' + avHTML(i) +
        '<b>' + esc(p.name) + (i === bestT ? ' <i>Best target</i>' : "") + '</b><span>' + (blocked ? "In a bunker" : p.regions.length + (p.regions.length === 1 ? " Region" : " Regions")) + '</span></button>';
    }).join("");
    sheet.hidden = false;
    mapSync();
  }

  // ---------- end of game ----------
  //MC 2026-10-23 the last play used to cut straight to the results: the final card, the Regions it moved and the closing
  //   count all went by under the end screen. Now the final board holds for a moment under a Game over banner, so the
  //   last play lands where everyone can see it. A tap on the table skips the wait.
  function endHold(ms) {
    return new Promise(function (res) {
      var b = $("g-banner"), done = false, t = 0;
      function go() { if (done) return; done = true; clearTimeout(t); root.removeEventListener("pointerdown", go, true); if (b) b.hidden = true; res(); }
      if (b) { b.className = "g-banner final"; b.textContent = "Game over"; b.hidden = false; }
      sfx("tick");
      t = setTimeout(go, ms || 2200);
      setTimeout(function () { if (!done) root.addEventListener("pointerdown", go, true); }, 350);
    });
  }
  async function finish() {
    var my = g;
    if (!my.endHeld) { my.endHeld = true; busy = true; sel = -1; $("g-targets").hidden = true; render(); await endHold(ff ? 900 : 2200); if (g !== my) return; }
    if (g.replay) return replayEnd();   // a Daily replay holds its last play too
    finishNow();
  }
  function finishNow() {
    $("g-targets").hidden = true;
    [].forEach.call(root.querySelectorAll(".g-taunt,.g-ouch"), function (e) { e.remove(); });   //MC 2026-10-11 a bot's last line doesn't sit on the results
    render();
    roundSnapshot();
    var s = G.standings(g), w = G.winners(g), won = w.indexOf(0) >= 0;
    var result = won ? (w.length > 1 ? "tie" : "win") : "loss";
    var mine = g.players[0].regions.length;
    var others = s.filter(function (x) { return x.i !== 0; }).map(function (x) { return x.regions; });
    var margin = mine - Math.max.apply(null, others);
    var mode = isDaily() ? "daily" : isDuel() ? "normal" : me.mode;
    var hints = !isDaily() && !isDuel() && me.hints;

    // stats
    stats.games++;
    if (result === "win") { stats.wins++; stats.streak++; } else stats.streak = 0;
    stats.bestStreak = Math.max(stats.bestStreak, stats.streak);
    stats.best = Math.max(stats.best, mine);
    Object.keys(track.played).forEach(function (id) { stats.cards[id] = 1; });
    if (isDaily()) {
      stats.dailies++;
      if (!stats.daily[g.dayKey]) stats.daily[g.dayKey] = { regions: mine, result: result, grid: shareGrid() };
    }
    // badges
    var earned = [];
    function award(id, ok) { if (ok && !stats.badges[id]) { stats.badges[id] = Date.now(); earned.push(id); } }
    award("initiated", true);
    award("leader", result === "win");
    award("normal", result === "win" && mode !== "easy" && !hints);
    award("daily", isDaily());
    award("chosen", isDaily() && result === "win");
    award("empire", mine >= 10);
    award("shadowempire", mine >= 13);
    award("untouchable", track.blocks >= 2);
    award("comeback", result === "win" && track.wasLast);
    award("flawless", result === "win" && !track.lost);
    award("landslide", result === "win" && margin >= 5);
    award("onfire", stats.streak >= 3);
    award("collector", Object.keys(stats.cards).length >= 12);
    award("regular", stats.games >= 25);
    saveStats();
    renderProfile();

    $("g-end-k").textContent = isDaily() ? "Daily Challenge #" + g.dailyNo : isDuel() ? "Duel vs " + g.duel.vs : "Game over";
    setTimeout(function () { eggEnd(result); }, 0);   //MC 2026-10-13 after the sub line below is in place
    $("g-end-title").textContent = won ? (w.length > 1 ? "You share the world." : "You rule the world.") : g.players[w[0]].name + " rules the world.";
    //MC 2026-10-09 each sentence in its own span so the translations find them. Joined into one string, the whole line
    //never matched a translation and stayed in English (a Turkish player's end screen showed it).
    $("g-end-sub").innerHTML = [endReason(g.regionDeck.length, s[0].regions, s[0].i === 0 ? "You" : s[0].name), tieNote(s).trim(),
      (won ? "The chaos bent to your will." : margin === 0 ? "So close." : (margin >= -1 ? "So close. One more round would have done it." : "The chaos had other plans. Run it back?"))]
      .filter(Boolean).map(function (t) { return "<span>" + esc(t) + "</span>"; }).join(" ");
    $("g-end-list").innerHTML = s.map(function (x, k) {
      return '<li' + (x.i === 0 ? ' class="me"' : "") + '><span>' + (k + 1) + '</span>' + avHTML(x.i, "sm") + '<b>' + esc(x.i === 0 ? (me.name || "You") : x.name) + '</b><em>' + x.regions + (x.regions === 1 ? ' Region' : ' Regions') + (tied(s, x) ? ' <small>' + x.hand + ' cards</small>' : '') + '</em></li>';
    }).join("");

    var base = mine * 5, bonus = result === "win" ? 100 : result === "tie" ? 50 : 0, pts = base + bonus, notes = [];
    if (mode === "easy") { pts = Math.floor(pts / 2); notes.push("Easy halves it"); }
    if (hints) { pts = Math.floor(pts / 2); notes.push("hints halve it"); }
    $("g-breakdown").innerHTML = '<span>' + mine + (mine === 1 ? ' Region' : ' Regions') + ' x 5 = ' + base + '</span>' + (bonus ? '<span>' + (result === "win" ? "Win" : "Tie") + ' +' + bonus + '</span>' : "") +
      (notes.length ? '<span class="cut">' + notes.join(", ") + '</span>' : "") + '<b>+' + pts + ' points</b>';
    // a Daily replay scores nothing, so don't show points it won't get
    if (g.practice) $("g-breakdown").innerHTML = '<span>' + mine + (mine === 1 ? ' Region' : ' Regions') + '</span><b>Practice run, no points</b>';
    $("g-unlocks").innerHTML = earned.map(function (id) {
      var b = BADGES.filter(function (x) { return x.id === id; })[0];
      return '<span class="g-unlock"><i>' + b.icon + '</i>' + esc(b.name) + '</span>';
    }).join("");
    $("g-record").textContent = stats.wins + " " + (stats.wins === 1 ? "win" : "wins") + " in " + stats.games + " " + (stats.games === 1 ? "game" : "games") +
      (stats.streak > 1 ? ", " + stats.streak + " in a row" : "") + ". " + badgeCount() + "/" + BADGES.length + " badges.";

    shareSetup({ kind: isDaily() ? "daily" : "solo", result: result, regions: mine, mode: mode, dailyNo: g.dailyNo || 0, humans: 1,
      standings: s.map(function (x) { return { n: x.i === 0 ? (me.name || "You") : x.name, r: x.regions, c: x.i, me: x.i === 0 }; }) },
      shareText(result, mine));
    $("g-again").textContent = isDaily() || isDuel() ? "Quick game" : "Play again";
    var afs = $("g-addfr"); if (afs) afs.hidden = true;
    var da = $("g-duel-again"); if (da) { da.hidden = !isDuel(); if (isDuel()) da.dataset.duelvs = g.duel.vsId; }
    $("g-rematch").hidden = true;
    $("g-end-daily").hidden = isDaily() || !!stats.daily[dayKey()];
    endMap(); shadowNote(); shadowEnd(s[0].i); bountyEnd(mine, result !== "loss");
    $("g-end").hidden = false;
    $("g-end").scrollTop = 0;
    if (won) { victory(); sfx("win"); buzz([20, 60, 20, 60, 40]); } else sfx("lose");
    spEnd(won, s[0].i);
    if (earned.length) setTimeout(function () { sfx("badge"); }, 700);

    pendingResult = { regions: mine, result: result, mode: mode, hints: hints, daily: isDaily(), moves: track.moves.slice() };
    submitted = false;
    if (!token) { setLbMsg("Leaderboard is offline right now. Your game still counts on this device."); $("g-save").hidden = true; return; }
    if (g.practice) { setLbMsg("Daily replays are practice. Your first run today is the one on the board."); $("g-save").hidden = true; return; }
    if (me.name) { $("g-save").hidden = true; submit(); }
    else { $("g-save").hidden = false; setLbMsg("Add a name to put this score on the leaderboard."); }
  }
  function shareGrid() {
    var r = track.rounds, out = "";
    for (var i = 1; i < r.length; i++) out += r[i] > r[i - 1] ? "\u{1F7E9}" : r[i] < r[i - 1] ? "\u{1F7E5}" : "\u{1F7E8}";
    return out;
  }
  // The post players share on X: what happened in their game in plain words, no emoji grid.
  //MC 2026-10-11 the place counted Regions only, so losing a Regions tie on cards said "Finished 2nd" under a list that
  //   showed 3rd. Rows now carry the cards in hand (h) and are placed like the game's standings: Regions, then cards.
  //   Only an exact tie on both shares a place.
  function resultPost(o) {
    var rows = o.standings.slice().sort(function (x, y) { return (y.r - x.r) || ((y.h || 0) - (x.h || 0)); });
    var mineRow = rows.filter(function (x) { return x.me; })[0] || { r: o.mine, h: 0 };
    //MC 2026-10-12 a boss match gets its own words. The live wording called the Shogun "Runner-up" in a 1v1, which read
    //   like a lobby of strangers ("Won a live Shilluminati match... Runner-up The Shogun had 10"), spotted on a real post.
    if (o.boss) {
      var sr = (rows.filter(function (x) { return !x.me; })[0] || { r: 0 }).r;
      var bh = o.result === "win" ? "I beat the Shogun in Shilluminati Online, " + o.mine + " Regions to " + sr + "."
        : o.result === "tie" ? "Fought the Shogun to a draw in Shilluminati Online, " + o.mine + " to " + sr + "."
        : "The Shogun held the world, " + sr + " Regions to my " + o.mine + ".";
      var bf = [];
      if (o.result === "win") bf.push("The hardest bot in the game. It plays every move out to the end before it chooses.");
      if (o.blocks > 0) bf.push("Blocked " + o.blocks + (o.blocks === 1 ? " attack." : " attacks."));
      if (o.result !== "win" && o.rounds) bf.push("It took " + o.rounds + " rounds to put me down.");
      var bw = myAvatar() ? "Playing as Shadow #" + myAvatar() + ". " : "";
      return bh + "\n" + bf.slice(0, 2).join(" ") + "\n\n" + bw + (o.result === "win" ? "Think you can do it too?" : "Think you can do better?") + " Play free with @ShyOnSol_ $SHY";
    }
    var place = 1 + rows.filter(function (x) { return !x.me && (x.r > mineRow.r || (x.r === mineRow.r && (x.h || 0) > (mineRow.h || 0))); }).length;
    var field = rows.length, ord = ["", "1st", "2nd", "3rd", "4th", "5th", "6th"][place] || place + "th";
    var where = o.kind === "daily" ? "today's Shilluminati Daily (#" + o.dailyNo + ")" : o.kind === "live" ? "a live Shilluminati match" : "Shilluminati Online";
    var vs = o.kind === "live" && o.humans > 1 ? " against " + (o.humans - 1) + " other " + (o.humans === 2 ? "player" : "players") : "";
    var head;
    if (o.result === "win") head = (o.kind === "daily" ? "Won " + where : o.kind === "live" ? "Won " + where + vs : "I ruled the world in Shilluminati Online") + " with " + o.mine + " of 40 Regions.";
    else if (o.result === "tie") head = "Tied for the world in " + where + vs + " with " + o.mine + (o.mine === 1 ? " Region." : " Regions.");
    else head = "Finished " + ord + " of " + field + " in " + where + vs + " with " + o.mine + (o.mine === 1 ? " Region." : " Regions.");
    var facts = [];
    var top = rows.filter(function (x) { return !x.me; })[0];
    if (o.comeback && o.result === "win") facts.push("Came back from last place.");
    if (top && o.result === "loss") facts.push(top.n + " took the world with " + top.r + ".");
    else if (top && o.result === "win") facts.push("Runner-up " + top.n + " had " + top.r + ".");
    if (o.blocks > 0) facts.push("Blocked " + o.blocks + (o.blocks === 1 ? " attack." : " attacks."));
    if (o.rounds) facts.push("Over in " + o.rounds + " rounds.");
    if (o.cards > 5 && facts.length < 2) facts.push("Played " + o.cards + " different Chaos cards.");
    var who = myAvatar() ? "Playing as Shadow #" + myAvatar() + ". " : "";
    var tail = o.result === "win" ? "Think you can beat it?" : "Rematch incoming.";
    return head + "\n" + facts.slice(0, 2).join(" ") + "\n\n" + who + tail + " Play free with @ShyOnSol_ $SHY";
  }
  function shareText(result, mine) {
    return resultPost({ kind: isDaily() ? "daily" : "solo", result: result, mine: mine, dailyNo: g.dailyNo || 0, humans: 1, rounds: g.round,
      blocks: track.blocks, comeback: track.wasLast, cards: Object.keys(track.played).length,
      standings: G.standings(g).map(function (x) { return { n: x.i === 0 ? (me.name || "You") : x.name, r: x.regions, h: x.hand, me: x.i === 0 }; }) });
  }

  // ---------- share cards ----------
  // When a game ends we ask the server for a short link with a drawn result card. X shows the card under the post.
  var SHARE_API = "api/share.php", shareState = null, xUser = null, xEnabled = false, xPost = false, xAuto = false, xTags = "", xKol = "", xAlways = "";
  if (window.ShyX) ShyX.status().then(function (j) {
    xEnabled = !!(j && j.enabled); xUser = j && j.linked ? j.user : null; xPost = !!(j && j.post && !j.paused);
    xAuto = !!(j && j.auto && j.autoOn); xTags = (j && j.tags) || ""; xKol = (j && j.kol) || ""; xAlways = (j && j.always) || "";   //MC 2026-10-11 automatic win posts and the admin's tags
    var b = $("g-share"); if (b && shareState) b.textContent = xUser && xPost ? "Post to X" : "Share on X";
  });
  function ownersCode() {
    var now = ownersNow();
    return G.REGIONS.map(function (n) { var o = now[n]; return typeof o === "number" ? String(o) : o === "gone" ? "g" : "o"; }).join("");
  }
  function roundsCode() {
    var r = track.rounds, out = "";
    for (var i = 1; i < r.length && out.length < 12; i++) out += r[i] > r[i - 1] ? "u" : r[i] < r[i - 1] ? "d" : "s";
    return out;
  }
  function shareSetup(info, text) {
    //MC 2026-10-11 the admin's tags ($SHY #Solana ...) ride on every result post, once, if they fit
    //MC 2026-10-12 only the tags the text doesn't have yet: the text ends in "$SHY", the first tag, so none were ever added
    var miss = xTags.split(/\s+/).filter(function (t) { return t && text.toLowerCase().indexOf(t.toLowerCase()) < 0; }).join(" ");
    if (miss && (text + "\n" + miss).length < 240) text += "\n" + miss;
    if (spLast && (text + "\n" + spLast).length < 250) text += "\n" + spLast;   //MC 2026-10-24 the Shadow's own play rides on the share
    var st = shareState = { text: text, url: "", img: "", blob: null, info: info, name: me.name || "" };
    info.standings.forEach(function (row) { if (row.me) row.n = me.name || "You"; });
    var xBtn = $("g-share"), imgBtn = $("g-img");
    //MC 2026-10-12 a share the player sends themselves can carry one account from the admin's list (xKol); the automatic post never does
    var mine = function () { var add = (xAlways + " " + xKol).split(/\s+/).filter(function (h, i, a) { return h && a.indexOf(h) === i && st.text.indexOf(h) < 0; }).join(" "); return st.text + (add ? " " + add : "") + "\n" + (st.url || (info.boss ? "https://shyonsol.io/shogun" : "https://shyonsol.io/play?v=w3")); };   //MC 2026-10-12 while the card isn't ready, a boss post links /shogun (its own preview card), not the plain play page //MC 2026-10-13 ?v=w3: X keeps one preview per exact URL, and the bare /play still showed the design from weeks ago
    var setX = function () { xBtn.href = "https://x.com/intent/tweet?text=" + encodeURIComponent(mine()); };
    setX();
    imgBtn.hidden = true;
    $("g-copy").textContent = "Copy result";
    $("g-copy").onclick = function () {
      var done = function () { $("g-copy").textContent = "Copied"; setTimeout(function () { $("g-copy").textContent = "Copy result"; }, 1600); };
      try { navigator.clipboard.writeText(st.text + "\n" + (st.url || (info.boss ? "https://shyonsol.io/shogun" : "https://shyonsol.io/play?v=w3"))).then(done, done); } catch (e) { done(); }
    };
    xBtn.onclick = function (e) {
      sfx("tap");
      // linked to X: post right here instead of leaving for x.com
      if (xUser && xPost && window.ShyX) { e.preventDefault(); ShyX.compose(mine(), xUser, function (j) { toast(j && j.xt ? "Posted to X. X task done: +" + j.xt.koban + " Koban" : "Posted to X"); if (j && j.xt && window.ShyEco) ShyEco.refresh(); }); }
    };
    xBtn.textContent = xUser && xPost ? "Post to X" : "Share on X";
    var xtn = $("g-xt"), nudge = window.ShyEco && ShyEco.xtNudge ? ShyEco.xtNudge(info.kind === "daily") : "";
    if (xtn) { xtn.innerHTML = nudge; xtn.hidden = !nudge; }
    var hint = $("g-x-hint");
    if (hint) hint.hidden = !(xEnabled && !xUser);
    var body = { a: "create", pid: me.pid, key: me.key, name: me.name || "Player", avatar: myAvatar(), mask: "unbound",
      owners: ownersCode(), rounds: roundsCode() };
    Object.keys(info).forEach(function (k) { body[k] = info[k]; });
    //MC 2026-10-12 the card can be asked for before the game's own score has reached the server (a Daily run's score is
    //   saved a moment after the end screen opens): the server says "not on your record" (409) and the post went out with
    //   the plain /play link, so X showed the site's preview instead of the card. Now it asks again (2.5s, then 6s), and
    //   the Share button says "Making your card…" and waits until the card is there (or the last try fails).
    var xLabel = xBtn.textContent, ready = false;
    var waitOn = function () { xBtn.classList.add("is-wait"); xBtn.setAttribute("aria-disabled", "true"); xBtn.textContent = "Making your card…"; };
    var waitOff = function () { if (ready) return; ready = true; xBtn.classList.remove("is-wait"); xBtn.removeAttribute("aria-disabled"); if (xBtn.textContent === "Making your card…") xBtn.textContent = xLabel; };
    var guard = xBtn.onclick; xBtn.onclick = function (e) { if (!ready) { e.preventDefault(); return; } if (guard) return guard.call(this, e); };
    waitOn(); setTimeout(waitOff, 12000);
    var tries = 0;
    (function make() { fetch(SHARE_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (j) { if (j && !j.ok) j.status = r.status; return j; }); })
      .then(function (j) {
        if (shareState !== st) return;
        if (!j || !j.ok) { if (tries < 2 && (!j || j.status === 409 || j.status >= 500)) { setTimeout(make, [2500, 6000][tries++]); } else waitOff(); return; }
        waitOff();
        st.url = j.url; st.img = SHARE_API + "?i=" + j.id;
        setX();
        //MC 2026-10-11 a win, with "Post my wins to X" on: it goes out now, and the player is told it did (or why not)
        if (info.result === "win" && !info.autoTried && xUser && xPost && xAuto && window.ShyX && ShyX.autoPost) {
          info.autoTried = true;   // a renamed card is drawn again with a new id; the win still goes out once
          ShyX.autoPost(st.text + "\n" + st.url, j.id).then(function (p) {
            if (shareState !== st) return;
            if (p && p.ok) {
              toast("Your win was posted to your X automatically.");
              xBtn.textContent = "View on X"; xBtn.href = p.url; xBtn.target = "_blank"; xBtn.rel = "noopener";
              xBtn.onclick = function () { sfx("tap"); };
            } else if (p && p.status !== 409 && p.status !== 429 && p.status !== 403) toast("Couldn't post your win to X this time. Use Share on X.");
          });
        }
        imgBtn.hidden = false;
        // phones can hand the picture straight to X, Telegram and the rest, so fetch it ahead of the tap
        if (navigator.canShare) fetch(st.img).then(function (r) { return r.blob(); }).then(function (b) { if (shareState === st) st.blob = b; }).catch(function () {});
      }).catch(function () { if (tries < 2) setTimeout(make, [2500, 6000][tries++]); else waitOff(); }); })();
  }
  $("g-img").addEventListener("click", function () {
    var st = shareState; if (!st || !st.img) return;
    sfx("tap");
    if (st.blob && navigator.canShare) {
      var file = new File([st.blob], "shilluminati.png", { type: "image/png" });
      if (navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], text: st.text + "\n" + st.url }).catch(function () {});
        return;
      }
    }
    // desktop: download the card
    var a = document.createElement("a");
    a.href = st.img; a.download = "shilluminati.png"; document.body.appendChild(a); a.click(); a.remove();
  });

  function setLbMsg(t, good) { var m = $("g-lb-msg"); m.textContent = t; m.className = "g-lb-msg" + (good ? " good" : ""); }

  async function submit() {
    if (submitted || !pendingResult || !token) return;
    submitted = true;
    // this save belongs to this game only; a new game started meanwhile keeps its own ticket and screen
    var myTok = token, mine = pendingResult;
    var stale = function () { return pendingResult !== mine; };
    setLbMsg("Saving your score...");
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({
        a: "submit", token: myTok, pid: me.pid, key: me.key, name: me.name, avatar: myAvatar(), badges: badgeCount(),
        regions: mine.regions, result: mine.result, mode: mine.mode, hints: mine.hints, moves: mine.moves }) });
      var j = await r.json();
      if (stale()) return;
      if (!j.ok) {
        submitted = false;
        if (r.status === 409 || /name/i.test(j.error || "")) { $("g-save").hidden = false; me.name = ""; store("shy-lb-name", ""); }
        else if (r.status === 400 || r.status === 403) token = null;   // this game can't be saved, don't offer a retry
        setLbMsg(j.error || "Couldn't save the score.");
        bountyMiss(!token);
        return;
      }
      //MC 2026-10-19 this profile was combined into another: swap ids and save the same game again as the
      //   kept profile (the ticket is still live, the server left it unspent)
      if (j.moved && !submit.movedOnce) {
        submit.movedOnce = true;
        me.pid = j.moved; store("shy-lb-pid", me.pid);
        if (j.name) { me.name = j.name; store("shy-lb-name", me.name); }
        submitted = false;
        return submit();
      }
      if (token === myTok) token = null;
      $("g-save").hidden = true;
      if (j.already) { setLbMsg("Saved.", true); loadBoard(board); return; }
      if (j.practice) { setLbMsg("Your first Daily run today is already on the board. This one was practice.", true); return; }
      // the admin can set a player's name; take it on so this device stays in step
      if (j.me && j.me.name && j.me.name !== me.name) { me.name = j.me.name; store("shy-lb-name", me.name); }
      // the server decides who you played as; if that changed, ownership changed
      if (j.me && (j.me.avatar || "") !== myAvatar()) holderPost({ a: "status" }).then(function (h) { if (h.ok) applyHolder(h); });
      var msg = "Saved. You're #" + j.rank + " of " + j.total + " all time with " + j.me.points.toLocaleString() + " points.";
      if (j.daily && j.dailyCounted) msg = "Saved. You're #" + j.dailyRank + " of " + j.dailyTotal + " in today's Daily, and #" + j.rank + " all time.";
      if (j.duel) {
        var dd = j.duel;
        msg = dd.sent ? "Saved. Your " + mine.regions + (mine.regions === 1 ? " Region is" : " Regions are") + " in: " + dd.vsName + " has 24 hours to beat " + (mine.regions === 1 ? "it." : "them.")
          : dd.done ? (dd.won === "me" ? "You won the Duel, " + dd.mine + " to " + dd.theirs + "." : dd.won === "tie" ? "The Duel is a tie, " + dd.mine + " each." : dd.vsName + " won the Duel, " + dd.theirs + " to " + dd.mine + ".") : msg;
        if (dd.done && dd.won === "me") victory();
        if (window.ShyFriends) ShyFriends.refresh();
      }
      setLbMsg(msg, true);
      if (j.bounty) bountyResult(j.bounty);
      if (window.ShyEco && ShyEco.onGame) ShyEco.onGame(j.eco, j.league);
      loadBoard(j.daily ? "daily" : board);
      // a name added after the game: redraw the share card with it
      if (shareState && shareState.name !== (me.name || "")) shareSetup(shareState.info, shareState.text);
    } catch (e) {
      if (stale()) return;
      submitted = false;
      setLbMsg("Couldn't reach the leaderboard. Tap Save to try again.");
      bountyMiss(false);
      if (me.name) $("g-name").value = me.name;
      $("g-save").hidden = false;
    }
  }

  // ---------- leaderboard ----------
  // the board itself lives in board.js (shared with the Stats page); the game tells it when to refresh
  var board = "all";
  function loadBoard(which) {
    if (!window.ShyBoard) return;
    ShyBoard.setOwned(ownedNums);
    board = which || ShyBoard.board();
    ShyBoard.load(which || null);
  }


  // ---------- start ----------



  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  // ---------- Daily replays: the day's deal and one player's moves, played back exactly as the server scored them ----------
  async function replayTurn(my) {
    if (!my || g !== my || !g.replay) return;
    var R = g.replay, name = g.players[0].name;
    busy = true; render();
    await wait(700);
    if (g !== my || !g.replay) return;
    while (!g.over) {
      var m = R.moves[R.i++];
      if (!m || m.h < 0) { if (g.played || !g.regionDeck.length) g.log.push({ who: 0, text: name + " ends the turn.", kind: "info" }); break; }
      var id = g.players[0].hand[m.h];
      if (!id) break;
      await flash(0, id);
      if (g !== my || !g.replay) return;
      var logAt = g.log.length;
      G.play(g, 0, m.h, m.t == null ? null : m.t);
      sfxFor(logAt); render();
      if (!G.morePlays(g, 0)) break;
      await wait(500);
      if (g !== my || !g.replay) return;
    }
    render();
    await wait(600);
    if (g !== my || !g.replay) return;
    G.endTurn(g);
    nextTurn(my);
  }
  function overlay(id) {
    var o = $(id);
    if (!o) { o = document.createElement("div"); o.id = id; o.className = "g-overlay g-wend"; $("g-end").parentNode.appendChild(o); }
    return o;
  }
  function replayEnd() {
    render();
    var R = g.replay.R, s = G.standings(g), mine = g.players[0].regions.length;
    var res = R.result === "win" ? "won" : R.result === "tie" ? "tied" : "lost";
    var o = overlay("g-rend");
    o.innerHTML = '<div class="g-ov-in"><span class="eyebrow">Replay · Daily #' + R.no + '</span><h2><span data-i18n-skip>' + esc(R.name) + '</span> ' + res + ' with ' + mine + (mine === 1 ? " Region" : " Regions") + '.</h2>' +
      '<p class="sub">' + fmt(R.points) + ' points. Same deck for everyone that day: could you beat it?</p><ul class="g-end-list">' + s.map(function (x, k) { return '<li' + (x.i === 0 ? ' class="me"' : "") + '><span>' + (k + 1) + '</span>' + avHTML(x.i, "sm") + '<b data-i18n-skip>' + esc(g.players[x.i].name) + '</b><em>' + x.regions + (x.regions === 1 ? " Region" : " Regions") + '</em></li>'; }).join("") + '</ul>' +
      '<div class="btns"><button class="btn btn-red" data-game-start="daily">Play today\'s Daily</button><button class="btn btn-line" data-replay-again>Watch again</button><button class="btn btn-line" data-game-board>Daily board</button><a class="btn btn-line" href="/p/' + encodeURIComponent(R.tag) + '">See their profile</a></div></div>';
    o.hidden = false;
  }
  async function beginReplay(R) {
    liveStop(); lastMode = "quick";
    G.useSeason(R.deck || []);
    var rnd = G.seeded(R.seed), riv = G.setupRivals(rnd);
    riv.names = G.rivalNames(riv.names, R.seed);
    avatars = [{ label: R.name, src: R.img || UNBOUND, look: R.aura ? lookCls(R.aura) : "", n: R.aura && R.avatar ? String(R.avatar) : "", au: R.aura || "" }].concat(riv.names.map(function (n) { return { label: n, src: maskSrc(n), hue: maskHue(n) }; }));
    spPrep();
    if (window.SHYI18N) SHYI18N.addNames(riv.names.concat([R.name]));
    g = G.newGame([R.name].concat(riv.names), 0, rnd, { easy: false, styles: [""].concat(riv.styles) });
    lastReplay = R;
    g.replay = { R: R, moves: R.moves, i: 0 }; g.daily = true; g.practice = true; g.dayKey = R.day; g.dailyNo = R.no;
    shown = 0; sel = -1; busy = true; prevCounts = null; submitted = true; ff = false; tipKey = ""; newCard = -1; mapPrev = null;
    track = { rounds: [], lastRound: 0, blocks: 0, lost: false, wasLast: false, played: {}, moves: [] }; spSeen = {}; spLast = "";
    $("g-log").innerHTML = "";
    ["g-start", "g-end", "g-targets", "g-flash", "g-coach", "g-rend"].forEach(function (k) { var e = $(k); if (e) e.hidden = true; });
    root.classList.add("is-watch");
    watchBar("Replay · Daily #" + R.no, R.name);
    g.log.push({ who: g.start, text: "Replay of " + R.name + "'s Daily #" + R.no + ". " + g.players[g.start].name + (g.start === 0 ? " goes first." : " goes first."), kind: "info" });
    //MC 2026-10-09 replays played inside the page on phones with the watch bar over the map. Same full screen as a game.
    if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true);
    render();
    try { if (!document.body.classList.contains("g-focus")) root.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {}
    banner("Replay: Daily #" + R.no, "daily");
    var my = g;
    setTimeout(function () { nextTurn(my); }, 600);
  }
  async function loadReplay(day, tag) {
    try {
      var j = await (await fetch("api/replay.php?d=" + encodeURIComponent(day) + "&p=" + encodeURIComponent(tag))).json();
      if (!j.ok) { toast(esc(j.error || "That replay isn't available.")); return; }
      beginReplay(j);
    } catch (e) { toast("Couldn't load the replay. Try again."); }
  }
  // the bar under the table while watching: what this is, and a way out
  function watchBar(what, who) {
    var b = $("g-watchbar");
    if (!b) { b = document.createElement("div"); b.id = "g-watchbar"; b.className = "g-watchbar"; root.querySelector(".g-hand-wrap").after(b); }
    //MC 2026-10-11 no "Skip ahead" while watching a live match: the match runs at its own pace, it only cut the card flashes short
    b.innerHTML = '<span class="g-wb-eye" aria-hidden="true">👁</span><div><b>' + esc(what) + '</b>' + (who ? '<small data-i18n-skip>' + esc(who) + '</small>' : "") + '</div>' + (live && live.watch ? "" : '<button class="btn btn-line btn-sm" data-ff>Skip ahead</button>') + '<button class="btn btn-line btn-sm" data-watch-stop>Leave</button>';
    b.hidden = false;
  }
  //MC 2026-10-15 late join: while a bot seat is still open (the first two minutes of a match), someone watching gets a
  //   Jump in button with the time left. It joins like the room code would, taking over that bot's hand and Regions.
  var lateT = 0;
  function lateJump(v) {
    var b = $("g-watchbar"); if (!b) return;
    var btn = b.querySelector("[data-late-join]");
    var open = v && v.status === "playing" && v.lateUntil && v.lateUntil > serverNow() + 2 && !v.tourney;
    if (!open) { if (btn) btn.remove(); clearInterval(lateT); return; }
    if (!btn) {
      btn = document.createElement("button"); btn.type = "button"; btn.className = "btn btn-red btn-sm g-late"; btn.setAttribute("data-late-join", "");
      btn.innerHTML = 'Jump in <span class="g-late-t" data-i18n-skip></span>';
      b.insertBefore(btn, b.querySelector("[data-watch-stop]"));
    }
    var until = v.lateUntil;
    var draw = function () { var left = until - serverNow(); var t = btn.querySelector(".g-late-t"); if (left <= 1) { btn.remove(); clearInterval(lateT); return; } if (t) t.textContent = clock(left); };
    clearInterval(lateT); lateT = setInterval(draw, 1000); draw();
  }
  function watchStop() {
    root.classList.remove("is-watch");
    var b = $("g-watchbar"); if (b) b.hidden = true;
    ["g-rend", "g-wend"].forEach(function (k) { var e = $(k); if (e) e.hidden = true; });
    if (live && live.watch) liveStop();
    if (g) { g.over = true; g.replay = null; g.stopped = true; }   //MC 2026-10-11 stopped: the replay's turn loop ends here instead of running on into a solo results screen
    showMenu();
  }
  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-watch-stop]")) { watchStop(); return; }
    if (e.target.closest("[data-late-join]")) { var lc = live && live.code; clearInterval(lateT); if (lc) { root.classList.remove("is-watch"); var wb = $("g-watchbar"); if (wb) wb.hidden = true; liveStart("live-join", lc); } return; }
    if (e.target.closest("[data-ff]")) { ff = true; return; }
    if (e.target.closest("[data-replay-again]") && g && g.dayKey) { var R = (g.replay && g.replay.R) || lastReplay; if (R) beginReplay(R); return; }
    var w = e.target.closest("[data-watch]"); if (w) { e.preventDefault(); startWatch(w.dataset.watch); return; }
    var rp = e.target.closest("[data-replay]"); if (rp) { e.preventDefault(); var x = rp.dataset.replay.split(":"); loadReplay(x[0], x[1]); }
  });
  var lastReplay = null;

  async function begin(kind) {
    if (kind === "again") kind = lastMode === "daily" || /^duel:/.test(lastMode) ? "quick" : lastMode;
    unwatch();
    if (/^live/.test(kind)) return liveStart(kind);
    //MC 2026-10-11 starting a solo game from inside a live room (Missions > Play today's Daily) only stopped polling, so
    //   the table kept waiting on this seat's turn clock every turn. Tell the room we left, as the Leave button does.
    //   A tournament seat is the bracket's call, so that one is left alone.
    if (live && !live.watch && !live.done && live.kind !== "tourney") { try { livePost(Object.assign({ a: "leave" }, liveCreds())); } catch (e) {} }
    liveStop();
    var duelId = /^duel:([a-f0-9]{10})$/.exec(kind), duel = null;
    lastMode = kind;
    var daily = kind === "daily", practice = daily && !!stats.daily[dayKey()];
    var easy = !daily && !duelId && me.mode === "easy";
    // get the game's seed first: the server replays this exact game from it to verify the score
    token = null;
    var seed = null, deck = window.SHY_SEASON || [];
    try {
      //MC 2026-10-11 the Daily start carries the player's key too, so the server can tell whether today's run is used
      //   (see lb.php start) and answer practice:true for a second device or a run left after its first move
      var r0 = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(duelId ? { a: "start", duel: duelId[1], pid: me.pid, key: me.key } : { a: "start", daily: daily, mode: easy ? "easy" : "normal", pid: me.pid, key: me.key }) });
      var j0 = await r0.json(); if (j0.ok) { token = j0.token; seed = j0.seed; if (j0.deck) deck = j0.deck; if (daily && j0.practice != null) practice = !!j0.practice; }
      // a Duel is the Duel's own deal or nothing
      if (duelId && !j0.ok) { toast(esc(j0.error || "Couldn't open that Duel.")); showMenu(); return; }
      if (duelId) duel = { id: duelId[1], vs: j0.vs, vsId: j0.vsId, target: j0.target };
    } catch (e) { token = null; if (duelId) { toast("Couldn't reach the game. Try again."); showMenu(); return; } }
    var rnd = seed != null ? G.seeded(seed) : (daily ? seeded("shy-daily-" + dayKey()) : Math.random);
    G.useSeason(deck);   // the original 71 plus the season cards in play when this game was dealt
    var riv = G.setupRivals(rnd);
    riv.names = G.rivalNames(riv.names, seed != null ? seed : (daily ? (hashStr("shy-daily-" + dayKey())) : Math.floor(Math.random() * 4294967296)));
    var rivals = riv.names.map(function (n, k) { return { name: n, src: maskSrc(n), hue: maskHue(n), style: riv.styles[k] }; });
    bountyNear = 0;
    var ms = meSeat(true);
    avatars = [{ label: me.name || "You", src: ms.src, look: ms.look, n: ms.n, au: ms.au, trial: ms.trial }].concat(rivals.map(function (r) { return { label: r.name, src: r.src, hue: r.hue }; }));
    spPrep();
    RX = {};
    if (window.SHYI18N) SHYI18N.addNames(rivals.map(function (r) { return r.name; }).concat([me.name || ""]));
    g = G.newGame(["You"].concat(rivals.map(function (r) { return r.name; })), 0, rnd,
      { easy: easy, styles: [""].concat(rivals.map(function (r) { return r.style; })) });
    g.daily = daily; g.practice = practice; g.dayKey = dayKey(); g.dailyNo = dailyNo(); g.duel = duel;
    shown = 0; sel = -1; busy = true; prevCounts = null; submitted = false; ff = false; tipKey = ""; newCard = -1;
    track = { rounds: [], lastRound: 0, blocks: 0, lost: false, wasLast: false, played: {}, moves: [] }; spSeen = {}; spLast = "";
    mapPrev = null;
    $("g-log").innerHTML = "";
    $("g-start").hidden = true; $("g-end").hidden = true; $("g-targets").hidden = true; $("g-flash").hidden = true; $("g-coach").hidden = true;
    // phones and tablets get the whole screen while playing; the corner icon exits for this game only
    if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true);
    try { if (!document.body.classList.contains("g-focus")) root.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {}
    g.log.push({ who: g.start, text: (daily ? "Daily #" + g.dailyNo + (practice ? " (practice). " : ". ") : "") + (duel ? "Duel with " + duel.vs + (duel.target != null ? ": beat " + duel.target + (duel.target === 1 ? " Region. " : " Regions. ") : ": the same deal goes to them next. ") : "") + g.players[g.start].name + (g.start === 0 ? " go first." : " goes first."), kind: "info" });
    render();
    sfx(daily ? "match" : "join");
    // short laptop screens: suggest full screen once
    //MC 2026-10-11 up to 760px tall (was 700), so a 1280x720 laptop gets the tip too (#12)
    if (matchMedia("(min-width:900px) and (max-height:760px)").matches && !document.body.classList.contains("g-focus") && !store("shy-fs-tip")) {
      store("shy-fs-tip", "1"); setTimeout(function () { toast("Small screen? Press F for full screen."); }, 1200);
    }
    var my = g;
    var go = function () {
      if (g !== my) return;
      if (daily && !practice) banner("Daily #" + g.dailyNo, "daily");
      if (duel) banner("Duel vs " + duel.vs, "daily");
      setTimeout(function () { nextTurn(my); }, 500);
    };
    if (!intro(go)) go();
  }
  //MC 2026-10-11 the Daily counts as played from your first move (a card or a claim). Leaving used to keep the run open
  //   with the same deal, so a player could look at the Daily as often as they liked before playing the run that counts.
  //   The server is told once, on the first move; a later start today is then practice. Closing the page before any move
  //   costs nothing: the next start carries on with the same run. Tried counting it at the deal instead, but then an
  //   accidental close or a crash before you'd done anything would lose the day's Daily.
  function dailyBegun() {
    if (!g || !g.daily || g.practice || g.replay || g.begun || !token) return;
    g.begun = true;
    try { fetch(API, { method: "POST", keepalive: true, headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "dbegin", token: token, pid: me.pid, key: me.key }) }).catch(function () {}); } catch (e) {}
  }
  // leaving a replay or a match being watched: the table is the player's own again
  function unwatch() {
    root.classList.remove("is-watch");
    ["g-watchbar", "g-rend", "g-wend"].forEach(function (k) { var e = $(k); if (e) e.hidden = true; });
  }
  function showMenu() {
    //MC 2026-10-09 the lobby is never full screen. Leave room and End screen > Settings used to land here still in
    //   g-focus, with the site header and tab bar hidden.
    if (document.body.classList.contains("g-focus")) toggleFocus(true);
    unwatch();
    document.documentElement.classList.remove("g-playing");
    if (live && live.done) liveStop();
    $("g-end").hidden = true; $("g-start").hidden = false; $("g-start").scrollTop = 0;
    refreshLiveCard();
    refreshStart();
    loadBounty();
  }
  //MC 2026-10-09 the 15 Club bounty (api/bountylib.php): the lobby card, a heads-up when a qualifying game gets close,
  //and the results. The server decides who won; the browser only shows what it says.
  var BOUNTY = null, bountyNear = 0, bountyPend = false;
  function bountyDate(ts) { try { return new Date(ts * 1000).toLocaleDateString(document.documentElement.lang || "en", { month: "long", day: "numeric", timeZone: "UTC" }); } catch (e) { return ""; } }
  function loadBounty() { fetch("api/bounty.php?me=" + String(me.pid || "").slice(0, 6)).then(function (r) { return r.json(); }).then(function (j) { if (j && j.ok) { BOUNTY = j; drawBounty(); } }).catch(function () {}); }
  function drawBounty() {
    var el = $("g-bounty"), b = BOUNTY; if (!el) return;
    if (!b || !b.on) { el.hidden = true; return; }
    var left = Math.max(1, Math.ceil((b.ends * 1000 - Date.now()) / 864e5));
    el.className = "g-bounty" + (b.winner ? " won" : "");
    el.innerHTML = '<span class="gb-ic" aria-hidden="true">15</span><div class="gb-t">' + (b.winner
      ? '<span class="gb-k">Monthly bounty · claimed</span><b>' + esc(b.prize) + ' went to <span data-i18n-skip>' + esc(b.winner.name) + '</span></b><small>The next bounty opens <span data-i18n-skip>' + esc(bountyDate(b.ends)) + '</span>. Win holding all ' + b.at + ' Regions to join the 15 Club.</small>'
      : '<span class="gb-k">Monthly bounty</span><b>The 15 Club: ' + esc(b.prize) + '</b><small>The first player this month to win holding all ' + b.at + ' Regions takes it. Normal with hints off, the Daily, or any live match. ' + (left === 1 ? "Last day." : left + " days left.") + '</small>') +
      '</div><a class="gb-rules" href="rules.html#monthly-bounty-the-club">Rules</a>' + bountyOdds(b) + bountyBoard(b);
    el.hidden = false;
  }
  //MC 2026-10-09 How rare it is: the test run before launch, real games since the bounty opened, and the most anyone has
  //   held at the end. Numbers come from the server (bounty.php odds), so they grow as people play.
  function bountyOdds(b) {
    var o = b.odds; if (!o) return "";
    var at = b.at || 15, n = function (x) { return Number(x || 0).toLocaleString("en-US"); };
    var sim = o.sim || { games: 0, wins: 0, best: 0 };
    var real = o.games ? (o.wins ? "1 in " + n(Math.round(o.games / o.wins)) : "0 of " + n(o.games)) : "0 so far";
    var best = Math.max(o.best || 0, sim.best || 0);
    return '<div class="gbo"><span class="gbo-h">How rare is it?</span><div class="gbo-row">' +
      '<div class="gbo-s"><b>' + (sim.wins ? "1 in " + n(Math.round(sim.games / sim.wins)) : "0 of " + n(sim.games)) + '</b><small>test games before launch ended with a win holding all ' + at + '</small></div>' +
      '<div class="gbo-s"><b>' + real + '</b><small>' + (o.games ? "real games that count, since the bounty opened" : "real games have done it. Yours could be the first") + '</small></div>' +
      '<div class="gbo-s"><b>' + best + '<em>/' + at + '</em></b><small>the most anyone has held at the end</small></div></div></div>';
  }
  //MC 2026-10-09 Closest to 15: this month's most Regions held at the end of a qualifying game, for everyone to see.
  //Top 5 open, the rest of the top 10 one tap away, and your own spot if you're further down.
  var bountyAll = false;
  function bountyBoard(b) {
    var list = b.board || [], at = b.at || 15, myTag = String(me.pid || "").slice(0, 6), mineIn = false;
    var rows = list.slice(0, bountyAll ? 10 : 5).map(function (x, i) {
      var mine = x.tag === myTag; if (mine) mineIn = true;
      return '<li' + (mine ? ' class="me"' : "") + '><span class="gbb-n">' + (i + 1) + '</span><a class="gbb-name" href="/p/' + encodeURIComponent(String(x.name).replace(/ /g, "_")) + '" data-i18n-skip>' + esc(x.name) + '</a>' +
        '<span class="gbb-bar" aria-hidden="true"><i style="width:' + Math.min(100, Math.round(x.r / at * 100)) + '%"></i></span><b class="gbb-r">' + Math.min(at, x.r) + '<small>/' + at + '</small></b>' + (x.won ? '<span class="gbb-w" title="Won that game">W</span>' : '<span class="gbb-w no"></span>') + '</li>';
    }).join("");
    //MC 2026-10-11 after the bounty is claimed the board is final for the month (the server stops adding to it)
    var h = '<div class="gbb' + (b.locked ? ' locked' : '') + '"><div class="gbb-h"><b>' + (b.locked ? "Final board this month" : "Closest to " + at + " this month") + '</b><small>' + (b.locked ? "The bounty was claimed, so this month's board is locked. A new one opens with next month's bounty." : "Most Regions held at the end of a game that counts") + '</small></div>';
    if (!list.length) return h + '<p class="gbb-empty">' + (b.locked ? "Nobody else made the board this month." : "No games on the board yet this month. Yours could be first.") + '</p></div>';
    h += '<ol class="gbb-list">' + rows + '</ol>';
    if (b.mine && !mineIn) h += '<p class="gbb-me">You: #' + b.mine.rank + ' with ' + b.mine.r + (b.mine.r === 1 ? " Region" : " Regions") + '</p>';
    if (list.length > 5) h += '<button type="button" class="gbb-more" data-bounty-more>' + (bountyAll ? "Show top 5" : "Show top 10") + '</button>';
    return h + '</div>';
  }
  document.addEventListener("click", function (e) { if (e.target.closest && e.target.closest("[data-bounty-more]")) { bountyAll = !bountyAll; drawBounty(); } });
  // does this game count for the bounty? Live matches and first Daily runs do; solo needs Normal with hints off; Duels don't
  function bountyGame() { if (!g) return false; if (isLive()) return true; if (isDuel() || g.practice) return false; if (isDaily()) return true; return me.mode !== "easy" && !me.hints; }
  function bountyCloser(n) {
    var b = BOUNTY; if (!b || !b.on || b.winner || !bountyGame() || n < b.at - 3 || n >= b.at || n <= bountyNear) return;
    bountyNear = n;
    banner((b.at - n) + (b.at - n === 1 ? " Region" : " Regions") + " from the bounty", "final");
  }
  // the results: pending until the server confirms (a solo score has to be saved first), then won or joined the club
  function bountyEnd(regions, won) {
    var el = $("g-bwin"); if (!el) return;
    bountyPend = false;
    if (!won || !BOUNTY || regions < BOUNTY.at || !bountyGame()) { el.hidden = true; el.innerHTML = ""; return; }
    bountyPend = true;
    el.className = "g-bwin pend";
    el.innerHTML = '<span class="gbw-k">The 15 Club</span><b>You held all ' + BOUNTY.at + ' Regions!</b><p>' + (BOUNTY.winner ? "That's the rarest win in the game. Saving your score adds you to the 15 Club." : "Saving your score claims this month's bounty, if nobody beat you to it.") + '</p>';
    el.hidden = false;
  }
  //MC 2026-10-09 the save failed: say so on the bounty card instead of leaving it on "saving"
  function bountyMiss(final) {
    var el = $("g-bwin"); if (!el || !bountyPend) return;
    var p = el.querySelector("p"); if (p) p.textContent = final ? "This game couldn't be saved, so it can't claim the bounty." : "Your score isn't saved yet. Save it to claim the bounty.";
  }
  function bountyResult(x) {
    var el = $("g-bwin"); if (!el || !x) return;
    bountyPend = false;
    el.className = "g-bwin" + (x.won ? " won" : "");
    el.innerHTML = x.won
      ? '<span class="gbw-k">15 Club bounty</span><b>You won this month\'s bounty!</b><p>' + esc(x.prize) + ' goes to the wallet you connect on your profile. Connect one now if you haven\'t, and the team will send it. The 15 Club title is yours too.</p><a class="btn btn-mint" href="profile.html">Open your profile</a>'
      : '<span class="gbw-k">The 15 Club</span><b>You joined the 15 Club</b><p>' + (x.winner ? 'This month\'s bounty already went to <span data-i18n-skip>' + esc(x.winner) + '</span>, but the 15 Club title is yours. Wear it from the Dojo Shop.' : 'The 15 Club title is yours. Wear it from the Dojo Shop.') + '</p>';
    el.hidden = false;
    if (x.won) { try { fxRun("money"); } catch (e) {} sfx("badge"); }
    loadBounty();
  }
  loadBounty();
  function refreshStart() {
    $("g-quick-sub").textContent = (me.mode === "easy" ? "Easy" : "Normal") + ", " + (me.hints ? "hints on" : "hints off") + ", " + (me.speed === "fast" ? "fast" : "chill");
    var played = stats.daily[dayKey()];
    $("g-daily-no").textContent = "Daily Challenge #" + dailyNo();
    $("g-daily-sub").textContent = played ? (played.left ? "Played today: you left your run. Replays are practice." : "Played today: " + played.regions + (played.regions === 1 ? " Region" : " Regions") + ". Replays are practice.") : "Same deck for everyone today. One shot at the board.";
    renderProfile();
  }

  // ---------- live matches ----------
  var LIVE_API = "api/live.php";
  var REACTS = ["\u{1F602}", "\u{1F525}", "\u{1F631}", "\u{1F440}", "\u{1FAE1}", "\u{1F480}",
    "\u{1F479}", "\u{1F5E1}\uFE0F", "\u{1F3EF}", "\u{1F409}", "\u{1F338}", "\u{1F375}", "\u{1F390}", "\u{1F647}",
    "\u{1F4B0}", "\u{1F451}", "\u{1F48E}", "\u{1F680}", "\u{1F315}", "\u{1F98A}", "\u{1F319}", "\u26E9\uFE0F"];
  var live = null;
  function liveSaved() { try { return JSON.parse(store("shy-live") || "null"); } catch (e) { return null; } }
  function liveRemember() { store("shy-live", live && live.code ? JSON.stringify({ code: live.code, seat: live.seat, secret: live.secret, kind: live.kind, ts: Date.now() }) : ""); }
  async function livePost(body) {
    try {
      var r = await fetch(LIVE_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      return await r.json();
    } catch (e) { return { ok: false, error: "Can't reach the live server. Check your connection.", net: true }; }
  }
  function liveCreds() { return { code: live.code, seat: live.seat, secret: live.secret }; }
  function liveRel(i) { return (i - live.seat + live.n) % live.n; }
  function liveAbs(rel) { return (rel + live.seat) % live.n; }
  function serverNow() { return Date.now() / 1000 + (live ? live.offset : 0); }
  function clock(sec) { sec = Math.max(0, Math.ceil(sec)); return Math.floor(sec / 60) + ":" + ("0" + sec % 60).slice(-2); }
  function timerText() {
    if (!live || !live.view || !live.view.game || !live.view.game.deadline || live.view.status !== "playing") return "";
    return " " + clock(live.view.game.deadline - serverNow());
  }
  function profile() { return { pid: me.pid, key: me.key, name: me.name, avatar: myAvatar() }; }
  function liveMsg(t) { var m = $("g-live-msg"); if (m) { m.textContent = t || ""; m.hidden = !t; } }

  async function liveStart(kind, code) {
    var nameBox = $("g-live-name"), viaInvite = kind === "live-join" && !!code;
    if (!me.name) {
      var n = (nameBox && nameBox.value || "").trim();
      if (!/^[A-Za-z0-9 _.\-]{3,20}$/.test(n)) { liveMsg("Pick a player name first (3 to 20 letters or numbers)."); if (nameBox) nameBox.focus(); return; }
      me.name = n; store("shy-lb-name", n); $("g-name").value = n;
    }
    if (kind === "live-join") {
      code = (code || $("g-live-code").value || "").trim().toUpperCase();
      if (!/^[A-Z0-9]{5}$/.test(code)) { liveMsg("Room codes are 5 letters and numbers."); return; }
    }
    //MC 2026-10-10 moving to another room never told the server we left the old one. Two friends calling each other out at
    //   once: one joined the other, and their own room stayed open with a host who was gone, so a tap on that invite sat
    //   forever with no one to press Start. Now the old room is left once the new one says yes (it closes if we were
    //   hosting and it hadn't started), and a join that fails leaves you where you were instead of in no room at all.
    var oldRoom = live && !live.watch && live.kind !== "tourney" && live.code !== code ? liveCreds() : null;   // a tournament seat is the bracket's call
    var keep = viaInvite && live && !live.done && !live.watch;
    if (!keep) liveStop();
    var duel2 = kind === "live-quick2" || kind === "live-create2" || kind === "live-quickf";   //MC 2026-10-18 1v1 tables, real players only
    var forged = kind === "live-quickf" || kind === "live-createf" || kind === "live-bossf";   //MC 2026-10-18 the Deck Forge
    lastMode = /boss/.test(kind) ? kind : kind === "live-quick2" || kind === "live-quickf" ? kind : "live-quick";   //MC 2026-10-12 Play again after a boss match is another boss match
    liveMsg(kind === "live-quick" ? "Finding a match..." : kind === "live-quickf" ? "Looking for a forged rival..." : kind === "live-quick2" ? "Looking for a rival..." : /boss/.test(kind) ? "The Shogun takes its seat..." : kind === "live-createf" ? "Lighting the forge..." : "Opening the room...");
    var r = await livePost(Object.assign({ a: /quick/.test(kind) ? "quick" : /create/.test(kind) ? "create" : /boss/.test(kind) ? "boss" : "join", code: code, size: duel2 ? 2 : undefined, forged: forged ? 1 : undefined }, profile()));
    if (r.ok) { liveStop(); if (oldRoom) livePost(Object.assign({ a: "leave" }, oldRoom)); }
    if (!r.ok) {
      liveMsg(r.error || "Something went wrong.");
      //MC 2026-10-10 a challenge or link that can't be joined only wrote this under the room code box, often off screen
      //   on a phone, so the player saw nothing happen. Say it where they're looking too.
      if (viaInvite) toast(esc(r.error || "Something went wrong."));
      if (/name/i.test(r.error || "")) { me.name = ""; store("shy-lb-name", ""); refreshLiveCard(); }
      return;
    }
    liveMsg("");
    if (r.tgInvite) tgInviteBase = r.tgInvite;
    liveBegin({ code: r.code, seat: r.seat, secret: r.secret, kind: kind });
    //MC 2026-10-15 late join: say whose seat they took, so the hand and Regions they find aren't a surprise
    if (r.late) toast("You jumped in for <b data-i18n-skip>" + esc(r.late) + "</b>. Their hand and Regions are yours now, and the match counts for you.");
  }
  function liveBegin(c) {
    live = { code: c.code, seat: c.seat, secret: c.secret, kind: c.kind, ver: 0, offset: 0, n: 4, lastLog: 0, started: false,
      chain: Promise.resolve(), seenReacts: {}, seats: 0, tickAt: -1 };
    liveRemember();
    g = null; tip = null; sel = -1; busy = true; newCard = -1;
    $("g-start").hidden = true; $("g-end").hidden = true; $("g-targets").hidden = true;
    $("g-room").hidden = false;
    $("g-room-code").textContent = live.code;
    //MC 2026-10-10 a "calling you out" card for this same room is done once you're in it
    try { document.querySelectorAll('.fr-note [data-fr-join="' + live.code + '"]').forEach(function (b) { var n = b.closest(".fr-note"); if (n) n.remove(); }); } catch (e) {}
    if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true);
    //MC 2026-10-09 on desktop the room opened below the fold (Start match off screen at 1366x768). Scroll to it.
    try { if (!document.body.classList.contains("g-focus")) root.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {}
    sfx("join");
    livePoll();
  }
  // watching someone else's live match: the table from seat 1's side, no hand, no moves
  function startWatch(code) {
    code = String(code || "").toUpperCase();
    if (!/^[A-Z0-9]{5}$/.test(code)) return;
    liveStop();
    live = { code: code, seat: 0, secret: "", kind: "watch", watch: true, ver: 0, offset: 0, n: 4, lastLog: 0, started: false, chain: Promise.resolve(), seenReacts: {}, seats: 0, tickAt: -1 };
    g = null; tip = null; sel = -1; busy = true; newCard = -1;
    $("g-start").hidden = true; $("g-end").hidden = true; $("g-targets").hidden = true;
    root.classList.add("is-watch");
    watchBar("Watching room " + code, "");
    //MC 2026-10-09 watching a match gets full screen on phones and tablets too, like a replay.
    if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true);
    try { if (!document.body.classList.contains("g-focus")) root.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {}
    livePoll();
  }
  function watchEnd(v) {
    live.done = true;
    var res = v.result, st = res.standings, w = res.winners;
    var o = overlay("g-wend");
    var wr = liveRel(w[0]), wa = avatars[wr];
    o.innerHTML = '<div class="g-ov-in">' + (wa && wa.n && window.ShyLiving ? '<div class="g-pose au-' + esc(wa.au || "none") + '">' + living(wr, "win enter", matchMedia("(min-width:700px)").matches ? "190px" : "clamp(130px,40vw,160px)") + '<span class="gp-k">Shadow #' + esc(wa.n) + '</span></div>' : "") + '<span class="eyebrow">' + (v.tourney ? esc(v.tourney.name) : "Live match") + '</span><h2><span data-i18n-skip>' + esc(v.seats[w[0]].name.replace(" (bot)", "")) + '</span> ' + (w.length > 1 ? "shares the world." : "takes the match.") + '</h2>' +
      '<ul class="g-end-list">' + st.map(function (x, k) { return '<li><span>' + (k + 1) + '</span>' + avHTML(liveRel(x.i), "sm") + '<b data-i18n-skip>' + esc(String(x.name).replace(" (bot)", "")) + '</b><em>' + x.regions + (x.regions === 1 ? " Region" : " Regions") + '</em></li>'; }).join("") + '</ul>' +
      '<div class="btns"><button class="btn btn-red" data-game-start="live-quick">Play a live match</button><button class="btn btn-line" data-watch-stop>Back</button></div></div>';
    o.hidden = false;
  }
  function liveStop() {
    document.documentElement.classList.remove("g-playing");
    if (window.ShyDock) ShyDock.hide();   //MC 2026-10-15
    chatReset();
    if (!live) return;
    clearTimeout(live.timer);
    live = null;
    liveRemember();
    root.classList.remove("is-live");
    sealChip(null);
  }
  function liveQueue(v) {
    if (!live) return Promise.resolve();
    var my = live;
    my.chain = my.chain.then(function () { if (live === my && (v.ver > my.ver || !my.view)) return liveApply(v); }).catch(function () {});
    return my.chain;
  }
  async function livePoll() {
    if (!live) return;
    var my = live;
    clearTimeout(my.timer);
    var v = await livePost(my.watch ? { a: "watch", code: my.code, ver: my.ver } : Object.assign({ a: "state", ver: my.ver }, liveCreds()));
    if (live !== my) return;
    if (!v.ok) {
      if (!v.net && /not in this room|not found/i.test(v.error || "")) { liveEnd(my.kind === "tourney" ? "That table has finished, so your seat there is closed." : v.error); return; }
      my.errors = (my.errors || 0) + 1;
      if (my.errors === 3) toast("Connection is shaky. Reconnecting...");
    } else {
      my.errors = 0;
      my.offset = v.now - Date.now() / 1000;
      if (!v.same) await liveQueue(v);
    }
    if (live !== my) return;
    var st = my.view && my.view.status;
    my.timer = setTimeout(livePoll, st === "playing" ? 800 : st === "over" ? 2500 : 1200);
  }
  async function liveApply(v) {
    live.ver = v.ver; live.view = v; live.n = v.seats.length;
    if (window.SHYI18N) SHYI18N.addNames(v.seats.map(function (s) { return String(s.name || "").replace(" (bot)", "").replace(" (no show)", ""); }).concat(v.seats.map(function (s) { return String(s.name || ""); }).filter(function (n) { return / \(no show\)$/.test(n); })).concat(v.tourney ? [v.tourney.name] : []));
    //MC 2026-10-16 chat and reactions can never stop a match: a bad message or bubble used to throw here, before the
    //   board drew, and that player's table froze on the old state
    try { showReacts(v.reacts || []); } catch (e) {}
    try { showChat(v); } catch (e) {}   //MC 2026-10-12 live chat
    var eyes = $("g-eyes"); if (eyes) { eyes.hidden = !v.watchers; eyes.textContent = "👁 " + (v.watchers || 0); }
    sealChip(v.fair);   //MC 2026-10-15 the sealed deal, from the first turn
    if (v.status === "closed") { liveEnd("The host closed the room."); return; }
    if (v.status === "waiting") { if (live.watch) { watchBar("Room " + live.code + " hasn't started yet", "It starts when the host is ready."); return; } renderRoom(v); return; }
    var gm = v.game, firstLook = !live.started;
    //MC 2026-10-18 the Shogun speaks as the match opens: one line to this challenger, from their record against it
    //MC 2026-10-23 the Shogun dropped into this quick match: say so once, as the match opens
    if (v.shogunIn && firstLook && !live.watch && v.status === "playing") setTimeout(function () { toast('<b>The Shogun took a seat.</b> Same brain as the boss match. Finish ahead of it.'); sfx("match"); }, 1400);
    //MC 2026-10-23 the Shogun talks through the match (api/bosslib.php shogun_voice): each new line in a bubble under its seat.
    //   Read before the "nothing changed" check below, since a line alone doesn't change the board.
    if (v.say) {
      if (firstLook) live.sayN = v.say.n;   // a line said before this player looked isn't replayed
      else if (v.say.n !== live.sayN) { live.sayN = v.say.n; var sI = v.say.i, sT = String(v.say.t || ""), myL = live; setTimeout(function () { if (live === myL && g) talk(liveRel(sI), sT, Math.min(5200, 2600 + sT.length * 45)); }, 700); }
    }
    if (v.taunt && firstLook && !live.watch) { var tt = v.taunt; setTimeout(function () { toast('<b data-i18n-skip>The Shogun:</b> <span data-i18n-skip>「' + esc(tt) + '」</span>'); }, 900); }
    //MC 2026-10-16 a chat line or an emoji bumps the room version too, and every one of them redrew the whole table (hand,
    //   map, 3D table) for every player. With a few players sending emojis on a phone that was a redraw a second while
    //   the keyboard was up, enough for iPhones to drop the page. Now when only the chat or reactions changed, the
    //   board stays as it is.
    var sig = ""; try { sig = JSON.stringify([v.status, gm, v.seats, v.rematch || null, v.lateUntil || 0, v.tourney ? v.tourney.name : ""]); } catch (e) {}
    if (!firstLook && sig && sig === live.sig) return;
    live.sig = sig;
    if (firstLook) {
      live.started = true;
      $("g-room").hidden = true;
      root.classList.add("is-live");
      g = null; shown = 0; prevCounts = null; mapPrev = null; bountyNear = 0;
      track = { rounds: [], lastRound: 0, blocks: 0, lost: false, wasLast: false, played: {} }; spSeen = {}; spLast = "";
      if (v.status === "playing") { sfx("match"); banner("Match on", "daily"); if (!live.watch) live.introDue = true; }
      //MC 2026-10-15 the match started while they were looking around: the bar goes, the table comes back
      if (live.browsing || document.hidden) { if (window.ShyDock) { ShyDock.alertStart(); ShyDock.hide(); } live.browsing = false; if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true); try { root.scrollIntoView({ behavior: "auto", block: "start" }); } catch (e) {} }
      else if (window.ShyDock) ShyDock.hide();
    }
    var fresh = gm.log.filter(function (e) { return e.id > live.lastLog; }), myLive = live;
    //MC 2026-10-24 a Shadow arriving at a live table makes an entrance: yours when you first see the table, a rival's
    //   when their seat fills after that (seen seats are remembered on the live record)
    if (window.ShyShadowPlay && ShyShadowPlay.on()) {
      live.spSeen = live.spSeen || {};
      avatars.forEach(function (a, i) { if (!a || !a.n || a.trial || live.spSeen[a.n]) return; live.spSeen[a.n] = 1; if (i === 0 ? firstLook : !firstLook) live.chain = live.chain.then(function () { return ShyShadowPlay.play({ root: root, n: a.n, au: a.au, kind: "enter", mirror: i !== 0, name: i === 0 ? (me.name || "You") : a.label }); }); });
    }
    if (!firstLook) {
      for (var i = 0; i < fresh.length; i++) {
        var e = fresh[i];
        if (e.kind === "play" && e.card) {
          if (e.who === live.seat && live.flashedOwn) { live.flashedOwn = false; continue; }
          await flash(liveRel(e.who), e.card);
          if (live !== myLive) return;   //MC 2026-10-11 another game started during the card flash
        }
      }
    }
    var handBefore = g ? g.players[0].hand.length : 0;
    var from = g ? g.log.length : 0;
    liveMap(v, fresh);
    if (!firstLook && fresh.length) sfxFor(from);
    var mine = !live.watch && v.status === "playing" && gm.turn === live.seat && gm.phase === "act";
    if (mine && !live.mine) {
      sel = -1; tipKey = "";
      newCard = g.players[0].hand.length > handBefore ? g.players[0].hand.length - 1 : -1; drawAnim = newCard >= 0;
      sfx("turn"); buzz(10);
      if (newCard >= 0) setTimeout(function () { sfx("draw"); }, 260);
    }
    if (!mine) { sel = -1; newCard = -1; $("g-targets").hidden = true; }
    live.mine = mine;
    busy = !mine || !!live.sending;
    render();
    if (live.introDue) { live.introDue = false; intro(); }
    if (mine && newCard >= 0) scrollToCard(newCard);
    if (!firstLook && v.status === "playing") {
      var lf = gm.deck, ln = v.seats.length;
      if (!live.endgame && lf <= ln * 2 && lf > ln) { live.endgame = true; banner("Endgame: " + lf + " Regions left", "final"); }
      if (!live.lastShown && lf && lf <= ln) { live.lastShown = live.endgame = true; banner(lf === 1 ? "Last Region" : "Last " + lf + " Regions", "final"); }
    }
    if (live.watch && firstLook) watchBar((v.tourney ? v.tourney.name + " · " : "") + "Watching live", v.seats.map(function (x) { return x.name.replace(" (bot)", ""); }).join(" · "));
    if (live.watch) lateJump(v);
    //MC 2026-10-23 the final board holds a moment before the results (see endHold); joining a match already over goes straight there
    if (v.status === "over" && !live.done && !live.ending) {
      live.ending = true;
      var lv = live, endIt = function () { if (live !== lv || lv.done) return; if (lv.watch) watchEnd(v); else liveFinish(v); };
      if (firstLook) endIt(); else endHold(2200).then(endIt);
    }
    if (v.status === "over" && v.rematch && live.done) offerRematch(v.rematch);
  }
  function liveMap(v, fresh) {
    var gm = v.game, n = v.seats.length, order = [];
    for (var k = 0; k < n; k++) order.push(liveAbs(k));
    avatars = order.map(function (abs) { var s = v.seats[abs]; if (s.img && s.avatar) NFTIMG[s.avatar] = s.img; return { label: abs === live.seat && !live.watch ? (me.name || "You") : s.name.replace(" (bot)", ""), src: s.img || avatarSrc(s.avatar, s.name, s.human, s.cos), hue: !s.human && !s.img ? maskHue(s.name) : 0, look: s.aura ? lookCls(s.aura, s.cos && s.cos.halo) : "", n: s.aura && s.avatar ? String(s.avatar) : "", au: s.aura || "" }; });
    spPrep();
    var myName = String(gm.players[live.seat].name || "").replace(/ \(bot\)$/, "");
    var players = order.map(function (abs, k) {
      var p = gm.players[abs], s = v.seats[abs];
      return { name: k === 0 && !live.watch ? "You" : p.name.replace(" (bot)", ""), bot: k !== 0 || live.watch, style: s.human ? (s.away ? "away" : "live") : (s.style || p.style || ""),
        regions: p.regions, hand: k === 0 ? (live.watch ? [] : gm.hand.slice()) : new Array(p.hand).fill("x"), shield: p.shield, skip: p.skip, lone: !!p.lone, paper: !!p.paper, harvest: p.harvest || 0, holder: !!s.holder, cos: s.cos || {} };
    });
    if (!g || !g.online) { g = { online: true, log: [] }; shown = 0; $("g-log").innerHTML = ""; prevCounts = null; }
    g.round = gm.round; g.turn = liveRel(gm.turn); g.start = liveRel(gm.start); g.over = v.status === "over";
    g.regionDeck = new Array(gm.deck); g.regionDiscard = gm.discardList || new Array(gm.discard); g.players = players;
    g.plays = gm.plays || 0; g.played = !!gm.played; g.truce = gm.truce != null && gm.truce >= 0 ? liveRel(gm.truce) : -1;
    if (gm.season) G.useSeason(gm.season);
    g.finalRound = g.finalRound || gm.deck <= n;
    // one entry per round for the share grid, plus a final one when the match ends
    if (track && (gm.round !== track.lastRound || (g.over && !track.endSnap))) {
      track.lastRound = gm.round; if (g.over) track.endSnap = true;
      track.rounds.push(players[0].regions.length);
    }
    var shield = live.watch || !fresh.length ? null : nameShield(myName, gm.players.map(function (p) { return String(p.name || "").replace(/ \(bot\)$/, ""); }));
    fresh.forEach(function (e) {
      if (e.kind === "block" && e.who === live.seat && track) track.blocks++;
      var tx = String(e.text || "").replace(/ \(bot\)/g, "");
      g.log.push({ who: e.who == null ? null : liveRel(e.who), text: shield ? youName(tx, myName, shield) : tx, kind: e.kind });
      live.lastLog = Math.max(live.lastLog, e.id);
    });
  }
  //MC 2026-10-11 your name in a live log line becomes "You". It was a plain split/join, so a name that sits inside
  //   another name or a card ("Ronin": "Neon Ronin plays Ronin for Hire.") broke the line into "Neon You plays You for
  //   Hire.". Now any seat name, card or Region that contains your name is set aside first, and your name is only
  //   replaced as a whole word. Tried whole-word matching alone first: "Ronin" is a whole word in both of those.
  function nameShield(myName, seats) {
    if (!myName) return null;
    var all = seats.concat(Object.keys(G.CARDS).map(function (k) { return G.CARDS[k].name; }), G.REGIONS);
    return all.filter(function (n, i) { return n && n !== myName && n.indexOf(myName) >= 0 && all.indexOf(n) === i; })
      .sort(function (a, b) { return b.length - a.length; });
  }
  function youName(text, myName, shield) {
    if (!myName || text.indexOf(myName) < 0) return text;
    var kept = [];
    shield.forEach(function (n) { if (text.indexOf(n) >= 0) { text = text.split(n).join("\u0001" + kept.length + "\u0002"); kept.push(n); } });
    text = text.replace(new RegExp("(^|[^\\w])" + myName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?![\\w])", "g"), "$1You");
    return text.replace(/\u0001(\d+)\u0002/g, function (m, i) { return kept[+i]; });
  }
  async function liveAct(action) {
    if (!live || live.sending || !live.mine) return;
    var myLive = live;
    live.sending = true; busy = true;
    $("g-targets").hidden = true;
    var playedId = action.pass ? null : g.players[0].hand[action.hand];
    render();
    if (playedId) { live.flashedOwn = true; track.played[playedId] = 1; flash(0, playedId); }
    var r = await livePost(Object.assign({ a: "act" }, liveCreds(), action));
    if (!live || live !== myLive) return;
    live.sending = false;
    if (!r.ok) {
      live.flashedOwn = false;
      toast(r.error || "That move didn't go through.");
      busy = !live.mine; render();
      return;
    }
    sel = -1; newCard = -1;
    await liveQueue(r);
  }
  // room lobby
  //MC 2026-10-15 the waiting room, made into a table: four seats around a felt with the countdown ring and how many are
  //   in, a seat that flips in with a burst when someone sits down, empty seats that sweep like a radar, a card to study
  //   while you wait, Wait for real players on a quick match, and Look around while you wait (the room bar, roomdock.js,
  //   keeps your seat while you scroll the page or open any other page). A player asked for this one.
  function renderRoom(v) {
    var list = $("g-room-seats"), html = "", prev = live.seatNames || null, names = [];
    var SZ = v.size === 2 ? 2 : 4;   //MC 2026-10-18 a 1v1 table has two chairs
    list.classList.toggle("duo", SZ === 2);
    for (var i = 0; i < SZ; i++) {
      var s = v.seats[i];
      if (s) {
        names.push(s.name);
        var just = prev && prev.indexOf(s.name) < 0 && i !== live.seat;
        html += '<li class="wr-s' + i + (i === live.seat ? " me" : "") + (s.human ? "" : " bot") + (just ? " just" : "") + '"><span class="g-av' + (s.aura ? lookCls(s.aura, s.cos && s.cos.halo) : "") + '" style="background:' + COLORS[i] + '">' + '<img src="' + (s.img || avatarSrc(s.avatar, s.name, s.human, s.cos)) + '" alt="" onerror="this.remove()">' + '<span class="g-av-txt">' + esc(s.name.charAt(0)) + '</span></span><b data-i18n-skip>' + esc(s.name) + '</b><em>' + (i === live.seat ? "You" : i === 0 && !v.public ? "Host" : s.human ? "Ready" : "Bot") + (v.forged && v.deckNames && v.deckNames[i] ? ' · <span data-i18n-skip>' + esc(v.deckNames[i]) + '</span>' : "") + '</em></li>';
      }
      else html += '<li class="wr-s' + i + ' empty"><span class="g-av"><i class="wr-radar" aria-hidden="true"></i></span><b>' + (v.public ? (SZ === 2 ? "Searching for a rival..." : "Searching...") : "Open seat") + '</b><em>' + (SZ === 2 ? "Real players only" : v.public ? "Bot if empty" : "Invite a friend") + '</em></li>';
    }
    list.innerHTML = html;
    // someone new sat down: the chime here, and the full alert (buzz, tab title, notification) if you're looking elsewhere
    if (prev) {
      var fresh = v.seats.filter(function (x, k) { return x.human && k !== live.seat && prev.indexOf(x.name) < 0; });
      if (fresh.length) {
        var humans = v.seats.filter(function (x) { return x.human; }).length;
        if (live.browsing || document.hidden) { if (window.ShyDock) ShyDock.alertJoin(String(fresh[0].name), humans, SZ); }
        else sfx("join");
      }
    }
    live.seatNames = names;
    live.seats = v.seats.length;
    $("g-room-k").textContent = (v.tourney ? v.tourney.name + ", " + (v.tourney.final ? "final table" : "round " + (v.tourney.round + 1)) : v.public ? (SZ === 2 ? "1v1 quick match" : "Quick match") : SZ === 2 ? "Private 1v1" : "Private room") + (v.forged ? " · Forged" : "");
    var sb = $("g-room-start");
    sb.hidden = !(v.host && !v.public && !v.tourney);
    //MC 2026-10-18 a 1v1 never fills with bots, so Start waits for the rival
    var hcount = v.seats.filter(function (x) { return x.human; }).length;
    sb.disabled = SZ === 2 && hcount < 2;
    sb.textContent = SZ === 2 && hcount < 2 ? "Waiting for your rival..." : "Start match";
    $("g-room-share").hidden = v.public || !!v.tourney;
    var hb = $("g-room-hold");
    if (hb) { hb.hidden = !(v.public && !v.tourney && (v.canHold || v.held)); hb.disabled = !v.canHold; hb.textContent = v.canHold ? (v.held ? "Wait another minute" : "Wait for real players (+1 min)") : "Waiting as long as we can"; }
    roomStatus();
    roomSpot();
    roomDockWatch();
  }
  function roomStatus() {
    if (!live || !live.view || live.view.status !== "waiting") return;
    var v = live.view, st = $("g-room-status"), h;
    if (v.tourney) h = esc("Starts when everyone is here, or in " + clock(v.startsAt - serverNow()) + " with a bot for anyone missing.");
    //MC 2026-10-11 each sentence in its own span so the translations find them; the clock was inside one long sentence,
    //   which never matched a translation (German showed it in English with the line under it in German). Written only
    //   when it changes (once a second for the clock, not on every 250ms tick), so a translation isn't thrown away 4x a second.
    else if (v.public && v.size === 2) h = '<span>Waiting for a rival.</span> <span>The match starts the moment one sits down.</span> <span>Real players only, no bots.</span>'
      + '<small class="g-room-lg">' + (v.seats.filter(function (x) { return x.human; }).length > 1 ? "" : "Tip: call in a friend below, or share the room code.") + '</small>';
    else if (v.public) h = '<span>Finding players.</span> <span>Starting in ' + esc(clock(v.startsAt - serverNow())) + '.</span> <span>Bots fill any empty seats.</span>' + '<small class="g-room-lg">' + (v.seats.filter(function (x) { return x.human; }).length < 2 ? "It counts as a League game once another real player joins." : "Another real player is here, so this one counts for the League.") + '</small>';
    else if (v.host && v.size === 2) h = esc(v.seats.filter(function (x) { return x.human; }).length > 1 ? "Your rival is in. Press Start." : "Share the link or call in a friend. The match starts when your rival sits down.");
    else if (v.host) h = esc(v.seats.length > 1 ? "Ready when you are. Bots fill the empty seats." : "Share the link with friends, then press Start.");
    else h = esc("Waiting for the host to start the match.");
    put(st, h);
    // the felt in the middle of the table: how many are in and, on a timed room, the countdown ring
    var humans = v.seats.filter(function (x) { return x.human; }).length, left = v.startsAt ? v.startsAt - serverNow() : null;
    var cnt = $("g-room-count"); if (cnt) cnt.textContent = v.seats.length + "/" + (v.size === 2 ? 2 : 4);
    var ck = $("g-room-clock"); if (ck) ck.textContent = left != null ? clock(left) : humans > 1 ? humans + " players" : "waiting";
    var fg = $("g-room-ringfg");
    if (fg) {
      if (left != null) { live.ringTotal = Math.max(live.ringTotal || 0, left, 1); fg.style.strokeDashoffset = String(Math.round(339 * (1 - Math.max(0, left) / live.ringTotal))); }
      else fg.style.strokeDashoffset = String(Math.round(339 * (1 - v.seats.length / (v.size === 2 ? 2 : 4))));
      fg.parentNode.parentNode.classList.toggle("low", left != null && left <= 10);
    }
    if (window.ShyDock && live.browsing) ShyDock.show(dockState(v), roomBack, roomLeaveFromDock);
  }
  // ---- while you wait: one card at a time to study, turning by itself
  function roomSpot() {
    var box = $("g-room-spot"); if (!box || box.dataset.on) return;
    box.dataset.on = "1";
    var ids = (G.DECK || Object.keys(G.CARDS)).filter(function (k, i, all) { return G.CARDS[k] && G.CARDS[k].text && all.indexOf(k) === i; });   // the 71 cards of the deck
    for (var i = ids.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
    var at = 0, timer = 0;
    var kindName = { attack: "Attack", defense: "Defense", gain: "Gain", chaos: "Chaos", wild: "Wild" };
    function draw() {
      var c = G.CARDS[ids[at]];
      box.innerHTML = '<span class="wr-spot-k">While you wait · Know your cards</span><div class="wr-card"><img src="' + cardArt(ids[at]) + '" alt="" loading="lazy"><div><small class="wr-kind k-' + esc(c.kind) + '">' + esc(kindName[c.kind] || c.kind) + '</small><b>' + esc(c.name) + '</b><p>' + esc(c.text) + '</p></div></div>' +
        '<div class="wr-spot-nav"><button type="button" data-wr-spot="-1" aria-label="Previous card">&lsaquo;</button><span>' + (at + 1) + ' / ' + ids.length + '</span><button type="button" data-wr-spot="1" aria-label="Next card">&rsaquo;</button></div>';
    }
    function go(d) { at = (at + d + ids.length) % ids.length; draw(); clearInterval(timer); timer = setInterval(function () { if (!live || !live.view || live.view.status !== "waiting") { clearInterval(timer); return; } at = (at + 1) % ids.length; draw(); }, 9000); }
    box.addEventListener("click", function (e) { var b = e.target.closest("[data-wr-spot]"); if (b) go(+b.dataset.wrSpot); });
    go(0);
  }
  // ---- look around while you wait: the room bar takes over whenever the room is out of sight
  function dockState(v) {
    return { code: live.code, seats: v.seats.map(function (x, i) { return { name: x.name, img: x.img || avatarSrc(x.avatar, x.name, x.human, x.cos), human: x.human, me: i === live.seat }; }), n: 4,
      startsAt: v.startsAt || 0, offset: live.offset || 0, host: !!v.host, status: v.status };
  }
  function roomBack() {
    if (!live) return;
    live.browsing = false;
    if (window.ShyDock) ShyDock.hide();
    if (autoFocusDevice() && !document.body.classList.contains("g-focus")) toggleFocus(true);
    try { root.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {}
  }
  function roomLeaveFromDock() { if (window.ShyDock) ShyDock.hide(); var b = $("g-room-leave"); if (b) b.click(); }
  var roomIO = null;
  function roomDockWatch() {
    if (roomIO || !("IntersectionObserver" in window)) return;
    var box = $("g-room").querySelector(".g-ov-in");
    roomIO = new IntersectionObserver(function (es) {
      if (!live || !live.view || live.view.status !== "waiting" || live.watch) { if (window.ShyDock) ShyDock.hide(); return; }
      var seen = es[0].isIntersecting && !$("g-room").hidden;
      live.browsing = !seen;
      if (window.ShyDock) { if (seen) ShyDock.hide(); else ShyDock.show(dockState(live.view), roomBack, roomLeaveFromDock); }
    }, { threshold: 0.08 });
    roomIO.observe(box);
  }
  function inviteLink() {
    // inside Telegram, invites open the game in Telegram straight into the room
    if (window.SHY_TG && window.SHY_TG.invite && live) return window.SHY_TG.invite + live.code;
    return location.origin + location.pathname.replace(/\.html$/, "") + "?room=" + (live ? live.code : "");
  }
  //MC 2026-10-11 the Telegram invite: one tap sends the room code with a link that opens the game in Telegram and joins
  //   the room at once (startapp=join_CODE), plus the web link for anyone not on Telegram. Before, the button shared
  //   only the website link and friends had to copy the code by hand. The mini app link comes from the room's server
  //   reply (tgInvite), so it works from the website too, not only inside Telegram.
  var tgInviteBase = "";
  function tgInviteText() {
    var web = location.origin + location.pathname.replace(/\.html$/, "") + "?room=" + live.code + "&go=1";
    var tg = tgInviteBase ? tgInviteBase + live.code : "";
    return { url: tg || web, text: "Join my Shilluminati Online match. Room code " + live.code + "." + (tg ? "\nOn the web: " + web : "") };
  }
  function tgOpen(url) {
    var W = window.Telegram && window.Telegram.WebApp;
    if (W && W.initData && W.openTelegramLink) W.openTelegramLink(url); else open(url, "_blank", "noopener");
  }
  // reactions
  function showReacts(list) {
    list.forEach(function (r) {
      if (live.seenReacts[r.id]) return;
      live.seenReacts[r.id] = 1;
      if (live.started) bubble(liveRel(r.seat), REACTS[r.e]);
    });
  }
  function bubble(rel, emoji) {
    var anchor = rel === 0 ? $("g-me-av") : $("g-riv-" + rel);
    if (!anchor || !emoji) return;
    var a = anchor.getBoundingClientRect(), b = root.getBoundingClientRect();
    var el = document.createElement("span");
    el.className = "g-bubble"; el.textContent = emoji;
    el.style.left = (a.left - b.left + a.width / 2) + "px"; el.style.top = (a.top - b.top + root.scrollTop) + "px";
    root.appendChild(el);
    setTimeout(function () { el.remove(); }, 2400);
  }
  //MC 2026-10-15 provably fair: a live match's deal is sealed before the first turn (api/fairlib.php). The seal sits in
  //   the map header the whole match; the end screen links to the Fair page, which opens it and rebuilds the deal.
  function sealChip(f) {
    var el = $("g-seal");
    if (!f || !f.seal) { if (el) el.remove(); return; }
    if (!el) {
      var host = $("g-deck"); if (!host || !host.parentNode) return;
      el = document.createElement("a"); el.id = "g-seal"; el.className = "g-seal"; el.target = "_blank"; el.rel = "noopener";
      host.parentNode.appendChild(el);
    }
    if (el.dataset.s === f.seal + (f.seed ? "o" : "")) return;
    el.dataset.s = f.seal + (f.seed ? "o" : "");
    el.href = "/fair?m=" + encodeURIComponent(f.id);
    el.title = f.seed ? "The deal is open now. Tap to check it." : "This deal was sealed before the first turn: " + f.seal;
    el.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="7" width="10" height="7" rx="1.5"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg><span>' + (f.seed ? "Verify deal" : "Sealed") + '</span><code data-i18n-skip>' + esc(f.seal.slice(0, 6)) + '</code>';
  }
  // end of a live match
  function liveFinish(v) {
    live.done = true;
    var res = v.result, mineR = res.seats[live.seat], won = mineR.result !== "loss";
    var humansIn = v.seats.filter(function (s) { return s.human; }).length;
    stats.games++;
    if (mineR.result === "win") { stats.wins++; stats.streak++; } else stats.streak = 0;
    stats.bestStreak = Math.max(stats.bestStreak, stats.streak);
    stats.best = Math.max(stats.best, mineR.regions);
    stats.live = (stats.live || 0) + 1;
    Object.keys(track.played).forEach(function (id) { stats.cards[id] = 1; });
    var earned = [];
    function award(id, ok) { if (ok && !stats.badges[id]) { stats.badges[id] = Date.now(); earned.push(id); } }
    award("initiated", true);
    award("leader", mineR.result === "win");
    award("duelist", mineR.result === "win" && humansIn > 1);
    award("crew", !v.public && humansIn > 1);
    award("empire", mineR.regions >= 10);
    award("shadowempire", mineR.regions >= 13);
    award("untouchable", track.blocks >= 2);
    award("onfire", stats.streak >= 3);
    award("collector", Object.keys(stats.cards).length >= 12);
    award("regular", stats.games >= 25);
    saveStats(); renderProfile();

    var w = res.winners.map(liveRel);
    if (window.ShyEco && ShyEco.onGame && mineR.eco) ShyEco.onGame(mineR.eco, mineR.league ? { gain: mineR.league } : (mineR.lwhy ? { miss: mineR.lwhy } : null));
    $("g-end-k").textContent = v.tourney ? v.tourney.name + ", " + (v.tourney.final ? "final table" : "round " + (v.tourney.round + 1)) : v.boss ? "Boss match" : v.public ? "Live match" : "Private match";
    setTimeout(function () { eggEnd(mineR.result); }, 0);   //MC 2026-10-13
    if (v.tourney) { $("g-rematch").hidden = true; setTimeout(function () { document.dispatchEvent(new CustomEvent("shy:tourney-end", { detail: v.tourney })); }, 400); }
    rankLine(mineR.rk);
    if (mineR.eco && mineR.eco.rankRewards && mineR.eco.rankRewards.length) { var rr = mineR.eco.rankRewards[0]; setTimeout(function () { toast("Season " + rr.s + " ranked reward: " + RANKS[rr.tier] + ", +" + rr.koban + " Koban" + (rr.item ? " and a new title" : "")); }, 900); }
    $("g-end-title").textContent = v.boss ? (mineR.result === "win" ? "You beat the Shogun." : mineR.result === "tie" ? "A draw with the Shogun." : "The Shogun wins this one.") :
      mineR.result === "win" ? "You won the match." : mineR.result === "tie" ? "You share the world." : g.players[w[0]].name.replace(" (bot)", "") + " takes the match.";
    var topRegions = res.standings[0].regions, topRel = liveRel(res.standings[0].i);
    //MC 2026-10-11 one span per sentence, like the solo end screen (10-09): joined into one string the line never matched
    //   a translation and stayed English in every language
    $("g-end-sub").innerHTML = [endReason(v.game ? v.game.deck : 0, topRegions, topRel === 0 ? "You" : res.standings[0].name.replace(" (bot)", "")), tieNote(res.standings).trim(),
      v.boss ? "" : (won ? (humansIn > 1 ? "Real players, real win. It's on the Live leaderboard." : "Nobody else showed up, but a win is a win.") : mineR.regions === topRegions ? "So close." : "Close one. Run it back?")]
      .concat(v.boss ? bossLine(mineR.boss, won) : []).filter(Boolean).map(function (t) { return "<span>" + esc(t) + "</span>"; }).join(" ");
    $("g-end-list").innerHTML = res.standings.map(function (x, k) {
      var rel = liveRel(x.i);
      return '<li' + (rel === 0 ? ' class="me"' : "") + '><span>' + (k + 1) + '</span>' + avHTML(rel, "sm") + '<b>' + esc(rel === 0 ? (me.name || "You") : x.name.replace(" (bot)", "")) + '</b><em>' + x.regions + (x.regions === 1 ? ' Region' : ' Regions') + (tied(res.standings, x) ? ' <small>' + x.hand + ' cards</small>' : '') + '</em></li>';
    }).join("");
    var bonus = mineR.result !== "loss" && humansIn > 1 ? 20 * (humansIn - 1) : 0;
    $("g-breakdown").innerHTML = '<span>' + mineR.regions + (mineR.regions === 1 ? ' Region' : ' Regions') + ' x 5 = ' + mineR.regions * 5 + '</span>' +
      (mineR.result === "win" ? '<span>Win +100</span>' : mineR.result === "tie" ? '<span>Tie +50</span>' : "") +
      (bonus ? '<span>Real opponents +' + bonus + '</span>' : "") + '<b>+' + mineR.points + ' points</b>';
    if (v.boss) $("g-breakdown").innerHTML = '<span>Boss matches go on your Shogun record only, not the leaderboards.</span>';   //MC 2026-10-12
    if (v.fair && v.fair.seed) $("g-breakdown").insertAdjacentHTML("beforeend", '<a class="g-fair-link" href="/fair?m=' + encodeURIComponent(v.fair.id) + '" target="_blank" rel="noopener">This deal was sealed before the first turn. Check it</a>');
    $("g-unlocks").innerHTML = earned.map(function (id) {
      var b = BADGES.filter(function (x) { return x.id === id; })[0];
      return '<span class="g-unlock"><i>' + b.icon + '</i>' + esc(b.name) + '</span>';
    }).join("");
    $("g-save").hidden = true;
    // real players at the table can be added as friends from here
    var af = $("g-addfr"), others = v.seats.filter(function (x, i) { return x.human && x.tag && i !== live.seat; }).map(function (x) { return { tag: x.tag, name: x.name }; });
    if (af) { af.innerHTML = others.length && window.ShyFriends ? ShyFriends.addChips(others) : ""; af.hidden = !af.innerHTML; }
    setLbMsg(v.boss ? "Added to your record against the Shogun." : "Recorded on the Live leaderboard.", true);
    $("g-record").textContent = stats.wins + " " + (stats.wins === 1 ? "win" : "wins") + " in " + stats.games + " " + (stats.games === 1 ? "game" : "games") + ". " + badgeCount() + "/" + BADGES.length + " badges.";
    var share = resultPost({ kind: "live", boss: !!v.boss, result: mineR.result, mine: mineR.regions, humans: humansIn, rounds: (v.game && v.game.round) || track.lastRound || 0,
      blocks: track.blocks, comeback: track.wasLast, cards: Object.keys(track.played).length,
      standings: res.standings.map(function (x) { var rel = liveRel(x.i); return { n: rel === 0 ? (me.name || "You") : x.name.replace(" (bot)", ""), r: x.regions, h: x.hand, me: rel === 0 }; }) });
    shareSetup({ kind: "live", boss: !!v.boss, result: mineR.result, regions: mineR.regions, mode: "normal", dailyNo: 0, humans: humansIn,
      standings: res.standings.map(function (x) { var rel = liveRel(x.i); return { n: rel === 0 ? (me.name || "You") : x.name.replace(" (bot)", ""), r: x.regions, c: rel, me: rel === 0 }; }) },
      share);
    $("g-again").textContent = v.boss ? "Find a live match" : "Find another match";
    $("g-end-daily").hidden = true;
    $("g-rematch").hidden = v.public || !!v.tourney;
    $("g-rematch").textContent = v.boss ? "Challenge the Shogun again" : "Rematch";
    if (v.boss) { lastMode = "live-quick"; if (mineR.boss && mineR.boss.koban) setTimeout(function () { toast("+" + fmtN(mineR.boss.koban) + " Koban for beating the Shogun"); }, 900); bossCard(); }
    endMap(); shadowNote(); shadowEnd(w[0]); bountyEnd(mineR.regions, mineR.result !== "loss"); if (mineR.bounty) bountyResult(mineR.bounty);
    $("g-end").hidden = false; $("g-end").scrollTop = 0;
    if (mineR.result === "win") { victory(); sfx("win"); buzz([20, 60, 20, 60, 40]); }
    spEnd(mineR.result === "win", w[0] != null ? w[0] : -1);
    if (mineR.result !== "win") {
      sfx("lose");
      //MC 2026-10-10 the winner's victory effect plays for everyone at the table, so a rival sees what you bought
      var wcos = w.length === 1 && w[0] !== 0 && g.players[w[0]] && g.players[w[0]].cos;
      if (wcos && wcos.fx && /^[a-z]+$/.test(wcos.fx)) setTimeout(function () { fxRun(wcos.fx); }, 500);
    }
    if (earned.length) setTimeout(function () { sfx("badge"); }, 700);
    store("shy-live", "");
    loadBoard("live");
  }
  function offerRematch(code) {
    if (live.rematchShown === code) return;
    live.rematchShown = code;
    var b = $("g-rematch");
    b.hidden = false; b.textContent = "Join the rematch";
    b.dataset.code = code;
    toast("Rematch ready. Tap to join.");
  }
  async function rematch() {
    if (!live) return;
    var b = $("g-rematch");
    if (b.dataset.code) { var c = b.dataset.code; b.dataset.code = ""; return liveStart("live-join", c); }
    var r = await livePost(Object.assign({ a: "rematch" }, liveCreds(), profile()));
    if (!r.ok) { toast(r.error || "Couldn't open a rematch."); return; }
    if (r.rematch && r.secret) liveBegin({ code: r.rematch, seat: r.seat, secret: r.secret, kind: "live-create" });
    else if (r.rematch) liveStart("live-join", r.rematch);
  }
  function liveEnd(msg) {
    liveStop();
    if (msg) toast(msg);
    g = null;
    $("g-room").hidden = true;
    showMenu();
  }
  // matches on right now that anyone can watch, under the Live card
  async function loadWatchList() {
    var box = $("g-watchlist"); if (!box || (g && !g.over) || live) return;
    var j; try { j = await (await fetch(LIVE_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "rooms" }) })).json(); } catch (e) { return; }
    if (!j || !j.ok || !j.rooms.length) { box.hidden = true; return; }
    box.innerHTML = '<span class="g-wl-k"><i class="g-live-dot"></i>Watch live</span>' + j.rooms.slice(0, 4).map(function (r) {
      var lead = r.seats.slice().sort(function (a, b) { return b.regions - a.regions; })[0];
      return '<button class="g-wl" data-watch="' + esc(r.code) + '"><b>' + (r.tourney ? esc(r.tourney) + (r.final ? " · Final" : "") : "Quick match") + '</b><small data-i18n-skip>' + r.seats.filter(function (x) { return x.human; }).map(function (x) { return esc(x.name); }).join(" vs ") + '</small><em>Round ' + r.round + ' · ' + esc(lead.name) + ' leads with ' + lead.regions + '</em>' + (r.watchers ? '<span class="g-wl-eye">👁 ' + r.watchers + '</span>' : "") + (r.open ? '<span class="g-wl-seat">Seat open</span>' : "") + '</button>';
    }).join("");
    box.hidden = false;
  }
  setInterval(function () { if (!document.hidden && !$("g-start").hidden) loadWatchList(); }, 20000);
  //MC 2026-10-12 the Shogun: its card on the start screen (reward, your record, how many have beaten it) and the line
  //   on the results screen that says what a boss win paid, or why it didn't
  function fmtN(n) { return Number(n || 0).toLocaleString("en-US"); }
  // one sentence per entry, so each one matches its translation
  function bossLine(b, won) {
    if (!b) return [won ? "You beat the Shogun." : "It doesn't make mistakes often. Run it back?"];
    var rec = b.record ? "Your record against it: " + b.record[0] + "-" + (b.record[1] - b.record[0]) + "." : "";
    //MC 2026-10-18 the Shogun gets the last word on every result, in its own voice, keyed to this player's record
    var say = b.taunt ? "「" + b.taunt + "」" : "";
    if (b.won && b.koban) return ["+" + fmtN(b.koban) + " Koban for the win.", rec, say];
    if (b.won && b.why === "covered") return ["A bot covered " + (b.cov > 1 ? b.cov + " of your turns" : "your turns") + ", so this win doesn't pay boss Koban or reach the chat.", "One covered turn is forgiven; keep the match in hand and the next one pays.", rec];
    if (b.won && b.why === "already") return [b.per === "week" ? "This week's boss Koban is already yours." : "Today's boss Koban is already yours.", "The win still counts on your record.", rec, say];
    if (b.won && b.why === "weekcap") return ["The week's " + (b.wcap || 3) + " bounties are all claimed.", "The win still counts on your record. Fresh bounties Monday.", rec, say];
    return [say || "It doesn't make mistakes often. Run it back?", rec];
  }
  async function bossCard() {
    var el = $("g-boss"); if (!el) return;
    var j = await livePost({ a: "bossinfo", pid: me.pid });
    if (!j.ok || !j.boss || !j.boss.on) { el.hidden = true; return; }
    var b = j.boss;
    var sp = function (l) { return l.filter(Boolean).map(function (t) { return "<span>" + esc(t) + "</span>"; }).join(" "); };
    //MC 2026-10-18 the weekly bounty cap on the card: how many of the week's paid wins are left, and plain words
    //   when they're spent, so the cap never reads like a broken payout
    var weekOut = b.wcap && b.wleft === 0;
    $("g-boss-sub").innerHTML = sp([b.koban ? (b.open ? (b.per === "week" ? "Beat it for " + fmtN(b.koban) + " Koban, once a week." : "Beat it for " + fmtN(b.koban) + " Koban, once a day.") : (weekOut ? "The week's " + b.wcap + " bounties are claimed. Fresh ones Monday." : b.per === "week" ? "You've claimed this week's " + fmtN(b.koban) + " Koban." : "You've claimed today's " + fmtN(b.koban) + " Koban.")) : "",
      b.koban && b.open && b.wcap ? "Bounties left this week: " + b.wleft + " of " + b.wcap + "." : "",
      b.koban && !b.open ? "Wins still count." : "", "A 1v1 against the hardest bot in Shilluminati.", b.edge ? (b.edge === 1 ? "It starts with 1 extra card." : "It starts with " + b.edge + " extra cards.") : ""]);
    //MC 2026-10-13 matches used today against the team's daily cap (3/10 today), asked for by the team: the cap is a
    //   setting, so the card always says the number it is right now. The line turns into "all used" at the cap.
    var capLine = b.max ? (b.today >= b.max ? "All " + b.max + " matches for today are used. Come back tomorrow." : "Matches today: " + (b.today || 0) + "/" + b.max + ".") : "";
    $("g-boss-rec").innerHTML = sp([b.me[1] ? "Your record: " + b.me[0] + "-" + (b.me[1] - b.me[0]) + "." : "", capLine, b.beaten ? (b.beaten === 1 ? "1 player has beaten it." : fmtN(b.beaten) + " players have beaten it.") : "Nobody has beaten it yet."]);
    el.classList.toggle("open", !!(b.koban && b.open));
    //MC 2026-10-13 beat it once and the panel admits there is more: the avatar burns red and one line is added
    //MC 2026-10-18 from the third win the line changes: the Shogun remembers this challenger and thinks longer
    el.classList.toggle("final-form", (b.me[0] || 0) >= 1);
    if (b.mem > 0) $("g-boss-rec").innerHTML += ' <span class="egg-ff">The Shogun remembers you. It thinks longer against your game now.</span>';
    else if ((b.me[0] || 0) >= 1) $("g-boss-rec").innerHTML += ' <span class="egg-ff">You have not seen its final form.</span>';
    //MC 2026-10-13 a mask replaced in the admin shows here at once: the server sends the mask file's time, and a
    //   changed time becomes a new image address, past any cached copy (the 504-era week cache held old masks for days)
    var bav = el.querySelector(".g-boss-av");
    if (bav && b.maskv) { var want = "/assets/art/masks/shogun.svg?mv=" + b.maskv; if (bav.getAttribute("src") !== want) bav.setAttribute("src", want); }
    el.hidden = false;
    bossShare(b.last);
  }
  //MC 2026-10-12 "Share your win": the end screen is the only place a result could be shared from, and once it closed a win
  //   over the Shogun was unshareable (asked for after a real win). The Play page's Shogun panel now offers the player's own
  //   last win over it (within a day, from the server's record). The map on the card is drawn from the score alone, since
  //   the real board is gone with the room; the score itself is still checked against the player's game history.
  function bossShare(last) {
    var a = $("g-boss-share"); if (!a) return;
    if (!last || !last.r || last.r <= last.b) { a.hidden = true; return; }
    a.hidden = false;
    var text = resultPost({ kind: "live", boss: true, result: "win", mine: last.r, humans: 1, rounds: 0, blocks: 0, cards: 0,
      standings: [{ n: me.name || "You", r: last.r, me: true }, { n: "The Shogun", r: last.b }] });
    var miss = xTags.split(/\s+/).filter(function (t) { return t && text.toLowerCase().indexOf(t.toLowerCase()) < 0; }).join(" ");
    if (miss && (text + "\n" + miss).length < 240) text += "\n" + miss;
    var url = "";
    var full = function () { return text + "\n" + (url || "https://shyonsol.io/shogun"); };
    var setHref = function () { a.href = "https://x.com/intent/tweet?text=" + encodeURIComponent(full()); };
    setHref();
    a.textContent = xUser && xPost ? "Post your win to X" : "Share your win";
    a.onclick = function (e) {
      sfx("tap");
      if (xUser && xPost && window.ShyX) { e.preventDefault(); ShyX.compose(full(), xUser, function (j) { toast(j && j.xt ? "Posted to X. X task done: +" + j.xt.koban + " Koban" : "Posted to X"); if (j && j.xt && window.ShyEco) ShyEco.refresh && ShyEco.refresh(); }); }
    };
    // the card: a fresh one from the recorded score; the board is seeded from the win time so sharing twice draws the same map
    var rng = last.t || 1, rnd = function () { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng / 0x7fffffff; };
    var marks = []; for (var i = 0; i < G.REGIONS.length; i++) marks.push("o");
    var spots = G.REGIONS.map(function (_, i) { return i; }).sort(function () { return rnd() - 0.5; });
    for (var k = 0; k < last.r; k++) marks[spots[k]] = "0";
    for (var k2 = 0; k2 < last.b; k2++) marks[spots[last.r + k2]] = "1";
    fetch(SHARE_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "create", pid: me.pid, key: me.key,
      name: me.name || "Player", avatar: myAvatar(), mask: "unbound", owners: marks.join(""), rounds: "", kind: "live", boss: true, result: "win",
      regions: last.r, mode: "normal", dailyNo: 0, humans: 1,
      standings: [{ n: me.name || "You", r: last.r, c: 0, me: true }, { n: "The Shogun", r: last.b, c: 1 }] }) })
      .then(function (r) { return r.json(); }).then(function (j) { if (j && j.ok) { url = j.url; setHref(); } }).catch(function () {});
  }
  function refreshLiveCard() {
    loadWatchList();
    bossCard();
    var nb = $("g-live-name-row");
    if (nb) nb.hidden = !!me.name;
    var who = $("g-live-who");
    if (who) who.textContent = me.name ? "Playing as " + me.name : "";
  }
  // timers: turn clock, last-seconds ticks, lobby countdown
  setInterval(function () {
    if (!live || !live.view) return;
    if (live.view.status === "waiting") { roomStatus(); return; }
    if (live.view.status !== "playing" || !g) return;
    var dl = live.view.game.deadline;
    var tt = g.turn === 0 ? "Your turn" + timerText() : $("g-turn").textContent.replace(/ \d+:\d\d$/, "") + timerText();
    if ($("g-turn").textContent !== tt) $("g-turn").textContent = tt;   //MC 2026-10-11 4 times a second; only when the clock text changes
    var left = dl ? Math.ceil(dl - serverNow()) : 99;
    $("g-turn").classList.toggle("hurry", g.turn === 0 && left <= 10);
    if (g.turn === 0 && live.mine && left <= 5 && left > 0 && left !== live.tickAt) { live.tickAt = left; sfx("tick"); if (left <= 3) buzz(6); }
  }, 250);

  // ---------- input ----------
  $("g-hand").addEventListener("click", function (e) {
    if (dragMoved) return;
    var b = e.target.closest(".gc");
    if (!b || b.disabled) return;
    selectCard(parseInt(b.dataset.i, 10));
  });
  $("g-play").addEventListener("click", tryPlay);
  $("g-pass").addEventListener("click", pass);
  $("g-targets").addEventListener("click", function (e) {
    if (e.target.closest(".g-cancel")) { $("g-targets").hidden = true; mapSync(); return; }
    var b = e.target.closest(".g-tgt");
    if (b && !b.disabled) doPlay(parseInt(b.dataset.t, 10));
  });
  // tap the board during rival turns to speed things up
  root.addEventListener("click", function (e) {
    if (!g || g.over || !busy || g.turn === 0 || isLive()) return;
    if (e.target.closest(".g-overlay, .g-tool, button")) return;
    if (!ff) { ff = true; render(); }
  });
  document.querySelectorAll("[data-game-start]").forEach(function (b) { b.addEventListener("click", function () { begin(b.dataset.gameStart || "quick"); }); });
  document.querySelectorAll("[data-game-menu]").forEach(function (b) { b.addEventListener("click", showMenu); });
  document.querySelectorAll("[data-game-board]").forEach(function (b) {
    b.addEventListener("click", function (e) {
      e.preventDefault();
      if (document.body.classList.contains("g-focus")) toggleFocus(true);
      var lb = $("leaderboard"); if (lb) lb.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
    });
  });
  $("g-save-btn").addEventListener("click", function () {
    var n = $("g-name").value.trim();
    if (!/^[A-Za-z0-9 _.\-]{3,20}$/.test(n)) { setLbMsg("Use 3 to 20 letters, numbers, spaces, dots or dashes."); return; }
    me.name = n; store("shy-lb-name", n);
    submit();
  });
  $("g-name").addEventListener("keydown", function (e) { if (e.key === "Enter") $("g-save-btn").click(); });

  // live match buttons
  $("g-live-code").addEventListener("keydown", function (e) { if (e.key === "Enter") liveStart("live-join"); });
  $("g-live-name").addEventListener("keydown", function (e) { if (e.key === "Enter") liveStart("live-quick"); });
  //MC 2026-10-15 Look around while you wait: out of full screen, down to the rest of the Play page; the room bar follows
  $("g-room-browse").addEventListener("click", function () {
    if (!live) return;
    if (document.body.classList.contains("g-focus")) toggleFocus();
    live.browsing = true;
    if (window.ShyDock && live.view) ShyDock.show(dockState(live.view), roomBack, roomLeaveFromDock);
    var to = document.getElementById("leaderboard") || document.getElementById("tourney");
    setTimeout(function () { try { (to || document.body).scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } catch (e) {} }, 60);
  });
  $("g-room-hold").addEventListener("click", async function () {
    if (!live) return;
    var b = this; b.disabled = true;
    var r = await livePost(Object.assign({ a: "hold" }, liveCreds()));
    if (!r.ok) { toast(esc(r.error || "Couldn't wait longer.")); b.disabled = false; return; }
    live.ringTotal = 0; toast("A minute more for real players to join.");
    liveQueue(r);
  });
  $("g-room-leave").addEventListener("click", async function () {
    if (live) { var c = liveCreds(); livePost(Object.assign({ a: "leave" }, c)); }
    liveEnd("");
  });
  $("g-room-start").addEventListener("click", async function () {
    if (!live) return;
    var r = await livePost(Object.assign({ a: "start" }, liveCreds()));
    if (r.ok) liveQueue(r); else toast(r.error || "Couldn't start.");
  });
  //MC 2026-10-09 said "Link copied" even when the browser blocked the clipboard, and the rejected promise went
  //   uncaught. Wait for the result; on a fail show the room code so it can still be shared by hand.
  $("g-room-copy").addEventListener("click", function () {
    var lbl = function (t) { $("g-room-copy").textContent = t; setTimeout(function () { $("g-room-copy").textContent = "Copy invite link"; }, 1600); };
    var fail = function () { lbl("Copy failed"); if (live) toast("Room code: " + live.code); };
    try { navigator.clipboard.writeText(inviteLink()).then(function () { lbl("Link copied"); }, fail); } catch (e) { fail(); }
  });
  $("g-room-tg").addEventListener("click", function () {
    if (!live) return;
    var t = tgInviteText();
    tgOpen("https://t.me/share/url?url=" + encodeURIComponent(t.url) + "&text=" + encodeURIComponent(t.text));
  });
  $("g-room-x").addEventListener("click", function () {
    open("https://x.com/intent/tweet?text=" + encodeURIComponent("Who wants to get wrecked in Shilluminati Online? Join my room: " + inviteLink() + " $SHY"), "_blank", "noopener");
  });
  $("g-rematch").addEventListener("click", rematch);
  // leaving mid-game: solo and Daily runs just aren't scored; in a live match or a tournament table a bot takes the seat
  function inGame() {
    if (live) return !!(live.view && live.view.status === "playing");
    return !!(g && !g.over && $("g-start").hidden && $("g-end").hidden);
  }
  function quitText() {
    if (live) {
      var t = live.view && live.view.tourney;
      return t ? "You'll be out of " + t.name + ". A bot plays your seat for the rest of this table." : "A bot plays your seat for the rest of the match. It won't count for you.";
    }
    //MC 2026-10-11 the Daily is used once you've made a move (dailyBegun), so the text says so instead of "stays open"
    if (g && g.daily && !g.practice && !g.replay) return g.begun ? "This is your Daily run for today. If you leave, it won't be scored and today's Daily is used up." : "You haven't made a move yet, so today's Daily stays open for you.";
    return "This game won't be scored. You can start a new one right away.";
  }
  $("g-quit-btn").addEventListener("click", function () {
    if (!inGame()) { toast("No game in progress."); return; }
    sfx("tap");
    $("g-quit-txt").textContent = quitText();
    $("g-quit").hidden = false;
    $("g-quit-no").focus();
  });
  $("g-quit-no").addEventListener("click", function () { $("g-quit").hidden = true; });
  $("g-quit-yes").addEventListener("click", function () {
    $("g-quit").hidden = true;
    if (document.body.classList.contains("g-focus")) toggleFocus();
    if (live) {
      var c = liveCreds();
      livePost(Object.assign({ a: "leave" }, c));
      liveEnd("You left the match.");
      return;
    }
    // a solo game has turns already in flight, so a fresh page is the clean way out
    if (g && g.daily && g.begun && !g.practice && g.dayKey && !stats.daily[g.dayKey]) { stats.daily[g.dayKey] = { left: 1 }; saveStats(); }   //MC 2026-10-11 the lobby shows today's Daily as used
    try { sessionStorage.setItem("shy-left", "1"); } catch (e) {}
    location.reload();
  });
  try { if (sessionStorage.getItem("shy-left") === "1") { sessionStorage.removeItem("shy-left"); setTimeout(function () { toast("Game left. It wasn't scored."); try { root.scrollIntoView({ block: "start" }); } catch (e) {} }, 400); } } catch (e) {}
  // reactions
  var reactPop = $("g-react-pop");
  function drawReacts() {
    var have = eco().reacts || [0, 1, 2, 3, 4, 5];
    reactPop.innerHTML = REACTS.map(function (r, i) { var on = have.indexOf(i) >= 0; return '<button data-r="' + i + '"' + (on ? "" : ' class="locked" title="Unlock in the shop"') + '>' + r + '</button>'; }).join("") +
      '<a class="g-react-more" href="#shop" data-shop="items:emote">More reactions</a>';
  }
  drawReacts();
  $("g-react").addEventListener("click", function (e) { e.stopPropagation(); drawReacts(); reactPop.hidden = !reactPop.hidden; });
  reactPop.addEventListener("click", function (e) {
    var b = e.target.closest("[data-r]"); if (!b || !live) return;
    var i = parseInt(b.dataset.r, 10);
    reactPop.hidden = true;
    if (b.classList.contains("locked")) { toast("Unlock more reactions in the shop."); return; }
    if (Date.now() - (live.lastReact || 0) < 1300) return;
    live.lastReact = Date.now();
    bubble(0, REACTS[i]);
    livePost(Object.assign({ a: "react", e: i }, liveCreds())).then(function (r) { if (r.ok && r.reacts) r.reacts.forEach(function (x) { live && (live.seenReacts[x.id] = 1); }); });
  });
  document.addEventListener("click", function (e) { if (!reactPop.hidden && !e.target.closest("#g-react-pop")) reactPop.hidden = true; });

  //MC 2026-10-12 Live chat for the players at a live table. The server keeps the last 40 messages with the room and sends
  //   them with every update (v.chat). The panel is a bottom sheet on phones (over the hand, which is the one part of the
  //   screen you can spare for a moment) and a small panel in the map's corner on bigger screens. While it's closed, a
  //   new message shows as a speech bubble over the sender's seat and a count on the Chat button. Quick buttons send the
  //   usual things in one tap. Tap a name in the chat to mute that player for you (kept on this device).
  var chat = { code: "", seen: {}, unread: 0, open: false, first: true, sending: false };
  var CHAT_MUTE = (function () { try { return JSON.parse(store("shy-chat-mute") || "{}") || {}; } catch (e) { return {}; } })();
  function chatReset() { chat = { code: "", seen: {}, unread: 0, open: false, first: true, sending: false }; var p = $("g-chat"); if (p) p.hidden = true; root.classList.remove("chat-open"); var l = $("g-chat-list"); if (l) l.innerHTML = ""; chatBadge(); chatButtons(false); }
  function chatButtons(on) { var b = $("g-chat-btn"), r = $("g-room-chat"); if (b) b.hidden = !on; if (r) r.hidden = !on; }
  function chatBadge() {
    [$("g-chat-n"), $("g-room-chat-n")].forEach(function (n) { if (!n) return; n.hidden = !chat.unread; n.textContent = chat.unread > 9 ? "9+" : String(chat.unread); });
  }
  function chatWho(v, seat) { var s = v.seats[seat] || {}; return { name: String(s.name || "Player").replace(" (bot)", ""), tag: s.tag || "", human: !!s.human }; }
  function chatAt(ts) { try { return new Date(ts * 1000).toLocaleTimeString(document.documentElement.lang || undefined, { hour: "numeric", minute: "2-digit" }); } catch (e) { return ""; } }
  function showChat(v) {
    if (!live || live.watch) { chatButtons(false); return; }
    if (chat.code !== live.code) { chatReset(); chat.code = live.code; }
    var on = v.chatOn !== false && v.seats.filter(function (x) { return x.human; }).length > 1;
    chatButtons(on || (v.chat || []).length > 0);
    var list = $("g-chat-list"), added = 0;
    (v.chat || []).forEach(function (m) {
      if (chat.seen[m.id]) return;
      chat.seen[m.id] = 1;
      var w = chatWho(v, m.seat), mine = m.seat === live.seat, muted = !mine && w.tag && CHAT_MUTE[w.tag];
      if (muted) return;
      var li = document.createElement("li");
      li.className = mine ? "me" : "";
      li.innerHTML = '<button type="button" class="g-chat-who" data-tag="' + esc(w.tag) + '" data-name="' + esc(w.name) + '"' + (mine ? " disabled" : "") + ' data-i18n-skip>' + esc(mine ? "You" : w.name) + '</button><span class="g-chat-t" data-i18n-skip>' + esc(m.t) + '</span><time>' + esc(chatAt(m.ts)) + '</time>';
      list.appendChild(li);
      added++;
      // not on first load (older messages), not my own: a bubble over their seat and the count
      if (!chat.first && !mine) {
        if (!chat.open) { chat.unread++; if (live.started) talkBubble(liveRel(m.seat), m.t); sfx("tap"); }
      }
    });
    if (added) list.scrollTop = list.scrollHeight;
    while (list.children.length > 60) list.removeChild(list.firstChild);
    $("g-chat-sub").textContent = on ? "" : "Chat is off for now";
    $("g-chat-f").hidden = !on;
    $("g-chat-quick").hidden = !on;
    chat.first = false;
    chatBadge();
  }
  //MC 2026-10-16 cut by whole emoji: slice() split a family or flag emoji in half and left a broken character
  function shortText(t, max) {
    var parts;
    try { parts = window.Intl && Intl.Segmenter ? Array.from(new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(t), function (x) { return x.segment; }) : Array.from(t); } catch (e) { parts = Array.from(t); }
    return parts.length > max + 2 ? parts.slice(0, max).join("") + "…" : t;
  }
  function cutText(t, max) {
    try { return Array.from(new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(t), function (x) { return x.segment; }).slice(0, max).join(""); } catch (e) { return Array.from(t).slice(0, max).join(""); }
  }
  function talkBubble(rel, text) {
    var anchor = rel === 0 ? $("g-me-av") : $("g-riv-" + rel);
    if (!anchor) return;
    var a = anchor.getBoundingClientRect(), b = root.getBoundingClientRect();
    var el = document.createElement("span");
    el.className = "g-talk"; el.setAttribute("data-i18n-skip", "");
    el.textContent = shortText(String(text || ""), 44);
    var x = a.left - b.left + a.width / 2, maxX = b.width - 12;
    el.style.left = Math.max(80, Math.min(maxX - 80, x)) + "px"; el.style.top = (a.top - b.top + root.scrollTop + a.height - 4) + "px";
    root.appendChild(el);
    setTimeout(function () { el.classList.add("out"); }, 3600);
    setTimeout(function () { el.remove(); }, 4100);
  }
  function chatOpen(open) {
    chat.open = open; var p = $("g-chat");
    p.hidden = !open; root.classList.toggle("chat-open", open);
    if (open) { chat.unread = 0; chatBadge(); var l = $("g-chat-list"); l.scrollTop = l.scrollHeight; if (window.matchMedia("(min-width: 900px)").matches) $("g-chat-in").focus(); }
  }
  async function chatSend(text) {
    text = String(text || "").trim();
    if (!text || !live || chat.sending) return;
    chat.sending = true; $("g-chat-send").disabled = true;
    //MC 2026-10-16 the send button can't stay stuck off, and a reply that won't draw can't throw out of here
    var r = {};
    try { r = await livePost(Object.assign({ a: "chat", text: text.replace(/[\ud800-\udbff](?![\udc00-\udfff])|(^|[^\ud800-\udbff])[\udc00-\udfff]/g, "$1") }, liveCreds())) || {}; } catch (e) { r = {}; }
    chat.sending = false; $("g-chat-send").disabled = false;
    if (r.ok) { $("g-chat-in").value = ""; try { if (r.seats) showChat(r); } catch (e) {} }
    else toast(esc(r.error || "Couldn't send that."));
  }
  $("g-chat-btn").addEventListener("click", function () { chatOpen(!chat.open); });
  $("g-room-chat").addEventListener("click", function () { chatOpen(!chat.open); });
  $("g-chat-x").addEventListener("click", function () { chatOpen(false); });
  $("g-chat-f").addEventListener("submit", function (e) { e.preventDefault(); chatSend($("g-chat-in").value); });
  //MC 2026-10-16 phones: the keyboard pushes the page up to show the box, and in the full screen table (no page scroll)
  //   iPhones could leave it pushed up after the keyboard closed, so the table looked broken. The sheet now rides on top
  //   of the keyboard, and the page goes back where it was when the keyboard closes.
  (function () {
    var inp = $("g-chat-in"), sheet = $("g-chat"), vv = window.visualViewport, y0 = 0, on = false;
    function lift() {
      if (!on || !vv || window.matchMedia("(min-width: 900px)").matches) { sheet.style.bottom = ""; return; }
      var gap = Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop));
      sheet.style.bottom = gap ? gap + "px" : "";
    }
    inp.addEventListener("focus", function () { y0 = window.scrollY; on = true; lift(); });
    //MC 2026-10-16 120 characters counted by whole emoji (the box's own limit counted pieces and cut a family emoji in half)
    inp.addEventListener("input", function () { var v = inp.value, c = cutText(v, 120); if (c !== v) inp.value = c; });
    inp.addEventListener("blur", function () {
      on = false; sheet.style.bottom = "";
      setTimeout(function () { if (document.activeElement === inp) return; if (document.body.classList.contains("g-focus")) window.scrollTo(0, 0); else if (Math.abs(window.scrollY - y0) > 2) window.scrollTo(window.scrollX, y0); }, 120);
    });
    if (vv) { vv.addEventListener("resize", lift); vv.addEventListener("scroll", lift); }
  })();
  $("g-chat-quick").addEventListener("click", function (e) { var b = e.target.closest("button"); if (b) chatSend(b.textContent); });
  $("g-chat-list").addEventListener("click", function (e) {
    var b = e.target.closest(".g-chat-who"); if (!b || !b.dataset.tag) return;
    var t = b.dataset.tag, was = !!CHAT_MUTE[t];
    if (was) delete CHAT_MUTE[t]; else CHAT_MUTE[t] = 1;
    store("shy-chat-mute", JSON.stringify(CHAT_MUTE));
    toast(esc(was ? b.dataset.name + " is unmuted." : b.dataset.name + " is muted. You won't see their messages."));
    if (!was) [].forEach.call($("g-chat-list").querySelectorAll('.g-chat-who[data-tag="' + t + '"]'), function (x) { x.closest("li").remove(); });
  });
  // keys: C opens the chat, Escape closes it; typing in the box never plays a card
  document.addEventListener("keydown", function (e) {
    if (e.target && e.target.id === "g-chat-in") { e.stopPropagation(); if (e.key === "Escape") chatOpen(false); return; }
    if ((e.key === "c" || e.key === "C") && !e.ctrlKey && !e.metaKey && !e.altKey && live && !$("g-chat-btn").hidden && !/INPUT|TEXTAREA|SELECT/.test((e.target && e.target.tagName) || "")) { e.preventDefault(); chatOpen(!chat.open); }
  }, true);

  //MC 2026-10-12 ?boss=1 (Telegram's Challenge the Shogun button, /shilluminatiboss): the player already asked, so start
  //MC 2026-10-15 ?daily=1 (the Daily blink and /daily) opens today's Daily straight away
  if (/[?&]daily=1/.test(location.search)) { try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {} setTimeout(function () { var d = document.querySelector('[data-game-start="daily"]'); if (d) d.click(); }, 450); }
  if (/[?&]boss=1/.test(location.search)) { try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {} setTimeout(function () { liveStart("live-boss"); }, 450); }
  // links to watch a match or a Daily replay
  var openedToWatch = false;
  (function () {
    var w = /[?&]watch=([A-Za-z0-9]{5})/.exec(location.search), r = /[?&]replay=(\d{4}-\d{2}-\d{2}):([a-f0-9]{6})/.exec(location.search);
    if (w || r) { openedToWatch = true; try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {} setTimeout(function () { if (w) startWatch(w[1]); else loadReplay(r[1], r[2]); }, 400); }
  })();
  // invite links and coming back after a refresh
  (function () {
    if (openedToWatch) return;
    var m = location.search.match(/[?&]room=([A-Za-z0-9]{5})/);
    var saved = liveSaved();
    if (saved && saved.code && Date.now() - saved.ts < 2 * 3600e3 && (!m || m[1].toUpperCase() === saved.code)) {
      liveBegin(saved);
      return;
    }
    if (m) {
      var code = m[1].toUpperCase();
      $("g-live-code").value = code;
      $("g-live-invite").hidden = false;
      $("g-live-invite-code").textContent = code;
      var go = $("g-live-invite-go");
      go.addEventListener("click", function () { liveStart("live-join", code); });
      //MC 2026-10-10 read go=1 before replaceState below wipes the query, otherwise the auto join never fired
      var autoGo = /[?&]go=1/.test(location.search) || /[?&]tgWebAppStartParam=join_/.test(location.search);
      try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {}
      //MC 2026-10-10 a challenge (the in-game notice, Telegram's Join button, a browser notification) carries go=1: the
      //   player already said yes, so join now instead of asking again with a second card
      if (autoGo) setTimeout(function () { liveStart("live-join", code); }, 350);
      else try { $("g-live-invite").scrollIntoView({ block: "center" }); } catch (e) {}
    }
  })();

  // keyboard
  document.addEventListener("keydown", function (e) {
    if (e.target.closest && e.target.closest("input, textarea, select")) return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    var k = e.key;
    if (k === "f" || k === "F") { if (root.getBoundingClientRect().bottom > 0) { toggleFocus(); e.preventDefault(); } return; }
    if (k === "m" || k === "M") { setSound(!me.sound); return; }
    if (k === "Escape") {
      if (!$("g-quit").hidden) { $("g-quit").hidden = true; return; }   //MC 2026-10-09 Esc closes "Leave this game?" first
      if (!$("g-targets").hidden) { $("g-targets").hidden = true; return; }
      if (document.body.classList.contains("g-focus")) toggleFocus();
      return;
    }
    if (!g || g.over) return;
    if (!$("g-targets").hidden) {
      var t = parseInt(k, 10);
      if (t >= 1 && t <= 3) { var btn = document.querySelector('.g-tgt[data-t="' + t + '"]'); if (btn && !btn.disabled) doPlay(t); e.preventDefault(); }
      return;
    }
    if (/^[1-9]$/.test(k)) { selectCard(parseInt(k, 10) - 1); e.preventDefault(); return; }
    if (k === "ArrowRight" || k === "ArrowLeft") {
      if (busy || g.turn !== 0) return;
      var n = g.players[0].hand.length; if (!n) return;
      var next = sel < 0 ? 0 : (sel + (k === "ArrowRight" ? 1 : -1) + n) % n;
      sel = next; sfx("select"); render(); scrollToCard(next); e.preventDefault(); return;
    }
    if (k === "Enter" || k === " ") { if (sel >= 0 || busy) { tryPlay(); e.preventDefault(); } return; }
    if (k === "p" || k === "P") { pass(); }
  });

  // drag and wheel scrolling for the hand when it doesn't fit
  var hand = $("g-hand"), dragX = null, dragLeft = 0, dragMoved = false;
  hand.addEventListener("pointerdown", function (e) {
    if (e.pointerType !== "mouse" || hand.scrollWidth <= hand.clientWidth) return;
    dragX = e.clientX; dragLeft = hand.scrollLeft; dragMoved = false;
  });
  addEventListener("pointermove", function (e) {
    if (dragX == null) return;
    var dx = e.clientX - dragX;
    if (Math.abs(dx) > 5) { dragMoved = true; hand.classList.add("dragging"); }
    if (dragMoved) hand.scrollLeft = dragLeft - dx;
  });
  addEventListener("pointerup", function () {
    if (dragX == null) return;
    dragX = null; hand.classList.remove("dragging");
    setTimeout(function () { dragMoved = false; }, 0);
  });
  hand.addEventListener("wheel", function (e) {
    if (hand.scrollWidth <= hand.clientWidth || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    hand.scrollLeft += e.deltaY; e.preventDefault();
  }, { passive: false });
  // desktop: one row of cards that overlap like a real hand when they don't fit
  var wide = matchMedia("(min-width:900px)");
  function fitHand() {
    var n = hand.children.length;
    if (!wide.matches || n < 2) { hand.style.removeProperty("--ov"); return; }
    var w = hand.children[0].offsetWidth, gap = 10, room = hand.clientWidth;
    var need = n * w + (n - 1) * gap;
    hand.style.setProperty("--ov", need > room ? Math.ceil((need - room) / (n - 1) + gap) + "px" : "0px");
  }
  //MC 2026-10-11 Persian (right to left): the hand always faded its right edge, which is where the first and the picked
  //   card sit, and never the left. In RTL scrollLeft runs from 0 down to negative, so "scrolled past the start" is
  //   Math.abs(scrollLeft) and the start is the right edge. Also, edges() ran straight from the MutationObserver after
  //   every hand redraw and read scrollWidth right after the writes, forcing a layout each time (part of #9's thrash);
  //   it now runs once per frame, after the frame's writes.
  var edgesQ = 0;
  function edgesNow() {
    edgesQ = 0;
    fitHand();
    var room = hand.scrollWidth - hand.clientWidth, over = room > 2;
    var x = Math.abs(hand.scrollLeft), rtl = getComputedStyle(hand).direction === "rtl";
    var past = over && x > 4, more = over && x < room - 4;
    hand.classList.toggle("fade-l", rtl ? more : past);
    hand.classList.toggle("fade-r", rtl ? past : more);
  }
  function edges() { if (!edgesQ) edgesQ = requestAnimationFrame(edgesNow); }
  hand.addEventListener("scroll", edges, { passive: true });
  new MutationObserver(edges).observe(hand, { childList: true });
  addEventListener("resize", edges);

  // full screen game
  //MC 2026-10-08 leaving full screen once on a phone used to be saved for good (shy-autofocus=off), so every game after
  //   that opened squeezed into the page under the site menu, and iPads never got full screen at all (760px cutoff).
  //   Now every new game on a phone or tablet opens full screen and the corner icon only exits the game in progress.
  function autoFocusDevice() { return matchMedia("(max-width:760px), (pointer:coarse) and (hover:none) and (max-width:1400px)").matches; }
  function toggleFocus(auto) {
    var on = !document.body.classList.contains("g-focus");
    document.body.classList.toggle("g-focus", on);
    $("g-focus").classList.toggle("on", on);
    if (on && auto !== true) toast(matchMedia("(hover:hover)").matches ? "Full screen. Press Esc or F to exit." : "Full screen. Tap the corner icon to exit.");
    if (!on) try { root.scrollIntoView({ block: "start" }); } catch (e) {}
    setTimeout(edges, 50);
  }
  $("g-focus").addEventListener("click", toggleFocus);
  function setSound(on) {
    me.sound = on;
    A.setSfx(on);
    $("g-sound").classList.toggle("muted", !on);
    var box = $("g-snd"); if (box) box.checked = on;
    if (g && !g.over) toast(on ? "Sound on" : "Sound off");
  }
  $("g-sound").addEventListener("click", function () { setSound(!me.sound); });

  // ---------- Shadow picker + wallet ----------
  var MINT_URL = "https://www.launchmynft.io/mint/shyshadows";
  var HOLDER_API = "api/holder.php";
  var holderEnabled = null, walletBusy = false;
  var picker = $("g-pick");
  function saveHolder() { store("shy-holder", JSON.stringify(holder)); }
  function renderPicker() {
    if (!picker) return;
    var own = holder.shadows || [], cur = myAvatar();
    if (own.length) {
      picker.innerHTML = own.map(function (x) {
        return '<button class="g-pick-av verified' + (String(x.n) === cur ? " on" : "") + (auraOf(x) ? " fx-" + auraOf(x).fx : "") + '" data-n="' + esc(x.n) + '" aria-label="Shadow #' + esc(x.n) + '"><img src="' + (x.img || shadowSrc(x.n) || UNBOUND) + '" alt="" onerror="this.src=\'' + UNBOUND + '\'"><i class="g-ver" title="Verified">✓</i><span>#' + esc(x.n) + (x.games ? " &middot; " + x.wins + "W" : "") + '</span></button>';
      }).join("");
    } else {
      picker.innerHTML = '<button class="g-pick-av on unbound" data-n="" data-shop="style:skin" title="Change your Shadow skin in the Dojo Shop"><img src="' + (mySkin() || UNBOUND) + '" alt=""><span>' + (mySkin() ? "Your skin" : "Unbound") + '</span></button>' +
        SHADOWS.map(function (x) { var on = trial && trial.n === x.n; return '<button class="g-pick-av locked' + (on ? " trying" : "") + '" data-locked="' + x.n + '" aria-label="Shadow #' + x.n + (on ? ", trying it" : ", try it free") + '"><img src="' + x.src + '" alt="" onerror="this.style.visibility=\'hidden\'">' + (on ? '<i class="g-try">Try</i>' : '<i class="g-lock">\u{1F512}</i>') + '<span>#' + x.n + '</span></button>'; }).join("");
      picker.querySelector(".unbound").classList.toggle("on", !trial);
    }
    pickLabel();
  }
  //MC 2026-10-10 a Shadow's rarity rank in words. 1,335 Shadows in the collection; 1 is the rarest.
  var RARITY_TIP = "Rarity rank among all 1,335 Shytoshi Shadows. 1 is the rarest. It isn't your game rank.";
  function rarityText(r) {
    var n = parseInt(String(r == null ? "" : r).replace(/[^0-9]/g, ""), 10);
    return n > 0 ? "Rarity #" + n.toLocaleString("en-US") + " of 1,335" : "";
  }
  function pickLabel() {
    var lbl = $("g-pick-label"); if (!lbl) return;
    var own = holder.shadows || [];
    if (!own.length && trial) { lbl.innerHTML = '<span>Next game: Shadow #' + esc(trial.n) + '</span> <em class="g-pick-meta">Trying it free</em>'; return; }
    if (!own.length) { var sk = (eco().eq.skin || "").slice(5); lbl.innerHTML = '<span>' + esc(sk ? "You play as " + ({ btc: "Bitcoin" }[sk] || sk.charAt(0).toUpperCase() + sk.slice(1)) + " Shade" : "You play as Unbound") + '</span>' + (SHADOWS.length ? ' <em class="g-pick-meta">Tap a Shadow to try it free</em>' : ""); return; }
    var x = myShadow(), a = auraOf(x), bits = [];
    //MC 2026-10-10 the Shadow's rarity rank from the collection used to read "Rank 1206", which players took for their
    //   game rank (League, Ranked). It now says what it is: "Rarity #1,206 of 1,335", and the tooltip says 1 is the rarest.
    var rr = rarityText(x && x.rank);
    if (rr) bits.push(rr);
    if (a && a.fx !== "confetti") bits.push("Win effect: " + a.name);
    lbl.innerHTML = esc(own.length === 1 ? "Your Shadow" : "Choose your Shadow") + (bits.length ? ' <em class="g-pick-meta"' + (rr ? ' title="' + esc(RARITY_TIP) + '"' : "") + '>' + esc(bits.join(" \u00b7 ")) + "</em>" : "");
  }
  if (picker) picker.addEventListener("click", function (e) {
    var b = e.target.closest(".g-pick-av"); if (!b) return;
    //MC 2026-10-09 a locked Shadow used to say "hold one to play as it" and stop. Now it's picked as a free try for
    //the next solo game; tapping it again (or Unbound) goes back.
    if (b.dataset.locked) {
      buzz(8); sfx("select");
      if (trial && trial.n === b.dataset.locked) { setTrial(null); return; }
      setTrial(b.dataset.locked);
      toast("Next solo game: Shadow #" + esc(trial.n));
      return;
    }
    // with a try picked, Unbound cancels it instead of opening the skin shop
    if (b.classList.contains("unbound") && trial) { e.stopPropagation(); setTrial(null); return; }
    me.avatar = b.dataset.n; store("shy-avatar", me.avatar); buzz(8); sfx("select");
    picker.querySelectorAll(".g-pick-av").forEach(function (x) { x.classList.toggle("on", x === b); });
    pickLabel();
  });

  function walletProvider() {
    var w = window;
    if (w.phantom && w.phantom.solana && w.phantom.solana.isPhantom) return w.phantom.solana;
    if (w.solflare && w.solflare.isSolflare) return w.solflare;
    if (w.backpack && w.backpack.solana) return w.backpack.solana;
    if (w.backpack && w.backpack.isBackpack) return w.backpack;
    if (w.solana) return w.solana;
    return null;
  }
  function inTg() { return document.documentElement.classList.contains("tgapp"); }
  //MC 2026-10-15 the site saved to a phone's home screen: like Telegram it has no wallet, and on iPhone "Open in Phantom"
  //   left the app for good (the page reopened in Phantom's browser as a guest). It now uses the Telegram hand-off: the
  //   wallet app signs in, and this app follows to the wallet's profile when you switch back (howait).
  function appMode() { try { return !!(window.navigator.standalone || matchMedia("(display-mode: standalone)").matches); } catch (e) { return false; } }
  var hoPrep = null;   // {code, t}: a hand-off code fetched ahead, so the wallet buttons can be real links (iPhone only opens other apps from a tap)
  async function hoPrepare() {
    if (hoPrep && Date.now() - hoPrep.t < 20 * 60000) return;
    hoPrep = { code: "", t: Date.now() };
    var j; try { j = await (await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "handoff", pid: me.pid, key: me.key }) })).json(); } catch (e) { j = null; }
    if (j && j.stale) { hoFresh(); try { j = await (await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "handoff", pid: me.pid, key: me.key }) })).json(); } catch (e) { j = null; } }
    if (j && j.ok) { hoPrep = { code: j.code, t: Date.now() }; store("shy-ho-code", j.code); renderWallet(); } else hoPrep = null;
  }
  function hoLink(app, code) {
    var here = location.origin + location.pathname + "?claim=" + code + "&app=1";
    return app === "phantom" ? "https://phantom.app/ul/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin)
      : "https://solflare.com/ul/v1/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin);
  }
  //MC 2026-10-19 a stale device key cannot vouch for its profile: a fresh guest identity can, and the wallet
  //   sign-in then carries this device to its real profile (same move as the connect flow)
  function hoFresh() { me.pid = hex(8); me.key = hex(16); store("shy-lb-pid", me.pid); store("shy-lb-key", me.key); }
  // a wallet hand-off started from Telegram, waiting for the holder to come back
  function hoWaiting() { var t = +(store("shy-ho-wait") || 0); return t > 0 && Date.now() - t < 1800000; }
  async function handOff(app) {
    renderWallet("Opening your wallet...");
    var j;
    try { j = await (await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "handoff", pid: me.pid, key: me.key }) })).json(); } catch (e) { j = null; }
    if (j && j.stale) { hoFresh(); try { j = await (await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "handoff", pid: me.pid, key: me.key }) })).json(); } catch (e) { j = null; } }
    if (!j || !j.ok) { renderWallet((j && j.error) || "Couldn't start. Check your connection and try again.", true); return; }
    var here = location.origin + location.pathname + "?claim=" + j.code;
    var url = app === "phantom" ? "https://phantom.app/ul/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin)
      : app === "solflare" ? "https://solflare.com/ul/v1/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin) : here;
    store("shy-ho-wait", String(Date.now())); store("shy-ho-code", j.code);
    var W = window.Telegram && window.Telegram.WebApp;
    if (W && W.openLink) W.openLink(url); else open(url, "_blank", "noopener");
    renderWallet();
  }
  // back in Telegram (or the home screen app) after the wallet app: pick up the verified Shadow
  //MC 2026-10-15 first ask whether the wallet signed in to a profile of its own (it already had one): then this app
  //   switches to it, with everything on it. The same profile: just refresh the wallet as before.
  var hoBusy = false;
  async function hoBack() {
    if (document.hidden || !(inTg() || appMode()) || !hoWaiting() || hoBusy) return;
    hoBusy = true;
    try {
      var code = store("shy-ho-code") || "";
      if (code) {
        var w = null; try { w = await (await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "howait", code: code, pid: me.pid, key: me.key }) })).json(); } catch (e) {}
        if (w && w.to && w.to !== me.pid) {
          store("shy-lb-pid", w.to); if (w.name) store("shy-lb-name", w.name);
          store("shy-ho-wait", ""); store("shy-ho-code", ""); store("shy-holder", ""); store("shy-avatar", "");
          try { sessionStorage.setItem("shy-ho-done", w.name || "1"); } catch (e) {}
          location.reload(); return;
        }
        if (w && (w.to || w.gone)) { store("shy-ho-code", ""); hoPrep = null; }
      }
      await hoStatus();
    } finally { hoBusy = false; }
  }
  document.addEventListener("visibilitychange", hoBack);
  setInterval(function () { if (appMode()) hoBack(); }, 4000);
  async function hoStatus() {
    var j = await holderPost({ a: "status" });
    if (!j.ok) return;
    applyHolder(j);
    if (j.linked) {
      store("shy-ho-wait", "");
      if (j.holder && j.shadows.length) { me.avatar = String(j.shadows[0].n); store("shy-avatar", me.avatar); renderPicker(); sfx("badge"); toast("Verified. You're playing as Shadow #" + myAvatar() + "."); }
    }
  }
  function shortAddr(a) { return a ? a.slice(0, 4) + "…" + a.slice(-4) : ""; }
  //MC 2026-10-23 every wallet the browser has (Solana Wallet Standard, assets/wallets.js), and Trust Wallet and MetaMask
  //   where it has neither: their apps open only to approve, then the game carries on. Phantom keeps its own flow.
  function pageWallets() { return window.ShyWallets ? ShyWallets.found().filter(function (w) { return !w.shyKit && w.features["solana:signMessage"]; }) : []; }
  function hasPageWallet() { return !!walletProvider() || pageWallets().length > 0; }
  function kitBtns() {
    return window.ShyWallets ? ShyWallets.extras().map(function (x) { return '<button class="btn btn-line btn-sm g-w-kit" data-w="kit" data-k="' + esc(x.id) + '"><img alt="" src="' + esc(x.icon) + '">' + esc(x.name) + '</button>'; }).join("") : "";
  }
  // Solflare on a phone: approve in the app and come straight back (api/wallet.php keeps the conversation)
  var SFX = { next: null, wait: false, busy: false, sign: "" };
  function sfRet() { return inTg() ? "tg" : appMode() ? "app" : "web"; }
  function sfApp(u) { return inTg() || appMode() ? String(u || "").replace("https://solflare.com/", "solflare://") : u; }
  function sfLive() { var t = +(store("shy-wl-t") || 0); return !!store("shy-wl") && Date.now() - t < 1800000; }
  async function wlPost(body) {
    try { return await (await fetch("/api/wallet.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) })).json(); }
    catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  // the connect link is fetched ahead, so the Solflare button is a real link (phones only open an app from a tap)
  async function sfPrep() {
    if (SFX.next && (SFX.next.wait || (SFX.next.fail ? Date.now() - SFX.next.t < 30000 : Date.now() - SFX.next.t < 10 * 60000))) return;
    SFX.next = { wait: 1, t: Date.now() };
    var j = await wlPost({ a: "new", app: "solflare", ret: sfRet() });
    SFX.next = j && j.ok ? { s: j.s, url: j.url, t: Date.now() } : { fail: 1, t: Date.now() };   // a failure waits 30 seconds before the next try
    renderWallet();
  }
  function sfBtn() {
    var n = SFX.next;
    if (!n || !n.url) { sfPrep(); return '<span class="btn btn-line btn-sm"' + (n && n.fail ? ' title="Solflare isn\'t reachable right now"' : ' aria-busy="true"') + '>Solflare</span>'; }
    return '<a class="btn btn-line btn-sm" data-sf-go href="' + esc(sfApp(n.url)) + '" data-web="' + esc(n.url) + '">Solflare</a>';
  }
  // if this page is still showing a moment after the tap, the app didn't take the link: the web form opens instead
  function sfFallback(e, url) {
    setTimeout(function () {
      if (!url || e.defaultPrevented || url.indexOf("https://") !== 0) return;
      var t = setTimeout(function () { if (!document.hidden) location.href = url; }, 1700);
      document.addEventListener("visibilitychange", function h() { clearTimeout(t); document.removeEventListener("visibilitychange", h); });
    }, 0);
  }
  function sfEnd(tellServer) { var sid = store("shy-wl"); if (tellServer && sid) wlPost({ a: "end", s: sid }); store("shy-wl", ""); store("shy-wl-t", ""); store("shy-wl-n", ""); SFX.sign = ""; SFX.wait = false; }
  // where the Solflare conversation stands: connected (sign next), signed (verify here, as every connect does), or cancelled
  async function sfCheck() {
    if (SFX.busy || !sfLive()) return;
    SFX.busy = true;
    try {
      var sid = store("shy-wl"), j = await wlPost({ a: "state", s: sid });
      if (!j || !j.ok) return;
      if (j.gone) { sfEnd(false); renderWallet(); return; }
      if (j.err) { var cancel = j.err === "cancel"; sfEnd(true); renderWallet(cancel ? "Cancelled in Solflare. Nothing was signed." : j.err, true); return; }
      if (j.stage === "connected" && !SFX.sign) {
        var n = await holderPost({ a: "nonce", wallet: j.wallet });
        if (!n.ok) { sfEnd(true); renderWallet(n.error || "Couldn't start verification.", true); return; }
        var sg = await wlPost({ a: "sign", s: sid, message: n.message });
        if (!sg.ok) { sfEnd(true); renderWallet(sg.error || "Couldn't get Solflare ready to sign.", true); return; }
        store("shy-wl-n", n.nonce); store("shy-wl-t", String(Date.now())); SFX.sign = sg.url;
        renderWallet(); sfx("turn"); buzz(10);
        return;
      }
      if (j.stage === "signed" && j.sig && store("shy-wl-n")) {
        var nonce = store("shy-wl-n");
        store("shy-wl-n", ""); renderWallet("Checking your Shadows on Solana...");
        var v = await holderPost({ a: "verify", nonce: nonce, signature: j.sig });
        sfEnd(true);
        if (!v.ok && v.stale) { renderWallet("This sign-in went stale. Connect Solflare once more.", true); hoFresh(); return; }
        if (!v.ok) { renderWallet(v.error || "Verification failed.", true); return; }
        afterVerify(v);
      }
    } finally { SFX.busy = false; }
  }
  document.addEventListener("visibilitychange", function () { if (!document.hidden && sfLive()) sfCheck(); });
  setInterval(function () { if (sfLive() && !document.hidden) sfCheck(); }, 3000);
  function isPhone() { return /iPhone|iPad|Android/i.test(navigator.userAgent); }
  // no wallet app? a free wallet with just an email (assets/ewallet.js), when it's set up
  function ewRow() { return window.ShyEW && ShyEW.ready() ? '<span class="ew-or">No wallet? Get a free one</span>' + ShyEW.buttons() : ""; }
  //MC 2026-10-23 a message stays a few seconds even when the box redraws (wallets turning up, the kit getting ready)
  var walletMsg = null;
  function renderWallet(msg, err) {
    var box = $("g-wallet"); if (!box) return;
    if (msg) walletMsg = { m: msg, e: !!err, t: Date.now() };
    else if (msg === undefined && walletMsg && Date.now() - walletMsg.t < 8000) { msg = walletMsg.m; err = walletMsg.e; }
    var html = "";
    if (holderEnabled === false) {
      html = '<div class="g-w-txt"><b>Holders play as their own Shadow</b><small>Wallet connect opens soon. Mint now and be ready.</small></div><div class="g-w-btns"><a class="btn btn-line btn-sm" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint a Shadow</a></div>';
    } else if (holder.linked && holder.holder) {
      var n = (holder.shadows || []).length;
      html = '<div class="g-w-txt"><b><i class="g-ver">✓</i> Verified holder</b><small><span data-i18n-skip>' + shortAddr(holder.wallet) + '</span>' + " &middot; " + n + (n === 1 ? " Shadow" : " Shadows") + '. Your wins stay on your Shadow\'s record.</small></div>' +
        '<div class="g-w-btns"><button class="btn btn-line btn-sm" data-w="refresh">Refresh</button><button class="btn btn-line btn-sm" data-w="unlink">Disconnect</button></div>';
    } else if (holder.linked) {
      html = '<div class="g-w-txt"><b>No Shadows in ' + shortAddr(holder.wallet) + '</b><small>Mint one, or connect the wallet that holds yours.</small></div>' +
        '<div class="g-w-btns"><a class="btn btn-mint btn-sm" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint a Shadow</a><button class="btn btn-line btn-sm" data-w="refresh">Check again</button><button class="btn btn-line btn-sm" data-w="unlink">Disconnect</button></div>';
    } else if (sfLive() && SFX.sign) {
      //MC 2026-10-23 Solflare approved the connection: one more tap to sign the holder message, then back here
      html = '<div class="g-w-txt"><b>Connected. Now sign in Solflare</b><small>Free, and not a transaction. Solflare opens, then sends you back here.</small></div>' +
        '<div class="g-w-btns"><a class="btn btn-mint btn-sm" data-sf-sign href="' + esc(sfApp(SFX.sign)) + '" data-web="' + esc(SFX.sign) + '">Sign in Solflare</a><button class="btn btn-line btn-sm" data-w="sf-stop">Cancel</button></div>';
    } else if (sfLive() && !hasPageWallet()) {
      html = '<div class="g-w-txt"><b>Approve it in Solflare</b><small>Then come back here. This updates by itself.</small></div><div class="g-w-btns"><button class="btn btn-line btn-sm" data-w="sf-stop">Start over</button></div>';
    } else if (inTg() && !hasPageWallet()) {
      // Telegram's browser has no wallet: the holder finishes in their wallet app, signed in as this same profile
      html = '<div class="g-w-txt"><b>Holder? Connect your wallet</b><small>' + (hoWaiting() ? "Approve it in your wallet, then come back here. This updates by itself." : "Play as your own Shadow. Not needed to play. The wallet opens only to approve.") + '</small></div>' +
        '<div class="g-w-btns">' + (isPhone()
          ? '<button class="btn btn-mint btn-sm" data-w="ho" data-app="phantom">Phantom</button>' + sfBtn() + kitBtns()
          : '<button class="btn btn-mint btn-sm" data-w="ho" data-app="web">Connect in my browser</button>') + ewRow() + '</div>';
    } else if (appMode() && !hasPageWallet() && isPhone()) {
      var hc = (hoPrep && hoPrep.code) || (hoWaiting() && store("shy-ho-code")) || "";
      if (!hc) hoPrepare();
      html = '<div class="g-w-txt"><b>Play as your own Shadow</b><small>' + (hoWaiting() ? "Approve it in your wallet app, then come back here. This updates by itself." : "Tap your wallet app, approve there, then come back to this app.") + '</small></div>' +
        '<div class="g-w-btns">' + (hc ? '<a class="btn btn-mint btn-sm" data-ho-go href="' + hoLink("phantom", hc) + '">Open in Phantom</a>'
          : '<span class="btn btn-mint btn-sm" aria-busy="true">Getting ready...</span>') + sfBtn() + kitBtns() +
        '<a class="btn btn-line btn-sm" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint</a>' + ewRow() + '</div>';
    } else if (!hasPageWallet() && isPhone()) {
      var here = location.origin + location.pathname + "?connect=1";
      html = '<div class="g-w-txt"><b>Play as your own Shadow</b><small>Pick your wallet. Solflare, Trust Wallet and MetaMask open only to approve, then send you back here.</small></div>' +
        '<div class="g-w-btns"><a class="btn btn-mint btn-sm" href="https://phantom.app/ul/browse/' + encodeURIComponent(here) + '?ref=' + encodeURIComponent(location.origin) + '">Open in Phantom</a>' +
        sfBtn() + kitBtns() +
        '<a class="btn btn-line btn-sm" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint</a>' + ewRow() + '</div>';
    } else {
      // a computer (or a wallet's own browser): the legacy injected wallet first (Phantom), then every other wallet the browser has
      var pw = pageWallets(), lp = walletProvider(), lpName = lp ? (lp.isPhantom ? "Phantom" : lp.isSolflare ? "Solflare" : "") : "";
      var more = pw.filter(function (w) { return !lpName || String(w.name).toLowerCase().indexOf(lpName.toLowerCase()) < 0; });
      var many = more.length + (lp ? 1 : 0) > 1 || kitBtns() !== "";
      html = '<div class="g-w-txt"><b>Play as your own Shadow</b><small>Holders connect a wallet to unlock their Shadow and its record. Free, no transaction.</small></div>' +
        '<div class="g-w-btns">' + (lp || !more.length ? '<button class="btn btn-mint btn-sm" data-w="connect">' + (many && lpName ? esc(lpName) : "Connect wallet") + '</button>' : "") +
        more.map(function (w) { return '<button class="btn btn-line btn-sm g-w-kit" data-w="std" data-n="' + esc(w.name) + '">' + (w.icon ? '<img alt="" src="' + esc(w.icon) + '">' : "") + esc(w.name) + '</button>'; }).join("") +
        kitBtns() + '<a class="btn btn-line btn-sm" href="' + MINT_URL + '" target="_blank" rel="noopener">Mint a Shadow</a>' + (hasPageWallet() ? "" : ewRow()) + '</div>';
    }
    if (msg) html += '<p class="g-w-msg' + (err ? " err" : "") + '">' + esc(msg) + '</p>';
    box.innerHTML = html;
  }
  async function holderPost(body) {
    try {
      var r = await fetch(HOLDER_API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) });
      return await r.json();
    } catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  function applyHolder(j) {
    //MC 2026-10-15 a Seeker phone owner's one-time welcome bonus (paid by the holder check that brought this answer)
    if (j.seekerBonus) setTimeout(function () { toast('<b>Seeker owner!</b> +<span data-i18n-skip>' + fmt(j.seekerBonus) + '</span> Koban welcome bonus'); }, 400);
    holder = { linked: !!j.linked, holder: !!j.holder, wallet: j.wallet || "", shadows: j.shadows || [] };
    holder.shadows.forEach(function (x) { if (x.img) NFTIMG[x.n] = x.img; });
    saveHolder(); renderPicker(); renderWallet();
  }
  //MC 2026-10-15 an email wallet (assets/ewallet.js): the email and code happen in a sheet on this page, so it works in
  //   Telegram as it is (the first version sent Telegram players out to their browser for Google; not needed now)
  async function ewStart() {
    try { var ep = await ShyEW.start(); if (ep && ep.publicKey) connectWallet(ep); }
    catch (e) { if (!/cancelled/.test(String(e && e.message))) renderWallet((e && e.message) || "Couldn't open the sign-in. Try again.", true); }
  }
  async function connectWallet(pGiven, fresh) {
    if (walletBusy) return;
    var p = pGiven && pGiven.signMessage ? pGiven : walletProvider();
    if (!p) { renderWallet("No Solana wallet found in this browser. Install Phantom or Solflare, or open this page in your wallet app.", true); return; }
    walletBusy = true;
    try {
      renderWallet("Approve the connection in your wallet...");
      var res = await p.connect();
      var pk = ((res && res.publicKey) || p.publicKey).toString();
      var n = await holderPost({ a: "nonce", wallet: pk });
      if (!n.ok) throw new Error(n.error || "Couldn't start verification.");
      renderWallet(p.isEmbedded ? "Linking your email wallet..." : "Sign the message in your wallet. It's free and not a transaction.");
      var out = await p.signMessage(new TextEncoder().encode(n.message), "utf8");
      //MC 2026-10-15 an email wallet (assets/ewallet.js) hands back its Crossmint sign-in token instead of a signature
      var cmJwt = out && out.cmJwt ? out.cmJwt : "";
      var sig = cmJwt ? null : (out && out.signature ? out.signature : out);
      var b64 = cmJwt ? "" : btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(sig))));
      renderWallet("Checking your Shadows on Solana...");
      var v = await holderPost({ a: "verify", nonce: n.nonce, signature: b64, cm: cmJwt });
      //MC 2026-10-19 a stale device key (merges, the old device cap) can't vouch for its profile: rotate to a
      //   fresh guest profile and connect once more, and the wallet signs that one in cleanly.
      if (!v.ok && v.stale && !fresh) {
        me.pid = hex(8); me.key = hex(16); store("shy-lb-pid", me.pid); store("shy-lb-key", me.key);
        walletBusy = false;
        return connectWallet(pGiven, true);
      }
      if (!v.ok) throw new Error(v.error || "Verification failed.");
      afterVerify(v);
    } catch (e) {
      var m = (e && e.message) || "";
      renderWallet(/reject|denied|cancel/i.test(m) ? "Cancelled in your wallet. Nothing was signed." : m || "Something went wrong. Try again.", true);
    }
    walletBusy = false;
  }
  //MC 2026-10-23 what happens once a wallet is verified, whichever way it connected (in the page, or Solflare's hand-off)
  async function afterVerify(v) {
    {
      if (v.switch && v.switch !== me.pid) {
        // this wallet already has a profile: this device signs in to it (purchases and records follow the wallet)
        me.pid = v.switch; store("shy-lb-pid", me.pid);
        if (v.name) { me.name = v.name; store("shy-lb-name", me.name); var ln = $("g-live-name"); if (ln) ln.value = me.name; }
        toast("Signed in" + (v.name ? " as " + esc(v.name) : "") + ". Your items and records came with your wallet.");
        renderProfile && renderProfile();
      }
      // this page was opened from Telegram to connect the wallet: if the wallet already had its own profile, Telegram moves to it
      var ho = null; try { ho = JSON.parse(store("shy-ho") || "null"); } catch (x) {}
      if (ho && ho.c) {
        store("shy-ho", "");
        //MC 2026-10-15 always, so the app that started this hears it's done (and follows if the wallet had its own profile)
        try { await fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "relink", code: ho.c, pid: me.pid, key: me.key }) }); } catch (x) {}
        setTimeout(function () { renderWallet(ho.pf ? "All set. Go back to your browser tab, your profile is signed in there." : ho.app ? "All set. Go back to the Shy on Solana app on your home screen, you're signed in there." : "All set. Go back to Telegram, your Shadow is waiting there."); }, 50);
      }
      applyHolder(v);
      if (window.ShyEco && ShyEco.refresh) ShyEco.refresh();
      if (v.holder) { me.avatar = String(v.shadows[0].n); store("shy-avatar", me.avatar); renderPicker(); sfx("badge"); toast("Verified. You're playing as Shadow #" + myAvatar() + "."); }
      else renderWallet();
    }
  }
  var walletBox = $("g-wallet");
  if (walletBox) walletBox.addEventListener("click", async function (e) {
    var eb = e.target.closest("[data-ew]"); if (eb) return ewStart();   //MC 2026-10-15 email wallet
    //MC 2026-10-15 home screen app hand-off. The code stays the same while it waits: a new one would cancel this one.
    if (e.target.closest("[data-ho-go]")) { store("shy-ho-wait", String(Date.now())); if (hoPrep) { store("shy-ho-code", hoPrep.code); hoPrep.t = Date.now(); } setTimeout(renderWallet, 300); return; }
    //MC 2026-10-23 Solflare's hand-off: the connect link, then the sign link, each a real tap
    var sg = e.target.closest("[data-sf-go]");
    if (sg) { if (!SFX.next || !SFX.next.s) { e.preventDefault(); return; } sfFallback(e, sg.dataset.web); store("shy-wl", SFX.next.s); store("shy-wl-t", String(Date.now())); store("shy-wl-n", ""); SFX.next = null; SFX.sign = ""; setTimeout(function () { renderWallet(); }, 300); return; }
    var ss = e.target.closest("[data-sf-sign]");
    if (ss) { sfFallback(e, ss.dataset.web); SFX.sign = ""; store("shy-wl-t", String(Date.now())); setTimeout(function () { renderWallet("Sign it in Solflare, then come back here. This updates by itself."); }, 300); return; }
    var b = e.target.closest("[data-w]"); if (!b) return;
    var w = b.dataset.w;
    if (w === "sf-stop") { sfEnd(true); renderWallet(); return; }
    if (w === "kit" && window.ShyWallets) return connectWallet(ShyWallets.provider(ShyWallets.kit(b.dataset.k)));   // Trust Wallet, MetaMask
    if (w === "std" && window.ShyWallets) { var sw = pageWallets().filter(function (x) { return x.name === b.dataset.n; })[0]; if (sw) return connectWallet(ShyWallets.provider(sw)); return; }
    if (w === "connect") return connectWallet();
    if (w === "ho") return handOff(b.dataset.app);
    if (w === "refresh") { renderWallet("Checking your Shadows on Solana..."); var j = await holderPost({ a: "refresh" }); if (j.ok) { applyHolder(j); renderWallet(j.holder ? "Up to date." : ""); } else renderWallet(j.error, true); }
    if (w === "unlink") { var u = await holderPost({ a: "unlink" }); applyHolder(u.ok ? u : { linked: false }); me.avatar = ""; store("shy-avatar", ""); try { var pr = walletProvider(); if (pr && pr.disconnect) pr.disconnect(); } catch (x) {} renderPicker(); }
  });
  // on load: check with the server (ownership may have changed since last visit)
  (async function () {
    renderPicker(); renderWallet();
    var hoErr = ""; try { hoErr = sessionStorage.getItem("shy-ho-err") || ""; sessionStorage.removeItem("shy-ho-err"); } catch (x) {}
    var j = await holderPost({ a: "status" });
    if (j.ok) { holderEnabled = j.enabled; if (window.ShyEW) ShyEW.set(j.ew); applyHolder(j); }
    else { holderEnabled = false; renderWallet(); }
    //MC 2026-10-15 just followed the wallet to its profile (home screen app hand-off)
    var hd = ""; try { hd = sessionStorage.getItem("shy-ho-done") || ""; sessionStorage.removeItem("shy-ho-done"); } catch (x) {}
    if (hd) setTimeout(function () { sfx("badge"); toast("Signed in" + (hd !== "1" ? " as <b data-i18n-skip>" + esc(hd) + "</b>" : "") + ". Your wallet, Shadows and Koban are here now."); }, 500);
    if (hoErr) renderWallet(hoErr, true);
    //MC 2026-10-23 back from Solflare: the answer is on the server, this picks it up (and the page that landed here in
    //   Safari from the home-screen app says where to finish)
    var wl = /[?&]wl=([a-f0-9]{32})/.exec(location.search), away = /[?&]away=1/.test(location.search);
    if (wl) { try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {} if (wl[1] !== store("shy-wl") && away) renderWallet("Approved in Solflare. Go back to the Shy on Solana app on your home screen to finish."); }
    if (sfLive()) sfCheck();
    if (window.ShyWallets) { ShyWallets.onFound(function () { renderWallet(); }); ShyWallets.ready().then(function () { renderWallet(); }); }
    if (/[?&]connect=1/.test(location.search) && holderEnabled && !holder.linked && walletProvider()) {
      try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {}
      connectWallet();
    }
  })();

  function seg(attr, key) {
    document.querySelectorAll("[data-" + attr + "]").forEach(function (b) {
      b.classList.toggle("on", b.dataset[attr] === me[key]);
      b.addEventListener("click", function () {
        me[key] = b.dataset[attr]; store("shy-" + key, me[key]);
        document.querySelectorAll("[data-" + attr + "]").forEach(function (x) { x.classList.toggle("on", x === b); });
        refreshStart();
      });
    });
  }
  seg("mode", "mode"); seg("speed", "speed");
  var hintBox = $("g-hints");
  hintBox.checked = me.hints;
  hintBox.addEventListener("change", function () { me.hints = hintBox.checked; store("shy-hints", me.hints ? "on" : "off"); tipKey = ""; refreshStart(); render(); });
  //MC 2026-10-24 Shadow plays: a holder's Shadow playing its own big cards (assets/shadowplay.js), on unless switched off
  //MC 2026-10-24 three settings now: every worthy play, big moments only, off (assets/shadowplay.js keeps it in shy-sp)
  var spSel = $("g-sp");
  if (spSel) { spSel.value = window.ShyShadowPlay ? ShyShadowPlay.mode() : "on"; spSel.addEventListener("change", function () { if (window.ShyShadowPlay) ShyShadowPlay.setMode(spSel.value); }); }
  var sndBox = $("g-snd");
  sndBox.checked = me.sound;
  sndBox.addEventListener("change", function () { setSound(sndBox.checked); });
  $("g-sound").classList.toggle("muted", !me.sound);
  function setMusic(on) {
    A.setMusic(on);
    $("g-music").classList.toggle("muted", !on);
    var box = $("g-mus"); if (box) box.checked = on;
    if (g && !g.over) toast(on ? "Music on" : "Music off");
  }
  $("g-music").classList.toggle("muted", !A.prefs.music);
  $("g-music").addEventListener("click", function () { setMusic(!A.prefs.music); });
  var musBox = $("g-mus");
  musBox.checked = A.prefs.music;
  musBox.addEventListener("change", function () { setMusic(musBox.checked); });
  $("g-badges").addEventListener("click", function (e) {
    var b = e.target.closest(".g-badge"); if (!b) return;
    var d = BADGES.filter(function (x) { return x.id === b.dataset.b; })[0];
    $("g-badge-desc").textContent = d.icon + " " + d.name + ": " + d.desc + (stats.badges[d.id] ? " Earned." : "");
  });
  if (me.name) $("g-name").value = me.name;
  refreshStart();

  var refresh = $("lb-refresh");
  if (refresh) refresh.addEventListener("click", function () { loadBoard(); });
  loadBoard(location.hash === "#daily" ? "daily" : "live");
  refreshLiveCard();
  //MC 2026-10-13 /try, the link for ads and shoutouts: it deals a quick game right away, no menu first. New players land
  //   on the defaults (Easy, hints on); a returning player keeps their own settings, and a saved live seat wins over this.
  if (window.SHY_TRY && !location.hash) setTimeout(function () { if (!g && !live && !liveSaved()) begin("quick"); }, 300);

  // ---------- confetti ----------
  // ---------- victory effects ----------
  // Holders celebrate with their Shadow's Aura. Everyone else gets confetti.
  function myShadow() { var a = myAvatar(); return (holder.shadows || []).filter(function (x) { return String(x.n) === a; })[0] || null; }
  function auraOf(x) { return x && x.aura ? AURAS[String(x.aura).toLowerCase()] || null : null; }
  window.ShyPlay = {
    xState: function () { return { on: xEnabled && xPost, user: xUser }; },
    me: me, esc: esc, toast: toast, sfx: sfx, buzz: buzz, fxRun: function (k) { fxRun(k); },
    holder: function () { return holder; }, holderEnabled: function () { return holderEnabled; },
    connectWallet: function () { return connectWallet(); }, provider: function () { return walletProvider(); },
    redraw: function () { renderPicker(); if (g && !live && avatars[0]) { var ms = meSeat(!!avatars[0].trial); avatars[0].src = ms.src; avatars[0].look = ms.look; avatars[0].n = ms.n; avatars[0].au = ms.au; avatars[0].trial = ms.trial; } if (g) render(); }, start: function (kind) { var b = document.querySelector('[data-game-start="' + kind + '"]'); if (b) b.click(); },
    // tournaments: sit at a table the server already set, and know whether a game is on screen
    //MC 2026-10-23 a quick match lobby gives its seat back before the tournament table takes over
    joinRoom: function (c) { if (live && !live.started && !live.done && !live.watch && live.kind !== "tourney") { try { livePost(Object.assign({ a: "leave" }, liveCreds())); } catch (e) {} } liveStop(); liveBegin({ code: c.code, seat: c.seat, secret: c.secret, kind: "tourney" }); },
    liveCode: function () { return live && live.code; }, busy: function () { return !!(live || (g && !g.over)); },
    //MC 2026-10-23 what's on screen, for the tournament seat: a finished live match (results dismissed) used to count as
    //   busy until something else started, so a player back on the menu never got their table. 'solo' and 'live' are a
    //   game in progress; 'lobby' (waiting for a quick match), 'watch' and 'idle' give way to the table.
    gameState: function () {
      if (live) { if (live.done) return "idle"; if (live.watch) return "watch"; if (!live.started) return "lobby"; return "live"; }
      return g && !g.over && !g.replay ? "solo" : "idle";
    },
    //MC 2026-10-09 "Join after this game": friends.js waits until the game in progress is over, then joins the room
    playing: function () { return !!(g && !g.over && !(g.replay)); },
    joinCode: function (code) { try { if (!live || live.done || live.watch) showMenu(); } catch (e) {} var c = $("g-live-code"); if (c) c.value = code; try { root.scrollIntoView({ block: "start" }); } catch (e) {} return liveStart("live-join", code); },
    name: function () { return me.name || (($("g-live-name") || {}).value || "").trim(); }, setName: function (n) { me.name = n; store("shy-lb-name", n); var x = $("g-name"); if (x) x.value = n; },
    avatar: function () { return myAvatar(); },
    // friends: a Duel run, and a private room opened to challenge a friend
    duel: function (id) { begin("duel:" + id); },
    //MC 2026-10-15 the room an invite should go to: any room you're seated in that is still filling (yours or someone
    //   else's, private or quick), not only one you host. Before, inviting from a friend's lobby opened a new room of
    //   your own and left theirs. Not in one: empty, and the invite opens a new private room as before.
    hosting: function () { var v = live && live.view; return live && !live.watch && !live.started && !live.done && live.kind !== "tourney" && v && v.status === "waiting" && !v.tourney && v.seats && v.seats.length < 4 ? live.code : ""; },
    liveChallenge: async function (tag) {
      if (!(live && live.seat === 0 && live.kind === "live-create" && !live.started)) await liveStart("live-create");
      if (live && live.seat === 0 && window.ShyFriends) ShyFriends.sendLive(live.code, tag);
    }
  };
  function victory() { var e = eco().eq.fx; if (e) return fxRun(e.replace("fx_", "")); var a = auraOf(myShadow()); fxRun(a ? a.fx : "confetti"); }
  function confetti() { fxRun("confetti"); }
  // preview any effect: /play?fx=lightning (or cyan, money, btc, crimson, confetti)
  //MC 2026-10-09 "Try one free in the game" on the NFTs page lands here with ?try=1: a random Shadow is picked for the
  //next solo game. A holder already plays as their own, so nothing changes for them.
  (function () {
    if (!/[?&]try=1/.test(location.search)) return;
    try { history.replaceState(null, "", location.pathname + "#game"); } catch (e) {}
    if ((holder.shadows || []).length) return;
    var t = tryRandom();
    if (t) setTimeout(function () { toast("Next solo game: Shadow #" + esc(t.n)); try { root.scrollIntoView({ block: "start" }); } catch (e) {} }, 700);
  })();
  (function () { var m = /[?&]fx=(\w+)/.exec(location.search); if (m) setTimeout(function () { fxRun(m[1]); }, 600); })();
  function fxRun(kind) {
    if (reduce) return;
    //MC 2026-10-10 the Animated victory effects live in fx2.js
    if (window.ShyFx2 && ShyFx2.has(kind)) return ShyFx2.run(kind, { sfx: sfx, buzz: buzz, root: root });
    var cv = document.createElement("canvas");
    cv.className = "g-confetti";
    //MC 2026-10-10 an animated table isolates #game (its moving layer sits under everything), which would trap this
    //   canvas under the page header, so it goes on <body> then (body > .g-confetti already sits on top)
    (root.classList.contains("tbx") ? document.body : root).appendChild(cv);
    var dpr = Math.min(2, window.devicePixelRatio || 1), W = window.innerWidth, H = window.innerHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    var ctx = cv.getContext("2d"); ctx.scale(dpr, dpr);
    var R = Math.random, bits = [], t0 = performance.now(), LIFE = kind === "confetti" ? 2600 : 3200;
    function coin(sym, face, rim) {
      return { x: R() * W, y: -30 - R() * H * 0.6, vy: 5 + R() * 4, vx: (R() - .5) * 1.2, r: 9 + R() * 8, spin: R() * 6, vs: 0.08 + R() * 0.12, sym: sym, face: face, rim: rim };
    }
    if (kind === "confetti") {
      var cols = ["#ff5d73", "#ff9f43", "#ffd166", "#2ef0b0", "#8b5cf6", "#4cc9f0"];
      for (var i = 0; i < 140; i++) bits.push({ x: W / 2, y: H * 0.35, vx: (R() - .5) * 12, vy: R() * -12 - 4, r: R() * 6 + 3, c: cols[i % cols.length], a: R() * 6 });
    } else if (kind === "money") {
      for (var i = 0; i < Math.max(45, Math.min(100, W / 14)); i++) bits.push(coin("$", "#ffd166", "#b8860b"));
    } else if (kind === "btc") {
      for (var i = 0; i < Math.max(45, Math.min(100, W / 14)); i++) bits.push(coin("₿", "#f7931a", "#9a5a0c"));
    } else if (kind === "crimson") {
      for (var i = 0; i < 60; i++) bits.push({ ember: true, x: R() * W, y: H * (0.5 + R() * 0.6), vy: -(2 + R() * 3.5), vx: (R() - .5) * 0.8, r: 1.5 + R() * 3, ph: R() * 6 });
      for (var i = 0; i < 60; i++) bits.push({ petal: true, x: R() * W * 0.9 - W * 0.1, y: -20 - R() * H * 0.5, vy: 2.2 + R() * 2.2, vx: 0.6 + R() * 1.2, r: 8 + R() * 7, a: R() * 6, ph: R() * 6 });
    } else if (kind === "cyan") {
      for (var i = 0; i < 90; i++) { var ang = R() * Math.PI * 2, sp = 4 + R() * 10; bits.push({ x: W / 2, y: H * 0.4, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, px: W / 2, py: H * 0.4, life: 0.6 + R() * 0.4 }); }
    } else if (kind === "lightning") {
      for (var i = 0; i < 5; i++) bits.push({ bolt: true, at: 120 + i * 420 + R() * 200, x: W * (0.15 + R() * 0.7), path: null });
    }
    function boltPath(x) {
      var pts = [[x, 0]], y = 0;
      while (y < H * 0.75) { y += 18 + R() * 30; x += (R() - .5) * 60; pts.push([x, y]); }
      return pts;
    }
    function drawCoin(b) {
      var sx = Math.abs(Math.cos(b.spin)) * 0.85 + 0.15;
      ctx.save(); ctx.translate(b.x, b.y); ctx.scale(sx, 1);
      ctx.beginPath(); ctx.arc(0, 0, b.r, 0, 7); ctx.fillStyle = b.rim; ctx.fill();
      ctx.beginPath(); ctx.arc(0, 0, b.r * 0.82, 0, 7); ctx.fillStyle = b.face; ctx.fill();
      if (sx > 0.45) { ctx.fillStyle = b.rim; ctx.font = "800 " + Math.round(b.r * 1.15) + "px system-ui,sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText(b.sym, 0, 1); }
      ctx.restore();
    }
    var last = t0;
    (function step(t) {
      var k = Math.min(4, Math.max(0.2, (t - last) / 16.7)); last = t;
      var el = t - t0, fade = el > LIFE - 500 ? Math.max(0, (LIFE - el) / 500) : 1;
      ctx.clearRect(0, 0, W, H);
      ctx.globalAlpha = fade;
      bits.forEach(function (b) {
        if (kind === "confetti") {
          b.vy += 0.35 * k; b.x += b.vx * k; b.y += b.vy * k; b.a += 0.2 * k;
          ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a); ctx.fillStyle = b.c; ctx.fillRect(-b.r / 2, -b.r / 4, b.r, b.r / 2); ctx.restore();
        } else if (b.sym) {
          b.y += b.vy * k; b.x += b.vx * k; b.spin += b.vs * k; b.vy += 0.04 * k; drawCoin(b);
        } else if (b.ember) {
          b.y += b.vy * k; b.x += (b.vx + Math.sin(el / 300 + b.ph) * 0.4) * k;
          var g2 = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r * 4);
          g2.addColorStop(0, "rgba(255,120,90,.95)"); g2.addColorStop(0.3, "rgba(230,40,60,.55)"); g2.addColorStop(1, "rgba(200,0,40,0)");
          ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(b.x, b.y, b.r * 4, 0, 7); ctx.fill();
        } else if (b.petal) {
          b.y += b.vy * k; b.x += (b.vx + Math.sin(el / 400 + b.ph) * 0.9) * k; b.a += 0.03 * k;
          ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a); ctx.scale(1, 0.55 + 0.45 * Math.abs(Math.sin(el / 350 + b.ph)));
          ctx.fillStyle = "#ff9ab0"; ctx.beginPath(); ctx.moveTo(0, -b.r); ctx.quadraticCurveTo(b.r, 0, 0, b.r); ctx.quadraticCurveTo(-b.r, 0, 0, -b.r); ctx.fill();
          ctx.fillStyle = "#e63958"; ctx.beginPath(); ctx.arc(0, b.r * 0.55, b.r * 0.18, 0, 7); ctx.fill();
          ctx.restore();
        } else if (kind === "cyan") {
          b.px = b.x; b.py = b.y; var dmp = Math.pow(0.96, k); b.vx *= dmp; b.vy = b.vy * dmp + 0.12 * k; b.x += b.vx * k + (R() - .5) * 3; b.y += b.vy * k + (R() - .5) * 3;
          var life = Math.max(0, 1 - el / (LIFE * b.life));
          if (!life) return;
          ctx.strokeStyle = "rgba(46,240,240," + life + ")"; ctx.lineWidth = 2; ctx.shadowColor = "#2ef0f0"; ctx.shadowBlur = 12;
          ctx.beginPath(); ctx.moveTo(b.px, b.py); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.shadowBlur = 0;
        } else if (b.bolt) {
          var age = el - b.at;
          if (age < 0 || age > 360) return;
          if (!b.path) { b.path = boltPath(b.x); sfx("hit"); buzz(30); }
          var a = age < 60 ? 1 : 1 - (age - 60) / 300;
          if (age < 90) { ctx.fillStyle = "rgba(200,220,255," + (0.28 * (1 - age / 90)) + ")"; ctx.fillRect(0, 0, W, H); }
          ctx.save(); ctx.globalAlpha = a * fade; ctx.shadowColor = "#9fd8ff"; ctx.shadowBlur = 24;
          [[7, "rgba(120,180,255,.6)"], [2.5, "#ffffff"]].forEach(function (s2) {
            ctx.strokeStyle = s2[1]; ctx.lineWidth = s2[0]; ctx.lineJoin = "round"; ctx.beginPath();
            b.path.forEach(function (pt, k) { k ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]); }); ctx.stroke();
          });
          ctx.restore();
        }
      });
      ctx.globalAlpha = 1;
      if (el < LIFE) requestAnimationFrame(step); else cv.remove();
    })(t0);
  }
})();
