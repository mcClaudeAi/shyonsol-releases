<?php
//MC 2026-10-13 the admin's map. The old sidebar had 19 tabs named after where the code lived (Rewards held payouts,
//   prize settings, Houses and a points recovery tool; Players held X posting and live chat), so the team kept asking
//   where things were. Now every job has its own page, grouped by what you came to do. A page is a tab plus the
//   sections (by heading) of that tab it shows: the tab's code is unchanged, admin.js shows only that page's sections
//   and the rest of the tab stays hidden. A tab's first page ('main') also gets its summary cards and any section no
//   other page claims, so a new heading never goes missing. ?tab=x links still work and land on x's main page.
//   Each page: [label, title, what it is for, icon, group, tab, headings or null for all, guide section, who can see it]
if (!defined('SHY_API')) exit;

//MC 2026-10-15 Economy was one long list mixing the shop, prizes and Solana setup, and Sales showed five unrelated
//   parts. Split into Shop (what sells and what it costs), Rewards (what the game pays out) and Solana (wallet sign-in,
//   trophies and the public Treasury page). Each shop part has its own page now.
const ADMIN_GROUPS = ['' => '', 'work' => 'Daily work', 'people' => 'Players', 'shop' => 'Shop', 'money' => 'Rewards', 'chain' => 'Solana', 'reach' => 'Channels', 'reports' => 'Reports', 'system' => 'Team and system'];

function admin_pages() {
    return [
        'home'      => ['Home', 'Home', 'What needs you today, the health of the site and this week in numbers.', 'home', '', 'overview', ['This week so far', 'Setup'], 'overview', null, 'main'],

        'payouts'   => ['Payouts', 'Payouts', 'Pay what is owed to prize winners in $SHY with Phantom, and the 15 Club bounty.', 'wallet', 'work', 'rewards', ['Payouts', '15 Club bounty'], 'rewards', fn() => can('payouts'), 'main'],
        'fairplay'  => ['Fair Play', 'Fair Play', 'Players who may be farming League points with a second account. Look at their matches and strike any that should not count.', 'shield', 'work', 'fairplay', null, 'players', null],
        'fixweek'   => ['Fix a final week', 'Fix a final week', 'Correct a week that has already ended, before it is paid, and post the corrected results.', 'wrench', 'work', 'rewards', ['Fix a final week', 'Daily runs not in the League'], 'rewards', fn() => can('rewards', 2)],
        'orders'    => ['Orders and payments', 'Orders and payments', 'Every shop order, payments players say did not arrive, and the nightly check that matches payments on Solana.', 'receipt', 'work', 'shop', ['Payment help', 'Nightly payment check', 'Orders'], 'shop', null],
        'ideas'     => ['Ideas', 'Ideas', 'Player suggestions and the public Ideas board.', 'bulb', 'work', 'ideas', null, 'ideas', null],
        'live'      => ['Live rooms', 'Live rooms', 'Live matches running now. Close one only if it looks stuck.', 'live', 'work', 'live', null, 'boards', null],
        'chat'      => ['Live chat', 'Live chat', 'Moderate table chat in live matches and the list of blocked words.', 'chat', 'work', 'players', ['Live chat', 'Blocked words'], 'players', null],

        'players'   => ['All players', 'Players', 'Find, rename, combine or ban players, review names and award Koban.', 'users', 'people', 'players', null, 'players', null, 'main'],
        'holders'   => ['Holders', 'Holders', 'Connected wallets and the Shadows they hold.', 'gem', 'people', 'holders', ['Wallets and Shadows'], 'boards', null, 'main'],
        //MC 2026-10-12 every player's $SHY and Koban on one board (admin/holdings.js)
        'holdings'  => ['Holdings', '$SHY and Koban holdings', 'How much $SHY each player holds, their Army Rank, and the Koban in every account.', 'wallet', 'people', 'holders', ['$SHY and Koban'], 'boards', null],
        'tourneys'  => ['Tournaments', 'Tournaments', 'Schedule knockout tournaments, follow the bracket and pay the winners.', 'flag', 'people', 'tourneys', null, 'tourneys', null],
        'houses'    => ['Houses', 'Houses', 'Player teams, their weekly board and the Koban the top Houses win.', 'house', 'people', 'rewards', ['Houses'], 'rewards', null],
        'recover'   => ['Recover lost points', 'Recover lost League points', 'Put back League points from a saved copy of the scores. Owners only.', 'undo', 'people', 'rewards', ['Recover lost League points'], 'rewards', fn() => is_owner()],

        'sales'     => ['Sales', 'Sales', 'Revenue, what sells, and how Koban comes into and goes out of the economy.', 'chart', 'shop', 'shop', ['Sales by product', 'Koban flow'], 'shop', null, 'main'],
        'today'     => ["Today's shop", "Today's shop", 'The deal of the day, the Holo Foil cards, the picks and this week\'s bundle. Roll new ones if today\'s need a change.', 'store', 'shop', 'shop', ["Today's shop"], 'shop', null],
        'drops'     => ['Limited drops', 'Limited drops', 'Numbered card finishes sold for $SHY in a set window. Schedule one, follow it, or stop it.', 'drop', 'shop', 'shop', ['Limited drops'], 'shop', null],
        'prices'    => ['Shop prices', 'Shop prices', 'The Koban price of everything in the shop, by the whole shop, by kind, by rarity or one item at a time.', 'tag', 'shop', 'shop', ['Shop prices'], 'shop', null],
        'gifts'     => ['Give Koban or items', 'Give Koban or items', 'Send Koban or a shop item to a player, with a note.', 'gift', 'shop', 'shop', ['Give Koban or an item'], 'shop', null],

        'prizes'    => ['Prize budget', 'Prize budget and pools', 'How long the marketing wallet lasts, how each prize pool is sized and split, Koban prizes and the $SHY Army Ranks.', 'trophy', 'money', 'rewards', ['Prize pools and rules'], 'rewards', fn() => can('rewards')],
        'growth'    => ['Invites and tasks', 'Invites, ambassadors and tasks', 'Invite rewards, the ambassador board and the Daily X tasks.', 'spark', 'money', 'shop', ['Invite rewards', 'Ambassadors by month', 'Daily X tasks'], 'shop', null],
        'expeditions' => ['Expeditions and Seeker', 'Shadow Expeditions and the Seeker bonus', 'Turn Shadow Expeditions on or off, what they pay, how many a day and the daily Koban cap, and the one time Koban bonus for Solana Seeker owners.', 'flag', 'money', 'rewards', ['Shadow Expeditions', 'Seeker bonus'], 'rewards', fn() => can('rewards')],   //MC 2026-10-16
        'features'  => ['Turn off features', 'Turn off features', 'Switch the Deck Forge (forged decks), the Shogun and Shogun Elite off or on for the whole site.', 'flag', 'money', 'rewards', ['Turn off features'], 'rewards', fn() => can('rewards')],   //MC 2026-11-01
        'boss'      => ['The Shogun', 'The Shogun (boss bot)', 'The 1v1 boss bot: the Koban a win pays, how hard it plays, and who has beaten it.', 'flag', 'money', 'rewards', ['The Shogun'], 'rewards', fn() => can('rewards')],
        'elite'     => ['Shogun Elite', 'Shogun Elite (boss bot that sees your hand)', 'The Shogun\'s harder twin: it plays with the challenger\'s real hand in view. Its own reward, record and gate.', 'flag', 'money', 'rewards', ['Shogun Elite'], 'rewards', fn() => can('rewards')],   //MC 2026-10-30
        'events'    => ['Events', 'Events', 'Double Points Weekends and other League point multipliers, with their countdowns.', 'cal', 'money', 'rewards', ['Events'], 'rewards', fn() => can('rewards')],

        'exchange'  => ['Shy Swap', 'Shy Swap', 'The swap at shyonsol.io/swap: the Jupiter API key, the swap fee paid to the marketing wallet, and a check that Jupiter takes it.', 'wallet', 'chain', 'shop', ['Shy Swap'], 'shop', fn() => can('shop')],   //MC 2026-10-17
        'ewallet'   => ['Email wallets', 'Email wallets', 'A free Solana wallet by email (Crossmint) for players with no wallet app, in Telegram, on phones and on desktops.', 'mail', 'chain', 'shop', ['Email wallets'], 'shop', fn() => is_owner()],
        'trophies'  => ['Trophies on Solana', 'Trophies on Solana', 'Trophy NFTs minted to winners\' wallets through Crossmint: the settings, what is waiting and what has minted.', 'trophy', 'chain', 'shop', ['Trophies on Solana'], 'shop', fn() => can('shop', 2)],
        'treasury'  => ['Treasury page', 'Treasury page', 'What the public Treasury page shows: payouts, burns and treasury moves.', 'safe', 'chain', 'rewards', ['Treasury page'], 'rewards', fn() => can('payouts')],

        //MC 2026-10-15 Telegram was one page of nine parts. Now three: set up the bot, choose what it posts (with the hype
        //   cards), and the messages it sent
        'telegram'  => ['Telegram', 'Telegram setup', 'The bot and the chat it posts to, playing inside Telegram, reminders to players and the Game Design channel.', 'send', 'reach', 'telegram', ['Bot', 'Play inside Telegram', 'Reminders to players', 'Game Design channel', 'On time, even when the site is quiet'], 'telegram', null, 'main'],
        'tgposts'   => ['Telegram posts', 'What the bot posts', 'Every kind of post, grouped, with the new player, Shadow and trophy hype cards, the hourly caps and pins.', 'spark', 'reach', 'telegram', ['What gets posted', 'Hype cards'], 'telegram', null],
        'tgsent'    => ['Telegram messages', 'Telegram messages', 'Everything the bot posted in the chat: pin, change, delete or send again.', 'chat', 'reach', 'telegram', ['Messages sent', 'Send again'], 'telegram', null],
        //MC 2026-10-22 established coin communities from DexScreener, each with its own challenge page, posted by hand
        'vs'        => ['Community challenges', 'Community challenges', 'Find established coin communities on DexScreener, approve the ones worth challenging, and post each challenge to X by hand.', 'spark', 'reach', 'players', ['Community challenges'], 'players', null],
        'x'         => ['X posting', 'Posting to X', 'Posting wins to X, the tags and accounts on every post, and connected X accounts.', 'x', 'reach', 'players', ['Posting to X'], 'players', null],
        //MC 2026-10-14 ten ready hype posts built around the deck's cards, posted by hand from the brand account
        'hype'      => ['Hype posts', 'Hype posts for X', 'Ten ready hype posts about the game, built around real cards with their art previewed. Pick one, open it in X and post it.', 'spark', 'reach', 'players', ['Hype posts for X'], 'players', null],
        'xrel'      => ['Release posts', 'Release posts for X', 'Every release with its own share card and a post ready to send. Post the newest, or go back and post an older one.', 'spark', 'reach', 'players', ['Release posts for X'], 'players', null],   //MC 2026-10-15
        'email'     => ['Email', 'Email', 'Who gets which alert, the daily and weekly reports, and every email sent.', 'mail', 'reach', 'email', null, 'system', null],
        'art'       => ['Card art', 'Card art', 'Give any card new art: upload, set the focus, preview it, then publish. Season card ballots too.', 'image', 'reach', 'art', null, 'art', null],

        'analytics' => ['Player analytics', 'Player analytics', 'When and where players play, and where new players drop off.', 'pulse', 'reports', 'overview', ['When and where players play', 'Where players drop off'], 'overview', null],
        'weekly'    => ['Weekly boards', 'Weekly boards', 'Each week\'s final board, with CSV downloads.', 'list', 'reports', 'weekly', null, 'boards', null],
        'daily'     => ['Daily Challenge', 'Daily Challenge', 'Who played each day\'s Daily Challenge.', 'sun', 'reports', 'daily', null, 'boards', null],

        'team'      => ['Team', 'Team', 'Admins, roles, what each one can see and change, and a log of every sign-in and change.', 'key', 'system', 'team', null, 'team', null],
        'logs'      => ['Logs', 'Logs', 'Problems the site recorded. Most should stay empty.', 'log', 'system', 'logs', null, 'system', null],
        'backups'   => ['Backups', 'Backups', 'Daily and weekly copies of the data, and a download of everything.', 'box', 'system', 'backups', null, 'system', null],
        //MC 2026-10-13 upload a release zip and the server deploys it itself; owners only
        'deploy'    => ['Deploy an update', 'Deploy an update', 'Upload a release zip and the server swaps the site files itself. Card art is left in place.', 'wrench', 'system', 'deploy', null, 'system', fn() => is_owner()],
        'guide'     => ['How-to guide', 'How-to guide', 'Everything the admin can do, step by step.', 'book', 'system', 'guide', null, 'start', null],
        'account'   => ['My account', 'My account', 'Your details, your password, two-step sign-in and your access.', 'user', 'system', 'account', null, 'team', null],
    ];
}
// the pages this admin can open (their tab allowed, and the page's own check)
function admin_pages_ok() {
    $out = [];
    foreach (admin_pages() as $k => $p) { if (!tab_ok($p[5])) continue; if ($p[8] && !($p[8])()) continue; $out[$k] = $p; }
    return $out;
}
// a tab's main page: the one marked main, else its first page
function admin_main_page($tab, $pages) {
    $first = null;
    foreach ($pages as $k => $p) if ($p[5] === $tab) { if (($p[9] ?? '') === 'main') return $k; $first = $first ?? $k; }
    return $first;
}
// after a form is sent, go back to the page it came from (when it's a page of that tab). admin.js adds _p to every
//   form as it's sent; the Referer can't be used, the admin sends no-referrer
function admin_page_from_post($tab) {
    $p = (string)($_POST['_p'] ?? ''); $all = admin_pages();
    return isset($all[$p]) && $all[$p][5] === $tab ? $p : '';
}

//MC 2026-10-13 "Needs you": everything waiting on the team, in one list, newest worry first. Each item links to the
//   page that fixes it. Cheap checks only (files already loaded on most pages); the health check is the one the cron
//   saved in the last 10 minutes.
function admin_inbox($players, $ideaNew, $helpOpen) {
    $out = [];   // [level bad|warn|info, title, detail, page, anchor]
    if (can('payouts')) {
        $rw = load(REWARDS); $n = 0; $usd = 0.0; $appr = 0;
        foreach (payall_lists($rw) as [$per]) {
            $ref = &payout_list($rw, $per);
            $open = 0; foreach ((array)$ref as $w) if (empty($w['sig']) && empty($w['skip'])) { $open++; $usd += (float)($w['usd'] ?? 0); }
            unset($ref);
            $n += $open;
            if ($open && payout_block($rw, $per)) $appr++;
        }
        if ($n) $out[] = ['warn', $n . ($n === 1 ? ' prize to pay' : ' prizes to pay'), '$' . number_format($usd, 2) . ' in $SHY owed to winners.', 'payouts', 'payall'];
        if ($appr) $out[] = ['warn', $appr . ($appr === 1 ? ' prize list needs' : ' prize lists need') . ' a second admin', 'Over the approval limit, so another admin approves before it can be sent.', 'payouts', ''];
        if (function_exists('bounty_db')) foreach (bounty_db()['m'] ?? [] as $m => $bw) if (empty($bw['paid'])) { $out[] = ['warn', '15 Club bounty to pay', ($bw['name'] ?? 'A player') . ' won ' . gmdate('F', strtotime($m . '-01')) . '\'s bounty.', 'payouts', 'bounty']; break; }
    }
    if ($helpOpen && can('shop')) $out[] = ['bad', $helpOpen . ($helpOpen === 1 ? ' player says' : ' players say') . ' a payment did not arrive', 'Match each one to its transaction or refund it.', 'orders', ''];
    if (can('players')) {
        $fl = defined('FP_FLAGS') ? (array)(load(FP_FLAGS)['list'] ?? []) : []; $wk = 0; foreach ($fl as $f) if (($f['t'] ?? 0) > time() - 7 * 86400) $wk++;
        if ($wk) $out[] = ['warn', $wk . ($wk === 1 ? ' match flagged' : ' matches flagged') . ' by the farming check', 'In the last 7 days. Look before the week is paid.', 'fairplay', 'fp-flags'];
        $rev = 0; foreach ($players as $p) if (name_blocked($p['name'] ?? '')) $rev++;
        if ($rev) $out[] = ['info', $rev . ($rev === 1 ? ' name to review' : ' names to review'), 'Names on the board that fail the name filter.', 'players', ''];
    }
    if ($ideaNew && can('ideas')) $out[] = ['info', $ideaNew . ($ideaNew === 1 ? ' new idea' : ' new ideas'), 'Player suggestions nobody has looked at yet.', 'ideas', ''];
    if (can('rewards') && function_exists('prize_runway')) {
        $set = eco_settings(); $warn = (int)($set['runway_warn'] ?? 4);
        $c = load(DATA_DIR . '/cache-runway.php');
        if (!$c || ($c['at'] ?? 0) < time() - 1800) { $r = prize_runway(shy_balance(mw_address())); $c = ['at' => time(), 'w' => $r['weeks'] === null ? null : (is_finite($r['weeks']) ? round($r['weeks'], 1) : 999)]; save(DATA_DIR . '/cache-runway.php', $c); }
        if ($warn && $c['w'] !== null && $c['w'] < $warn) $out[] = ['bad', 'About ' . $c['w'] . ' weeks of prizes left', 'The marketing wallet is running low at this week\'s prize pools.', 'prizes', 'budget'];
    }
    if (is_owner()) {
        $hh = null; try { $hh = health_get(300); } catch (Throwable $e) {}
        if ($hh) foreach ($hh['checks'] as $x) if ($x[1] !== 'ok') $out[] = [$x[1] === 'bad' ? 'bad' : 'warn', $x[0], $x[2], 'home', ''];
    }
    $rank = ['bad' => 0, 'warn' => 1, 'info' => 2];
    usort($out, fn($a, $b) => $rank[$a[0]] <=> $rank[$b[0]]);
    return $out;
}
function admin_inbox_html($inbox, $max) {
    if (!$inbox) return '<p class="needs-none">Nothing waiting. All clear.</p>';
    $h = '<ul class="needs-l">';
    foreach (array_slice($inbox, 0, $max) as [$lv, $t, $d, $p, $a]) $h .= '<li class="nd-' . $lv . '"><a href="?p=' . h($p) . ($a !== '' ? '#' . h($a) : '') . '"><i aria-hidden="true"></i><span><b>' . h($t) . '</b><small>' . h($d) . '</small></span></a></li>';
    if (count($inbox) > $max) $h .= '<li class="nd-more"><small>and ' . (count($inbox) - $max) . ' more on Home</small></li>';
    return $h . '</ul>';
}
