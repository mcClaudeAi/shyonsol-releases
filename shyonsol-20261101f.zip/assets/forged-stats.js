//MC 2026-11-01 Custom decks on the Stats page, from api/stats.php?a=forged: forged matches by kind, player wins, the last
//   30 days and the Forge masters (latest wins, most wins). The Forged record is its own territory: none of these count
//   toward the leaderboards or the Shogun and Elite records.
(function () {
  "use strict";
  var root = document.getElementById("fgs");
  if (!root) return;
  var $ = function (id) { return document.getElementById(id); };
  var LANG = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || "en";
  var D = null, view = "recent", shown = false;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function slug(n) { return String(n).replace(/ /g, "_"); }
  function who(n) { return '<a href="/p/' + encodeURIComponent(slug(n)) + '" data-i18n-skip>' + esc(n) + '</a>'; }
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t)), f;
    try { f = new Intl.RelativeTimeFormat(LANG, { numeric: "auto", style: "narrow" }); } catch (e) { return ""; }
    if (s < 3600) return f.format(-Math.max(1, Math.floor(s / 60)), "minute");
    if (s < 86400) return f.format(-Math.floor(s / 3600), "hour");
    return f.format(-Math.floor(s / 86400), "day");
  }
  function day(d) { try { return new Date(d + "T12:00:00Z").toLocaleDateString(LANG, { month: "short", day: "numeric" }); } catch (e) { return d; } }
  var KIND = { live: "Live match", shogun: "vs the Shogun", elite: "vs Shogun Elite" };
  function tiles() {
    var t = D.t || {};
    root.querySelectorAll("[data-fgs]").forEach(function (el) {
      var k = el.dataset.fgs;
      if (/N$/.test(k)) { var kk = k.slice(0, -1), w = t[kk + "W"] || 0; el.textContent = t[kk] ? "Players won " + fmt(w) + "." : ""; }
      else el.textContent = fmt(t[k] || 0);
    });
  }
  function days() {
    var list = D.days || [], max = 1; list.forEach(function (x) { max = Math.max(max, x[1]); });
    var any = list.some(function (x) { return x[1] > 0; });
    $("fgs-days").innerHTML = '<div class="sg-bars">' + list.map(function (x) {
      var h = 100 * x[1] / max, hw = x[1] ? h * x[2] / x[1] : 0;
      return '<span title="' + esc(day(x[0])) + ': ' + x[1] + ' / ' + x[2] + '"><i class="m" style="height:' + h.toFixed(1) + '%"></i><i class="w" style="height:' + hw.toFixed(1) + '%"></i></span>';
    }).join("") + '</div><div class="sg-ax"><span data-i18n-skip>' + esc(day(list[0] ? list[0][0] : "")) + '</span><span>Today</span></div>' + (any ? "" : '<p class="st-empty sg-none">No forged matches in the last 30 days.</p>');
  }
  function hall() {
    var el = $("fgs-list"), rows = view === "recent" ? D.recent : D.top;
    if (!rows || !rows.length) { el.innerHTML = '<li class="st-empty">No forged wins yet. Build a deck in the Forge.</li>'; return; }
    el.innerHTML = rows.map(function (x, i) {
      if (view === "recent") return '<li><span class="sg-chip" data-i18n-skip>' + x.r + '-' + x.v + '</span><span class="st-li-n">' + who(x.n) + '<small><span class="fgs-k">' + esc(KIND[x.k] || "") + '</span>' + (x.deck ? '<span data-i18n-skip>' + esc(x.deck) + '</span> · ' : "") + '<span data-i18n-skip>' + esc(ago(x.t)) + '</span></small></span></li>';
      return '<li><span class="st-pos">' + (i + 1) + '</span><span class="st-li-n">' + who(x.n) + '<small>Live <span data-i18n-skip>' + x.lw + '</span> · Shogun <span data-i18n-skip>' + x.sw + '</span> · Elite <span data-i18n-skip>' + x.ew + '</span></small></span><b class="st-li-v" data-i18n-skip>' + x.w + '-' + (x.g - x.w) + '</b></li>';
    }).join("");
  }
  function draw() { tiles(); days(); hall(); root.classList.add("on"); }
  root.addEventListener("click", function (e) {
    var b = e.target.closest("[data-fgv]"); if (!b || !D) return;
    b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    view = b.dataset.fgv; hall();
  });
  function load() { fetch("/api/stats.php?a=forged", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) { if (!j || !j.ok) return; D = j; if (shown) draw(); }).catch(function () {}); }
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { shown = true; io.disconnect(); if (D) draw(); } }); }, { rootMargin: "0px 0px -10% 0px" });
    io.observe(root);
  } else shown = true;
  load();
  setInterval(function () { if (!document.hidden && shown) load(); }, 60000);
})();
