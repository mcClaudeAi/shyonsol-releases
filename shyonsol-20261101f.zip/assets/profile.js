// Player profile: wallet-connected players see their stats, ranks, items and purchases, and can change their name.
(function () {
  "use strict";
  var root = document.getElementById("pf");
  if (!root) return;
  var API = "api/profile.php", HOLDER_API = "api/holder.php", SHOP_API = "api/shop.php";
  var AV = (document.querySelector('script[src*="profile.js"]') || {}).src;
  AV = AV && AV.indexOf("?") > 0 ? AV.slice(AV.indexOf("?")) : "";

  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  var me = { pid: store("shy-lb-pid"), key: store("shy-lb-key") };
  if (!me.pid) { me.pid = hex(8); store("shy-lb-pid", me.pid); }
  if (!me.key) { me.key = hex(16); store("shy-lb-key", me.key); }

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  //MC 2026-10-09 ledger note in its own element, item name and kind split, so each piece hits its own dictionary key
  var LED_KIND = /^(.+) (card frame|table|victory effect|title|name ring|reactions|card back|share card|page banner|nameplate|page effect|page accent|for your page|portrait frame|page seal)$/;   //MC 2026-10-10 plus the new Studio frames and seals
  function ledNote(w) { var m = LED_KIND.exec(w || ""); return '<em class="hi-w">' + (m ? '<i>' + esc(m[1]) + '</i> <i>' + esc(m[2]) + '</i>' : esc(w)) + '</em>'; }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  //MC 2026-10-09 added thousands separators, "$1500.00" didn't match the rest of the site
  function usd(n) { n = Number(n || 0); return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
  function short(w) { return w ? w.slice(0, 4) + "…" + w.slice(-4) : ""; }
  var L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined;   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
  function date(ts, withTime) {
    var d = new Date(ts * 1000);
    return d.toLocaleDateString(L, { month: "short", day: "numeric", year: withTime ? undefined : "numeric" }) + (withTime ? ", " + d.toLocaleTimeString(L, { hour: "numeric", minute: "2-digit" }) : "");
  }
  function ago(ts) {
    var s = Math.max(0, Date.now() / 1000 - ts);
    // in the reader's own language, so it never needs translating
    var f; try { f = new Intl.RelativeTimeFormat(L, { numeric: "auto", style: "short" }); } catch (e) { f = null; }
    if (!f) return date(ts);
    if (s < 90) return f.format(0, "minute");
    if (s < 3600) return f.format(-Math.round(s / 60), "minute");
    if (s < 86400) return f.format(-Math.round(s / 3600), "hour");
    if (s < 86400 * 7) return f.format(-Math.round(s / 86400), "day");
    return date(ts);
  }
  function koban(n) { return '<span class="kb"><i class="kb-coin" aria-hidden="true"></i>' + fmt(n) + '</span>'; }
  async function post(url, body) {
    try {
      var r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) });
      var j = await r.json(); if (j && !j.ok && !j.status) j.status = r.status; return j;
    } catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  function provider() {
    var w = window;
    if (w.phantom && w.phantom.solana && w.phantom.solana.isPhantom) return w.phantom.solana;
    if (w.solflare && w.solflare.isSolflare) return w.solflare;
    if (w.backpack && w.backpack.solana) return w.backpack.solana;
    return w.solana || null;
  }
  function isPhone() { return /iPhone|iPad|Android/i.test(navigator.userAgent); }

  //MC 2026-10-10 the $SHY Army Ranks replace the Bronze to Kami tiers: each rank has its emblem from the community poster
  var RK = ["sapling", "cadet", "scout", "knight", "champion", "commander", "sovereign", "king", "supreme"];
  var RKN = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King / Queen", supreme: "Shytoshi Supreme" };
  var RKC = ["Recruits", "Recruits", "Recruits", "Officers", "Officers", "Officers", "High Command", "High Command", "High Command"];
  function rkImg(k, small) { return "/assets/ranks/" + k + (small ? "-64" : "") + ".webp"; }
  function tierChip() {
    if (RKN[P.tier]) return '<span class="pf-tier rk t-' + P.tier + '"><img src="' + rkImg(P.tier, 1) + '" alt="" width="22" height="22"><span data-i18n-skip>' + esc(RKN[P.tier]) + '</span></span>';
    return P.tier === "shadow" ? '<span class="pf-tier t-shadow">Shadow holder</span>' : '<span class="pf-tier">Connected player</span>';
  }
  // the rank panel under the header: emblem, name, $SHY held, how far the next rank is, and all nine on a track
  function rankCard() {
    if (!P.shy && !P.tier) return "";
    var k = RKN[P.tier] ? P.tier : "", i = RK.indexOf(k), nx = P.next, bal = P.shy ? Math.floor(P.shy.bal) : 0, from = P.tierAt || 0;
    var pct = nx ? Math.max(3, Math.min(100, Math.round((bal - from) / Math.max(1, nx.at - from) * 100))) : 100;
    var need = !nx ? '<p class="rk-need">The top of the ranks.</p>'
      : !k ? '<p class="rk-need">Hold any $SHY in your connected wallet to join as a <b data-i18n-skip>' + esc(RKN.sapling) + '</b>.</p>'
      : '<p class="rk-need">' + fmt(Math.ceil(nx.need)) + ' more $SHY to reach <b data-i18n-skip>' + esc(P.nextName) + '</b></p>';
    var track = RK.map(function (r, j) { return '<i class="rk-step' + (j < i ? " done" : j === i ? " on" : "") + '" title="' + esc(RKN[r]) + '"><img src="' + rkImg(r, 1) + '" alt="" width="64" height="64" loading="lazy"></i>'; }).join("");
    return '<section class="rk-card rk ' + (k ? "t-" + k : "t-none") + '"><div class="rk-em"><img src="' + rkImg(k || "sapling") + '" alt="" width="256" height="256"></div>' +
      '<div class="rk-txt"><span class="rk-k">' + (k ? '$SHY Army Rank &middot; ' + RKC[i] : "$SHY Army Ranks") + '</span>' +
      (k ? '<h2 class="rk-name" data-i18n-skip>' + esc(RKN[k]) + '</h2>' : '<h2 class="rk-name">' + (P.tier === "shadow" ? "Shadow holder" : "No rank yet") + '</h2>') +
      '<p class="rk-sub"><b>' + fmt(bal) + '</b> $SHY held</p></div>' +
      '<div class="rk-next">' + need + (nx && k ? '<span class="rk-bar"><i style="width:' + pct + '%"></i></span>' : "") + '<div class="rk-track">' + track + '</div>' +
      '<a class="rk-all" href="/token#holders">See every rank and its perks</a></div></section>';
  }
  var MODE = { normal: "Solo", easy: "Solo · Easy", daily: "Daily", live: "Live" };
  var RES = { win: "Win", tie: "Tie", loss: "Loss" };
  var ORDER_ST = {
    paid: ["ok", "Delivered", ""],
    open: ["wait", "Confirming", "Waiting for Solana to confirm the payment."],
    unpaid: ["mute", "Not paid", "No payment was sent for this order."],
    expired: ["mute", "Expired", "This price hold ran out before a payment arrived."],
    self: ["wait", "Checking", "Paid from the marketing wallet. Checking the transfer on Solana."],
    nopay: ["bad", "Not delivered", "That transaction sent nothing to the marketing wallet. Contact us with the order number."],
    failed: ["bad", "Failed on Solana", "The payment failed on Solana, so nothing was taken except the network fee."],
    dropped: ["mute", "Didn't go through", "Solana never confirmed this payment, so nothing left your wallet. Buy again to try once more."],
    short: ["bad", "Underpaid", "The payment was less than the price. Contact us with the order number."]
  };

  // ---------- not connected ----------
  function locked(msg, err) {
    var p = provider(), btn;
    if (p) btn = '<button class="btn btn-red" data-connect>Connect wallet</button>';
    //MC 2026-10-15 saved to the home screen: no wallet here, and Open in Phantom would leave the app for good. The Play
    //   page hands off to the wallet app and brings the sign-in back (play.js, home screen app hand-off).
    else if (isPhone() && (window.navigator.standalone || (window.matchMedia && matchMedia("(display-mode: standalone)").matches))) btn = '<a class="btn btn-red" href="/play#game">Connect on the Play page</a>';
    //MC 2026-10-18 phones without a wallet in the browser used to get bare Open-in links: the wallet app signed in on
    //   its own browser and this tab never heard about it. Now it is the Play page hand-off (tglink claim): the wallet
    //   app signs in there, and this tab follows to that profile by itself when you come back.
    else if (isPhone()) {
      btn = '<button class="btn btn-red" data-ho="phantom">Open in Phantom</button>' +
        '<button class="btn btn-line" data-ho="solflare">Open in Solflare</button>';
      if (!msg && hoOn()) msg = "Approve in your wallet app, then come back here. This signs in by itself.";
    } else btn = '<a class="btn btn-red" href="https://phantom.com" target="_blank" rel="noopener">Get Phantom</a>';
    if (!p && window.ShyEW && ShyEW.ready()) btn += '<span class="ew-or">No wallet? Get a free one</span>' + ShyEW.buttons("btn-line");
    var ghost = ["Points", "Win rate", "Best game", "Live record", "This week", "League"].map(function (l) { return '<div class="pf-stat"><small>' + l + '</small><b>' + "&#9608;&#9608;&#9608;" + '</b></div>'; }).join("");
    root.innerHTML = '<div class="pf-lock reveal in"><div class="pf-lock-in"><span class="pf-seal">名</span><h1>Your profile</h1>' +
      '<p>Profiles are for connected players. Connect a Solana wallet to claim your name, keep your record on every device, and see every game, rank and reward in one place.</p>' +
      '<div class="pf-lock-btns">' + btn + '<a class="btn btn-line" href="/play">Keep playing as a guest</a></div>' +
      '<small>Free. You sign a message, not a transaction.</small>' + (msg ? '<p class="pf-msg' + (err ? " err" : "") + '">' + esc(msg) + '</p>' : "") + '</div>' +
      '<div class="pf-ghost" aria-hidden="true">' + ghost + '</div></div>';
  }
  //MC 2026-10-18 the wallet app hand-off, the same machinery the game uses from Telegram and the home screen app:
  //   a one-time code signs the wallet app's browser in as this profile, the wallet connects there, and this tab
  //   polls howait until it hears which profile to follow, then reloads signed in.
  function hoOn() { var h = hoGet(); return !!(h && Date.now() - h.t < 1800000); }
  function hoGet() { try { return JSON.parse(store("shy-pf-ho") || "null"); } catch (e) { return null; } }
  async function hoStart(app) {
    locked("Opening your wallet...");
    var j = await post("/api/tglink.php", { a: "handoff" });
    //MC 2026-10-19 a stale device key: rotate to a fresh guest identity and ask once more; the wallet sign-in
    //   then carries this device to its real profile
    if (!j.ok && j.stale) { me.pid = hex(8); me.key = hex(16); store("shy-lb-pid", me.pid); store("shy-lb-key", me.key); j = await post("/api/tglink.php", { a: "handoff" }); }
    if (!j.ok) { locked(j.error || "Couldn't start. Check your connection and try again.", true); return; }
    store("shy-pf-ho", JSON.stringify({ c: j.code, t: Date.now() }));
    var here = location.origin + "/play?claim=" + j.code + "&pf=1";
    location.href = app === "solflare"
      ? "https://solflare.com/ul/v1/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin)
      : "https://phantom.app/ul/browse/" + encodeURIComponent(here) + "?ref=" + encodeURIComponent(location.origin);
    setTimeout(function () { if (!P) locked(); }, 600);
  }
  var hoBusy = false;
  async function hoPoll() {
    var h = hoGet();
    if (!h || P || hoBusy) return;
    if (Date.now() - h.t > 1800000) { store("shy-pf-ho", ""); return; }
    hoBusy = true;
    try {
      var w = await post("/api/tglink.php", { a: "howait", code: h.c });
      if (w && w.to) {
        store("shy-pf-ho", "");
        if (w.to !== me.pid) { me.pid = w.to; store("shy-lb-pid", me.pid); }
        if (w.name) store("shy-lb-name", w.name);
        store("shy-holder", ""); store("shy-avatar", "");
        location.reload(); return;
      }
      if (w && w.gone) store("shy-pf-ho", "");
    } finally { hoBusy = false; }
  }
  document.addEventListener("visibilitychange", function () { if (!document.hidden) hoPoll(); });
  setInterval(hoPoll, 4000);
  async function connect(pGiven, fresh) {
    var p = pGiven && pGiven.signMessage ? pGiven : provider(); if (!p) return locked();
    try {
      locked("Approve the connection in your wallet…");
      var res = await p.connect();
      var pk = ((res && res.publicKey) || p.publicKey).toString();
      var n = await post(HOLDER_API, { a: "nonce", wallet: pk });
      if (!n.ok) throw new Error(n.error || "Couldn't start verification.");
      locked("Sign the message in your wallet. It's free and not a transaction.");
      var out = await p.signMessage(new TextEncoder().encode(n.message), "utf8");
      //MC 2026-10-15 an email wallet (assets/ewallet.js) hands back its Crossmint sign-in token instead of a signature
      var cmJwt = out && out.cmJwt ? out.cmJwt : "";
      var sig = cmJwt ? null : (out && out.signature ? out.signature : out);
      var b64 = cmJwt ? "" : btoa(String.fromCharCode.apply(null, Array.from(new Uint8Array(sig))));
      var v = await post(HOLDER_API, { a: "verify", nonce: n.nonce, signature: b64, cm: cmJwt });
      //MC 2026-10-19 a stale device key can't vouch for its profile: rotate to a fresh guest identity and run the
      //   connect once more, and the wallet signature signs this device into its real profile.
      if (!v.ok && v.stale && !fresh) {
        me.pid = hex(8); me.key = hex(16); store("shy-lb-pid", me.pid); store("shy-lb-key", me.key);
        return connect(pGiven, true);
      }
      if (!v.ok) throw new Error(v.error || "Verification failed.");
      if (v.switch && v.switch !== me.pid) { me.pid = v.switch; store("shy-lb-pid", me.pid); }
      if (v.name) store("shy-lb-name", v.name);
      if (v.holder && v.shadows && v.shadows[0]) store("shy-avatar", String(v.shadows[0].n));
      //MC 2026-10-15 a Seeker phone owner's one-time welcome bonus
      if (v.seekerBonus) setTimeout(function () { flNote("Seeker owner! +" + fmt(v.seekerBonus) + " Koban welcome bonus"); }, 600);
      load();
    } catch (e) {
      var m = (e && e.message) || "";
      locked(/reject|denied|cancel/i.test(m) ? "Cancelled in your wallet. Nothing was signed." : m || "Something went wrong. Try again.", true);
    }
  }

  // ---------- connected ----------
  var P = null, editing = false;
  function rank(r) { return r && r.rank ? '#' + fmt(r.rank) + ' <small>of ' + fmt(r.of) + '</small>' : '<small>Unranked</small>'; }

  //MC 2026-10-13 power tiers: one bar to 9,000 meant the top players sat on a full bar forever and the 9,000 label
  //   collided with the number. Now the bar is progress through the CURRENT tier, 9,000 is the gate into Limit Breaker
  //   (where the meter cracks for good), and Final Form at 35,000 is the show the top players earn. Tier names stay
  //   untranslated like brand words. assets/eggs.js animates it.
  var PW_TIERS = [["Initiate", 0, "\u521D"], ["Ronin", 3000, "\u6D6A"], ["Limit Breaker", 9000, "\u9650"], ["Warlord", 18000, "\u8987"], ["Final Form", 35000, "\u6975"]];
  function power(s) {
    var pw = s.points + 90 * s.wins + 45 * s.best + 9 * s.games;
    var ti = 0; for (var i = 0; i < PW_TIERS.length; i++) if (pw >= PW_TIERS[i][1]) ti = i;
    var tier = PW_TIERS[ti], next = PW_TIERS[ti + 1] || null;
    var pct = next ? Math.min(100, 100 * (pw - tier[1]) / (next[1] - tier[1])) : 100;
    var rows = [["Points", s.points, 1], ["Wins", s.wins, 90], ["Best boards", s.best, 45], ["Games", s.games, 9]];
    return '<section class="pw-strip t' + (ti + 1) + (ti >= 2 ? " broken" : "") + (next ? "" : " final") + '" data-pw="' + pw + '" data-pct="' + pct.toFixed(1) + '" role="button" tabindex="0" aria-expanded="false">' +
      '<i class="pw-kanji" aria-hidden="true" data-i18n-skip>' + tier[2] + '</i>' +
      '<div class="pw-top"><small>Power level</small><b class="pw-n" data-i18n-skip>' + fmt(pw) + '</b><span class="pw-tier" data-i18n-skip><i>' + tier[2] + '</i>' + tier[0] + '</span><span class="pw-hint">Tap for the breakdown</span></div>' +
      '<span class="pw-bar"><i class="pw-fill" style="width:' + pct.toFixed(1) + '%"></i></span>' +
      '<span class="pw-sub">' + (next ? '<span>Next tier:</span> <b data-i18n-skip>' + next[0] + '</b> <span>at</span> <b data-i18n-skip>' + fmt(next[1]) + '</b>' + (ti >= 2 ? ' <span>The meter was not built for this.</span>' : "") : '<span>The ladder ends here. The meter gave up long ago.</span>') + '</span>' +
      '<div class="pw-break" hidden>' + rows.map(function (r) {
        return '<div class="pw-row"><span>' + r[0] + '</span><em data-i18n-skip>' + fmt(r[1]) + (r[2] > 1 ? " \u00D7 " + r[2] : "") + '</em><b data-i18n-skip>+' + fmt(r[1] * r[2]) + '</b></div>';
      }).join("") + '</div></section>';
  }
  function stat(label, value, sub, cls) { return '<div class="pf-stat' + (cls ? " " + cls : "") + '"><small>' + label + '</small><b>' + value + '</b>' + (sub ? '<span>' + sub + '</span>' : "") + '</div>'; }
  function avatarImg() {
    var s = (P.shadows || []).filter(function (x) { return x.n === String(P.avatar); })[0] || (P.shadows || [])[0];
    var sk = P.eco && P.eco.eq && P.eco.eq.skin && /^skin_[a-z]+$/.test(P.eco.eq.skin.id) ? P.eco.eq.skin : null;
    var ak = s && { "electric cyan": "cyan", "crimson glow": "crimson", "lightning aura": "lightning", "money aura": "money", "btc aura": "btc" }[String(s.aura || "").toLowerCase()] || "none";
    var hl = P.eco && P.eco.eq && P.eco.eq.halo ? String(P.eco.eq.halo.id).slice(5) : "";
    return s && s.img ? '<img class="av-aura au-' + ak + (/^[a-z]+$/.test(hl) ? " hl-" + hl : "") + '" src="' + esc(s.img) + '" alt="Shadow #' + esc(s.n) + '">' : sk ? '<img src="assets/art/skins/' + sk.id + '.svg' + AV + '" alt="' + esc(sk.name) + '" title="' + esc(sk.name) + '">' : '<img src="assets/art/masks/unbound.svg' + AV + '" alt="">';
  }
  function render() {
    var s = P.stats, e = P.eco, wr = s.games ? Math.round(s.wins / s.games * 100) : 0;
    var pc = e.public || (P.eco && P.eco.public) || null;
    var title = (pc && pc.imp > 0 && pc.imp < 5 ? '<i class="imp-cr c' + (pc.imp | 0) + '" title="Imperial crest"></i>' : "") + (e.eq.title ? '<em class="g-title' + (pc && pc.tim ? " imp" : "") + '">' + esc(e.eq.title.name) + '</em>' : "");   //MC 2026-10-24 the Imperial crest and title
    var pg = (P.eco && P.eco.page) || {}, L = window.ShyLook;
    //MC 2026-10-10 the banner's moving layer and the Studio portrait frame and seal
    var av = '<div class="pf-av' + (P.tier ? " holder" : "") + '">' + avatarImg() + '</div>';
    var head = '<section class="pf-card pf-head ' + (L ? L.head(pg) : "") + '">' + (L ? (L.layers ? L.layers(pg, 11) : L.fx(pg, 11)) : "") +
      (L && L.avatar ? L.avatar(pg, av) : av) +
      '<div class="pf-id">' + tierChip() +
      //MC 2026-10-09 hint said 2 to 16 letters, numbers or spaces, but the server allows 3 to 20 with dots and dashes. Matched it to the server
      (editing ? '<form class="pf-name-form" id="pf-name-form"><input id="pf-name" maxlength="20" value="' + esc(P.name) + '" placeholder="Pick a name" autocomplete="off" spellcheck="false"><button class="btn btn-red btn-sm">Save</button><button type="button" class="btn btn-line btn-sm" data-cancel>Cancel</button></form><p class="pf-hint" id="pf-hint">3 to 20 letters, numbers, spaces, dots or dashes. Shown on every leaderboard.</p>'
        : '<h1 class="pf-name' + (L ? L.name(pg) : "") + '">' + esc(P.name || "No name yet") + (P.locked ? '' : ' <button class="pf-edit" data-edit aria-label="Change name"><svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m14 6 4 4"/></svg></button>') + '</h1>') +
      title + '<div class="pf-meta"><span>' + short(P.wallet) + ' <button class="pf-copy" data-copy-w="' + esc(P.wallet) + '">Copy</button></span><span>Joined <span data-i18n-skip>' + date(P.since) + '</span></span>' + (P.last ? '<span>Last played <span data-i18n-skip>' + ago(P.last) + '</span></span>' : "") + '</div>' +
      (P.locked ? '<p class="pf-hint">An admin set this name.</p>' : "") + ppRow() + '<div class="pf-x" id="pf-x">' + xRow() + '</div><div class="pf-x pf-tg" id="pf-tg">' + tgRow() + '</div></div>' +
      '<div class="pf-wallet"><div><small>Koban</small><b>' + koban(e.koban) + '</b></div>' + (P.shy ? '<div><small>$SHY held</small><b>' + fmt(Math.round(P.shy.bal)) + '</b><span>' + usd(P.shy.usd) + '</span></div>' : "") +   //MC 2026-10-10 the next rank moved to the rank panel below
      '<a class="btn btn-line btn-sm" href="/play#shop">Open the shop</a></div>' +
      //MC 2026-10-13 flaunt: holders choose what their public page shows off. Off by default, saved to the server
      (P.shy ? '<div class="pf-flaunt"><small>Flaunt it</small>' +
        '<label><input type="checkbox" data-fl="shy"' + (P.flaunt && P.flaunt.shy ? " checked" : "") + '> <span>Show your $SHY held on your public page</span></label>' +
        '<label><input type="checkbox" data-fl="koban"' + (P.flaunt && P.flaunt.koban ? " checked" : "") + '> <span>Show your Koban on your public page</span></label></div>' : "") +
      '</section>';

    var stats = '<section class="pf-stats">' +
      stat("Points", fmt(s.points), "All-time " + rank(P.ranks.all), "hot") +
      stat("Win rate", wr + "%", fmt(s.wins) + " wins in " + fmt(s.games) + " games") +
      stat("Best game", s.best + ' <small>Regions</small>', "Most Regions held at the end") +
      stat("Live record", fmt(s.live_w) + "–" + fmt(Math.max(0, s.live_g - s.live_w)), "Live board " + rank(P.ranks.live)) +
      stat("This week", fmt(s.week) + ' <small>pts</small>', "Weekly " + rank(P.ranks.week)) +
      stat("Weekly League", fmt(P.league.pts) + ' <small>pts</small>', P.league.n >= P.league.min ? "League " + rank(P.ranks.league) : (P.league.min - P.league.n) + " more league games to qualify for prizes") +
      '</section>';

    var sc = e.scroll, into = sc.xp % 100, maxed = sc.tier >= sc.of;
    var st = e.streak || { n: 0, best: 0 };
    var prog = '<section class="pf-two"><div class="pf-card"><div class="pf-h"><h2>Season ' + sc.season + ' Scroll</h2><span>' + (sc.prem ? "Premium track" : "Free track") + '</span></div>' +
      '<div class="pf-scroll"><b>Tier ' + Math.min(sc.tier, sc.of) + '<small> / ' + sc.of + '</small></b><span class="dj-bar big"><i style="width:' + (maxed ? 100 : into) + '%"></i></span><small>' + (maxed ? "Complete" : (100 - into) + " XP to tier " + (sc.tier + 1)) + '</small></div>' +
      '<div class="pf-row"><div><small>Daily streak</small><b>' + fmt(st.n) + ' <small>' + (st.n === 1 ? "day" : "days") + '</small></b></div><div><small>Best streak</small><b>' + fmt(st.best || st.n) + ' <small>' + ((st.best || st.n) === 1 ? "day" : "days") + '</small></b></div><div><small>Items owned</small><b>' + fmt(e.owned) + '</b></div><div><small>Badges</small><b>' + fmt(s.badges) + '</b></div></div>' +
      //MC 2026-10-09 equipped item name in its own <em> so it gets translated
      (Object.keys(e.eq).length ? '<div class="pf-eq">' + Object.keys(e.eq).map(function (k) { return '<span><small>' + ({ pframe: "frame" }[k] || k) + '</small><em>' + esc(e.eq[k].name) + '</em></span>'; }).join("") + '</div>' : "") +
      '</div>' + shadowsCard() + '</section>';

    var games = gamesCard(s);

    var daily = P.dailies.length ? '<section class="pf-card"><div class="pf-h"><h2>Daily Challenge</h2><span>Last 7 days</span></div><div class="pf-days">' +
      P.dailies.map(function (d) { return '<div class="r-' + d.result + '"><small>' + date(Date.parse(d.day + "T12:00:00Z") / 1000).replace(/, \d{4}$/, "") + '</small><b>' + fmt(d.points) + '</b><span>' + RES[d.result] + ' · ' + d.regions + ' Regions</span></div>'; }).join("") + '</div></section>' : "";

    var pwHtml = power(P.stats);
    root.innerHTML = head + rankCard() + stats + pwHtml + '<div id="pf-studio-slot"></div><div id="pf-hype-slot"></div>' + prog + collectionCard() + games + daily + historyCard();
    studio();
    hype();
    //MC 2026-10-24 the living portrait: a holder's Shadow drawn with its depth map, following the pointer (assets/shadowplay.js)
    var sh0 = (P.shadows || []).filter(function (x) { return x.n === String(P.avatar); })[0] || (P.shadows || [])[0], pav = root.querySelector(".pf-av");
    if (sh0 && pav && window.ShyShadowPlay) ShyShadowPlay.portrait(".pf-av", sh0.n, { "electric cyan": "cyan", "crimson glow": "crimson", "lightning aura": "lightning", "money aura": "money", "btc aura": "btc" }[String(sh0.aura || "").toLowerCase()] || "none");
  }
  // Profile Studio: mounted once and moved back into place when the page redraws, so it never reloads on its own
  var studioEl = null;
  function studio() {
    var slot = document.getElementById("pf-studio-slot");
    if (!slot || !window.ShyStudio || !P.name) { if (slot) slot.remove(); return; }
    if (!studioEl) {
      studioEl = document.createElement("section"); studioEl.className = "pf-card st-card"; studioEl.id = "pf-studio";
      window.ShyStudio.mount(studioEl, {
        post: post, name: function () { return P.name; }, avatar: avatarImg,
        stats: function () { var t = P.stats || {}; return { wr: t.games ? Math.round(t.wins / t.games * 100) : 0, best: t.best || 0 }; },
        url: function () { return P.public && P.name ? "/p/" + encodeURIComponent(P.name.replace(/ /g, "_")) : ""; },
        onLook: function (pg) { P.eco.page = pg; applyLook(); }
      });
    }
    slot.replaceWith(studioEl);
  }
  //MC 2026-10-14 Hype your run: three ready-to-post lines about you, right under the Studio. The server writes them
  //   (profile.php a=hype) from your record, your signature card and your climb; Refresh asks again with a new seed.
  //   Each preview is the exact picture X will unfurl (api/share.php?hp=), and Share on X opens the post on your own X.
  //   Mounted once like the Studio, so a page redraw never throws away the set you were reading.
  var hypeEl = null, HY = { seed: 0, posts: null, ready: false, why: "", busy: false };
  function hype() {
    var slot = document.getElementById("pf-hype-slot");
    if (!slot || !P.name) { if (slot) slot.remove(); return; }
    if (!hypeEl) {
      hypeEl = document.createElement("section"); hypeEl.className = "pf-card hy-card"; hypeEl.id = "pf-hype";
      hypeEl.addEventListener("click", hypeTap);
      loadHype(Math.floor(Math.random() * 1000));
    }
    slot.replaceWith(hypeEl);
  }
  function drawHype() {
    var body;
    if (HY.busy && !HY.posts) body = '<p class="pf-empty">Writing your posts…</p>';
    else if (!HY.ready) body = '<p class="pf-empty">' + (HY.why === "private" ? "Your public page is private, and hype posts link to it. Turn it on above and they unlock." :
      HY.why === "games" ? "Play one game and your hype posts unlock." : "Couldn't write your posts just now. Try a refresh.") + '</p>';
    else body = '<div class="hy-grid">' + HY.posts.map(function (o, i) {
      return '<article class="hy-c"><a href="' + esc(o.url) + '" target="_blank" rel="noopener"><img src="' + esc(o.img) + '" alt="" loading="lazy"></a>' +
        '<p class="hy-t" data-i18n-skip>' + esc(o.t).replace(/\n/g, "<br>") + '</p>' +
        '<div class="hy-b"><button type="button" class="btn btn-mint btn-sm" data-hy-x="' + i + '">' + (window.ShyX ? ShyX.icon : "") + 'Share on X</button>' +
        '<button type="button" class="btn btn-line btn-sm" data-hy-copy="' + i + '">Copy</button></div></article>';
    }).join("") + '</div>';
    hypeEl.innerHTML = '<div class="pf-h hy-h"><div><span class="pf-k hy-k">Your megaphone · Hype posts</span><h2>Hype your run</h2></div>' +
      '<button type="button" class="btn btn-line btn-sm" data-hy-refresh' + (HY.busy ? " disabled" : "") + '>Refresh</button></div>' +
      '<p class="hy-lead">Three posts about you, written from your own record. The picture is yours too. Post one, or make it yours first.</p>' + body;
  }
  async function loadHype(seed) {
    HY.busy = true; drawHype();
    var j = await post(API, { a: "hype", seed: seed });
    HY.busy = false;
    if (j && j.ok) { HY.ready = !!j.ready; HY.why = j.why || ""; HY.posts = j.posts || null; HY.seed = seed; }
    else { HY.ready = false; HY.posts = null; HY.why = "err"; }
    drawHype();
  }
  function hypeTap(e) {
    var b = e.target.closest("[data-hy-refresh]");
    if (b) { if (!HY.busy) loadHype(HY.seed + 1); return; }
    b = e.target.closest("[data-hy-x]");
    if (b) {
      var o = HY.posts && HY.posts[+b.getAttribute("data-hy-x")]; if (!o) return;
      window.open("https://x.com/intent/tweet?text=" + encodeURIComponent(o.t + "\n" + o.url), "_blank");
      return;
    }
    b = e.target.closest("[data-hy-copy]");
    if (b) {
      var o2 = HY.posts && HY.posts[+b.getAttribute("data-hy-copy")]; if (!o2) return;
      var full = o2.t + "\n" + o2.url;
      var done = function () { var was = b.textContent; b.textContent = "Copied"; setTimeout(function () { b.textContent = was; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(full).then(done, function () {});
      else { var ta = document.createElement("textarea"); ta.value = full; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); done(); } catch (x) {} ta.remove(); }
    }
  }
  // the header of this page wears the same look as the public page
  function applyLook() {
    var L = window.ShyLook, h = root.querySelector(".pf-head"); if (!L || !h) return;
    var pg = P.eco.page || {};
    h.className = h.className.replace(/\s*pg-look|\s*pgb-[a-z]+/g, "") + " " + L.head(pg);
    h.querySelectorAll(".pgfx,.pgbg").forEach(function (x) { x.remove(); });
    var fx = L.layers ? L.layers(pg, 11) : L.fx(pg, 11); if (fx) h.insertAdjacentHTML("afterbegin", fx);
    //MC 2026-10-10 re-wrap the picture in its new frame and seal
    var av = h.querySelector(".pf-av"); if (av && L.avatar) { var w = av.closest(".pfr") || av; w.outerHTML = L.avatar(pg, av.outerHTML); }
    var n = h.querySelector(".pf-name"); if (n) n.className = "pf-name" + L.name(pg);
  }
  // ---------- X ----------
  var X = { enabled: false, user: null, msg: "" };
  var X_MSG = { linked: "X connected. Your badge shows on every leaderboard.", taken: "That X account is already linked to another player.",
    cancelled: "X connection cancelled. Nothing changed.", expired: "That took too long. Try connecting X again.", failed: "X didn't finish the connection. Try again in a minute." };
  function xRow() {
    var m = X.msg ? '<p class="pf-xmsg">' + esc(X.msg) + '</p>' : "";
    //MC 2026-10-11 "Post my wins to X": shown once X is connected and the admin has automatic posts on
    if (X.user) return '<div class="pf-xrow">' + ShyX.badge(X.user.username, true) + '<span class="pf-xv">Verified with X</span><button class="pf-xoff" data-x-off>Disconnect</button></div>' +
      (X.autoOn ? '<label class="pf-xauto"><input type="checkbox" data-x-auto' + (X.auto ? ' checked' : '') + '><span><b>Post my wins to X</b><small>When you win, your result card goes out on your X automatically. Up to 3 a day.</small></span></label>' : "") + m;
    if (X.enabled) return '<div class="pf-xrow"><button class="btn btn-line btn-sm pf-xon" data-x-on>' + (window.ShyX ? ShyX.icon : "") + 'Connect X</button><span class="pf-xv">Get the X badge on every leaderboard.</span></div>' + m;
    return m;
  }
  function drawX() { var el = document.getElementById("pf-x"); if (el) el.innerHTML = xRow(); }
  async function loadX() {
    if (!window.ShyX) return;
    var j = await ShyX.status(true);
    X.tags = (j && j.tags) || "";   //MC 2026-10-12 the admin's tags ride on profile shares too, like end-screen posts
    if (j && j.ok) { X.enabled = j.enabled; X.user = j.linked ? j.user : null; X.auto = !!j.auto; X.autoOn = !!j.autoOn; }
    var m = /[?&]x=([a-z]+)/.exec(location.search);
    if (m && X_MSG[m[1]]) { X.msg = X_MSG[m[1]]; try { history.replaceState(null, "", location.pathname + "#x"); } catch (e) {} }
    drawX();
  }
  // ---------- Telegram ----------
  var T = { ready: false, linked: false, msg: "", wait: 0 };
  var TG_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 3 3 10.5l7 2.5 2.5 7L21 3Z"/><path d="m10 13 4.5-4.5"/></svg>';
  function tgRow() {
    var m = T.msg ? '<p class="pf-xmsg">' + esc(T.msg) + '</p>' : "";
    if (!T.ready) return m;
    if (!T.linked) return '<div class="pf-xrow"><button class="btn btn-line btn-sm pf-xon" data-tg-on>' + TG_ICON + (T.wait ? "Check again" : "Link Telegram") + '</button><span class="pf-xv">' + (T.wait ? "Press Start in Telegram, then come back here." : "Play inside Telegram as you, and get a nudge before your streak ends.") + '</span></div>' + m;
    var who = T.user && T.user.un ? "@" + T.user.un : (T.user && T.user.fn) || "Telegram";
    var boxes = Object.keys(T.labels || {}).map(function (k) { return '<label class="pf-note"><input type="checkbox" data-tg-note="' + k + '"' + (T.notes[k] ? " checked" : "") + '> ' + esc(T.labels[k]) + '</label>'; }).join("");
    return '<div class="pf-xrow"><span class="pf-tgb">' + TG_ICON + '<span data-i18n-skip>' + esc(who) + '</span></span><span class="pf-xv">Telegram linked</span><button class="pf-xoff" data-tg-off>Unlink</button></div>' +
      '<div class="pf-notes"><small>Message me on Telegram about</small>' + boxes + '</div>' +
      (!T.dm ? '<p class="pf-xmsg">Open <a href="https://t.me/' + esc(T.bot) + '" target="_blank" rel="noopener">@' + esc(T.bot) + '</a> and press Start so the bot can message you.</p>' : "") + m;
  }
  function drawTg() { var el = document.getElementById("pf-tg"); if (el) el.innerHTML = tgRow(); }
  function takeTg(j) { if (!j || !j.ok) return; T.ready = j.ready; T.linked = j.linked; T.user = j.user; T.dm = j.dm; T.notes = j.notes; T.labels = j.labels; T.bot = j.bot; if (j.linked) T.wait = 0; }
  async function loadTg() { takeTg(await post("api/tglink.php", { a: "status" })); drawTg(); }
  function shadowsCard() {
    var list = P.shadows || [];
    if (!list.length) return '<div class="pf-card pf-shadows"><div class="pf-h"><h2>Shadows</h2></div><p class="pf-empty">No Shytoshi Shadows in this wallet. Holders play as their Shadow and every win is written to its record.</p><a class="btn btn-mint btn-sm" href="/nfts">Meet the Shadows</a></div>';
    //MC 2026-10-10 each Shadow shows its rarity rank, labelled so it can't be read as a game rank, with one line on what
    //   the two numbers mean. Players asked whether "#22, rank 1206" was their standing.
    var rar = function (r) { var n = parseInt(String(r == null ? "" : r).replace(/[^0-9]/g, ""), 10); return n > 0 ? n : 0; };
    return '<div class="pf-card pf-shadows"><div class="pf-h"><h2>Your Shadows</h2><span>' + list.length + '</span></div>' +
      '<p class="sh-key">The # is each Shadow\'s number in the collection. Rarity ranks it among all 1,335 Shadows, and 1 is the rarest. It\'s separate from your game rank (League, Ranked).</p><div class="pf-sh-grid">' + list.map(function (x) {
      var rk = rar(x.rank);
      return '<figure' + (String(P.avatar) === x.n ? ' class="on"' : "") + '>' + (x.img ? '<img src="' + esc(x.img) + '" alt="Shadow #' + esc(x.n) + '" loading="lazy">' : "") + '<figcaption>#' + esc(x.n) + '<small>' + fmt(x.wins) + 'W · ' + fmt(x.games) + 'G</small>' +
        (rk ? '<span class="sh-rar" title="Rarity rank among all 1,335 Shytoshi Shadows. 1 is the rarest.">Rarity #' + fmt(rk) + ' <small>of 1,335</small></span>' : "") + '</figcaption></figure>';
    }).join("") + '</div></div>';
  }
  // finishes owned, full sets and fully finished cards: the show-off side of the Cards tab
  //MC 2026-10-10 the Animated finishes too, so a showcased one has its name
  var FIN_N = { gold: "Gold Leaf", crimson: "Blood Moon", neon: "Neon Shrine", holo: "Holo Foil", shadow: "Shadow Ink", ink: "Ink Bleed", seal: "Vermilion Seal", smoke: "Smoke Wisp", kintsugi: "Kintsugi", sakura: "Sakura Drift", ember: "Ember Rise", frost: "Frost Creep", koi: "Koi Pond", raijin: "Raijin Crackle", glitch: "Glitch Scan", aurora: "Aurora Veil", cosmos: "Night Sky", regalia: "Imperial Gilt" };
  var KIND_N = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", trick: "Trick", passive: "Reaction" };
  function collectionCard() {
    var c = P.eco && P.eco.col; if (!c) return "";
    var fins = ["gold", "crimson", "neon", "holo", "shadow"].map(function (f) {
      return '<div class="pf-fin f-' + f + (c.by[f] ? " on" : "") + '"><i class="fd fd-' + f + (c.by[f] ? " on" : "") + '" aria-hidden="true"></i><small>' + FIN_N[f] + '</small><b>' + fmt(c.by[f] || 0) + '</b></div>';
    }).join("");
    var badges = c.sets.map(function (x) { return '<span class="pf-set f-' + x.fin + '" title="Every ' + KIND_N[x.kind] + ' card in ' + FIN_N[x.fin] + '">🏆 <span>' + KIND_N[x.kind] + ' set</span> · <span>' + FIN_N[x.fin] + '</span></span>'; });
    if (c.full) badges.push('<span class="pf-set f-all">✨ <span>' + (c.full === 1 ? "1 card with every finish" : fmt(c.full) + " cards with every finish") + '</span></span>');
    return '<section class="pf-card pf-col"><div class="pf-h"><h2>Collection</h2><span>Level ' + c.lv + '</span></div>' +
      '<p class="pf-col-n"><b>' + fmt(c.n) + '</b> <span>finishes owned across ' + fmt(c.cards) + ' cards</span></p>' +
      '<div class="pf-fins">' + fins + '</div>' +
      (badges.length ? '<div class="pf-sets">' + badges.join("") + '</div>' : '<p class="pf-empty">Own every card of one kind in one finish, like every Attack in Gold Leaf, and the set shows here.</p>') +
      '<a class="pf-more" href="/play#shop-cards">Open your cards →</a></section>';
  }
  // the public page at shyonsol.io/p/name: a link to it and a switch to keep it private
  function ppRow() {
    if (!P.name) return "";
    var url = "/p/" + encodeURIComponent(P.name.replace(/ /g, "_"));
    return '<div class="pf-pp">' + (P.public ? '<a href="' + url + '" class="pf-pp-l">Your public page →</a>' : '<span class="pf-pp-off">Your public page is private</span>') +
      '<label class="pf-pp-sw"><input type="checkbox" data-pp-public' + (P.public ? " checked" : "") + '> <span>Show my public page</span></label></div>';
  }
  //MC 2026-10-09 purchases and Koban activity, eight to a page; a page change redraws only this card (#pf-hist), so the
  //Profile Studio above it keeps whatever you were trying on
  var HPG = {};
  //MC 2026-10-11 a checkout you pressed Continue on but never paid stayed in Purchases as NOT PAID for a day, one card
  // per quote (pages of them for anyone who compared prices). Once its 20 minute price hold is over and no payment was
  // sent, it's left out and counted in one quiet line instead. The server still honours a late payment, and the check
  // below still looks for one, so a quote that did get paid comes back as Delivered.
  function abandoned(o) { return o.status === "open" && !o.sig && Date.now() / 1000 - o.ts > 20 * 60; }
  //MC 2026-10-11 amounts read like money: whole $SHY (243,821.138 showed three decimals), USDC to the cent, SOL to 4 places
  function amt(o) {
    var n = +o.amount, d = o.cur === "SOL" ? 4 : o.cur === "USDC" ? 2 : n >= 100 ? 0 : 2;
    return n.toLocaleString("en-US", { maximumFractionDigits: d }) + " " + (o.cur === "SHY" ? "$SHY" : esc(o.cur));
  }
  //MC 2026-10-12 Recent games became All matches: ten a page, each with Share on X and Telegram. The card for a share is
  //   made on the first tap (api/share.php checks the match against this record, so only real results get one); a boss
  //   match posts as a boss match with the Shogun's score when the boss record still holds it. The window a share opens
  //   in is created before the card is asked for, so popup blockers leave it alone (same pattern as the Telegram link).
  var GSH = {};   // per-match share state: { url, busy }
  function gamesCard(s) {
    s = s || P.stats;
    var pg = window.ShyPager ? ShyPager.slice(P.games, 10, HPG["pf-gm"]) : { items: P.games };
    var start = pg.per ? (pg.page - 1) * pg.per : 0;
    return '<section class="pf-card" id="pf-games"><div class="pf-h"><h2>All matches</h2><a href="/play">Play now →</a></div>' +
      (P.games.length ? '<p class="pf-sub-line">Your last ' + fmt(P.games.length) + ' matches, newest first.</p><ul class="pf-games">' + pg.items.map(function (g, k) {
        var i = start + k;
        return '<li class="r-' + g.r + '"><span class="pf-res">' + RES[g.r] + '</span><span class="pf-mode">' + (g.f ? "Forged · " : "") + (g.b ? (g.e ? "Shogun Elite" : "The Shogun") : (MODE[g.m] || g.m)) + '</span><span class="pf-reg">' + g.g + ' Regions' + (g.b && g.vs != null ? ' <small data-i18n-skip>· ' + g.g + '-' + g.vs + '</small>' : "") + '</span><b>+' + fmt(g.p) + '</b><small>' + ago(g.t) + '</small>' +
          '<span class="pf-share"><button type="button" class="pf-shb" data-shx="' + i + '" title="Share on X" aria-label="Share on X">𝕏</button><button type="button" class="pf-shb" data-shtg="' + i + '" title="Telegram" aria-label="Telegram" data-i18n-skip>TG</button></span></li>';
      }).join("") + '</ul>' + (window.ShyPager ? ShyPager.html(pg, "pf-gm") : "") :
      '<p class="pf-empty">' + (s.games ? "Your games show up here from now on. Older games still count in your totals above." : "No games yet. Your first one is a click away.") + '</p>') + '</section>';
  }
  function postText(g) {
    var R = " of 40 Regions.";
    var head;
    if (g.b) {
      var BN = g.e ? "Shogun Elite" : "the Shogun";   //MC 2026-10-30
      if (g.r === "win") head = "I beat " + BN + " in Shilluminati Online" + (g.vs != null ? ", " + g.g + " Regions to " + g.vs + "." : " with " + g.g + " Regions.") + "\nThe hardest bot in the game. It plays every move out to the end before it chooses.";
      else if (g.r === "tie") head = "Fought " + BN + " to a draw in Shilluminati Online at " + g.g + " Regions.";
      else head = (g.e ? "Shogun Elite" : "The Shogun") + " held the world" + (g.vs != null ? ", " + g.vs + " Regions to my " + g.g + "." : ". I made it to " + g.g + " Regions.");
    } else if (g.m === "daily") head = (g.r === "win" ? "Won a Shilluminati Daily Challenge with " + g.g + R : "Took " + g.g + " Regions in a Shilluminati Daily Challenge.");
    else if (g.m === "live") head = (g.r === "win" ? "Won a live Shilluminati match with " + g.g + R : g.r === "tie" ? "Tied a live Shilluminati match at " + g.g + " Regions." : "Took " + g.g + " Regions in a live Shilluminati match.");
    else head = (g.r === "win" ? "Ruled the world in a solo Shilluminati game, " + g.g + R : "Fought for the world in a solo Shilluminati game, " + g.g + " Regions.");
    var who = P.avatar ? "Playing as Shadow #" + P.avatar + ". " : "";
    var tail = g.b ? (g.r === "win" ? "Think you can do it too?" : "Think you can do better?") : (g.r === "win" ? "Think you can beat it?" : "Rematch incoming.");
    var text = head + "\n\n" + who + tail + " Play free with @ShyOnSol_ $SHY";
    var miss = (X.tags || "").split(/\s+/).filter(function (t) { return t && text.toLowerCase().indexOf(t.toLowerCase()) < 0; }).join(" ");
    if (miss && (text + "\n" + miss).length < 240) text += "\n" + miss;
    return text;
  }
  function shareCard(i) {
    var g = P.games[i], st = GSH[i];
    if (st && st.url !== undefined) return Promise.resolve(st.url);
    // the board is gone with the room, so the map on the card is laid out from the score, seeded by the match time
    var N = 40, rng = (g.t || 1) >>> 0, rnd = function () { rng = (rng * 1103515245 + 12345) & 0x7fffffff; return rng / 0x7fffffff; };
    var marks = []; for (var k = 0; k < N; k++) marks.push("o");
    var spots = []; for (k = 0; k < N; k++) spots.push(k); spots.sort(function () { return rnd() - 0.5; });
    for (k = 0; k < Math.min(N, g.g); k++) marks[spots[k]] = "0";
    if (g.b && g.vs != null) for (k = 0; k < Math.min(N - g.g, g.vs); k++) marks[spots[g.g + k]] = "1";
    var standings = [{ n: P.name || "You", r: g.g, c: 0, me: true }];
    if (g.b) standings.push({ n: g.e ? "Shogun Elite" : "The Shogun", r: g.vs != null ? g.vs : 0, c: 1 });
    var body = { a: "create", pid: me.pid, key: me.key, name: P.name || "Player", avatar: P.avatar || "", mask: "unbound",
      owners: marks.join(""), rounds: "", kind: g.b ? "live" : (g.m === "daily" ? "daily" : (g.m === "live" ? "live" : "solo")),
      boss: !!g.b, elite: !!g.e, result: g.r, regions: g.g, mode: g.m === "easy" ? "easy" : "normal", dailyNo: 0, humans: 1, standings: standings };
    return fetch("api/share.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); }).then(function (j) { var u = j && j.ok ? j.url : ""; GSH[i] = { url: u }; return u; })
      .catch(function () { GSH[i] = { url: "" }; return ""; });
  }
  async function shareMatch(i, to, btn) {
    var g = P.games[i]; if (!g || (GSH[i] && GSH[i].busy)) return;
    GSH[i] = GSH[i] || {}; GSH[i].busy = 1;
    var was = btn.textContent; btn.textContent = "…"; btn.disabled = true;
    var w = window.open("about:blank", "_blank");   // opened on the tap itself, so the browser allows it
    var url = await shareCard(i);
    GSH[i].busy = 0; btn.textContent = was; btn.disabled = false;
    var link = url || (g.b ? "https://shyonsol.io/shogun" : "https://shyonsol.io/play?v=w3");   //MC 2026-10-13 ?v=w3 so X unfurls the current preview, not its cached old one
    var text = postText(g);
    var dest = to === "tg" ? "https://t.me/share/url?url=" + encodeURIComponent(link) + "&text=" + encodeURIComponent(text)
      : "https://x.com/intent/tweet?text=" + encodeURIComponent(text + "\n" + link);
    if (w) w.location = dest; else location.href = dest;
  }
  function historyCard() {
    var all = (P.orders || []).filter(function (o) { return o.status === "paid" || o.sig || o.status === "open"; });
    var orders = all.filter(function (o) { return !abandoned(o); }), quiet = all.length - orders.length;
    var skipped = quiet ? '<p class="pf-empty hi-skip">' + (quiet === 1 ? "1 checkout you started but didn't pay is hidden. Nothing was taken from your wallet." : fmt(quiet) + " checkouts you started but didn't pay are hidden. Nothing was taken from your wallet.") + '</p>' : "";
    var po = window.ShyPager ? ShyPager.slice(orders, 8, HPG["pf-ord"]) : { items: orders };
    var o = orders.length ? '<ul class="hi-list">' + po.items.map(function (o) {
      var st = o.status === "open" && !o.sig ? "unpaid" : o.status, m = ORDER_ST[st] || ORDER_ST.open;
      var tx = o.proof && !/^(cs_|manual)/.test(o.proof) ? o.proof : o.sig;
      var price = o.cur === "CARD" ? usd(o.usd) + " by card" : (o.amount ? amt(o) : "") + ' <small>' + usd(o.usd) + '</small>';
      return '<li class="hi-o st-' + m[0] + '"><div class="hi-top"><b>' + esc(o.name) + '</b><span class="hi-pill">' + m[1] + '</span></div><div class="hi-meta"><span>' + price + '</span><span>' + date(o.paid || o.ts, true) + '</span><span class="hi-id">#' + esc(o.id) + '</span></div>' +
        (o.status === "paid" && o.got && o.got.length ? '<p class="hi-got">' + esc(o.got.join(", ")) + '</p>' : m[2] ? '<p class="hi-note">' + m[2] + '</p>' : "") +
        '<div class="hi-act">' + (tx ? '<a href="https://solscan.io/tx/' + esc(tx) + '" target="_blank" rel="noopener">View on Solscan</a>' : "") +
        (o.status !== "paid" && o.sig && ["expired", "nopay", "dropped"].indexOf(st) < 0 ? '<button class="btn btn-line btn-sm" data-recheck="' + esc(o.id) + '" data-sig="' + esc(o.sig) + '">Check again</button>' : "") + '</div></li>';
    }).join("") + '</ul>' + (window.ShyPager ? ShyPager.html(po, "pf-ord") : "") + skipped : '<p class="pf-empty">No purchases yet.</p>' + skipped;
    var led = P.eco.ledger || [], pl = window.ShyPager ? ShyPager.slice(led, 8, HPG["pf-led"]) : { items: led };
    var l = led.length ? '<ul class="hi-led">' + pl.items.map(function (x) { return '<li><span>' + ledNote(x.w) + '<small data-i18n-skip>' + date(x.t, true) + '</small></span><b class="' + (x.n < 0 ? "neg" : "pos") + '">' + (x.n > 0 ? "+" : "") + fmt(x.n) + '</b></li>'; }).join("") + '</ul>' + (window.ShyPager ? ShyPager.html(pl, "pf-led") : "") : '<p class="pf-empty">Koban you earn and spend shows up here.</p>';
    return '<section class="pf-two" id="pf-hist"><div class="pf-card"><div class="pf-h"><h2>Purchases</h2>' + (P.eco.spent ? '<span>' + usd(P.eco.spent) + ' total</span>' : "") + '</div>' + o + '<p class="pf-help"><a href="/play#shop-history">Paid, but nothing arrived? Paste the payment and we\'ll find it →</a></p></div>' +
      '<div class="pf-card"><div class="pf-h"><h2>Koban activity</h2></div>' + l + '</div></section>';
  }

  async function load() {
    var j = await post(API, { a: "me" });
    //MC 2026-10-19 this profile was combined into another: this device signs itself over and reloads as it
    if (j.moved) { me.pid = j.moved; store("shy-lb-pid", me.pid); if (j.name) store("shy-lb-name", j.name); location.reload(); return; }
    //MC 2026-10-19 a device whose key fell off the profile (too many sign-ins elsewhere) used to get one bare line
    //   and a dead end. Now it gets the connect card: one wallet approval and the profile is back on this device.
    if (!j.ok && (j.error || "") === "not your profile") { locked("This device got signed out, which can happen after signing in on several phones and apps. Connect your wallet and your profile comes right back.", false); return; }
    if (!j.ok) { root.innerHTML = '<p class="pf-empty">' + esc(j.error || "Couldn't load your profile.") + '</p>'; return; }
    if (!j.linked) {
      //MC 2026-10-15 email wallet (assets/ewallet.js): the key comes with the holder status
      if (window.ShyEW) { var hs = await post(HOLDER_API, { a: "status" }); if (hs && hs.ok) ShyEW.set(hs.ew); }
      return locked();
    }
    P = j.profile;
    if (P.name) store("shy-lb-name", P.name);
    render();
    loadX();
    loadTg();
    checkStale();
  }
  //MC 2026-10-11 payments still "confirming" after a few minutes get one fresh look on Solana. This used to check five,
  // then call load() again for the next five: the whole page (profile, X, Telegram, every rank emblem) reloaded up to
  // five times and jumped each time. Now every stale order is checked once, five at a time, then the profile is fetched
  // once more: a payment that turned up redraws the page (Koban and items changed), otherwise only Purchases is redrawn.
  async function checkStale() {
    var stale = (P.orders || []).filter(function (o) { return ["open", "self", "dropped"].indexOf(o.status) >= 0 && !load.done[o.id] && Date.now() / 1000 - o.ts > 240; });
    if (!stale.length) return;
    stale.forEach(function (o) { load.done[o.id] = 1; });
    var paid = false;
    for (var i = 0; i < stale.length; i += 5) {
      var rs = await Promise.all(stale.slice(i, i + 5).map(function (o) { return post(SHOP_API, { a: "check", order: o.id, sig: o.sig || "" }); }));
      rs.forEach(function (r) { if (r && r.ok && r.status === "paid") paid = true; });
    }
    var j = await post(API, { a: "me" });
    if (!j || !j.ok || !j.linked || !P) return;
    if (paid) { P = j.profile; render(); return; }
    P.orders = j.profile.orders;
    var hc = document.getElementById("pf-hist"); if (hc) hc.outerHTML = historyCard();
  }

  load.done = {};
  //MC 2026-10-13 flaunt switches save on tap (holder shows $SHY or Koban on their public page). The first cut called
  //   toast(), which only exists on the Play page: the success branch threw, the catch flipped the box back, and the
  //   choice never looked saved even though it was. flNote reuses the egg chip style.
  function flNote(t) {
    var c = document.querySelector(".egg-chip");
    if (!c) { c = document.createElement("div"); c.className = "egg-chip"; document.body.appendChild(c); }
    c.innerHTML = "<span>" + esc(t) + "</span>";
    c.classList.remove("on"); void c.offsetWidth; c.classList.add("on");
    clearTimeout(c._t); c._t = setTimeout(function () { c.classList.remove("on"); }, 2600);
  }
  root.addEventListener("change", function (e) {
    var fl = e.target.closest("[data-fl]"); if (!fl) return;
    var body = { a: "flaunt", pid: me.pid, key: me.key };
    root.querySelectorAll("[data-fl]").forEach(function (x) { body[x.dataset.fl] = x.checked ? 1 : 0; });
    fetch("/api/profile.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.ok) { P.flaunt = j.flaunt; flNote("Saved. Your public page shows what you picked."); } else { fl.checked = !fl.checked; flNote((j && j.error) || "Could not save that."); } })
      .catch(function () { fl.checked = !fl.checked; flNote("Could not save that."); });
  });
  root.addEventListener("click", async function (e) {
    var hp = window.ShyPager && ShyPager.hit(e, "pf-");
    if (hp) { HPG[hp.key] = hp.page; if (hp.key === "pf-gm") { var gc = document.getElementById("pf-games"); if (gc) gc.outerHTML = gamesCard(); } else { var hc = document.getElementById("pf-hist"); if (hc) hc.outerHTML = historyCard(); } return; }
    var b;
    if ((b = e.target.closest("[data-shx]"))) return shareMatch(+b.dataset.shx, "x", b);
    if ((b = e.target.closest("[data-shtg]"))) return shareMatch(+b.dataset.shtg, "tg", b);
    if (e.target.closest("[data-connect]")) return connect();
    var hb = e.target.closest("[data-ho]"); if (hb) return hoStart(hb.dataset.ho);
    var ewb = e.target.closest("[data-ew]");
    if (ewb && window.ShyEW) { ShyEW.start().then(function (ep) { if (ep && ep.publicKey) connect(ep); }).catch(function (x) { if (!/cancelled/.test(String(x && x.message))) locked((x && x.message) || "Couldn't open the sign-in. Try again.", true); }); return; }
    if (e.target.closest("[data-x-on]")) { var bx = e.target.closest("[data-x-on]"); bx.disabled = true; bx.lastChild.textContent = "Opening X…"; var r0 = await ShyX.start("/profile"); if (r0 !== true) { X.msg = (r0 && r0.error) || "Couldn't reach X."; drawX(); } return; }
    if (e.target.matches && e.target.matches("[data-x-auto]")) { var cb = e.target; cb.disabled = true; var ra = await ShyX.setAuto(cb.checked); cb.disabled = false; if (!ra.ok) { cb.checked = !cb.checked; X.msg = ra.error || "Couldn't save that."; drawX(); } else X.auto = cb.checked; return; }
    if (e.target.closest("[data-x-off]")) { await ShyX.unlink(); X.user = null; X.msg = "X disconnected. The badge is gone from the boards."; drawX(); return; }
    if (e.target.closest("[data-tg-on]")) {
      if (T.wait) { T.msg = ""; await loadTg(); if (!T.linked) { T.msg = "Not linked yet. In Telegram, press Start in the chat with the bot."; drawTg(); } return; }
      var tw = window.open("about:blank", "_blank");
      var c = await post("api/tglink.php", { a: "code" });
      if (!c.ok) { if (tw) tw.close(); T.msg = c.error || "Couldn't start linking."; drawTg(); return; }
      if (tw) tw.location = c.url; else location.href = c.url;
      T.wait = 1; T.msg = ""; drawTg();
      var tries = 0, iv = setInterval(async function () { tries++; await loadTg(); if (T.linked || tries > 40) { clearInterval(iv); if (T.linked) { T.msg = "Telegram linked. Pick what the bot may message you about."; drawTg(); } } }, 3000);
      return;
    }
    if (e.target.closest("[data-tg-off]")) { takeTg(await post("api/tglink.php", { a: "unlink" })); T.msg = "Telegram unlinked. The bot won't message you."; drawTg(); return; }
    if (e.target.closest("[data-edit]")) { editing = true; render(); var i = document.getElementById("pf-name"); if (i) { i.focus(); i.select(); } return; }
    if (e.target.closest("[data-cancel]")) { editing = false; render(); return; }
    if ((b = e.target.closest("[data-copy-w]"))) { try { await navigator.clipboard.writeText(b.dataset.copyW); b.textContent = "Copied"; setTimeout(function () { b.textContent = "Copy"; }, 1400); } catch (x) {} return; }
    if ((b = e.target.closest("[data-recheck]"))) {
      b.disabled = true; b.textContent = "Checking…";
      var r = await post(SHOP_API, { a: "check", order: b.dataset.recheck, sig: b.dataset.sig });
      if (!(r.ok && r.status === "paid")) { b.textContent = r.ok && r.status === "open" ? "Not confirmed yet" : "Checked"; }
      setTimeout(load, 900);
    }
  });
  root.addEventListener("change", async function (e) {
    var pp = e.target.closest("[data-pp-public]");
    if (pp) { var j = await post(API, { a: "public", on: pp.checked }); if (j.ok) { P.public = j.on; render(); } else pp.checked = !pp.checked; return; }
    var n = e.target.closest("[data-tg-note]"); if (!n) return;
    var notes = {}; notes[n.dataset.tgNote] = n.checked;
    takeTg(await post("api/tglink.php", { a: "prefs", notes: notes })); T.msg = ""; drawTg();
  });
  root.addEventListener("submit", async function (e) {
    if (e.target.id !== "pf-name-form") return;
    e.preventDefault();
    var input = document.getElementById("pf-name"), hint = document.getElementById("pf-hint"), name = input.value.trim();
    if (name === P.name) { editing = false; render(); return; }
    hint.textContent = "Saving…"; hint.classList.remove("err");
    var r = await post(API, { a: "rename", name: name });
    if (!r.ok) { hint.textContent = r.error || "Couldn't save that name."; hint.classList.add("err"); return; }
    P.name = r.name; store("shy-lb-name", r.name); editing = false; render();
  });

  load();
})();
// links like /profile#pf-tg land on that part once the profile has drawn
(function () { var h = location.hash.slice(1); if (!/^pf-\w+$/.test(h)) return; var n = 0; (function go() { var el = document.getElementById(h); if (el && el.offsetHeight) el.scrollIntoView({ block: "center" }); else if (n++ < 20) setTimeout(go, 250); })(); })();
