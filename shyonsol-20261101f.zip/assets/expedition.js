// Shadow Expeditions on the Play page (api/expedition.php): pick one of today's three Regions (one is a hot zone), how
// long to go for, and which Shadow goes (holders) or your Unbound mask (everyone). It comes back with Koban and Season
// Scroll XP, sometimes treasure. The card counts down here, says when it's back, and the claim opens a chest.
//MC 2026-10-16 first version
//MC 2026-11-01 holders only: without a Shadow in the connected wallet the card says what it takes instead of a send form.
//   An Unbound run sent before today still shows and can be claimed.
(function () {
  "use strict";
  var box = document.getElementById("g-exp");
  if (!box) return;
  var API = "/api/expedition.php";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var S = null, pick = { region: "", len: "raid", shadow: "" }, offset = 0, tick = 0, busy = false, seenDone = {};
  function ls(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function now() { return Date.now() / 1000 + offset; }
  function left(s) { s = Math.max(0, Math.ceil(s)); var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return h ? h + "h " + ("0" + m).slice(-2) + "m" : m ? m + "m " + ("0" + x).slice(-2) + "s" : x + "s"; }
  var UNB = "/assets/art/masks/unbound.svg";
  var AURA = { cyan: "Electric Cyan", crimson: "Crimson Glow", lightning: "Lightning", money: "Money", btc: "BTC", none: "No Aura" };

  function post(body) {
    var pid = ls("shy-lb-pid"), key = ls("shy-lb-key");
    return fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: pid, key: key }, body)) })
      .then(function (r) { return r.json(); }).catch(function () { return { ok: false, error: "Can't reach the server. Check your connection." }; });
  }
  function load() {
    if (!/^[a-f0-9]{16}$/.test(ls("shy-lb-pid"))) return;
    post({ a: "state" }).then(function (j) { if (j && j.ok) take(j); });
  }
  function take(j) {
    S = j; offset = j.now - Date.now() / 1000;
    if (!S.dest.some(function (d) { return d.r === pick.region; })) pick.region = S.dest[0] ? S.dest[0].r : "";
    var idle = S.shadows.filter(function (x) { return !x.busy; });
    if (S.holder && !idle.some(function (x) { return x.n === pick.shadow; })) pick.shadow = idle[0] ? idle[0].n : "";
    if (!S.holder) pick.shadow = "";
    S.active.forEach(function (a) { if (a.done) seenDone[a.id] = 1; });
    box.hidden = !S.on && !S.active.length;
    draw();
    clearInterval(tick); tick = setInterval(step, 1000);
  }
  function bonusFor() {
    var b = 0, d = S.dest.filter(function (x) { return x.r === pick.region; })[0];
    if (d && d.hot) b += S.hot;
    var sh = S.shadows.filter(function (x) { return x.n === pick.shadow; })[0];
    if (sh) b += sh.bonus;
    return b;
  }
  function draw() {
    if (!S) return;
    var freeSlots = S.slots - S.active.length, sendsLeft = Math.max(0, S.sends - S.sent);
    var h = '<div class="ex-head"><span class="ex-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5 5-2Z"/></svg></span>' +
      '<div class="ex-ht"><span class="g-mode-k">Expeditions</span><b>Send your Shadow out</b><small>' + (S.holder ? sendsLeft + ' of ' + S.sends + ' left today. It comes back with Koban and Scroll XP, sometimes treasure.' : 'A Shadow holder perk: timed missions that bring back Koban and Scroll XP, sometimes treasure.') + '</small></div></div>';
    // out right now
    if (S.active.length) {
      h += '<div class="ex-act">' + S.active.map(function (a) {
        var tot = a.end - a.start, rem = a.end - now(), p = Math.max(0, Math.min(1, 1 - rem / tot)), done = rem <= 0;
        return '<div class="ex-run' + (done ? " back" : "") + '" data-run="' + esc(a.id) + '"><span class="ex-av"><img src="' + esc(a.img || UNB) + '" alt="" onerror="this.src=\'' + UNB + '\'"></span>' +
          '<div class="ex-rt"><b>' + esc(a.name) + ' to <span data-i18n-skip>' + esc(a.region) + '</span></b><span class="ex-bar"><i style="width:' + (p * 100).toFixed(1) + '%"></i></span>' +
          '<small data-ex-left>' + (done ? "Back home" : "Back in " + left(rem)) + '</small></div>' +
          (done ? '<button type="button" class="btn btn-red btn-sm ex-claim" data-claim="' + esc(a.id) + '">Claim</button>' : '<span class="ex-haul"><span data-i18n-skip>' + fmt(a.koban) + '</span> Koban</span>') + '</div>';
      }).join("") + '</div>';
    }
    // send another
    if (!S.on) h += '<p class="ex-note">Expeditions are resting right now. Check back soon.</p>';
    else if (!S.holder) h += '<p class="ex-note ex-lock"><b>For Shadow holders.</b> Connect the wallet that holds your Shytoshi Shadow to send it out, one per Shadow, up to three at once. <a href="/nfts">Get a Shadow</a></p>';
    else if (sendsLeft <= 0) h += '<p class="ex-note">That\'s ' + S.sends + ' expeditions today. New ones open at midnight UTC.</p>';
    else if (freeSlots <= 0) h += '<p class="ex-note">All your Shadows are out. Claim one when it comes back.</p>';
    else {
      var b = bonusFor();
      h += '<div class="ex-send"><span class="ex-k">Where to</span><div class="ex-dest">' + S.dest.map(function (d) {
        return '<button type="button" class="ex-d' + (d.r === pick.region ? " on" : "") + (d.hot ? " hot" : "") + '" data-region="' + esc(d.r) + '"><b data-i18n-skip>' + esc(d.r) + '</b><small>' + (d.hot ? "Hot zone +" + S.hot + "%" : "Open today") + '</small></button>';
      }).join("") + '</div>';
      h += '<span class="ex-k">How long</span><div class="ex-lens">' + S.lens.map(function (l) {
        return '<button type="button" class="ex-l' + (l.id === pick.len ? " on" : "") + '" data-len="' + esc(l.id) + '"><b>' + esc(l.name) + '</b><small>' + l.h + (l.h === 1 ? " hour" : " hours") + '</small><em><span data-i18n-skip>' + fmt(Math.round(l.koban * (100 + b) / 100)) + '</span> Koban &middot; <span data-i18n-skip>' + l.xp + '</span> XP</em></button>';
      }).join("") + '</div>';
      if (S.holder) {
        h += '<span class="ex-k">Who goes</span><div class="ex-who">' + S.shadows.map(function (x) {
          return '<button type="button" class="ex-s' + (x.n === pick.shadow ? " on" : "") + '"' + (x.busy ? " disabled" : "") + ' data-shadow="' + esc(x.n) + '" title="Shadow #' + esc(x.n) + ', ' + esc(AURA[x.aura] || "") + '"><img src="' + esc(x.img || UNB) + '" alt="" onerror="this.src=\'' + UNB + '\'"><small><span data-i18n-skip>#' + esc(x.n) + '</span>' + (x.busy ? " out" : " +" + x.bonus + "%") + '</small></button>';
        }).join("") + '</div>';
      }
      var who = pick.shadow ? "Shadow #" + pick.shadow : "your Shadow";
      var L = S.lens.filter(function (l) { return l.id === pick.len; })[0];
      h += '<button type="button" class="btn btn-red ex-go" data-go>Send <span data-i18n-skip>' + esc(who) + '</span> on a ' + esc(L ? L.name : "Raid") + (b ? ' <i>+' + b + '%</i>' : "") + '</button></div>';
    }
    if (S.log.length) h += '<div class="ex-log"><span class="ex-k">Last back</span>' + S.log.slice(0, 3).map(function (l) {
      return '<span><b data-i18n-skip>' + esc(l.region) + '</b> +<span data-i18n-skip>' + fmt(l.koban) + '</span> Koban' + (l.find ? ' <em class="f-' + esc(l.find) + '">' + (l.find === "relic" ? "Relic" : "Treasure") + '</em>' : "") + '</span>';
    }).join("") + '</div>';
    box.innerHTML = h;
  }
  function step() {
    if (!S) return;
    var redraw = false;
    S.active.forEach(function (a) {
      var rem = a.end - now(), el = box.querySelector('[data-run="' + a.id + '"]');
      if (rem <= 0 && !seenDone[a.id]) { seenDone[a.id] = 1; a.done = true; redraw = true; note("Your Shadow is back from <b data-i18n-skip>" + esc(a.region) + "</b>. Claim what it found."); }
      if (el && rem > 0) {
        var t = el.querySelector("[data-ex-left]"); if (t) t.textContent = "Back in " + left(rem);
        var bar = el.querySelector(".ex-bar i"); if (bar) bar.style.width = (Math.max(0, Math.min(1, 1 - rem / (a.end - a.start))) * 100).toFixed(1) + "%";
      }
    });
    if (redraw) draw();
  }
  function note(html) {
    var t = document.getElementById("g-toast");
    if (!t) return;
    t.innerHTML = html; t.hidden = false; t.classList.remove("out");
    clearTimeout(note.tm); note.tm = setTimeout(function () { t.classList.add("out"); setTimeout(function () { t.hidden = true; }, 300); }, 3200);
  }
  // the haul: a chest that opens and throws its coins
  function chest(c) {
    //MC 2026-10-19 the reveal grew into the full moment: the painted chest, turning light behind it, the coin
    //   burst, the number rolling up, and the signature. A plain return keeps a quieter version of the same card.
    var o = document.createElement("div"); o.className = "ex-ov"; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true");
    var rich = c.find === "treasure" || c.find === "relic";
    var coins = ""; for (var i = 0; i < (reduce ? 0 : rich ? 22 : 10); i++) coins += '<i style="--a:' + (i * (rich ? 16 : 36) + Math.random() * 14) + 'deg;--d:' + (130 + Math.random() * 100) + 'px;--t:' + (Math.random() * .3) + 's"></i>';
    var spark = ""; for (var k2 = 0; k2 < (reduce ? 0 : 10); k2++) spark += '<i style="left:' + (6 + Math.random() * 88) + '%;top:' + (8 + Math.random() * 80) + '%;animation-delay:' + (Math.random() * 2.4).toFixed(2) + 's"></i>';
    var big = c.find === "relic" ? "Relic found" : c.find === "treasure" ? "Treasure" : "Back home";
    var sub = c.find === "relic" ? "An old relic, worth an extra 300 Koban." : c.find === "treasure" ? "It found treasure and doubled the haul." : "From " + esc(c.region) + ".";
    o.innerHTML = '<div class="ex-ov-in' + (c.find ? " f-" + esc(c.find) : "") + '">' +
      '<div class="ex-scene" aria-hidden="true"><span class="ex-rays"></span><img class="ex-art" src="assets/art/chest-haul.webp" alt="" decoding="async"><span class="ex-spark">' + spark + '</span><span class="ex-coins">' + coins + '</span></div>' +
      '<span class="ex-ok">' + big + '</span><b class="ex-amt">+<span data-i18n-skip data-ex-n>' + (reduce ? fmt(c.koban) : "0") + '</span> Koban</b><small>+<span data-i18n-skip>' + c.xp + '</span> Scroll XP &middot; ' + sub + '</small>' +
      (c.capped ? '<small class="ex-cap">Today\'s treasure limit is reached, so this one paid its normal haul.</small>' : "") +
      '<span class="ex-sig" aria-hidden="true">Shytoshi Kusama</span>' +
      '<button type="button" class="btn btn-red" data-ov-close>Nice</button></div>';
    document.body.appendChild(o);
    var art = o.querySelector(".ex-art");
    art.addEventListener("error", function () { art.remove(); });
    requestAnimationFrame(function () { o.classList.add("in"); });
    // the haul rolls up while the coins fly
    if (!reduce && c.koban > 1) {
      var nEl = o.querySelector("[data-ex-n]"), t0 = performance.now(), ms = Math.min(1200, 500 + c.koban);
      var step = function (t) {
        if (!nEl.isConnected) return;
        var k = Math.min(1, (t - t0) / ms); k = 1 - Math.pow(1 - k, 3);
        nEl.textContent = fmt(Math.round(c.koban * k));
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }
    var close = function () { o.remove(); };
    o.addEventListener("click", function (e) { if (e.target === o || e.target.closest("[data-ov-close]")) close(); });
    try { if (navigator.vibrate) navigator.vibrate(rich ? [30, 40, 60, 40, 90] : [30, 40, 60]); } catch (e) {}
    o.querySelector("[data-ov-close]").focus();
  }
  //MC 2026-10-19 a door for the test harness and for anything else that wants to throw the reveal
  window.ShyExp = window.ShyExp || {}; window.ShyExp.reveal = chest;
  box.addEventListener("click", function (e) {
    var t;
    if ((t = e.target.closest("[data-region]"))) { pick.region = t.dataset.region; draw(); return; }
    if ((t = e.target.closest("[data-len]"))) { pick.len = t.dataset.len; draw(); return; }
    if ((t = e.target.closest("[data-shadow]")) && !t.disabled) { pick.shadow = t.dataset.shadow; draw(); return; }
    if (busy) return;
    if ((t = e.target.closest("[data-go]"))) {
      busy = true; t.disabled = true;
      post({ a: "send", len: pick.len, region: pick.region, shadow: pick.shadow }).then(function (j) {
        busy = false;
        if (!j.ok) { note(esc(j.error || "Couldn't send it. Try again.")); t.disabled = false; return; }
        take(j); note("Off it goes to <b data-i18n-skip>" + esc(pick.region) + "</b>.");
      });
      return;
    }
    if ((t = e.target.closest("[data-claim]"))) {
      busy = true; t.disabled = true;
      post({ a: "claim", id: t.dataset.claim }).then(function (j) {
        busy = false;
        if (!j.ok) { note(esc(j.error || "Couldn't claim it. Try again.")); t.disabled = false; return; }
        take(j); if (j.claimed) chest(j.claimed);
        if (window.ShyEco && window.ShyEco.refresh) window.ShyEco.refresh();
      });
    }
  });
  document.addEventListener("visibilitychange", function () { if (!document.hidden) load(); });
  setTimeout(load, 600);
})();
