<?php
//MC 2026-11-01 the Forged record: custom deck matches keep their own territory. A forged match (live, Shogun or Shogun
//   Elite) pays no Koban or XP, moves no League points or Ranked, and leaves the main leaderboard and the Shogun and
//   Elite records alone. It goes here instead: each player's forged matches and wins by kind, the totals, the latest wins
//   and the last 30 days, for the Custom decks section on the Stats page and the line on the Forge card.
//   Why: a tuned deck beat Shogun Elite easily (the counter-forge answers your list, it can't out-draw it) and the win
//   paid the full Elite bounty. Custom decks are craft, and craft gets its own board, not the prize ones.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('FORGED_DB', DATA_DIR . '/forged.php');   // {t: {g, w, live, liveW, shogun, shogunW, elite, eliteW}, p: {pid: {n, g, w, best, live.., shogun.., elite..}}, recent: [...], days: {d: [g, w]}}
const FORGED_KINDS = ['live', 'shogun', 'elite'];

// the kind of a forged room: a live match, the Shogun or Shogun Elite
function forged_kind($room) { return empty($room['boss']) ? 'live' : (!empty($room['boss']['elite']) ? 'elite' : 'shogun'); }

// one human seat's forged result. Called inside end_game's lock. Returns what the end screen shows.
function forged_result($room, $i, $pid, $name, $r) {
    $kind = forged_kind($room); $won = $r['result'] === 'win';
    $db = load(FORGED_DB) + ['t' => [], 'p' => [], 'recent' => [], 'days' => []];
    $t = $db['t'] + ['g' => 0, 'w' => 0];
    foreach (FORGED_KINDS as $k) $t += [$k => 0, $k . 'W' => 0];
    $me = ($db['p'][$pid] ?? []) + ['n' => '', 'g' => 0, 'w' => 0, 'best' => 0];
    foreach (FORGED_KINDS as $k) $me += [$k => 0, $k . 'W' => 0];
    $me['n'] = (string)$name; $me['g']++; $me[$kind]++; $t['g']++; $t[$kind]++;
    $me['best'] = max((int)$me['best'], (int)$r['regions']);
    $d = today(); $db['days'][$d] = $db['days'][$d] ?? [0, 0]; $db['days'][$d][0]++;
    // the rival's Regions: the boss in a boss match, else the best other seat
    $vs = 0; foreach ($room['g']['players'] as $j => $pl) if ($j !== $i) $vs = max($vs, count($pl['regions']));
    if ($won) {
        $me['w']++; $me[$kind . 'W']++; $t['w']++; $t[$kind . 'W']++; $db['days'][$d][1]++;
        array_unshift($db['recent'], ['t' => time(), 'n' => (string)$name, 'k' => $kind, 'r' => (int)$r['regions'], 'v' => $vs, 'deck' => (string)($room['deckNames'][$i] ?? '')]);
        $db['recent'] = array_slice($db['recent'], 0, 30);
    }
    if (count($db['days']) > 60) { ksort($db['days']); $db['days'] = array_slice($db['days'], -60, null, true); }
    $db['t'] = $t; $db['p'][$pid] = $me;
    save(FORGED_DB, $db);
    return ['kind' => $kind, 'won' => $won, 'record' => [(int)$me['w'], (int)$me['g']], 'kindRecord' => [(int)$me[$kind . 'W'], (int)$me[$kind]]];
}

// the Stats page section: names only, never ids
function forged_public() {
    $db = load(FORGED_DB) + ['t' => [], 'p' => [], 'recent' => [], 'days' => []];
    $t = $db['t'] + ['g' => 0, 'w' => 0]; foreach (FORGED_KINDS as $k) $t += [$k => 0, $k . 'W' => 0];
    $ppl = array_filter($db['p'], fn($x) => !empty($x['n']) && ($x['g'] ?? 0) > 0);
    uasort($ppl, fn($a, $b) => [(int)($b['w'] ?? 0), -(int)($b['g'] ?? 0)] <=> [(int)($a['w'] ?? 0), -(int)($a['g'] ?? 0)]);
    $top = array_values(array_map(fn($x) => ['n' => $x['n'], 'w' => (int)$x['w'], 'g' => (int)$x['g'], 'lw' => (int)($x['liveW'] ?? 0), 'sw' => (int)($x['shogunW'] ?? 0), 'ew' => (int)($x['eliteW'] ?? 0)], array_slice($ppl, 0, 10)));
    $days = []; for ($i = 29; $i >= 0; $i--) { $d = gmdate('Y-m-d', time() - $i * 86400); $days[] = [$d, (int)($db['days'][$d][0] ?? 0), (int)($db['days'][$d][1] ?? 0)]; }
    return ['ok' => true, 'at' => time(), 't' => $t, 'players' => count($ppl), 'top' => $top,
        'recent' => array_map(fn($x) => ['n' => $x['n'], 'k' => $x['k'], 'r' => (int)$x['r'], 'v' => (int)$x['v'], 't' => (int)$x['t'], 'deck' => (string)($x['deck'] ?? '')], array_slice($db['recent'], 0, 12)), 'days' => $days];
}
// one player's forged line, for the Forge card
function forged_mine($pid) {
    $me = load(FORGED_DB)['p'][$pid] ?? null;
    if (!$me) return null;
    return ['g' => (int)$me['g'], 'w' => (int)$me['w'], 'lw' => (int)($me['liveW'] ?? 0), 'sw' => (int)($me['shogunW'] ?? 0), 'ew' => (int)($me['eliteW'] ?? 0)];
}

//MC 2026-11-01 forged boss matches from before the Forged record went on the Shogun or Elite record. The sealed deal of
//   every live match (fair-live.php, kept 45 days) says whether it was forged (its decks) and which boss sat there, so
//   each boss log row is matched to its sealed deal by player name and end time and moved: off the boss record (matches,
//   wins, flawless and comeback counts, the day and the margin charts, the latest wins), onto the Forged record. Koban
//   already paid stays paid; the row is marked so it is never moved twice. Admin > Rewards, per boss.
function forged_move_past($elite) {
    if (!defined('FAIR_LIVE')) require_once __DIR__ . '/fairlib.php';
    return with_lock(function () use ($elite) {
        // every sealed boss match of this boss, forged or not: a row is matched to its nearest seal, each seal used once,
        // and it moves only when that seal is a forged one (a plain one wins a tie)
        $seals = [];
        foreach ((array)load(FAIR_LIVE) as $sid => $r) if (!empty($r['boss']) && !empty($r['elite']) === $elite) $seals[$sid] = $r;
        $used = [];
        $db = load(boss_dbf($elite)); $fd = load(FORGED_DB) + ['t' => [], 'p' => [], 'recent' => [], 'days' => []];
        $kind = $elite ? 'elite' : 'shogun'; $n = 0;
        foreach ((array)($db['log'] ?? []) as $li => $row) {
            if (!empty($row['fg']) || ($row['res'] ?? '') === 'quit') continue;
            $best = null; $bd = 16;
            foreach ($seals as $sid => $sr) {
                if (isset($used[$sid]) || !in_array((string)$row['name'], array_map(fn($x) => preg_replace('/ \(bot\)$/', '', (string)$x), (array)$sr['names']), true)) continue;
                $dd = abs((int)$sr['end'] - (int)$row['t']);
                if ($dd < $bd || ($dd === $bd && $best !== null && !empty($seals[$best]['decks']) && empty($sr['decks']))) { $bd = $dd; $best = $sid; }
            }
            if ($best === null) continue;
            $used[$best] = 1;
            if (empty($seals[$best]['decks'])) continue;
            $pid = (string)$row['pid']; $won = $row['res'] === 'win'; $d = gmdate('Y-m-d', (int)$row['t']);
            $db['log'][$li]['fg'] = 1; $n++;
            // off the boss record
            $me = &$db['p'][$pid];
            if ($me) { $me['g'] = max(0, (int)$me['g'] - 1); if ($won) { $me['w'] = max(0, (int)$me['w'] - 1); if ((int)$row['b'] === 0) $me['flaw'] = max(0, (int)($me['flaw'] ?? 0) - 1); if ((int)($row['down'] ?? 0) >= BOSS_COMEBACK) $me['cb'] = max(0, (int)($me['cb'] ?? 0) - 1); } }
            unset($me);
            $db['t']['g'] = max(0, (int)($db['t']['g'] ?? 0) - 1);
            if (isset($db['days'][$d])) { $db['days'][$d][0] = max(0, $db['days'][$d][0] - 1); if ($won) $db['days'][$d][1] = max(0, $db['days'][$d][1] - 1); }
            $df = (string)max(-15, min(15, (int)$row['r'] - (int)$row['b'])); if (isset($db['diff'][$df])) $db['diff'][$df] = max(0, (int)$db['diff'][$df] - 1);
            if ($won) {
                $db['t']['w'] = max(0, (int)($db['t']['w'] ?? 0) - 1);
                if ((int)$row['b'] === 0) $db['t']['flaw'] = max(0, (int)($db['t']['flaw'] ?? 0) - 1);
                if ((int)($row['down'] ?? 0) >= BOSS_COMEBACK) $db['t']['cb'] = max(0, (int)($db['t']['cb'] ?? 0) - 1);
                foreach ((array)($db['recent'] ?? []) as $ri => $x) if (($x['pid'] ?? '') === $pid && abs((int)$x['t'] - (int)$row['t']) <= 5) { $db['t']['koban'] = max(0, (int)($db['t']['koban'] ?? 0) - (int)$x['k']); array_splice($db['recent'], $ri, 1); break; }
            }
            // onto the Forged record
            $t = $fd['t'] + ['g' => 0, 'w' => 0]; foreach (FORGED_KINDS as $k) $t += [$k => 0, $k . 'W' => 0];
            $fm = ($fd['p'][$pid] ?? []) + ['n' => (string)$row['name'], 'g' => 0, 'w' => 0, 'best' => 0]; foreach (FORGED_KINDS as $k) $fm += [$k => 0, $k . 'W' => 0];
            $fm['g']++; $fm[$kind]++; $t['g']++; $t[$kind]++; $fm['best'] = max((int)$fm['best'], (int)$row['r']);
            $fd['days'][$d] = $fd['days'][$d] ?? [0, 0]; $fd['days'][$d][0]++;
            if ($won) { $fm['w']++; $fm[$kind . 'W']++; $t['w']++; $t[$kind . 'W']++; $fd['days'][$d][1]++; $fd['recent'][] = ['t' => (int)$row['t'], 'n' => (string)$row['name'], 'k' => $kind, 'r' => (int)$row['r'], 'v' => (int)$row['b'], 'deck' => '']; }
            $fd['t'] = $t; $fd['p'][$pid] = $fm;
        }
        if ($n) {
            usort($fd['recent'], fn($a, $b) => $b['t'] <=> $a['t']); $fd['recent'] = array_slice($fd['recent'], 0, 30);
            save(boss_dbf($elite), $db); save(FORGED_DB, $fd);
            @unlink(DATA_DIR . '/stats-boss-cache.php'); @unlink(DATA_DIR . '/stats-elite-cache.php'); @unlink(DATA_DIR . '/stats-forged-cache.php');
        }
        return $n;
    });
}

