<?php
//MC 2026-10-18 the Deck Forge API. POST JSON {a: view|save|del|active, pid, key, ...}. Decks live in the player's
//   economy account (acc['decks']), the rules live in decklib.php, and buying the Forge or a slot goes through the
//   normal shop (api/shop.php buy), so prices, the holder discount and the ledger all work the usual way.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
define('SHY_ENGINE', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/engine.php';
require __DIR__ . '/decklib.php';
require_once __DIR__ . '/forgedlib.php';   //MC 2026-11-01 the Forged record for the Forge card
require_once __DIR__ . '/bosslib.php';     //MC 2026-11-01 whether each boss takes challenges, for the Forged Shogun and Elite buttons

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$body = json_decode((string)file_get_contents('php://input'), true) ?: [];
$a = (string)($body['a'] ?? '');
$pid = (string)($body['pid'] ?? '');
$key = (string)($body['key'] ?? '');
if ($a === 'on') out(['ok' => true, 'on' => forge_on()]);   //MC 2026-11-01 for the Forge card, signed in or not
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('Who is this?', 403);
$kh = hash('sha256', $key);
// each helper lives in its page's API file, so this one keeps its own copy
function limit_or_fail($what, $max, $window) {
    $ok = with_lock(function () use ($what, $max, $window) { $l = load(LIMITS); $r = rate_ok($l, $what . ':' . client_ip(), $max, $window); save(LIMITS, $l); return $r; });
    if (!$ok) fail('Slow down a moment and try again.', 429);
}
limit_or_fail('decks:' . $pid, 60, 600);

function decks_out($acc) {
    [$un, $slots, $dk] = deck_state($acc);
    $list = [];
    foreach ($dk['list'] as $id => $d) $list[] = ['id' => $id, 'name' => (string)$d['name'], 'c' => $d['c'], 'used' => (int)($d['used'] ?? 0)];
    return ['ok' => true, 'on' => forge_on(), 'bossOn' => boss_cfg()['on'], 'eliteOn' => elite_cfg()['on'], 'unlocked' => $un, 'slots' => $slots, 'decks' => $list, 'active' => (string)$dk['active'],
        'mine' => function_exists('forged_mine') ? forged_mine((string)($GLOBALS['pid'] ?? '')) : null,   //MC 2026-11-01 the Forged record
        'founder' => founder_deck(), 'rails' => ['size' => DECK_SIZE, 'copies' => DECK_COPY_MAX, 'minGain' => DECK_MIN_GAIN, 'maxAttack' => DECK_MAX_ATTACK, 'nameMax' => DECK_NAME_MAX]];
}
// lock, check the key, hand the account to $fn, save what it changed
function with_deck_acc($pid, $kh, $fn) {
    return with_lock(function () use ($pid, $kh, $fn) {
        if (!key_ok($pid, $kh)) return ['err' => 'This browser is not signed in as that player.', 'code' => 403];
        $eco = load(ECO);
        $acc = eco_get($eco, $pid);
        $r = $fn($acc);
        if (!isset($r['err'])) { $eco[$pid] = $acc; save(ECO, $eco); }
        return $r + ['acc' => $acc];
    });
}

if ($a === 'view') {
    $r = with_deck_acc($pid, $kh, fn(&$acc) => []);
    if (isset($r['err'])) fail($r['err'], $r['code'] ?? 400);
    out(decks_out($r['acc']));
}
if ($a === 'save') {
    $name = trim(preg_replace('/\s+/', ' ', (string)($body['name'] ?? '')));
    if ($name === '' || mb_strlen($name) > DECK_NAME_MAX || !preg_match('/^[\p{L}\p{N} _.\'\-]+$/u', $name)) fail('Give the deck a name: letters and numbers, up to ' . DECK_NAME_MAX . '.');
    $cards = [];
    foreach ((array)($body['c'] ?? []) as $id => $n) if (is_string($id)) $cards[$id] = (int)$n;
    if ($why = deck_check($cards)) fail($why);
    $did = (string)($body['id'] ?? '');
    $r = with_deck_acc($pid, $kh, function (&$acc) use ($did, $name, $cards) {
        [$un, $slots, $dk] = deck_state($acc);
        if (!$un) return ['err' => 'Unlock the Deck Forge first.'];
        if ($did !== '' && !isset($dk['list'][$did])) return ['err' => 'That deck is gone. Save it as a new one.'];
        if ($did === '') {
            if (count($dk['list']) >= $slots) return ['err' => 'All your deck slots are full. Free one, or add a slot.'];
            $did = substr(bin2hex(random_bytes(4)), 0, 6);
        }
        $dk['list'][$did] = ['name' => $name, 'c' => $cards, 'used' => (int)($dk['list'][$did]['used'] ?? 0), 't' => time()];
        if ($dk['active'] === '') $dk['active'] = $did;   // the first deck forged goes straight into your hands
        $acc['decks'] = $dk;
        return ['saved' => $did];
    });
    if (isset($r['err'])) fail($r['err'], $r['code'] ?? 400);
    track('forge_save');
    out(decks_out($r['acc']) + ['saved' => $r['saved']]);
}
if ($a === 'del') {
    $did = (string)($body['id'] ?? '');
    $r = with_deck_acc($pid, $kh, function (&$acc) use ($did) {
        [, , $dk] = deck_state($acc);
        if (!isset($dk['list'][$did])) return ['err' => 'That deck is already gone.'];
        unset($dk['list'][$did]);
        if ($dk['active'] === $did) $dk['active'] = array_key_first($dk['list']) ?? '';
        $acc['decks'] = $dk;
        return [];
    });
    if (isset($r['err'])) fail($r['err'], $r['code'] ?? 400);
    out(decks_out($r['acc']));
}
if ($a === 'active') {
    $did = (string)($body['id'] ?? '');
    $r = with_deck_acc($pid, $kh, function (&$acc) use ($did) {
        [$un, , $dk] = deck_state($acc);
        if (!$un) return ['err' => 'Unlock the Deck Forge first.'];
        if ($did !== '' && !isset($dk['list'][$did])) return ['err' => 'That deck is gone.'];
        $dk['active'] = $did;   // '' means the Founder's deck
        $acc['decks'] = $dk;
        return [];
    });
    if (isset($r['err'])) fail($r['err'], $r['code'] ?? 400);
    out(decks_out($r['acc']));
}
fail('unknown action');
