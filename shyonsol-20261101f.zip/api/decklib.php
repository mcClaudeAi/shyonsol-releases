<?php
//MC 2026-10-18 the Deck Forge: players build their own 40-card decks and bring them to forged matches. A forged match
//   shuffles every seat's deck into one Chaos pool and deals each opening hand from its owner's cards (engine.php
//   eng_new), so no card effect changes and a stacked deck shapes the whole table, not just its owner. The rails here
//   keep decks playable rather than degenerate; the merged pool does most of the balancing on its own, because a deck
//   full of attacks arms your rivals too. Tried per-player draw piles first on paper: it touches every effect that
//   moves cards between decks plus the Shogun's determinizer, so the shared pool won.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const DECK_SIZE = 40;         // cards in a forged deck
const DECK_COPY_MAX = 2;      // copies of one card
const DECK_MIN_GAIN = 6;      // a deck has to be able to build, not only burn
const DECK_MAX_ATTACK = 16;   // and can't be wall-to-wall aggression
const DECK_SLOTS_BASE = 2;    // slots the Forge itself comes with
const DECK_NAME_MAX = 24;

// the cards decks are built from: the 71 the base game plays with (season cards sit forged matches out)
function deck_pool() {
    static $p = null;
    if ($p === null) { $p = []; foreach (CARDS as $id => $c) if ($c['n'] > 0) $p[$id] = $c['kind']; }
    return $p;
}
// the Founder's deck: the free deck everyone forges from, a balanced slice of the pool in deck order
function founder_deck() {
    static $d = null;
    if ($d !== null) return $d;
    $quota = ['attack' => 9, 'gain' => 8, 'defense' => 4, 'global' => 11, 'trick' => 6, 'passive' => 2];
    $d = [];
    foreach (deck_pool() as $id => $kind) if (($quota[$kind] ?? 0) > 0) { $quota[$kind]--; $d[] = $id; }
    return $d;
}
// a deck as stored: ['name' => ..., 'c' => [card id => copies]]. Returns '' when fine, or what's wrong in plain words.
function deck_check($cards) {
    if (!is_array($cards) || !$cards) return 'Pick your 40 cards first.';
    $pool = deck_pool(); $n = 0; $kinds = [];
    foreach ($cards as $id => $k) {
        if (!isset($pool[$id])) return 'That card is not in the pool.';
        $k = (int)$k;
        if ($k < 1 || $k > DECK_COPY_MAX) return 'At most ' . DECK_COPY_MAX . ' copies of one card.';
        $n += $k; $kinds[$pool[$id]] = ($kinds[$pool[$id]] ?? 0) + $k;
    }
    if ($n !== DECK_SIZE) return 'A deck is exactly ' . DECK_SIZE . ' cards. This one has ' . $n . '.';
    if (($kinds['gain'] ?? 0) < DECK_MIN_GAIN) return 'At least ' . DECK_MIN_GAIN . ' gain cards, so the deck can build.';
    if (($kinds['attack'] ?? 0) > DECK_MAX_ATTACK) return 'At most ' . DECK_MAX_ATTACK . ' attack cards.';
    return '';
}
// a stored deck's cards as the flat 40-card list the engine takes, in pool order so the list is deterministic
function deck_list($cards) {
    $out = [];
    foreach (deck_pool() as $id => $kind) for ($k = 0; $k < (int)($cards[$id] ?? 0); $k++) $out[] = $id;
    return $out;
}
// what the player's account says: [unlocked, slots, decks, active id]
function deck_state($acc) {
    $un = isset($acc['items']['deckforge']);
    $slots = DECK_SLOTS_BASE + (isset($acc['items']['deckslot3']) ? 1 : 0) + (isset($acc['items']['deckslot4']) ? 1 : 0) + (isset($acc['items']['deckslot5']) ? 1 : 0);
    $dk = is_array($acc['decks'] ?? null) ? $acc['decks'] : ['list' => [], 'active' => ''];
    return [$un, $slots, $dk];
}
// the 40 cards a player brings to a forged match: their active deck, or the Founder's deck
function deck_of_player($pid) {
    $eco = load(ECO);
    $acc = $eco[$pid] ?? null;
    if ($acc) {
        [$un, , $dk] = deck_state($acc);
        $cur = $un && $dk['active'] !== '' ? ($dk['list'][$dk['active']] ?? null) : null;
        if ($cur && deck_check($cur['c']) === '') return deck_list($cur['c']);
    }
    return founder_deck();
}

//MC 2026-11-01 Admin > Turn off features: the Deck Forge site wide. Off, no forged match can start, the Forge card is
//   gone from the Play page and the Forge and its slots can't be bought. Decks already built are kept for when it's back.
function forge_on() { return empty(eco_settings()['forge_off']); }
function deck_unlocked($pid) { $acc = load(ECO)[$pid] ?? null; return $acc && isset($acc['items']['deckforge']); }
// the active deck's name, for the table ('' falls back to the Founder's deck)
function deck_name_of($pid) {
    if ($pid === '') return "Founder's deck";
    $acc = load(ECO)[$pid] ?? null;
    if (!$acc) return "Founder's deck";
    [$un, , $dk] = deck_state($acc);
    $cur = $un && $dk['active'] !== '' ? ($dk['list'][$dk['active']] ?? null) : null;
    return $cur ? (string)$cur['name'] : "Founder's deck";
}

//MC 2026-10-18 the Shogun reads a challenger's deck list and forges its own answer: counters to what you lean on,
//   filled with its best-rated cards. Attack-heavy decks meet walls and reactions; builders meet pressure.
function shogun_deck($playerList) {
    $pool = deck_pool();
    $kinds = []; foreach ($playerList as $id) if (isset($pool[$id])) $kinds[$pool[$id]] = ($kinds[$pool[$id]] ?? 0) + 1;
    $atk = $kinds['attack'] ?? 0; $gain = $kinds['gain'] ?? 0;
    // base shape, then the lean: 10+ attacks in yours adds walls and reactions; 10+ gain in yours adds attacks
    $quota = ['attack' => 10, 'gain' => 8, 'defense' => 5, 'global' => 8, 'trick' => 6, 'passive' => 3];
    if ($atk >= 10) { $quota['defense'] += 3; $quota['passive'] += 2; $quota['attack'] -= 3; $quota['global'] -= 2; }
    if ($gain >= 10) { $quota['attack'] += 3; $quota['trick'] += 1; $quota['global'] -= 4; }
    $byKind = [];
    foreach ($pool as $id => $kind) $byKind[$kind][] = $id;
    foreach ($byKind as $kind => &$ids) usort($ids, fn($a, $b) => (WORTH[$b] ?? 3) <=> (WORTH[$a] ?? 3));
    unset($ids);
    $deck = [];
    foreach ($quota as $kind => $q) {
        $ids = $byKind[$kind] ?? [];
        for ($k = 0; $k < $q; $k++) { if (!$ids) break; $deck[] = $ids[$k % min(count($ids), (int)ceil($q / DECK_COPY_MAX))]; }
    }
    // top up or trim to exactly DECK_SIZE with the best of everything
    $all = array_merge(...array_values($byKind));
    for ($i = 0; count($deck) < DECK_SIZE; $i++) { $cand = $all[$i % count($all)]; if ((array_count_values($deck)[$cand] ?? 0) < DECK_COPY_MAX) $deck[] = $cand; }
    if (count($deck) > DECK_SIZE) $deck = array_slice($deck, 0, DECK_SIZE);
    // keep it legal by the same rails players follow
    $counts = array_count_values($deck);
    if (deck_check($counts) !== '') return founder_deck();
    return deck_list($counts);
}
