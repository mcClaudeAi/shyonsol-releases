<?php
// Shilluminati Online leaderboard. Flat-file storage, no database needed.
// GET  ?a=top&b=all|week|daily|live|holders -> board
// POST a=start (daily: true | duel: id with pid, key) -> one-time game token
// POST a=submit                  -> record a finished game

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/statslib.php';
define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/fairlib.php';   //MC 2026-10-15 the sealed Daily seed
require_once __DIR__ . '/friendslib.php';
define('DAILY', DATA_DIR . '/daily.php');
const MIN_GAME_SECONDS = 20;
const TOKEN_TTL = 6 * 3600;   // long enough for a game left open over lunch
const TOP_N = 25;
const PER_PAGE = 10;
const DAILY_EPOCH = '2026-10-06';

// 5 per Region, +100 win, +50 tie. Easy halves it, hints halve it again. Daily uses Normal rules with no hints.
function points($regions, $result, $mode, $hints) {
    $p = $regions * 5 + ($result === 'win' ? 100 : ($result === 'tie' ? 50 : 0));
    if ($mode === 'easy') $p = intdiv($p, 2);
    if ($hints && $mode !== 'daily') $p = intdiv($p, 2);
    return $p;
}
function daily_no($day) { return (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime(DAILY_EPOCH . ' 00:00:00 UTC')) / 86400) + 1; }

function row($pid, $p, $pts, $extra = []) {
    static $eco = null, $hol = null;
    if ($eco === null) { $eco = load(ECO); $hol = load(HOLDERS); }
    $tr = holder_tier($hol[$pid] ?? null);
    $cos = isset($eco[$pid]) ? eco_public(eco_get($eco, $pid), $tr) : (holder_is_shy($tr) ? ['tier' => $tr] : []);
    //MC 2026-10-11 a few old records have no name
    return ['cos' => $cos, 'name' => $p['name'] ?? '', 'points' => $pts, 'wins' => $p['wins'] ?? 0, 'games' => $p['games'] ?? 0,
        'best' => $p['best'] ?? 0, 'avatar' => $p['avatar'] ?? '', 'img' => !empty($p['avatar']) ? shadow_img($p['avatar']) : '',
        'holder' => !empty($p['holder']), 'aura' => !empty($p['holder']) && !empty($p['avatar']) ? shadow_aura($p['avatar']) : '', 'badges' => $p['badges'] ?? 0, 'x' => $p['xu'] ?? '', 'pid' => substr($pid, 0, 6), 'house' => house_tag_of($pid)] + $extra;
}
function board($players, $which, $daily, $day = null) {
    $list = [];
    if ($which === 'daily') {
        $day = $day ?: today();
        foreach ($daily[$day] ?? [] as $pid => $d) {
            $p = $players[$pid] ?? null;
            if (!$p) continue;
            $list[] = row($pid, $p, $d['points'], ['regions' => $d['regions'], 'result' => $d['result'], 'ts' => $d['ts']] + (!empty($d['mv']) && empty($p['hide']) ? ['rp' => $day . ':' . substr($pid, 0, 6)] : []));
        }
        usort($list, fn($a, $b) => [$b['points'], $b['regions'], $a['ts']] <=> [$a['points'], $a['regions'], $b['ts']]);
        return $list;
    }
    $wk = week_key();
    foreach ($players as $pid => $p) {
        if ($which === 'ranked') {
            $rs = rank_show($p); if (!$rs) continue;
            $list[] = row($pid, $p, $rs['rp'], ['rank' => $rs['tier'], 'rankName' => $rs['name'], 'rk_n' => $rs['n'], 'rk_w' => $rs['w']]);
        } elseif ($which === 'live') {
            if (empty($p['pvp_g'])) continue;
            $list[] = row($pid, $p, $p['lpts'] ?? 0, ['pvp_w' => $p['pvp_w'] ?? 0, 'pvp_g' => $p['pvp_g']]);
        } elseif ($which === 'holders') {
            if (empty($p['holder']) || ($p['wk'] ?? '') !== $wk || empty($p['wpts'])) continue;
            $list[] = row($pid, $p, $p['wpts']);
        } elseif ($which === 'week') {
            if (($p['wk'] ?? '') !== $wk || empty($p['wpts'])) continue;
            $list[] = row($pid, $p, $p['wpts']);
        } else {
            if (empty($p['games'])) continue;   // connected profiles that haven't played yet
            $list[] = row($pid, $p, $p['points']);
        }
    }
    if ($which === 'ranked') usort($list, fn($a, $b) => [$b['points'], $b['rk_w'], $a['rk_n']] <=> [$a['points'], $a['rk_w'], $b['rk_n']]);
    elseif ($which === 'live') usort($list, fn($a, $b) => [$b['points'], $b['pvp_w'], $a['pvp_g']] <=> [$a['points'], $a['pvp_w'], $b['pvp_g']]);
    else usort($list, fn($a, $b) => [$b['points'], $b['wins'], $a['games']] <=> [$a['points'], $a['wins'], $b['games']]);
    return $list;
}
function rank_of($list, $pid) {
    foreach ($list as $i => $r) if ($r['pid'] === substr($pid, 0, 6)) return $i + 1;
    return 0;
}

$a = $_GET['a'] ?? $_POST['a'] ?? '';
$body = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 4000) fail('too large');
    $body = json_decode($raw, true) ?: $_POST;
    $a = $body['a'] ?? $a;
}

if ($a === 'top') {
    $which = in_array($_GET['b'] ?? 'all', ['all', 'week', 'daily', 'live', 'ranked', 'holders'], true) ? ($_GET['b'] ?? 'all') : 'all';
    //MC 2026-10-11 the built board is kept for 15 seconds (cache-board-<board>.php, outside the lock). Every request used
    //   to take the site lock, decode the whole players file and rank everyone: a few clients refreshing the board kept
    //   everyone else waiting. The cache is only used while players.php and daily.php are exactly the files it was built
    //   from (same inode, size and time), so a new score shows at once; save() also drops it when they change.
    $cf = DATA_DIR . '/cache-board-' . $which . '.php';
    $cached = load($cf); $sig = load_sig(PLAYERS) . '|' . load_sig(DAILY);
    if (!empty($cached['list']) && is_array($cached['list']) && time() - (int)($cached['t'] ?? 0) < 15 && ($cached['sig'] ?? '') === $sig) { $list = $cached['list']; $ont = $cached['ont'] ?? []; tg_tick(); }   // the timed jobs keep their own clocks, so they still run from here
    else {
        [$players, $daily] = with_lock(function () { $pl = load(PLAYERS); archive_weeks($pl); rewards_freeze($pl); return [$pl, load(DAILY)]; });
        tg_daily_check($daily, $players);   // yesterday's Daily, once, to the Telegram chat
        tg_tick();                          // reminders to linked players, every couple of minutes at most
        $list = board(array_diff_key($players, banned_in($players)), $which, $daily);   //MC 2026-10-11 banned profiles stay off the boards
        $ont = fr_online_tags($players);
        save($cf, ['t' => time(), 'list' => $list, 'ont' => $ont, 'sig' => $sig]);
    }
    $res = ['ok' => true, 'board' => $which, 'day' => today(), 'daily' => daily_no(today()), 'total' => count($list)];
    if ($which === 'ranked') { [, $se] = season_bounds(season_no()); $res['season'] = ['n' => season_no(), 'ends' => $se, 'tiers' => RANK_TIERS]; }
    if (isset($_GET['pg'])) {
        // pages of 10, plus the asking player's own row so it can stay pinned
        $pages = max(1, (int)ceil(count($list) / PER_PAGE));
        $pg = max(1, min($pages, (int)$_GET['pg']));
        $res += ['page' => $pg, 'pages' => $pages, 'per' => PER_PAGE, 'top' => array_slice($list, ($pg - 1) * PER_PAGE, PER_PAGE)];
        $mine = (string)($_GET['me'] ?? '');
        if (preg_match('/^[a-f0-9]{6}$/', $mine) && ($r = rank_of($list, $mine))) $res['me'] = ['rank' => $r] + $list[$r - 1];
    } else $res['top'] = array_slice($list, 0, TOP_N);   // the home page's mini board
    //MC 2026-10-09 a green dot on whoever is on the site right now ($ont comes with the board, above)
    foreach ($res['top'] as $i => $r) if (isset($ont[$r['pid'] ?? ''])) $res['top'][$i]['on'] = 1;
    if (isset($res['me']) && isset($ont[$res['me']['pid'] ?? ''])) $res['me']['on'] = 1;
    //MC 2026-10-11 the up and down arrows: places moved since the board's first look today (api/lbmoves.php)
    if (isset($_GET['pg'])) { require_once __DIR__ . '/lbmoves.php'; lb_moves_mark($res, $which, $list); }
    out($res);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
//MC 2026-10-11 a banned profile can't start or save games
if (preg_match('/^[a-f0-9]{16}$/', (string)($body['pid'] ?? '')) && player_banned((string)$body['pid'])) fail(BANNED_MSG, 403);

// a Duel run: the Duel's own deal, once for each of the two players
if ($a === 'start' && !empty($body['duel'])) {
    $id = (string)$body['duel'];
    $pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
    if (!preg_match('/^[a-f0-9]{10}$/', $id) || !preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('That Duel link looks wrong.');
    $res = with_lock(function () use ($id, $pid, $key) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'start:' . client_ip(), 200, 3600)) { save(LIMITS, $limits); return ['err' => 'slow down', 'code' => 429]; }
        save(LIMITS, $limits);
        $players = load(PLAYERS);
        if (!key_ok($pid, hash('sha256', $key), $players)) return ['err' => 'not your profile', 'code' => 403];
        $d = duels_tidy(); $x = $d[$id] ?? null;
        if (!$x || ($x['a'] !== $pid && $x['b'] !== $pid)) return ['err' => "That Duel isn't yours, or it's gone.", 'code' => 404];
        $side = $x['a'] === $pid ? 'a' : 'b';
        if (!empty($x['r' . $side])) return ['err' => "You've played this Duel.", 'code' => 409, 'played' => true];
        //MC 2026-10-10 a Duel ended by an unfriend said "You passed on this Duel", and the challenger could still start a
        //   run for one that was already called off (it would never count). Both now get a plain "called off".
        if ($side === 'b' && $x['st'] !== 'open') return ['err' => $x['st'] === 'expired' ? 'This Duel ran out of time.' : ($x['st'] === 'declined' ? (!empty($x['off']) ? 'This Duel was called off.' : 'You passed on this Duel.') : "This Duel isn't ready yet."), 'code' => 409];
        if ($side === 'a' && $x['st'] !== 'new') return ['err' => $x['st'] === 'expired' ? 'This Duel ran out of time.' : 'This Duel was called off.', 'code' => 409];
        if (!fr_are(fr_all(), $x['a'], $x['b'])) return ['err' => "You're not friends any more, so this Duel is off.", 'code' => 409];
        // one run per side: starting again (a reload, a crash) carries on with the same game ticket, and only twice
        $tokens = array_filter(load(TOKENS), fn($t) => $t['ts'] > time() - TOKEN_TTL);
        $tok = $x['t' . $side] ?? '';
        $starts = (int)($x['s' . $side] ?? 0);
        if ($starts >= 2) return ['err' => "You've started this Duel twice already, so it can't be started again.", 'code' => 409, 'played' => true];
        if ($tok === '' || !isset($tokens[$tok])) {
            $tok = bin2hex(random_bytes(12));
            $tokens[$tok] = ['ts' => time(), 'seed' => $x['seed'], 'easy' => false, 'duel' => $id, 'dpid' => $pid, 'deck' => $x['deck'] ?? []];
            save(TOKENS, $tokens);
        }
        $d[$id]['t' . $side] = $tok; $d[$id]['s' . $side] = $starts + 1;
        save(DUELS, $d);
        $vs = $side === 'a' ? $x['b'] : $x['a'];
        return ['token' => $tok, 'seed' => $x['seed'], 'deck' => $x['deck'] ?? [], 'vs' => fr_name($players, $vs), 'vsId' => fr_tag($vs), 'target' => $side === 'b' ? $x['ra']['g'] : null, 'exp' => $x['exp'] ?? 0];
    });
    if (isset($res['err'])) { $c = $res['code']; unset($res['code']); out(['ok' => false, 'error' => $res['err']] + array_diff_key($res, ['err' => 1]), $c); }
    out(['ok' => true, 'easy' => false, 'day' => today(), 'daily' => daily_no(today()), 'duel' => $id] + $res);
}

if ($a === 'start') {
    $isDaily = !empty($body['daily']);
    $easy = !$isDaily && ($body['mode'] ?? '') === 'easy';
    // the seed the browser plays from; the server replays the same game to score it. Daily: same seed for everyone today.
    //MC 2026-10-11 the Daily's seed comes from a server secret now (engine.php daily_seed), not crc32 of the date, so it
    //   can't be worked out before the day's Daily is started. Solo seeds were already random_int, unknown until the start.
    //MC 2026-10-14 the Daily's seed and deck are now wrapped: if anything behind them throws (a damaged deck secret once
    //   fataled every Daily start, leaving the board empty all day), the Daily falls back to the plain date deal and no
    //   season cards rather than a 500, so a run always counts. The cause is written to daily-errors.log for the team.
    $dwarn = '';
    try {
        $seed = $isDaily ? fair_daily_seed(today()) : random_int(0, 0xffffffff);   //MC 2026-10-15 sealed Daily seed (fairlib.php)
    } catch (\Throwable $e) {
        $seed = (int)sprintf('%u', crc32('shy-daily-' . today())); $dwarn = 'seed';
        @file_put_contents(DATA_DIR . '/daily-errors.log', gmdate('c') . ' seed ' . get_class($e) . ': ' . $e->getMessage() . "\n", FILE_APPEND);
    }
    $fp = (string)($body['pid'] ?? '');
    $fk = (string)($body['key'] ?? '');
    // the season cards in the deck: a Daily uses the deck its day started with, so everyone that day plays the same cards
    try {
        cs_maybe_finalize();
        $deck = season_deck_at($isDaily ? strtotime(today() . ' 00:00:00 UTC') : time());
    } catch (\Throwable $e) {
        $deck = []; if ($dwarn === '') $dwarn = 'deck';
        @file_put_contents(DATA_DIR . '/daily-errors.log', gmdate('c') . ' deck ' . get_class($e) . ': ' . $e->getMessage() . "\n", FILE_APPEND);
    }
    $res = with_lock(function () use ($isDaily, $easy, $seed, $fp, $fk, $deck) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'start:' . client_ip(), 200, 3600)) { save(LIMITS, $limits); return null; }
        save(LIMITS, $limits);
        funnel_mark($fp, 's');
        $tokens = load(TOKENS);
        $now = time();
        $tokens = array_filter($tokens, fn($t) => $t['ts'] > $now - TOKEN_TTL);
        //MC 2026-10-11 a Daily started by a known player (pid and key) is recorded. A start after that player's first
        //   move today, or after their run is on the board, is practice. A start before any move carries on with the
        //   same game ticket, so closing the page by accident costs nothing. Starts without a key (old pages, scripts)
        //   work as before; a counted run on one of those is refused at submit if this player has a recorded run.
        $practice = false; $dp = '';
        if ($isDaily && preg_match('/^[a-f0-9]{16}$/', $fp) && preg_match('/^[a-f0-9]{32}$/', $fk) && key_ok($fp, hash('sha256', $fk), load(PLAYERS))) {
            $dp = $fp; $day = today();
            $runs = load(DAILY_RUNS); $r = $runs[$day][$fp] ?? null;
            if (isset(load(DAILY)[$day][$fp]) || ($r && !empty($r['b']))) $practice = true;
            elseif ($r && isset($tokens[$r['t']]) && empty($tokens[$r['t']]['done'])) {
                save(TOKENS, $tokens);
                return ['tok' => $r['t'], 'practice' => false];
            }
            if (!$practice) { $runs[$day][$fp] = ['t' => '', 'b' => 0]; }
        }
        $tok = bin2hex(random_bytes(12));
        $tokens[$tok] = ['ts' => $now, 'seed' => $seed, 'easy' => $easy, 'deck' => $deck] + ($isDaily ? ['day' => today()] : []) + ($dp !== '' ? ['dp' => $dp] : []) + ($practice ? ['pr' => 1] : []);
        save(TOKENS, $tokens);
        if ($dp !== '' && !$practice) { $runs[$day][$fp]['t'] = $tok; save(DAILY_RUNS, daily_runs_tidy($runs)); }
        return ['tok' => $tok, 'practice' => $practice];
    });
    if (!$res) fail('slow down', 429);
    //MC 2026-10-14 bld lets the team confirm which build is actually serving (opcache can keep old PHP after a deploy);
    //   dwarn marks a Daily that fell back because its seed or deck prep threw. Both are harmless extra fields.
    out(['ok' => true, 'token' => $res['tok'], 'seed' => $seed, 'deck' => $deck, 'easy' => $easy, 'day' => today(), 'daily' => daily_no(today()), 'bld' => '20261018o']
        + ($isDaily ? ['practice' => $res['practice']] : []) + ($dwarn !== '' ? ['dwarn' => $dwarn] : []));
}

//MC 2026-10-11 the browser says when the first move of a counted Daily run is made; from then on today's Daily is used
if ($a === 'dbegin') {
    $tok = (string)($body['token'] ?? ''); $pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
    if (!preg_match('/^[a-f0-9]{24}$/', $tok) || !preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad request');
    $ok = with_lock(function () use ($tok, $pid, $key) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'dbegin:' . client_ip(), 120, 3600)) { save(LIMITS, $limits); return false; }
        save(LIMITS, $limits);
        $t = load(TOKENS)[$tok] ?? null;
        if (!$t || empty($t['day']) || ($t['dp'] ?? '') !== $pid || !key_ok($pid, hash('sha256', $key), load(PLAYERS))) return false;
        $runs = load(DAILY_RUNS);
        if (($runs[$t['day']][$pid]['t'] ?? '') !== $tok || !empty($runs[$t['day']][$pid]['b'])) return true;
        $runs[$t['day']][$pid]['b'] = 1;
        save(DAILY_RUNS, daily_runs_tidy($runs));
        return true;
    });
    out(['ok' => (bool)$ok]);
}

if ($a === 'submit') {
    $tok = (string)($body['token'] ?? '');
    $pid = (string)($body['pid'] ?? '');
    $key = (string)($body['key'] ?? '');
    $name = clean_name($body['name'] ?? '');
    $regions = (int)($body['regions'] ?? -1);
    $result = (string)($body['result'] ?? '');
    $mode = in_array($body['mode'] ?? '', ['easy', 'normal', 'daily'], true) ? $body['mode'] : 'normal';
    $hints = !empty($body['hints']);
    $badges = max(0, min(40, (int)($body['badges'] ?? 0)));
    $avatar = preg_match('/^\d{1,4}$/', (string)($body['avatar'] ?? '')) ? (string)$body['avatar'] : '';
    $moves = is_array($body['moves'] ?? null) ? array_slice(array_values($body['moves']), 0, 60) : null;

    if (!preg_match('/^[a-f0-9]{24}$/', $tok)) fail('bad token');
    if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
    if ($name === null) fail(name_problem($body['name'] ?? ''));
    if ($regions < 0 || $regions > count(REGIONS)) fail('bad score');
    if (!in_array($result, ['win', 'tie', 'loss'], true)) fail('bad result');

    //MC 2026-10-11 any Shadow / $SHY lookup that's due happens here, before the lock (see holder_prefetch)
    holder_prefetch($pid, false, hash('sha256', $key));
    $res = with_lock(function () use ($tok, $pid, $key, $name, $regions, $result, $mode, $hints, $badges, $avatar, $moves) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'submit:' . client_ip(), 150, 3600)) { save(LIMITS, $limits); return ['err' => 'slow down', 'code' => 429]; }
        save(LIMITS, $limits);

        $tokens = load(TOKENS);
        $t = $tokens[$tok] ?? null;
        if (!$t) return ['err' => 'This game ran out of time to save. Start a new one.', 'code' => 400];
        // already saved (the reply got lost on the way back): say so instead of failing
        if (!empty($t['done'])) return $t['done'] === $pid ? ['already' => true] : ['err' => 'game not found', 'code' => 400];
        $age = time() - $t['ts'];
        if ($age < MIN_GAME_SECONDS) return ['err' => 'That game was too quick to count.', 'code' => 400];
        if ($age > TOKEN_TTL) return ['err' => 'This game ran out of time to save. Start a new one.', 'code' => 400];
        if (!isset($t['seed']) || $moves === null) return ['err' => 'Refresh the page to update the game, then play again.', 'code' => 400];

        // profile and name checks come BEFORE the game is used up, so a player can fix the name and save again
        $players = load(PLAYERS);
        archive_weeks($players);
        rewards_freeze($players);
        $kh = hash('sha256', $key);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        if (!empty($players[$pid]['nlock']) || !empty($players[$pid]['nprof'])) $name = $players[$pid]['name'];   // set by the admin or on the profile page, keep it
        foreach ($players as $id => $p) {
            if ($id !== $pid && strcasecmp($p['name'] ?? '', $name) === 0) return ['err' => 'That name is taken. Try another.', 'code' => 409];
        }

        // replay the whole game on the server; its result is the one that counts. One try per game.
        $mode = !empty($t['day']) ? 'daily' : (!empty($t['easy']) ? 'easy' : 'normal');
        // a Duel is played at Normal with no hints, by the player it was dealt to
        $duel = $t['duel'] ?? '';
        if ($duel !== '') {
            if (($t['dpid'] ?? '') !== $pid) return ['err' => "That Duel isn't yours.", 'code' => 403];
            $dx = load(DUELS)[$duel] ?? null; $dside = $dx && $dx['a'] === $pid ? 'a' : 'b';
            // only the Duel's own ticket for this player counts, once
            if (!$dx || ($dx['t' . $dside] ?? '') !== $tok || !empty($dx['r' . $dside])) { unset($tokens[$tok]); save(TOKENS, $tokens); return ['err' => "That Duel run can't be saved.", 'code' => 400]; }
            $hints = false;
        }
        eng_season($t['deck'] ?? []);
        $rp = eng_replay($t['seed'], !empty($t['easy']), $moves);
        eng_season([]);
        if (isset($rp['err'])) {
            unset($tokens[$tok]); save(TOKENS, $tokens);
            @file_put_contents(DATA_DIR . '/replay-errors.log', gmdate('c') . ' ' . $rp['err'] . ' seed=' . $t['seed'] . ' moves=' . json_encode($moves) . "\n", FILE_APPEND);
            return ['err' => "We couldn't verify that game, so it wasn't scored.", 'code' => 400];
        }
        $regions = $rp['regions']; $result = $rp['result'];

        // Daily: only the first finished run of the day counts, anywhere. Replays score nothing.
        $daily = load(DAILY);
        $day = $t['day'] ?? '';
        $dailyCounted = false;
        //MC 2026-10-11 also practice: a ticket the start already called practice, a run started by another player, and a
        //   keyless run from a player who has a recorded run today (see start)
        $dr = $mode === 'daily' ? (load(DAILY_RUNS)[$day][$pid] ?? null) : null;
        if ($mode === 'daily' && (isset($daily[$day][$pid]) || !empty($t['pr']) || (($t['dp'] ?? '') !== '' && $t['dp'] !== $pid) || (($t['dp'] ?? '') === '' && $dr && ($dr['t'] ?? '') !== $tok))) {
            $tokens[$tok]['done'] = $pid; save(TOKENS, $tokens);
            return ['practice' => true];
        }

        $p = $players[$pid] ?? ['kh' => $kh, 'points' => 0, 'wins' => 0, 'games' => 0, 'best' => 0, 'since' => time()];
        $gain = points($regions, $result, $mode, $hints);
        // only a verified holder can play as a Shadow; everyone else is Unbound
        [$avatar, $holder] = verified_avatar($pid, $avatar);
        $p['holder'] = $holder;
        $wk = week_key();
        if (($p['wk'] ?? '') !== $wk) { $p['wk'] = $wk; $p['wpts'] = 0; }
        $p['name'] = $name;
        $p['avatar'] = $avatar;
        $p['badges'] = max($p['badges'] ?? 0, $badges);
        $p['points'] = ($p['points'] ?? 0) + $gain;
        $p['wpts'] = ($p['wpts'] ?? 0) + $gain;
        $p['games'] = ($p['games'] ?? 0) + 1;
        if ($result === 'win') $p['wins'] = ($p['wins'] ?? 0) + 1;
        $prevBest = (int)($p['best'] ?? 0);
        $p['best'] = max($prevBest, $regions);
        $p['last'] = time();
        // the Daily Challenge (first try) counts toward the prize league; quick solo games don't
        $leagueGain = $mode === 'daily' ? league_add($p, $gain) : 0;
        game_log($p, $mode, $result, $regions, $gain);
        stats_add($pid, $mode, $result, $regions, $rp['cards'] ?? []);
        if ($duel === '') tg_game($mode, $name, $result, $regions, ['pid' => $pid, 'no' => $mode === 'daily' ? daily_no($day) : 0, 'all' => $rp['all'] ?? [], 'hints' => $hints,
            'gain' => $gain, 'wins' => $p['wins'], 'games' => $p['games'], 'best' => $p['best'], 'pb' => $p['games'] > 1 && $regions > $prevBest,
            'shadow' => $holder && $avatar !== '' ? $avatar : 0]);
        //MC 2026-10-15 a first-ever game (not a Duel) is a new player: welcome them in the Telegram chat (tg_join)
        if ((int)$p['games'] === 1 && $duel === '' && function_exists('tg_join')) tg_join($pid, $name, ['mode' => $mode, 'result' => $result, 'regions' => $regions], count(array_filter($players, fn($x) => !empty($x['games']))) + 1);
        $players[$pid] = $p;
        save(PLAYERS, $players);
        // the game is used up only once the score is safely written
        $tokens[$tok]['done'] = $pid; save(TOKENS, $tokens);
        if ($avatar !== '') shadow_record($avatar, $gain, $result, $regions, false);
        $eco = eco_award_game($pid, $mode === 'daily' ? 'daily' : 'solo', $result, 0, ['regions' => $regions, 'easy' => $mode === 'easy', 'cards' => $rp['cards'] ?? []]);

        $duelOut = $duel !== '' ? duel_scored($duel, $pid, $regions, $result, $gain) : null;
        //MC 2026-10-09 the 15 Club bounty: Normal with hints off, or a first Daily run. Easy and Duels don't count.
        $bounty = $duel === '' && !$hints && in_array($mode, ['normal', 'daily'], true) ? bounty_claim($pid, $name, $mode, $regions, $result) : null;
        $dailyRank = 0;
        if ($mode === 'daily') {
            $daily[$day][$pid] = ['points' => $gain, 'regions' => $regions, 'result' => $result, 'ts' => time(), 'lg' => 1,   // lg: counted in the League
                'mv' => array_map(fn($m) => (int)($m['h'] ?? -1) < 0 ? [-1] : [(int)$m['h'], isset($m['t']) && $m['t'] !== null ? (int)$m['t'] : null], $moves),   // the moves, for replays
                'sd' => (int)$t['seed']];   //MC 2026-10-11 and the deal it was played on, so its replay never depends on how the day's seed is made
            $dailyCounted = true;
            krsort($daily);
            $daily = array_slice($daily, 0, 7, true);
            save(DAILY, $daily);
            $dailyRank = rank_of(board($players, 'daily', $daily, $day), $pid);
        }

        $list = board($players, 'all', $daily);
        return ['gain' => $gain, 'rank' => rank_of($list, $pid), 'total' => count($list), 'bounty' => $bounty,
            'weekRank' => rank_of(board($players, 'week', $daily), $pid),
            'daily' => $mode === 'daily', 'dailyCounted' => $dailyCounted, 'dailyRank' => $dailyRank,
            'dailyTotal' => count($daily[$day ?: today()] ?? []),
            'me' => ['name' => $p['name'], 'points' => $p['points'], 'wpts' => $p['wpts'], 'wins' => $p['wins'], 'games' => $p['games'], 'avatar' => $avatar, 'holder' => $holder],
            'verified' => ['regions' => $regions, 'result' => $result],
            'eco' => $eco, 'duel' => $duelOut, 'league' => $leagueGain ? ['gain' => $leagueGain, 'pts' => $p['lg']['pts']] : null,
            'top' => array_slice($list, 0, TOP_N)];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    if (!empty($res['already'])) out(['ok' => true, 'already' => true]);
    if (!empty($res['practice'])) out(['ok' => true, 'practice' => true]);
    out(['ok' => true] + $res);
}

fail('unknown action');
