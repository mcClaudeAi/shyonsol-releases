<?php
// Admin team: personal sign-ins, roles and per-area permissions (none, view or edit), and an activity log.
// Accounts live in shy-data/admins.php. The old shared password in config.php ('admin_hash') still works as the
// setup key: sign in with an empty name, create your own owner account, and you can retire the key.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)

define('ADMINS', DATA_DIR . '/admins.php');
define('AUDIT', DATA_DIR . '/admin-audit.php');

// every part of the admin, and what "view" and "edit" mean there
const AREAS = [
    'overview' => ['Overview', 'The numbers at a glance.', 1],
    'ideas'    => ['Ideas', 'Read suggestions; edit to reply, change status and publish to the board.', 2],
    'players'  => ['Players', 'See players and wallets; edit to rename, remove, combine, block words and set X posting.', 2],
    'shop'     => ['Shop', 'See sales and orders; edit to check payments on Solana and deliver orders.', 2],
    'gifts'    => ['Give Koban and items', 'Hand out free Koban or cosmetics to a player.', 2],
    'rewards'  => ['Prize settings', 'See prize pools and events; edit to change pools, splits, holder tiers and events.', 2],
    'payouts'  => ['Prize payouts', 'See who is owed prizes; edit to price and send payouts from the marketing wallet.', 2],
    'boards'   => ['Boards', 'Weekly, Daily, Holders and Live rooms; edit to close a stuck live room.', 2],
    'telegram' => ['Telegram', 'See the bot setup; edit to change what posts to the chat.', 2],
    'tourney'  => ['Tournaments', 'See tournaments and brackets; edit to schedule, start or call them off.', 2],
    'art'      => ['Card art', 'See the card art; edit to upload, publish or revert new art.', 2],
    'logs'     => ['Logs', 'Read problem logs; edit to clear them.', 2],
    'backups'  => ['Backups', 'See and download backups; edit to restore one.', 2],
    'team'     => ['Team', 'See the admins and the activity log; edit to add admins and change their access.', 2],
];
// ready-made roles; Custom lets you set each area by hand
const ROLES = [
    'owner'     => ['Owner', 'Everything, including other owners and the setup key.'],
    'admin'     => ['Admin', 'Runs the whole site and manages the team, but can\'t change owners.'],
    'moderator' => ['Moderator', 'Keeps the boards friendly: players, names and ideas.'],
    'support'   => ['Support', 'Helps players with purchases: checks payments and delivers orders.'],
    'treasurer' => ['Treasurer', 'Prize pools and payouts, with a view of the shop.'],
    'viewer'    => ['Viewer', 'Sees everything except the team, changes nothing.'],
    'custom'    => ['Custom', 'Pick each area yourself.'],
];
function role_perms($role) {
    $all = fn($lvl) => array_map(fn($a) => min($lvl, $a[2]), AREAS);
    switch ($role) {
        case 'owner': return $all(2);
        case 'admin': return $all(2);
        case 'moderator': return array_merge($all(0), ['overview' => 1, 'ideas' => 2, 'players' => 2, 'boards' => 2, 'tourney' => 2, 'telegram' => 1, 'logs' => 1]);
        case 'support': return array_merge($all(0), ['overview' => 1, 'ideas' => 1, 'players' => 1, 'shop' => 2, 'boards' => 1, 'logs' => 1]);
        case 'treasurer': return array_merge($all(0), ['overview' => 1, 'shop' => 1, 'rewards' => 2, 'payouts' => 2, 'boards' => 1, 'logs' => 1]);
        case 'viewer': return array_merge($all(1), ['team' => 0]);
    }
    return $all(0);
}
function user_perms($u) {
    if (!$u) return role_perms('none');
    if (($u['role'] ?? '') === 'custom') { $p = role_perms('none'); foreach (AREAS as $k => $a) $p[$k] = max(0, min($a[2], (int)($u['perms'][$k] ?? 0))); return $p; }
    return role_perms($u['role'] ?? 'viewer');
}
function team() { return load(ADMINS); }
function team_find($team, $login) {
    $l = strtolower(trim($login));
    foreach ($team as $id => $u) if (strtolower($u['username']) === $l || ($u['email'] !== '' && strtolower($u['email']) === $l)) return $id;
    return null;
}
function owners_active($team) { return count(array_filter($team, fn($u) => $u['role'] === 'owner' && !empty($u['active']))); }
function temp_password() {
    $a = 'abcdefghjkmnpqrstuvwxyz23456789'; $p = '';
    for ($g = 0; $g < 4; $g++) { if ($g) $p .= '-'; for ($i = 0; $i < 5; $i++) $p .= $a[random_int(0, strlen($a) - 1)]; }
    return $p;
}

// the signed-in admin: a team member, or the setup key ('key')
$ME = null;
function me() { return $GLOBALS['ME']; }
function can($area, $lvl = 1) { $m = me(); return $m && ((int)($m['perms'][$area] ?? 0)) >= $lvl; }
function is_owner() { $m = me(); return $m && $m['role'] === 'owner'; }
function load_me() {
    $uid = $_SESSION['uid'] ?? '';
    if ($uid === 'key') return ['id' => 'key', 'name' => 'Setup key', 'username' => 'setup key', 'email' => '', 'role' => 'owner', 'perms' => role_perms('owner'), 'key' => 1];
    $u = team()[$uid] ?? null;
    if (!$u || empty($u['active']) || (int)($u['sv'] ?? 0) !== (int)($_SESSION['sv'] ?? -1)) return null;
    return array_merge($u, ['id' => $uid, 'perms' => user_perms($u)]);
}

// ---------- activity log ----------
function audit($what, $info = '') {
    $m = me();
    $row = ['t' => time(), 'u' => $m['id'] ?? '', 'n' => $m['username'] ?? ($info['user'] ?? ''), 'do' => $what, 'i' => is_array($info) ? $info : ['note' => (string)$info]];
    with_lock(function () use ($row) { $a = load(AUDIT); array_unshift($a, $row); save(AUDIT, array_slice($a, 0, 3000)); });
}
// which admin action needs which permission
const ACTION_NEEDS = [
    'rename' => ['players', 2], 'clear-motto' => ['players', 2], 'remove' => ['players', 2], 'merge' => ['players', 2], 'ban' => ['players', 2], 'unban' => ['players', 2], 'blocked-words' => ['players', 2], 'x-settings' => ['players', 2], 'hype-tags' => ['players', 2], 'rel-posted' => ['players', 2],
    'idea-save' => ['ideas', 2], 'idea-translate' => ['ideas', 2], 'idea-publish' => ['ideas', 2], 'idea-delete' => ['ideas', 2], 'idea-email' => ['ideas', 2], 'mail-save' => ['team', 2], 'mail-test' => ['overview', 1], 'mail-report' => ['overview', 1],
    //MC 2026-10-15 trophy-* and ew-save: trophies and wallet sign-in (the key forms also check for the owner)
    'order-check' => ['shop', 2], 'order-paid' => ['shop', 2], 'payhelp-close' => ['shop', 2], 'grant' => ['gifts', 2], 'xt-settings' => ['shop', 2], 'ref-settings' => ['shop', 2], 'trophy-save' => ['shop', 2], 'trophy-run' => ['shop', 2], 'trophy-retry' => ['shop', 2], 'trophy-backfill' => ['shop', 2], 'trophy-give' => ['shop', 2], 'ew-save' => ['shop', 2], 'xt-revoke' => ['gifts', 2], 'xt-free' => ['shop', 2],
    'eco-settings' => ['rewards', 2], 'league-credit' => ['rewards', 2], 'league-skip' => ['rewards', 2], 'event-add' => ['rewards', 2], 'event-del' => ['rewards', 2], 'bounty-save' => ['payouts', 2], 'bounty-paid' => ['payouts', 2], 'bounty-void' => ['payouts', 2], 'treasury-add' => ['payouts', 2], 'burn-scan' => ['payouts', 2], 'burn-log' => ['payouts', 2], 'burn-clear' => ['payouts', 2], 'house-settings' => ['rewards', 2], 'house-del' => ['rewards', 2], 'house-clear' => ['rewards', 2], 'treasury-del' => ['payouts', 2],
    'payout-prepare' => ['payouts', 2], 'payout-skip' => ['payouts', 2], 'payout-approve' => ['payouts', 2],
    'close-room' => ['boards', 2], 'fp-settings' => ['players', 2], 'fp-strike' => ['players', 2], 'tg-save' => ['telegram', 2], 'tg-find' => ['telegram', 2], 'tg-pick' => ['telegram', 2], 'tg-app' => ['telegram', 2], 'tg-burn' => ['telegram', 2], 'tg-release' => ['telegram', 2],
    'tourney-add' => ['tourney', 2], 'tourney-start' => ['tourney', 2], 'tourney-cancel' => ['tourney', 2], 'tourney-del' => ['tourney', 2],
    'art-upload' => ['art', 2], 'art-focus' => ['art', 2], 'art-publish' => ['art', 2], 'art-discard' => ['art', 2], 'art-revert' => ['art', 2], 'art-restore' => ['art', 2], 'art-backup' => ['art', 2], 'shop-reroll' => ['shop', 2], 'mask-upload' => ['art', 2], 'mask-revert' => ['art', 2], 'drop-add' => ['shop', 2], 'drop-off' => ['shop', 2], 'drop-del' => ['shop', 2], 'cardset-public' => ['art', 2],
    'clear-log' => ['logs', 2], 'restore' => ['backups', 2], 'hash-tool' => ['team', 2], 'deploy-zip' => ['backups', 2], 'deploy-prev' => ['backups', 2],   //MC 2026-10-13 deploy also checks for an owner
    //MC 2026-10-16 exp-settings and seeker-settings: Admin > Expeditions and Seeker
    'tg-resend' => ['telegram', 2], 'tg-msg' => ['telegram', 2], 'shop-prices' => ['shop', 2], 'chat-settings' => ['players', 2], 'boss-settings' => ['rewards', 2], 'exp-settings' => ['rewards', 2], 'seeker-settings' => ['rewards', 2], 'tg-link' => ['telegram', 2], 'lg-week' => ['rewards', 2], 'recon-run' => ['shop', 2], 'lg-recover' => ['rewards', 2],   //MC 2026-10-11 lg-recover also checks for an owner
    'team-add' => ['team', 2], 'team-edit' => ['team', 2], 'team-reset' => ['team', 2], 'team-remove' => ['team', 2], 'team-2fa' => ['team', 2],
];
// a short note of what an action touched, for the activity log (never passwords or tokens)
function action_note($do) {
    $keep = ['card', 'help', 'day', 'pid', 'why', 'who', 'from', 'into', 'name', 'order', 'period', 'who', 'koban', 'item', 'why', 'id', 'status', 'f', 'log', 'code', 'chat', 'username', 'role', 'uid', 'i', 'key'];
    $n = [];
    foreach ($keep as $k) if (isset($_POST[$k]) && $_POST[$k] !== '' && is_string($_POST[$k])) $n[$k] = mb_substr($_POST[$k], 0, 80);
    return $n;
}

// ---------- team actions ----------
function team_actions($do) {
    $me = me();
    $levels = function () { $p = []; foreach (AREAS as $k => $a) $p[$k] = max(0, min($a[2], (int)($_POST['p_' . $k] ?? 0))); return $p; };
    // nobody hands out more than they have, and only owners make or change owners
    $within = function ($perms, $role) use ($me) {
        if ($role === 'owner' && $me['role'] !== 'owner') return 'Only an owner can make someone an owner.';
        foreach ($perms as $k => $l) if ($l > (int)($me['perms'][$k] ?? 0)) return 'You can only give access you have yourself (' . AREAS[$k][0] . ').';
        return '';
    };
    if ($do === 'team-add') {
        $name = trim(mb_substr((string)($_POST['name'] ?? ''), 0, 40));
        $user = strtolower(trim((string)($_POST['username'] ?? '')));
        $email = strtolower(trim((string)($_POST['email'] ?? '')));
        $role = (string)($_POST['role'] ?? 'viewer'); if (!isset(ROLES[$role])) $role = 'viewer';
        if (!preg_match('/^[a-z0-9_.\-]{3,24}$/', $user)) go('team', 'Usernames are 3 to 24 lowercase letters, numbers, dots, dashes or underscores.');
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) go('team', 'That email doesn\'t look right.');
        $perms = $role === 'custom' ? $levels() : role_perms($role);
        if ($e = $within($perms, $role)) go('team', $e);
        $pw = temp_password();
        $res = with_lock(function () use ($name, $user, $email, $role, $perms, $pw, $me) {
            $t = team();
            if (team_find($t, $user) !== null || ($email !== '' && team_find($t, $email) !== null)) return 'Someone already uses that username or email.';
            $id = bin2hex(random_bytes(6));
            $t[$id] = ['name' => $name ?: $user, 'username' => $user, 'email' => $email, 'role' => $role, 'perms' => $role === 'custom' ? $perms : [], 'hash' => password_hash($pw, PASSWORD_DEFAULT),
                'active' => 1, 'must_change' => 1, 'sv' => 1, 'created' => time(), 'by' => $me['username'], 'last' => 0, 'fails' => 0, 'locked' => 0];
            save(ADMINS, $t);
            return '';
        });
        if ($res) go('team', $res);
        audit('team-add', ['username' => $user, 'role' => $role]);
        $_SESSION['reveal'] = ['user' => $user, 'pw' => $pw, 'email' => $email];
        if ($email !== '' && !empty($_POST['invite'])) team_invite($email, $name ?: $user, $user, $me['name'] ?? 'An owner');
        go('team', 'Added ' . $user . ' as ' . ROLES[$role][0] . '. Share the temporary password below privately. They pick their own when they first sign in.');
    }
    $uid = (string)($_POST['uid'] ?? '');
    $t = team(); $u = $t[$uid] ?? null;
    if (!$u) go('team', 'That admin is gone.');
    // you can only manage people whose access is within your own
    if ($u['role'] === 'owner' && $me['role'] !== 'owner') go('team', 'Only an owner can change an owner.');
    foreach (user_perms($u) as $k => $l) if ($l > (int)($me['perms'][$k] ?? 0)) go('team', 'That admin has access you don\'t, so only an owner can change them.');
    if ($do === 'team-edit') {
        $role = (string)($_POST['role'] ?? $u['role']); if (!isset(ROLES[$role])) $role = $u['role'];
        $perms = $role === 'custom' ? $levels() : role_perms($role);
        if ($e = $within($perms, $role)) go('team', $e);
        $active = !empty($_POST['active']) ? 1 : 0;
        $name = trim(mb_substr((string)($_POST['name'] ?? $u['name']), 0, 40));
        $email = strtolower(trim((string)($_POST['email'] ?? $u['email'])));
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) go('team', 'That email doesn\'t look right.');
        $msg = with_lock(function () use ($uid, $role, $perms, $active, $name, $email, $me) {
            $t = team(); $u = $t[$uid];
            $other = team_find($t, $email);
            if ($email !== '' && $other !== null && $other !== $uid) return 'Another admin already uses that email.';
            $wasOwner = $u['role'] === 'owner' && !empty($u['active']);
            if ($wasOwner && ($role !== 'owner' || !$active) && owners_active($t) <= 1) return 'This is the last active owner. Make someone else an owner first.';
            if ($uid === $me['id'] && !$active) return 'You can\'t switch off your own account.';
            if (!$active && !empty($u['active'])) $u['sv'] = (int)$u['sv'] + 1;   // signs them out now
            $u['role'] = $role; $u['perms'] = $role === 'custom' ? $perms : []; $u['active'] = $active; $u['name'] = $name ?: $u['username']; $u['email'] = $email;
            $t[$uid] = $u; save(ADMINS, $t);
            return '';
        });
        if ($msg) go('team', $msg);
        audit('team-edit', ['username' => $u['username'], 'role' => $role, 'active' => $active]);
        go('team', 'Saved ' . $u['username'] . '. Changes apply on their next click.');
    }
    if ($do === 'team-reset') {
        $pw = temp_password();
        with_lock(function () use ($uid, $pw) { $t = team(); $t[$uid]['hash'] = password_hash($pw, PASSWORD_DEFAULT); $t[$uid]['must_change'] = 1; $t[$uid]['sv'] = (int)$t[$uid]['sv'] + 1; $t[$uid]['fails'] = 0; $t[$uid]['locked'] = 0; save(ADMINS, $t); });
        audit('team-reset', ['username' => $u['username']]);
        $_SESSION['reveal'] = ['user' => $u['username'], 'pw' => $pw, 'email' => $u['email']];
        go('team', 'New temporary password for ' . $u['username'] . '. They were signed out and pick a new password at their next sign-in.');
    }
    if ($do === 'team-2fa') {
        if ($me['role'] !== 'owner') go('team', 'Only an owner can reset two-step sign-in.');
        with_lock(function () use ($uid) { $t = team(); unset($t[$uid]['tfa'], $t[$uid]['tfa_rc'], $t[$uid]['tfa_last']); $t[$uid]['sv'] = (int)$t[$uid]['sv'] + 1; save(ADMINS, $t); });
        audit('team-2fa', ['username' => $u['username']]);
        go('team', 'Two-step sign-in reset for ' . $u['username'] . '. They were signed out and set it up again when they next sign in.');
    }
    if ($do === 'team-remove') {
        $msg = with_lock(function () use ($uid, $me) {
            $t = team();
            if ($uid === $me['id']) return 'You can\'t remove yourself.';
            if ($t[$uid]['role'] === 'owner' && owners_active($t) <= 1 && !empty($t[$uid]['active'])) return 'This is the last active owner.';
            unset($t[$uid]); save(ADMINS, $t); return '';
        });
        if ($msg) go('team', $msg);
        audit('team-remove', ['username' => $u['username']]);
        go('team', 'Removed ' . $u['username'] . '. They can no longer sign in.');
    }
}
function team_invite($email, $name, $user, $from) {
    $host = preg_replace('/[^a-z0-9.\-:]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io');
    $body = "Hi $name,\n\n$from added you to the Shy on Solana admin.\n\nSign in at https://$host/admin/ with the username: $user\n\n$from will send you a temporary password separately. You'll pick your own password the first time you sign in.\n\nShy on Solana";
    $headers = "From: Shy on Solana <no-reply@$host>\r\nContent-Type: text/plain; charset=utf-8";
    @mail($email, 'You\'re now an admin on shyonsol.io', $body, $headers);
}

// ---------- my account ----------
function account_actions($do) {
    $me = me();
    if ($do !== 'account-save' || !empty($me['key'])) return;
    $cur = (string)($_POST['current'] ?? ''); $new = (string)($_POST['new'] ?? ''); $new2 = (string)($_POST['new2'] ?? '');
    $t = team(); $u = $t[$me['id']];
    $name = trim(mb_substr((string)($_POST['name'] ?? $u['name']), 0, 40));
    $email = strtolower(trim((string)($_POST['email'] ?? $u['email'])));
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) go('account', 'That email doesn\'t look right.');
    $other = team_find($t, $email);
    if ($email !== '' && $other !== null && $other !== $me['id']) go('account', 'Another admin already uses that email.');
    if ($new !== '' || !empty($u['must_change'])) {
        if (!password_verify($cur, $u['hash'])) { usleep(300000); go('account', 'Your current password isn\'t right.'); }
        if (strlen($new) < 12) go('account', 'Pick a new password of at least 12 characters.');
        if ($new !== $new2) go('account', 'The two new passwords don\'t match.');
        if (password_verify($new, $u['hash'])) go('account', 'Pick a password you haven\'t used here before.');
        if (stripos($new, $u['username']) !== false) go('account', 'Keep your username out of your password.');
    }
    with_lock(function () use ($me, $name, $email, $new) {
        $t = team(); $u = $t[$me['id']];
        $u['name'] = $name ?: $u['username']; $u['email'] = $email;
        if ($new !== '') { $u['hash'] = password_hash($new, PASSWORD_DEFAULT); $u['must_change'] = 0; $u['sv'] = (int)$u['sv'] + 1; }
        $t[$me['id']] = $u; save(ADMINS, $t);
        if ($new !== '') $_SESSION['sv'] = $u['sv'];   // stay signed in here, every other device is signed out
    });
    audit('account-save', ['password' => $new !== '' ? 'changed' : 'unchanged']);
    go($new !== '' ? 'overview' : 'account', $new !== '' ? 'Password changed. Any other device signed in as you was signed out.' : 'Saved.');
}

// ---------- sign in ----------
function team_login($login, $pw) {
    $login = trim($login);
    $ip = with_lock(function () { $l = load(LIMITS); $r = rate_ok($l, 'admin:' . client_ip(), 10, 900); save(LIMITS, $l); return $r; });
    if (!$ip) return 'Too many tries from here. Wait 15 minutes.';
    // the setup key: the shared password in config.php, with no name
    if ($login === '' || strtolower($login) === 'setup') {
        $hash = admin_hash();
        if ($hash === '') return 'Enter your username or email.';
        if (!password_verify($pw, $hash)) { usleep(400000); audit_raw('login-failed', 'setup key'); return 'Wrong password.'; }
        login_ok_ip();
        session_regenerate_id(true); $_SESSION['ok'] = 1; $_SESSION['uid'] = 'key'; $_SESSION['sv'] = 0; $_SESSION['seen'] = time();
        $GLOBALS['ME'] = load_me(); audit('login', 'setup key');
        go(team() ? 'overview' : 'team', team() ? '' : 'Signed in with the setup key. Create your own owner account below, then use that from now on.');
    }
    $res = with_lock(function () use ($login, $pw) {
        $t = team(); $id = team_find($t, $login);
        if ($id === null) { usleep(400000); return ['err' => 'Wrong username or password.']; }
        $u = $t[$id];
        if (empty($u['active'])) return ['err' => 'This admin account is switched off. Ask an owner.'];
        if (($u['locked'] ?? 0) > time()) return ['err' => 'Too many wrong passwords. This account is locked for ' . ceil(($u['locked'] - time()) / 60) . ' more minutes.'];
        if (!password_verify($pw, $u['hash'])) {
            $u['fails'] = (int)($u['fails'] ?? 0) + 1;
            if ($u['fails'] >= 5) { $u['locked'] = time() + 900; $u['fails'] = 0; }
            $t[$id] = $u; save(ADMINS, $t); usleep(400000);
            return ['err' => 'Wrong username or password.', 'fail' => $u['username']];
        }
        if (password_needs_rehash($u['hash'], PASSWORD_DEFAULT)) $u['hash'] = password_hash($pw, PASSWORD_DEFAULT);
        $u['fails'] = 0; $u['locked'] = 0; $u['prev'] = $u['last'] ?? 0; $u['last'] = time(); $t[$id] = $u; save(ADMINS, $t);
        return ['id' => $id, 'sv' => (int)$u['sv']];
    });
    if (!empty($res['err'])) { if (!empty($res['fail'])) audit_raw('login-failed', $res['fail']); return $res['err']; }
    // two-step sign-in: the password was right, now the code from their app
    if (!empty(team()[$res['id']]['tfa'])) {
        session_regenerate_id(true);
        $_SESSION['tfa'] = ['uid' => $res['id'], 'at' => time()];
        header('Location: ./'); exit;
    }
    login_ok_ip();
    session_regenerate_id(true); $_SESSION['ok'] = 1; $_SESSION['uid'] = $res['id']; $_SESSION['sv'] = $res['sv']; $_SESSION['seen'] = time();
    $GLOBALS['ME'] = load_me(); audit('login');
    go(!empty($GLOBALS['ME']['must_change']) ? 'account' : 'overview', !empty($GLOBALS['ME']['must_change']) ? 'Welcome. Pick your own password to finish signing in.' : '');
}
// a good sign-in clears this address's count, so only wrong guesses add up
function login_ok_ip() { with_lock(function () { $l = load(LIMITS); unset($l['admin:' . client_ip()]); save(LIMITS, $l); }); }
function audit_raw($what, $who) {
    $row = ['t' => time(), 'u' => '', 'n' => $who, 'do' => $what, 'i' => []];
    with_lock(function () use ($row) { $a = load(AUDIT); array_unshift($a, $row); save(AUDIT, array_slice($a, 0, 3000)); });
}

// ---------- pages ----------
const LEVEL_LABEL = [0 => 'No access', 1 => 'View', 2 => 'Edit'];
function perm_grid($perms, $locked = false, $limit = null) {
    $o = '<div class="pgrid">';
    foreach (AREAS as $k => $a) {
        $o .= '<div class="prow"><span><b>' . h($a[0]) . '</b><small>' . h($a[1]) . '</small></span><span class="pseg">';
        for ($l = 0; $l <= $a[2]; $l++) {
            $dis = $locked || ($limit !== null && $l > (int)($limit[$k] ?? 0));
            $o .= '<label' . ($dis ? ' class="dis"' : '') . '><input type="radio" name="p_' . $k . '" value="' . $l . '"' . ((int)($perms[$k] ?? 0) === $l ? ' checked' : '') . ($dis ? ' disabled' : '') . '><span>' . LEVEL_LABEL[$l] . '</span></label>';
        }
        $o .= '</span></div>';
    }
    return $o . '</div>';
}
function access_summary($perms) {
    $e = []; $v = [];
    foreach (AREAS as $k => $a) { if (($perms[$k] ?? 0) >= 2) $e[] = $a[0]; elseif (($perms[$k] ?? 0) === 1) $v[] = $a[0]; }
    if (count($e) === count(AREAS)) return 'Edit everything';
    $s = $e ? 'Edit: ' . implode(', ', $e) : '';
    if ($v) $s .= ($s ? '. ' : '') . 'View: ' . (count($v) > 4 ? count($v) . ' areas' : implode(', ', $v));
    return $s ?: 'No access';
}
function role_options($cur, $me) {
    $o = '';
    foreach (ROLES as $k => $r) { if ($k === 'owner' && $me['role'] !== 'owner') continue; $o .= '<option value="' . $k . '"' . ($k === $cur ? ' selected' : '') . '>' . h($r[0]) . '</option>'; }
    return $o;
}
function page_team() {
    $me = me(); $t = team(); $edit = can('team', 2);
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    if (!empty($_SESSION['reveal'])) {
        $r = $_SESSION['reveal']; unset($_SESSION['reveal']);
        echo '<div class="reveal"><b>Temporary password for ' . h($r['user']) . '</b><p class="muted">Shown once. Send it privately, not in a group chat. They sign in at <code>shyonsol.io/admin</code> with the username <code>' . h($r['user']) . '</code>' . ($r['email'] ? ' or <code>' . h($r['email']) . '</code>' : '') . ' and pick their own password straight away.</p><div class="hashline"><code id="tmp-pw">' . h($r['pw']) . '</code><button type="button" class="ghost" data-copy="tmp-pw">Copy</button></div></div>';
    }
    if (!empty($me['key'])) echo '<div class="tg-status"><b>You\'re signed in with the setup key.</b><span>That\'s the shared password from config.php. Add yourself below as an Owner with your own username, sign in with that, and the setup key is only needed if everyone gets locked out.</span></div>';
    // the team
    //MC 2026-10-09 tw-team class replaces the .tw:has(table.team) selector, which slowed down the big Players table
    echo '<h2>Admins <small>' . count($t) . '</small></h2><div class="tw tw-team"><table class="team"><thead><tr><th>Admin</th><th>Role</th><th>Access</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead><tbody>';
    foreach ($t as $id => $u) {
        $p = user_perms($u);
        $st = empty($u['active']) ? '<span class="pill off">Off</span>' : (($u['locked'] ?? 0) > time() ? '<span class="pill warn">Locked</span>' : (!empty($u['must_change']) ? '<span class="pill warn">Invited</span>' : '<span class="pill on">Active</span>'));
        $st .= !empty($u['tfa']) ? ' <span class="pill on" title="Signs in with a code from an app">2-step</span>' : (tfa_required($u) && !empty($u['active']) ? ' <span class="pill warn" title="Needs to set up two-step sign-in">No 2-step</span>' : '');
        echo '<tr><td><div class="who"><span class="av">' . h(mb_strtoupper(mb_substr($u['name'], 0, 1))) . '</span><span><b>' . h($u['name']) . ($id === ($me['id'] ?? '') ? ' <small>(you)</small>' : '') . '</b><small>' . h($u['username']) . ($u['email'] ? ' &middot; ' . h($u['email']) : '') . '</small></span></div></td>' .
            '<td><span class="role r-' . h($u['role']) . '">' . h(ROLES[$u['role']][0] ?? $u['role']) . '</span></td><td class="muted small">' . h(access_summary($p)) . '</td><td>' . $st . '</td><td class="muted small">' . ($u['last'] ? h(ago($u['last'])) : 'Never') . '</td><td class="acts">';
        $mine = true; foreach ($p as $k => $l) if ($l > (int)($me['perms'][$k] ?? 0)) $mine = false;
        if ($edit && $mine && !($u['role'] === 'owner' && $me['role'] !== 'owner')) {
            echo '<details class="tedit"><summary class="btnish">Edit</summary><form method="post" class="tform">' . $csrf . '<div class="tehead"><b>Edit ' . h($u['name']) . '</b><button type="button" class="ghost tclose" onclick="this.closest(\'details\').open=false">Close</button></div><input type="hidden" name="uid" value="' . h($id) . '">' .
                '<div class="grid2"><label>Name<input name="name" value="' . h($u['name']) . '"></label><label>Email<input name="email" type="email" value="' . h($u['email']) . '"></label></div>' .
                '<label>Role<select name="role" data-role>' . role_options($u['role'], $me) . '</select></label>' .
                '<div class="pwrap"' . ($u['role'] === 'custom' ? '' : ' data-preset') . '>' . perm_grid($p, false, $me['perms']) . '</div>' .
                '<label class="chk"><input type="checkbox" name="active" value="1"' . (!empty($u['active']) ? ' checked' : '') . '> Can sign in</label>' .
                '<div class="bar"><button name="do" value="team-edit">Save</button><button name="do" value="team-reset" class="ghost" data-confirm="Make a new temporary password for ' . h($u['username']) . '? They get signed out everywhere.">New temporary password</button>' .
                (!empty($u['tfa']) && $id !== ($me['id'] ?? '') && $me['role'] === 'owner' ? '<button name="do" value="team-2fa" class="ghost" data-confirm="Switch off two-step sign-in for ' . h($u['username']) . '? Do this only if they lost their phone. They set it up again at their next sign-in.">Reset two-step</button>' : '') .
                ($id !== ($me['id'] ?? '') ? '<button name="do" value="team-remove" class="ghost danger" data-confirm="Remove ' . h($u['username']) . ' from the admin for good?">Remove</button>' : '') . '</div></form></details>';
        }
        echo '</td></tr>';
    }
    if (!$t) echo '<tr><td colspan="6" class="muted">No personal accounts yet. Everyone signs in with the setup key until you add them here.</td></tr>';
    echo '</tbody></table></div>';
    // add someone
    if ($edit) {
        echo '<details class="addbox"' . (!$t ? ' open' : '') . '><summary class="btnish primary">Add an admin</summary><form method="post" class="tform">' . $csrf .
            '<div class="grid3"><label>Name<input name="name" placeholder="Taylor" maxlength="40"></label><label>Username<input name="username" required placeholder="taylor" pattern="[a-z0-9_.\-]{3,24}" autocomplete="off"></label><label><span>Email <small>(optional, can sign in with it)</small></span><input name="email" type="email" placeholder="taylor@example.com" autocomplete="off"></label></div>' .
            '<label>Role<select name="role" data-role>' . role_options(!$t ? 'owner' : 'moderator', $me) . '</select></label>' .
            '<div class="pwrap" data-preset>' . perm_grid(role_perms(!$t ? 'owner' : 'moderator'), false, $me['perms']) . '</div>' .
            '<label class="chk"><input type="checkbox" name="invite" value="1"> Email them the sign-in link and their username (never the password)</label>' .
            '<div class="bar"><button name="do" value="team-add">Add admin</button><span class="muted">They get a temporary password, shown to you once, and choose their own at first sign-in.</span></div></form></details>';
    }
    // what each role can do
    echo '<h2>Roles</h2><p class="muted">Pick a role for a quick setup, or Custom to set each area. View lets someone see a page; Edit lets them change things there. Nobody can give access they don\'t have, and only owners manage owners.</p><div class="tw"><table class="matrix"><thead><tr><th></th>';
    foreach (ROLES as $k => $r) if ($k !== 'custom') echo '<th><span class="role r-' . $k . '">' . h($r[0]) . '</span></th>';
    echo '</tr></thead><tbody>';
    foreach (AREAS as $a => $info) {
        echo '<tr><td><b>' . h($info[0]) . '</b></td>';
        foreach (ROLES as $k => $r) { if ($k === 'custom') continue; $l = role_perms($k)[$a]; echo '<td class="lv l' . $l . '">' . ($l === 2 ? 'Edit' : ($l === 1 ? 'View' : '&ndash;')) . '</td>'; }
        echo '</tr>';
    }
    echo '<tr class="rdesc"><td></td>'; foreach (ROLES as $k => $r) if ($k !== 'custom') echo '<td><small>' . h($r[1]) . '</small></td>'; echo '</tr>';
    echo '</tbody></table></div>';
    // activity
    $log = load(AUDIT); $who = (string)($_GET['who'] ?? '');
    if ($who !== '') $log = array_values(array_filter($log, fn($r) => $r['n'] === $who));
    $names = array_values(array_unique(array_column(load(AUDIT), 'n')));
    echo '<h2>Activity <small>sign-ins and every change</small></h2><form method="get" class="bar"><input type="hidden" name="tab" value="team"><select name="who" onchange="this.form.submit()"><option value="">Everyone</option>';
    foreach ($names as $n) if ($n !== '') echo '<option' . ($n === $who ? ' selected' : '') . '>' . h($n) . '</option>';
    echo '</select></form><div class="tw"><table><thead><tr><th>When</th><th>Who</th><th>What</th><th>Details</th></tr></thead><tbody>';
    foreach (array_slice($log, 0, 200) as $r) {
        $det = []; foreach ($r['i'] as $k => $v) { if ($v === '' || $v === null || $v === []) continue; $v = is_scalar($v) ? (string)$v : json_encode($v); $det[] = $k === 'note' ? h($v) : h($k) . ': ' . h($v); }
        //MC 2026-10-09 nw keeps "02:04 UTC" on one line on phones
        echo '<tr><td class="small nw">' . h(gmdate('M j H:i', $r['t'])) . ' UTC<small>' . h(ago($r['t'])) . '</small></td><td><b>' . h($r['n'] ?: '?') . '</b></td><td>' . h(action_label($r['do'])) . '</td><td class="muted small">' . implode(' &middot; ', $det) . '</td></tr>';
    }
    if (!$log) echo '<tr><td colspan="4" class="muted">Nothing yet.</td></tr>';
    echo '</tbody></table></div>';
}
function action_label($do) {
    $L = ['login' => 'Signed in', 'login-failed' => 'Wrong password', 'logout' => 'Signed out', 'team-add' => 'Added an admin', 'team-edit' => 'Changed an admin', 'team-reset' => 'New temporary password', 'team-remove' => 'Removed an admin',
        'account-save' => 'Updated own account', 'rename' => 'Renamed a player', 'clear-motto' => 'Cleared a player\'s motto', 'remove' => 'Removed a player', 'merge' => 'Combined players', 'blocked-words' => 'Changed blocked words', 'x-settings' => 'Changed X posting', 'hype-tags' => 'Changed the hype post tag list', 'rel-posted' => 'Marked a release post as posted on X',
        'idea-save' => 'Updated a suggestion', 'idea-translate' => 'Translated a suggestion', 'idea-publish' => 'Published or hid a suggestion', 'idea-delete' => 'Deleted a suggestion', 'idea-email' => 'Changed the ideas email', 'mail-save' => 'Changed the team email settings', 'mail-test' => 'Sent a test email', 'mail-report' => 'Sent a report email', 'order-check' => 'Checked an order on Solana',
        'bounty-save' => 'Changed the 15 Club bounty', 'bounty-paid' => 'Marked the 15 Club bounty paid', 'bounty-void' => 'Took back a 15 Club bounty win', 'trophy-save' => 'Changed the trophy minting settings', 'trophy-run' => 'Sent waiting trophies', 'trophy-retry' => 'Queued failed trophies again', 'trophy-backfill' => 'Recorded trophies for past wins', 'trophy-give' => 'Gave a trophy by hand', 'ew-save' => 'Changed wallet sign-in', 'order-paid' => 'Delivered an order by hand', 'payhelp-close' => 'Closed a payment help request', 'grant' => 'Gave Koban or an item', 'xt-settings' => 'Changed Daily X tasks', 'ref-settings' => 'Changed invite rewards', 'xt-revoke' => 'Took back an X task', 'xt-free' => 'Freed an X handle', 'eco-settings' => 'Changed prize settings', 'league-credit' => 'Counted an early Daily run in the League', 'league-skip' => 'Marked an early Daily run as not needed', 'event-add' => 'Added an event', 'event-del' => 'Removed an event', 'treasury-add' => 'Recorded a treasury move', 'burn-scan' => 'Scanned a wallet for past burns', 'burn-log' => 'Logged burns found on chain', 'burn-clear' => 'Cleared a burn scan', 'house-settings' => 'Changed House settings', 'house-del' => 'Closed a House', 'treasury-del' => 'Removed a treasury move',
        'payout-prepare' => 'Priced a payout', 'payout-skip' => 'Left out or included a winner', 'payout-sent' => 'Sent a payout', 'payout-approve' => 'Approved a payout', 'close-room' => 'Closed a live room', 'tg-save' => 'Changed Telegram', 'tg-find' => 'Looked for Telegram chats',
        'tg-pick' => 'Picked the Telegram chat', 'tg-app' => 'Turned on the Telegram Play button', 'tg-release' => 'Posted release notes to Telegram', 'tg-burn' => 'Sent and pinned the burn card', 'tg-msg' => 'Changed a Telegram post', 'shop-prices' => 'Changed Koban prices in the shop', 'chat-settings' => 'Turned live chat on or off', 'boss-settings' => 'Changed the Shogun boss settings', 'exp-settings' => 'Changed the Shadow Expeditions settings', 'seeker-settings' => 'Changed the Seeker bonus', 'tg-link' => 'Changed an older Telegram post', 'lg-week' => 'Corrected a final League week', 'fp-settings' => 'Changed whether private rooms count for the League', 'fp-strike' => 'Struck a match from the League', 'tourney-add' => 'Scheduled a tournament', 'tourney-start' => 'Started a tournament early', 'tourney-cancel' => 'Called off a tournament', 'tourney-del' => 'Removed a tournament', 'art-upload' => 'Uploaded card art', 'mask-upload' => 'Replaced a bot mask', 'mask-revert' => 'Put a stock bot mask back', 'art-focus' => 'Moved card art focus', 'art-publish' => 'Published card art', 'art-discard' => 'Threw away card art', 'art-revert' => 'Put back original card art', 'art-restore' => 'Rebuilt missing card art images', 'art-backup' => 'Backed up card art', 'shop-reroll' => 'Refreshed today\'s shop', 'drop-add' => 'Scheduled a limited drop', 'drop-off' => 'Stopped a limited drop', 'drop-del' => 'Removed a limited drop', 'cardset-public' => 'Revealed or hid the next card set', 'clear-log' => 'Cleared a log', 'restore' => 'Restored a backup', 'deploy-zip' => 'Deployed a site update', 'deploy-prev' => 'Put back an earlier release', 'deploy-done' => 'Finished a site deploy', 'hash-tool' => 'Made a setup key line', 'denied' => 'Tried something without access', 'tfa-on' => 'Turned on two-step sign-in', 'tfa-off' => 'Turned off two-step sign-in', 'tfa-codes' => 'Made new recovery codes', 'team-2fa' => 'Reset someone\'s two-step sign-in'];
    return $L[$do] ?? $do;
}
function page_account() {
    $me = me();
    if (!empty($me['key'])) { echo '<p class="muted">You\'re signed in with the setup key, which has no account of its own. Add yourself in Team and sign in with that.</p>'; return; }
    $u = team()[$me['id']];
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    if (!empty($u['must_change'])) echo '<div class="tg-status"><b>Pick your own password to finish signing in.</b><span>Use the temporary password you were given as the current password. At least 12 characters; a few random words work well.</span></div>';
    echo '<form method="post" class="tform acct">' . $csrf . '<h2>Your details</h2><div class="grid2"><label>Name<input name="name" value="' . h($u['name']) . '"></label><label><span>Email <small>(you can sign in with it)</small></span><input name="email" type="email" value="' . h($u['email']) . '"></label></div>' .
        '<p class="muted">Username: <b>' . h($u['username']) . '</b> &middot; Role: <b>' . h(ROLES[$u['role']][0]) . '</b>' . (!empty($u['prev']) ? ' &middot; Previous sign-in ' . h(ago($u['prev'])) : '') . '</p>' .
        '<h2>Password</h2><div class="grid3"><label>Current password<input name="current" type="password" autocomplete="current-password"' . (!empty($u['must_change']) ? ' required' : '') . '></label><label>New password<input name="new" type="password" autocomplete="new-password" minlength="12"' . (!empty($u['must_change']) ? ' required' : '') . '></label><label>New password again<input name="new2" type="password" autocomplete="new-password" minlength="12"' . (!empty($u['must_change']) ? ' required' : '') . '></label></div>' .
        '<p class="muted">Changing your password signs you out on every other device.</p><div class="bar"><button name="do" value="account-save">Save</button></div></form>';
    echo tfa_section($u);
    echo '<h2>Your access</h2>' . perm_grid($me['perms'], true);
}
