<?php
// Tournaments in the admin: schedule one (or a weekly series), watch the bracket, start early or call one off.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)

function tourney_actions($do) {
    if ($do === 'tourney-add') {
        $name = trim(preg_replace('/[^A-Za-z0-9 \-!\'&#.]/', '', (string)($_POST['name'] ?? '')));
        $start = strtotime((string)($_POST['start'] ?? '') . ' UTC');
        if ($name === '' || !$start) go('tourneys', 'Give the tournament a name and a start time.');
        if ($start < time() + 300) go('tourneys', 'Pick a start at least 5 minutes from now, so players can sign up and check in.');
        //MC 2026-10-23 the place prizes are Koban or $SHY (picked on the form); $SHY prizes can run far bigger
        $pz = ($_POST['pz'] ?? '') === 'shy' ? 'shy' : 'koban';
        $prizes = array_map(fn($k) => max(0, min($pz === 'shy' ? 100000000 : 100000, (int)($_POST['p' . $k] ?? 0))), [1, 2, 3, 4]);
        //MC 2026-10-23 player counts come from the balanced sizes (tables of 4, one moves on); an old custom number still works
        $max = (int)($_POST['max'] ?? 16); if ($max < 4) $max = 4; if ($max > 128) $max = 128;
        $gate = holder_key_new((string)($_POST['gate'] ?? ''));   //MC 2026-10-10 an old tier key (from a stale form) becomes its rank
        if (!isset(TOURNEY_GATES[$gate])) $gate = '';
        $partner = null;
        if ($gate === 'partner') {
            $pn = trim(mb_substr((string)($_POST['pt_name'] ?? ''), 0, 40)); $pm = trim((string)($_POST['pt_mint'] ?? ''));
            $pu = trim((string)($_POST['pt_url'] ?? '')); $pl = trim((string)($_POST['pt_logo'] ?? '')); $ps = strtoupper(trim(preg_replace('/[^A-Za-z0-9$]/', '', (string)($_POST['pt_sym'] ?? ''))));
            if ($pn === '' || !preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $pm)) go('tourneys', 'A joint event needs the partner\'s name and their token\'s mint address.');
            if ($pu !== '' && !preg_match('#^https://[^\s"<>]+$#', $pu)) go('tourneys', 'The partner\'s website should start with https://');
            if ($pl !== '' && !preg_match('#^https://[^\s"<>]+$#', $pl)) go('tourneys', 'The partner\'s logo should be an https:// image link.');
            $partner = ['name' => $pn, 'mint' => $pm, 'url' => $pu, 'logo' => $pl, 'sym' => $ps !== '' ? (strpos($ps, '$') === 0 ? $ps : '$' . $ps) : $pn, 'min' => max(0, (float)($_POST['pt_min'] ?? 0)), 'code' => tp_code()];
        }
        //MC 2026-10-13 paid events: the entry fee in $SHY and the pool share. A fee needs the shop open to sell tickets.
        //MC 2026-10-23 or in Koban, taken from the player's balance at sign-up: no shop, no wallet needed
        $fc = ($_POST['fc'] ?? '') === 'koban' ? 'koban' : 'shy';
        $fee = $fc === 'koban' ? max(0, min(100000, (int)($_POST['fee'] ?? 0))) : max(0, round((float)($_POST['fee'] ?? 0), 2));
        if ($fee > 0 && $fc === 'shy' && !eco_settings()['shop_open']) go('tourneys', 'The shop is closed, so entry tickets can\'t be sold. Open the shop first, take the entry in Koban, or make it free.');
        $t = tourney_new(['name' => mb_substr($name, 0, 48), 'start' => $start, 'max' => $max, 'prizes' => $prizes, 'pz' => $pz,
            'note' => mb_substr(trim((string)($_POST['note'] ?? '')), 0, 200), 'repeat' => !empty($_POST['repeat']), 'by' => me()['username'], 'gate' => $gate, 'partner' => $partner,
            'fee' => $fee, 'fc' => $fc, 'pool_pct' => (int)($_POST['pool_pct'] ?? 60)]);
        tourney_lock(function () use ($t) { $db = tourney_db(); $db['list'][$t['id']] = $t; save(TOURNEY, $db); });
        if (!empty($_POST['announce'])) tourney_announce($t);   //MC 2026-10-23 with the event's own card as the picture
        go('tourneys', 'Scheduled ' . $t['name'] . '. Players can sign up on the Play page now. Its share card is ready under the event.');
    }
    $id = (string)($_POST['id'] ?? '');
    //MC 2026-10-23 post the event to our Telegram chat again, with its card (the schedule form's Announce does the same once)
    //MC 2026-10-23 a push about the event, to the players who turned notifications on: the ones not signed up yet (an
    //   invite, which counts toward their two broadcast knocks a day), the ones signed up (always delivered), or both.
    //   One push per event every 2 hours, so a double tap never knocks everyone twice.
    if ($do === 'tourney-push') {
        $to = in_array($_POST['to'] ?? '', ['new', 'in', 'all'], true) ? $_POST['to'] : 'new';
        $msg = trim(preg_replace('/\s+/u', ' ', mb_substr((string)($_POST['msg'] ?? ''), 0, 140)));
        $res = tourney_lock(function () use ($id, $to, $msg) {
            $db = tourney_db(); $t = $db['list'][$id] ?? null;
            if (!$t || $t['status'] !== 'signup') return 'Only an event still taking sign-ups can be pushed.';
            if (time() - (int)($t['told']['push'] ?? 0) < 7200) return 'A push for this event went out ' . max(1, (int)round((time() - (int)$t['told']['push']) / 60)) . ' minutes ago. Give it 2 hours between pushes so nobody gets knocked twice.';
            $t['told']['push'] = time(); $db['list'][$id] = $t; save(TOURNEY, $db);
            return ['t' => $t];
        });
        if (is_string($res)) go('tourneys', $res);
        [$sent, $of, $capped] = tourney_push($res['t'], $to, $msg);
        if (!$of) { tourney_lock(function () use ($id) { $db = tourney_db(); unset($db['list'][$id]['told']['push']); save(TOURNEY, $db); }); go('tourneys', 'Nobody in that group has notifications turned on yet, so nothing was sent.'); }
        go('tourneys', 'Pushed ' . $res['t']['name'] . ' to ' . $sent . ' ' . ($sent === 1 ? 'player' : 'players') . ($capped ? ' (' . $capped . ' more already had their 2 notifications today, so it skipped them)' : '') . '.');
    }
    if ($do === 'tourney-post') {
        $t = tourney_db()['list'][$id] ?? null;
        if (!$t || $t['status'] !== 'signup') go('tourneys', 'Only an event still taking sign-ups can be posted.');
        tourney_announce($t, 'tpost:' . $id . ':' . time());
        go('tourneys', 'Posted ' . $t['name'] . ' to the Telegram chat with its card.');
    }
    //MC 2026-10-23 move an event that hasn't started: new start time, then the full post with the new card goes to the
    //   chat (pinned in place of the old one) and every player signed up gets a DM if they take tournament notes
    if ($do === 'tourney-time') {
        $ns = strtotime((string)($_POST['start'] ?? '') . ' UTC');
        if (!$ns || $ns < time() + 300) go('tourneys', 'Pick a new start at least 5 minutes from now.');
        $res = tourney_lock(function () use ($id, $ns) {
            $db = tourney_db(); $t = $db['list'][$id] ?? null;
            if (!$t || $t['status'] !== 'signup') return 'Only an event that hasn\'t started can be moved.';
            if ($ns === (int)$t['start']) return 'That\'s the time it already has.';
            $was = (int)$t['start']; $t['start'] = $ns;
            foreach (['hour', 'checkin', 'pday', 'r3h', 'r1h', 'r15'] as $k) unset($t['told'][$k]);   //MC 2026-10-23 reminders run again for the new time
            // check-ins made for the old time don't carry to a later one: everyone checks in again in the new last 30 minutes
            if ($ns > $was) foreach ($t['players'] as &$p) if ($ns - T_CHECKIN > time()) $p['in'] = 0;
            unset($p);
            $db['list'][$id] = $t; save(TOURNEY, $db);
            return ['t' => $t, 'was' => $was];
        });
        if (is_string($res)) go('tourneys', $res);
        tourney_moved($res['t'], $res['was']);
        go('tourneys', 'Moved ' . $res['t']['name'] . ' to ' . gmdate('D, M j, H:i', $res['t']['start']) . ' UTC and posted the new time to Telegram with its card.');
    }
    if ($do === 'tourney-start') {
        $msg = tourney_lock(function () use ($id) {
            $db = tourney_db(); $t = $db['list'][$id] ?? null;
            if (!$t || $t['status'] !== 'signup') return 'Only a tournament that hasn\'t started can be started.';
            // everyone signed up counts as checked in when it's started by hand
            foreach ($t['players'] as &$p) if (empty($p['in'])) $p['in'] = time();
            unset($p);
            $t['start'] = time();
            tourney_start($t);
            $db['list'][$id] = $t; save(TOURNEY, $db);
            return $t['status'] === 'running' ? 'Started. Round 1 tables are open.' : 'Not started: ' . $t['why'];
        });
        go('tourneys', $msg);
    }
    if ($do === 'tourney-cancel') {
        $paidOff = tourney_lock(function () use ($id) {
            $db = tourney_db(); $t = &$db['list'][$id];
            if (!$t || !in_array($t['status'], ['signup', 'running'], true)) return false;
            $t['status'] = 'cancelled'; $t['ended'] = time(); $t['why'] = 'Called off by the team.'; $t['repeat'] = false;
            //MC 2026-10-13 a paid event called off refunds every entry: the list lands in Rewards for the payout button
            //MC 2026-10-23 Koban entries go straight back, and the roster is saved after so they can't come back twice
            tourney_refunds($t);
            tourney_unpin($t);
            $tt = $t; unset($t); save(TOURNEY, $db);
            $kob = tourney_fc($tt) === 'koban';
            if (!empty($tt['fee'])) tg_post('tourney', '🏯 <b>' . tg_h($tt['name']) . '</b> is off. ' . ($kob ? 'Every Koban entry is back in its account.' : 'Every entry fee is refunded in $SHY to the wallet that paid.'), 'tcancel:' . $id);
            return empty($tt['fee']) ? '' : ($kob ? 'k' : 's');
        });
        go('tourneys', $paidOff === 's' ? 'Called off. The entry refunds are on the Rewards tab: Pay everything owed sends them.' : ($paidOff === 'k' ? 'Called off. Every Koban entry went back into its account.' : 'Called off. No prizes were paid.'));
    }
    if ($do === 'tourney-del') {
        tourney_lock(function () use ($id) { $db = tourney_db(); if (isset($db['list'][$id]) && $db['list'][$id]['status'] !== 'running') { unset($db['list'][$id]); save(TOURNEY, $db); } });
        go('tourneys', 'Removed.');
    }
}

function page_tourneys() {
    tourney_tick(true);
    //MC 2026-10-09 joint events made before partner groups existed get their group code here
    tourney_lock(function () { $db = tourney_db(); $ch = false; foreach ($db['list'] as &$t) if (($t['gate'] ?? '') === 'partner' && empty($t['partner']['code'])) { $t['partner']['code'] = tp_code(); $ch = true; } unset($t); if ($ch) save(TOURNEY, $db); });
    $db = tourney_db(); $edit = can('tourney', 2); $bot = (string)(tg_cfg()['bot'] ?? '');
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    $list = $db['list']; uasort($list, fn($a, $b) => $b['start'] <=> $a['start']);
    $ST = ['signup' => ['warn', 'Sign-ups open'], 'running' => ['on', 'Running'], 'done' => ['on', 'Finished'], 'cancelled' => ['off', 'Called off']];
    echo '<p class="muted">A tournament is a knockout of live matches. Players sign up on the Play page and check in during the last 30 minutes. At the start they\'re seated at tables of up to 4, with bots in empty seats. The best real player at each table moves on until 4 or fewer are left for the final table, which decides 1st to 4th. Prizes are Koban (in their account the moment it ends) or $SHY (sent from the Rewards tab), picked when you schedule it, and the winner gets the Cup Champion title. Every event gets its own share card and link for X and Telegram.</p>';
    if ($edit) {
        $next = strtotime('next saturday 20:00 UTC');
        echo '<details class="addbox"' . (!$list ? ' open' : '') . '><summary class="btnish primary">Schedule a tournament</summary><form method="post" class="tform">' . $csrf .
            '<div class="grid3"><label>Name<input name="name" value="Weekly Shilluminati Cup" maxlength="48" required></label><label>Starts (UTC)<input name="start" type="datetime-local" value="' . gmdate('Y-m-d\TH:i', $next) . '" required></label><label>Players<select name="max">' . implode('', array_map(fn($n, $l) => '<option value="' . $n . '"' . ($n === 16 ? ' selected' : '') . '>' . $n . ' players: ' . h($l) . '</option>', array_keys(TOURNEY_SIZES), TOURNEY_SIZES)) . '</select><small class="muted">Balanced brackets: every table seats 4 and one moves on (the top two when two tables are left), so these sizes fill every round. Fewer sign-ups still play, with bots in the empty seats.</small></label></div>' .
            '<div class="grid2"><label>Prizes paid in<select name="pz" data-pz><option value="koban">Koban, into their account the moment it ends</option><option value="shy">$SHY, sent from the Rewards tab to their wallet</option></select></label></div>' .
            '<div class="grid4"><label><span data-pz-l>1st place (Koban)</span><input name="p1" type="number" min="0" value="2000"></label><label>2nd<input name="p2" type="number" min="0" value="1000"></label><label>3rd<input name="p3" type="number" min="0" value="500"></label><label>4th<input name="p4" type="number" min="0" value="250"></label></div>' .
            '<p class="muted small" data-pz-note hidden>$SHY prizes go on the Rewards payout list when the final ends, added to any pool share, and the Pay everything owed button sends them. A winner needs a wallet connected on their profile (or the one that paid their entry) to be paid; until then their row waits.</p>' .
            '<div class="grid3"><label>Entry paid in<select name="fc" data-fc><option value="shy">$SHY, bought in the shop checkout</option><option value="koban">Koban, from their balance at sign-up</option></select></label><label><span data-fc-l>Entry fee ($SHY, 0 = free)</span><input name="fee" type="number" step="any" min="0" value="0"></label><label>Prize pool share (% of entries)<input name="pool_pct" type="number" min="0" max="100" value="60"></label></div>' .
            '<p class="muted small" data-fc-note hidden>A Koban entry comes out of the player\'s balance when they sign up, and they can\'t sign up without enough. Backing out before the start, or the event being called off, puts it straight back. The pool share pays 1st to 4th in Koban (50 / 25 / 15 / 10) the moment the final ends, on top of any Koban prize; the rest of the entries leave the game.</p>' .
            '<p class="muted small" data-fc-shy>A paid event sells its entry through the shop checkout, in $SHY only, and seats ticket holders only. The usual burn share of every $SHY payment burns in the buyer\'s own transaction; the pool share of collected fees pays 1st to 4th (50 / 25 / 15 / 10) from the Rewards tab, and the rest stays in the marketing wallet. If the event is called off, every entry is refunded in full from the Rewards tab.</p>' .
            '<label>Extra prize note <small class="muted">(optional, shown to players, for example a $SHY prize you send by hand)</small><input name="note" maxlength="200" placeholder="The winner also gets $25 in $SHY."></label>' .
            '<div class="grid2"><label>Who can sign up<select name="gate" data-gate>' . implode('', array_map(fn($k, $v) => '<option value="' . h($k) . '">' . h($k === 'partner' ? 'Joint event: $SHY holders and a partner community' : $v) . '</option>', array_keys(TOURNEY_GATES), TOURNEY_GATES)) . '</select><small class="muted">Holder events check the wallet a player connected on their profile.</small></label></div>' .
            '<fieldset class="pt-box" data-pt hidden><legend>Partner community</legend><div class="grid3"><label>Name<input name="pt_name" maxlength="40" placeholder="Bonk"></label><label>Token ticker<input name="pt_sym" maxlength="12" placeholder="$BONK"></label><label>Hold at least<input name="pt_min" type="number" step="any" min="0" value="0"></label></div>' .
            '<label>Token mint address<input name="pt_mint" placeholder="DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" spellcheck="false"></label><div class="grid2"><label>Website<input name="pt_url" placeholder="https://"></label><label>Logo image link<input name="pt_logo" placeholder="https://…png"></label></div>' .
            '<p class="muted small">The partner\'s holders sign up with the wallet they connect on their profile. Their logo and name show on the tournament card, and $SHY holders can always join too.</p></fieldset>' .
            '<label class="chk"><input type="checkbox" name="repeat" value="1" checked> Repeat every week at the same time</label>' .
            '<label class="chk"><input type="checkbox" name="announce" value="1" checked> Announce it in the Telegram chat</label>' .
            '<div class="bar"><button name="do" value="tourney-add">Schedule</button></div></form></details>';
    }
    if (!$list) { echo '<p class="muted">Nothing scheduled yet.</p>'; return; }
    foreach ($list as $id => $t) {
        $st = $ST[$t['status']] ?? ['', $t['status']];
        $in = count(array_filter($t['players'], fn($p) => !empty($p['in'])));
        echo '<section class="tcard"><div class="tc-head"><div><h2>' . h($t['name']) . ' <span class="pill ' . $st[0] . '">' . h($st[1]) . '</span>' . (!empty($t['repeat']) ? ' <span class="pill">Weekly</span>' : '') . (!empty($t['gate']) ? ' <span class="pill warn">' . h(($t['gate'] === 'partner' ? 'Joint with ' . ($t['partner']['name'] ?? '') : TOURNEY_GATES[tourney_gate($t)] ?? '')) . '</span>' : '') . '</h2>' .   //MC 2026-10-10 old tier gates show as their rank
            '<p class="muted small">' . h(gmdate('D, M j, H:i', $t['start'])) . ' UTC &middot; ' . count($t['players']) . ' signed up, ' . $in . ' checked in &middot; ' . (int)$t['max'] . ' seats &middot; prizes ' . h(implode(' / ', array_map('number_format', $t['prizes']))) . (tourney_pz($t) === 'shy' ? ' $SHY' : ' Koban') .
            (!empty($t['fee']) ? ' &middot; entry ' . h(tourney_fee_label($t)) . ', ' . ($pl = tourney_pool($t))['n'] . ' paid, pool ' . number_format($pl['amt']) . ' ' . h(tourney_cur($pl['cur'])) . ' (' . (int)$t['pool_pct'] . '%)' : '') .   //MC 2026-10-13 paid events
            ($t['note'] !== '' ? ' &middot; ' . h($t['note']) : '') . (!empty($t['why']) ? ' &middot; ' . h($t['why']) : '') . '</p></div>';
        if ($edit) {
            echo '<div class="bar">';
            if ($t['status'] === 'signup') echo '<form method="post" class="t-move">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><input name="start" type="datetime-local" value="' . gmdate('Y-m-d\TH:i', $t['start']) . '" required aria-label="New start (UTC)"><button name="do" value="tourney-time" class="ghost" data-confirm="Move ' . h($t['name']) . ' to the new time? It posts the new time to Telegram with its card.">Change time (UTC)</button></form>';   //MC 2026-10-23
            if ($t['status'] === 'signup') echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-start" class="ghost" data-confirm="Start ' . h($t['name']) . ' now? Everyone signed up plays, checked in or not.">Start now</button></form>';
            if (in_array($t['status'], ['signup', 'running'], true)) echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-cancel" class="ghost danger" data-confirm="Call off ' . h($t['name']) . '? Nobody gets prizes.">Call off</button></form>';
            elseif ($t['status'] !== 'running') echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-del" class="ghost" data-confirm="Delete this tournament from the list?">Remove</button></form>';
            echo '</div>';
        }
        echo '</div>';
        //MC 2026-10-23 the share kit while it takes sign-ups: the event's own card, its link, Share on X and Telegram with the
        //   words ready, Post to our chat, and the card to download for anywhere else
        if (in_array($t['status'], ['signup', 'running'], true)) {
            $lnk = tourney_link($t); $card = '/api/share.php?tn=' . $t['id'] . '&h=' . tourney_card_hash($t); $pitch = tourney_pitch($t);
            echo '<div class="t-share"><a href="' . h($card) . '" target="_blank" rel="noopener"><img src="' . h($card) . '" alt="' . h($t['name']) . ' share card" width="300" height="158" loading="lazy"></a><div>'
                . '<p class="small"><b>Share it</b> <code style="user-select:all">' . h($lnk) . '</code></p><p class="muted small">' . h($pitch) . '</p><div class="bar">'
                . '<a class="btn" href="https://x.com/intent/tweet?text=' . h(rawurlencode($pitch . "\n" . $lnk)) . '" target="_blank" rel="noopener">Share on X</a>'
                . '<a class="btn" href="https://t.me/share/url?url=' . h(rawurlencode($lnk)) . '&amp;text=' . h(rawurlencode($pitch)) . '" target="_blank" rel="noopener">Share on Telegram</a>'
                . ($edit && $t['status'] === 'signup' ? '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-post" class="ghost" data-confirm="Post ' . h($t['name']) . ' to the Telegram chat with its card?">Post to our Telegram chat</button></form>' : '')
                . '<a class="btn ghost" href="' . h($card . '&dl=1') . '">Download the card</a></div>'
                . ($edit && $t['status'] === 'signup' ? '<form method="post" class="t-push">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><b class="small">Send a push notification</b>'
                    . '<select name="to"><option value="new">To players not signed up yet (' . (int)($pc = tourney_push_counts($t))['new'] . ')</option><option value="in">To players signed up (' . (int)$pc['in'] . ')</option><option value="all">To everyone with notifications on (' . (int)$pc['all'] . ')</option></select>'
                    . '<input name="msg" maxlength="140" placeholder="Optional message, or leave it blank for the prize and the start time">'
                    . '<button name="do" value="tourney-push" class="ghost" data-confirm="Send a push notification about ' . h($t['name']) . ' now?">Send push</button>'
                    . '<small class="muted">Goes to the app and browsers of players who turned notifications on. Tapping it opens the sign-up. One push per event every 2 hours.' . (!empty($t['told']['push']) ? ' Last sent ' . h(gmdate('H:i', (int)$t['told']['push'])) . ' UTC.' : '') . '</small></form>' : '')
                . '<p class="muted small">The link shows this card as its preview on X and Telegram, and opens the sign-up on the Play page. The card redraws itself when the prizes or the pool change.</p></div></div>';
        }
        //MC 2026-10-09 the partner's Telegram group: linked, or the two steps their admin needs
        if (($t['gate'] ?? '') === 'partner' && in_array($t['status'], ['signup', 'running'], true)) {
            $pc = (string)($t['partner']['code'] ?? '');
            echo !empty($t['partner']['chat'])
                ? '<p class="small"><i class="ok">Partner group linked:</i> ' . h($t['partner']['chat_title'] ?? 'their group') . '. It gets the reminders, the start and the winners by itself.</p>'
                : '<p class="small"><b>Partner group:</b> not linked yet. Send their admin this: <i>Add ' . ($bot !== '' ? '@' . h($bot) : 'our bot') . ' to your Telegram group, then type</i> <code style="user-select:all">/partner ' . h($pc) . '</code> <i>in the group.</i> The announcement goes out there straight away.</p>';
        }
        //MC 2026-10-13 a paid event's $SHY list (pool prizes, or refunds when called off): who, how much, sent or not
        if (((!empty($t['fee']) && tourney_fc($t) === 'shy') || tourney_pz($t) === 'shy') && in_array($t['status'], ['done', 'cancelled'], true)) {
            $tx = load(REWARDS)['tourneys'][$t['id']] ?? null;
            if ($tx) {
                $open = count(array_filter($tx['list'], fn($w) => empty($w['sig']) && empty($w['skip'])));
                echo '<p class="small"><b>' . h($tx['label']) . ':</b> ' . implode(' &middot; ', array_map(fn($w) => h($w['name']) . ' ' . number_format($w['shy']) . ' $SHY' . (!empty($w['sig']) ? ' <i class="ok">paid</i>' : ''), $tx['list'])) .
                    ($open ? ' &middot; <a href="?tab=rewards">Pay everything owed on Rewards sends ' . ($open === count($tx['list']) ? 'them' : 'the rest') . '</a>' : ' &middot; <i class="ok">All sent</i>') . '</p>';
            } elseif ($t['status'] === 'cancelled') echo '<p class="small muted">No entries were sold, so there is nothing to refund.</p>';
        }
        if ($t['status'] === 'done' && $t['places']) {
            echo '<ol class="tc-places">';
            foreach (array_slice($t['places'], 0, 4) as $i => $pid) echo '<li><b>' . h($t['players'][$pid]['name'] ?? '?') . '</b>' . (tourney_prize_label($t, $i) !== '' ? '<small>' . h(tourney_prize_label($t, $i)) . '</small>' : '') . '</li>';
            echo '</ol>';
        }
        if ($t['rounds']) {
            echo '<div class="tc-rounds">';
            foreach ($t['rounds'] as $ri => $tables) {
                echo '<div class="tc-round"><b>' . (count($tables) === 1 && $ri > 0 ? 'Final table' : 'Round ' . ($ri + 1)) . '</b>';
                foreach ($tables as $tb) {
                    echo '<div class="tc-table' . ($tb['done'] ? ' done' : '') . '"><small>' . h($tb['code']) . ($tb['done'] ? '' : ' &middot; playing') . '</small>';
                    foreach ($tb['seats'] as $pid) echo '<span' . (in_array($pid, $tb['adv'] ?? [$tb['win']], true) ? ' class="win"' : '') . '>' . h($t['players'][$pid]['name'] ?? '?') . '</span>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
        } elseif ($t['players'] && $t['status'] === 'signup') {
            echo '<p class="small">' . implode(', ', array_map(fn($p) => h($p['name']) . (!empty($p['in']) ? ' &#10003;' : ''), $t['players'])) . '</p>';
        }
        echo '</section>';
    }
}
