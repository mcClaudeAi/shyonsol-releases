// The Deck Forge on the Play page (api/decks.php): build 40-card decks from the full pool and bring them to forged
// matches, where every seat's deck is shuffled into one Chaos pool and your opening hand comes from your own cards.
// The card on the menu shows your decks and the ways to play them; the builder opens over the page.
//MC 2026-10-18 first version
(function () {
  "use strict";
  var box = document.getElementById("g-forge");
  if (!box) return;
  var API = "/api/decks.php";
  var S = null, cur = null, curId = "", filter = "all", busy = false;
  var KINDN = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", trick: "Trick", passive: "Reaction" };
  function ls(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function G() { return window.ShyGame || null; }
  function toast(t) { var el = document.getElementById("toast"); if (!el) return; var was = el.textContent; el.textContent = t; el.classList.add("show"); setTimeout(function () { el.classList.remove("show"); el.textContent = was; }, 2600); }
  function post(url, body) {
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: ls("shy-lb-pid"), key: ls("shy-lb-key") }, body)) })
      .then(function (r) { return r.json(); }).catch(function () { return { ok: false, error: "Can't reach the server. Check your connection." }; });
  }
  function signedIn() { return /^[a-f0-9]{16}$/.test(ls("shy-lb-pid")); }
  function load() { if (!signedIn()) { box.hidden = false; drawCard(); return; } post(API, { a: "view" }).then(function (j) { if (j && j.ok) { S = j; box.hidden = false; drawCard(); } }); }

  // ---------------------------------------------------------------- the card on the Play menu
  function deckChips() {
    if (!S || !S.decks.length) return "";
    return '<div class="fg-decks">' + S.decks.map(function (d) {
      var on = d.id === S.active;
      return '<button class="fg-deck' + (on ? " on" : "") + '" data-fg-deck="' + esc(d.id) + '"><b data-i18n-skip>' + esc(d.name) + '</b><small>' + (on ? "In your hands" : "Tap to carry") + '</small></button>';
    }).join("") + (S.active === "" ? '<span class="fg-deck on founder"><b>Founder\'s deck</b><small>In your hands</small></span>' : '<button class="fg-deck founder" data-fg-deck=""><b>Founder\'s deck</b><small>Tap to carry</small></button>') + '</div>';
  }
  function drawCard() {
    var un = S && S.unlocked;
    box.innerHTML =
      '<div class="fg-head"><span class="fg-anvil" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M3 7h13a5 5 0 0 1-4 5h-2v3h4l1 3H6l1-3h2v-3C5.7 12 3.6 10 3 7z"/></svg></span>' +
      '<div class="fg-t"><span class="g-mode-k">Forged matches</span><b>The Deck Forge</b><small>' +
      (un ? "Your 40 cards against theirs. Every deck at the table is shuffled into one pool, and your opening hand is dealt from your own."
          : "Build your own 40-card decks and bring them to battle. Every deck at the table joins one pool; your opening hand is yours alone.") +
      '</small></div></div>' +
      (un
        ? deckChips() +
          '<div class="fg-btns"><button class="btn btn-mint btn-sm" id="fg-build">' + (S.decks.length ? "Open the Forge" : "Forge your first deck") + '</button>' +
          '<button class="btn btn-red btn-sm" data-game-start="live-quickf">Forged 1v1</button>' +
          '<button class="btn btn-line btn-sm" data-game-start="live-createf">Forged room</button>' +
          '<button class="btn btn-line btn-sm" data-game-start="live-bossf">Forged Shogun</button></div>' +
          '<p class="fg-note">Friends can join your forged rooms free; they play the Founder\'s deck.</p>'
        : '<div class="fg-btns"><button class="btn btn-red" id="fg-unlock">Unlock the Forge &middot; 20,000 Koban</button><button class="btn btn-line btn-sm" id="fg-peek">See the pool</button></div>' +
          '<p class="fg-note">One unlock, two deck slots, every card in the pool. No card is ever sold: the Forge sells craft, not power.</p>');
  }
  box.addEventListener("click", function (e) {
    var d = e.target.closest("[data-fg-deck]");
    if (d) { if (busy) return; busy = true; post(API, { a: "active", id: d.getAttribute("data-fg-deck") }).then(function (j) { busy = false; if (j.ok) { S = j; drawCard(); toast("That deck is in your hands now."); } else toast(esc(j.error || "Try again.")); }); return; }
    if (e.target.closest("#fg-build") || e.target.closest("#fg-peek")) { openForge(); return; }
    if (e.target.closest("#fg-unlock")) {
      if (!signedIn()) { toast("Play one match first, so the Forge knows whose hands these are."); return; }
      if (busy) return; busy = true;
      post("/api/shop.php", { a: "buy", item: "deckforge" }).then(function (j) {
        busy = false;
        if (j.ok || j.bought) { toast("The Forge is yours. Build your first deck."); load(); setTimeout(openForge, 400); }
        else toast(esc(j.error || "Try again.") + (j.need ? " You need " + Number(j.need).toLocaleString("en-US") + " more Koban." : ""));
      });
    }
  });

  // ---------------------------------------------------------------- the builder
  var ov = null;
  function cards() {
    var g = G(); if (!g) return [];
    return Object.keys(g.CARDS).filter(function (id) { return g.CARDS[id].n > 0; })
      .map(function (id) { return { id: id, name: g.CARDS[id].name, kind: g.CARDS[id].kind, text: g.CARDS[id].text || "" }; });
  }
  function counts() { var n = 0, gain = 0, atk = 0, g = G(); Object.keys(cur).forEach(function (id) { var k = cur[id]; n += k; var kind = g.CARDS[id].kind; if (kind === "gain") gain += k; if (kind === "attack") atk += k; }); return { n: n, gain: gain, atk: atk }; }
  function openForge() {
    if (!G()) { toast("One moment, the cards are still loading."); return; }
    if (!ov) {
      ov = document.createElement("div");
      ov.className = "fg-ov"; ov.id = "fg-ov";
      document.body.appendChild(ov);
      ov.addEventListener("click", onForgeClick);
      ov.addEventListener("input", function (e) { if (e.target.id === "fg-name" && cur) saveable(); });
    }
    var first = S && S.unlocked && S.decks.length ? S.decks[0] : null;
    pickDeck(first ? first.id : "");
    ov.hidden = false; document.documentElement.classList.add("sx-lock");
    requestAnimationFrame(function () { ov.classList.add("in"); });
  }
  function closeForge() { if (!ov) return; ov.classList.remove("in"); document.documentElement.classList.remove("sx-lock"); setTimeout(function () { ov.hidden = true; }, 200); }
  function pickDeck(id) {
    curId = id || "";
    var d = S && S.decks.filter(function (x) { return x.id === curId; })[0];
    cur = {};
    if (d) Object.keys(d.c).forEach(function (k) { cur[k] = d.c[k]; });
    else if (S) S.founder.forEach(function (k) { cur[k] = (cur[k] || 0) + 1; });
    drawForge(d ? d.name : "");
  }
  function drawForge(name) {
    var un = S && S.unlocked, c = counts(), rails = (S && S.rails) || { size: 40, copies: 2, minGain: 6, maxAttack: 16 };
    var kinds = ["all", "attack", "gain", "defense", "global", "trick", "passive"];
    ov.innerHTML =
      '<div class="fg-sheet">' +
      '<div class="fg-bar"><b>The Deck Forge</b>' +
      (un ? '<select id="fg-pick">' + (S.decks.map(function (d) { return '<option value="' + esc(d.id) + '"' + (d.id === curId ? " selected" : "") + '>' + esc(d.name) + '</option>'; }).join("")) + '<option value=""' + (curId === "" ? " selected" : "") + '>New deck (from the Founder\'s)</option></select>' : '<span class="fg-ro">The pool, read only</span>') +
      '<button class="sx-x" id="fg-x" aria-label="Close">&times;</button></div>' +
      (un ? '<div class="fg-meta"><input id="fg-name" maxlength="24" placeholder="Name this deck" value="' + esc(name || "") + '" autocomplete="off" spellcheck="false">' +
        '<div class="fg-rails"><span id="fg-r-n" class="' + (c.n === rails.size ? "ok" : "") + '">' + c.n + '/' + rails.size + ' cards</span>' +
        '<span id="fg-r-g" class="' + (c.gain >= rails.minGain ? "ok" : "") + '">' + c.gain + '/' + rails.minGain + '+ gain</span>' +
        '<span id="fg-r-a" class="' + (c.atk <= rails.maxAttack ? "ok" : "bad") + '">' + c.atk + '/' + rails.maxAttack + ' attack</span></div>' +
        '<button class="btn btn-mint btn-sm" id="fg-save" disabled>Save deck</button>' +
        (curId !== "" ? '<button class="btn btn-line btn-sm" id="fg-del">Melt it down</button>' : "") + '</div>' : "") +
      '<div class="fg-kinds">' + kinds.map(function (k) { return '<button data-fg-kind="' + k + '"' + (filter === k ? ' class="on"' : "") + '>' + (k === "all" ? "All" : KINDN[k]) + '</button>'; }).join("") + '</div>' +
      '<div class="fg-grid" id="fg-grid"></div>' +
      '<p class="fg-foot">Two copies of a card at most. Every deck at a forged table is shuffled into one pool, so a deck of pure knives arms your rivals too.</p>' +
      '</div>';
    drawGrid();
    saveable();
  }
  function drawGrid() {
    var un = S && S.unlocked;
    var list = cards().filter(function (x) { return filter === "all" || x.kind === filter; });
    document.getElementById("fg-grid").innerHTML = list.map(function (x) {
      var k = (cur && cur[x.id]) || 0;
      return '<button class="fg-card k-' + x.kind + (k ? " has n" + k : "") + '" data-fg-card="' + x.id + '"' + (un ? "" : ' disabled') + '>' +
        '<img src="assets/cards/' + x.id + '.webp" alt="" loading="lazy" width="90" height="126" onerror="this.style.visibility=\'hidden\'">' +
        '<b data-i18n-skip>' + esc(x.name) + '</b><small>' + KINDN[x.kind] + '</small>' +
        '<i class="fg-n" aria-hidden="true">' + (k ? "x" + k : "") + '</i></button>';
    }).join("");
  }
  function saveable() {
    var b = document.getElementById("fg-save"); if (!b) return;
    var c = counts(), rails = S.rails, name = (document.getElementById("fg-name") || {}).value || "";
    var ok = c.n === rails.size && c.gain >= rails.minGain && c.atk <= rails.maxAttack && name.trim().length > 0;
    b.disabled = !ok;
    var rn = document.getElementById("fg-r-n"), rg = document.getElementById("fg-r-g"), ra = document.getElementById("fg-r-a");
    if (rn) { rn.textContent = c.n + "/" + rails.size + " cards"; rn.className = c.n === rails.size ? "ok" : c.n > rails.size ? "bad" : ""; }
    if (rg) { rg.textContent = c.gain + "/" + rails.minGain + "+ gain"; rg.className = c.gain >= rails.minGain ? "ok" : ""; }
    if (ra) { ra.textContent = c.atk + "/" + rails.maxAttack + " attack"; ra.className = c.atk <= rails.maxAttack ? "ok" : "bad"; }
  }
  function onForgeClick(e) {
    if (e.target.closest("#fg-x") || e.target === ov) { closeForge(); return; }
    var kb = e.target.closest("[data-fg-kind]");
    if (kb) { filter = kb.getAttribute("data-fg-kind"); ov.querySelectorAll("[data-fg-kind]").forEach(function (x) { x.classList.toggle("on", x === kb); }); drawGrid(); return; }
    var cb = e.target.closest("[data-fg-card]");
    if (cb && S && S.unlocked) {
      var id = cb.getAttribute("data-fg-card");
      var k = ((cur[id] || 0) + 1) % ((S.rails.copies || 2) + 1);   // tap: 0 -> 1 -> 2 -> 0
      if (k) cur[id] = k; else delete cur[id];
      cb.className = cb.className.replace(/ has n\d| n\d| has/g, "") + (k ? " has n" + k : "");
      cb.querySelector(".fg-n").textContent = k ? "x" + k : "";
      saveable(); return;
    }
    if (e.target.closest("#fg-save")) {
      if (busy) return; busy = true;
      var name = (document.getElementById("fg-name").value || "").trim();
      post(API, { a: "save", id: curId, name: name, c: cur }).then(function (j) {
        busy = false;
        if (j.ok) { S = j; curId = j.saved; toast("Forged. " + esc(name) + " is ready."); drawCard(); drawForge(name); }
        else toast(esc(j.error || "Try again."));
      });
      return;
    }
    if (e.target.closest("#fg-del")) {
      if (busy || curId === "") return; busy = true;
      post(API, { a: "del", id: curId }).then(function (j) { busy = false; if (j.ok) { S = j; toast("Melted down."); drawCard(); pickDeck(S.decks.length ? S.decks[0].id : ""); } else toast(esc(j.error || "Try again.")); });
      return;
    }
    var pk = e.target.closest("#fg-pick");
    if (pk) return;   // the change event below
  }
  document.addEventListener("change", function (e) { if (e.target && e.target.id === "fg-pick" && ov && !ov.hidden) pickDeck(e.target.value); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && ov && !ov.hidden) closeForge(); });

  load();
  window.ShyForge = { reload: load };
})();
