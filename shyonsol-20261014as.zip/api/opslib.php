<?php
//MC 2026-10-11 Running the site: the health check, the daily and weekly backups, the "download all data" zip, the nightly
//   payment check, Telegram send health and the one-time League points recovery for bug #35. Used by api/cron.php,
//   api/health.php, the admin and the daily report email. Nothing here runs inside a player's request.
//   Needs common.php, and economy.php (with tg.php and maillib.php) for the payment check and the Telegram parts.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('OPS_HEALTH', DATA_DIR . '/health-cache.php');   // the last health check, so the admin Overview stays quick
define('OPS_CRON', DATA_DIR . '/cron-last.php');        // when api/cron.php last ran
define('OPS_RECON', DATA_DIR . '/recon.php');           // the last nightly payment check
define('OPS_TGH', DATA_DIR . '/tg-health.php');         // the last Telegram chat sends, and the last weekly and payout posts
define('OPS_LOCKW', DATA_DIR . '/lock-wait.dat');       // lock wait samples when APCu isn't there (see lock_wait_note)

// ---------------------------------------------------------------- backups
// What the daily and weekly backups keep: backup name => [file in shy-data, what it holds].
//   The name is the start of each copy's file name in shy-data/backups: players-2026-10-11.php (daily), players-2026-W41.php
//   (weekly). Only players has a Restore button; the rest go back by hand (see the Backups tab and backup_readme()).
const OPS_BACKUP = [
    'players' => ['players.php', 'Scores, names, weekly points, League and Season points'],
    'economy' => ['economy.php', 'Shop accounts: Koban, items, the Scroll, missions, streaks'],
    'orders' => ['orders.php', 'Shop orders and their payments'],
    'rewards' => ['rewards.php', 'Final weekly and season results, prizes and what was paid'],
    'holders' => ['holders.php', 'Connected wallets and the Shadows and $SHY they hold'],
    'keys' => ['keys.php', 'Which devices are signed in to which player'],
    'tg-links' => ['tg-links.php', 'Players linked to Telegram and their reminder choices'],
    'x-accounts' => ['x-accounts.php', 'Players linked to X'],
    'houses' => ['houses.php', 'Houses and their members'],
    'friends' => ['friends.php', 'Friends lists and requests'],
    'bounty' => ['bounty.php', '15 Club bounty settings and winners'],
    'telegram' => ['telegram.php', 'Telegram bot settings, including the bot token'],
    'card-art' => ['card-art.php', 'Which card art is published (the pictures themselves are in card-art-keep)'],
    'daily-secret' => ['daily-secret.php', 'The secret behind the Daily Challenge decks. Without it future Daily decks change'],
    'wallet-claims' => ['wallet-claims.php', 'Which wallet collected its weekly stipend and free Scroll'],
    'fairplay-settings' => ['fairplay/settings.php', 'Fair Play rules'],
    'daily' => ['daily.php', 'Daily Challenge results'],
    'weeks' => ['weeks.php', 'Past weekly boards'],
    'eco-settings' => ['eco-settings.php', 'Prize pools, shop, reward and email settings'],
    'admins' => ['admins.php', 'Admin team sign-ins and access'],
    'bans' => ['bans.php', 'Banned players, wallets and devices'],
    'grants' => ['grants.php', 'Koban and items given by hand'],
    'tourney' => ['tourney.php', 'Tournaments and brackets'],
    'cardset' => ['cardset.php', 'Season card votes'],
    'pay-help' => ['pay-help.php', 'Payment help requests'],
];
const OPS_KEEP_DAYS = 14;
const OPS_KEEP_WEEKS = 8;
function backup_dir() { return DATA_DIR . '/backups'; }
function backup_daily_re($name) { return '/^' . preg_quote($name, '/') . '-\d{4}-\d{2}-\d{2}\.php$/'; }
function backup_weekly_re($name) { return '/^' . preg_quote($name, '/') . '-\d{4}-W\d{2}\.php$/'; }
// copy a file without ever leaving half a copy under the final name
function backup_copy($src, $dst) {
    $tmp = $dst . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
    if (!@copy($src, $tmp) || @filesize($tmp) !== @filesize($src) || !@rename($tmp, $dst)) { @unlink($tmp); return false; }
    return true;
}
// Only file names that are exactly "<name>-<date>.php" are ever pruned, and only past the newest $keep of them.
//   The old prune counted every players-*.php, so the copies made before a restore (players-before-restore-...) pushed real
//   daily copies out early.
function backup_prune($name, $re, $keep) {
    $all = array_values(array_filter(array_map('basename', glob(backup_dir() . '/' . $name . '-*.php') ?: []), fn($b) => preg_match($re, $b)));
    sort($all);
    $gone = [];
    foreach (array_slice($all, 0, max(0, count($all) - $keep)) as $b) if (@unlink(backup_dir() . '/' . $b)) $gone[] = $b;
    return $gone;
}
// Today's copy of every file in OPS_BACKUP (unless it has one already) and this week's copy, then the prune. Once a day
//   from cron, right after midnight UTC. Copies are read under the site lock so they line up with each other.
//   save() in common.php still makes the daily copy of players, economy, orders and rewards on its own, so those four are
//   kept even on a host where the cron job isn't set up yet.
function backup_run() {
    $dir = backup_dir();
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return ['error' => 'no backups folder'];
    $day = gmdate('Y-m-d'); $wk = gmdate('o-\WW');
    $done = with_lock(function () use ($dir, $day, $wk) {
        $made = []; $failed = [];
        foreach (OPS_BACKUP as $name => [$file]) {
            $src = DATA_DIR . '/' . $file;
            if (!is_file($src)) continue;
            foreach ([$day, $wk] as $tag) {
                $dst = $dir . '/' . $name . '-' . $tag . '.php';
                if (is_file($dst)) continue;
                if (backup_copy($src, $dst)) $made[] = basename($dst); else $failed[] = basename($dst);
            }
        }
        return [$made, $failed];
    });
    [$made, $failed] = $done;
    $gone = [];
    // never prune after a failed copy: better too many copies than too few
    if (!$failed) foreach (array_keys(OPS_BACKUP) as $name) $gone = array_merge($gone, backup_prune($name, backup_daily_re($name), OPS_KEEP_DAYS), backup_prune($name, backup_weekly_re($name), OPS_KEEP_WEEKS));
    // the copies made just before a players restore: the newest 10 stay
    $pre = glob($dir . '/players-before-restore-*.php') ?: []; sort($pre);
    foreach (array_slice($pre, 0, max(0, count($pre) - 10)) as $f) if (@unlink($f)) $gone[] = basename($f);
    foreach (glob($dir . '/*.tmp.*') ?: [] as $f) if (@filemtime($f) < time() - 3600) @unlink($f);
    if ($failed) @file_put_contents(DATA_DIR . '/storage-errors.log', gmdate('c') . ' backup copy failed ' . implode(' ', $failed) . "\n", FILE_APPEND);
    return array_filter(['made' => count($made), 'failed' => $failed, 'pruned' => count($gone)]);
}
// what the backups folder holds, per backup name: newest daily, number of dailies and weeklies
function backup_status() {
    $out = [];
    $files = array_map('basename', glob(backup_dir() . '/*.php') ?: []);
    foreach (OPS_BACKUP as $name => [$file, $what]) {
        $d = array_values(array_filter($files, fn($b) => preg_match(backup_daily_re($name), $b)));
        $w = array_values(array_filter($files, fn($b) => preg_match(backup_weekly_re($name), $b)));
        sort($d); sort($w);
        $out[$name] = ['file' => $file, 'what' => $what, 'days' => count($d), 'weeks' => count($w), 'last' => $d ? substr(end($d), strlen($name) + 1, 10) : '', 'exists' => is_file(DATA_DIR . '/' . $file)];
    }
    return $out;
}
// newest daily copy of anything, as a time (0 if there is none)
function backup_newest() {
    $t = 0;
    foreach (glob(backup_dir() . '/*-*.php') ?: [] as $f) if (preg_match('/-\d{4}-\d{2}-\d{2}\.php$/', $f)) $t = max($t, (int)@filemtime($f));
    return $t;
}
// what restores what, in plain words (in the zip as README.txt, and the same facts in the Backups tab)
function backup_readme() {
    $l = ["shy-data, downloaded " . gmdate('Y-m-d H:i') . " UTC", '',
        'Every file here is a .php file that starts with one guard line, then JSON. Open it in a text editor to read it.',
        'To put a file back: in Hostinger File Manager, open shy-data (next to public_html), upload the file over the old one.',
        'Do it at a quiet time, and put back the files that belong together at the same time (players, economy, orders, rewards).', '',
        'What each file holds:'];
    foreach (OPS_BACKUP as $name => [$file, $what]) $l[] = '  ' . str_pad($file, 22) . $what;
    $l[] = '  config.php            Private settings: admin password, keys for Helius, X, Stripe. Keep this zip private.';
    $l[] = '';
    $l[] = 'Daily copies are in shy-data/backups for ' . OPS_KEEP_DAYS . ' days and weekly copies for ' . OPS_KEEP_WEEKS . ' weeks (not in this zip).';
    $l[] = 'Players has a Restore button in Admin > Backups. Everything else goes back by hand as described above.';
    return implode("\n", $l) . "\n";
}
// files left out of the zip: caches the site rebuilds by itself, lock files, temp files, and short-lived game state
function backup_zip_skip($rel) {
    $b = basename($rel);
    if (preg_match('#^(rooms|shares|backups)/#', $rel)) return true;
    if (preg_match('/^cache-|-cache\.php$|\.lock$|-lock\.php$|^lock\.php$|\.tmp\.|^(market|medium|prices|presence|limits|tokens|stats-cache|treasury-cache)\.php$|^lock-wait\.dat|^zip/', $b)) return true;
    return false;
}
// Stream every data file as a zip. $art adds the card art pictures (card-art-src and card-art-keep, big).
//   The data files are read under the site lock (a few MB, a few ms) so they match each other; pictures are added as they are.
function backup_zip_stream($art = false) {
    if (!class_exists('ZipArchive')) return 'This server\'s PHP has no zip support (ZipArchive). Download the backups one by one instead, or ask the host to turn on the PHP zip extension.';
    @set_time_limit(600);
    $root = DATA_DIR; $data = []; $pics = [];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $rel = ltrim(substr($f->getPathname(), strlen($root)), '/');
        if (backup_zip_skip($rel)) continue;
        if (preg_match('#^card-art-(src|keep)/#', $rel)) { if ($art) $pics[] = $rel; continue; }
        $data[] = $rel;
    }
    sort($data);
    $raw = with_lock(function () use ($root, $data) { $o = []; foreach ($data as $rel) { $s = @file_get_contents($root . '/' . $rel); if ($s !== false) $o[$rel] = $s; } return $o; });
    $tmp = @tempnam($root, 'zip');
    if (!$tmp) return 'Could not make a temporary file in shy-data.';
    register_shutdown_function(fn() => @unlink($tmp));
    $z = new ZipArchive();
    if ($z->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) return 'Could not start the zip.';
    $top = 'shy-data-' . gmdate('Y-m-d') . '/';
    $z->addFromString($top . 'README.txt', backup_readme());
    foreach ($raw as $rel => $s) $z->addFromString($top . $rel, $s);
    foreach ($pics as $rel) { $z->addFile($root . '/' . $rel, $top . $rel); if (method_exists($z, 'setCompressionName')) $z->setCompressionName($top . $rel, ZipArchive::CM_STORE); }
    if (!$z->close()) return 'Could not finish the zip (is the disk full?).';
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="shy-data-' . gmdate('Y-m-d') . ($art ? '-with-art' : '') . '.zip"');
    header('Content-Length: ' . filesize($tmp));
    header('X-Content-Type-Options: nosniff');
    while (ob_get_level()) ob_end_clean();
    readfile($tmp);
    @unlink($tmp);
    exit;
}

// ---------------------------------------------------------------- lock wait (written by lock_wait_note in common.php)
// average and longest wait for the site lock over the last $secs seconds, in ms; n is how many lock takes that covers
function lock_wait_stats($secs = 3600) {
    $since = time() - $secs;
    if (function_exists('apcu_enabled') && @apcu_enabled()) {
        $p = 'shylw:' . substr(md5(DATA_DIR), 0, 8) . ':'; $n = 0; $s = 0; $x = 0;
        for ($m = intdiv($since, 60); $m <= intdiv(time(), 60); $m++) { $n += (int)apcu_fetch($p . $m . ':n'); $s += (int)apcu_fetch($p . $m . ':s'); $x = max($x, (int)apcu_fetch($p . $m . ':x')); }
        return ['n' => $n, 'avg' => $n ? round($s / $n / 1000, 1) : 0, 'max' => round($x / 1000, 1), 'src' => 'apcu'];
    }
    $n = 0; $s = 0; $x = 0;
    $sz = (int)@filesize(OPS_LOCKW);
    if ($sz > 0 && ($fh = @fopen(OPS_LOCKW, 'r'))) {
        if ($sz > 400000) { fseek($fh, $sz - 400000); fgets($fh); }   // the last part is enough for an hour
        while (($line = fgets($fh)) !== false) {
            $p = explode(' ', trim($line));
            if (count($p) !== 3 || (int)$p[0] < $since) continue;
            $w = max(1, (int)$p[2]); $us = (int)$p[1];
            $n += $w; $s += $us * $w; $x = max($x, $us);
        }
        fclose($fh);
    }
    return ['n' => $n, 'avg' => $n ? round($s / $n / 1000, 1) : 0, 'max' => round($x / 1000, 1), 'src' => 'file'];
}
// keep only the last two hours of samples (hourly, from cron)
function lock_wait_trim() {
    if (!is_file(OPS_LOCKW)) return;
    $keep = []; $cut = time() - 7200;
    foreach (@file(OPS_LOCKW, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $l) if ((int)$l >= $cut) $keep[] = $l;
    $tmp = OPS_LOCKW . '.tmp.' . getmypid();
    if (@file_put_contents($tmp, $keep ? implode("\n", $keep) . "\n" : '') !== false) @rename($tmp, OPS_LOCKW);
}

// ---------------------------------------------------------------- Telegram send health (written by tg_flush)
function tg_health() { $d = load(OPS_TGH); return ['r' => (array)($d['r'] ?? []), 'last' => (array)($d['last'] ?? [])]; }
// the error when the last 3 chat posts all failed, otherwise ''
function tg_health_down() {
    $r = array_slice(tg_health()['r'], 0, 3);
    if (count($r) < 3) return '';
    foreach ($r as $x) if (!empty($x['ok'])) return '';
    return ['t' => (int)$r[0]['t'], 'err' => (string)($r[0]['err'] ?? ''), 'k' => (string)($r[0]['k'] ?? '')];
}

// ---------------------------------------------------------------- health
function ops_tail($file, $bytes = 4000) {
    $sz = (int)@filesize($file); if (!$sz) return '';
    $fh = @fopen($file, 'r'); if (!$fh) return '';
    fseek($fh, max(0, $sz - $bytes)); $s = (string)fread($fh, $bytes); fclose($fh);
    $lines = array_values(array_filter(array_map('trim', explode("\n", $s)), 'strlen'));
    return $lines ? end($lines) : '';
}
// a log line's time (they start with gmdate('c'))
function ops_line_time($l) { $t = strtotime(substr($l, 0, 25)); return $t ?: 0; }
function ops_dir_size($dir) {
    $n = 0; $f = 0;
    try { foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)) as $x) if ($x->isFile()) { $n += $x->getSize(); $f++; } } catch (Throwable $e) {}
    return [$n, $f];
}
function ops_bytes($b) {
    if ($b >= 1 << 30) return round($b / (1 << 30), 1) . ' GB';
    if ($b >= 1 << 20) return round($b / (1 << 20), 1) . ' MB';
    return $b >= 1024 ? round($b / 1024) . ' KB' : $b . ' B';
}
function ops_ago($ts) { if (!$ts) return 'never'; $d = time() - $ts; return $d < 90 ? 'just now' : ($d < 5400 ? round($d / 60) . ' min ago' : ($d < 129600 ? round($d / 3600) . ' h ago' : round($d / 86400) . ' days ago')); }
function ops_mem_bytes($v) { $v = trim((string)$v); if ($v === '-1') return PHP_INT_MAX; $n = (int)$v; $u = strtolower(substr($v, -1)); return $u === 'g' ? $n << 30 : ($u === 'm' ? $n << 20 : ($u === 'k' ? $n << 10 : $n)); }
// Everything the health check looks at. Each check is [label, level, text] with level ok, warn or bad.
function health_compute() {
    $c = []; $now = time();
    // data files
    $sizes = [];
    foreach (glob(DATA_DIR . '/*.php') ?: [] as $f) { $b = basename($f); if (!backup_zip_skip($b)) $sizes[$b] = (int)@filesize($f); }
    arsort($sizes);
    $big = array_filter($sizes, fn($s) => $s >= 4 << 20);
    $huge = array_filter($sizes, fn($s) => $s >= 12 << 20);
    $top = array_slice($sizes, 0, 5, true);
    $c['files'] = ['Data files', $huge ? 'bad' : ($big ? 'warn' : 'ok'), ($big ? 'Big: ' . implode(', ', array_map(fn($k, $v) => $k . ' ' . ops_bytes($v), array_keys($big), $big)) . '. Every change rewrites the whole file, so the site slows down as they grow. ' : '') . 'Largest: ' . implode(', ', array_map(fn($k, $v) => $k . ' ' . ops_bytes($v), array_keys($top), $top))];
    // cron
    $cr = (int)(load(OPS_CRON)['t'] ?? 0);
    $c['cron'] = ['Cron job', !$cr ? 'warn' : ($now - $cr > 6 * 3600 ? 'bad' : ($now - $cr > 20 * 60 ? 'warn' : 'ok')), $cr ? 'Last ran ' . ops_ago($cr) . '.' . ($now - $cr > 20 * 60 ? ' It should run every 5 minutes. Check it in hPanel, Advanced, Cron Jobs.' : '') : 'Has not run yet. Add it in hPanel, Advanced, Cron Jobs (the command is at the bottom of the Telegram tab). Backups, the nightly payment check and timed posts depend on it.'];
    // the site lock
    $lw = lock_wait_stats(3600);
    $c['lock'] = ['Waiting for the site lock', $lw['avg'] > 1000 ? 'bad' : ($lw['avg'] > 250 || $lw['max'] > 3000 ? 'warn' : 'ok'), $lw['n'] ? 'Last hour: ' . $lw['avg'] . ' ms on average, ' . $lw['max'] . ' ms at most, about ' . number_format($lw['n']) . ' requests.' : 'No samples in the last hour.'];
    // Telegram
    $tgc = function_exists('tg_cfg') ? tg_cfg() : ['token' => '', 'chat' => ''];
    $down = tg_health_down();
    $tl = ops_tail(DATA_DIR . '/telegram-errors.log');
    $tt = ops_line_time($tl);
    $rq = is_file(DATA_DIR . '/tg-retry.php') ? count(load(DATA_DIR . '/tg-retry.php')) : 0;
    if ($tgc['token'] === '' || $tgc['chat'] === '') $c['tg'] = ['Telegram', 'ok', 'Not set up.'];
    else $c['tg'] = ['Telegram', $down ? 'bad' : ($tt > $now - 86400 || $rq ? 'warn' : 'ok'), $down ? 'The last 3 posts to the chat failed: ' . mb_substr($down['err'], 0, 160) . ' (' . ops_ago($down['t']) . ').' : (($tl !== '' ? 'Last error ' . ops_ago($tt) . ': ' . mb_substr(substr($tl, 26), 0, 160) . '.' : 'No errors logged.') . ($rq ? ' ' . $rq . ' ' . ($rq === 1 ? 'post is' : 'posts are') . ' waiting to be sent again.' : ''))];
    // email
    $ml = ops_tail(DATA_DIR . '/mail-errors.log'); $mt = ops_line_time($ml);
    $c['mail'] = ['Email', $mt > $now - 86400 ? 'warn' : 'ok', $ml !== '' ? 'Last error ' . ops_ago($mt) . ': ' . mb_substr(substr($ml, 26), 0, 160) : 'No errors logged.'];
    // backups
    $bn = backup_newest();
    $c['backup'] = ['Backups', !$bn ? 'warn' : ($now - $bn > 72 * 3600 ? 'bad' : ($now - $bn > 30 * 3600 ? 'warn' : 'ok')), $bn ? 'Newest copy ' . ops_ago($bn) . '.' : 'No backup yet. The first one is made by the cron job after midnight UTC.'];
    // disk
    [$dsz, $dn] = ops_dir_size(DATA_DIR);
    $rooms = count(glob(DATA_DIR . '/rooms/*.php') ?: []);
    $shares = count(glob(DATA_DIR . '/shares/*') ?: []);
    $free = @disk_free_space(DATA_DIR);
    $c['disk'] = ['Disk', $dsz > 1 << 30 || $shares > 20000 || ($free !== false && $free < 1 << 30) ? 'warn' : 'ok', 'shy-data uses ' . ops_bytes($dsz) . ' in ' . number_format($dn) . ' files: ' . number_format($rooms) . ' live rooms, ' . number_format($shares) . ' share files' . ($free !== false ? '. Free on the disk: ' . ops_bytes((int)$free) : '') . '.'];
    // payments paid but not delivered (the nightly check)
    $rc = recon_open();
    $c['pay'] = ['Payments', $rc ? 'warn' : 'ok', $rc ? count($rc) . ' ' . (count($rc) === 1 ? 'payment was' : 'payments were') . ' found on Solana but not delivered. See Shop, Nightly payment check.' : 'Nothing paid and undelivered at the last nightly check.'];
    // PHP
    $mem = ini_get('memory_limit');
    $c['php'] = ['PHP', ops_mem_bytes($mem) < 128 << 20 || !class_exists('ZipArchive') ? 'warn' : 'ok', 'PHP ' . PHP_VERSION . ', memory limit ' . $mem . ', zip ' . (class_exists('ZipArchive') ? 'yes' : 'no (the data download is off)') . ', APCu ' . (function_exists('apcu_enabled') && @apcu_enabled() ? 'yes' : 'no') . '.'];
    $rank = ['ok' => 0, 'warn' => 1, 'bad' => 2];
    $lvl = 'ok'; foreach ($c as $x) if ($rank[$x[1]] > $rank[$lvl]) $lvl = $x[1];
    return ['t' => $now, 'level' => $lvl, 'checks' => $c,
        'data' => ['files' => $sizes, 'cron' => $cr, 'lock' => $lw, 'tg_down' => $down ?: null, 'tg_err' => $tl, 'mail_err' => $ml, 'backup' => $bn, 'disk' => $dsz, 'disk_files' => $dn, 'free' => $free === false ? null : (int)$free,
            'rooms' => $rooms, 'shares' => $shares, 'php' => PHP_VERSION, 'memory_limit' => $mem, 'zip' => class_exists('ZipArchive'), 'unpaid' => count($rc)]];
}
// the last health check if it's younger than $maxAge seconds, otherwise a new one (saved for next time)
function health_get($maxAge = 300) {
    $h = load(OPS_HEALTH);
    if ($maxAge > 0 && !empty($h['t']) && time() - $h['t'] < $maxAge && isset($h['checks'])) return $h;
    $h = health_compute();
    try { save(OPS_HEALTH, $h); } catch (Throwable $e) {}
    return $h;
}
// one line for the daily email: "OK" or what needs a look
function health_line($h = null) {
    $h = $h ?? health_get(600);
    $bad = array_filter($h['checks'], fn($x) => $x[1] !== 'ok');
    if (!$bad) return ['ok', 'All green: cron, backups, Telegram, email, disk and the site lock look fine.'];
    return [$h['level'], implode(' ', array_map(fn($x) => $x[0] . ': ' . $x[2], $bad))];
}

// ---------------------------------------------------------------- nightly payment check
// Open (unpaid) Solana orders from the last 30 days that have a wallet signature or an open Payment help request are
//   looked up on Solana again. It delivers only where the buyer's own "check" in the shop would have delivered: the
//   payment carries the order's reference, covers the price and lands within the day the shop honours (ORDER_GRACE).
//   Everything else that found money (a ticket's payment that covers an order, a late or short payment, one paid more than a
//   day after the order) is only listed for the team, in Admin > Shop and the daily email.
function recon_due() { $r = load(OPS_RECON); return ($r['day'] ?? '') !== gmdate('Y-m-d') && (int)gmdate('G') >= 3; }
function recon_run($force = false) {
    if (!function_exists('verify_payment')) return null;
    // claimed first, so two cron runs at once can't both run it
    $go = with_lock(function () use ($force) {
        $r = load(OPS_RECON);
        if (!$force && (($r['day'] ?? '') === gmdate('Y-m-d') || (int)gmdate('G') < 3)) return false;
        if (!$force && time() - (int)($r['start'] ?? 0) < 600) return false;
        $r['start'] = time(); save(OPS_RECON, $r);
        return true;
    });
    if (!$go) return null;
    @set_time_limit(300);
    $t0 = time();
    [$orders, $help] = with_lock(fn() => [load(ORDERS), load(DATA_DIR . '/pay-help.php')]);
    $tick = [];   // order id => open tickets that point at it
    foreach ($help as $hid => $x) if (($x['status'] ?? '') === 'open') foreach (array_unique(array_filter(array_merge((array)($x['orders'] ?? []), [(string)($x['order'] ?? '')]))) as $oid) $tick[$oid][$hid] = $x;
    $cand = array_filter($orders, fn($o) => ($o['status'] ?? '') !== 'paid' && ($o['cur'] ?? '') !== 'CARD' && !empty($o['ref']) && ((string)($o['sig'] ?? '') !== '' || isset($tick[$o['id'] ?? ''])) && (int)($o['ts'] ?? 0) > time() - 30 * 86400);
    // at most 60 a night, the ones looked at longest ago first (then the newest), so a long list is covered over a few
    //   nights instead of the same newest ones every time. Tried newest-first only: with 114 open orders on the test copy
    //   the oldest 74 were never reached.
    $prev = load(OPS_RECON); $seen = (array)($prev['seen'] ?? []);
    uasort($cand, fn($a, $b) => [(string)($seen[$a['id']] ?? ''), $b['ts']] <=> [(string)($seen[$b['id']] ?? ''), $a['ts']]);
    $rows = []; $done = []; $n = 0; $rpcDown = 0; $looked = [];
    foreach (array_slice($cand, 0, 60, true) as $id => $o) {
        if (time() - $t0 > 120) break;   // the rest waits for the next night
        $n++; $looked[$id] = 1;
        $v = verify_payment($o, (string)($o['sig'] ?? ''));
        if (($v['wait'] ?? '') === 'rpc') { $rpcDown++; continue; }
        $row = ['id' => $id, 'pid' => $o['pid'], 'name' => $o['name'], 'usd' => (float)$o['usd'], 'cur' => $o['cur'], 'ts' => (int)$o['ts'], 'help' => implode(',', array_keys($tick[$id] ?? []))];
        if (!empty($v['paid'])) {
            if (time() <= $o['ts'] + ORDER_GRACE) {
                $res = with_lock(function () use ($id, $v) {
                    $all = load(ORDERS);
                    if (!isset($all[$id]) || $all[$id]['status'] === 'paid') return 'already';
                    foreach ($all as $x => $y) if ($x !== $id && ($y['proof'] ?? '') === $v['paid']) return 'used:' . $x;
                    if (!empty($v['selfpay'])) $all[$id]['selfpay'] = 1;
                    fulfill($all, $id, $v['paid'], $v);
                    return 'ok';
                });
                if ($res === 'ok') { $done[] = $row + ['sig' => $v['paid'], 'what' => 'Delivered: the payment carries the order\'s reference and covers the price.']; shop_log('order ' . $id . ' delivered by the nightly check ' . $v['paid']); continue; }
                if ($res === 'already') continue;
                $rows[] = $row + ['sig' => $v['paid'], 'kind' => 'used', 'what' => 'Paid, but the same payment already delivered order ' . substr($res, 5) . '.'];
                continue;
            }
            $rows[] = $row + ['sig' => $v['paid'], 'kind' => 'paid', 'what' => 'Paid in full, but more than a day after the order, so the shop no longer delivers it on its own.'];
            continue;
        }
        if (isset($v['late'])) { $rows[] = $row + ['sig' => $v['late'], 'kind' => 'late', 'what' => 'Paid ' . (int)$v['mins'] . ' minutes after the price hold; covers ' . $v['got'] . ' of the ' . $v['need'] . ' units today\'s price needs.']; continue; }
        if (isset($v['short'])) { $rows[] = $row + ['sig' => $v['short'], 'kind' => 'short', 'what' => 'Paid less than the price: ' . $v['got'] . ' of ' . $o['units'] . ' units.']; continue; }
        // a payment the player pasted (Payment help) that doesn't carry the reference: would it cover this order?
        foreach ($tick[$id] ?? [] as $hid => $x) {
            $sig = (string)($x['sig'] ?? '');
            if ($sig === '' || $sig === (string)($o['sig'] ?? '')) continue;
            $m = tx_pays_manual($o, $sig, [], true);
            if (!empty($m['paid'])) { $rows[] = $row + ['sig' => $sig, 'kind' => 'help', 'what' => 'The payment in request #' . $hid . ' covers this order' . (($m['payer'] ?? '') !== ($o['wallet'] ?? '') ? ', sent from ' . substr((string)($m['payer'] ?? ''), 0, 6) . '…, not the wallet on the order' : '') . '.']; break; }
            if (isset($m['late'])) { $rows[] = $row + ['sig' => $sig, 'kind' => 'late', 'what' => 'The payment in request #' . $hid . ' came after the price hold; covers ' . $m['got'] . ' of ' . $m['need'] . ' units at today\'s price.']; break; }
            if (isset($m['short'])) { $rows[] = $row + ['sig' => $sig, 'kind' => 'short', 'what' => 'The payment in request #' . $hid . ' is short: ' . $m['got'] . ' of ' . $o['units'] . ' units.']; break; }
        }
    }
    // what an earlier night found for an order that wasn't looked at tonight stays on the list while the order is open
    foreach ((array)($prev['rows'] ?? []) as $x) if (!isset($looked[$x['id']]) && isset($cand[$x['id']])) $rows[] = $x;
    foreach ($looked as $id => $_) $seen[$id] = gmdate('Y-m-d H:i');
    $seen = array_intersect_key($seen, $cand);
    $out = ['day' => gmdate('Y-m-d'), 't' => time(), 'start' => 0, 'checked' => $n, 'waiting' => max(0, count($cand) - $n), 'rpc' => $rpcDown, 'rows' => $rows, 'done' => $done, 'seen' => $seen];
    with_lock(fn() => save(OPS_RECON, $out));
    if ($done && function_exists('track')) track('recon_delivered', count($done));
    return ['checked' => $n, 'delivered' => count($done), 'listed' => count($rows)] + ($rpcDown ? ['rpc_down' => $rpcDown] : []);
}
// rows of the last check whose order still isn't delivered
function recon_open() {
    $r = load(OPS_RECON);
    if (empty($r['rows'])) return [];
    $orders = defined('ORDERS') ? load(ORDERS) : [];
    return array_values(array_filter($r['rows'], fn($x) => ($orders[$x['id']]['status'] ?? '') !== 'paid'));
}

// ---------------------------------------------------------------- bug #35: League points lost to the language report
// Compares a backup of players.php with the players now. A player shows up when the backup has League points for the
//   current week (lg, same week key) or Season points for the current season (sg) that are higher than now, or missing now.
//   The fix takes the higher of the two for points and games, so nothing is ever lowered. $bk and $cur are player maps.
function lg_recover_plan($bk, $cur, $wk, $sn) {
    $rows = [];
    foreach ($bk as $pid => $b) {
        if (!is_array($b) || !isset($cur[$pid]) || !is_array($cur[$pid])) continue;   // a player removed since stays removed
        $c = $cur[$pid];
        $row = ['pid' => $pid, 'name' => (string)($c['name'] ?? ($b['name'] ?? ''))];
        $bl = is_array($b['lg'] ?? null) && ($b['lg']['wk'] ?? '') === $wk ? $b['lg'] : null;
        $cl = is_array($c['lg'] ?? null) && ($c['lg']['wk'] ?? '') === $wk ? $c['lg'] : null;
        if ($bl && (int)$bl['pts'] > 0 && (!$cl || (int)$cl['pts'] < (int)$bl['pts'])) {
            $row['lg'] = [(int)$bl['pts'], $cl ? (int)$cl['pts'] : null, ['wk' => $wk, 'pts' => max((int)$bl['pts'], (int)($cl['pts'] ?? 0)), 'n' => max((int)($bl['n'] ?? 0), (int)($cl['n'] ?? 0))]];
            $row['lgwas'] = is_array($c['lg'] ?? null) ? 'week ' . ($c['lg']['wk'] ?? '?') : (isset($c['lg']) ? 'text "' . mb_substr((string)$c['lg'], 0, 8) . '"' : 'missing');
        }
        $bs = is_array($b['sg'] ?? null) && (int)($b['sg']['s'] ?? 0) === (int)$sn ? $b['sg'] : null;
        $cs = is_array($c['sg'] ?? null) && (int)($c['sg']['s'] ?? 0) === (int)$sn ? $c['sg'] : null;
        if ($bs && (int)$bs['pts'] > 0 && (!$cs || (int)$cs['pts'] < (int)$bs['pts']))
            $row['sg'] = [(int)$bs['pts'], $cs ? (int)$cs['pts'] : null, ['s' => (int)$sn, 'pts' => max((int)$bs['pts'], (int)($cs['pts'] ?? 0)), 'n' => max((int)($bs['n'] ?? 0), (int)($cs['n'] ?? 0))]];
        if (isset($row['lg']) || isset($row['sg'])) $rows[$pid] = $row;
    }
    uasort($rows, fn($a, $b) => (($b['lg'][0] ?? 0) - ($b['lg'][1] ?? 0)) <=> (($a['lg'][0] ?? 0) - ($a['lg'][1] ?? 0)));
    return $rows;
}
// the backup files the tool can compare with (daily and weekly copies of players, newest first)
function lg_recover_files() {
    $out = [];
    foreach (glob(backup_dir() . '/players-*.php') ?: [] as $f) { $b = basename($f); if (preg_match('/^players-\d{4}-(\d{2}-\d{2}|W\d{2})\.php$/', $b)) $out[] = $b; }
    rsort($out);
    return $out;
}
// Put the plan's League and Season values back, inside the site lock, against the players as they are at that moment
//   (so a game finished between the preview and the press is never undone). Returns the rows changed.
function lg_recover_apply($file) {
    if (!in_array($file, lg_recover_files(), true)) return null;
    $bk = load(backup_dir() . '/' . $file);
    if (!$bk) return null;
    return with_lock(function () use ($bk) {
        $pl = load(PLAYERS);
        // a week that just ended is filed first, exactly like the admin pages do, so its standings are kept as they were
        archive_weeks($pl); if (function_exists('rewards_freeze')) rewards_freeze($pl);
        $plan = lg_recover_plan($bk, $pl, week_key(), season_no());
        foreach ($plan as $pid => $r) {
            if (isset($r['lg'])) {
                if (is_string($pl[$pid]['lg'] ?? null) && empty($pl[$pid]['lang'])) $pl[$pid]['lang'] = $pl[$pid]['lg'];   // the language it held
                $pl[$pid]['lg'] = $r['lg'][2];
            }
            if (isset($r['sg'])) $pl[$pid]['sg'] = $r['sg'][2];
        }
        if ($plan) { save(PLAYERS, $pl); @unlink(DATA_DIR . '/cache-rewards.php'); }
        return $plan;
    });
}
