//MC 2026-10-17 Shy Swap (first called Shy Exchange), our own swap. Pick two tokens and an amount, get the best route across every Solana DEX from
//   Jupiter (through api/swap.php, which adds our fee for the marketing wallet), and approve it in your own wallet.
//   Wallets are found through the Solana Wallet Standard (Phantom, Solflare, Backpack and the rest announce themselves
//   to the page), so no wallet library is loaded: the wallet signs the transaction bytes Jupiter built, and the signed
//   swap goes back through api/swap.php to Jupiter, which lands it. Nothing here can move funds on its own.
//   If Jupiter can't be reached through us, the page swaps over to Jupiter's own swap box (assets/exchange.js).
(function () {
  "use strict";
  var EX = window.SHY_EX || {}, SHY = EX.ca, SOL = EX.sol;
  var $ = function (id) { return document.getElementById(id); };
  if (!$("sx-go") || !SHY) return;
  var API = "/api/swap.php";
  var FEE_SOL = 0.012;   // SOL kept back on Max for network fees and a new token account
  var REFRESH = 20;      // seconds between fresh quotes
  var st = {
    tin: { id: SOL, symbol: "SOL", name: "Solana", decimals: 9, icon: "" },
    tout: { id: SHY, symbol: "SHY", name: "Shy", decimals: 6, icon: EX.logo || "" },
    amt: "", quote: null, qn: 0, loading: false, busy: false, slip: "", fee: 0, search: false,
    wallets: [], w: null, acct: null, addr: "", bal: null, tokens: [], picking: "in", left: REFRESH, err: ""
  };
  var KNOWN = {};
  KNOWN[SOL] = st.tin; KNOWN[SHY] = st.tout;

  // ---------------------------------------------------------------- numbers
  // amounts move as whole units of the token's smallest part (BigInt), never as floats
  function toRaw(s, dec) {
    s = String(s || "").replace(/,/g, ".").trim();
    if (!/^\d*\.?\d*$/.test(s) || s === "" || s === ".") return 0n;
    var p = s.split("."), w = p[0] || "0", f = (p[1] || "").slice(0, dec);
    while (f.length < dec) f += "0";
    try { return BigInt(w) * (10n ** BigInt(dec)) + BigInt(f || "0"); } catch (e) { return 0n; }
  }
  function fromRaw(r, dec) {
    r = BigInt(r || 0); var neg = r < 0n; if (neg) r = -r;
    var d = 10n ** BigInt(dec), w = r / d, f = (r % d).toString().padStart(dec, "0").replace(/0+$/, "");
    return (neg ? "-" : "") + w.toString() + (f ? "." + f : "");
  }
  function nice(str, max) {
    var n = parseFloat(str); if (!isFinite(n) || n === 0) return "0";
    var a = Math.abs(n), d = a >= 1000 ? 2 : a >= 1 ? 4 : Math.min(10, -Math.floor(Math.log10(a)) + 3);
    if (max != null) d = Math.min(d, max);
    return n.toLocaleString("en-US", { maximumFractionDigits: d });
  }
  function pct(bps) { return String(Math.round(bps) / 100) + "%"; }
  function usd(n) { if (!(n > 0)) return ""; return "$" + n.toLocaleString("en-US", { minimumFractionDigits: n < 1 ? 2 : 2, maximumFractionDigits: n < 1 ? 4 : 2 }); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function b64ToBytes(b) { var s = atob(b), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
  function bytesToB64(u) { var s = ""; for (var i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
  function short(a) { return a ? a.slice(0, 4) + "..." + a.slice(-4) : ""; }
  function sym(t) { return t.id === SHY ? "$SHY" : t.symbol; }

  function api(params) {
    var q = Object.keys(params).filter(function (k) { return params[k] !== "" && params[k] != null; }).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]); }).join("&");
    return fetch(API + "?" + q, { cache: "no-store" }).then(function (r) { return r.json().catch(function () { return { ok: false, error: "Something went wrong. Try again." }; }); });
  }

  // ---------------------------------------------------------------- tokens on screen
  //MC 2026-10-17 logos on IPFS ($SHY, $WIF) often never load, and the rest are 400 to 800px files the picker shrinks
  //   to 32px. DexScreener keeps a 64px copy of most Solana logos, so that goes first, then the token's own logo,
  //   then ours. Our own $SHY logo always comes first for $SHY.
  var NOPIC = "/assets/art/icon-192.png";
  function letter(sy) {
    var c = String(sy || "?").replace(/^\$/, "").charAt(0).toUpperCase() || "?";
    if (!/[A-Z0-9]/.test(c)) c = "?";
    return "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b4bb7"/><stop offset="1" stop-color="#2a1f5c"/></linearGradient></defs><circle cx="32" cy="32" r="32" fill="url(#g)"/><text x="32" y="42" font-family="Arial,sans-serif" font-size="28" font-weight="700" fill="#fff" text-anchor="middle">' + c + '</text></svg>');
  }
  function pics(t) {
    var own = t.icon || "";
    if (t.id === SHY && EX.logo) return [EX.logo, own];
    if (t.id === SOL) return [own, "https://dd.dexscreener.com/ds-data/tokens/solana/" + SOL + ".png"];
    return ["https://dd.dexscreener.com/ds-data/tokens/solana/" + encodeURIComponent(t.id) + ".png", own];
  }
  function imgTag(t) {
    var p = pics(t);
    return '<img alt="" width="32" height="32" decoding="async" loading="lazy" data-l="' + esc(t.id === SHY ? "" : sym(t)) + '" src="' + esc(p[0] || p[1] || letter(sym(t))) + '"' + (p[0] && p[1] ? ' data-alt="' + esc(p[1]) + '"' : "") + '>';
  }
  document.addEventListener("error", function (e) {
    var el = e.target;
    if (!el || el.tagName !== "IMG" || !el.closest(".sx-swap,#sx-pick")) return;
    var alt = el.getAttribute("data-alt");
    if (alt) { el.removeAttribute("data-alt"); el.src = alt; }
    else if (!el.hasAttribute("data-nopic")) { el.setAttribute("data-nopic", ""); var l = el.getAttribute("data-l"); el.src = l ? letter(l) : NOPIC; }
  }, true);
  function tokImg(img, t) {
    var p = pics(t);
    img.removeAttribute("data-nopic"); img.setAttribute("data-l", t.id === SHY ? "" : sym(t));
    if (p[0] && p[1]) img.setAttribute("data-alt", p[1]); else img.removeAttribute("data-alt");
    var want = p[0] || p[1] || (t.id === SHY ? NOPIC : letter(sym(t)));
    if (img.getAttribute("src") !== want) img.src = want;
  }
  function drawTokens() {
    tokImg($("sx-tok-in-i"), st.tin); tokImg($("sx-tok-out-i"), st.tout);
    $("sx-tok-in-s").textContent = sym(st.tin); $("sx-tok-out-s").textContent = sym(st.tout);
    document.querySelectorAll(".sx-route").forEach(function (b) { b.classList.toggle("on", b.dataset.in === st.tin.id && b.dataset.out === st.tout.id); });
    drawBal();
  }
  function balRaw(t) {
    if (!st.bal) return null;
    if (t.id === SOL) return BigInt(st.bal.sol || "0");
    var x = st.bal.tokens.filter(function (k) { return k.id === t.id; })[0];
    return x ? BigInt(x.raw) : 0n;
  }
  function drawBal() {
    var a = balRaw(st.tin), b = balRaw(st.tout);
    $("sx-bal-in-w").hidden = a === null; $("sx-bal-out-w").hidden = b === null;
    if (a !== null) $("sx-bal-in").textContent = nice(fromRaw(a, st.tin.decimals));
    if (b !== null) $("sx-bal-out").textContent = nice(fromRaw(b, st.tout.decimals));
  }

  // ---------------------------------------------------------------- the quote
  var qTimer = 0;
  function want() { clearTimeout(qTimer); qTimer = setTimeout(quote, 320); }
  function quote() {
    var raw = toRaw(st.amt, st.tin.decimals);
    st.quote = null; st.err = "";
    if (raw <= 0n) { st.loading = false; drawQuote(); return; }
    var n = ++st.qn; st.loading = true; drawQuote();
    api({ a: "order", inputMint: st.tin.id, outputMint: st.tout.id, amount: raw.toString(), slippageBps: st.slip }).then(function (j) {
      if (n !== st.qn) return;
      st.loading = false; st.left = REFRESH;
      if (j && j.outAmount && !j.error) { st.quote = j; noteTokens(j); }
      else { st.err = friendly(j); if (j && (j.code === 401 || /api key|unauthor/i.test(String(j.error || j.errorMessage || "")))) fallback(); }
      drawQuote();
    }).catch(function () { if (n !== st.qn) return; st.loading = false; st.err = "Can't reach the swap right now. Check your connection."; drawQuote(); netFails(); });
  }
  var fails = 0;
  function netFails() { if (++fails >= 3) fallback(); }
  function fallback() { if (window.ShyEx && ShyEx.loadPlugin) { ShyEx.loadPlugin(st.tin.id, st.tout.id); $("sx-swap").classList.add("plugin"); } }
  function friendly(j) {
    var m = String((j && (j.errorMessage || j.error)) || "");
    if (/no route|could not find|not tradable|no routes/i.test(m)) return "No route for this pair right now. Try a different amount or token.";
    if (/insufficient/i.test(m)) return "Not enough in your wallet for this swap and its network fee.";
    if (/slow down/i.test(m)) return m;
    return m ? m.replace(/\s+/g, " ").slice(0, 160) : "Couldn't get a price. Try again.";
  }
  function noteTokens(q) {
    // Jupiter tells us each side's USD value; keep a per-token price for the USD lines
    var ia = parseFloat(fromRaw(q.inAmount || "0", st.tin.decimals)), oa = parseFloat(fromRaw(q.outAmount || "0", st.tout.decimals));
    if (q.inUsdValue && ia > 0) st.tin.usd = q.inUsdValue / ia;
    if (q.outUsdValue && oa > 0) st.tout.usd = q.outUsdValue / oa;
  }
  function drawQuote() {
    var q = st.quote, out = $("sx-out");
    out.classList.toggle("loading", st.loading);
    var ia = parseFloat(st.amt || "0");
    $("sx-usd-in").textContent = ia > 0 && st.tin.usd ? usd(ia * st.tin.usd) : " ";
    if (q) {
      var oa = fromRaw(q.outAmount, st.tout.decimals);
      out.textContent = nice(oa); out.classList.remove("zero");
      $("sx-usd-out").textContent = q.outUsdValue ? usd(q.outUsdValue) : " ";
      var per = parseFloat(oa) / ia;
      $("sx-rate-t").textContent = "1 " + sym(st.tin) + " = " + nice(String(per)) + " " + sym(st.tout);
      $("sx-rate").hidden = false;
      //MC 2026-10-17 Jupiter gives the impact signed: below zero the route beats the market price, which costs nothing
      var impRaw = parseFloat(q.priceImpact != null ? q.priceImpact : (q.priceImpactPct || 0) * 100) || 0, imp = impRaw > 0 ? impRaw : 0;
      var dImp = $("sx-d-imp"); dImp.textContent = imp < 0.01 ? "None" : imp.toFixed(2) + "%"; dImp.className = imp >= 10 ? "bad" : imp >= 3 ? "warn" : "good";
      $("sx-d-min").textContent = q.otherAmountThreshold ? nice(fromRaw(q.otherAmountThreshold, st.tout.decimals)) + " " + sym(st.tout) : "-";
      $("sx-d-slip").textContent = st.slip === "" ? (q.slippageBps ? pct(q.slippageBps) + " (auto)" : "Auto") : pct(st.slip);
      //MC 2026-10-17 the whole swap fee as Jupiter takes it: ours when the referral fee is on, otherwise Jupiter's own
      var fb = +(q.feeBps || 0), ours = q.shyFee || 0;
      $("sx-d-fee").textContent = fb ? pct(fb) + (ours ? " (Shy Swap)" : " (routing)") : "None";
      var net = (q.signatureFeeLamports || 0) + (q.prioritizationFeeLamports || 0) + (q.rentFeeLamports || 0);
      $("sx-d-net").textContent = net ? "about " + nice(String(net / 1e9), 6) + " SOL" : "a tiny amount of SOL";
      var labels = []; (q.routePlan || []).forEach(function (s) { var l = s.swapInfo && s.swapInfo.label; if (l && labels.indexOf(l) < 0) labels.push(l); });
      $("sx-d-route").textContent = labels.length ? labels.join(" → ") : (q.router ? q.router : "Jupiter");
      var w = $("sx-warn");
      if (st.err) { w.hidden = false; w.className = "sx-warn bad"; w.textContent = st.err; }   // a failed or cancelled swap says so first
      else if (imp >= 3) { w.hidden = false; w.className = "sx-warn " + (imp >= 10 ? "bad" : ""); w.textContent = imp >= 10 ? "Very high price impact (" + imp.toFixed(1) + "%). You'd get much less than the market price. Try a smaller amount." : "Price impact is " + imp.toFixed(1) + "%. A smaller amount gets a better price."; }
      else w.hidden = true;
    } else {
      out.textContent = st.loading ? out.textContent : "0"; out.classList.toggle("zero", !st.loading);
      $("sx-usd-out").textContent = " ";
      $("sx-rate").hidden = true; $("sx-det").hidden = true; $("sx-det-b").setAttribute("aria-expanded", "false");
      var w2 = $("sx-warn");
      if (st.err) { w2.hidden = false; w2.className = "sx-warn bad"; w2.textContent = st.err; } else w2.hidden = true;
    }
    drawGo();
  }
  function drawGo() {
    var b = $("sx-go"), t = $("sx-go-t"), raw = toRaw(st.amt, st.tin.decimals), have = balRaw(st.tin);
    var label, ok = false;
    if (st.busy) { label = st.busy; }
    else if (!st.addr) { label = "Connect wallet"; ok = true; }
    else if (raw <= 0n) label = "Enter an amount";
    else if (have !== null && raw > have) label = "Not enough " + sym(st.tin);
    else if (st.loading && !st.quote) label = "Finding the best price...";
    else if (!st.quote) label = st.err ? "Try a different amount" : "Enter an amount";
    else { label = "Swap " + sym(st.tin) + " for " + sym(st.tout); ok = true; }
    t.textContent = label; b.disabled = !ok || !!st.busy;
    b.classList.toggle("busy", !!st.busy);
  }

  // the ring that counts down to the next fresh quote
  var ring = $("sx-ring-fg"), C = 2 * Math.PI * 15;
  if (ring) { ring.style.strokeDasharray = C; }
  setInterval(function () {
    if (document.hidden || st.busy) return;
    if (!st.quote || st.loading) { if (ring) ring.style.strokeDashoffset = C; return; }
    st.left--;
    if (ring) ring.style.strokeDashoffset = String(C * (1 - st.left / REFRESH));
    if (st.left <= 0) quote();
  }, 1000);
  $("sx-refresh").addEventListener("click", function () { if (!st.busy) { this.classList.remove("spin"); void this.offsetWidth; this.classList.add("spin"); quote(); } });

  // ---------------------------------------------------------------- amount, flip, quick pairs, slippage
  var amt = $("sx-amt");
  amt.addEventListener("input", function () {
    var v = amt.value.replace(/,/g, ".").replace(/[^\d.]/g, ""), i = v.indexOf(".");
    if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, "").slice(0, st.tin.decimals);
    if (v !== amt.value) amt.value = v;
    st.amt = v; st.quote = null; st.err = ""; drawQuote(); want();
  });
  document.querySelectorAll("[data-pct]").forEach(function (b) {
    b.addEventListener("click", function () {
      var have = balRaw(st.tin); if (have === null) return;
      var r = have * BigInt(b.dataset.pct) / 100n;
      if (st.tin.id === SOL && b.dataset.pct === "100") { var keep = toRaw(String(FEE_SOL), 9); r = r > keep ? r - keep : 0n; }
      st.amt = fromRaw(r, st.tin.decimals); amt.value = st.amt; st.quote = null; drawQuote(); quote();
    });
  });
  $("sx-flip").addEventListener("click", function () {
    var a = st.tin; st.tin = st.tout; st.tout = a;
    if (st.quote) { st.amt = fromRaw(st.quote.outAmount, st.tin.decimals); amt.value = st.amt; }
    this.classList.remove("turn"); void this.offsetWidth; this.classList.add("turn");
    drawTokens(); st.quote = null; drawQuote(); quote(); remember();
  });
  document.querySelectorAll(".sx-route").forEach(function (b) {
    b.addEventListener("click", function () {
      setPair(b.dataset.in, b.dataset.out);
    });
  });
  function setPair(inId, outId) {
    Promise.all([tokenById(inId), tokenById(outId)]).then(function (r) {
      if (!r[0] || !r[1]) return;
      if (r[0].id !== st.tin.id) { st.amt = ""; amt.value = ""; }   // the number was in the old token
      st.tin = r[0]; st.tout = r[1]; drawTokens(); st.quote = null; st.err = ""; drawQuote(); quote(); remember();
    });
  }
  function slipText() { return st.slip === "" ? "Auto" : (st.slip / 100) + "%"; }
  $("sx-slip-b").addEventListener("click", function () { var p = $("sx-slip"); p.hidden = !p.hidden; this.setAttribute("aria-expanded", p.hidden ? "false" : "true"); drawSlip(); });
  function drawSlip() { document.querySelectorAll("[data-slip]").forEach(function (b) { b.classList.toggle("on", b.dataset.slip === String(st.slip)); }); $("sx-slip-v").textContent = slipText(); }
  document.querySelectorAll("[data-slip]").forEach(function (b) { b.addEventListener("click", function () { st.slip = b.dataset.slip; $("sx-slip-in").value = ""; drawSlip(); quote(); remember(); }); });
  $("sx-slip-in").addEventListener("input", function () {
    var v = parseFloat(this.value.replace(",", "."));
    if (v > 0 && v <= 50) { st.slip = String(Math.round(v * 100)); drawSlip(); want(); remember(); }
  });
  $("sx-det-b").addEventListener("click", function () { var d = $("sx-det"); d.hidden = !d.hidden; this.setAttribute("aria-expanded", d.hidden ? "false" : "true"); this.classList.toggle("open", !d.hidden); });

  // ---------------------------------------------------------------- the token picker
  var pick = $("sx-pick"), list = $("sx-list"), qIn = $("sx-q"), sTimer = 0, sn = 0;
  function tokenById(id) {
    if (KNOWN[id]) return Promise.resolve(KNOWN[id]);
    var x = st.tokens.concat(st.bal ? st.bal.tokens : []).filter(function (t) { return t.id === id; })[0];
    if (x) { KNOWN[id] = x; return Promise.resolve(x); }
    return api({ a: "search", q: id }).then(function (j) { var t = j && j.tokens && j.tokens[0]; if (t) KNOWN[t.id] = t; return t || null; }).catch(function () { return null; });
  }
  function row(t) {
    var b = st.bal ? (t.id === SOL ? { raw: st.bal.sol } : st.bal.tokens.filter(function (k) { return k.id === t.id; })[0]) : null;
    var amtTxt = b && b.raw && b.raw !== "0" ? nice(fromRaw(b.raw, t.decimals)) : "";
    return '<button class="sx-trow" role="option" data-id="' + esc(t.id) + '">' + imgTag(t) + '<span><b>' + esc(sym(t)) + (t.verified ? ' <i class="sx-ver" title="Verified by Jupiter"></i>' : "") + '</b><small>' + esc(t.name) + ' &middot; ' + esc(short(t.id)) + '</small></span>' + (amtTxt ? '<em>' + esc(amtTxt) + '</em>' : "") + '</button>';
  }
  function openPick(side) {
    st.picking = side;
    $("sx-pick-h").textContent = side === "in" ? "You pay with" : "You receive";
    qIn.value = ""; drawPickList(); open(pick);
    setTimeout(function () { if (window.matchMedia("(min-width: 700px)").matches) qIn.focus(); }, 60);
    if (!st.tokens.length) api({ a: "tokens" }).then(function (j) { if (j && j.tokens) { st.tokens = j.tokens; j.tokens.forEach(function (t) { if (!KNOWN[t.id] || !KNOWN[t.id].icon) KNOWN[t.id] = t; }); fixKnownIcons(); drawPickList(); } }).catch(function () {});
  }
  function fixKnownIcons() { [st.tin, st.tout].forEach(function (t) { var k = KNOWN[t.id]; if (k && k.icon && !t.icon) t.icon = k.icon; }); drawTokens(); }
  function drawPickList() {
    var pop = st.tokens.slice(0, 8);
    $("sx-pop").innerHTML = pop.map(function (t) { return '<button data-id="' + esc(t.id) + '">' + imgTag(t) + esc(sym(t)) + '</button>'; }).join("");
    var seen = {}, rows = [];
    (st.bal ? [{ id: SOL, symbol: "SOL", name: "Solana", decimals: 9, icon: (KNOWN[SOL] && KNOWN[SOL].icon) || "" }].concat(st.bal.tokens) : []).concat(st.tokens).forEach(function (t) { if (!seen[t.id]) { seen[t.id] = 1; rows.push(t); } });
    list.innerHTML = rows.length ? (st.bal ? '<p class="sx-lh">Your tokens and popular ones</p>' : '<p class="sx-lh">Popular tokens</p>') + rows.map(row).join("") : '<div class="sx-load"><i></i><i></i><i></i><span>Loading tokens</span></div>';
    $("sx-pick-n").hidden = true;
  }
  //MC 2026-10-17 every key used to redraw the whole list with full size logos and fire a search, which crawled on
  //   phones. Now the list waits for a short pause in typing, shows at most 40 rows, and searches once.
  var fTimer = 0;
  qIn.addEventListener("input", function () {
    clearTimeout(sTimer); clearTimeout(fTimer);
    fTimer = setTimeout(filterNow, 140);
  });
  function filterNow() {
    var q = qIn.value.trim();
    if (!q) { ++sn; drawPickList(); return; }
    var ql = q.toLowerCase(), seen0 = {};
    var local = st.tokens.concat(st.bal ? st.bal.tokens : []).filter(function (t) { if (seen0[t.id]) return false; seen0[t.id] = 1; return (t.symbol + " " + t.name + " " + t.id).toLowerCase().indexOf(ql) >= 0; });
    list.innerHTML = (local.length ? local.slice(0, 40).map(row).join("") : "") + (q.length >= 2 ? '<div class="sx-load sx-more"><i></i><i></i><i></i><span>Searching</span></div>' : "");
    $("sx-pick-n").hidden = true;
    if (q.length < 2) return;
    sTimer = setTimeout(function () {
      var n = ++sn;
      api({ a: "search", q: q }).then(function (j) {
        if (n !== sn) return;
        var seen = {}, all = [];
        local.concat((j && j.tokens) || []).forEach(function (t) { if (!seen[t.id]) { seen[t.id] = 1; all.push(t); KNOWN[t.id] = KNOWN[t.id] || t; } });
        list.innerHTML = all.slice(0, 40).map(row).join("");
        var note = $("sx-pick-n");
        if (!all.length) { note.hidden = false; note.textContent = "No token found. Check the name, or paste the token's address."; }
        else note.hidden = true;
      }).catch(function () { if (n === sn) { var l = list.querySelector(".sx-more"); if (l) l.remove(); } });
    }, 260);
  }
  function choose(id) {
    tokenById(id).then(function (t) {
      if (!t) return;
      if (st.picking === "in") { if (t.id === st.tout.id) st.tout = st.tin; if (t.id !== st.tin.id) { st.amt = ""; amt.value = ""; } st.tin = t; }
      else { if (t.id === st.tin.id) st.tin = st.tout; st.tout = t; }
      close(pick); drawTokens(); st.quote = null; st.err = ""; drawQuote(); quote(); remember();
    });
  }
  list.addEventListener("click", function (e) { var b = e.target.closest("[data-id]"); if (b) choose(b.dataset.id); });
  $("sx-pop").addEventListener("click", function (e) { var b = e.target.closest("[data-id]"); if (b) choose(b.dataset.id); });
  $("sx-tok-in").addEventListener("click", function () { openPick("in"); });
  $("sx-tok-out").addEventListener("click", function () { openPick("out"); });

  // ---------------------------------------------------------------- dialogs
  var opener = null;
  //MC 2026-10-17 on iPhones the keyboard covered the bottom sheet and shoved it under the search box. On phones the
  //   picker now hangs from the top and its height follows the space left above the keyboard.
  var vv = window.visualViewport;
  function fitSheet() {
    if (!vv || pick.hidden) return;
    pick.style.setProperty("--sx-vh", Math.round(vv.height) + "px");
    pick.style.setProperty("--sx-vt", Math.round(vv.offsetTop) + "px");
  }
  if (vv) { vv.addEventListener("resize", fitSheet); vv.addEventListener("scroll", fitSheet); }
  function open(m) { opener = document.activeElement; m.hidden = false; if (m === pick) fitSheet(); requestAnimationFrame(function () { m.classList.add("in"); }); document.documentElement.classList.add("sx-lock"); }
  function close(m) { m.classList.remove("in"); setTimeout(function () { m.hidden = true; }, 200); document.documentElement.classList.remove("sx-lock"); if (opener && opener.focus) try { opener.focus({ preventScroll: true }); } catch (e) {} }
  [pick, $("sx-wal")].forEach(function (m) {
    m.addEventListener("click", function (e) { if (e.target === m || e.target.closest("[data-close]")) close(m); });
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") [pick, $("sx-wal")].forEach(function (m) { if (!m.hidden) close(m); }); });

  // ---------------------------------------------------------------- wallets (the Solana Wallet Standard)
  function addWallet(w) {
    try {
      if (!w || !w.features || !w.features["standard:connect"] || !w.features["solana:signTransaction"]) return;
      if (!(w.chains || []).some(function (c) { return String(c).indexOf("solana:") === 0; })) return;
      if (st.wallets.some(function (x) { return x === w || x.name === w.name; })) return;
      st.wallets.push(w); drawWallets();
      autoReconnect(w);
    } catch (e) {}
  }
  var reg = { register: function () { for (var i = 0; i < arguments.length; i++) addWallet(arguments[i]); return function () {}; } };
  window.addEventListener("wallet-standard:register-wallet", function (e) { try { e.detail(reg); } catch (err) {} });
  try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: reg })); } catch (e) {}
  function drawWallets() {
    var l = $("sx-wlist");
    //MC 2026-10-23 the browser's own wallets first; Trust Wallet and MetaMask (assets/wallets.js) join the list where the
    //   browser has neither, opening only to approve. The kit's wallets, once used, aren't listed twice.
    var rows = [];
    st.wallets.forEach(function (w, i) { if (!w.shyKit) rows.push('<button class="sx-wrow" data-w="' + i + '"><img alt="" src="' + esc(w.icon || "") + '"><b>' + esc(w.name) + '</b><span>Detected</span></button>'); });
    var own = rows.length;
    if (window.ShyWallets) ShyWallets.extras().forEach(function (x) { rows.push('<button class="sx-wrow" data-k="' + esc(x.id) + '"><img alt="" src="' + esc(x.icon) + '"><b>' + esc(x.name) + '</b><span>' + esc(x.sub) + '</span></button>'); });
    //MC 2026-10-18 on desktop the big two are always on the list: a wallet nobody has installed yet still deserves a
    //   door in, so a missing one shows with a Get link to its download page instead of not existing at all
    var mob0 = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (!mob0) [["Phantom", "https://phantom.com/download", "#9886e5", "#5a47c7"], ["Solflare", "https://www.solflare.com/download/", "#ffc24b", "#fc7227"]].forEach(function (g) {
      if (st.wallets.some(function (w) { return String(w.name || "").toLowerCase().indexOf(g[0].toLowerCase()) >= 0; })) return;
      var ic = "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' + g[2] + '"/><stop offset="1" stop-color="' + g[3] + '"/></linearGradient></defs><rect x="2" y="4" width="20" height="16" rx="4" fill="url(#g)"/><circle cx="16.5" cy="12" r="1.8" fill="#fff" opacity=".9"/></svg>');
      rows.push('<a class="sx-wrow" style="text-decoration:none;color:inherit" href="' + g[1] + '" target="_blank" rel="noopener"><img alt="" src="' + ic + '"><b>' + g[0] + '</b><span>Get</span></a>');
    });
    l.innerHTML = rows.join("");
    $("sx-wnone").hidden = rows.length > 0 || (mob0 && st.phOk);
    var ph = $("sx-wnone-ph"), mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (mobile && window.ShyEx && ShyEx.phantomLink) { ph.href = ShyEx.phantomLink; ph.textContent = "Open in Phantom"; ph.removeAttribute("target"); }
    var useApp = mobile && st.phOk && !own;
    $("sx-wph").hidden = !useApp;
    if (useApp) {
      $("sx-wnone").hidden = true;
      $("sx-wph-alt").href = (window.ShyEx && ShyEx.phantomLink) || "#";
      $("sx-wph-alt2").href = sfApp(SF_BROWSE);
      phPrep("phantom"); phPrep("solflare");
    }
  }
  $("sx-wlist").addEventListener("click", function (e) {
    var k = e.target.closest("[data-k]");
    if (k && window.ShyWallets) { connect(ShyWallets.kit(k.dataset.k)); return; }   //MC 2026-10-23 Trust Wallet, MetaMask
    var b = e.target.closest("[data-w]"); if (b) connect(st.wallets[+b.dataset.w]);
  });
  // a Trust Wallet or MetaMask session from last time comes back quietly (nothing opens)
  if (window.ShyWallets) ShyWallets.ready().then(function () {
    var last = ""; try { last = localStorage.getItem("shy-sx-wallet") || ""; } catch (e) {}
    var id = ShyWallets.kitFor(last); if (id && !st.addr) connect(ShyWallets.kit(id), true);
  });
  function connect(w, silent) {
    if (!w) return Promise.resolve();
    return w.features["standard:connect"].connect(silent ? { silent: true } : undefined).then(function (r) {
      var acct = (r && r.accounts && r.accounts[0]) || (w.accounts && w.accounts[0]);
      if (!acct) return;
      st.w = w; st.acct = acct; st.addr = acct.address; st.silent = !!silent;
      try { localStorage.setItem("shy-sx-wallet", w.name); } catch (e) {}
      if (!silent) close($("sx-wal"));
      drawMe(); loadBal(); drawGo();
      if (w.features["standard:events"]) try { w.features["standard:events"].on("change", function (p) { if (p && p.accounts) { var a = p.accounts[0]; if (!a) disconnect(true); else if (a.address !== st.addr) { st.acct = a; st.addr = a.address; drawMe(); loadBal(); } } }); } catch (e) {}
    }).catch(function (e) { if (!silent) toast(/reject|cancel|denied/i.test(String(e && e.message)) ? "You cancelled the connection." : "That wallet didn't connect. Try again."); });
  }
  function autoReconnect(w) {
    var last = ""; try { last = localStorage.getItem("shy-sx-wallet") || ""; } catch (e) {}
    if (!st.addr && last && w.name === last) connect(w, true);
  }
  function disconnect(quiet) {
    if (st.mode === "ph") { phForget(true); st.mode = ""; }
    var w = st.w; st.w = null; st.acct = null; st.addr = ""; st.bal = null;
    try { localStorage.removeItem("shy-sx-wallet"); } catch (e) {}
    if (!quiet && w && w.features["standard:disconnect"]) try { w.features["standard:disconnect"].disconnect(); } catch (e) {}
    drawMe(); drawBal(); drawGo();
  }
  // ---------------------------------------------------------------- Phantom approval from a phone with no wallet in the browser
  //MC 2026-10-17 in the Shilluminati home-screen app (or Safari, or Telegram) there's no wallet in the page, so Connect
  //   used to send people into Phantom's own browser, where they stayed. Now Phantom opens only to approve and sends
  //   them back: api/swap.php keeps the Phantom keys and sends the approved swap to Jupiter; this page holds a random
  //   handle and asks how it went. Both steps go through real links tapped by the player, since phones only open an
  //   app from a tap. On iPhone, Phantom hands back to Safari (iOS won't reopen a home-screen app for another app),
  //   so Safari shows the result, and the app shows it too as soon as the player switches back.
  //MC 2026-10-18 Solflare speaks the same deeplink protocol, so one flow carries both: each wallet gets its own
  //   prepared session, and the one the player taps becomes the live one
  var PH = { s: "", app: "phantom", sess: {}, t: 0, timer: 0, until: 0, prepping: 0, sign: "", signT: 0, seen: 0 };
  function phAppName() { return PH.app === "solflare" ? "Solflare" : "Phantom"; }
  try { PH.s = localStorage.getItem("shy-sx-ph") || ""; PH.app = localStorage.getItem("shy-sx-ph-a") || "phantom"; PH.seen = +localStorage.getItem("shy-sx-ph-t") || 0; } catch (e) {}
  var phBack = (function () {
    var u = new URL(location.href), id = u.searchParams.get("phs"), step = u.searchParams.get("ph");
    if (!id || !/^[a-f0-9]{32}$/.test(id)) return "";
    PH.s = id; try { localStorage.setItem("shy-sx-ph", id); } catch (e) {}
    u.searchParams.delete("phs"); u.searchParams.delete("ph");
    try { history.replaceState(null, "", u.pathname + (u.search || "") + u.hash); } catch (e) {}
    return step || "back";
  })();
  function phForget(tell) {
    if (tell && PH.s) try { fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "ph_end", s: PH.s }) }).catch(function () {}); } catch (e) {}
    PH.s = ""; PH.sess = {}; try { localStorage.removeItem("shy-sx-ph"); localStorage.removeItem("shy-sx-ph-a"); } catch (e) {}
  }
  //MC 2026-10-18 webviews (Telegram's above all) open the https universal link as the solflare.com website and drop
  //   the request, so Solflare links go out on the app's own scheme. If this page is still visible a moment after the
  //   tap, the app did not take over (not installed, or the scheme was blocked) and the https form opens instead.
  var SF_BROWSE = "https://solflare.com/ul/v1/browse/" + encodeURIComponent(location.origin + "/swap") + "?ref=" + encodeURIComponent(location.origin);
  function sfApp(u) { return (u || "").replace("https://solflare.com/", "solflare://"); }
  function sfFallback(e, url) {
    setTimeout(function () {
      if (!url || e.defaultPrevented) return;
      var t = setTimeout(function () { if (!document.hidden) location.href = url; }, 1700);
      document.addEventListener("visibilitychange", function h() { clearTimeout(t); document.removeEventListener("visibilitychange", h); });
    }, 0);
  }
  function phBtn(app) { return app === "solflare" ? $("sx-wph-go2") : $("sx-wph-go"); }
  function phPrep(app) {
    var go = phBtn(app), have = PH.sess[app];
    if (have && have.url) { go.href = app === "solflare" ? sfApp(have.url) : have.url; return; }
    if (have && have.wait) return;   // one request per wallet at a time
    PH.sess[app] = { wait: 1 };
    go.classList.add("busy"); go.removeAttribute("href");
    fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "ph_new", w: app }) }).then(function (r) { return r.json(); }).then(function (j) {
      go.classList.remove("busy");
      if (!j || !j.ok) { PH.sess[app] = null; toast("The wallet link isn't ready. Try again in a moment."); return; }
      PH.sess[app] = { s: j.s, url: j.url };
      go.href = app === "solflare" ? sfApp(j.url) : j.url;
    }).catch(function () { PH.sess[app] = null; go.classList.remove("busy"); });
  }
  [$("sx-wph-go"), $("sx-wph-go2")].forEach(function (go) {
    go.addEventListener("click", function (e) {
      var app = go.getAttribute("data-w") || "phantom", have = PH.sess[app];
      if (!have || !have.url) { e.preventDefault(); phPrep(app); return; }
      if (app === "solflare") sfFallback(e, have.url);
      PH.s = have.s; PH.app = app; have.url = "";   // a connect link works once; a fresh one is made next time
      try { localStorage.setItem("shy-sx-ph", PH.s); localStorage.setItem("shy-sx-ph-a", app); } catch (e2) {}
      phWatch();
    });
  });
  $("sx-wph-alt2").addEventListener("click", function (e) { sfFallback(e, SF_BROWSE); });
  function phSet(wallet) {
    st.mode = "ph"; st.addr = wallet; st.acct = null; st.w = { name: phAppName(), icon: "" };
    drawMe(); loadBal(); drawGo();
  }
  function phState(first) {
    if (!PH.s) return;
    api({ a: "ph_state", s: PH.s }).then(function (j) {
      if (!j || !j.ok) return;
      if (j.gone) { if (st.mode === "ph") disconnect(true); phForget(false); return; }
      if (j.app && j.app !== PH.app) { PH.app = j.app; try { localStorage.setItem("shy-sx-ph-a", j.app); } catch (e) {} }
      if (j.wallet && (st.mode === "ph" || !st.addr) && st.addr !== j.wallet) phSet(j.wallet);
      var l = j.last;
      if (l && l.t > PH.seen && (!first || phBack)) { PH.seen = l.t; try { localStorage.setItem("shy-sx-ph-t", String(l.t)); } catch (e) {} phResult(l); }
      else if (l && first && l.t > PH.seen) { PH.seen = l.t; try { localStorage.setItem("shy-sx-ph-t", String(l.t)); } catch (e) {} if (l.st === "sign" && l.ok && Date.now() / 1000 - l.t < 600) phResult(l); }
    }).catch(function () {});
  }
  function phWatch() {
    clearInterval(PH.timer); PH.until = Date.now() + 4 * 60000;
    PH.timer = setInterval(function () { if (Date.now() > PH.until) { clearInterval(PH.timer); PH.timer = 0; if (/^Waiting for /.test(String(st.busy))) busy(""); return; } if (!document.hidden) phState(); }, 2500);
  }
  document.addEventListener("visibilitychange", function () { if (!document.hidden && PH.s && (PH.timer || st.mode === "ph")) phState(); });
  window.addEventListener("pageshow", function (e) { if (e.persisted && PH.s) phState(); });
  function phResult(l) {
    clearInterval(PH.timer); PH.timer = 0;
    if (l.st === "connect") {
      if (l.ok) { close($("sx-wal")); toast(phAppName() + " connected."); }
      else toast(l.err === "cancel" ? "You cancelled it in " + phAppName() + "." : (l.err || phAppName() + " didn't connect. Try again."));
      return;
    }
    phSignReset(); busy("");
    if (l.ok && l.sig) {
      var tout = KNOWN[l.out] || (st.tout.id === l.out ? st.tout : null);
      var txt = l.got && tout ? "You got " + nice(fromRaw(l.got, tout.decimals)) + " " + sym(tout) + "." : "";
      var toShy = l.out === SHY;
      if (window.ShyEx && ShyEx.done) ShyEx.done(l.sig, toShy, (toShy ? txt + " Connect this wallet in Shilluminati Online to unlock holder perks: shop discounts, weekly Koban and holder-only events." : txt + " It's on Solana for good, and you can check it any time.") + (phBack && /iPhone|iPad|iPod/i.test(navigator.userAgent) && !navigator.standalone ? " Back in the Shilluminati app it shows up too." : ""));
      st.amt = ""; amt.value = ""; st.quote = null; drawQuote();
      setTimeout(loadBal, 2500); setTimeout(loadBal, 9000);
    } else {
      st.err = l.err === "cancel" ? "You cancelled it in " + phAppName() + ". Nothing was spent." : (l.err || "The swap didn't go through. Nothing was spent. Try again.");
      drawQuote();
    }
  }
  // the swap: get the order ready, then a real link the player taps to approve it in Phantom
  function phSwap(raw) {
    var tin = st.tin, tout = st.tout;
    busy("Getting your swap ready...");
    fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "ph_sign", s: PH.s, inputMint: tin.id, outputMint: tout.id, amount: raw.toString(), slippageBps: st.slip }) }).then(function (r) { return r.json(); }).then(function (j) {
      busy("");
      if (!j || !j.ok || !j.url) {
        if (j && /^Connect .{1,12} again/.test(String(j.error || ""))) { disconnect(true); toast("Connect " + phAppName() + " again."); return; }
        st.err = friendly(j); drawQuote(); return;
      }
      var a = $("sx-phgo"); a.href = PH.app === "solflare" ? sfApp(j.url) : j.url; a.dataset.web = j.url; a.textContent = "Approve in " + phAppName(); a.hidden = false; $("sx-go").hidden = true;
      PH.signT = Date.now();
      clearTimeout(PH.sign); PH.sign = setTimeout(function () { if (!$("sx-phgo").hidden) { phSignReset(); st.err = "That price ran out. Tap Swap for a fresh one."; drawQuote(); } }, 50000);
    }).catch(function () { busy(""); st.err = "Can't reach the swap right now. Check your connection."; drawQuote(); });
  }
  function phSignReset() { clearTimeout(PH.sign); $("sx-phgo").hidden = true; $("sx-go").hidden = false; }
  $("sx-phgo").addEventListener("click", function (e) {
    if (PH.app === "solflare") sfFallback(e, this.dataset.web || "");
    var a = this; setTimeout(function () { a.hidden = true; $("sx-go").hidden = false; busy("Waiting for " + phAppName() + "..."); }, 50);
    phWatch();
  });

  function drawMe() {
    var m = $("sx-me");
    m.hidden = !st.addr;
    if (st.addr) m.innerHTML = (st.w && st.w.icon ? '<img alt="" src="' + esc(st.w.icon) + '">' : "") + esc(short(st.addr)) + ' <i title="Disconnect">&times;</i>';
  }
  $("sx-me").addEventListener("click", function () { disconnect(); toast("Wallet disconnected."); });
  function loadBal() {
    if (!st.addr) return;
    var a = st.addr;
    api({ a: "balances", owner: a }).then(function (j) {
      if (a !== st.addr || !j || !j.ok) return;
      st.bal = { sol: j.sol || "0", tokens: j.tokens || [] };
      if (j.solUsd) st.tin.id === SOL ? (st.tin.usd = j.solUsd) : (KNOWN[SOL].usd = j.solUsd);
      j.tokens.forEach(function (t) { if (!KNOWN[t.id]) KNOWN[t.id] = t; });
      drawBal(); drawGo();
    }).catch(function () {});
  }

  // ---------------------------------------------------------------- the swap
  $("sx-go").addEventListener("click", function () {
    if (!st.addr) { drawWallets(); open($("sx-wal")); return; }
    swap();
  });
  function swap() {
    var raw = toRaw(st.amt, st.tin.decimals); if (raw <= 0n || st.busy) return;
    if (st.mode === "ph") { phSwap(raw); return; }
    var tin = st.tin, tout = st.tout, acct = st.acct, w = st.w, rid = "", step = "connect";
    busy("Getting your swap ready...");
    //MC 2026-10-17 a wallet put back by the silent reconnect on page load can fail the first signing request (Phantom on
    //   iPhone showed "Unknown Error", the second try worked). A normal connect first opens the session properly; a
    //   wallet that already trusts the site answers it straight away without asking.
    var ready = st.silent ? w.features["standard:connect"].connect().then(function (r) { st.silent = false; var a = r && r.accounts && r.accounts[0]; if (a && a.address === st.addr) acct = st.acct = a; }).catch(function () { st.silent = false; }) : Promise.resolve();
    ready.then(function () { step = "order"; return api({ a: "order", inputMint: tin.id, outputMint: tout.id, amount: raw.toString(), slippageBps: st.slip, taker: st.addr }); }).then(function (q) {
      if (!q || !q.transaction) throw new Error(friendly(q));
      st.quote = q; drawQuote(); rid = q.requestId;
      busy("Approve it in your wallet..."); step = "sign";
      return w.features["solana:signTransaction"].signTransaction({ account: acct, transaction: b64ToBytes(q.transaction), chain: "solana:mainnet" });
    }).then(function (res) {
      var out = Array.isArray(res) ? res[0] : res;
      var signed = out && (out.signedTransaction || out.transaction);
      if (!signed) throw new Error("Your wallet didn't return the signed swap.");
      busy("Swapping..."); step = "send";
      return fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "execute", signedTransaction: bytesToB64(new Uint8Array(signed)), requestId: rid }) }).then(function (r) { return r.json(); });
    }).then(function (x) {
      busy("");
      if (x && x.status === "Success" && x.signature) {
        var got = x.outputAmountResult || x.totalOutputAmount || (st.quote && st.quote.outAmount);
        var txt = got ? "You got " + nice(fromRaw(got, tout.decimals)) + " " + sym(tout) + "." : "";
        if (window.ShyEx && ShyEx.done) ShyEx.done(x.signature, tout.id === SHY, tout.id === SHY ? txt + " Connect this wallet in Shilluminati Online to unlock holder perks: shop discounts, weekly Koban and holder-only events." : txt + " It's on Solana for good, and you can check it any time.");
        st.amt = ""; amt.value = ""; st.quote = null; drawQuote();
        setTimeout(loadBal, 2500); setTimeout(loadBal, 9000);
      } else {
        st.err = x && x.error ? friendly({ error: x.error }) : "The swap didn't go through" + (x && x.code != null ? " (code " + x.code + ")" : "") + ". Nothing was taken except possibly a tiny network fee. Get a new price and try again.";
        drawQuote();   // the message stays until they change something; the ring brings a fresh price
      }
    }).catch(function (e) {
      busy("");
      var m = String(e && e.message || "");
      if (/reject|cancel|denied|declined|user/i.test(m)) st.err = "You cancelled it in your wallet. Nothing was spent.";
      else {
        if (step === "sign" || step === "connect") {
          try { fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "err", m: m || String(e && e.code || "no message"), w: w && w.name, step: step, mob: /Mobi|iPhone|Android/i.test(navigator.userAgent) ? 1 : 0 }) }).catch(function () {}); } catch (x) {}
          st.err = "Your wallet hit a snag before signing. Nothing was spent. Tap Swap to try again.";
        } else st.err = m || "Something went wrong. Nothing was spent. Try again.";
      }
      drawQuote();
    });
  }
  function busy(t) { st.busy = t; drawGo(); $("sx-swap").classList.toggle("working", !!t); }
  function toast(t) { var el = $("toast"); if (!el) return; var was = el.textContent; el.textContent = t; el.classList.add("show"); setTimeout(function () { el.classList.remove("show"); el.textContent = was; }, 2200); }

  // ---------------------------------------------------------------- remember the pair and slippage, links in
  function remember() { try { localStorage.setItem("shy-sx", JSON.stringify({ i: st.tin.id, o: st.tout.id, s: st.slip })); } catch (e) {} }
  (function start() {
    var p = {}; try { p = JSON.parse(localStorage.getItem("shy-sx") || "{}") || {}; } catch (e) {}
    var m = /[?&]out=([1-9A-HJ-NP-Za-km-z]{32,44})/.exec(location.search), mi = /[?&]in=([1-9A-HJ-NP-Za-km-z]{32,44})/.exec(location.search);
    if (p.s != null) st.slip = String(p.s);
    drawSlip(); drawTokens(); drawQuote();
    var inId = mi ? mi[1] : (p.i || SOL), outId = m ? m[1] : (p.o || SHY);
    if (inId !== SOL || outId !== SHY) setPair(inId, outId);
    if (PH.s) setTimeout(function () { phState(true); }, phBack ? 0 : 900);   // after any wallet in the page has had its turn
    api({ a: "cfg" }).then(function (j) { if (j && j.ok) { st.fee = j.fee || 0; st.search = !!j.search; st.phOk = !!j.ph; if (!$("sx-wal").hidden) drawWallets(); } }).catch(function () {});
    api({ a: "tokens" }).then(function (j) { if (j && j.tokens) { st.tokens = j.tokens; j.tokens.forEach(function (t) { if (!KNOWN[t.id] || !KNOWN[t.id].icon) { if (KNOWN[t.id]) { KNOWN[t.id].icon = t.icon; KNOWN[t.id].name = t.name; } else KNOWN[t.id] = t; } }); fixKnownIcons(); } }).catch(function () {});
    // a first quote for 1 SOL so the rate shows straight away
    if (!st.amt) { amt.value = ""; }
  })();
  window.ShySwap = { pair: function () { return { in: st.tin.id, out: st.tout.id }; } };
})();
