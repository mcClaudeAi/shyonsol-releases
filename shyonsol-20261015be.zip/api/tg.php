<?php
// Telegram: post game results, the daily and weekly wrap-ups and big shop purchases to the $SHY chat, link players'
// Telegram accounts to their game profiles, and send linked players the reminders they asked for.
// Uses a Telegram bot (free, made with @BotFather). The bot token and chat live in shy-data/telegram.php, set in the admin.
// Messages are queued while a request runs and sent after the player already has their answer, so Telegram never slows the game.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('TGCFG', DATA_DIR . '/telegram.php');
define('TGLINKS', DATA_DIR . '/tg-links.php');   // ['u' => tg user id => link, 'p' => pid => tg user id, 'c' => link code => [pid, exp]]
const TG_KINDS = ['live' => 'Live matches', 'daily_run' => 'Daily Challenge runs', 'solo' => 'Solo wins', 'daily' => 'Daily wrap-up', 'weekly' => 'Weekly League results', 'buy' => 'Shop purchases', 'tourney' => 'Tournaments', 'release' => 'New releases', 'daily_am' => 'Daily Challenge morning call', 'partner' => 'Joint events in partner groups', 'bounty' => '15 Club bounty', 'payout' => 'Prize payouts', 'burn' => 'Burn tracker (pinned)', 'boss' => 'Wins against the Shogun', 'boss_loss' => 'Losses to the Shogun', 'idea' => 'Approved ideas', 'drop' => 'Limited drops'];   //MC 2026-10-13
// what a linked player can be messaged about, and what's on until they say otherwise
const TG_NOTES = ['streak' => 'Streak reminders', 'daily' => 'New Daily Challenge', 'tourney' => 'Tournaments', 'friends' => 'Friends, challenges and Duels'];
const TG_NOTES_ON = ['streak' => true, 'daily' => true, 'tourney' => true, 'friends' => true];
// a player's reminders: the defaults until they pick their own (with /notify or on their profile)
function tg_notes($u) { return $u && !empty($u['nset']) ? ($u['n'] ?? []) + TG_NOTES_ON : TG_NOTES_ON; }
const TG_HOOK_V = 5;   // bump when the webhook needs new update types (5: re-sends the command list, for /shilluminatiboss)

//MC 2026-10-10 what each kind does when the saved settings don't mention it. Settings saved before a kind existed
//   leave it out; a missing kind now always means its default here, while one switched off (false) stays off.
const TG_ON = ['live' => true, 'daily_run' => false, 'solo' => false, 'daily' => true, 'weekly' => true, 'buy' => true, 'tourney' => true, 'release' => true, 'daily_am' => true, 'partner' => true, 'bounty' => true, 'payout' => true, 'burn' => true, 'boss' => true, 'boss_loss' => true, 'idea' => true, 'drop' => true];
function tg_on($c, $kind) {
    $on = is_array($c['on'] ?? null) ? $c['on'] : [];
    return array_key_exists($kind, $on) && $on[$kind] !== null ? !empty($on[$kind]) : !empty(TG_ON[$kind]);
}
function tg_cfg() {
    $c = load(TGCFG);
    $on = TG_ON;
    if (isset($c['on']) && !is_array($c['on'])) unset($c['on']);   //MC 2026-10-10 a damaged switch list reads as the defaults
    if (isset($c['on'])) { foreach ($c['on'] as $k => $v) if ($v === null) unset($c['on'][$k]); $c['on'] += $on; }   // kinds added after the bot was set up start out on
    if (isset($c['design_on'])) $c['design_on'] += ['art_up' => true, 'art_pub' => true];
    return $c + ['token' => '', 'chat' => '', 'title' => '', 'on' => $on,
        'buy_min' => 9.99, 'hour_cap' => 8, 'sent' => [], 'once' => [], 'app' => '', 'dm_on' => true, 'remind_hour' => 18, 'remind_min' => 2, 'daily_hour' => 13,
        'design_chat' => '', 'design_title' => '', 'design_topic' => '', 'design_on' => ['art_up' => true, 'art_pub' => true]];
}
//MC 2026-10-11 every change to telegram.php is made holding tg-lock, the lock tg_flush and the pin updates already use.
//   The admin's Telegram settings saved it under the site lock instead, so a flush a moment later could put the old
//   settings back. Nested calls run straight through.
function tg_locked($fn) {
    static $held = false;
    if ($held) return $fn();
    $lf = @fopen(DATA_DIR . '/tg-lock.php', 'c');
    if (!$lf) return $fn();
    $held = true;
    try { return lock_run($lf, $fn); } finally { $held = false; }
}
function tg_ready($c = null) { $c = $c ?? tg_cfg(); return $c['token'] !== '' && $c['chat'] !== ''; }
function tg_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

//MC 2026-10-10 the burn tracker: one message in the chat, pinned once, that always shows the total $SHY the game has burned
//   and the latest burn. Every burn edits it in place instead of pinning a new post, so the group's other pins stay put
//   and nobody gets a pin notice per purchase. If the message was deleted it's posted and pinned again.
//   Pinning needs the bot to be an admin with "Pin messages"; if it can't, the message still posts and updates.
function tg_burn($shy, $sig, $what) { tg_hook(); $GLOBALS['TG_BURN'] = ['shy' => $shy, 'sig' => $sig, 'w' => $what, 't' => time()]; }
function tg_burn_text($b) {
    $t = function_exists('burn_totals') ? burn_totals() : ['shy' => $b['shy'], 'n' => 1];
    $pct = (int)(eco_settings()['burn_pct'] ?? 0);
    return "🔥 <b>\$SHY burned by the game</b>\n\n" .
        'Total burned: <b>' . number_format($t['shy']) . ' $SHY</b> in ' . number_format($t['n']) . ($t['n'] === 1 ? ' burn' : ' burns') . "\n" .
        'Latest: <b>' . number_format($b['shy']) . ' $SHY</b>' . ($b['w'] !== '' ? ' from ' . tg_h($b['w']) : '') . ', ' . gmdate('M j, H:i', $b['t']) . ' UTC' . ($b['sig'] !== '' ? ' (<a href="https://solscan.io/tx/' . tg_h($b['sig']) . '">proof</a>)' : '') . "\n\n" .
        ($pct ? $pct . '% of every $SHY payment in the Dojo Shop is burned in the buyer\'s own transaction. ' : '') . 'Every burn is on the ' . tg_link('/treasury', 'Treasury') . '.';
}
function tg_burn_update($b) {
    $lf = @fopen(DATA_DIR . '/tg-lock.php', 'c'); if (!$lf) return;
    flock($lf, LOCK_EX);
    try {
        $c = tg_cfg(); if ($c['token'] === '' || $c['chat'] === '') return;
        $text = tg_burn_text($b);
        $id = (int)($c['burn_msg'] ?? 0);
        if ($id && ($c['burn_chat'] ?? '') === $c['chat']) {
            $j = tg_api($c['token'], 'editMessageText', ['chat_id' => $c['chat'], 'message_id' => $id, 'text' => $text, 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]]);
            if (!empty($j['ok']) || stripos((string)($j['description'] ?? ''), 'not modified') !== false) {
                // it couldn't be pinned before (the bot wasn't an admin yet): try again now
                if (!empty($c['burn_pin'])) { $p = tg_api($c['token'], 'pinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $id, 'disable_notification' => true]); $c['burn_pin'] = !empty($p['ok']) ? '' : mb_substr((string)($p['description'] ?? 'no answer'), 0, 120); }
                $c['burn_at'] = time(); save(TGCFG, $c);   //MC 2026-10-12 when it last changed, for Admin > Telegram
                return;
            }
            tg_err_log('burn tracker edit: ' . ($j['description'] ?? 'no answer'));
        }
        $j = tg_api($c['token'], 'sendMessage', ['chat_id' => $c['chat'], 'text' => $text, 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]]);
        if (empty($j['ok'])) return;
        $c['burn_msg'] = (int)($j['result']['message_id'] ?? 0); $c['burn_chat'] = $c['chat'];
        $p = tg_api($c['token'], 'pinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $c['burn_msg'], 'disable_notification' => true]);
        $c['burn_pin'] = !empty($p['ok']) ? '' : mb_substr((string)($p['description'] ?? 'no answer'), 0, 120);
        $c['burn_at'] = time();
        save(TGCFG, $c);
    } finally { flock($lf, LOCK_UN); fclose($lf); }
}
//MC 2026-10-12 Admin > Telegram > Post the burn tracker again. The tracker is one message edited in place on every burn, so
//   once it scrolls up (or someone unpins it) new burns change a message nobody sees and nothing new shows in the chat.
//   This deletes the old one and posts a fresh tracker at the bottom with the current totals, pinned quietly.
//   Returns '' when it worked, otherwise what Telegram said.
function tg_burn_repost() {
    $c = tg_cfg(); if (!tg_ready($c)) return 'Connect the bot and pick the chat first.';
    $old = (int)($c['burn_msg'] ?? 0);
    if ($old && ($c['burn_chat'] ?? '') === $c['chat']) { tg_api($c['token'], 'unpinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $old]); tg_api($c['token'], 'deleteMessage', ['chat_id' => $c['chat'], 'message_id' => $old]); }
    tg_locked(function () { $c = tg_cfg(); $c['burn_msg'] = 0; save(TGCFG, $c); });
    $last = ['shy' => 0, 'sig' => '', 'w' => '', 't' => time()];
    foreach (load(ORDERS) as $o) {
        if (($o['status'] ?? '') !== 'paid' || !empty($o['selfpay'])) continue;
        $amt = (float)($o['burned'] ?? 0) + (float)($o['burn_done'] ?? 0); if ($amt <= 0) continue;
        $t = (int)($o['paid'] ?? 0);
        if ($last['shy'] == 0 || $t >= $last['t']) { $pn = function_exists('eco_product') ? (eco_product($o['product'] ?? '')['name'] ?? '') : ''; $last = ['shy' => (int)round($amt / 10 ** (int)($o['dec'] ?? 6)), 'sig' => (string)($o['proof'] ?? ''), 'w' => $pn !== '' ? 'a ' . $pn : '', 't' => $t ?: time()]; }
    }
    tg_burn_update($last);
    $c = tg_cfg();
    if (empty($c['burn_msg'])) return 'Telegram did not take the post. Check Logs for the reason.';
    return $c['burn_pin'] !== '' && !empty($c['burn_pin']) ? 'Posted, but it could not be pinned: ' . $c['burn_pin'] : '';
}
//MC 2026-10-10 prize payouts go to the chat and stay pinned until the next payout replaces them. Pinned quietly
//   (disable_notification), and only the last payout pin is taken down: the burn tracker and the group's own pins stay.
//   The message id is kept as payout_msg/payout_chat; if the pin fails (bot not an admin yet) the reason is kept in
//   payout_pin and tg_tick tries again every 15 minutes, the same way the burn tracker does.
function tg_payout($html, $once = '') {
    tg_hook();
    $GLOBALS['TG_Q'][] = ['k' => 'payout', 'h' => $html, 'o' => $once, 'kb' => null, 'img' => '', 'pin' => 'payout'];
}
function tg_payout_pin($id, $retry = false) {
    if (!$id) return;
    $lf = @fopen(DATA_DIR . '/tg-lock.php', 'c'); if (!$lf) return;
    flock($lf, LOCK_EX);
    try {
        $c = tg_cfg(); if ($c['token'] === '' || $c['chat'] === '') return;
        $old = (int)($c['payout_msg'] ?? 0);
        if (!$retry && $old && $old !== $id && ($c['payout_chat'] ?? '') === $c['chat'] && $old !== (int)($c['burn_msg'] ?? 0))
            tg_api($c['token'], 'unpinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $old]);
        $p = tg_api($c['token'], 'pinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $id, 'disable_notification' => true]);
        $c['payout_msg'] = $id; $c['payout_chat'] = $c['chat']; $c['payout_try'] = time();
        $c['payout_pin'] = !empty($p['ok']) ? '' : mb_substr((string)($p['description'] ?? 'no answer'), 0, 120);
        save(TGCFG, $c);
    } finally { flock($lf, LOCK_UN); fclose($lf); }
}
function tg_api($token, $method, $params, $timeout = 8) {
    $base = shy_config()['tg_api'] ?? 'https://api.telegram.org';   // tg_api only for local testing
    $ch = curl_init($base . '/bot' . $token . '/' . $method);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode($params),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 4]);
    $raw = curl_exec($ch);
    curl_close($ch);
    $j = json_decode((string)$raw, true);
    if (empty($j['ok'])) @file_put_contents(DATA_DIR . '/telegram-errors.log', gmdate('c') . " $method " . substr((string)$raw, 0, 300) . "\n", FILE_APPEND);
    return $j;
}

// ---------------------------------------------------------------- links to the game
function tgl() { $l = load(TGLINKS); return $l + ['u' => [], 'p' => [], 'c' => [], 'h' => []]; }
function tg_user_of($pid) { $l = tgl(); $t = $l['p'][$pid] ?? null; return $t !== null && isset($l['u'][$t]) ? ['id' => $t] + $l['u'][$t] : null; }
function tg_pid_of($tgid) { $l = tgl(); return $l['u'][(string)$tgid]['pid'] ?? null; }
// tie a Telegram user to a game profile (each side can only have one). Call inside with_lock.
function tg_link_set($tgid, $pid, $who, $dm = null) {
    $tgid = (string)$tgid;
    $l = tgl();
    $old = $l['u'][$tgid] ?? null;
    if ($old && $old['pid'] !== $pid) unset($l['p'][$old['pid']]);
    $prevT = $l['p'][$pid] ?? null;
    if ($prevT !== null && $prevT !== $tgid) unset($l['u'][$prevT]);
    if (!$old && function_exists('track')) track('tg_links');   //MC 2026-10-09 new Telegram links, for the reports
    $l['u'][$tgid] = ['pid' => $pid, 'un' => mb_substr((string)($who['username'] ?? ''), 0, 40), 'fn' => mb_substr((string)($who['first_name'] ?? ''), 0, 40),
        'at' => $old['at'] ?? time(), 'dm' => $dm ?? ($old['dm'] ?? false), 'n' => $old['n'] ?? [], 'nset' => $old['nset'] ?? false, 'last' => $old['last'] ?? []];
    $l['p'][$pid] = $tgid;
    save(TGLINKS, $l);
    return $l['u'][$tgid];
}
function tg_unlink($pid) {
    $l = tgl(); $t = $l['p'][$pid] ?? null;
    if ($t === null) return false;
    unset($l['p'][$pid], $l['u'][$t]); save(TGLINKS, $l); return true;
}
// a short code the player takes to the bot (t.me/bot?start=link_CODE) to prove which profile is theirs
function tg_link_code($pid) {
    $l = tgl();
    $now = time();
    $l['c'] = array_filter($l['c'], fn($c) => $c['exp'] > $now && $c['pid'] !== $pid);
    $a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $code = '';
    for ($i = 0; $i < 10; $i++) $code .= $a[random_int(0, strlen($a) - 1)];
    $l['c'][$code] = ['pid' => $pid, 'exp' => $now + 900];
    save(TGLINKS, $l);
    return $code;
}
function tg_take_code($code) {
    $l = tgl(); $c = $l['c'][$code] ?? null;
    if (!$c) return null;
    unset($l['c'][$code]); save(TGLINKS, $l);
    return $c['exp'] > time() ? $c['pid'] : null;
}
// Telegram Mini App sign-in: check the signed initData the app hands us (https://core.telegram.org/bots/webapps)
function tg_webapp_user($initData, $token) {
    if ($token === '' || !is_string($initData) || strlen($initData) > 4096) return null;
    parse_str($initData, $f);
    $hash = (string)($f['hash'] ?? ''); unset($f['hash']);
    if ($hash === '') return null;
    ksort($f);
    $check = implode("\n", array_map(fn($k, $v) => $k . '=' . $v, array_keys($f), $f));
    $secret = hash_hmac('sha256', $token, 'WebAppData', true);
    if (!hash_equals(hash_hmac('sha256', $check, $secret), $hash)) return null;
    if ((int)($f['auth_date'] ?? 0) < time() - 86400) return null;   // older than a day: open the app again
    $u = json_decode((string)($f['user'] ?? ''), true);
    if (!is_array($u) || empty($u['id'])) return null;
    return ['user' => $u, 'start' => (string)($f['start_param'] ?? '')];
}

// links into the game: the Mini App inside Telegram when it's set up, otherwise the website
function tg_app_url($start = '') {
    $c = tg_cfg();
    if (!empty($c['bot']) && !empty($c['app'])) return 'https://t.me/' . $c['bot'] . '/' . $c['app'] . ($start !== '' ? '?startapp=' . rawurlencode($start) : '');
    $q = '';
    if (strpos($start, 'room_') === 0) $q = '?room=' . rawurlencode(substr($start, 5));
    elseif (strpos($start, 'join_') === 0) $q = '?room=' . rawurlencode(substr($start, 5)) . '&go=1';   //MC 2026-10-10 challenges join on arrival
    elseif (strpos($start, 'duelvs_') === 0) $q = '?duelvs=' . rawurlencode(substr($start, 7));
    elseif (strpos($start, 'duel_') === 0) $q = '?duel=' . rawurlencode(substr($start, 5)) . '&go=1';   //MC 2026-10-10 same as the mini app: Play the Duel starts it
    elseif (strpos($start, 'friend_') === 0) $q = '?friend=' . rawurlencode(substr($start, 7));
    elseif ($start === 'friends') $q = '?friends=1';
    elseif ($start === 'boss') $q = '?boss=1';   //MC 2026-10-12 straight into a match against the Shogun
    //MC 2026-10-09 tracked links (src_tg-groupname) fall back to ?ref= on the website when the Mini App isn't set up
    elseif (strpos($start, 'src_') === 0) $q = '?ref=' . rawurlencode(strtolower(substr($start, 4)));
    return TG_SITE . '/play' . $q;
}
function tg_kb($label, $start = '') { return ['inline_keyboard' => [[['text' => $label, 'url' => tg_app_url($start)]]]]; }
// in a private chat the button can open the game right inside Telegram
function tg_kb_private($label = '🎴 Play now') { return ['inline_keyboard' => [[['text' => $label, 'web_app' => ['url' => TG_SITE . '/play?tgapp=1']]]]]; }

// ---------------------------------------------------------------- sending
// queue a message for the chat: kind decides if it's switched on; once = a key so it's only ever sent one time
function tg_post($kind, $html, $once = '', $kb = null, $img = '') {
    tg_hook();
    $GLOBALS['TG_Q'][] = ['k' => $kind, 'h' => $html, 'o' => $once, 'kb' => $kb, 'img' => $img];
}
// queue a private message to one linked player
function tg_dm($tgid, $html, $kb = null) {
    tg_hook();
    $GLOBALS['TG_DM'][] = ['t' => (string)$tgid, 'h' => $html, 'kb' => $kb];
}
// queue a post for the team's Game Design channel, with a picture from a file on the server (sent as an upload,
// so it works for images players can't see yet). The file is removed once it has been sent.
// $reply: a message id in that chat to answer, so a follow-up sits under the post it's about.
// $done: called with Telegram's answer once sent (for keeping the message id).
function tg_design($kind, $html, $imgFile = '', $kb = null, $reply = 0, $done = null) {
    tg_hook();
    $GLOBALS['TG_DS'][] = ['k' => $kind, 'h' => $html, 'f' => $imgFile, 'kb' => $kb, 'r' => (int)$reply, 'cb' => $done];
}
// a JPEG copy of any image for Telegram, at most $max px on the long side; returns a temp file path or ''
function tg_jpeg_copy($src, $max = 1600) {
    $raw = @file_get_contents($src);
    $im = $raw !== false ? @imagecreatefromstring($raw) : false;
    if (!$im) return '';
    $w = imagesx($im); $h = imagesy($im); $k = min(1, $max / max($w, $h));
    $nw = max(1, (int)round($w * $k)); $nh = max(1, (int)round($h * $k));
    $out = imagecreatetruecolor($nw, $nh);
    imagefill($out, 0, 0, imagecolorallocate($out, 18, 12, 44));   // transparent corners on the site's own dark, not black
    imagecopyresampled($out, $im, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $f = @tempnam(DATA_DIR, 'shyart') ?: @tempnam(sys_get_temp_dir(), 'shyart');   // shy-data first: some hosts lock the system temp folder
    $ok = $f && @imagejpeg($out, $f, 86);
    imagedestroy($im); imagedestroy($out);
    if (!$ok) { if ($f) @unlink($f); return ''; }
    return $f;
}
// a Bot API call with a file attached (multipart), for photos that aren't on a public web address
function tg_api_file($token, $method, $params, $field, $path, $timeout = 20) {
    $base = shy_config()['tg_api'] ?? 'https://api.telegram.org';
    $post = [];
    foreach ($params as $k => $v) $post[$k] = is_array($v) ? json_encode($v) : (string)$v;
    $post[$field] = new CURLFile($path, 'image/jpeg', 'art.jpg');
    $ch = curl_init($base . '/bot' . $token . '/' . $method);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $post, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 4]);
    $raw = curl_exec($ch);
    curl_close($ch);
    $j = json_decode((string)$raw, true);
    if (empty($j['ok'])) @file_put_contents(DATA_DIR . '/telegram-errors.log', gmdate('c') . " $method " . substr((string)$raw, 0, 300) . "\n", FILE_APPEND);
    return $j;
}
// where Game Design posts go: chat id plus the forum topic, if the group uses topics
function tg_design_to($c) {
    $p = ['chat_id' => $c['design_chat']];
    if ((string)$c['design_topic'] !== '') $p['message_thread_id'] = (int)$c['design_topic'];
    return $p;
}
function tg_design_send($c, $m) {
    $p = tg_design_to($c) + ['parse_mode' => 'HTML'];
    if ($m['kb']) $p['reply_markup'] = $m['kb'];
    if (!empty($m['r'])) $p['reply_parameters'] = ['message_id' => $m['r'], 'allow_sending_without_reply' => true];
    $sent = false;
    if ($m['f'] !== '' && is_file($m['f'])) {
        $j = tg_api_file($c['token'], 'sendPhoto', $p + ['caption' => $m['h']], 'photo', $m['f']);
        $sent = !empty($j['ok']);
        @unlink($m['f']);
    }
    // no picture, or Telegram wouldn't take it: the words still go out
    if (!$sent) $j = tg_api($c['token'], 'sendMessage', $p + ['text' => $m['h'], 'link_preview_options' => ['is_disabled' => true]]);
    return $j;
}
//MC 2026-10-11 split a long HTML post into parts Telegram accepts (4,096 characters), at blank lines, then lines.
//   The blocks the site builds keep their tags inside one paragraph, so a split never cuts a tag in two.
function tg_split($html, $max = 3800) {
    if (mb_strlen($html) <= $max) return [$html];
    $out = []; $cur = '';
    foreach (preg_split('/(?<=\n\n)/', $html) as $para) {
        foreach (mb_strlen($para) > $max ? preg_split('/(?<=\n)/', $para) : [$para] as $bit) {
            if (mb_strlen($bit) > $max) $bit = mb_substr(strip_tags($bit), 0, $max - 1) . '…';
            if ($cur !== '' && mb_strlen($cur) + mb_strlen($bit) > $max) { $out[] = rtrim($cur); $cur = ''; }
            $cur .= $bit;
        }
    }
    if (trim($cur) !== '') $out[] = rtrim($cur);
    return $out;
}
function tg_err_log($m) { $f = DATA_DIR . '/telegram-errors.log'; if (@filesize($f) > 1000000) @rename($f, $f . '.1'); @file_put_contents($f, gmdate('c') . ' ' . $m . "\n", FILE_APPEND); }
//MC 2026-10-11 posts that failed (Telegram down, the bot kicked for a while): their once key is released and they wait in
//   tg-retry.php, tried again from tg_tick after 2, 4, 8... minutes, up to 8 tries (about 8 hours). Hourly-capped game
//   results aren't worth retrying and are dropped as before.
define('TGRETRY', DATA_DIR . '/tg-retry.php');
//MC 2026-10-12 every post to the chat with its Telegram message ids (newest 100), so Admin > Telegram can list what went
//   out and pin, edit, delete or send any of them again. Before this, nothing kept the ids and a wrong post could only be
//   taken down by hand in Telegram.
define('TGPOSTS', DATA_DIR . '/tg-posts.php');
// posts that get pinned when they go out, unless the admin changes it (payout and burn have their own pins)
//MC 2026-10-12 wins against the Shogun are pinned too (the last one is unpinned, so the chat keeps the latest). The saved
//   pin settings list every kind that existed when they were saved, so a kind added later takes its default here.
const TG_PIN_DEF = ['weekly' => true, 'boss' => false];   //MC 2026-10-12 Shogun wins off by default: each new pin pushed the burn tracker out of the pinned bar
function tg_pin_set($c) { return (is_array($c['pins'] ?? null) ? $c['pins'] : []) + TG_PIN_DEF; }
function tg_pin_on($c, $k) { if (in_array($k, ['payout', 'burn'], true)) return false; return !empty(tg_pin_set($c)[$k]); }
function tg_posts() { $d = load(TGPOSTS); return is_array($d) ? $d : []; }
function tg_post_log($rec) {
    try { tg_locked(function () use ($rec) { $d = tg_posts(); $old = $d[$rec['id']] ?? []; $d[$rec['id']] = $rec + $old; if (count($d) > 100) $d = array_slice($d, -100, null, true); save(TGPOSTS, $d); }); } catch (Throwable $e) {}
}
// pin a post; the last pinned post of the same kind is unpinned so the chat keeps one of each
function tg_pin_kind($k, $id) {
    $c = tg_cfg(); if (!$id || $c['token'] === '' || $c['chat'] === '') return ['ok' => false];
    $old = (int)($c['pinned'][$k] ?? 0);
    if ($old && $old !== $id && $old !== (int)($c['payout_msg'] ?? 0) && $old !== (int)($c['burn_msg'] ?? 0)) { tg_api($c['token'], 'unpinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $old]); tg_post_log(['id' => (string)$old, 'pin' => 0]); }
    $j = tg_api($c['token'], 'pinChatMessage', ['chat_id' => $c['chat'], 'message_id' => $id, 'disable_notification' => true]);
    if (!empty($j['ok'])) {
        tg_locked(function () use ($k, $id) { $c = tg_cfg(); $c['pinned'][$k] = $id; save(TGCFG, $c); });
        tg_post_log(['id' => (string)$id, 'pin' => 1]);
    }
    return $j;
}
// send one post to the chat right now (admin tools): split when long, logged, pinned if asked. Returns Telegram's answer
// for the first part plus 'id'.
function tg_send_now($kind, $html, $pin = false, $once = '') {
    $c = tg_cfg(); if (!tg_ready($c)) return ['ok' => false, 'description' => 'The bot or the chat isn\'t set up.'];
    $p = ['chat_id' => $c['chat'], 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]];
    $kb = !empty($c['app']) && !empty($c['bot']) ? tg_kb('🎴 Play in Telegram') : null;
    if ($kb) { $p['reply_markup'] = $kb; $html = preg_replace('#(<a href="' . preg_quote(TG_SITE, '#') . '[^"]*">)([^<]+)(</a>)#', '$1🌐 $2 on the web$3', $html); }
    $ids = []; $first = null;
    foreach (tg_split($html) as $i => $part) {
        $pp = $p + ['text' => $part]; if ($i > 0) unset($pp['reply_markup']);
        $j = tg_api($c['token'], 'sendMessage', $pp);
        if (empty($j['ok'])) return $first ?? $j;
        $ids[] = (int)$j['result']['message_id']; if ($i === 0) $first = $j;
    }
    $first['id'] = $ids[0];
    tg_post_log(['id' => (string)$ids[0], 'ids' => $ids, 'k' => $kind, 'o' => $once, 't' => time(), 'h' => $html, 'photo' => '', 'chat' => $c['chat'], 'pin' => 0]);
    if ($pin) tg_pin_kind($kind, $ids[0]);
    return $first;
}
// what the admin can do with a logged post: delete it (every part), pin or unpin it, or change its words
function tg_post_act($id, $op, $html = '') {
    $c = tg_cfg(); $d = tg_posts(); $r = $d[(string)$id] ?? ['id' => (string)$id, 'ids' => [(int)$id], 'k' => '', 'photo' => ''];
    if (!tg_ready($c)) return 'Connect the bot and pick the chat first.';
    $chat = $r['chat'] ?? $c['chat']; $mid = (int)$id;
    if ($op === 'delete') {
        $bad = '';
        foreach ($r['ids'] ?? [$mid] as $m) { $j = tg_api($c['token'], 'deleteMessage', ['chat_id' => $chat, 'message_id' => (int)$m]); if (empty($j['ok'])) $bad = (string)($j['description'] ?? 'no answer'); }
        if ($bad !== '') return 'Telegram wouldn\'t delete it: ' . $bad . '. A bot can only delete its own posts from the last 48 hours; anything older you delete by hand in Telegram.';
        tg_post_log(['id' => (string)$id, 'del' => time(), 'pin' => 0]);
        return 'Deleted from the chat.';
    }
    if ($op === 'pin') { $j = tg_pin_kind($r['k'] !== '' ? $r['k'] : 'other', $mid); return !empty($j['ok']) ? 'Pinned.' : 'Telegram wouldn\'t pin it: ' . ($j['description'] ?? 'no answer') . '. The bot needs the Pin messages right.'; }
    if ($op === 'unpin') { $j = tg_api($c['token'], 'unpinChatMessage', ['chat_id' => $chat, 'message_id' => $mid]); if (!empty($j['ok'])) tg_post_log(['id' => (string)$id, 'pin' => 0]); return !empty($j['ok']) ? 'Unpinned.' : 'Telegram wouldn\'t unpin it: ' . ($j['description'] ?? 'no answer') . '.'; }
    if ($op === 'edit') {
        $html = trim($html); if ($html === '') return 'The message can\'t be empty.';
        if (mb_strlen($html) > ($r['photo'] !== '' ? 1000 : 3800)) return 'That\'s too long for one Telegram message. Shorten it, or delete this one and send it as a new post.';
        $p = ['chat_id' => $chat, 'message_id' => $mid, 'parse_mode' => 'HTML'];
        $kb = !empty($c['app']) && !empty($c['bot']) ? tg_kb('🎴 Play in Telegram') : null; if ($kb) $p['reply_markup'] = $kb;
        $j = $r['photo'] !== '' ? tg_api($c['token'], 'editMessageCaption', $p + ['caption' => $html]) : tg_api($c['token'], 'editMessageText', $p + ['text' => $html, 'link_preview_options' => ['is_disabled' => true]]);
        if (empty($j['ok'])) return 'Telegram wouldn\'t change it: ' . ($j['description'] ?? 'no answer') . (preg_match('/parse|entit/i', (string)($j['description'] ?? '')) ? '. Check the tags: only <b>, <i>, <u>, <s>, <a href="..."> and <code> work, and each must be closed.' : '.');
        tg_post_log(['id' => (string)$id, 'h' => $html, 'ed' => time()]);
        return 'Changed in the chat.';
    }
    return 'Unknown action.';
}
// a message link from Telegram (t.me/c/123/456, t.me/group/456, or a topic link t.me/c/123/7/456) to its message id
function tg_msg_from_link($s) {
    $s = trim((string)$s);
    if (preg_match('/^\d{1,12}$/', $s)) return (int)$s;
    if (preg_match('~t\.me/(?:c/\d+|[A-Za-z][A-Za-z0-9_]{3,})(?:/\d+)?/(\d+)/?(?:\?.*)?$~', $s, $m)) return (int)$m[1];
    return 0;
}
function tg_retry_add($failed) {
    $keep = array_values(array_filter($failed, fn($m) => !in_array($m['k'], ['live', 'daily_run', 'solo'], true)));
    tg_locked(function () use ($failed, $keep) {
        $c = tg_cfg(); $ch = false;
        foreach ($failed as $m) if (($m['o'] ?? '') !== '' && isset($c['once'][$m['o']])) { unset($c['once'][$m['o']]); $ch = true; }
        if ($ch) save(TGCFG, $c);
        if (!$keep) return;
        $r = load(TGRETRY);
        foreach ($keep as $m) {
            $k = ($m['o'] ?? '') !== '' ? $m['o'] : 'h:' . md5($m['h']);
            $n = max((int)($r[$k]['n'] ?? 0), (int)($m['_rn'] ?? 0)) + 1;
            if ($n > 8) { unset($r[$k]); tg_err_log('gave up on ' . $k); continue; }
            $r[$k] = ['m' => $m, 'n' => $n, 'at' => time() + 60 * (2 ** $n)];
        }
        save(TGRETRY, $r);
    });
}
function tg_retry_due() {
    if (!is_file(TGRETRY)) return;
    // taken off the list before they're sent; one that fails again comes back through tg_retry_add with its count
    $due = tg_locked(function () {
        $r = load(TGRETRY); $out = [];
        foreach ($r as $k => $x) if ($x['at'] <= time()) { $out[] = ['_rn' => $x['n']] + $x['m']; unset($r[$k]); }
        if ($out) save(TGRETRY, $r);
        return $out;
    });
    foreach ($due as $m) { tg_hook(); $GLOBALS['TG_Q'][] = $m; }   // sent by tg_flush when this request ends
}
//MC 2026-10-11 what the last chat posts did, newest first (20 kept), and the text of the last weekly and payout posts,
//   so Admin > Telegram can say when the bot stopped getting through (kicked, chat gone) and send those two again.
//   Read by tg_health() in opslib.php. Its own small file, written once per flush, under tg-lock.
function tg_sent_note($hist, $last) {
    try {
        tg_locked(function () use ($hist, $last) {
            $f = DATA_DIR . '/tg-health.php'; $d = load($f);
            $d['r'] = array_slice(array_merge(array_reverse($hist), (array)($d['r'] ?? [])), 0, 20);
            foreach ($last as $k => $v) $d['last'][$k] = $v;
            save($f, $d);
        });
    } catch (Throwable $e) {}
}
function tg_hook() { static $hooked = false; if (!$hooked) { $hooked = true; register_shutdown_function('tg_flush'); } }
function tg_flush() {
    $q = $GLOBALS['TG_Q'] ?? []; $dms = $GLOBALS['TG_DM'] ?? []; $ds = $GLOBALS['TG_DS'] ?? []; $pq = $GLOBALS['TG_PQ'] ?? []; $burn = $GLOBALS['TG_BURN'] ?? null;
    $GLOBALS['TG_Q'] = []; $GLOBALS['TG_DM'] = []; $GLOBALS['TG_DS'] = []; $GLOBALS['TG_PQ'] = []; $GLOBALS['TG_BURN'] = null;
    if (!$q && !$dms && !$ds && !$pq && !$burn) return;
    // hand the player their answer first, then talk to Telegram
    if (function_exists('litespeed_finish_request')) @litespeed_finish_request();
    elseif (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
    $lf = @fopen(DATA_DIR . '/tg-lock.php', 'c');
    if (!$lf) return;
    flock($lf, LOCK_EX);
    $send = [];
    try {
        $c = tg_cfg();
        if ($c['token'] === '') { foreach ($ds as $m) if ($m['f'] !== '') @unlink($m['f']); return; }
        $now = time();
        $c['sent'] = array_values(array_filter($c['sent'], fn($t) => $t > $now - 3600));
        if ($c['chat'] !== '') foreach ($q as $m) {
            if (!tg_on($c, $m['k'])) continue;
            if ($m['o'] !== '') { if (isset($c['once'][$m['o']])) continue; $c['once'][$m['o']] = $now; }
            // game results are capped per hour so a busy evening never floods the chat
            if (in_array($m['k'], ['live', 'daily_run', 'solo'], true)) {   //MC 2026-10-12 Shogun results are left out of the cap too: a loss skipped by a busy hour never showed up
                if (count($c['sent']) >= max(1, (int)$c['hour_cap'])) continue;
                $c['sent'][] = $now;
            }
            $send[] = $m;
        }
        //MC 2026-10-09 posts for partner groups (joint events), each sent once per group, with their own switch
        $psend = [];
        if (tg_on($c, 'partner')) foreach ($pq as $m) { if (isset($c['once'][$m['o']])) continue; $c['once'][$m['o']] = $now; $psend[] = $m; }
        //MC 2026-10-11 once keys are kept for 14 days instead of the newest 300: with many purchase posts the 'daily:<day>'
        //   key could fall off the end and the Daily wrap-up went out a second time. A hard cap stays as a backstop.
        $c['once'] = array_filter($c['once'], fn($t) => $t > $now - 14 * 86400);
        if (count($c['once']) > 3000) { asort($c['once']); $c['once'] = array_slice($c['once'], -3000, null, true); }
        save(TGCFG, $c);
    } finally { flock($lf, LOCK_UN); fclose($lf); }
    $failed = [];
    $hist = []; $lastPost = [];   //MC 2026-10-11 how each chat post went, for Admin > Telegram (tg_sent_note)
    // a Play button under each post when the Mini App is set up, so one tap opens the game inside Telegram
    $appKb = !empty($c['app']) && !empty($c['bot']) ? tg_kb('🎴 Play in Telegram') : null;
    foreach ($send as $m) {
        if (in_array($m['k'], ['weekly', 'payout'], true)) $lastPost[$m['k']] = ['h' => $m['h'], 't' => time(), 'o' => (string)($m['o'] ?? '')];
        $p = ['chat_id' => $c['chat'], 'text' => $m['h'], 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]];
        $kb = $m['kb'] ?? $appKb;
        if ($kb) {
            $p['reply_markup'] = $kb;
            // the button under the post opens the game in Telegram, so the link in the text says plainly it goes to the website
            $p['text'] = preg_replace('#(<a href="' . preg_quote(TG_SITE, '#') . '[^"]*">)([^<]+)(</a>)#', '$1🌐 $2 on the web$3', $p['text']);
        }
        if (!empty($m['img'])) {
            // the result card goes up as a photo with the text as its caption
            $p['photo'] = $m['img']; $p['caption'] = $p['text'];
            unset($p['text'], $p['link_preview_options']);
            $j = tg_api($c['token'], 'sendPhoto', $p, 15);
            if (!empty($j['ok'])) {
                $hist[] = ['t' => time(), 'k' => $m['k'], 'ok' => 1]; if (isset($lastPost[$m['k']])) $lastPost[$m['k']]['ok'] = 1;
                $mid = (int)($j['result']['message_id'] ?? 0);   //MC 2026-10-12 kept for Admin > Telegram (see TGPOSTS)
                if ($mid) { tg_post_log(['id' => (string)$mid, 'ids' => [$mid], 'k' => $m['k'], 'o' => (string)($m['o'] ?? ''), 't' => time(), 'h' => $p['caption'], 'photo' => (string)$m['img'], 'chat' => $c['chat'], 'pin' => 0]); if (tg_pin_on($c, $m['k'])) tg_pin_kind($m['k'], $mid); }
                continue;
            }
            // Telegram couldn't fetch the picture: the words still go out
            $p['text'] = $p['caption']; $p['link_preview_options'] = ['is_disabled' => true];
            unset($p['photo'], $p['caption']);
        }
        //MC 2026-10-11 Telegram refuses anything over 4,096 characters (a payout post with many prize lists ran to 7,352):
        //   long posts go out in parts, split between paragraphs, the button and the pin on the first part
        $j = null; $first = null; $ids = [];
        foreach (tg_split($p['text']) as $i => $part) {
            $pp = $p; $pp['text'] = $part; if ($i > 0) unset($pp['reply_markup']);
            $j = tg_api($c['token'], 'sendMessage', $pp);
            if (empty($j['ok'])) break;
            if ($i === 0) $first = $j;
            $ids[] = (int)($j['result']['message_id'] ?? 0);
        }
        //MC 2026-10-12 every post is logged with its ids, and pinned if its kind is set to pin (Admin > Telegram)
        if ($ids && $ids[0]) {
            tg_post_log(['id' => (string)$ids[0], 'ids' => $ids, 'k' => $m['k'], 'o' => (string)($m['o'] ?? ''), 't' => time(), 'h' => $p['text'], 'photo' => '', 'chat' => $c['chat'], 'pin' => ($m['pin'] ?? '') === 'payout' ? 1 : 0]);
            if (!empty($j['ok']) && tg_pin_on($c, $m['k'])) tg_pin_kind($m['k'], $ids[0]);
        }
        if (($m['pin'] ?? '') === 'payout' && $first && !empty($j['ok'])) tg_payout_pin((int)($first['result']['message_id'] ?? 0));   //MC 2026-10-10
        //MC 2026-10-11 a post that didn't go out is no longer marked sent: it's handed to the retry queue (tg_retry_*)
        if (empty($j['ok'])) { $failed[] = $m; tg_err_log('post ' . $m['k'] . ' ' . ($m['o'] ?? '') . ': ' . ($j['description'] ?? 'no answer')); }
        $hist[] = ['t' => time(), 'k' => $m['k'], 'ok' => empty($j['ok']) ? 0 : 1] + (empty($j['ok']) ? ['err' => mb_substr((string)($j['description'] ?? 'no answer from Telegram'), 0, 200)] : []);
        if (isset($lastPost[$m['k']])) $lastPost[$m['k']]['ok'] = empty($j['ok']) ? 0 : 1;
    }
    if ($failed) tg_retry_add($failed);
    if ($hist) tg_sent_note($hist, $lastPost);
    if ($burn && tg_on($c, 'burn') && $c['chat'] !== '') tg_burn_update($burn);
    // partner groups: a group that removed the bot or no longer exists is unlinked, so it's never tried again
    $gone = [];
    foreach ($psend as $m) {
        $j = tg_api($c['token'], 'sendMessage', ['chat_id' => $m['c'], 'text' => $m['h'], 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true], 'reply_markup' => $m['kb']]);
        $code = (int)($j['error_code'] ?? 0); $why = strtolower((string)($j['description'] ?? ''));
        if (empty($j['ok']) && ($code === 403 || ($code === 400 && preg_match('/chat not found|kicked|not a member|have no rights/', $why)))) $gone[$m['c']] = 1;
    }
    if ($gone && function_exists('tp_unlink_chat')) foreach (array_keys($gone) as $g) tp_unlink_chat($g);
    // the team's Game Design channel
    foreach ($ds as $m) {
        if ($c['design_chat'] !== '' && !empty($c['design_on'][$m['k']])) { $j = tg_design_send($c, $m); if (!empty($m['cb']) && !empty($j['ok'])) ($m['cb'])($j['result'] ?? [], $c); }
        elseif ($m['f'] !== '') @unlink($m['f']);
    }
    if (empty($c['dm_on'])) return;
    $blocked = [];
    foreach (array_slice($dms, 0, 25) as $m) {
        $p = ['chat_id' => $m['t'], 'text' => $m['h'], 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]];
        if ($m['kb']) $p['reply_markup'] = $m['kb'];
        $j = tg_api($c['token'], 'sendMessage', $p, 5);
        // the player blocked the bot or never opened it: stop messaging them until they come back
        if (empty($j['ok']) && in_array((int)($j['error_code'] ?? 0), [400, 403], true)) $blocked[] = $m['t'];
        usleep(40000);
    }
    if ($blocked) with_lock(function () use ($blocked) { $l = tgl(); foreach ($blocked as $t) if (isset($l['u'][$t])) $l['u'][$t]['dm'] = false; save(TGLINKS, $l); });
}

// ---------------------------------------------------------------- the chat messages
const TG_SITE = 'https://shyonsol.io';
function tg_link($path, $label) { return '<a href="' . TG_SITE . $path . '">' . tg_h($label) . '</a>'; }

// A solo or Daily result waits up to a minute for the player's result card, so the post goes out with the picture.
// The game save and the card arrive as two separate requests in either order. Both call these inside with_lock.
define('TGPEND', DATA_DIR . '/tg-pend.php');
function tg_pend_result($pid, $kind, $html) {
    $c = tg_cfg();
    if ($c['token'] === '' || $c['chat'] === '' || !tg_on($c, $kind)) return;
    $p = load(TGPEND); $card = $p['s:' . $pid] ?? null;
    if ($card && $card['k'] === $kind && time() - $card['t'] < 120) {
        unset($p['s:' . $pid]); save(TGPEND, $p);
        tg_post($kind, $html, '', null, TG_SITE . '/api/share.php?i=' . $card['id']);
        return;
    }
    $p[$pid] = ['k' => $kind, 'h' => $html, 't' => time()];
    save(TGPEND, $p);
}
// the card was made: send the waiting post with it, or leave the card for the result that's on its way
function tg_pend_card($pid, $shareKind, $id) {
    $kind = $shareKind === 'daily' ? 'daily_run' : ($shareKind === 'solo' ? 'solo' : ($shareKind === 'live' ? 'live' : ''));   //MC 2026-10-13 live winner cards pair with the match post too
    if ($kind === '') return;
    $p = load(TGPEND); $x = $p[$pid] ?? null;
    if ($x && $x['k'] === $kind && time() - $x['t'] < 300) {
        unset($p[$pid]); save(TGPEND, $p);
        tg_post($x['k'], $x['h'], '', null, TG_SITE . '/api/share.php?i=' . $id);
        return;
    }
    $p['s:' . $pid] = ['k' => $kind, 'id' => $id, 't' => time()];
    foreach ($p as $k => $v) if (time() - $v['t'] > 600) unset($p[$k]);
    save(TGPEND, $p);
}
// results whose card never came go out as words after a minute
function tg_pend_flush() {
    $go = with_lock(function () {
        $p = load(TGPEND); $go = []; $ch = false;
        foreach ($p as $k => $v) {
            if (strpos($k, 's:') !== 0 && time() - $v['t'] >= 60) { $go[] = $v; unset($p[$k]); $ch = true; }
            elseif (time() - $v['t'] > 600) { unset($p[$k]); $ch = true; }
        }
        if ($ch) save(TGPEND, $p);
        return $go;
    });
    foreach ($go as $v) tg_post($v['k'], $v['h']);
}

function tg_game($mode, $name, $result, $regions, $extra = []) {
    $n = '<b>' . tg_h($name ?: 'A player') . '</b>';
    // how the bots finished, highest first: "2, 1 and 0"
    $bots = array_map('intval', array_slice($extra['all'] ?? [], 1));
    rsort($bots);
    $vs = $bots ? (count($bots) > 1 ? implode(', ', array_slice($bots, 0, -1)) . ' and ' . end($bots) : (string)$bots[0]) : '';
    $score = "$regions " . ($regions === 1 ? 'Region' : 'Regions') . ($vs !== '' ? " to the bots' $vs" : '');
    $how = [];
    if ($mode === 'easy') $how[] = 'Easy';
    elseif ($mode === 'normal') $how[] = 'Normal';
    if ($mode !== 'daily') $how[] = !empty($extra['hints']) ? 'hints on' : 'no hints';
    if (!empty($extra['gain'])) $how[] = '+' . (int)$extra['gain'] . ' pts';
    $as = !empty($extra['shadow']) ? 'Playing as Shadow #' . (int)$extra['shadow'] . '. ' : '';
    $wins = (int)($extra['wins'] ?? 0); $games = (int)($extra['games'] ?? 0);
    $rec = $games === 1 && $wins === 1 ? 'First game, first win.' : ($games > 0 ? "That's $wins " . ($wins === 1 ? 'win' : 'wins') . " from $games " . ($games === 1 ? 'game' : 'games') . '.' : '');
    if (!empty($extra['pb'])) $rec .= ' New personal best.';
    elseif (!empty($extra['best']) && (int)$extra['best'] > $regions) $rec .= ' Best ever: ' . (int)$extra['best'] . ' Regions.';
    $tail = trim($as . $rec);
    if ($mode === 'daily') {
        $no = (int)($extra['no'] ?? 0);
        $head = $result === 'win' ? "$n won Daily #$no" : ($result === 'tie' ? "$n tied Daily #$no" : "$n played Daily #$no");
        $send = !empty($extra['pid']) ? fn($k, $h) => tg_pend_result($extra['pid'], $k, $h) : fn($k, $h) => tg_post($k, $h);
        $send('daily_run', "🗓 $head with $score." . ($how ? "\n" . implode(' · ', $how) . ' toward the League' : '') . ($tail !== '' ? "\n$tail" : '') .
            "\n\nSame deck for everyone today. " . tg_link('/play', 'Take your shot'));
    } elseif ($result === 'win') {
        $send = !empty($extra['pid']) ? fn($k, $h) => tg_pend_result($extra['pid'], $k, $h) : fn($k, $h) => tg_post($k, $h);
        $send('solo', "⚔️ $n ruled the world in a solo game, $score.\n" . implode(' · ', $how) . ($tail !== '' ? "\n$tail" : '') .
            "\n\n" . tg_link('/play', 'Play free'));
    }
}
// one message per live match
//MC 2026-10-10 the post now follows the game's own final standings (eng_standings: Regions, then cards in hand, then seat),
//   so the order and the winner always match the results screen. It used to sort by Regions alone: a bot that won a
//   3 to 3 tie on cards could sit second under a line saying it took the world. A shared world ('tie') also never read
//   as "tied" because only 'win' counted. The head counts players and bots separately ("3 players and a bot"), and
//   one Region is singular. Without standings (old callers) it falls back to the same order from the results.
//MC 2026-10-13 the post waits up to a minute for the winner's card (made as their end screen opens) and goes out as a
//   photo with the standings as its caption, like solo and Daily wins already did. No single human winner, or no card in
//   time, and it goes out as words exactly as before (tg_pend_flush is the fallback).
function tg_live($seats, $res, $standings = null) {
    if (!$standings) {
        $standings = [];
        foreach ($seats as $i => $s) $standings[] = ['i' => $i, 'regions' => (int)($res[$i]['regions'] ?? 0), 'hand' => (int)($res[$i]['hand'] ?? 0)];
        usort($standings, fn($a, $b) => [$b['regions'], $b['hand'], $a['i']] <=> [$a['regions'], $a['hand'], $b['i']]);
    }
    $rows = [];
    foreach ($standings as $x) {
        $i = $x['i']; $s = $seats[$i] ?? [];
        $rows[] = ['n' => str_replace(' (bot)', '', (string)($s['name'] ?? $x['name'] ?? '')), 'h' => !empty($s['human']), 'r' => (int)$x['regions'], 'c' => (int)($x['hand'] ?? 0), 'res' => $res[$i]['result'] ?? '', 'pid' => (string)($s['pid'] ?? '')];
    }
    if (!$rows) return;
    $humans = count(array_filter($rows, fn($r) => $r['h'])); $bots = count($rows) - $humans;
    $who = $humans . ' ' . ($humans === 1 ? 'player' : 'players') . ($bots ? ' and ' . ($bots === 1 ? 'a bot' : $bots . ' bots') : '');
    $win = array_values(array_filter($rows, fn($r) => $r['res'] === 'win' || $r['res'] === 'tie'));
    if (!$win) $win = [$rows[0]];
    $top = implode(' and ', array_map(fn($r) => '<b>' . tg_h($r['n']) . '</b>' . ($r['h'] ? '' : ' (bot)'), $win));
    $verb = count($win) > 1 ? 'shared the world' : 'took the world';
    // the same tie note as the results screen
    $note = '';
    if (count($rows) > 1 && $rows[0]['r'] === $rows[1]['r']) $note = $rows[0]['c'] === $rows[1]['c'] ? ' Tied on Regions and cards.' : ' Tied on Regions, decided by cards in hand (' . $rows[0]['c'] . ' to ' . $rows[1]['c'] . ').';
    $tied = fn($r) => count(array_filter($rows, fn($y) => $y['r'] === $r['r'])) > 1;
    $table = implode("\n", array_map(fn($r, $i) => ($i + 1) . '. ' . tg_h($r['n']) . ($r['h'] ? '' : ' (bot)') . ': ' . $r['r'] . ($r['r'] === 1 ? ' Region' : ' Regions') . ($tied($r) ? ', ' . $r['c'] . ($r['c'] === 1 ? ' card' : ' cards') : ''), $rows, array_keys($rows)));
    $html = "🔴 <b>Live match</b>, $who\n$top $verb.$note\n\n$table\n\n" . tg_link('/play', 'Join a live match');
    $wpid = count($win) === 1 && !empty($win[0]['h']) ? ($win[0]['pid'] ?? '') : '';
    if ($wpid !== '') { tg_pend_result($wpid, 'live', $html); return; }
    //MC 2026-10-13 a bot winner gets its own card: the machine-victory picture (share.php?bw=, drawn server side from
    //   this record), so a bot win doesn't go out bare while every human win carries one. Only a single clear bot winner
    //   gets it; shared worlds still go out as words.
    $img = count($win) === 1 && empty($win[0]['h']) ? tg_botwin_img($win[0]['n'], $rows) : '';
    tg_post('live', $html, '', null, $img ?: '');
}
//MC 2026-10-13 write the record the Shogun's victory card is drawn from (share.php?sw=), and hand back its address
function tg_shogun_img($rec) {
    $rec['t'] = time();
    $id = substr(sha1(json_encode($rec) . 'sw1'), 0, 10);
    $dir = DATA_DIR . '/shares';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (@file_put_contents($dir . '/shwin-' . $id . '.json', json_encode($rec)) === false) return '';
    return TG_SITE . '/api/share.php?sw=' . $id;
}
// write the record the bot-win card is drawn from, and hand back its picture address
function tg_botwin_img($winner, $rows) {
    $rec = ['w' => (string)$winner, 't' => time(),
        'standings' => array_map(fn($r) => ['n' => (string)$r['n'], 'h' => !empty($r['h']), 'r' => (int)$r['r'], 'c' => (int)$r['c']], array_slice($rows, 0, 6))];
    $id = substr(sha1(json_encode($rec) . 'bw1'), 0, 10);
    $dir = DATA_DIR . '/shares';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (@file_put_contents($dir . '/botwin-' . $id . '.json', json_encode($rec)) === false) return '';
    return TG_SITE . '/api/share.php?bw=' . $id;
}
//MC 2026-10-10 a $SHY purchase also says how much it burned (always posted, even under the amount floor: every burn counts)
function tg_buy($name, $product, $usd, $oid, $burnedShy = 0, $sig = '') {
    $c = tg_cfg();
    if ($usd < (float)$c['buy_min'] && $burnedShy <= 0) return;
    $burn = $burnedShy > 0 ? "\n🔥 <b>" . number_format($burnedShy) . " \$SHY burned</b> with this payment" . ($sig !== '' ? ' (<a href="https://solscan.io/tx/' . tg_h($sig) . '">proof</a>)' : '') . '.' : '';
    tg_post('buy', "🛍 <b>" . tg_h($name ?: 'A player') . "</b> just picked up the <b>" . tg_h($product) . "</b> in the Dojo Shop." . $burn . "\nEvery purchase goes to the community marketing wallet. " . tg_link('/play', 'Visit the shop'), 'order:' . $oid);
}
// yesterday's Daily, posted by the first visit after midnight UTC
function tg_daily_check($daily, $players) {
    if (!tg_ready()) return;
    $day = gmdate('Y-m-d', time() - 86400);
    $c = tg_cfg();
    if (isset($c['once']['daily:' . $day]) || !tg_on($c, 'daily')) return;
    $rows = [];
    foreach ($daily[$day] ?? [] as $pid => $d) $rows[] = ['n' => $players[$pid]['name'] ?? 'Player', 'p' => (int)$d['points'], 'g' => (int)$d['regions'], 'r' => $d['result'], 't' => (int)$d['ts']];
    if (!$rows) return;
    usort($rows, fn($a, $b) => [$b['p'], $b['g'], $a['t']] <=> [$a['p'], $a['g'], $b['t']]);   //MC 2026-10-10 same order as the Daily board (points, then Regions, then who finished first)
    $no = (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1;
    $medal = ['🥇', '🥈', '🥉'];
    $top = implode("\n", array_map(fn($r, $i) => ($medal[$i] ?? ($i + 1) . '.') . ' ' . tg_h($r['n']) . ': ' . $r['p'] . ' pts, ' . $r['g'] . ($r['g'] === 1 ? ' Region' : ' Regions'), array_slice($rows, 0, 5), array_keys(array_slice($rows, 0, 5))));
    $wins = count(array_filter($rows, fn($r) => $r['r'] === 'win'));
    //MC 2026-10-15 the day that just ended is opened on the Fair page, and the chat gets the seal of the day a week out:
    //   a timestamped copy nobody on the team can edit later, posted long before that deal is played
    $seal = '';
    if (function_exists('fair_daily_proof')) {
        $far = gmdate('Y-m-d', strtotime($day . ' 00:00:00 UTC') + (FAIR_AHEAD + 1) * 86400);
        $fp = fair_daily_proof($far);
        if ($fp !== null) $seal = "\n\n🔒 Seal for Daily #" . ($no + FAIR_AHEAD + 1) . ': <code>' . substr(fair_daily_seal($fp, $far), 0, 16) . '</code> ' . tg_link('/fair', 'Check any deal');
    }
    tg_post('daily', "🗓 <b>Daily #$no is in.</b> " . count($rows) . ' ' . (count($rows) === 1 ? 'player' : 'players') . " took the same shot, $wins won.\n\n$top\n\nDaily #" . ($no + 1) . ' is live now. ' . tg_link('/play', 'Play it') . $seal, 'daily:' . $day);
}
// a week's League just froze
function tg_weekly($wk, $league, $pool) {
    if (!$league) return;
    tg_post('weekly', tg_weekly_html($wk, $league, $pool), 'week:' . $wk);
}
//MC 2026-10-11 the post's text on its own, so Admin > Telegram can send the last one again
function tg_weekly_html($wk, $league, $pool, $fixed = false) {
    $medal = ['🥇', '🥈', '🥉'];
    $rows = implode("\n", array_map(fn($w, $i) => ($medal[$i] ?? ($i + 1) . '.') . ' ' . tg_h($w['name']) . ': ' . (int)$w['pts'] . ' pts, $' . number_format((float)$w['usd'], 2) . ' in $SHY', array_slice($league, 0, 10), array_keys(array_slice($league, 0, 10))));
    //MC 2026-10-12 the corrected version, posted from Admin > Rewards after a week was fixed
    if ($fixed) return "🏆 <b>Weekly League, week " . tg_h(substr($wk, 5)) . ": corrected results.</b> These replace the earlier post. $" . number_format((float)$pool, 0) . " in \$SHY goes to the top players.\n\n$rows\n\nPrizes are paid from the community marketing wallet. " . tg_link('/play#rewards', 'Climb the League');
    return "🏆 <b>Weekly League, week " . tg_h(substr($wk, 5)) . " is final.</b> $" . number_format((float)$pool, 0) . " in \$SHY goes to the top players.\n\n$rows\n\nPrizes are paid from the community marketing wallet. A new week starts now. " . tg_link('/play#rewards', 'Climb the League');
}

// ---------------------------------------------------------------- reminders to linked players
// Runs every couple of minutes at most, from busy pages and from api/cron.php when the host's cron calls it.
// Each player gets each kind of reminder once a day at most, and only the kinds they left switched on.
function tg_tick($force = false) {
    if (function_exists('tourney_tick')) tourney_tick();   // tournaments run with or without Telegram
    if (function_exists('mail_tick')) mail_tick();         //MC 2026-10-09 the daily and weekly report emails
    $c = tg_cfg();
    if ($c['token'] === '') return 0;
    tg_release_check($c);
    tg_daily_am($c);
    tg_drops($c);   //MC 2026-10-13 a scheduled drop opening, the last copies and the last hour
    //MC 2026-10-10 a payout post that couldn't be pinned: try again now and then (the bot may have been made an admin since)
    if (!empty($c['payout_pin']) && !empty($c['payout_msg']) && ($c['payout_chat'] ?? '') === $c['chat'] && time() - (int)($c['payout_try'] ?? 0) > 900) tg_payout_pin((int)$c['payout_msg'], true);
    tg_pend_flush();
    tg_retry_due();   //MC 2026-10-11 posts that failed earlier
    if (empty($c['dm_on'])) return 0;
    $tf = DATA_DIR . '/tg-tick.php';
    $last = (int)(load($tf)['t'] ?? 0);
    if (!$force && time() - $last < 120) return 0;
    save($tf, ['t' => time()]);
    $day = today(); $hour = (int)gmdate('G');
    $plan = with_lock(function () use ($c, $day, $hour) {
        $l = tgl();
        if (!$l['u']) return [];
        $eco = load(ECO); $players = load(PLAYERS);
        $out = []; $n = 0;
        $yest = gmdate('Y-m-d', time() - 86400);
        $no = (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1;
        foreach ($l['u'] as $t => &$u) {
            if ($n >= 25) break;
            if (empty($u['dm'])) continue;
            $notes = tg_notes($u);
            $a = $eco[$u['pid']] ?? null;
            $st = $a['st'] ?? ['d' => '', 'n' => 0];
            $name = $players[$u['pid']]['name'] ?? '';
            // a new Daily is up (after 00:05 UTC)
            if (!empty($notes['daily']) && ($u['last']['daily'] ?? '') !== $day && $hour >= (int)$c['daily_hour'] && ($st['d'] ?? '') !== $day) {
                $u['last']['daily'] = $day; $n++;
                $out[] = [$t, "☀️ <b>Daily #$no is up.</b> Same deck for everyone, one shot, and it counts for the Weekly League.", tg_kb_private('🗓 Play the Daily')];
                continue;
            }
            // the streak runs out at midnight UTC: one nudge in the evening if they haven't played today
            if (!empty($notes['streak']) && $hour >= (int)$c['remind_hour'] && ($u['last']['streak'] ?? '') !== $day && ($st['d'] ?? '') === $yest && (int)$st['n'] >= max(1, (int)$c['remind_min'])) {
                $u['last']['streak'] = $day; $n++;
                $left = 24 - $hour;
                $saver = !empty($a['saver']) ? ' You have a Streak Saver, so missing one day won\'t reset it.' : '';
                $out[] = [$t, '🔥 ' . ($name !== '' ? '<b>' . tg_h($name) . '</b>, your ' : 'Your ') . (int)$st['n'] . "-day streak ends at midnight UTC, about $left " . ($left === 1 ? 'hour' : 'hours') . " from now. One finished game keeps it going." . $saver, tg_kb_private('🔥 Keep my streak')];
            }
        }
        unset($u);
        if ($out) save(TGLINKS, $l);
        return $out;
    });
    foreach ($plan as [$t, $h, $kb]) tg_dm($t, $h, $kb);
    return count($plan);
}
// ---------------------------------------------------------------- limited drop reminders
//MC 2026-10-13 three moments in a drop's life the chat should hear about, each at most once per drop (the once keys):
//   - a drop scheduled ahead of time opens (an instant drop already got the admin's announcement, so no second post)
//   - the last copies: a tenth of the run left (at least 1, at most 10), only after something sold
//   - the last hour on the clock, when time will end it rather than the copies
// The sold-out post lives in fulfill() in economy.php, where the last copy actually sells.
function tg_drops($c) {
    if ($c['chat'] === '' || !tg_on($c, 'drop') || !defined('DROPS') || !function_exists('deck_card')) return;
    $now = time();
    foreach (load(DROPS) as $id => $d) {
        $sold = (int)($d['sold'] ?? 0); $n = (int)($d['n'] ?? 0); $left = $n - $sold;
        if (!empty($d['off']) || $left < 1 || $now < (int)$d['start'] || $now >= (int)$d['end']) continue;
        $card = deck_card($d['card']); $fin = FINISHES[$d['fin']] ?? null;
        if (!$card || !$fin) continue;
        $nm = $card['name'] . ' in ' . $fin['name'];
        if ((int)$d['start'] > (int)($d['created'] ?? 0) + 600 && $now - (int)$d['start'] < 3600 && !isset($c['once']['dropgo:' . $id]))
            tg_post('drop', '🔔 <b>The ' . tg_h($nm) . ' drop is open.</b> ' . $n . ' numbered copies at ' . number_format((float)$d['shy']) . " \$SHY each, until " . gmdate('M j, H:i', (int)$d['end']) . " UTC or sold out. Every copy keeps its number forever.\n" . tg_link('/play#shop', 'Get yours'), 'dropgo:' . $id);
        $low = max(1, min(10, (int)ceil($n / 10)));
        if ($left <= $low && $sold > 0 && !isset($c['once']['droplow:' . $id]))
            tg_post('drop', '⚡ <b>Almost gone.</b> ' . ($left === 1 ? 'The last copy' : 'Only ' . $left . ' of ' . $n . ' copies') . ' of the ' . tg_h($nm) . ' drop ' . ($left === 1 ? 'is' : 'are') . " left, and it never sells again.\n" . tg_link('/play#shop', 'Claim one'), 'droplow:' . $id);
        if ((int)$d['end'] - $now < 3600 && (int)$d['end'] - (int)$d['start'] > 7200 && !isset($c['once']['drophr:' . $id]))
            tg_post('drop', '⏳ <b>Last hour.</b> The ' . tg_h($nm) . ' drop closes at ' . gmdate('H:i', (int)$d['end']) . ' UTC with ' . ($left === 1 ? '1 copy' : $left . ' copies') . " still unclaimed. After that the finish is gone for good.\n" . tg_link('/play#shop', 'Beat the clock'), 'drophr:' . $id);
    }
}

// ---------------------------------------------------------------- the Daily, every morning
// once a day at the hour set in the admin (13 UTC is 9 AM in New York): today's Daily is up, who's on top so far
function tg_daily_am($c) {
    if ($c['chat'] === '' || !tg_on($c, 'daily_am') || (int)gmdate('G') < (int)$c['daily_hour']) return;
    $day = today();
    if (isset($c['once']['dam:' . $day])) return;
    $rows = load(DATA_DIR . '/daily.php')[$day] ?? [];
    $no = (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1;
    $lead = '';
    if ($rows) {
        uasort($rows, fn($a, $b) => [$b['points'], $a['ts']] <=> [$a['points'], $b['ts']]);
        $pid = array_key_first($rows); $pl = load(PLAYERS);
        $lead = ' <b>' . tg_h($pl[$pid]['name'] ?? 'Someone') . '</b> leads with ' . (int)$rows[$pid]['points'] . ' points, ' . count($rows) . ' ' . (count($rows) === 1 ? 'player has' : 'players have') . ' taken their shot.';
    }
    $left = 24 - (int)gmdate('G');
    tg_post('daily_am', "☀️ <b>Daily Challenge #$no is up.</b> Same deck for everyone, one shot each, and it counts for the Weekly League." . ($lead !== '' ? $lead : ' Nobody has played it yet, so the top spot is open.') . "\nIt closes in about $left hours. " . tg_link('/play#daily', 'Play the Daily'), 'dam:' . $day);
}

// ---------------------------------------------------------------- release notes
// the newest entry from scripts/releases.py, written by the build into api/lib/release.php
function tg_release_latest() {
    $f = __DIR__ . '/lib/release.php';
    if (!is_file($f)) return null;
    $r = include $f;
    return is_array($r) && !empty($r['v']) ? $r : null;
}
function tg_release_text($r) {
    $icon = ['new' => '✨', 'better' => '⚡', 'fixed' => '🛠'];
    $items = $r['items'] ?? [];
    $lines = [];
    foreach (array_slice($items, 0, 8) as [$tag, $txt]) {
        $txt = trim((string)$txt);
        if (mb_strlen($txt) > 240) $txt = rtrim(mb_substr($txt, 0, 237)) . '…';
        $lines[] = ($icon[$tag] ?? '•') . ' ' . tg_h($txt);
    }
    $more = count($items) - count($lines);
    return '🚀 <b>New on shyonsol.io: ' . tg_h($r['title']) . "</b>\n" . tg_h($r['summary']) . "\n\n" . implode("\n\n", $lines) .
        ($more > 0 ? "\n\n…and $more more." : '') . "\n\n" . tg_link('/updates#v' . rawurlencode($r['v']), 'Read the release notes');
}
//MC 2026-10-10 every release newer than the last one posted, newest first (uploads that skip a version used to drop it).
//   An unknown last version (or none) means just the newest, so a fresh bot never floods the chat with history.
function tg_release_since($r, $seenV) {
    $out = [];
    foreach ($r['recent'] ?? [] as $x) { if ($x['v'] === $seenV) return $out ?: [$r]; $out[] = $x; }
    return [$r];
}
function tg_release_multi($list) {
    if (count($list) === 1) return tg_release_text($list[0]);
    $icon = ['new' => '✨', 'better' => '⚡', 'fixed' => '🛠'];
    $list = array_slice($list, 0, 5);
    $parts = [];
    foreach ($list as $r) {
        $lines = [];
        foreach (array_slice($r['items'] ?? [], 0, 3) as [$tag, $txt]) { $txt = trim((string)$txt); if (mb_strlen($txt) > 160) $txt = rtrim(mb_substr($txt, 0, 157)) . '…'; $lines[] = ($icon[$tag] ?? '•') . ' ' . tg_h($txt); }
        $more = count($r['items'] ?? []) - count($lines);
        $parts[] = '<b>' . tg_h($r['title']) . "</b>\n" . tg_h($r['summary']) . "\n" . implode("\n", $lines) . ($more > 0 ? "\n…and $more more. " . tg_link('/updates#v' . rawurlencode($r['v']), 'All of it') : '');
    }
    return '🚀 <b>' . count($list) . " updates on shyonsol.io</b>\n\n" . implode("\n\n", $parts) . "\n\n" . tg_link('/updates', 'Read the release notes');
}
// after an upload, the first visit (or the cron job) posts the new release to the chat, once per version
function tg_release_check($c) {
    if ($c['chat'] === '') return;
    $r = tg_release_latest();
    if (!$r) return;
    $sf = DATA_DIR . '/tg-release.php';
    $seen = load($sf);
    if (($seen['v'] ?? '') === $r['v']) return;
    $done = with_lock(function () use ($sf, $r) { $s = load($sf); if (($s['v'] ?? '') === $r['v']) return false; save($sf, ['v' => $r['v'], 't' => time()]); return true; });
    // switched off: the version still counts as seen, so turning posts on later never sends an old release
    if ($done && tg_on($c, 'release')) tg_post('release', tg_release_multi(tg_release_since($r, (string)($seen['v'] ?? ''))), 'rel:' . $r['v']);
}
// the secret the host's cron job sends to api/cron.php (made the first time it's needed)
function cron_key() {
    $f = DATA_DIR . '/cron.php';
    $d = load($f);
    if (empty($d['k'])) { $d['k'] = bin2hex(random_bytes(16)); save($f, $d); }
    return $d['k'];
}
// the command list Telegram shows when someone types / in a chat with the bot
function tg_commands($token) {
    tg_api($token, 'setMyCommands', ['commands' => [
        ['command' => 'play', 'description' => 'Play Shilluminati Online'], ['command' => 'shilluminatiboss', 'description' => 'Take on the Shogun, the hardest bot, for Koban'], ['command' => 'daily', 'description' => "Today's Daily Challenge so far"],
        ['command' => 'leaderboard', 'description' => 'Every board, prizes and your place'], ['command' => 'friends', 'description' => 'You and your friends this week'], ['command' => 'me', 'description' => 'Your streak, Koban and League rank'],
        ['command' => 'notify', 'description' => 'Reminders I can send you'], ['command' => 'stats', 'description' => 'Games played today'], ['command' => 'help', 'description' => 'What I can do']]]);
}
