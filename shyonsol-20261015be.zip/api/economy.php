<?php
// Shilluminati economy: Koban, cosmetics, the Season Scroll, daily streaks, league points and holder tiers.
// Nothing sold here changes the cards, the deal or who wins. Include after common.php and holders.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

require_once __DIR__ . '/tg.php';
require_once __DIR__ . '/tourney.php';
require_once __DIR__ . '/collection.php';
require_once __DIR__ . '/houselib.php';
require_once __DIR__ . '/cardsetlib.php';
require_once __DIR__ . '/bountylib.php';   //MC 2026-10-09 the monthly 15 Club bounty
require_once __DIR__ . '/maillib.php';     //MC 2026-10-09 emails to the team: sales, prizes, daily and weekly reports
require_once __DIR__ . '/loyaltylib.php';  //MC 2026-10-15 holder perks that grow with time held
define('ECO', DATA_DIR . '/economy.php');          // pid => account
define('ORDERS', DATA_DIR . '/orders.php');        // order id => order
define('REWARDS', DATA_DIR . '/rewards.php');      // weekly and season results, payouts, revenue by week
define('ECOSET', DATA_DIR . '/eco-settings.php');  // prize pools, events, holder tiers (edited in admin)
define('KEYS', DATA_DIR . '/keys.php');            // pid => [key hashes] for every device signed in
define('PRICES', DATA_DIR . '/prices.php');
define('DROPS', DATA_DIR . '/drops.php');          //MC 2026-10-13 limited finish drops: id => drop (admin schedules them)

const MW_DEFAULT = 'AAKP39aNkyhi5tqQg5g3EFsx8y3EEtNdsRcrTvhAubZ4';
const SHY_MINT = '7d1vpt5eri79nETcL74Punhp3mGkeBgUkMdPWep6pump';
const SOL_MINT = 'So11111111111111111111111111111111111111112';
const USDC_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const SEASON_EPOCH = '2026-10-05';   // a Monday; seasons are 4 weeks
const SEASON_WEEKS = 4;
const SCROLL_TIERS = 30;
const TIER_XP = 100;
const SHY_BONUS = 20;               // % extra Koban when paying in $SHY

//MC 2026-10-10 extra Koban for paying in $SHY: 20% for everyone, plus 5% to 40% more by holder tier
function shy_bonus_for($pid) { return SHY_BONUS + holder_perks(holder_tier(load(HOLDERS)[$pid] ?? null))['shyb']; }
function mw_address() { $c = shy_config(); return (!empty($c['mw']) && valid_wallet($c['mw'])) ? $c['mw'] : MW_DEFAULT; }

// ---------------------------------------------------------------- catalog
function eco_catalog() {
    static $cat = null;
    if ($cat) return $cat;
    $s = season_no();
    $cat = [
        // Koban packs (USD). Bonus Koban is shown as a separate number.
        'packs' => [
            ['id' => 'k120',   'koban' => 120,   'bonus' => 0,    'usd' => 0.99,  'name' => 'Pouch of Koban'],
            ['id' => 'k650',   'koban' => 600,   'bonus' => 50,   'usd' => 4.99,  'name' => 'Purse of Koban'],
            ['id' => 'k1400',  'koban' => 1200,  'bonus' => 200,  'usd' => 9.99,  'name' => 'Chest of Koban', 'tag' => 'Popular'],
            ['id' => 'k3000',  'koban' => 2400,  'bonus' => 600,  'usd' => 19.99, 'name' => 'Vault of Koban'],
            ['id' => 'k8000',  'koban' => 6000,  'bonus' => 2000, 'usd' => 49.99, 'name' => 'Treasury of Koban', 'tag' => 'Best value'],
            ['id' => 'k17000', 'koban' => 12000, 'bonus' => 5000, 'usd' => 99.99, 'name' => "Shogun's Hoard"],
        ],
        // one-time offers
        'offers' => [
            ['id' => 'starter', 'usd' => 2.99, 'name' => 'Starter Pack', 'koban' => 300, 'items' => ['frame_lacquer', 'title_initiate'], 'once' => true,
                'desc' => '300 Koban, the Red Lacquer card frame and the Initiate title.'],
            ['id' => 'founder', 'usd' => 29.99, 'name' => "Founder's Bundle", 'koban' => 3000, 'items' => ['title_founder', 'frame_gold', 'table_gold', 'fx_money', 'ring_gold'], 'once' => true,
                'until' => eco_settings()['founder_until'], 'desc' => '3,000 Koban, the Founder title (never sold again), Gold Leaf frame, Edo Gold table, Gold Rain victory and a gold name ring.'],
            ['id' => 'scroll', 'usd' => 9.99, 'koban_price' => 2850, 'name' => "Season $s Scroll", 'scroll' => 1, 'desc' => 'Unlock the premium track of this season: six Shadow Ink cards, a card back, a share card theme, cosmetics and 1,225 Koban back. Plus a free Mission Reroll every week.'],
            ['id' => 'scrollplus', 'usd' => 24.99, 'name' => "Season $s Scroll+", 'scroll' => 1, 'xp' => 15 * TIER_XP, 'boost' => 'xp7', 'plus' => 1, 'koban' => 0, 'desc' => 'The premium Scroll, 15 tiers unlocked right away, a 7-day XP Boost, and the Bounty Board free every week this season.'],
            ['id' => 'plusup', 'usd' => 14.99, 'name' => "Season $s Scroll+ upgrade", 'xp' => 15 * TIER_XP, 'boost' => 'xp7', 'plus' => 1, 'koban' => 0, 'needs' => 'scroll', 'desc' => 'Already have the Scroll? Upgrade to Scroll+: 15 tiers right away, a 7-day XP Boost and the Bounty Board free every week this season.'],
            ['id' => 'moon', 'usd' => 4.99, 'name' => 'Koban Moon', 'koban' => 300, 'moon' => 30, 'desc' => '300 Koban now, then 60 more every day for 30 days when you collect your daily gift. 2,100 Koban in all, the best value in the shop.', 'tag' => 'Best value'],
        ],
        // things you use up, bought with Koban
        'goods' => eco_goods(),
        // cosmetics bought with Koban. Slot decides where it shows.
        //MC 2026-10-10 every Koban price here is 3x what it was. An active free player was earning 1,000 to 1,500 Koban a
        //   week from gifts, streaks, missions and X tasks, enough for two to four items, so nobody needed to buy Koban.
        //   Now a mid item takes one to two weeks of play and the showpieces take a month, or a pack.
        //MC 2026-10-10 then every price up 50% again, and 2x for anything that moves (Animated tags, victory effects, page
        //   effects, the neon nameplate). Rounded to the nearest 50 under 2,000 and the nearest 100 from 2,000 up. Earning didn't change.
        'items' => [
            // card frames: your hand, and your plays in live matches
            ['id' => 'frame_lacquer', 'slot' => 'frame', 'name' => 'Red Lacquer', 'koban' => 1150],
            ['id' => 'frame_sakura',  'slot' => 'frame', 'name' => 'Sakura', 'koban' => 2000],
            ['id' => 'frame_jade',    'slot' => 'frame', 'name' => 'Jade', 'koban' => 2000],
            ['id' => 'frame_obsidian','slot' => 'frame', 'name' => 'Obsidian', 'koban' => 2900],
            ['id' => 'frame_gold',    'slot' => 'frame', 'name' => 'Gold Leaf', 'koban' => 4100],
            ['id' => 'frame_kami',    'slot' => 'frame', 'name' => 'Kami Flame', 'koban' => 10800, 'tag' => 'Animated'],
            ['id' => 'frame_moon',    'slot' => 'frame', 'name' => 'Moonlit Ink', 'scroll' => true],
            ['id' => 'frame_archive', 'slot' => 'frame', 'name' => 'Archivist', 'earned' => 'collection'],
            // table themes
            ['id' => 'table_ink',     'slot' => 'table', 'name' => 'Ink Wash', 'koban' => 1800],
            ['id' => 'table_sakura',  'slot' => 'table', 'name' => 'Sakura Night', 'koban' => 2700],
            ['id' => 'table_crimson', 'slot' => 'table', 'name' => 'Crimson War', 'koban' => 2700],
            ['id' => 'table_gold',    'slot' => 'table', 'name' => 'Edo Gold', 'koban' => 5000],
            ['id' => 'table_moon',    'slot' => 'table', 'name' => 'Moon Garden', 'scroll' => true],
            // victory effects
            ['id' => 'fx_cyan',       'slot' => 'fx', 'name' => 'Cyan Surge', 'koban' => 2400],
            ['id' => 'fx_crimson',    'slot' => 'fx', 'name' => 'Crimson Blossoms', 'koban' => 3000],
            ['id' => 'fx_lightning',  'slot' => 'fx', 'name' => 'Lightning Strike', 'koban' => 3600],
            ['id' => 'fx_money',      'slot' => 'fx', 'name' => 'Gold Rain', 'koban' => 4800],
            ['id' => 'fx_btc',        'slot' => 'fx', 'name' => 'Bitcoin Rain', 'koban' => 5400],
            // titles: under your name on the boards and at the live table
            ['id' => 'title_ronin',   'slot' => 'title', 'name' => 'Ronin', 'koban' => 700],
            ['id' => 'title_oni',     'slot' => 'title', 'name' => 'Oni', 'koban' => 1350],
            ['id' => 'title_daimyo',  'slot' => 'title', 'name' => 'Daimyo', 'koban' => 3200],
            ['id' => 'title_broker',  'slot' => 'title', 'name' => 'Shadow Broker', 'koban' => 4500],
            ['id' => 'title_shogun',  'slot' => 'title', 'name' => 'Shogun', 'koban' => 9000],
            ['id' => 'title_kami',    'slot' => 'title', 'name' => 'Kami of Chaos', 'koban' => 15800],
            //MC 2026-10-09 more titles, from cheap to show-off
            ['id' => 'title_blade',   'slot' => 'title', 'name' => 'Silent Blade', 'koban' => 900],
            ['id' => 'title_lantern', 'slot' => 'title', 'name' => 'Lantern Keeper', 'koban' => 1150],
            ['id' => 'title_tactician','slot' => 'title', 'name' => 'Tactician', 'koban' => 2000],
            ['id' => 'title_warlord', 'slot' => 'title', 'name' => 'Warlord', 'koban' => 4100],
            ['id' => 'title_ghost',   'slot' => 'title', 'name' => 'Ghost of Edo', 'koban' => 6300],
            ['id' => 'title_emperor', 'slot' => 'title', 'name' => 'Shadow Emperor', 'koban' => 22500],
            ['id' => 'title_initiate','slot' => 'title', 'name' => 'Initiate', 'offer' => 'starter'],
            ['id' => 'title_founder', 'slot' => 'title', 'name' => 'Founder', 'offer' => 'founder'],
            ['id' => 'title_wanderer','slot' => 'title', 'name' => 'Wanderer', 'scroll' => true],
            ['id' => 'title_bearer',  'slot' => 'title', 'name' => 'Scroll Bearer', 'scroll' => true],
            ['id' => 'title_moon',    'slot' => 'title', 'name' => 'Moon Shogun', 'scroll' => true],
            ['id' => 'title_holder',  'slot' => 'title', 'name' => 'Holder', 'holder' => true],
            ['id' => 'title_champ',   'slot' => 'title', 'name' => 'League Champion', 'earned' => true],
            ['id' => 'title_cup',     'slot' => 'title', 'name' => 'Cup Champion', 'earned' => true],
            ['id' => 'title_club15',  'slot' => 'title', 'name' => '15 Club', 'earned' => 'bounty'],   //MC 2026-10-09 won holding 15 Regions
            ['id' => 'title_collector','slot' => 'title', 'name' => 'Collector', 'earned' => 'collection'],
            ['id' => 'title_curator', 'slot' => 'title', 'name' => 'Curator', 'earned' => 'collection'],
            ['id' => 'title_master',  'slot' => 'title', 'name' => 'Grandmaster', 'earned' => 'mastery'],
            ['id' => 'title_diamond', 'slot' => 'title', 'name' => 'Diamond Hands', 'earned' => 'loyal'],   //MC 2026-10-15 90 days holding Kusama Cadet or higher
            ['id' => 'title_ancient', 'slot' => 'title', 'name' => 'Ancient Holder', 'earned' => 'loyal'],  //MC 2026-10-15 180 days
            ['id' => 'title_rk_jade', 'slot' => 'title', 'name' => 'Jade Ranked', 'earned' => 'ranked'],
            ['id' => 'title_rk_shogun','slot' => 'title', 'name' => 'Ranked Shogun', 'earned' => 'ranked'],
            // name rings on the leaderboard and live table
            ['id' => 'ring_red',      'slot' => 'ring', 'name' => 'Vermilion Ring', 'koban' => 1350],
            ['id' => 'ring_jade',     'slot' => 'ring', 'name' => 'Jade Ring', 'koban' => 1350],
            ['id' => 'ring_gold',     'slot' => 'ring', 'name' => 'Gold Ring', 'koban' => 3200],
            //MC 2026-10-09 more name rings
            ['id' => 'ring_sakura',   'slot' => 'ring', 'name' => 'Sakura Ring', 'koban' => 1350],
            ['id' => 'ring_cyan',     'slot' => 'ring', 'name' => 'Cyan Ring', 'koban' => 1350],
            ['id' => 'ring_violet',   'slot' => 'ring', 'name' => 'Violet Ring', 'koban' => 1600],
            ['id' => 'ring_ember',    'slot' => 'ring', 'name' => 'Ember Ring', 'koban' => 2300],
            ['id' => 'ring_moon',     'slot' => 'ring', 'name' => 'Silver Moon Ring', 'scroll' => true],
            ['id' => 'ring_holder',   'slot' => 'ring', 'name' => 'Holder Ring', 'holder' => true],
            // card backs: the back of your Chaos cards, on your draws and on every rival's screen in live matches
            ['id' => 'back_seigaiha', 'slot' => 'back', 'name' => 'Seigaiha Waves', 'earned' => 'collection'],
            ['id' => 'back_torii',    'slot' => 'back', 'name' => 'Red Torii', 'koban' => 1600],
            ['id' => 'back_koban',    'slot' => 'back', 'name' => 'Koban Hoard', 'koban' => 2500],
            ['id' => 'back_neon',     'slot' => 'back', 'name' => 'Neon Grid', 'koban' => 2500],
            ['id' => 'back_dragon',   'slot' => 'back', 'name' => 'Dragon Scale', 'koban' => 5400, 'tag' => 'Animated'],
            ['id' => 'back_sigil',    'slot' => 'back', 'name' => 'Shadow Sigil', 'scroll' => true],
            ['id' => 'back_holder',   'slot' => 'back', 'name' => 'Holder Seal', 'holder' => true],
            ['id' => 'back_vault',    'slot' => 'back', 'name' => 'Archive Vault', 'earned' => 'collection'],
            // share card themes: the picture on every result you share to X, and on your wins in the Telegram chat
            ['id' => 'share_sakura',  'slot' => 'share', 'name' => 'Hanami', 'koban' => 1800],
            ['id' => 'share_crimson', 'slot' => 'share', 'name' => 'War Banner', 'koban' => 1800],
            ['id' => 'share_gold',    'slot' => 'share', 'name' => 'Gilded', 'koban' => 2900],
            ['id' => 'share_neon',    'slot' => 'share', 'name' => 'Neon Tokyo', 'koban' => 2900],
            ['id' => 'share_moon',    'slot' => 'share', 'name' => 'Moonrise', 'scroll' => true],
            ['id' => 'share_archive', 'slot' => 'share', 'name' => 'Archive Scroll', 'earned' => 'collection'],
            ['id' => 'share_holder',  'slot' => 'share', 'name' => 'Holder Seal', 'holder' => true],
            // Shadow skins ("Shades"): the Unbound hood in a Shytoshi Shadow's colours and traits. Your look at the table, on the boards
            // and on your share card. Every one is named across the bottom, so it never passes for a numbered Shadow: that stays a holder's.
            ['id' => 'skin_void',    'slot' => 'skin', 'name' => 'Void Shade', 'koban' => 1350, 'trait' => 'No aura'],
            ['id' => 'skin_cyan',    'slot' => 'skin', 'name' => 'Cyan Shade', 'koban' => 2000, 'trait' => 'Electric Cyan'],
            ['id' => 'skin_crimson', 'slot' => 'skin', 'name' => 'Crimson Shade', 'koban' => 2000, 'trait' => 'Crimson Glow'],
            ['id' => 'skin_storm',   'slot' => 'skin', 'name' => 'Storm Shade', 'koban' => 2700, 'trait' => 'Lightning Aura'],
            ['id' => 'skin_gold',    'slot' => 'skin', 'name' => 'Gold Shade', 'koban' => 3600, 'trait' => 'Money Aura'],
            ['id' => 'skin_btc',     'slot' => 'skin', 'name' => 'Bitcoin Shade', 'koban' => 4100, 'trait' => 'BTC Aura'],
            ['id' => 'skin_oni',     'slot' => 'skin', 'name' => 'Oni Shade', 'koban' => 5000, 'tag' => 'Masked'],
            ['id' => 'skin_kitsune', 'slot' => 'skin', 'name' => 'Kitsune Shade', 'koban' => 5000, 'tag' => 'Masked'],
            ['id' => 'skin_kami',    'slot' => 'skin', 'name' => 'Kami Shade', 'koban' => 10800, 'tag' => 'Animated'],
            // Shadow Halos: animated frames around a holder's own Shadow. Only a wallet holding a Shadow can buy or wear one.
            ['id' => 'halo_moon',    'slot' => 'halo', 'name' => 'Moonlit Halo', 'koban' => 2700, 'shadow' => true],
            ['id' => 'halo_sakura',  'slot' => 'halo', 'name' => 'Sakura Halo', 'koban' => 2700, 'shadow' => true],
            ['id' => 'halo_storm',   'slot' => 'halo', 'name' => 'Storm Halo', 'koban' => 4500, 'shadow' => true, 'tag' => 'Animated'],
            ['id' => 'halo_shogun',  'slot' => 'halo', 'name' => 'Shogun Halo', 'koban' => 5400, 'shadow' => true],
            ['id' => 'halo_kami',    'slot' => 'halo', 'name' => 'Kami Halo', 'koban' => 9000, 'shadow' => true, 'tag' => 'Animated'],
            // live reaction packs (each adds 4 reactions)
            ['id' => 'emote_oni',     'slot' => 'emote', 'name' => 'Oni Pack', 'koban' => 1350, 'reacts' => [6, 7, 8, 9]],
            ['id' => 'emote_sakura',  'slot' => 'emote', 'name' => 'Sakura Pack', 'koban' => 1350, 'reacts' => [10, 11, 12, 13]],
            ['id' => 'emote_riches',  'slot' => 'emote', 'name' => 'Riches Pack', 'koban' => 1800, 'reacts' => [14, 15, 16, 17]],
            ['id' => 'emote_moon',    'slot' => 'emote', 'name' => 'Moon Pack', 'scroll' => true, 'reacts' => [18, 19, 20, 21]],
            //MC 2026-10-10 the Animated set for the game table: card backs, tables, victory effects, Region claim effects and
            //   turn auras. Every one moves, so they sit at the top of the shop. 'rar' is the rarity label (rare, epic,
            //   legendary, mythic). Backs, claim effects, turn auras and victory effects all show on rivals' screens in live matches.
            ['id' => 'back_tide',     'slot' => 'back', 'name' => 'Rolling Tide', 'koban' => 3500, 'rar' => 'rare', 'tag' => 'Animated'],
            ['id' => 'back_lantern',  'slot' => 'back', 'name' => 'Paper Lantern', 'koban' => 3500, 'rar' => 'rare', 'tag' => 'Animated'],
            ['id' => 'back_mon',      'slot' => 'back', 'name' => 'Turning Crest', 'koban' => 6000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'back_cascade',  'slot' => 'back', 'name' => 'Koban Cascade', 'koban' => 6000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'back_eye',      'slot' => 'back', 'name' => 'Waking Eye', 'koban' => 9000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'back_phoenix',  'slot' => 'back', 'name' => 'Phoenix Flame', 'koban' => 18000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'table_rain',    'slot' => 'table', 'name' => 'Rain on Washi', 'koban' => 7500, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'table_festival','slot' => 'table', 'name' => 'Festival Night', 'koban' => 7500, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'table_inkmoon', 'slot' => 'table', 'name' => 'Ink Moon', 'koban' => 11000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'table_radar',   'slot' => 'table', 'name' => 'War Room', 'koban' => 11000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'table_ember',   'slot' => 'table', 'name' => 'Ember Night', 'koban' => 11000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'table_storm',   'slot' => 'table', 'name' => 'Raijin Storm', 'koban' => 22000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'fx_seal',       'slot' => 'fx', 'name' => 'Seal Slam', 'koban' => 8000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'fx_ink',        'slot' => 'fx', 'name' => 'Sumi Splash', 'koban' => 8000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'fx_crane',      'slot' => 'fx', 'name' => 'Crane Flight', 'koban' => 8000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'fx_katana',     'slot' => 'fx', 'name' => 'Katana Slash', 'koban' => 12000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'fx_kobanburst', 'slot' => 'fx', 'name' => 'Koban Burst', 'koban' => 12000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'fx_kanji',      'slot' => 'fx', 'name' => 'Firework Kanji', 'koban' => 12000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'fx_dragon',     'slot' => 'fx', 'name' => 'Dragon Ascent', 'koban' => 30000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'cap_stamp',     'slot' => 'cap', 'name' => 'Hanko Stamp', 'koban' => 4000, 'rar' => 'rare', 'tag' => 'Animated'],
            ['id' => 'cap_enso',      'slot' => 'cap', 'name' => 'Ensō Circle', 'koban' => 4000, 'rar' => 'rare', 'tag' => 'Animated'],
            ['id' => 'cap_petals',    'slot' => 'cap', 'name' => 'Petal Burst', 'koban' => 6500, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'cap_banner',    'slot' => 'cap', 'name' => 'War Banner', 'koban' => 6500, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'cap_thunder',   'slot' => 'cap', 'name' => 'Thunderclap', 'koban' => 10000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'turn_ink',      'slot' => 'turn', 'name' => 'Ink Tide', 'koban' => 4000, 'rar' => 'rare', 'tag' => 'Animated'],
            ['id' => 'turn_sakura',   'slot' => 'turn', 'name' => 'Sakura Breeze', 'koban' => 7000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'turn_gold',     'slot' => 'turn', 'name' => 'Gold Current', 'koban' => 7000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'turn_spirit',   'slot' => 'turn', 'name' => 'Spirit Flames', 'koban' => 11000, 'rar' => 'legendary', 'tag' => 'Animated'],
            //MC 2026-10-14 the war table set, for the 3D command table (assets/map3d.js): felt (the cloth, frame and the
            //   room's light), land (the finish on the Region plates), pieces (the shape of your command pieces, which
            //   rivals see in live matches) and air (what drifts over the table). Priced as showpieces: the cheapest
            //   is a month of play, the mythics are a pack. Every animated one is a single extra layer on the table,
            //   so it costs nothing in frame rate.
            ['id' => 'felt_crimson',  'slot' => 'felt', 'name' => 'Crimson Felt', 'koban' => 6500, 'rar' => 'epic'],
            ['id' => 'felt_midnight', 'slot' => 'felt', 'name' => 'Midnight Felt', 'koban' => 6500, 'rar' => 'epic'],
            ['id' => 'felt_obsidian', 'slot' => 'felt', 'name' => 'Obsidian Glass', 'koban' => 9500, 'rar' => 'legendary'],
            ['id' => 'felt_ocean',    'slot' => 'felt', 'name' => 'Living Ocean', 'koban' => 16000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'felt_storm',    'slot' => 'felt', 'name' => 'Raijin Table', 'koban' => 28000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'land_jade',     'slot' => 'land', 'name' => 'Jade Land', 'koban' => 8000, 'rar' => 'epic'],
            ['id' => 'land_obsidian', 'slot' => 'land', 'name' => 'Obsidian Land', 'koban' => 8000, 'rar' => 'epic'],
            ['id' => 'land_gold',     'slot' => 'land', 'name' => 'Gold Leaf Land', 'koban' => 14000, 'rar' => 'legendary'],
            ['id' => 'land_holo',     'slot' => 'land', 'name' => 'Hologram Land', 'koban' => 24000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'piece_torii',   'slot' => 'piece', 'name' => 'Torii Gates', 'koban' => 7500, 'rar' => 'epic'],
            ['id' => 'piece_pagoda',  'slot' => 'piece', 'name' => 'Pagodas', 'koban' => 7500, 'rar' => 'epic'],
            ['id' => 'piece_katana',  'slot' => 'piece', 'name' => 'Katanas', 'koban' => 11000, 'rar' => 'legendary'],
            ['id' => 'piece_koban',   'slot' => 'piece', 'name' => 'Koban Stacks', 'koban' => 15000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'piece_dragon',  'slot' => 'piece', 'name' => 'Dragon Idols', 'koban' => 30000, 'rar' => 'mythic', 'tag' => 'Animated'],
            ['id' => 'air_fireflies', 'slot' => 'air', 'name' => 'Fireflies', 'koban' => 6000, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'air_snow',      'slot' => 'air', 'name' => 'First Snow', 'koban' => 7500, 'rar' => 'epic', 'tag' => 'Animated'],
            ['id' => 'air_sakura',    'slot' => 'air', 'name' => 'Sakura Fall', 'koban' => 9000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'air_embers',    'slot' => 'air', 'name' => 'Rising Embers', 'koban' => 12000, 'rar' => 'legendary', 'tag' => 'Animated'],
            ['id' => 'air_lanterns',  'slot' => 'air', 'name' => 'Lantern Festival', 'koban' => 20000, 'rar' => 'mythic', 'tag' => 'Animated'],
            // ---- Profile Studio: your public player page (/p/name). Sold only on the profile page, never in the game's shop.
            // banners: the art behind your page header
            ['id' => 'banner_ink',     'slot' => 'banner', 'name' => 'Ink Mountains', 'koban' => 1150],
            ['id' => 'banner_sakura',  'slot' => 'banner', 'name' => 'Sakura Night', 'koban' => 1800],
            ['id' => 'banner_torii',   'slot' => 'banner', 'name' => 'Torii at Dusk', 'koban' => 2000],
            ['id' => 'banner_wave',    'slot' => 'banner', 'name' => 'The Great Wave', 'koban' => 2700],
            ['id' => 'banner_neon',    'slot' => 'banner', 'name' => 'Neon Tokyo', 'koban' => 2900],
            ['id' => 'banner_vault',   'slot' => 'banner', 'name' => 'Koban Vault', 'koban' => 3600],
            ['id' => 'banner_dragon',  'slot' => 'banner', 'name' => 'Dragon Storm', 'koban' => 7800, 'tag' => 'Animated'],
            ['id' => 'banner_kami',    'slot' => 'banner', 'name' => 'Kami Realm', 'koban' => 12000, 'tag' => 'Animated'],
            //MC 2026-10-09 four new banners
            ['id' => 'banner_bamboo',  'slot' => 'banner', 'name' => 'Bamboo Grove', 'koban' => 2000],
            ['id' => 'banner_redmoon', 'slot' => 'banner', 'name' => 'Red Moon Castle', 'koban' => 2700],
            ['id' => 'banner_fuji',    'slot' => 'banner', 'name' => 'Fuji Dawn', 'koban' => 3400],
            ['id' => 'banner_lantern', 'slot' => 'banner', 'name' => 'Lantern Festival', 'koban' => 4300],
            ['id' => 'banner_holder',  'slot' => 'banner', 'name' => 'Shadow Council', 'holder' => true],
            // nameplates: how your name is written on your page
            ['id' => 'plate_brush',    'slot' => 'plate', 'name' => 'Brushstroke', 'koban' => 1350],
            ['id' => 'plate_sakura',   'slot' => 'plate', 'name' => 'Sakura Bloom', 'koban' => 1600],
            ['id' => 'plate_neon',     'slot' => 'plate', 'name' => 'Neon Sign', 'koban' => 3000],
            ['id' => 'plate_gold',     'slot' => 'plate', 'name' => 'Gold Leaf', 'koban' => 3200],
            ['id' => 'plate_holo',     'slot' => 'plate', 'name' => 'Holo Foil', 'koban' => 7200, 'tag' => 'Animated'],
            //MC 2026-10-09 four new nameplates
            ['id' => 'plate_ember',    'slot' => 'plate', 'name' => 'Ember', 'koban' => 1800],
            ['id' => 'plate_frost',    'slot' => 'plate', 'name' => 'Frost', 'koban' => 1800],
            ['id' => 'plate_chrome',   'slot' => 'plate', 'name' => 'Chrome', 'koban' => 2900],
            ['id' => 'plate_vapor',    'slot' => 'plate', 'name' => 'Vaporwave', 'koban' => 5400, 'tag' => 'Animated'],
            // page effects: drifting over your page header
            ['id' => 'pfx_snow',       'slot' => 'pfx', 'name' => 'Snowfall', 'koban' => 2400],
            ['id' => 'pfx_sakura',     'slot' => 'pfx', 'name' => 'Falling Sakura', 'koban' => 3000],
            ['id' => 'pfx_fireflies',  'slot' => 'pfx', 'name' => 'Fireflies', 'koban' => 3600],
            ['id' => 'pfx_embers',     'slot' => 'pfx', 'name' => 'Rising Embers', 'koban' => 4200],
            ['id' => 'pfx_koban',      'slot' => 'pfx', 'name' => 'Koban Shower', 'koban' => 5400],
            ['id' => 'pfx_storm',      'slot' => 'pfx', 'name' => 'Thunderstorm', 'koban' => 7200],
            //MC 2026-10-09 three new page effects
            ['id' => 'pfx_maple',      'slot' => 'pfx', 'name' => 'Autumn Maple', 'koban' => 3000],
            ['id' => 'pfx_lanterns',   'slot' => 'pfx', 'name' => 'Sky Lanterns', 'koban' => 4500],
            ['id' => 'pfx_stars',      'slot' => 'pfx', 'name' => 'Shooting Stars', 'koban' => 6000],
            // accents: the colour of your page's cards, borders and highlights
            ['id' => 'accent_vermilion', 'slot' => 'accent', 'name' => 'Vermilion', 'koban' => 700],
            ['id' => 'accent_jade',      'slot' => 'accent', 'name' => 'Jade', 'koban' => 700],
            ['id' => 'accent_violet',    'slot' => 'accent', 'name' => 'Violet', 'koban' => 700],
            ['id' => 'accent_ice',       'slot' => 'accent', 'name' => 'Glacier', 'koban' => 900],
            ['id' => 'accent_gold',      'slot' => 'accent', 'name' => 'Imperial Gold', 'koban' => 1350],
            ['id' => 'accent_obsidian',  'slot' => 'accent', 'name' => 'Obsidian', 'koban' => 1350],
            //MC 2026-10-09 three new accents
            ['id' => 'accent_sakura',    'slot' => 'accent', 'name' => 'Sakura', 'koban' => 700],
            ['id' => 'accent_ocean',     'slot' => 'accent', 'name' => 'Deep Ocean', 'koban' => 900],
            ['id' => 'accent_ember',     'slot' => 'accent', 'name' => 'Ember', 'koban' => 1150],
            // unlocks: new parts for your page, bought once
            ['id' => 'unlock_showcase', 'slot' => 'unlock', 'name' => 'Card Showcase', 'koban' => 2300],
            ['id' => 'unlock_motto',    'slot' => 'unlock', 'name' => 'Motto', 'koban' => 1150],
            //MC 2026-10-09 two new page features: your picture comes alive like a Living Shadow, and a visit counter
            ['id' => 'unlock_portrait', 'slot' => 'unlock', 'name' => 'Living Portrait', 'koban' => 2700],
            ['id' => 'unlock_visits',   'slot' => 'unlock', 'name' => 'Visit Counter', 'koban' => 1350],
            //MC 2026-10-10 the animated Profile Studio collection: 41 looks across banners, nameplates, effects and two new
            //   slots, portrait frames (pframe) and seals. Priced as the long grind: a Rare is a couple of weeks of play, a
            //   Legendary a month or more, a Mythic is the show-off. 'rarity' drives the Studio label. No 'tag' => 'Animated'
            //   on purpose, so a shop-wide rule that doubles tagged items doesn't double these a second time. The looks live
            //   in assets/pagelook.js and assets/profile-fx.css.
            ['id' => 'banner_inkclouds', 'slot' => 'banner', 'name' => 'Drifting Ink', 'koban' => 5000, 'rarity' => 'rare', 'desc' => 'Sumi ink clouds roll across cream washi under a red sun.'],
            ['id' => 'banner_washirain', 'slot' => 'banner', 'name' => 'Rain on Washi', 'koban' => 5500, 'rarity' => 'rare', 'desc' => 'Rain streaks the paper and ink drops ripple out.'],
            ['id' => 'banner_emberstorm', 'slot' => 'banner', 'name' => 'Ember Storm', 'koban' => 8000, 'rarity' => 'epic', 'desc' => 'A furnace glow with embers whirling up through the smoke.'],
            ['id' => 'banner_sakurawind', 'slot' => 'banner', 'name' => 'Sakura Wind', 'koban' => 8500, 'rarity' => 'epic', 'desc' => 'A blossoming branch sways at dusk and sheds its petals.'],
            ['id' => 'banner_matsuri', 'slot' => 'banner', 'name' => 'Matsuri Night', 'koban' => 9500, 'rarity' => 'epic', 'desc' => 'Strings of paper lanterns swing and flicker over the festival.'],
            ['id' => 'banner_dawn', 'slot' => 'banner', 'name' => 'Vermilion Dawn', 'koban' => 10500, 'rarity' => 'epic', 'desc' => 'A red sun climbs over ink mountains as the mist drifts by.'],
            ['id' => 'banner_koi', 'slot' => 'banner', 'name' => 'Koi Pond', 'koban' => 15000, 'rarity' => 'legendary', 'desc' => 'Two koi circle under shimmering water and lily pads.'],
            ['id' => 'banner_kinpaku', 'slot' => 'banner', 'name' => 'Kinpaku', 'koban' => 17500, 'rarity' => 'legendary', 'desc' => 'Black lacquer and gold leaf, with light sweeping across it.'],
            ['id' => 'banner_hokusai', 'slot' => 'banner', 'name' => 'Hokusai Tide', 'koban' => 20000, 'rarity' => 'legendary', 'desc' => 'Three bands of waves roll in under Fuji, without end.'],
            ['id' => 'banner_eye', 'slot' => 'banner', 'name' => 'Eye of Providence', 'koban' => 40000, 'rarity' => 'mythic', 'desc' => 'A starlit pyramid, turning rays and an eye that watches back.'],
            ['id' => 'plate_brushline', 'slot' => 'plate', 'name' => 'Brush Underline', 'koban' => 3000, 'rarity' => 'rare', 'desc' => 'A vermilion brushstroke paints itself under your name.'],
            ['id' => 'plate_brokenneon', 'slot' => 'plate', 'name' => 'Broken Neon', 'koban' => 3500, 'rarity' => 'rare', 'desc' => 'A pink tube sign that buzzes and stutters like a back alley bar.'],
            ['id' => 'plate_glitch', 'slot' => 'plate', 'name' => 'Glitch', 'koban' => 4500, 'rarity' => 'rare', 'desc' => 'Your name splits into red and cyan and snaps back.'],
            ['id' => 'plate_inkbleed', 'slot' => 'plate', 'name' => 'Vermilion Bleed', 'koban' => 6500, 'rarity' => 'epic', 'desc' => 'Red ink that keeps soaking into the paper around it.'],
            ['id' => 'plate_goldfoil', 'slot' => 'plate', 'name' => 'Gold Foil', 'koban' => 7500, 'rarity' => 'epic', 'desc' => 'Pressed gold foil with a bright glint running through.'],
            ['id' => 'plate_woodblock', 'slot' => 'plate', 'name' => 'Woodblock Print', 'koban' => 8000, 'rarity' => 'epic', 'desc' => 'Cream, red and black blocks sliding in and out of register.'],
            ['id' => 'plate_starlight', 'slot' => 'plate', 'name' => 'Starlight', 'koban' => 9000, 'rarity' => 'epic', 'desc' => 'Silver letters with stars that glint on and off.'],
            ['id' => 'plate_kamiflame', 'slot' => 'plate', 'name' => 'Kami Flame', 'koban' => 15000, 'rarity' => 'legendary', 'desc' => 'Your name burns from white gold to violet.'],
            ['id' => 'pfx_sweep', 'slot' => 'pfx', 'name' => 'Light Sweep', 'koban' => 3500, 'rarity' => 'rare', 'desc' => 'A beam of light slides across your header.'],
            ['id' => 'pfx_ash', 'slot' => 'pfx', 'name' => 'Falling Ash', 'koban' => 3500, 'rarity' => 'rare', 'desc' => 'Grey ash drifts down, a few flakes still glowing.'],
            ['id' => 'pfx_goldust', 'slot' => 'pfx', 'name' => 'Gold Dust', 'koban' => 4500, 'rarity' => 'rare', 'desc' => 'Tiny gold stars glint all over your header.'],
            ['id' => 'pfx_sparks', 'slot' => 'pfx', 'name' => 'Forge Sparks', 'koban' => 6500, 'rarity' => 'epic', 'desc' => 'White hot sparks fly up off the anvil.'],
            ['id' => 'pfx_inkdrops', 'slot' => 'pfx', 'name' => 'Ink Drops', 'koban' => 7000, 'rarity' => 'epic', 'desc' => 'Drops of white and vermilion ink fall and ripple out.'],
            ['id' => 'pfx_wisps', 'slot' => 'pfx', 'name' => 'Spirit Wisps', 'koban' => 7500, 'rarity' => 'epic', 'desc' => 'Blue hitodama flames wander up through the dark.'],
            ['id' => 'pfx_cranes', 'slot' => 'pfx', 'name' => 'Paper Cranes', 'koban' => 8500, 'rarity' => 'epic', 'desc' => 'Folded cranes flap their way across your page.'],
            ['id' => 'pfx_hanabi', 'slot' => 'pfx', 'name' => 'Hanabi', 'koban' => 16000, 'rarity' => 'legendary', 'desc' => 'Fireworks bloom over your header, one after another.'],
            ['id' => 'pframe_koban', 'slot' => 'pframe', 'name' => 'Koban Orbit', 'koban' => 5500, 'rarity' => 'rare', 'desc' => 'Six gold koban circle your picture.'],
            ['id' => 'pframe_sakura', 'slot' => 'pframe', 'name' => 'Sakura Wreath', 'koban' => 6000, 'rarity' => 'rare', 'desc' => 'A wreath of blossoms that breathes and sheds a petal now and then.'],
            ['id' => 'pframe_ink', 'slot' => 'pframe', 'name' => 'Ink Halo', 'koban' => 8500, 'rarity' => 'epic', 'desc' => 'An enso circle brushes itself around you in one stroke.'],
            ['id' => 'pframe_hanko', 'slot' => 'pframe', 'name' => 'Hanko Ring', 'koban' => 9500, 'rarity' => 'epic', 'desc' => 'A turning vermilion seal ring carved with kanji.'],
            ['id' => 'pframe_lightning', 'slot' => 'pframe', 'name' => 'Raijin Ring', 'koban' => 11000, 'rarity' => 'epic', 'desc' => 'Lightning crackles around your picture.'],
            ['id' => 'pframe_foxfire', 'slot' => 'pframe', 'name' => 'Kitsune Fire', 'koban' => 18000, 'rarity' => 'legendary', 'desc' => 'Three foxfire flames chase each other around you.'],
            ['id' => 'pframe_dragon', 'slot' => 'pframe', 'name' => 'Golden Dragon', 'koban' => 24000, 'rarity' => 'legendary', 'desc' => 'A gold dragon coils around your picture, chasing its pearl.'],
            ['id' => 'pframe_eye', 'slot' => 'pframe', 'name' => 'All-Seeing Eye', 'koban' => 45000, 'rarity' => 'mythic', 'desc' => 'Gold rays turn behind you and the eye above you blinks.'],
            ['id' => 'seal_kage', 'slot' => 'seal', 'name' => 'Shadow Seal', 'koban' => 3000, 'rarity' => 'rare', 'desc' => 'A red hanko with 影, stamped on your picture as the page opens.'],
            ['id' => 'seal_kin', 'slot' => 'seal', 'name' => 'Gold Seal', 'koban' => 7000, 'rarity' => 'epic', 'desc' => 'A gold 金 seal with a glint that never stops.'],
            ['id' => 'seal_oni', 'slot' => 'seal', 'name' => 'Oni Seal', 'koban' => 8000, 'rarity' => 'epic', 'desc' => 'A round 鬼 seal that glows like a coal.'],
            ['id' => 'seal_mon', 'slot' => 'seal', 'name' => 'Shogun Crest', 'koban' => 10000, 'rarity' => 'epic', 'desc' => 'A gold mitsudomoe crest that slowly turns.'],
            ['id' => 'seal_ryu', 'slot' => 'seal', 'name' => 'Dragon Seal', 'koban' => 15000, 'rarity' => 'legendary', 'desc' => 'Black lacquer, a gold 龍 and a spark running round the edge.'],
            ['id' => 'seal_kami', 'slot' => 'seal', 'name' => 'Kami Seal', 'koban' => 19000, 'rarity' => 'legendary', 'desc' => 'A shining 神 badge with rays turning behind it.'],
            ['id' => 'seal_eye', 'slot' => 'seal', 'name' => 'Illuminati Seal', 'koban' => 32000, 'rarity' => 'mythic', 'desc' => 'The eye in the triangle, glowing and blinking.'],
            //MC 2026-10-12 the Dev collection: free, never sold, never gifted. Only the profiles in eco setting dev_pids own
            //   them (eco_dev_grant), and the Shop and Studio only list them to someone who owns them.
            ['id' => 'banner_amaterasu', 'slot' => 'banner', 'name' => 'Amaterasu Dawn', 'koban' => 0, 'rarity' => 'dev', 'dev' => 1, 'desc' => 'The sun goddess rises behind a torii in the sea, rays turning, cranes crossing the light.'],
            ['id' => 'plate_kintsugi', 'slot' => 'plate', 'name' => 'Kintsugi', 'koban' => 0, 'rarity' => 'dev', 'dev' => 1, 'desc' => 'Porcelain letters mended with gold, light running along every seam.'],
            ['id' => 'pfx_shikigami', 'slot' => 'pfx', 'name' => 'Shikigami', 'koban' => 0, 'rarity' => 'dev', 'dev' => 1, 'desc' => 'Paper talismans wake up, spin and rise through your page.'],
            ['id' => 'pframe_torii', 'slot' => 'pframe', 'name' => 'Gate of the Maker', 'koban' => 0, 'rarity' => 'dev', 'dev' => 1, 'desc' => 'A torii over your picture, an aurora behind it and a ring of kanji turning round you.'],
            ['id' => 'seal_dev', 'slot' => 'seal', 'name' => 'Creator Seal', 'koban' => 0, 'rarity' => 'dev', 'dev' => 1, 'desc' => 'Black lacquer and gold, 創 for the one who made the game, with a living edge.'],
            ['id' => 'title_dev', 'slot' => 'title', 'name' => 'Dev', 'koban' => 0, 'dev' => 1],
        ],
    ];
    //MC 2026-10-12 the team's Koban prices (Admin > Shop > Shop prices); 'base' keeps the price written above
    foreach ($cat['items'] as &$it) if (!empty($it['koban'])) { $it['base'] = $it['koban']; $it['koban'] = shop_px('item', $it['id'], $it['base'], $it['slot'] ?? '', $it['rarity'] ?? ''); }
    unset($it);
    $cat['goods'] = eco_goods_priced();
    return $cat;
}
function eco_item($id) { foreach (eco_catalog()['items'] as $it) if ($it['id'] === $id) return $it; return null; }
function eco_product($id) {
    foreach (eco_catalog()['packs'] as $p) if ($p['id'] === $id) return $p + ['kind' => 'pack'];
    foreach (eco_catalog()['offers'] as $p) if ($p['id'] === $id) return $p + ['kind' => 'offer'];
    return null;
}

// The six cards a season's Scroll dresses in Shadow Ink, and the two its free track gives a finish
function season_cards($s = null) {
    $s = $s ?? season_no();
    $ids = array_keys(deck_cards());
    $seed = (int)sprintf('%u', crc32('shy-season-cards-' . $s));
    $out = [];
    while (count($out) < 8) { $c = $ids[seeded_pick($seed, count($ids))]; if (!in_array($c, $out, true)) $out[] = $c; }
    return $out;
}
// Season Scroll rewards per tier: [free reward, premium reward]. A reward is koban | item | fin [card, finish] | boost.
function scroll_rewards() {
    $sc = season_cards();
    $r = [];
    for ($t = 1; $t <= SCROLL_TIERS; $t++) {
        $free = in_array($t, [2, 5, 8, 11, 14, 17, 23, 26, 29], true) ? ['koban' => $t < 15 ? 20 : 30] : null;
        $r[$t] = [$free, ['koban' => 75]];
    }
    $r[4][0] = ['fin' => [$sc[6], 'gold']];
    $r[10][0] = ['item' => 'title_wanderer'];
    $r[12][0] = ['boost' => 'reroll'];
    $r[16][0] = ['fin' => [$sc[7], 'crimson']];
    $r[20][0] = ['koban' => 60];
    $r[30][0] = ['koban' => 100];
    $r[1][1] = ['item' => 'title_bearer'];
    $r[3][1] = ['fin' => [$sc[0], 'shadow']];
    $r[5][1] = ['item' => 'emote_moon'];
    $r[7][1] = ['boost' => 'xp3'];
    $r[8][1] = ['fin' => [$sc[1], 'shadow']];
    $r[10][1] = ['item' => 'share_moon'];
    $r[12][1] = ['item' => 'ring_moon'];
    $r[13][1] = ['fin' => [$sc[2], 'shadow']];
    $r[15][1] = ['item' => 'back_sigil'];
    $r[18][1] = ['item' => 'table_moon'];
    $r[20][1] = ['fin' => [$sc[3], 'shadow']];
    $r[23][1] = ['koban' => 125];
    $r[24][1] = ['item' => 'frame_moon'];
    $r[26][1] = ['fin' => [$sc[4], 'shadow']];
    $r[28][1] = ['koban' => 125];
    $r[29][1] = ['fin' => [$sc[5], 'shadow']];
    $r[30][1] = ['item' => 'title_moon'];
    return $r;
}

// ---------------------------------------------------------------- settings
function eco_settings() {
    static $s = null;
    if ($s !== null) return $s;
    $def = [
        'shop_open' => true,
        'founder_until' => '2026-11-07',
        'league_usd' => 100, 'league_share' => 20, 'league_split' => [25, 18, 13, 10, 8, 7, 6, 5, 4, 4],
        'cup_usd' => 50, 'cup_split' => [35, 25, 18, 12, 10],
        'season_usd' => 250, 'season_split' => [50, 30, 20],
        'min_games' => 3,
        'events' => [],   // [['name' => 'Double Points Weekend', 'from' => ts, 'to' => ts, 'mult' => 2]]
        //MC 2026-10-10 $SHY Army Ranks by $SHY held, and their weekly Koban (see HOLDER_PERKS for the rest of what each gets).
        //   Sapling starts at 1 so any $SHY in a connected wallet counts.
        'htiers' => HOLDER_TIERS_DEF,
        'hstip' => HOLDER_STIP_DEF,
        'burn_pct' => 15,          //MC 2026-10-10 % of every $SHY shop payment burned in the same transaction (0 turns it off)
        'bounty_usd' => 50,        //MC 2026-10-10 the 15 Club prize in USD, paid in $SHY by the payout button
        'league_koban' => [500, 350, 250, 200, 150, 120, 100, 80, 60, 50],   // in-game Koban for the weekly top 10, on top of $SHY
        'cup_koban' => [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        //MC 2026-10-12 prizes paid from shop sales. 'sales' sizes each pool as floor + pct% of the shop sales before it (the
        //   week before for the League and the Cup, the season itself for the Championship), never above max; 'fixed' is
        //   the old way (league_usd + league_share, cup_usd, season_usd). cash_top: places paid in $SHY, the places below
        //   get kswap Koban per $1 they would have won, on top of their usual Koban. Admin > Rewards > Prize budget.
        'prize_mode' => 'sales',
        'pp' => ['league' => ['floor' => 25, 'pct' => 40, 'max' => 100], 'cup' => ['floor' => 10, 'pct' => 10, 'max' => 50], 'season' => ['floor' => 50, 'pct' => 10, 'max' => 250]],
        'cash_top' => ['league' => 3, 'cup' => 3, 'season' => 3],
        'kswap' => 150,
        'runway_warn' => 4,        // email the team when the marketing wallet covers fewer weeks than this   //MC 2026-10-12 the same for the Holder Cup places (Admin > Rewards > Koban prizes)
        'idea_email' => 'shyjanedoe1@gmail.com',
        'x_post' => false,         // players post from the site through the X account (costs X credits); off = Share on X opens X with the result card
        'x_links' => false,        // X charges far more for posts that contain a link, so posts from the site go without one
        'payout_approve_usd' => 100,   // payouts at or above this (USD, per prize list) need a second admin to approve before sending; 0 = never
        'house_on' => true, 'house_cost' => 300, 'house_games' => 5, 'house_prize' => [300, 200, 100],   // Houses: Koban to found one, games needed first, Koban per member for the top 3 each week
        'ref_on' => true, 'ref_koban' => 150, 'ref_new' => 100, 'ref_holder' => 300, 'ref_games' => 3, 'ref_cap' => 10,   // invites: Koban for the inviter, a welcome for the new player, a bonus when they hold $SHY, games needed, rewarded invites a week
        'xt_on' => true, 'xt_koban' => 15, 'xt_bonus' => 25,   // Daily X tasks: on or off, Koban per task, bonus for all three (holders get double)
        'x_month_cap' => 300,      // most posts the site sends to X in a calendar month, across all players   // where new suggestions are emailed (blank turns email off)
        //MC 2026-10-11 automatic X posts: a player who connected X and turned on "Post my wins" gets their win posted for them.
        //   The admin switch turns the whole thing on or off. Tags go on every result post; no @mentions are ever added
        //   automatically (X treats automated mentions as spam and limits the account), the KOL list is for posting by hand.
        'x_autopost' => false, 'x_auto_day' => 3,
        'x_tags' => '$SHY #Solana #SolanaGaming',
        'x_kols' => '', 'x_kol_share' => false, 'x_always' => '@ShytoshiKusama', 'x_always_auto' => false, 'live_chat' => true,   //MC 2026-10-12 one account from x_kols in a player's own share
    ];
    $saved = is_file(ECOSET) ? load(ECOSET) : [];
    $s = array_merge($def, is_array($saved) ? $saved : []);
    holder_settings_fix($s);
    return $s;
}

// ---------------------------------------------------------------- time
function season_no($ts = null) {
    $ts = $ts ?? time();
    return max(1, intdiv($ts - strtotime(SEASON_EPOCH . ' 00:00:00 UTC'), SEASON_WEEKS * 7 * 86400) + 1);
}
function season_bounds($s) {
    $start = strtotime(SEASON_EPOCH . ' 00:00:00 UTC') + ($s - 1) * SEASON_WEEKS * 7 * 86400;
    return [$start, $start + SEASON_WEEKS * 7 * 86400];
}
function week_end_ts() { return strtotime('next monday 00:00:00 UTC', time()); }
function event_mult($ts = null) {
    $ts = $ts ?? time(); $m = 1;
    foreach (eco_settings()['events'] as $e) if ($ts >= ($e['from'] ?? 0) && $ts < ($e['to'] ?? 0)) $m = max($m, (float)($e['mult'] ?? 1));
    return $m;
}
function event_now() {
    $t = time();
    foreach (eco_settings()['events'] as $e) if ($t >= ($e['from'] ?? 0) && $t < ($e['to'] ?? 0)) return $e;
    // the next one coming up, so players can plan for it
    $next = null;
    foreach (eco_settings()['events'] as $e) if (($e['from'] ?? 0) > $t && (!$next || $e['from'] < $next['from'])) $next = $e;
    return $next ? $next + ['upcoming' => true] : null;
}

// ---------------------------------------------------------------- device keys
// A profile can be signed in on several devices: every device has its own key, and keys.php keeps all their hashes.
function keys_known($pid, $players = null, $holders = null) {
    $keys = load(KEYS);
    if (!empty($keys[$pid])) return $keys[$pid];
    $players = $players ?? load(PLAYERS); $holders = $holders ?? load(HOLDERS);
    $k = [];
    if (!empty($players[$pid]['kh'])) $k[] = $players[$pid]['kh'];
    if (!empty($holders[$pid]['kh'])) $k[] = $holders[$pid]['kh'];
    $eco = load(ECO);
    if (!empty($eco[$pid]['kh'])) $k[] = $eco[$pid]['kh'];
    return array_values(array_unique($k));
}
// true if this key may act for this profile (a brand-new profile is claimed by its first key). Call inside with_lock.
function key_ok($pid, $kh, $players = null, $holders = null) {
    $known = keys_known($pid, $players, $holders);
    if (!$known) return true;
    foreach ($known as $h) if (hash_equals($h, $kh)) return true;
    return false;
}
//MC 2026-10-11 about half the players had no row in keys.php, so every key check for them decoded players, holders and
//   the 1.4 MB economy.php to find their key. This copies every key already known into keys.php once (the slow path
//   stays as a fallback, so nothing that relies on it breaks). Call inside with_lock.
function keys_migrate_once() {
    $flag = DATA_DIR . '/keys-migrated.txt';
    if (is_file($flag)) return 0;
    $keys = load(KEYS); $n = 0;
    foreach ([load(PLAYERS), load(HOLDERS), load(ECO)] as $store) foreach ($store as $pid => $r) {
        if (!is_array($r) || empty($r['kh']) || !preg_match('/^[a-f0-9]{16}$/', (string)$pid)) continue;
        $list = $keys[$pid] ?? [];
        if (!in_array($r['kh'], $list, true)) { $list[] = $r['kh']; $keys[$pid] = array_slice($list, -8); $n++; }
    }
    if ($n) save(KEYS, $keys);
    @file_put_contents($flag, gmdate('c') . " added $n\n");
    return $n;
}
function key_add($pid, $kh) {
    $keys = load(KEYS);
    $list = $keys[$pid] ?? keys_known($pid);
    if (!in_array($kh, $list, true)) $list[] = $kh;
    $keys[$pid] = array_slice($list, -8);   // at most 8 devices
    save(KEYS, $keys);
}

// ---------------------------------------------------------------- bans
//MC 2026-10-11 a real ban. Admin "Remove" only took a player off the boards, and their next game put them straight back.
//   bans.php: 'p' => pid => [t, by, why, name], 'w' => wallet => pid, 'k' => device key hash => pid. A profile is banned
//   when its id, its linked wallet or one of its device keys is on the list: it can't start or save games, join live
//   tables or tournaments, or use the shop, and it's left off the boards and League prizes. Admin > Players lifts it.
define('BANS', DATA_DIR . '/bans.php');
const BANNED_MSG = 'This profile is suspended. If you think that\'s a mistake, contact the team.';
function bans($fresh = false) { static $b = null; if ($b === null || $fresh) { $b = load(BANS) + ['p' => [], 'w' => [], 'k' => []]; } return $b; }
function player_banned($pid, $holders = null) {
    $b = bans();
    if (!$b['p'] && !$b['w'] && !$b['k']) return false;
    if (isset($b['p'][$pid])) return true;
    $w = (string)(($holders ?? load(HOLDERS))[$pid]['wallet'] ?? '');
    if ($w !== '' && isset($b['w'][$w])) return true;
    if ($b['k']) foreach (load(KEYS)[$pid] ?? [] as $kh) if (isset($b['k'][$kh])) return true;
    return false;
}
// everyone banned right now, as pid => 1, for leaving them off a list ($players: pid => record)
function banned_in($players, $holders = null) {
    $b = bans(); if (!$b['p'] && !$b['w'] && !$b['k']) return [];
    $holders = $holders ?? load(HOLDERS); $out = [];
    foreach ($players as $pid => $_) if (player_banned($pid, $holders)) $out[$pid] = 1;
    return $out;
}

// ---------------------------------------------------------------- accounts
function eco_blank() {
    return ['koban' => 0, 'items' => [], 'eq' => [], 'sc' => ['s' => season_no(), 'xp' => 0, 'prem' => false, 'plus' => false, 'cf' => [], 'cp' => []],
        'st' => ['d' => '', 'n' => 0, 'best' => 0], 'xd' => ['d' => '', 'solo' => 0], 'once' => [], 'ledger' => [], 'spent_usd' => 0, 'since' => time(), 'beq' => 1,
        'vf' => [], 'veq' => [], 'cm' => [], 'cml' => [], 'cl' => [], 'boost' => [], 'fp' => []];
}
function eco_get(&$eco, $pid) {
    $a = $eco[$pid] ?? eco_blank();
    $old = !isset($a['beq']);
    $a += eco_blank();
    // a new season starts a new Scroll
    if (($a['sc']['s'] ?? 0) !== season_no()) $a['sc'] = ['s' => season_no(), 'xp' => 0, 'prem' => false, 'plus' => false, 'cf' => [], 'cp' => []];
    $a['sc'] += ['plus' => false];
    // bundles bought before they were worn on delivery: put the look on once, in any empty slot
    if ($old) { foreach (array_keys($a['once']) as $oid) eco_wear($a, eco_product($oid)['items'] ?? [], false); $a['beq'] = 1; }
    return $a;
}
// wear the items from a bundle. $force swaps out whatever is worn now; otherwise only empty slots are filled.
function eco_wear(&$a, $items, $force) {
    foreach ($items as $id) {
        $it = eco_item($id);
        if (!$it || !isset($a['items'][$id]) || ($it['slot'] ?? '') === 'emote') continue;
        if ($force || empty($a['eq'][$it['slot']])) $a['eq'][$it['slot']] = $id;
    }
}
function eco_credit(&$a, $n, $why, $src = '') {
    $a['koban'] = max(0, (int)$a['koban'] + (int)$n);
    //MC 2026-10-13 the faucet report in admin: every Koban is counted into earned (kin), bought (kbuy) or spent (kout)
    //   on the account as it moves, so the report is one sum over accounts. Counters start today; older flows aren't in them.
    if ($n > 0) { $k = $src === 'buy' ? 'kbuy' : 'kin'; $a[$k] = (int)($a[$k] ?? 0) + (int)$n; }
    elseif ($n < 0) $a['kout'] = (int)($a['kout'] ?? 0) - (int)$n;
    array_unshift($a['ledger'], ['t' => time(), 'n' => (int)$n, 'w' => $why]);
    $a['ledger'] = array_slice($a['ledger'], 0, 60);
}
function eco_grant_item(&$a, $id) { $it = eco_item($id); if ($it && empty($it['dev']) && !isset($a['items'][$id])) $a['items'][$id] = time(); }   //MC 2026-10-12 Dev items are never granted this way
//MC 2026-10-12 the Dev collection belongs to the profiles in eco setting dev_pids (Shilltoshi by default)
const DEV_PIDS_DEF = ['601dd0c5cd618874'];
function eco_dev($pid) { return $pid !== '' && in_array($pid, (array)(eco_settings()['dev_pids'] ?? DEV_PIDS_DEF), true); }
function eco_dev_grant(&$a, $pid) {
    if (!eco_dev($pid)) return;
    foreach (eco_catalog()['items'] as $it) if (!empty($it['dev']) && !isset($a['items'][$it['id']])) $a['items'][$it['id']] = time();
}

// everything a player can equip right now: bought, earned, or perks of holding
function eco_owned($a, $holderTier) {
    $own = $a['items'];
    if ($holderTier) { $own['title_holder'] = 1; $own['ring_holder'] = 1; $own['back_holder'] = 1; $own['share_holder'] = 1; $own['banner_holder'] = 1; }
    return $own;
}
// What other players see of you (titles, rings, frames). Only items you still own.
// $full adds what only matters at a live table: card finishes, mastery crests and the card back.
function eco_public($a, $holderTier, $full = false) {
    $own = eco_owned($a, $holderTier);
    $out = [];
    //MC 2026-10-10 a live table also sees your victory effect, Region claim effect and turn aura
    //MC 2026-10-14 and your command pieces on the 3D table
    foreach ($full ? ['title', 'ring', 'frame', 'back', 'skin', 'halo', 'fx', 'cap', 'turn', 'piece'] : ['title', 'ring', 'frame', 'skin', 'halo'] as $slot) {
        $id = $a['eq'][$slot] ?? '';
        if ($id && isset($own[$id]) && ($it = eco_item($id))) $out[$slot] = $slot === 'title' ? $it['name'] : substr($id, strlen($slot) + 1);
    }
    //MC 2026-10-10 the Profile Studio portrait frame also shows on the leaderboards and in Friends (still there, it plays on hover)
    $pf = $a['eq']['pframe'] ?? '';
    if ($pf && isset($own[$pf]) && eco_item($pf)) $out['pfr'] = substr($pf, 7);
    // a $SHY holder's tier shows next to their name everywhere (Shadow holders already show as Holder)
    if (holder_is_shy($holderTier)) $out['tier'] = $holderTier;
    if ($full) {
        $vf = [];
        foreach ($a['veq'] ?? [] as $c => $f) if (!empty($a['vf'][$c][$f])) $vf[$c] = $f;
        if ($vf) $out['vf'] = $vf;
        $ml = [];
        foreach ($a['cm'] ?? [] as $c => $n) { $l = mastery_level($n); if ($l >= 3) $ml[$c] = $l; }
        if ($ml) $out['ml'] = $ml;
    }
    return $out;
}
// the Profile Studio slots, and what a player's public page wears (only items they still own)
//MC 2026-10-10 added pframe (a portrait frame around your picture) and seal (a hanko stamped on its corner)
const PAGE_SLOTS = ['banner', 'plate', 'pfx', 'accent', 'pframe', 'seal'];
const PAGE_SHOW_MAX = 3;
function page_public($a, $holderTier) {
    $own = eco_owned($a, $holderTier); $out = [];
    foreach (PAGE_SLOTS as $slot) { $id = $a['eq'][$slot] ?? ''; if ($id && isset($own[$id])) $out[$slot] = substr($id, strlen($slot) + 1); }
    $pg = $a['pg'] ?? [];
    if (isset($own['unlock_motto']) && !empty($pg['motto'])) $out['motto'] = $pg['motto'];
    //MC 2026-10-09 the two newer unlocks: on once bought. player.php fills in the visit count.
    if (isset($own['unlock_portrait'])) $out['portrait'] = 1;
    if (isset($own['unlock_visits'])) $out['visits'] = 0;
    if (isset($own['unlock_showcase']) && !empty($pg['show'])) {
        $deck = deck_cards(); $show = [];
        foreach ($pg['show'] as [$c, $f]) {
            if (!isset($deck[$c])) continue;
            if ($f !== '' && empty($a['vf'][$c][$f])) $f = '';    // a finish no longer owned shows the plain card
            $show[] = ['id' => $c, 'name' => $deck[$c]['name'], 'kind' => $deck[$c]['kind'], 'fin' => $f, 'plays' => (int)($a['cm'][$c] ?? 0)];
        }
        if ($show) $out['show'] = $show;
    }
    return $out;
}
// a motto passes when it's short, plain and clean: no links, handles or words the name filter blocks
//MC 2026-10-11 also checks a House's About text ($max 140, $what 'House description'), which took anything before
function motto_problem($m, $max = 60, $what = 'motto') {
    if ($m === '') return '';
    if (mb_strlen($m) > $max) return 'Keep your ' . $what . ' to ' . $max . ' characters.';
    if (!preg_match('/^[\p{L}\p{N}\p{P}\p{Zs}\p{So}\p{Sk}]+$/u', $m)) return 'Use letters, numbers, punctuation and emoji only.';
    if (preg_match('~https?:|www\.|\.(com|io|net|org|xyz|gg|me|co)\b|t\.me/|@\w~i', $m)) return 'Links and handles can\'t go in a ' . $what . '.';
    if (name_blocked($m)) return 'That ' . $what . ' isn\'t allowed. Try other words.';
    return '';
}
function eco_reacts($a, $holderTier) {
    $r = [0, 1, 2, 3, 4, 5];
    foreach (eco_owned($a, $holderTier) as $id => $_) { $it = eco_item($id); if ($it && !empty($it['reacts'])) $r = array_merge($r, $it['reacts']); }
    return $r;
}

// ---------------------------------------------------------------- holder tiers
//MC 2026-10-10 tiers now go by how many $SHY a wallet holds, not their dollar value: seven steps from 25k to 5M+, in three
//   circles. A dollar ladder moved every time the price did (a holder could drop a tier overnight without selling a
//   coin), and the four old steps topped out where only a handful of wallets ever reached. The old USD keys ('tiers',
//   'stipend') stay in saved settings but nothing reads them any more.
//MC 2026-10-10 replaced the seven Bronze to Kami tiers with the nine $SHY Army Ranks from the community poster, Shy
//   Sapling to Shytoshi Supreme, in three circles. 'shadow' still means a wallet with a Shytoshi Shadow and no rank.
const HOLDER_LADDER = ['sapling', 'cadet', 'scout', 'knight', 'champion', 'commander', 'sovereign', 'king', 'supreme'];
const HOLDER_NAMES = ['shadow' => 'Shadow', 'sapling' => 'Shy Sapling', 'cadet' => 'Kusama Cadet', 'scout' => 'Shy Scout', 'knight' => 'Kusama Knight',
    'champion' => 'Shy Champion', 'commander' => 'Kusama Commander', 'sovereign' => 'Shy Sovereign', 'king' => 'Kusama King / Queen', 'supreme' => 'Shytoshi Supreme'];
const HOLDER_CIRCLE = ['shadow' => 'Shadow holders', 'sapling' => 'Recruits', 'cadet' => 'Recruits', 'scout' => 'Recruits', 'knight' => 'Officers', 'champion' => 'Officers',
    'commander' => 'Officers', 'sovereign' => 'High Command', 'king' => 'High Command', 'supreme' => 'High Command'];
const HOLDER_TIERS_DEF = ['sapling' => 1, 'cadet' => 5000, 'scout' => 20000, 'knight' => 50000, 'champion' => 100000, 'commander' => 250000, 'sovereign' => 500000, 'king' => 1500000, 'supreme' => 5000000];
const HOLDER_STIP_DEF = ['shadow' => 300, 'sapling' => 50, 'cadet' => 100, 'scout' => 150, 'knight' => 300, 'champion' => 500, 'commander' => 900, 'sovereign' => 1400, 'king' => 2200, 'supreme' => 4000];
// what each rank gets: % off every Koban price, daily gift multiplier, extra % Koban on packs paid in $SHY (on top of
// SHY_BONUS), and what comes free with the weekly stipend: the Bounty Board that week, the Season Scroll, Scroll+
const HOLDER_PERKS = [
    'shadow'    => ['disc' => 0,  'gift' => 2, 'shyb' => 0,  'free' => []],
    'sapling'   => ['disc' => 0,  'gift' => 2, 'shyb' => 0,  'free' => []],
    'cadet'     => ['disc' => 3,  'gift' => 2, 'shyb' => 3,  'free' => []],
    'scout'     => ['disc' => 5,  'gift' => 2, 'shyb' => 5,  'free' => []],
    'knight'    => ['disc' => 8,  'gift' => 2, 'shyb' => 10, 'free' => []],
    'champion'  => ['disc' => 10, 'gift' => 2, 'shyb' => 15, 'free' => []],
    'commander' => ['disc' => 12, 'gift' => 3, 'shyb' => 20, 'free' => ['bounty']],
    'sovereign' => ['disc' => 15, 'gift' => 3, 'shyb' => 25, 'free' => ['bounty']],
    'king'      => ['disc' => 18, 'gift' => 4, 'shyb' => 30, 'free' => ['bounty', 'scroll']],
    'supreme'   => ['disc' => 22, 'gift' => 5, 'shyb' => 40, 'free' => ['bounty', 'scroll', 'plus']],
];
//MC 2026-10-10 old tier keys to their nearest rank by $SHY held. Used on anything saved before the switch (tournament
//   gates, frozen weekly results). Bronze was 25k (Scout is 20k), Silver 50k, Gold 100k, Jade 250k and Daimyo 500k match
//   a rank exactly; Shogun was 1M and goes to King / Queen as asked, Kami stays the 5M top.
const HOLDER_OLD_KEYS = ['bronze' => 'scout', 'silver' => 'knight', 'gold' => 'champion', 'jade' => 'commander', 'daimyo' => 'sovereign', 'shogun' => 'king', 'kami' => 'supreme'];
function holder_key_new($k) { return HOLDER_OLD_KEYS[$k] ?? $k; }
//MC 2026-10-10 saved settings from before the ranks still hold bronze..kami. If the saved steps aren't exactly the nine
//   ranks, they go back to the defaults (old numbers don't fit the new ladder). Stipends the same, except the Shadow
//   stipend, which kept its meaning and keeps what the admin set. Runs on every read and on the admin save, so it's
//   safe whether or not the settings file has been rewritten yet.
function holder_settings_fix(&$s) {
    $ht = is_array($s['htiers'] ?? null) ? $s['htiers'] : [];
    $ok = array_keys($ht) === HOLDER_LADDER;
    if ($ok) { $prev = 0; foreach (HOLDER_LADDER as $k) { $v = (float)$ht[$k]; if ($v <= $prev) { $ok = false; break; } $prev = $v; } }
    if (!$ok) $s['htiers'] = HOLDER_TIERS_DEF;
    $st = is_array($s['hstip'] ?? null) ? $s['hstip'] : [];
    $old = array_intersect_key($st, HOLDER_OLD_KEYS);
    if ($old || array_diff_key(HOLDER_STIP_DEF, $st)) {
        $shadow = isset($st['shadow']) ? (int)$st['shadow'] : HOLDER_STIP_DEF['shadow'];
        $s['hstip'] = ['shadow' => $shadow] + HOLDER_STIP_DEF;
    }
}
function holder_is_shy($tier) { return in_array($tier, HOLDER_LADDER, true); }
function holder_perks($tier) {
    if (!isset(HOLDER_PERKS[$tier])) return ['disc' => 0, 'gift' => 1, 'shyb' => 0, 'free' => [], 'stip' => 0];
    return HOLDER_PERKS[$tier] + ['stip' => (int)(eco_settings()['hstip'][$tier] ?? 0)];
}
//MC 2026-10-10 the weekly Koban for a wallet. With Sapling starting at 1 $SHY, a Shadow holder with a few $SHY would
//   drop from the Shadow stipend to the Sapling one, so a wallet holding a Shadow never gets less than the Shadow stipend.
function holder_stip($tier, $h) {
    $k = holder_perks($tier)['stip'];
    if ($tier !== '' && !empty($h['shadows'])) $k = max($k, (int)(eco_settings()['hstip']['shadow'] ?? 0));
    //MC 2026-10-15 plus the time-held bonus (loyaltylib.php): up to +50% after 180 days at a rank
    if (holder_is_shy($tier) && ($l = loyalty_of($h, $tier))) $k += $l['bonus'];
    return $k;
}
// position on the ladder: 0 none, 1 Shadow or Sapling, up to 9 for Supreme (tournament gates use it)
function holder_rank($tier) { if ($tier === 'shadow') return 1; $i = array_search(holder_key_new($tier), HOLDER_LADDER, true); return $i === false ? 0 : $i + 1; }
function holder_tier($h) {
    if (!$h || empty($h['wallet'])) return '';
    $bal = (float)($h['shy_bal'] ?? 0);
    $t = eco_settings()['htiers'];
    $tier = '';
    foreach (HOLDER_LADDER as $k) if ($bal >= (float)($t[$k] ?? PHP_INT_MAX)) $tier = $k;
    if (!$tier && !empty($h['shadows'])) $tier = 'shadow';
    return $tier;
}
// the next step up for a wallet, for "hold N more to reach X"
function holder_next($h) {
    $bal = (float)($h['shy_bal'] ?? 0); $t = eco_settings()['htiers'];
    foreach (HOLDER_LADDER as $k) if ($bal < (float)$t[$k]) return ['tier' => $k, 'at' => (float)$t[$k], 'need' => (float)$t[$k] - $bal];
    return null;
}
//MC 2026-10-11 the stipend and the free perks now belong to the wallet, not just the profile. One wallet could be linked
//   to profile A, collect, unlink, link to B and collect again, as often as it liked (the audit got 12,000 Koban out of one
//   wallet with two spare profiles). wallet-claims.php keeps, per wallet, the week its stipend was last collected and the
//   week or season each free perk was last handed out, plus the week each Shadow last paid a Shadow stipend, so passing
//   one Shadow between wallets doesn't pay twice either. Moving a wallet to a new profile still collects once a week.
define('WCLAIMS', DATA_DIR . '/wallet-claims.php');
// the period a free perk is good for: the Bounty Board is weekly, the Scroll and Scroll+ last a season
function free_perk_period($f) { return $f === 'bounty' ? week_key() : 's' . season_no(); }
// has this wallet (or, for a Shadow-only holder, any of its Shadows) collected this week's stipend? Call inside with_lock.
function wallet_stip_taken($h, $tier, $wc = null) {
    if (empty($h['wallet'])) return false;
    $wc = $wc ?? load(WCLAIMS); $wk = week_key();
    if (($wc[$h['wallet']]['stip'] ?? '') === $wk) return true;
    if ($tier === 'shadow') foreach ($h['shadows'] ?? [] as $n) if (($wc['sh:' . $n]['stip'] ?? '') === $wk) return true;
    return false;
}
// write down that this wallet collected this week (and which free perks went out with it). Call inside with_lock.
function wallet_stip_mark($h, $tier, $perks) {
    if (empty($h['wallet'])) return;
    $wc = load(WCLAIMS); $wk = week_key(); $w = $h['wallet'];
    $wc[$w] = ['stip' => $wk, 'fp' => ($wc[$w]['fp'] ?? []), 't' => time()];
    foreach ($perks as $f) $wc[$w]['fp'][$f] = free_perk_period($f);
    if ($tier === 'shadow') foreach ($h['shadows'] ?? [] as $n) $wc['sh:' . $n] = ['stip' => $wk, 't' => time()];
    // nothing older than ~20 weeks matters again (seasons are 4 weeks), so the file stays small
    if (random_int(1, 50) === 1) foreach ($wc as $k => $r) if (($r['t'] ?? 0) < time() - 140 * 86400) unset($wc[$k]);
    save(WCLAIMS, $wc);
}
// the free perks of the top tiers, given out with the weekly stipend. Returns what was granted.
//MC 2026-10-11 $h is the holder record: a free perk this wallet already handed to another profile this week or season is
//   skipped. $given collects the perk keys actually granted, for wallet_stip_mark().
function holder_free_perks(&$a, $tier, $h = null, &$given = null) {
    $got = []; $given = [];
    $used = [];
    if ($h && !empty($h['wallet'])) foreach ((load(WCLAIMS)[$h['wallet']]['fp'] ?? []) as $f => $per) if ($per === free_perk_period($f)) $used[$f] = 1;
    foreach (holder_perks($tier)['free'] as $f) {
        if (isset($used[$f])) continue;
        if ($f === 'bounty') { missions_week_init($a); if (empty($a['ms']['b'])) { $a['ms']['b'] = 1; bounties_settle($a); $got[] = 'Bounty Board'; $given[] = 'bounty'; } }
        if ($f === 'scroll' && empty($a['sc']['prem'])) { $a['sc']['prem'] = true; $a['sc']['hp'] = 1; $got[] = 'Season ' . season_no() . ' Scroll'; $given[] = 'scroll'; }
        if ($f === 'plus' && empty($a['sc']['plus'])) {
            $given[] = 'plus';
            $a['sc']['prem'] = true; $a['sc']['plus'] = true; $a['sc']['hp'] = 1;
            $a['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, $a['sc']['xp'] + 15 * TIER_XP);
            $got[] = 'Scroll+ and 15 tiers';
        }
    }
    return $got;
}
// $SHY held by a wallet (raw amount and USD) or null when Solana can't be reached
function shy_balance($wallet) {
    $r = rpc('getTokenAccountsByOwner', [$wallet, ['mint' => SHY_MINT], ['encoding' => 'jsonParsed']]);
    if (!is_array($r) || !isset($r['value'])) return null;
    $amt = 0.0;
    foreach ($r['value'] as $acc) $amt += (float)($acc['account']['data']['parsed']['info']['tokenAmount']['uiAmountString'] ?? 0);
    $px = price_usd(SHY_MINT);
    return ['bal' => $amt, 'usd' => $px ? $amt * $px : 0];
}

// ---------------------------------------------------------------- games
// Called inside with_lock after a verified game is saved. mode: solo|daily|live. Returns what the player earned.
function eco_award_game($pid, $mode, $result, $leaguePts = 0, $info = []) {
    $eco = load(ECO);
    $a = eco_get($eco, $pid);
    $out = ['xp' => 0, 'koban' => 0, 'streak' => $a['st']['n'], 'tierUp' => 0];
    $day = today();
    // XP: verified play only; solo XP is capped per day so nobody grinds the Scroll against bots
    $xp = $mode === 'live' ? 50 + ($result === 'win' ? 30 : 0) : ($mode === 'daily' ? 40 + ($result === 'win' ? 20 : 0) : 10 + ($result === 'win' ? 10 : 0));
    if ($mode === 'solo') {
        if ($a['xd']['d'] !== $day) $a['xd'] = ['d' => $day, 'solo' => 0];
        $xp = max(0, min($xp, 150 - $a['xd']['solo']));
        $a['xd']['solo'] += $xp;
    }
    // daily streak: the first finished game of each day pays Koban; miss a day and it starts over,
    // unless the player holds Streak Savers: one covers each missed day
    if ($a['st']['d'] !== $day) {
        $yest = gmdate('Y-m-d', time() - 86400);
        $n = 1;
        if ($a['st']['d'] === $yest) $n = $a['st']['n'] + 1;
        elseif ($a['st']['d'] !== '' && $a['st']['n'] > 0) {
            $missed = (int)round((strtotime($day . ' 00:00:00 UTC') - strtotime($a['st']['d'] . ' 00:00:00 UTC')) / 86400) - 1;
            if ($missed >= 1 && $missed <= (int)($a['saver'] ?? 0)) {
                $a['saver'] -= $missed;
                $n = $a['st']['n'] + 1;
                eco_credit($a, 0, $missed === 1 ? 'Streak Saver used' : "$missed Streak Savers used");
                $out['saverUsed'] = $missed;
            }
        }
        $pay = [10, 15, 20, 25, 30, 40, 60][($n - 1) % 7];
        $a['st'] = ['d' => $day, 'n' => $n, 'best' => max($a['st']['best'] ?? 0, $n)];
        eco_credit($a, $pay, "Day $n streak");
        $out['koban'] = $pay; $out['streak'] = $n; $out['streakPay'] = $pay;
        $xp += 20;   // first game of the day bonus
    }
    // card mastery: the cards this player chose to play themselves
    $out['mastery'] = [];
    // solo games count toward mastery up to 60 plays a day, so nobody farms it against bots
    $soloLeft = PHP_INT_MAX;
    if ($mode === 'solo') { if (($a['xd']['d'] ?? '') !== $day) $a['xd'] = ['d' => $day, 'solo' => 0]; $soloLeft = max(0, 60 - (int)($a['xd']['mp'] ?? 0)); }
    foreach ($info['cards'] ?? [] as $c) {
        if (!is_string($c) || !deck_card($c)) continue;
        if ($soloLeft-- <= 0) break;
        if ($mode === 'solo') $a['xd']['mp'] = (int)($a['xd']['mp'] ?? 0) + 1;
        $was = (int)($a['cm'][$c] ?? 0);
        $a['cm'][$c] = $was + 1;
        if (mastery_level($was + 1) > mastery_level($was)) $out['mastery'][] = ['card' => $c, 'level' => mastery_level($was + 1)];
    }
    $out['missions'] = missions_progress($a, $mode, $result, $info);
    foreach ($out['missions'] as $m) if (!empty($m['new'])) $out['koban'] += $m['koban'];
    // an XP Boost adds half again
    if ((int)($a['boost']['xp'] ?? 0) > time()) { $xp = (int)round($xp * (100 + XP_BOOST) / 100); $out['boosted'] = true; }
    $before = intdiv($a['sc']['xp'], TIER_XP);
    $a['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, $a['sc']['xp'] + $xp);
    $out['xp'] = $xp;
    $out['tierUp'] = intdiv($a['sc']['xp'], TIER_XP) - $before;
    $out['tier'] = intdiv($a['sc']['xp'], TIER_XP);
    if ($rr = rank_rewards($a, load(PLAYERS)[$pid] ?? [])) $out['rankRewards'] = $rr;
    funnel_mark($pid, 'f');
    $eco[$pid] = $a;
    if ($r = ref_progress($eco, $pid)) $out['ref'] = $r;
    save(ECO, $eco);
    return $out;
}

// ---------------------------------------------------------------- ranked live seasons
// Matches with two or more real players move Rank Points (RP). Each Season Scroll season is a ranked season:
// RP start again at 0, and the tier a player finished on pays out the next time they play.
const RANK_TIERS = ['bronze' => 0, 'silver' => 150, 'gold' => 400, 'jade' => 800, 'shogun' => 1300];
const RANK_NAMES = ['bronze' => 'Bronze', 'silver' => 'Silver', 'gold' => 'Gold', 'jade' => 'Jade', 'shogun' => 'Shogun'];
const RANK_REWARD = ['bronze' => ['koban' => 50], 'silver' => ['koban' => 150], 'gold' => ['koban' => 400], 'jade' => ['koban' => 800, 'item' => 'title_rk_jade'], 'shogun' => ['koban' => 1500, 'item' => 'title_rk_shogun']];
function rank_tier($rp) { $t = 'bronze'; foreach (RANK_TIERS as $k => $min) if ($rp >= $min) $t = $k; return $t; }
function rank_next($rp) { foreach (RANK_TIERS as $k => $min) if ($rp < $min) return ['tier' => $k, 'at' => $min]; return null; }
// a player's ranked record for this season (moving last season's to the history first)
function rank_now(&$p) {
    $s = season_no();
    if (isset($p['rk']) && ($p['rk']['s'] ?? 0) !== $s) {
        if (!empty($p['rk']['n'])) $p['rkh']['s' . (int)$p['rk']['s']] = ['rp' => $p['rk']['rp'], 'tier' => rank_tier($p['rk']['rp']), 'n' => $p['rk']['n'], 'peak' => $p['rk']['peak'] ?? $p['rk']['rp']];
        unset($p['rk']);
    }
    if (!isset($p['rk'])) $p['rk'] = ['s' => $s, 'rp' => 0, 'n' => 0, 'w' => 0, 'peak' => 0];
    return $p['rk'];
}
// after a live match with real rivals: place is 1 for the most Regions; humans counts the real players at the table
function rank_apply(&$p, $place, $result, $humans) {
    if ($humans < 2) return null;
    rank_now($p);
    $before = $p['rk']['rp'];
    $d = $result === 'win' ? 30 + 5 * max(0, $humans - 2) : ($result === 'tie' ? 15 : ([2 => 5, 3 => -8][$place] ?? -15));
    $p['rk']['rp'] = max(0, $before + $d);
    $p['rk']['n']++; if ($result === 'win') $p['rk']['w']++;
    $p['rk']['peak'] = max($p['rk']['peak'] ?? 0, $p['rk']['rp']);
    $t0 = rank_tier($before); $t1 = rank_tier($p['rk']['rp']);
    return ['d' => $p['rk']['rp'] - $before, 'rp' => $p['rk']['rp'], 'tier' => $t1, 'name' => RANK_NAMES[$t1], 'up' => RANK_TIERS[$t1] > RANK_TIERS[$t0], 'down' => RANK_TIERS[$t1] < RANK_TIERS[$t0], 'next' => rank_next($p['rk']['rp'])];
}
// the rank to show for a player this season ('' before their first ranked match)
function rank_show($p) {
    if (empty($p['rk']['n']) || ($p['rk']['s'] ?? 0) !== season_no()) return null;
    $t = rank_tier($p['rk']['rp']);
    return ['tier' => $t, 'name' => RANK_NAMES[$t], 'rp' => (int)$p['rk']['rp'], 'n' => (int)$p['rk']['n'], 'w' => (int)($p['rk']['w'] ?? 0), 'next' => rank_next($p['rk']['rp'])];
}
// pay the end-of-season rank rewards a player hasn't had yet (inside eco_award_game, with the account in hand)
function rank_rewards(&$a, $p) {
    $got = [];
    foreach ($p['rkh'] ?? [] as $sk => $h) {
        $s = (int)ltrim((string)$sk, 's');   // stored as "s3", so the history is always a map
        if (isset($a['rkp']['s' . $s])) continue;
        $a['rkp']['s' . $s] = time();
        $rw = RANK_REWARD[$h['tier']] ?? null; if (!$rw) continue;
        eco_credit($a, $rw['koban'], 'Season ' . $s . ' ranked reward: ' . RANK_NAMES[$h['tier']]);
        if (!empty($rw['item'])) eco_grant_item($a, $rw['item']);
        $got[] = ['s' => (int)$s, 'tier' => $h['tier'], 'name' => RANK_NAMES[$h['tier']], 'koban' => $rw['koban'], 'item' => $rw['item'] ?? ''];
    }
    return $got;
}

// ---------------------------------------------------------------- the player funnel (admin)
// funnel.php: 'p' => pid => ['v' => first visit day, 'src' => where they came from, 's' => first game started,
//   'f' => first game finished, 'r' => came back and played on a later day, 'w' => connected a wallet, 'b' => first purchase]
define('FUNNEL', DATA_DIR . '/funnel.php');
// record the first time a step happens for a player (locked). Steps after a visit only count for players whose visit was seen.
function funnel_mark($pid, $step, $src = '') {
    if (!preg_match('/^[a-f0-9]{16}$/', (string)$pid)) return;
    $f = load(FUNNEL);
    $e = $f['p'][$pid] ?? null;
    if ($step === 'v') { if ($e) return; $f['p'][$pid] = ['v' => today(), 'src' => $src ?: 'direct']; }
    else {
        if (!$e) return;
        if ($step === 'f' && !empty($e['f'])) { if (empty($e['r']) && today() > $e['f']) $f['p'][$pid]['r'] = today(); else return; }
        elseif (!empty($e[$step])) return;
        else $f['p'][$pid][$step] = today();
    }
    // keep about three months
    if (random_int(1, 200) === 1) { $cut = gmdate('Y-m-d', time() - 92 * 86400); foreach ($f['p'] as $k => $x) if (($x['v'] ?? '') < $cut) unset($f['p'][$k]); }
    save(FUNNEL, $f);
}

// ---------------------------------------------------------------- invites
// refs.php: invited pid => ['by' => inviter pid, 't' => when, 'g' => verified games since, 'paid' => 1 once rewarded, 'hb' => 1 once the holder bonus is paid]
//           '_wk' => inviter pid => week => rewarded invites that week
define('REFS', DATA_DIR . '/refs.php');
// a new player arrived with someone's invite link (locked). '' when recorded, else why not.
function ref_record($pid, $by) {
    $set = eco_settings();
    if (empty($set['ref_on'])) return 'off';
    if ($pid === $by) return 'self';
    $players = load(PLAYERS);
    if (!empty($players[$pid]['games'])) return 'not new';
    if (empty($players[$by]['games'])) return 'inviter has not played';
    $refs = load(REFS);
    if (isset($refs[$pid])) return 'already';
    // the inviter can't be someone this player invited (no swapping invites back and forth)
    if (($refs[$by]['by'] ?? '') === $pid) return 'loop';
    $refs[$pid] = ['by' => $by, 't' => time(), 'g' => 0, 'ip' => substr(hash('sha256', client_ip() . 'ref'), 0, 12)];
    save(REFS, $refs);
    return '';
}
// after each verified game of an invited player: pay the invite once they've played enough, and the holder bonus once they hold $SHY
function ref_progress(&$eco, $pid) {
    $refs = load(REFS);
    if (!isset($refs[$pid])) return null;
    $set = eco_settings();
    $r = &$refs[$pid]; $by = $r['by']; $got = null;
    $r['g'] = (int)($r['g'] ?? 0) + 1;
    $wk = week_key();
    $done = (int)($refs['_wk'][$by][$wk] ?? 0);
    $name = load(PLAYERS)[$pid]['name'] ?? 'Your friend';
    if (empty($r['paid']) && $r['g'] >= (int)$set['ref_games'] && !empty($set['ref_on'])) {
        $r['paid'] = time();
        // the new player's welcome is always paid; the inviter's share stops at the weekly cap
        $me = eco_get($eco, $pid); eco_credit($me, (int)$set['ref_new'], 'Welcome gift: joined with an invite'); $eco[$pid] = $me;
        if ($done < (int)$set['ref_cap'] && isset(load(PLAYERS)[$by])) {
            $inv = eco_get($eco, $by); eco_credit($inv, (int)$set['ref_koban'], 'Invite reward: ' . $name . ' played ' . (int)$set['ref_games'] . ' games'); $eco[$by] = $inv;
            $refs['_wk'][$by][$wk] = $done + 1;
            ref_tell($by, $pid, (int)$set['ref_koban'], 'games');
        }
        $got = ['welcome' => (int)$set['ref_new']];
    }
    if (!empty($r['paid']) && empty($r['hb']) && !empty($set['ref_on']) && tier_of_pid($pid) !== '') {
        $r['hb'] = time();
        if (isset(load(PLAYERS)[$by])) { $inv = eco_get($eco, $by); eco_credit($inv, (int)$set['ref_holder'], 'Invite bonus: ' . $name . ' holds $SHY'); $eco[$by] = $inv; ref_tell($by, $pid, (int)$set['ref_holder'], 'holder'); }
    }
    unset($r);
    foreach ($refs['_wk'] ?? [] as $p => $w) { foreach ($w as $k => $_) if ($k < gmdate('o-W', time() - 21 * 86400)) unset($refs['_wk'][$p][$k]); if (empty($refs['_wk'][$p])) unset($refs['_wk'][$p]); }
    save(REFS, $refs);
    return $got;
}
function tier_of_pid($pid) { return holder_tier(load(HOLDERS)[$pid] ?? null); }
// tell the inviter (a notice in Friends, Telegram and a browser notification if they turned them on)
function ref_tell($by, $pid, $koban, $why) {
    if (!function_exists('fr_notify')) { if (!is_file(__DIR__ . '/friendslib.php')) return; require_once __DIR__ . '/friendslib.php'; }
    $name = load(PLAYERS)[$pid]['name'] ?? 'Your friend';
    $line = $why === 'holder' ? $name . ' now holds $SHY: +' . number_format($koban) . ' Koban for you.' : $name . ' joined with your invite and played their first games: +' . number_format($koban) . ' Koban for you.';
    fr_notify($by, 'ref', $pid, ['k' => $koban, 'why' => $why], function_exists('tg_h') ? ['🎁 ' . tg_h($line)] : null, ['url' => '/play?friends=1']);
}
// an inviter's invite summary for the Friends panel
function ref_summary($by) {
    $set = eco_settings(); $refs = load(REFS); $n = 0; $wait = 0;
    foreach ($refs as $p => $r) if ($p !== '_wk' && ($r['by'] ?? '') === $by) { if (!empty($r['paid'])) $n++; else $wait++; }
    return ['on' => !empty($set['ref_on']), 'k' => (int)$set['ref_koban'], 'new' => (int)$set['ref_new'], 'hold' => (int)$set['ref_holder'], 'games' => (int)$set['ref_games'],
        'cap' => (int)$set['ref_cap'], 'n' => $n, 'wait' => $wait, 'week' => (int)($refs['_wk'][$by][week_key()] ?? 0)];
}

// ---------------------------------------------------------------- weekly missions
// Three a week, the same for everyone: one for live matches, one for the Daily, one for any game.
// They reset Monday 00:00 UTC and pay Koban the moment they're done.
const MISSIONS = [
    'lw2'  => ['g' => 'live',  'text' => 'Win 2 live matches', 'goal' => 2, 'koban' => 200],
    'lp5'  => ['g' => 'live',  'text' => 'Finish 5 live matches', 'goal' => 5, 'koban' => 150],
    'lr30' => ['g' => 'live',  'text' => 'Hold 30 Regions across live matches', 'goal' => 30, 'koban' => 150],
    'dp3'  => ['g' => 'daily', 'text' => 'Play the Daily Challenge on 3 days', 'goal' => 3, 'koban' => 150],
    'dw1'  => ['g' => 'daily', 'text' => 'Win a Daily Challenge', 'goal' => 1, 'koban' => 120],
    'dr8'  => ['g' => 'daily', 'text' => 'Hold 8 or more Regions in a Daily Challenge', 'goal' => 1, 'koban' => 120],
    'aw5'  => ['g' => 'any',   'text' => 'Win 5 games of any kind', 'goal' => 5, 'koban' => 150],
    'ar12' => ['g' => 'any',   'text' => 'Finish a game holding 12 or more Regions', 'goal' => 1, 'koban' => 150],
    'ag10' => ['g' => 'any',   'text' => 'Finish 10 games', 'goal' => 10, 'koban' => 120],
    'as5'  => ['g' => 'any',   'text' => 'Play on 5 different days', 'goal' => 5, 'koban' => 200],
    'fd2'  => ['g' => 'any',   'text' => 'Win 2 Duels against friends', 'goal' => 2, 'koban' => 200, 'from' => '2026-42'],   // from: the week it joins the rotation
];
const BOUNTIES = [
    'bw3'  => ['text' => 'Win 3 live matches', 'goal' => 3],
    'b15'  => ['text' => 'Win a game holding 15 Regions', 'goal' => 1],
    'bd5'  => ['text' => 'Play the Daily Challenge on 5 days', 'goal' => 5],
    'bw8'  => ['text' => 'Win 8 games of any kind', 'goal' => 8],
    'br80' => ['text' => 'Hold 80 Regions across games', 'goal' => 80],
    'bl6'  => ['text' => 'Finish 6 live matches', 'goal' => 6],
];
const BOUNTY_KOBAN = 300;
function missions_week($wk = null) {
    $wk = $wk ?? week_key();
    $out = [];
    foreach (['live', 'daily', 'any'] as $i => $grp) {
        $ids = array_keys(array_filter(MISSIONS, fn($m) => $m['g'] === $grp && ($m['from'] ?? '') <= $wk));
        $out[] = $ids[(int)sprintf('%u', crc32('shy-missions-' . $wk . '-' . $i)) % count($ids)];
    }
    return $out;
}
function bounties_week($wk = null) {
    $wk = $wk ?? week_key();
    $ids = array_keys(BOUNTIES);
    $a = (int)sprintf('%u', crc32('shy-bounty-' . $wk)) % count($ids);
    return [$ids[$a], $ids[($a + 3) % count($ids)]];
}
function missions_public() {
    return array_map(fn($id) => ['id' => $id, 'text' => MISSIONS[$id]['text'], 'goal' => MISSIONS[$id]['goal'], 'koban' => MISSIONS[$id]['koban']], missions_week());
}
// a new week starts a clean sheet: this week's three missions (Scroll+ owners get the Bounty Board too)
function missions_week_init(&$a) {
    $wk = week_key();
    if (($a['ms']['wk'] ?? '') !== $wk) $a['ms'] = ['wk' => $wk, 'p' => [], 'done' => [], 'days' => []];
    $a['ms'] += ['ids' => missions_week($wk), 'b' => 0, 'rr' => 0, 'free' => 0];
    if (!empty($a['sc']['plus']) && ($a['sc']['s'] ?? 0) === season_no() && empty($a['ms']['b'])) { $a['ms']['b'] = 1; bounties_settle($a); }
}
function mission_def($id) {
    if (isset(MISSIONS[$id])) return MISSIONS[$id];
    if (isset(BOUNTIES[$id])) return BOUNTIES[$id] + ['g' => 'bounty', 'koban' => BOUNTY_KOBAN];
    return null;
}
// swap mission number $slot (0-2) for another one of the same kind that isn't on the sheet
function missions_reroll(&$a, $slot) {
    missions_week_init($a);
    $id = $a['ms']['ids'][$slot] ?? null;
    if ($id === null) return 'That mission is not on your sheet.';
    if (!empty($a['ms']['done'][$id])) return 'That one is done already. Reroll one that isn\'t.';
    $grp = MISSIONS[$id]['g'];
    $pool = array_values(array_filter(array_keys(MISSIONS), fn($x) => MISSIONS[$x]['g'] === $grp && (MISSIONS[$x]['from'] ?? '') <= week_key() && !in_array($x, $a['ms']['ids'], true) && empty($a['ms']['done'][$x])));
    if (!$pool) return 'There\'s no other mission of that kind this week.';
    $new = $pool[random_int(0, count($pool) - 1)];
    $a['ms']['ids'][$slot] = $new;
    $a['ms']['p'][$new] = 0;
    $a['ms']['rr']++;
    return '';
}
// count a finished game toward this week's missions. Returns each mission's state; 'new' = just completed (paid now).
function missions_progress(&$a, $mode, $result, $info) {
    missions_week_init($a);
    $day = today(); $regions = (int)($info['regions'] ?? 0); $win = $result === 'win';
    $newDay = !isset($a['ms']['days'][$day]);
    $a['ms']['days'][$day] = 1;
    $out = [];
    // bounties count all week, open or not, so opening the board late in the week isn't wasted; they pay only once it's open
    $sheet = array_merge($a['ms']['ids'], bounties_week());
    foreach ($sheet as $id) {
        $m = mission_def($id);
        $add = 0;
        switch ($id) {
            case 'lw2': $add = $mode === 'live' && $win ? 1 : 0; break;
            case 'lp5': $add = $mode === 'live' ? 1 : 0; break;
            case 'lr30': $add = $mode === 'live' ? $regions : 0; break;
            case 'dp3': $add = $mode === 'daily' ? 1 : 0; break;
            case 'dw1': $add = $mode === 'daily' && $win ? 1 : 0; break;
            case 'dr8': $add = $mode === 'daily' && $regions >= 8 ? 1 : 0; break;
            case 'aw5': $add = $win ? 1 : 0; break;
            case 'ar12': $add = $regions >= 12 ? 1 : 0; break;
            case 'ag10': $add = 1; break;
            case 'as5': $add = $newDay ? 1 : 0; break;
            case 'bw3': $add = $mode === 'live' && $win ? 1 : 0; break;
            case 'b15': $add = $win && $regions >= 15 ? 1 : 0; break;
            case 'bd5': $add = $mode === 'daily' && empty($a['ms']['dd'][$day]) ? 1 : 0; break;
            case 'bw8': $add = $win ? 1 : 0; break;
            case 'br80': $add = $regions; break;
            case 'bl6': $add = $mode === 'live' ? 1 : 0; break;
        }
        $was = (int)($a['ms']['p'][$id] ?? 0);
        $now = min($m['goal'], $was + $add);
        $a['ms']['p'][$id] = $now;
        $locked = $m['g'] === 'bounty' && empty($a['ms']['b']);
        $new = !$locked && mission_pay($a, $id);
        if ($locked) continue;   // counted quietly until the board is opened
        $out[] = ['id' => $id, 'text' => $m['text'], 'n' => $now, 'goal' => $m['goal'], 'koban' => $m['koban'], 'done' => !empty($a['ms']['done'][$id]), 'new' => $new, 'moved' => $now > $was, 'bounty' => $m['g'] === 'bounty'];
    }
    if ($mode === 'daily') $a['ms']['dd'][$day] = 1;
    return $out;
}
// pay a mission or bounty that has reached its goal (once)
function mission_pay(&$a, $id) {
    $m = mission_def($id);
    if (!$m || (int)($a['ms']['p'][$id] ?? 0) < $m['goal'] || !empty($a['ms']['done'][$id])) return false;
    $a['ms']['done'][$id] = time();
    eco_credit($a, $m['koban'], ($m['g'] === 'bounty' ? 'Bounty: ' : 'Mission: ') . $m['text']);
    if ($m['g'] === 'bounty') $a['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, $a['sc']['xp'] + TIER_XP);
    return true;
}
// the Bounty Board just opened: bounties already finished this week pay now
function bounties_settle(&$a) { foreach (bounties_week() as $id) mission_pay($a, $id); }
function missions_mine($a) {
    missions_week_init($a);
    $ms = $a['ms'];
    $sheet = $ms['ids'];
    $out = array_map(fn($id) => ['id' => $id, 'text' => MISSIONS[$id]['text'], 'goal' => MISSIONS[$id]['goal'], 'koban' => MISSIONS[$id]['koban'], 'n' => (int)($ms['p'][$id] ?? 0), 'done' => !empty($ms['done'][$id])], $sheet);
    foreach (bounties_week() as $id) $out[] = ['id' => $id, 'text' => BOUNTIES[$id]['text'], 'goal' => BOUNTIES[$id]['goal'], 'koban' => BOUNTY_KOBAN, 'n' => (int)($ms['p'][$id] ?? 0), 'done' => !empty($ms['done'][$id]), 'bounty' => true, 'locked' => empty($ms['b'])];
    return $out;
}

// A player record with no games yet: holds a name for a connected profile. Kept off the public boards until they play.
function blank_player($kh = '', $name = '') {
    return ['kh' => $kh, 'name' => $name, 'points' => 0, 'wins' => 0, 'games' => 0, 'best' => 0, 'since' => time()];
}

// The last 25 finished games on the player record, newest first, for the profile page.
function game_log(&$p, $mode, $result, $regions, $pts) {
    $h = $p['hist'] ?? [];
    array_unshift($h, ['t' => time(), 'm' => $mode, 'r' => $result, 'g' => (int)$regions, 'p' => (int)$pts]);
    $p['hist'] = array_slice($h, 0, 25);
}

// League points: Daily Challenge (first try) and live matches only. Updates the player record in place.
function league_add(&$p, $pts) {
    $pts = (int)round($pts * event_mult());
    $wk = week_key(); $s = season_no();
    if (($p['lg']['wk'] ?? '') !== $wk) $p['lg'] = ['wk' => $wk, 'pts' => 0, 'n' => 0];
    $p['lg']['pts'] += $pts; $p['lg']['n']++;
    if (($p['sg']['s'] ?? 0) !== $s) $p['sg'] = ['s' => $s, 'pts' => 0, 'n' => 0];
    $p['sg']['pts'] += $pts; $p['sg']['n']++;
    return $pts;
}

// ---------------------------------------------------------------- prices
function price_usd($mint) {
    if ($mint === USDC_MINT) return 1.0;
    $c = shy_config();
    if (isset($c['test_prices'][$mint])) return (float)$c['test_prices'][$mint];   // local testing only
    $cache = load(PRICES);
    if (isset($cache[$mint]) && time() - $cache[$mint]['ts'] < 60) return $cache[$mint]['usd'];
    $px = null;
    $j = http_json('https://lite-api.jup.ag/price/v3?ids=' . $mint);
    if (isset($j[$mint]['usdPrice']) && $j[$mint]['usdPrice'] > 0) $px = (float)$j[$mint]['usdPrice'];
    if (!$px) {
        $j = http_json('https://api.dexscreener.com/latest/dex/tokens/' . $mint);
        foreach (($j['pairs'] ?? []) as $pr) if (($pr['chainId'] ?? '') === 'solana' && ($pr['baseToken']['address'] ?? '') === $mint && !empty($pr['priceUsd'])) { $px = (float)$pr['priceUsd']; break; }
    }
    if ($px) { $cache[$mint] = ['usd' => $px, 'ts' => time()]; save(PRICES, $cache); return $px; }
    // a stale price is better than none for display, but never older than 15 minutes for a quote
    if (isset($cache[$mint]) && time() - $cache[$mint]['ts'] < 900) return $cache[$mint]['usd'];
    return null;
}
function http_json($url, $post = null, $headers = [], $timeout = 8) {
    $ch = curl_init($url);
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => array_merge(['Accept: application/json'], $headers)];
    if ($post !== null) { $opt[CURLOPT_POST] = true; $opt[CURLOPT_POSTFIELDS] = $post; }
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : null;
}
function rpc_url() {
    $c = shy_config();
    if (!empty($c['rpc_url'])) return $c['rpc_url'];
    return 'https://mainnet.helius-rpc.com/?api-key=' . rawurlencode($c['helius'] ?? '');
}
function rpc($method, $params) {
    if (function_exists('rpc_mock')) return rpc_mock($method, $params);   // tests only
    $j = http_json(rpc_url(), json_encode(['jsonrpc' => '2.0', 'id' => 1, 'method' => $method, 'params' => $params]), ['Content-Type: application/json'], 12);
    return $j['result'] ?? null;
}
function mint_decimals($mint) {
    if ($mint === SOL_MINT) return 9;
    if ($mint === USDC_MINT) return 6;
    $cache = load(PRICES);
    if (isset($cache['dec:' . $mint])) return $cache['dec:' . $mint];
    $r = rpc('getTokenSupply', [$mint]);
    if (!isset($r['value']['decimals'])) return null;
    $cache['dec:' . $mint] = (int)$r['value']['decimals'];
    save(PRICES, $cache);
    return (int)$r['value']['decimals'];
}

// ---------------------------------------------------------------- orders
const ORDER_TTL = 20 * 60;          // a quote holds its price this long
const ORDER_GRACE = 24 * 3600;      // a payment that lands late is still honoured within a day
//MC 2026-10-11 the quoted amount only holds for the 20 minutes the shop promises, plus this much for a slow wallet or a
//   busy network. A payment that lands later still delivers if it covers today's price; if it doesn't, it waits for the
//   team (pay-help) instead of delivering at a price that moved. Before, any quote could be paid at its old amount for a
//   whole day, so a buyer could hold quotes and pay only the ones the market had moved in their favour.
const ORDER_LATE_GRACE = 10 * 60;
// one order as the buyer sees it in their history
function order_row($o) {
    $amt = ($o['cur'] ?? '') === 'CARD' ? '' : rtrim(rtrim(number_format(($o['units'] ?? 0) / pow(10, $o['dec'] ?? 0), $o['dec'] ?? 0, '.', ''), '0'), '.');
    $st = $o['status'];
    if ($st !== 'paid') $st = !empty($o['issue']) ? $o['issue'] : (time() > $o['ts'] + ORDER_GRACE ? 'expired' : 'open');
    return ['id' => $o['id'], 'product' => $o['product'] ?? '', 'name' => $o['name'], 'usd' => $o['usd'], 'cur' => $o['cur'], 'amount' => $amt, 'status' => $st, 'ts' => $o['ts'],
        'paid' => $o['paid'] ?? 0, 'got' => $o['got'] ?? [], 'proof' => $o['proof'] ?? '', 'sig' => $o['sig'] ?? ''];
}
// Exact token units for a USD price, rounded UP so the wallet never receives less than the price.
function units_for_usd($usd, $mint) {
    $px = price_usd($mint);
    $dec = mint_decimals($mint);
    if (!$px || $dec === null) return null;
    $amount = $usd / $px;
    $units = (int)ceil($amount * pow(10, $dec));
    // trim to 4 significant decimals of the token so the number looks clean in the wallet
    $step = (int)pow(10, max(0, $dec - 4));
    if ($step > 1) $units = (int)(ceil($units / $step) * $step);
    return ['units' => $units, 'dec' => $dec, 'px' => $px];
}
function new_reference() {
    // 32 random bytes as a base58 public key, used only to find the payment on chain
    $alpha = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    $bytes = random_bytes(32);
    $num = array_values(unpack('C*', $bytes));
    $out = '';
    while ($num) {
        $rem = 0; $next = [];
        foreach ($num as $b) { $acc = $rem * 256 + $b; $q = intdiv($acc, 58); $rem = $acc % 58; if ($next || $q) $next[] = $q; }
        $out = $alpha[$rem] . $out; $num = $next;
    }
    for ($i = 0; $i < 32 && $bytes[$i] === "\0"; $i++) $out = '1' . $out;
    return $out;
}
//MC 2026-10-10 the burn: a share of every $SHY shop payment (burn_pct, 15% to start) is burned in the buyer's own payment
//   transaction, so the marketing wallet never holds it and anyone can see it on Solscan. The order keeps 'units' as the
//   whole price the buyer pays and 'burn' as the part of it that is burned; the marketing wallet must receive the rest.
function burn_units_for($units, $dec) {
    $pct = max(0, min(50, (int)eco_settings()['burn_pct']));
    if (!$pct) return 0;
    $step = (int)pow(10, max(0, $dec - 4));
    return (int)(floor($units * $pct / 100 / $step) * $step);
}
// $SHY burned by $owner in one parsed transaction (top-level and inner instructions)
function tx_burned($tx, $mint, $owner) {
    $n = 0;
    $all = $tx['transaction']['message']['instructions'] ?? [];
    foreach ($tx['meta']['innerInstructions'] ?? [] as $in) foreach ($in['instructions'] ?? [] as $ix) $all[] = $ix;
    foreach ($all as $ix) {
        $p = $ix['parsed'] ?? null;
        if (!is_array($p) || !in_array($p['type'] ?? '', ['burn', 'burnChecked'], true)) continue;
        $in = $p['info'] ?? [];
        if (($in['mint'] ?? '') !== $mint || (($in['authority'] ?? $in['multisigAuthority'] ?? '') !== $owner)) continue;
        $n += (int)($in['tokenAmount']['amount'] ?? $in['amount'] ?? 0);
    }
    return $n;
}
// what a payment that reached the marketing wallet settles: paid with the burn done, paid in full with the burn still
// owed (a wallet that only sent a plain transfer), or short
function pay_result($o, $sig, $tx, $payer, $got, $extra = []) {
    $r = pay_result_raw($o, $sig, $tx, $payer, $got, $extra);
    $bt = (int)($tx['blockTime'] ?? 0);
    if ($r && isset($r['paid']) && empty($o['late_ok']) && $bt > (int)($o['exp'] ?? ($o['ts'] + ORDER_TTL)) + ORDER_LATE_GRACE) {
        $now = units_for_usd((float)$o['usd'], $o['mint']);
        $sent = (int)$r['got'] + (int)($r['burned'] ?? 0);   // everything that left the buyer's wallet for this order
        if (!$now || $sent < $now['units']) return ['late' => $sig, 'got' => $sent, 'need' => $now['units'] ?? 0, 'payer' => $payer, 'mins' => (int)round(($bt - ($o['exp'] ?? $o['ts'] + ORDER_TTL)) / 60)];
    }
    return $r;
}
function pay_result_raw($o, $sig, $tx, $payer, $got, $extra = []) {
    $burn = (int)($o['burn'] ?? 0);
    if ($burn > 0) {
        $burned = tx_burned($tx, $o['mint'], $payer);
        if ($got >= $o['units'] - $burn && $burned >= $burn) return ['paid' => $sig, 'payer' => $payer, 'got' => $got, 'burned' => $burned] + $extra;
        if ($got >= $o['units']) return ['paid' => $sig, 'payer' => $payer, 'got' => $got, 'burned' => $burned, 'owed' => max(0, $burn - $burned)] + $extra;
        if ($got > 0 || $burned > 0) return ['short' => $sig, 'got' => $got + $burned];
        return null;
    }
    if ($got >= $o['units']) return ['paid' => $sig, 'payer' => $payer, 'got' => $got] + $extra;
    if ($got > 0) return ['short' => $sig, 'got' => $got];
    return null;
}
function order_pay_url($o) {
    //MC 2026-10-10 a burn needs its own instruction, which a plain Solana Pay transfer link can't carry. Those orders hand
    //   the wallet a transaction request instead: the wallet asks paytx.php for the full transaction and signs it.
    //   The order id is 16 random hex characters, so the link can't be guessed, and it only ever builds a payment.
    if (!empty($o['burn'])) return 'solana:' . rawurlencode((defined('TG_SITE') ? TG_SITE : 'https://shyonsol.io') . '/api/paytx.php?o=' . $o['id']);
    // Solana Pay transfer request: phones scan it or open it in a wallet
    $q = ['amount' => rtrim(rtrim(number_format($o['units'] / pow(10, $o['dec']), $o['dec'], '.', ''), '0'), '.'), 'reference' => $o['ref'],
        'label' => 'Shilluminati Online', 'message' => $o['name'], 'memo' => 'shy:' . $o['id']];
    if ($o['mint'] !== SOL_MINT) $q['spl-token'] = $o['mint'];
    return 'solana:' . $o['to'] . '?' . http_build_query($q, '', '&', PHP_QUERY_RFC3986);
}

// Look the order's payment up on Solana. Returns ['paid' => sig, 'payer' => wallet] or ['wait' => reason].
function shop_log($msg) { @file_put_contents(DATA_DIR . '/shop-errors.log', gmdate('c') . ' ' . $msg . "\n", FILE_APPEND); }
// Amount moved by a successful transfer instruction from the marketing wallet back into one of its own accounts.
function self_transfer($tx, $o, $keys) {
    $amt = 0;
    $owned = [];   // token accounts the marketing wallet owns for this mint, after the transaction
    foreach ($tx['meta']['postTokenBalances'] ?? [] as $b) if (($b['mint'] ?? '') === $o['mint'] && ($b['owner'] ?? '') === $o['to']) $owned[$keys[$b['accountIndex']] ?? ''] = 1;
    foreach ($tx['transaction']['message']['instructions'] ?? [] as $ix) {
        $p = $ix['parsed'] ?? null;
        if (!is_array($p)) continue;
        $t = $p['type'] ?? ''; $in = $p['info'] ?? [];
        if ($o['mint'] === SOL_MINT) {
            if (($ix['program'] ?? '') === 'system' && $t === 'transfer' && ($in['source'] ?? '') === $o['to'] && ($in['destination'] ?? '') === $o['to']) $amt += (int)($in['lamports'] ?? 0);
        } elseif ($t === 'transferChecked' && ($in['mint'] ?? '') === $o['mint'] && (($in['authority'] ?? $in['multisigAuthority'] ?? '') === $o['to']) && isset($owned[$in['destination'] ?? ''])) {
            $amt += (int)($in['tokenAmount']['amount'] ?? 0);
        }
    }
    return $amt;
}
// What one transaction paid toward an order: ['paid'|'short'|'failed'|'other' => ...]
function tx_pays($o, $sig) {
    $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]);
    if (!is_array($tx)) return ['pending' => $sig];
    if (!empty($tx['meta']['err'])) return ['failed' => $sig, 'why' => json_encode($tx['meta']['err'])];
    $keys = array_map(fn($k) => is_array($k) ? ($k['pubkey'] ?? '') : $k, $tx['transaction']['message']['accountKeys'] ?? []);
    if (!in_array($o['ref'], $keys, true)) return ['other' => $sig, 'why' => 'reference missing'];
    if (!empty($tx['blockTime']) && $tx['blockTime'] < $o['ts'] - 120) return ['other' => $sig, 'why' => 'older than the order'];
    // Sent from the marketing wallet to itself (the team testing, or buying with project funds). The balance doesn't
    // change, so read the transfer itself instead. It's delivered but kept out of the prize-pool revenue.
    if (($keys[0] ?? '') === $o['to']) {
        $amt = self_transfer($tx, $o, $keys);
        if ($amt >= $o['units']) return ['paid' => $sig, 'payer' => $o['to'], 'got' => $amt, 'selfpay' => true];
        if ($amt > 0) return ['short' => $sig, 'got' => $amt];
        return ['nopay' => $sig, 'why' => 'sent from the marketing wallet with no matching transfer'];
    }
    $got = 0;
    if ($o['mint'] === SOL_MINT) {
        $i = array_search($o['to'], $keys, true);
        if ($i !== false) $got = (int)$tx['meta']['postBalances'][$i] - (int)$tx['meta']['preBalances'][$i];
    } else {
        $pre = [];
        foreach ($tx['meta']['preTokenBalances'] ?? [] as $b) if (($b['mint'] ?? '') === $o['mint'] && ($b['owner'] ?? '') === $o['to']) $pre[$b['accountIndex']] = (int)$b['uiTokenAmount']['amount'];
        foreach ($tx['meta']['postTokenBalances'] ?? [] as $b) if (($b['mint'] ?? '') === $o['mint'] && ($b['owner'] ?? '') === $o['to']) $got += (int)$b['uiTokenAmount']['amount'] - ($pre[$b['accountIndex']] ?? 0);
    }
    if ($r = pay_result($o, $sig, $tx, $keys[0] ?? '', $got)) return $r;
    return ['nopay' => $sig, 'why' => 'no transfer to the marketing wallet found (got ' . $got . ')'];
}
// A payment the buyer points us to themselves (pasted from their wallet or Solscan), for an order whose reference
// never made it into the transaction: some wallets and exchanges drop it. It counts only if it came from a wallet
// linked to the buyer, landed after the order was made, and sent at least the price to the marketing wallet.
function tx_pays_manual($o, $sig, $wallets, $anyPayer = false) {
    static $memo = [];   // one look on Solana per request, however many orders it's tried against
    $tx = $memo[$sig] ?? ($memo[$sig] = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]));
    if (!is_array($tx)) return ['pending' => $sig];
    if (!empty($tx['meta']['err'])) return ['failed' => $sig, 'why' => json_encode($tx['meta']['err'])];
    $keys = array_map(fn($k) => is_array($k) ? ($k['pubkey'] ?? '') : $k, $tx['transaction']['message']['accountKeys'] ?? []);
    $payer = $keys[0] ?? '';
    if (!$anyPayer && !in_array($payer, $wallets, true)) return ['other' => $sig, 'why' => 'sent from a wallet that is not linked to this profile', 'payer' => $payer];
    $bt = (int)($tx['blockTime'] ?? 0);
    if ($bt && ($bt < $o['ts'] - 120 || $bt > $o['ts'] + ORDER_GRACE)) return ['other' => $sig, 'why' => 'sent at a different time than the order'];
    if (in_array($o['ref'], $keys, true)) return tx_pays($o, $sig);   // it does carry the reference after all
    $got = 0;
    if ($o['mint'] === SOL_MINT) {
        $i = array_search($o['to'], $keys, true);
        if ($i !== false) $got = (int)$tx['meta']['postBalances'][$i] - (int)$tx['meta']['preBalances'][$i];
    } else {
        $pre = [];
        foreach ($tx['meta']['preTokenBalances'] ?? [] as $b) if (($b['mint'] ?? '') === $o['mint'] && ($b['owner'] ?? '') === $o['to']) $pre[$b['accountIndex']] = (int)$b['uiTokenAmount']['amount'];
        foreach ($tx['meta']['postTokenBalances'] ?? [] as $b) if (($b['mint'] ?? '') === $o['mint'] && ($b['owner'] ?? '') === $o['to']) $got += (int)$b['uiTokenAmount']['amount'] - ($pre[$b['accountIndex']] ?? 0);
    }
    if ($r = pay_result($o, $sig, $tx, $payer, $got, ['manual' => true])) return $r;
    return ['nopay' => $sig, 'why' => 'no ' . ($o['cur'] ?? '') . ' sent to the marketing wallet'];
}
// Look the order's payment up on Solana. $hint is the signature the browser got back from the wallet, if any.
function verify_payment($o, $hint = '') {
    $tried = []; $hintWhy = ''; $hintFailed = null;
    if ($hint && preg_match('/^[1-9A-HJ-NP-Za-km-z]{64,90}$/', $hint)) {
        $r = tx_pays($o, $hint); $tried[$hint] = 1;
        if (isset($r['paid']) || isset($r['short']) || isset($r['late']) || isset($r['self']) || isset($r['nopay'])) { if (!isset($r['paid'])) shop_log('order ' . $o['id'] . ' ' . json_encode($r)); return $r; }
        if (isset($r['failed'])) $hintFailed = $r;   // a later retry for the same order may still have gone through
        if (isset($r['other'])) { shop_log('order ' . $o['id'] . ' hint ' . json_encode($r)); $hintWhy = $r['why']; }
        if (isset($r['pending'])) $hintWhy = 'the transaction is not on Solana yet';
    }
    $sigs = rpc('getSignaturesForAddress', [$o['ref'], ['limit' => 10, 'commitment' => 'confirmed']]);
    if (!is_array($sigs)) { shop_log('order ' . $o['id'] . ' rpc unreachable'); return ['wait' => 'rpc']; }
    $failed = $hintFailed;
    foreach ($sigs as $s) {
        if (isset($tried[$s['signature']])) continue;
        if (!empty($s['err'])) { $failed = ['failed' => $s['signature'], 'why' => json_encode($s['err'])]; continue; }
        $r = tx_pays($o, $s['signature']);
        if (isset($r['paid']) || isset($r['short']) || isset($r['late'])) return $r;
        if (isset($r['self']) || isset($r['nopay'])) { $failed = $failed ?: $r; continue; }
        if (isset($r['failed'])) $failed = $r;
    }
    if ($failed) { shop_log('order ' . $o['id'] . ' ' . json_encode($failed)); return $failed; }   // failed, self or nopay
    // A signature Solana still doesn't know minutes later, with nothing at all on the order's reference, was dropped
    // before it landed (blockhashes expire after about a minute), so nothing left the buyer's wallet.
    if ($hint && !$sigs && time() - ($o['sig_ts'] ?? $o['ts']) > 300) {
        $d = ['dropped' => $hint, 'why' => $hintWhy ?: 'no transaction found'];
        if (empty($o['issue'])) shop_log('order ' . $o['id'] . ' ' . json_encode($d));
        return $d;
    }
    return ['wait' => 'not yet', 'hint' => $hintWhy];
}

//MC 2026-10-10 $SHY the game has burned: shop payments that burned their share, and burns the team made later for payments
//   that came without one. For the Telegram burn tracker.
function burn_totals() {
    $shy = 0.0; $n = 0; $sigs = [];
    foreach (load(ORDERS) as $o) {
        if (($o['status'] ?? '') !== 'paid' || !empty($o['selfpay'])) continue;
        $d = 10 ** (int)($o['dec'] ?? 6);
        if (!empty($o['burned'])) { $shy += $o['burned'] / $d; $n++; if (!empty($o['proof'])) $sigs[$o['proof']] = 1; }
        if (!empty($o['burn_done'])) { $shy += $o['burn_done'] / $d; $n++; if (!empty($o['burn_sig'])) $sigs[$o['burn_sig']] = 1; }
    }
    //MC 2026-10-13 burns the team records as treasury moves (Admin > Treasury, kind burn) count too: the tracker only
    //   added up shop-order burns, so every burn made outside a sale was missing from the total. Deduped by signature,
    //   in case an order's burn was also logged as a move.
    foreach (load(DATA_DIR . '/treasury-log.php') ?: [] as $m) {
        if (($m['kind'] ?? '') !== 'burn' || (float)($m['shy'] ?? 0) <= 0) continue;
        if (!empty($m['sig']) && isset($sigs[$m['sig']])) continue;
        $shy += (float)$m['shy']; $n++;
    }
    return ['shy' => round($shy), 'n' => $n];
}
// the part of an order's price that reached the marketing wallet (a burned share didn't; a burn still owed did, for now)
function order_net_usd($o) {
    $b = (int)($o['burned'] ?? 0);
    return $b > 0 && !empty($o['units']) ? round($o['usd'] * max(0, $o['units'] - $b) / $o['units'], 2) : (float)$o['usd'];
}
// ---------------------------------------------------------------- limited finish drops
//MC 2026-10-13 a drop sells one card's finish for a set $SHY price, N copies, between a start and an end the team
//   schedules. Each copy is numbered as it sells (copy 7 of 50). Payment is the normal $SHY order: the burn share burns
//   in the buyer's own transaction and the rest lands in the marketing wallet. Nothing a drop sells changes gameplay.
function drop_get($id) { return load(DROPS)[$id] ?? null; }
function drop_live($d) { $now = time(); return $d && empty($d['off']) && $now >= $d['start'] && $now < $d['end'] && (int)$d['sold'] < (int)$d['n']; }
// open quotes inside their price hold keep a copy back, so the last copies can't be oversold by parallel checkouts
function drop_reserved($id) {
    $n = 0;
    foreach (load(ORDERS) as $o) if (($o['product'] ?? '') === 'drop:' . $id && $o['status'] === 'open' && $o['ts'] > time() - ORDER_TTL) $n++;
    return $n;
}
// what the shop shows: drops that are live, due within a week, or ended less than a day ago (shown sold out or ended)
function drops_public() {
    $out = []; $now = time();
    foreach (load(DROPS) as $id => $d) {
        if (!empty($d['off']) || $d['start'] > $now + 7 * 86400 || $d['end'] < $now - 86400) continue;
        $c = deck_card($d['card']); $f = FINISHES[$d['fin']] ?? null;
        if (!$c || !$f) continue;
        $sold = (int)$d['sold'];
        $out[] = ['id' => $id, 'card' => $d['card'], 'fin' => $d['fin'], 'cardName' => $c['name'], 'finName' => $f['name'],
            'shy' => (float)$d['shy'], 'n' => (int)$d['n'], 'sold' => $sold, 'left' => max(0, (int)$d['n'] - $sold),
            'start' => (int)$d['start'], 'end' => (int)$d['end'], 'soldout' => $sold >= (int)$d['n']];
    }
    usort($out, fn($x, $y) => $x['start'] <=> $y['start']);
    return $out;
}

// Give the player what they paid for. Idempotent. Call inside with_lock with the order loaded.
function fulfill(&$orders, $id, $proof, $v = []) {
    $o = $orders[$id] ?? null;
    if (!$o || $o['status'] === 'paid') return $o;
    //MC 2026-10-10 what was burned with this payment, and any burn still owed (a plain transfer of the full price: the team
    //   burns that share from the marketing wallet with the payout button)
    if (!empty($o['burn'])) {
        $o['burned'] = (int)($v['burned'] ?? 0);
        if (!empty($v['owed'])) $o['burn_owed'] = (int)$v['owed'];
        elseif (empty($v) && strpos($proof, 'manual:') === 0) $o['burn_owed'] = (int)$o['burn'];
    }
    $eco = load(ECO);
    $a = eco_get($eco, $o['pid']);
    //MC 2026-10-13 a tournament entry ticket: nothing lands in the account, the paid order itself is the ticket
    //   (tourney_ticket_order finds it when the player signs up). The burn and revenue bookkeeping below still run.
    $p = strpos($o['product'], 'tk:') === 0 ? ['id' => $o['product'], 'name' => $o['name'], 'usd' => $o['usd'], 'kind' => 'ticket']
       : (strpos($o['product'], 'drop:') === 0 ? ['id' => $o['product'], 'name' => $o['name'], 'usd' => $o['usd'], 'kind' => 'drop'] : eco_product($o['product']));
    $got = [];
    if ($p['kind'] === 'ticket') {
        $got[] = $o['name'];
    } elseif ($p['kind'] === 'drop') {
        //MC 2026-10-13 a limited drop: the finish lands on the card, worn right away, and the copy gets its number.
        //   A payment landing after the last copy sold still delivers (they paid); the drop just reads sold out sooner.
        $did = substr($o['product'], 5);
        $drops = load(DROPS);
        if (isset($drops[$did])) {
            $d = $drops[$did];
            grant_finish($a, $d['card'], $d['fin']);
            $a['veq'][$d['card']] = $d['fin'];
            $serial = ++$drops[$did]['sold'];
            $a['dropn'][$did] = $serial;
            save(DROPS, $drops);
            $got[] = $o['name'] . ', copy ' . $serial . ' of ' . (int)$d['n'];
            if ($serial >= (int)$d['n'] && empty($o['selfpay'])) tg_post('drop', '🔥 <b>Sold out.</b> All ' . (int)$d['n'] . ' copies of the ' . tg_h($o['name']) . ' drop are gone.', 'dropout:' . $did);
        } else $got[] = $o['name'];
    } elseif ($p['kind'] === 'pack') {
        $k = $p['koban'] + $p['bonus'];
        // the first time a player buys each pack size, it's double
        $first = empty($a['fp'][$p['id']]);
        if ($first) foreach ($orders as $oid => $x) if ($oid !== $id && $x['pid'] === $o['pid'] && ($x['product'] ?? '') === $p['id'] && $x['status'] === 'paid') { $first = false; break; }
        if ($first) { $k *= 2; $a['fp'][$p['id']] = time(); }
        if ($o['cur'] === 'SHY') $k = (int)round($k * (100 + shy_bonus_for($o['pid'])) / 100);
        eco_credit($a, $k, $p['name'] . ($first ? ' (first buy, doubled)' : ''), 'buy');   //MC 2026-10-13 counted as bought in the faucet report
        $got[] = number_format($k) . ' Koban' . ($first ? ' (doubled)' : '');
    } else {
        if (!empty($p['koban'])) { $k = $p['koban']; if ($o['cur'] === 'SHY') $k = (int)round($k * (100 + shy_bonus_for($o['pid'])) / 100); eco_credit($a, $k, $p['name'], 'buy'); $got[] = number_format($k) . ' Koban'; }   //MC 2026-10-13 counted as bought
        foreach ($p['items'] ?? [] as $it) { eco_grant_item($a, $it); $got[] = eco_item($it)['name']; }
        eco_wear($a, $p['items'] ?? [], true);   // a bundle shows up on you right away, on every board and at the table
        if (!empty($p['scroll'])) { $a['sc']['prem'] = true; $got[] = 'Season Scroll'; }
        if (!empty($p['xp'])) { $a['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, $a['sc']['xp'] + $p['xp']); $got[] = intdiv($p['xp'], TIER_XP) . ' tiers'; }
        if (!empty($p['boost'])) { grant_boost($a, $p['boost']); $got[] = eco_good($p['boost'])['name']; }
        if (!empty($p['plus'])) { $a['sc']['prem'] = true; $a['sc']['plus'] = true; missions_week_init($a); $a['ms']['b'] = 1; $got[] = 'Bounty Board every week'; }
        if (!empty($p['moon'])) { $a['moon'] = max(time(), (int)($a['moon'] ?? 0)) + $p['moon'] * 86400; $got[] = MOON_DAILY . ' Koban a day for ' . $p['moon'] . ' days'; }
        if (!empty($p['once'])) $a['once'][$p['id']] = time();
    }
    $a['spent_usd'] = round(($a['spent_usd'] ?? 0) + $o['usd'], 2);
    $eco[$o['pid']] = $a;
    save(ECO, $eco);
    $o['status'] = 'paid'; $o['paid'] = time(); $o['proof'] = $proof; $o['got'] = $got;
    if (empty($o['selfpay'])) funnel_mark($o['pid'], 'b');
    $orders[$id] = $o;
    save(ORDERS, $orders);
    // a share of every week's shop revenue goes into the next week's prize pool
    if (empty($o['selfpay'])) tg_buy(load(PLAYERS)[$o['pid']]['name'] ?? '', $p['name'], (float)$o['usd'], $o['id'], !empty($o['burned']) ? (int)round($o['burned'] / pow(10, $o['dec'])) : 0, $o['proof'] ?? '');
    if (!empty($o['burned']) && empty($o['selfpay'])) tg_burn((int)round($o['burned'] / pow(10, $o['dec'])), $o['proof'] ?? '', 'a ' . $p['name']);   //MC 2026-10-10 the pinned burn tracker
    if (!empty($o['burned'])) { track('burns'); track('burned_shy', (int)round($o['burned'] / pow(10, $o['dec']))); @unlink(DATA_DIR . '/treasury-cache.php'); }   //MC 2026-10-10
    if (empty($o['selfpay'])) { track('sales'); alert_sale($o, $p); }   //MC 2026-10-09 email the team about every sale
    if (empty($o['selfpay'])) {   // money the project paid itself isn't revenue
        $rw = load(REWARDS);
        $wk = week_key();
        $rw['rev'][$wk] = round(($rw['rev'][$wk] ?? 0) + order_net_usd($o), 2);   //MC 2026-10-10 the burned share never reached the wallet
        save(REWARDS, $rw);
    }
    return $o;
}

// ---------------------------------------------------------------- rewards
function league_pool_usd($wk = null) {
    $set = eco_settings();
    $rw = load(REWARDS);
    $prev = gmdate('o-W', strtotime(($wk ? week_monday($wk) : 'monday this week') . ' -7 days'));
    $rev = (float)($rw['rev'][$prev] ?? 0);
    if (prize_sales()) { $c = prize_cfg('league'); $tot = pool_from($c, $rev); return ['base' => min($c['floor'], $tot), 'share' => round(max(0, $tot - $c['floor']), 2), 'total' => $tot, 'max' => $c['max'], 'rev' => $rev]; }
    $share = round($rev * $set['league_share'] / 100, 2);
    return ['base' => (float)$set['league_usd'], 'share' => $share, 'total' => round($set['league_usd'] + $share, 2)];
}
//MC 2026-10-12 prizes paid from shop sales (see 'prize_mode' in eco_settings). The marketing wallet was paying about $700 a
//   month whatever the shop took; now a quiet week costs the floor and a good week pays more, up to the max.
function prize_sales() { return (eco_settings()['prize_mode'] ?? 'fixed') === 'sales'; }
function prize_cfg($k) { $c = (array)(eco_settings()['pp'][$k] ?? []); return ['floor' => max(0, (float)($c['floor'] ?? 0)), 'pct' => max(0, min(100, (float)($c['pct'] ?? 0))), 'max' => max(0, (float)($c['max'] ?? 0))]; }
function pool_from($c, $rev) { return round(min($c['max'], $c['floor'] + $rev * $c['pct'] / 100), 2); }
function cup_pool_usd($wk = null) {
    if (!prize_sales()) return (float)eco_settings()['cup_usd'];
    $prev = gmdate('o-W', strtotime(($wk ? week_monday($wk) : 'monday this week') . ' -7 days'));
    return pool_from(prize_cfg('cup'), (float)(load(REWARDS)['rev'][$prev] ?? 0));
}
// shop sales in a season: the weeks whose Monday falls inside it (so far, for the season being played)
function season_rev($sn) {
    [$a, $b] = season_bounds($sn); $t = 0.0;
    foreach (load(REWARDS)['rev'] ?? [] as $wk => $u) { $m = strtotime(week_monday($wk) . ' 00:00:00 UTC'); if ($m >= $a && $m < $b) $t += (float)$u; }
    return round($t, 2);
}
function season_pool_usd($sn = null) {
    if (!prize_sales()) return (float)eco_settings()['season_usd'];
    return pool_from(prize_cfg('season'), season_rev($sn ?? season_no()));
}
// places paid in $SHY, and the Koban the places below them get instead (kswap per $1)
function cash_top($k) { return prize_sales() ? max(1, (int)(eco_settings()['cash_top'][$k] ?? 99)) : 99; }
function prize_kx($list, $k) {
    $n = cash_top($k); $rate = max(0, (int)(eco_settings()['kswap'] ?? 0)); $cash = []; $kx = [];
    foreach ($list as $i => $w) { if ($i < $n) { $cash[] = $w; continue; } $kx[] = ['pid' => $w['pid'], 'tag' => $w['tag'] ?? '', 'name' => $w['name'], 'pts' => $w['pts'] ?? 0, 'n' => $w['n'] ?? 0, 'place' => $w['place'], 'koban' => (int)round($w['usd'] * $rate), 'was' => $w['usd']]; }
    return [$cash, $kx];
}
//MC 2026-10-12 how long the marketing wallet lasts: what the prizes cost a week (this week's League and Cup pools, a
//   quarter of the Season pool, the 15 Club spread over the weeks of a month) against what the shop brought in a week over
//   the last 4 finished weeks (shop payments land in the same wallet). $bal: shy_balance() of the wallet, or null.
function prize_runway($bal) {
    $set = eco_settings(); $rw = load(REWARDS); $now = week_key();
    $out = league_pool_usd()['total'] + cup_pool_usd() + season_pool_usd() / SEASON_WEEKS + (float)$set['bounty_usd'] * 12 / 52;
    $past = []; foreach ($rw['rev'] ?? [] as $wk => $u) if ($wk < $now) $past[$wk] = (float)$u;
    krsort($past); $past = array_slice($past, 0, 4, true);
    $in = $past ? array_sum($past) / 4 : 0.0;
    $net = $out - $in; $usd = $bal ? (float)$bal['usd'] : null;
    return ['usd' => $usd, 'shy' => $bal ? (float)$bal['bal'] : null, 'out' => round($out, 2), 'in' => round($in, 2), 'net' => round($net, 2),
        'weeks' => $usd === null ? null : ($net <= 0 ? INF : $usd / $net), 'warn' => max(0, (int)($set['runway_warn'] ?? 4))];
}
function runway_alert() {
    if (!function_exists('mail_alert')) return;
    $r = prize_runway(shy_balance(mw_address()));
    if ($r['weeks'] === null || !is_finite($r['weeks']) || $r['weeks'] >= $r['warn']) return;
    $wk = round($r['weeks'], 1);
    mail_alert('runway', '⚠️ Prize budget: about ' . $wk . ' weeks left in the marketing wallet', 'Prize budget', 'About ' . $wk . ' weeks of prizes left',
        'At this week\'s prize pools the marketing wallet runs out in about ' . $wk . ' weeks. Lower the floors or the max in Admin > Rewards > Prize budget, or top the wallet up.',
        [['stats' => [['Wallet', m_usd($r['usd']), 'in $SHY'], ['Prizes a week', m_usd($r['out']), ''], ['Shop a week', m_usd($r['in']), 'last 4 weeks']]]],
        [['Prize budget', mail_site() . '/admin/?tab=rewards#budget']]);
}
// what the public pages show for a list: Koban per place, the swapped Koban added to the usual Koban
function prize_kob_public($split, $pool, $kob, $k) {
    $n = cash_top($k); $rate = max(0, (int)(eco_settings()['kswap'] ?? 0)); $o = [];
    foreach ($split as $i => $pct) $o[$i] = (int)($kob[$i] ?? 0) + ($i >= $n ? (int)round($pool * $pct / 100 * $rate) : 0);
    return $o;
}
function week_monday($wk) { [$y, $w] = explode('-', $wk); $d = new DateTime('now', new DateTimeZone('UTC')); $d->setISODate((int)$y, (int)$w, 1); return $d->format('Y-m-d'); }

// Standings from player records. which: league | cup | season
function league_rows($players, $holders, $which, $key = null) {
    $rows = [];
    $min = eco_settings()['min_games'];
    $eco = load(ECO);
    $banned = banned_in($players, $holders);   //MC 2026-10-11 no League or Cup prizes for a banned profile
    foreach ($players as $pid => $p) {
        if (isset($banned[$pid])) continue;
        if ($which === 'season') { if (($p['sg']['s'] ?? 0) !== ($key ?? season_no()) || empty($p['sg']['pts'])) continue; $pts = $p['sg']['pts']; $n = $p['sg']['n']; }
        else { if (($p['lg']['wk'] ?? '') !== ($key ?? week_key()) || empty($p['lg']['pts'])) continue; $pts = $p['lg']['pts']; $n = $p['lg']['n']; }
        $h = $holders[$pid] ?? null;
        $tier = holder_tier($h);
        if ($which === 'cup' && !$tier) continue;
        $acc = $eco[$pid] ?? null;
        $rows[] = ['pid' => $pid, 'tag' => substr($pid, 0, 6), 'name' => $p['name'] ?? '', 'pts' => $pts, 'n' => $n, 'wallet' => $h['wallet'] ?? '',
            'tier' => $tier, 'ok' => $n >= ($which === 'season' ? $min * 2 : $min) && !empty($h['wallet']),
            'avatar' => $p['avatar'] ?? '', 'cos' => $acc ? eco_public(eco_get($eco, $pid), $tier) : []];
    }
    usort($rows, fn($a, $b) => [$b['pts'], $a['n']] <=> [$a['pts'], $b['n']]);
    return $rows;
}
// Prize table: who gets what share. Ineligible players (no wallet, too few games) are skipped and the next player moves up.
function prize_table($rows, $split, $poolUsd) {
    $out = []; $k = 0;
    foreach ($rows as $r) {
        if ($k >= count($split)) break;
        if (!$r['ok']) continue;
        $out[] = $r + ['place' => $k + 1, 'pct' => $split[$k], 'usd' => round($poolUsd * $split[$k] / 100, 2)];
        $k++;
    }
    return $out;
}
//MC 2026-10-12 correcting a week after it froze (a match struck on the Fair Play page, or a player banned for using
//   alts). The frozen top 50 is kept once as 'top0'; every correction is a line in 'adj' (tag => points and League games
//   to take off, with why), so the week can be rebuilt any number of times from the same starting point. The prize lists
//   are worked out again with today's bans and wallets, the in-game Koban for the top 10 is evened up (more for anyone who
//   moved up, taken back from anyone who moved down), and 'fixed' notes when. A week with anything already paid, or in a
//   payout batch that was sent, is never changed: the answer says so. Call inside with_lock.
function league_week_paid($rw, $wk) {
    $w = $rw['weeks'][$wk] ?? null; if (!$w) return false;
    foreach (array_merge($w['league'] ?? [], $w['cup'] ?? []) as $x) if (!empty($x['sig'])) return true;
    foreach ($rw['payall_pending'] ?? [] as $pp) foreach ($pp['items'] ?? [] as $it) if (strpos((string)($it['period'] ?? ''), 'week:' . $wk . ':') === 0) return true;
    return false;
}
function league_week_adjust(&$rw, $wk, $tag, $pts, $n, $why) {
    if (!isset($rw['weeks'][$wk])) return false;
    $w = &$rw['weeks'][$wk];
    if (!isset($w['top0'])) $w['top0'] = $w['top'] ?? [];
    $a = $w['adj'][$tag] ?? ['pts' => 0, 'n' => 0, 'why' => []];
    $a['pts'] += (int)$pts; $a['n'] += (int)$n; $a['why'][] = $why;
    $a['why'] = array_slice($a['why'], -20);
    $w['adj'][$tag] = $a;
    unset($w);
    return true;
}
function league_week_rebuild(&$rw, $wk, $players, $holders = null) {
    $w = &$rw['weeks'][$wk];
    if (!$w) return ['ok' => false, 'msg' => 'That week isn\'t final yet.'];
    if (league_week_paid($rw, $wk)) return ['ok' => false, 'msg' => 'Part of week ' . (int)substr($wk, 5) . ' is already paid or in a payout that was sent, so its prize lists stay as they are.'];
    $holders = $holders ?? load(HOLDERS);
    $set = eco_settings();
    $banned = banned_in($players, $holders);
    // tag (6 letters of the id) back to the player: the frozen prize list has the full id; otherwise the one player
    //   with that tag, or with that tag and name when two share it
    $byTag = []; foreach ($players as $pid => $p) $byTag[substr($pid, 0, 6)][] = $pid;
    $known = []; foreach (array_merge($w['league'] ?? [], $w['cup'] ?? []) as $x) if (!empty($x['pid'])) $known[$x['tag'] . '|' . $x['name']] = $x['pid'];
    $pidOf = function ($r) use ($byTag, $known, $players) {
        if (isset($known[$r['tag'] . '|' . $r['name']])) return $known[$r['tag'] . '|' . $r['name']];
        $c = $byTag[$r['tag']] ?? []; if (count($c) === 1) return $c[0];
        foreach ($c as $pid) if (($players[$pid]['name'] ?? '') === $r['name']) return $pid;
        return '';
    };
    if (!isset($w['top0'])) $w['top0'] = $w['top'] ?? [];
    $rows = [];
    foreach ($w['top0'] as $r) {
        $pid = $pidOf($r); if ($pid === '' || isset($banned[$pid])) continue;
        $a = $w['adj'][$r['tag']] ?? ['pts' => 0, 'n' => 0];
        $pts = max(0, (int)$r['pts'] - (int)$a['pts']); $n = max(0, (int)$r['n'] - (int)$a['n']);
        if ($pts <= 0) continue;
        $h = $holders[$pid] ?? null; $tier = holder_tier($h);
        $rows[] = ['pid' => $pid, 'tag' => $r['tag'], 'name' => $r['name'], 'pts' => $pts, 'n' => $n, 'wallet' => $h['wallet'] ?? '',
            'tier' => $tier, 'ok' => $n >= $set['min_games'] && !empty($h['wallet']), 'avatar' => $players[$pid]['avatar'] ?? ''];
    }
    usort($rows, fn($a, $b) => [$b['pts'], $a['n']] <=> [$a['pts'], $b['n']]);
    $skip = []; foreach (array_merge($w['league'] ?? [], $w['cup'] ?? []) as $x) if (!empty($x['skip'])) $skip[$x['pid']] = $x['skip'];
    $old = $w['league'] ?? [];
    $league = prize_table($rows, $set['league_split'], (float)($w['pool']['total'] ?? 0));
    $cup = prize_table(array_values(array_filter($rows, fn($r) => $r['tier'])), $set['cup_split'], (float)($w['cupPool'] ?? 0));
    //MC 2026-10-12 a week frozen with Koban places keeps them; an older week (no lkx) stays all $SHY
    $lkx = []; $ckx = [];
    if (isset($w['lkx'])) { [$league, $lkx] = prize_kx($league, 'league'); [$cup, $ckx] = prize_kx($cup, 'cup'); }
    foreach ([&$league, &$cup] as &$list) foreach ($list as &$x) if (isset($skip[$x['pid']])) $x['skip'] = $skip[$x['pid']];
    unset($list, $x);
    // the in-game Koban for the top 10, evened up
    //MC 2026-10-12 by place, and with the Koban won instead of $SHY
    $kob = function ($list) use ($set) { $o = []; foreach ($list as $x) $o[$x['pid']] = ($o[$x['pid']] ?? 0) + (int)($set['league_koban'][$x['place'] - 1] ?? 0) + (int)($x['koban'] ?? 0); return $o; };
    $kobC = function ($list) use ($set) { $o = []; foreach ($list as $x) $o[$x['pid']] = ($o[$x['pid']] ?? 0) + (int)($set['cup_koban'][$x['place'] - 1] ?? 0) + (int)($x['koban'] ?? 0); return $o; };   //MC 2026-10-12 the Cup's Koban too
    $sum = function ($a, $b) { foreach ($b as $k => $v) $a[$k] = ($a[$k] ?? 0) + $v; return $a; };
    $was = $sum($kob(array_merge($old, $w['lkx'] ?? [])), $kobC(array_merge($w['cup'] ?? [], $w['ckx'] ?? []))); $now = $sum($kob(array_merge($league, $lkx)), $kobC(array_merge($cup, $ckx))); $eco = load(ECO); $moved = false;
    foreach (array_unique(array_merge(array_keys($was), array_keys($now))) as $pid) {
        $d = ($now[$pid] ?? 0) - ($was[$pid] ?? 0); if (!$d) continue;
        $a = eco_get($eco, $pid); eco_credit($a, $d, 'League week ' . $wk . ' corrected'); $eco[$pid] = $a; $moved = true;
    }
    if ($moved) save(ECO, $eco);
    $changes = [];
    foreach ($league as $i => $x) { $j = array_search($x['pid'], array_column($old, 'pid'), true); if ($j === false) $changes[] = $x['name'] . ' in at #' . ($i + 1); elseif ($j !== $i) $changes[] = $x['name'] . ' #' . ($j + 1) . ' to #' . ($i + 1); }
    foreach ($old as $j => $x) if (!in_array($x['pid'], array_column($league, 'pid'), true)) $changes[] = $x['name'] . ' out (was #' . ($j + 1) . ')';
    $w['league'] = $league; $w['cup'] = $cup;
    if (isset($w['lkx'])) { $w['lkx'] = $lkx; $w['ckx'] = $ckx; }
    $w['top'] = array_slice(array_map(fn($r) => array_intersect_key($r, array_flip(['tag', 'name', 'pts', 'n'])), $rows), 0, 50);
    $w['fixed'] = time(); $w['status'] = 'pending';
    unset($w);
    return ['ok' => true, 'msg' => $changes ? 'Prize list changed: ' . implode(', ', $changes) . '.' : 'Prize places are the same as before.'];
}
// When a week ends, freeze its results so payouts use final numbers. Call inside with_lock.
function rewards_freeze($players) {
    $rw = load(REWARDS);
    $now = week_key();
    $changed = false;
    $holders = null;
    $weeks = [];
    foreach ($players as $p) if (!empty($p['lg']['wk']) && $p['lg']['wk'] !== $now) $weeks[$p['lg']['wk']] = 1;
    //MC 2026-10-11 a week is frozen once, ever. Only the newest 52 weeks keep their details, and a week cut from that list
    //   used to look unfrozen again: a player whose last League game was in it got that week's Koban, the email and the
    //   Telegram post on every request (the audit saw 500 Koban paid four times in four requests). 'frozen' keeps just the
    //   keys of every week ever frozen, which costs a few bytes a week; a week older than a year is skipped outright,
    //   the same guard archive_weeks() has. The first run fills 'frozen' from the weeks already kept.
    if (!isset($rw['frozen'])) { $rw['frozen'] = array_fill_keys(array_keys($rw['weeks'] ?? []), 1); if ($rw['frozen']) $changed = true; }
    $oldest = gmdate('o-W', time() - 52 * 7 * 86400);
    foreach (array_keys($weeks) as $wk) {
        if (isset($rw['weeks'][$wk]) || isset($rw['frozen'][$wk]) || $wk > $now || $wk < $oldest) continue;
        $holders = $holders ?? load(HOLDERS);
        $set = eco_settings();
        $pool = league_pool_usd($wk);
        $lg = league_rows($players, $holders, 'league', $wk);
        $cup = league_rows($players, $holders, 'cup', $wk);
        $cupPool = cup_pool_usd($wk);
        //MC 2026-10-12 places below cash_top win Koban instead of $SHY: they move from the prize list to lkx / ckx
        [$lgCash, $lgKx] = prize_kx(prize_table($lg, $set['league_split'], $pool['total']), 'league');
        [$cupCash, $cupKx] = prize_kx(prize_table($cup, $set['cup_split'], $cupPool), 'cup');
        $rw['weeks'][$wk] = ['at' => time(), 'pool' => $pool, 'cupPool' => $cupPool,
            'league' => $lgCash, 'cup' => $cupCash, 'lkx' => $lgKx, 'ckx' => $cupKx,
            'top' => array_slice(array_map(fn($r) => array_intersect_key($r, array_flip(['tag', 'name', 'pts', 'n'])), $lg), 0, 50), 'status' => 'pending'];
        tg_weekly($wk, $rw['weeks'][$wk]['league'], $pool['total']);
        alert_weekly($wk, $rw['weeks'][$wk]);   //MC 2026-10-09 winners and wallets by email
        // in-game Koban for the top 10 lands right away
        $eco = load(ECO);
        foreach (array_merge($rw['weeks'][$wk]['league'], $lgKx) as $w) {
            $i = $w['place'] - 1;
            $k = (int)($set['league_koban'][$i] ?? 0) + (int)($w['koban'] ?? 0);   //MC 2026-10-12 plus the Koban won instead of $SHY
            if (!$k) continue;
            $a = eco_get($eco, $w['pid']);
            eco_credit($a, $k, "League week $wk #" . ($i + 1));
            if ($i === 0) eco_grant_item($a, 'title_champ');
            $eco[$w['pid']] = $a;
        }
        //MC 2026-10-12 Koban for the Holder Cup places too, when the admin set any
        foreach (array_merge($rw['weeks'][$wk]['cup'], $cupKx) as $w) {
            $i = $w['place'] - 1;
            $k = (int)($set['cup_koban'][$i] ?? 0) + (int)($w['koban'] ?? 0);
            if (!$k) continue;
            $a = eco_get($eco, $w['pid']);
            eco_credit($a, $k, "Holder Cup week $wk #" . ($i + 1));
            $eco[$w['pid']] = $a;
        }
        save(ECO, $eco);
        $rw['frozen'][$wk] = 1;
        $changed = true;
        $runway = true;
    }
    // season results freeze once the season is over
    $s = season_no();
    $seasons = [];
    foreach ($players as $p) if (!empty($p['sg']['s']) && $p['sg']['s'] < $s) $seasons[$p['sg']['s']] = 1;
    foreach (array_keys($seasons) as $sn) {
        if (isset($rw['seasons'][$sn])) continue;
        $holders = $holders ?? load(HOLDERS);
        $set = eco_settings();
        $rows = league_rows($players, $holders, 'season', $sn);
        $sp = season_pool_usd($sn);   //MC 2026-10-12 from the season's shop sales in 'sales' mode
        $rw['seasons'][$sn] = ['at' => time(), 'pool' => $sp, 'winners' => prize_table($rows, $set['season_split'], $sp),
            'top' => array_slice(array_map(fn($r) => array_intersect_key($r, array_flip(['tag', 'name', 'pts', 'n'])), $rows), 0, 50), 'status' => 'pending'];
        alert_season($sn, $rw['seasons'][$sn]);
        $changed = true;
    }
    if ($changed) {
        if (!empty($rw['weeks'])) { krsort($rw['weeks']); $rw['weeks'] = array_slice($rw['weeks'], 0, 52, true); }
        if (!empty($rw['rev'])) { krsort($rw['rev']); $rw['rev'] = array_slice($rw['rev'], 0, 60, true); }
        save(REWARDS, $rw);
    }
    if (!empty($runway)) runway_alert();   //MC 2026-10-12 once a week, when the week freezes
}
