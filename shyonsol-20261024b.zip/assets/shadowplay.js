//MC 2026-10-24 Living Shadows, part 2: a holder's Shytoshi Shadow steps off its square and plays the card itself.
//   The figure is the real Shadow, cut out of its background once (api/shadowcut.php, cut on GitHub's machines by
//   checks/shadow_cut.py), with arms in its own hoodie colour that reach into the coat, pull the card and play it:
//   Attack throws it, Defense raises it as a shield, Global holds it overhead and lets it burst. Until a Shadow has its
//   cut, the full picture is used with its edges faded, so it still works for a holder who connected a minute ago.
//   A tap skips it. Reduce Motion and the "Shadow plays" switch in the game menu turn it off.
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var INFO = {}, AURA = { cyan: "#3ff6ff", crimson: "#ff3b5c", lightning: "#9fd0ff", money: "#ffd166", btc: "#f7931a", none: "#b9a6ff" };
  function on() { try { return localStorage.getItem("shy-sp") !== "off"; } catch (e) { return true; } }
  function setOn(v) { try { localStorage.setItem("shy-sp", v ? "on" : "off"); } catch (e) {} }
  function info(n) {
    n = String(n || "");
    if (!/^\d{1,5}$/.test(n)) return Promise.resolve(null);
    if (!INFO[n]) INFO[n] = fetch("api/shadowcut.php?n=" + n).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.has) return null;
      var src = "api/shadowcut.php?n=" + n + "&img=1&v=" + j.v;
      return new Promise(function (res) { var im = new Image(); im.onload = function () { res(Object.assign({ src: src }, j)); }; im.onerror = function () { res(null); }; im.src = src; });
    }).catch(function () { return null; });
    return INFO[n];
  }
  function within(p, ms) { return Promise.race([p, new Promise(function (r) { setTimeout(function () { r(null); }, ms); })]); }
  // a sleeve in the hoodie's colour with a gloved hand; the card rides in the hand of the front arm
  function arm(col, dark, front) {
    var g = "spA" + Math.random().toString(36).slice(2, 8);
    return '<svg viewBox="-30 -6 60 190" class="sp-arm-s"><defs><linearGradient id="' + g + '" x1="0" x2="1"><stop offset="0" stop-color="' + dark + '"/><stop offset=".45" stop-color="' + col + '"/><stop offset="1" stop-color="' + dark + '"/></linearGradient></defs>' +
      '<path d="M-24 0C-26 40 -22 90 -18 140L18 140C22 90 26 40 24 0Z" fill="url(#' + g + ')"/>' +
      '<path d="M-24 0C-26 40 -22 90 -18 140L18 140C22 90 26 40 24 0Z" fill="none" stroke="rgba(255,255,255,.3)" stroke-width="2.4"/><path d="M-24 0C-26 40 -22 90 -18 140" stroke="rgba(255,255,255,.18)" stroke-width="3" fill="none"/><path d="M-19 128H19" stroke="rgba(0,0,0,.35)" stroke-width="5"/>' +
      '<path d="M-17 138C-22 150 -18 172 0 176C18 172 22 150 17 138Z" fill="#0d0b12"/><path d="M-9 162C-3 168 5 168 10 161" stroke="#2a2533" stroke-width="2.4" fill="none"/>' +
      (front ? "" : "") + '</svg>';
  }
  // o: { root, n, src, au, kind: attack|defense|global, card (image url), glyph, mirror, sfx(fn) }
  function play(o) {
    if (reduce || !on() || !o || !o.root) return Promise.resolve(false);
    return within(info(o.n), 220).then(function (cut) { return run(o, cut); });
  }
  var cur = null;
  function run(o, cut) {
    return new Promise(function (done) {
      // the stage covers the part of the game that is on screen right now, so the Shadow never plays below the fold
      var root = o.root, G = root.getBoundingClientRect(), vh = window.innerHeight || document.documentElement.clientHeight;
      var R = { left: Math.max(0, G.left), top: Math.max(0, G.top), right: Math.min(window.innerWidth, G.right), bottom: Math.min(vh, G.bottom) };
      R.width = R.right - R.left; R.height = R.bottom - R.top;
      if (R.width < 200 || R.height < 200) return done(false);
      var col = (cut && cut.col) || "#3a3a46", dark = (cut && cut.dark) || "#121218", ar = (cut && cut.ar) || 1;
      var H = Math.max(170, Math.min(400, R.height * .5)), W = H * ar;
      var st = document.createElement("div");
      st.className = "sp-stage" + (o.mirror ? " mir" : "");
      var aura = AURA[o.au] || AURA.none, kind = o.kind;
      st.innerHTML = '<div class="sp-pos"><div class="sp-fig" style="--h:' + H + 'px;--w:' + W + 'px;--au:' + aura + '">' +
        '<i class="sp-aura"></i>' +
        '<div class="sp-arm sp-back">' + arm(col, dark) + '</div>' +
        (cut ? '<img class="sp-bust" src="' + cut.src + '" alt="">' : '<img class="sp-bust sp-fade" src="' + o.src + '" alt="">') +
        '<div class="sp-arm sp-front">' + arm(col, dark, true) + '<span class="sp-card k-' + kind + '">' + (o.card ? '<img src="' + o.card + '" alt="">' : "") + '<b>' + (o.glyph || "") + '</b></span></div></div></div>';
      st.style.setProperty("--h", H + "px");
      st.style.left = R.left + "px"; st.style.top = R.top + "px"; st.style.width = R.width + "px"; st.style.height = R.height + "px";
      document.body.appendChild(st);
      var pos = st.firstChild, fig = pos.firstChild, bust = fig.querySelector(".sp-bust"), fA = fig.querySelector(".sp-front"), bA = fig.querySelector(".sp-back"), card = fig.querySelector(".sp-card");
      // the arms hang from the shoulders, a little in from where the figure ends
      var sl = cut ? cut.sl : .14, sr = cut ? cut.sr : .86;
      fA.style.left = ((sr - .14) * 100) + "%"; bA.style.left = ((sl + .14) * 100) + "%";   // the card hand is the one nearer the table
      var anims = [], timers = [], ended = false;
      function A(el, frames, ms, delay, ease) { var a = el.animate(frames, { duration: ms, delay: delay || 0, easing: ease || "cubic-bezier(.45,0,.25,1)", fill: "forwards" }); anims.push(a); return a; }
      function T(ms, fn) { timers.push(setTimeout(fn, ms)); }
      function finish() {
        if (ended) return; ended = true;
        anims.forEach(function (a) { try { a.cancel(); } catch (e) {} }); timers.forEach(clearTimeout);
        st.removeEventListener("pointerdown", finish); st.remove(); cur = null; done(true);
      }
      cur = finish;
      st.addEventListener("pointerdown", finish);
      var r = function (d) { return "rotate(" + d + "deg)"; };
      // in: up from the bottom corner with a little overshoot
      A(pos, [{ transform: "translate3d(-30%,40%,0) scale(.86)", opacity: 0 }, { transform: "translate3d(0,0,0) scale(1)", opacity: 1, offset: .7 }, { transform: "translate3d(0,0,0) scale(1)", opacity: 1 }], 340, 0, "cubic-bezier(.2,.9,.3,1.15)");
      // breathe the whole time
      A(bust, [{ transform: "translateY(0) rotate(0)" }, { transform: "translateY(-1.2%) rotate(-1deg)" }, { transform: "translateY(0) rotate(0)" }], 1400, 0, "ease-in-out");
      // reach into the coat and come out holding the card
      A(fA, [{ transform: r(8) }, { transform: r(34), offset: .45 }, { transform: r(-96) }], 520, 220);
      A(card, [{ opacity: 0, transform: "scale(.4)" }, { opacity: 1, transform: "scale(1)" }], 140, 460, "ease-out");
      if (o.sfx) T(460, function () { o.sfx("select"); });
      var total;
      if (kind === "attack") {
        A(fA, [{ transform: r(-96) }, { transform: r(-200) }], 260, 760);
        A(bA, [{ transform: r(-8) }, { transform: r(34) }], 260, 760);
        A(fig, [{ transform: "rotate(0)" }, { transform: "rotate(-5deg)", offset: .55 }, { transform: "rotate(7deg)", offset: .75 }, { transform: "rotate(0)" }], 640, 760);
        A(fA, [{ transform: r(-200) }, { transform: r(-112) }], 150, 1020, "cubic-bezier(.2,.8,.2,1)");
        A(bA, [{ transform: r(34) }, { transform: r(-26) }], 150, 1020, "cubic-bezier(.2,.8,.2,1)");
        T(1080, function () { fly(st, card, o, 380); });
        A(fA, [{ transform: r(-112) }, { transform: r(-64) }], 400, 1170);
        total = 1700;
      } else if (kind === "defense") {
        A(fA, [{ transform: r(-96) }, { transform: r(-80) }], 300, 760, "cubic-bezier(.2,.8,.3,1.1)");
        A(bA, [{ transform: r(-8) }, { transform: r(-70) }], 300, 760, "cubic-bezier(.2,.8,.3,1.1)");
        T(980, function () { var s = spot(st, card), w = document.createElement("i"); w.className = "sp-shield"; w.style.left = s.x + "px"; w.style.top = s.y + "px"; st.appendChild(w); if (o.sfx) o.sfx("block"); });
        A(fig, [{ transform: "rotate(0)" }, { transform: "rotate(4deg)", offset: .3 }, { transform: "rotate(-3deg)", offset: .6 }, { transform: "rotate(0)" }], 700, 980);
        total = 1750;
      } else {
        A(fA, [{ transform: r(-96) }, { transform: r(-176) }], 320, 760, "cubic-bezier(.2,.8,.3,1.1)");
        A(bA, [{ transform: r(-8) }, { transform: r(160) }], 320, 760, "cubic-bezier(.2,.8,.3,1.1)");
        A(bust, [{ transform: "rotate(0)" }, { transform: "rotate(-6deg) translateY(-2%)" }], 320, 760);
        T(1080, function () { var s = spot(st, card), w = document.createElement("i"); w.className = "sp-burst"; w.style.left = s.x + "px"; w.style.top = s.y + "px"; st.appendChild(w); if (o.sfx) o.sfx("global"); if (o.shake) o.shake(); });
        total = 1800;
      }
      // out the way it came
      A(pos, [{ opacity: 1, transform: "translate3d(0,0,0)" }, { opacity: 0, transform: "translate3d(-24%,30%,0) scale(.9)" }], 300, total - 300, "ease-in");
      T(total, finish);
    });
  }
  // where an element is, in the stage's own coordinates
  function spot(st, el) { var s = st.getBoundingClientRect(), r = el.getBoundingClientRect(); return { x: r.left + r.width / 2 - s.left, y: r.top + r.height / 2 - s.top }; }
  // the card leaves the hand and lands in the middle of the table, where the big card picture takes over
  function fly(st, card, o, ms) {
    var a = spot(st, card), s = st.getBoundingClientRect(), b = { x: s.width / 2, y: s.height * .42 };
    var c = card.cloneNode(true); c.className += " sp-fly"; c.style.left = a.x + "px"; c.style.top = a.y + "px";
    card.style.visibility = "hidden"; st.appendChild(c);
    var mx = (a.x + b.x) / 2, my = Math.min(a.y, b.y) - s.height * .18, f = [];
    for (var i = 0; i <= 10; i++) { var t = i / 10, x = (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * mx + t * t * b.x, y = (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * my + t * t * b.y;
      f.push({ transform: "translate(" + (x - a.x) + "px," + (y - a.y) + "px) rotate(" + (t * 420) + "deg) scale(" + (1 + t * .5) + ")" }); }
    c.animate(f, { duration: ms, easing: "cubic-bezier(.3,.1,.5,1)", fill: "forwards" });
    setTimeout(function () { var w = document.createElement("i"); w.className = "sp-hit"; w.style.left = b.x + "px"; w.style.top = b.y + "px"; st.appendChild(w); c.remove(); if (o.sfx) o.sfx("hit"); if (o.shake) o.shake(); }, ms);
  }
  window.ShyShadowPlay = { play: play, prep: function (n) { if (!reduce && on()) info(n); }, on: on, setOn: setOn, skip: function () { if (cur) cur(); } };
})();
