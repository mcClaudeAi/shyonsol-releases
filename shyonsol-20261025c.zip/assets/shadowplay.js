//MC 2026-10-24 Living Shadows, part 2: a holder's Shytoshi Shadow steps off its square and plays the card itself.
//   The figure is the real Shadow, cut out of its background once (api/shadowcut.php, cut on GitHub's machines by
//   checks/shadow_cut.py, which also estimates a depth map for it). Nothing is drawn onto the art: no arms, no hands.
//   The cut figure is lit and moved like a character on a stage. With its depth map the figure is drawn on WebGL and
//   really turns: the hood comes forward, the face sits back, and the whole thing parallaxes with the camera lean.
//   A rim light and a key light are masked to the figure's own outline, so the Shadow is lit by the card it summons.
//   Every Aura has its own move (Lightning cracks the card across the table, Crimson burns it in, Money rains koban,
//   BTC spins it like a coin, Cyan raises a hex dome), each with its own sound, made here with Web Audio so nothing
//   is downloaded. The card's landing is passed back to the game, which hits the real table. In a duel a rival's
//   Shadow takes the hit on its side. A tap skips it. Reduce Motion and the "Shadow plays" setting turn it off, and
//   the game decides which plays earn a cut-in (play.js, spWorthy).
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var INFO = {}, AURA = { cyan: "#3ff6ff", crimson: "#ff3b5c", lightning: "#9fd0ff", money: "#ffd166", btc: "#f7931a", none: "#b9a6ff" };
  var KIND = { attack: "#ff6a5e", defense: "#6ad3ff", global: "#ffd27a" };
  // the setting: on (every worthy play), few (big moments only), off
  function mode() { try { var v = localStorage.getItem("shy-sp"); return v === "off" || v === "few" ? v : "on"; } catch (e) { return "on"; } }
  function setMode(v) { try { localStorage.setItem("shy-sp", v); } catch (e) {} }
  function soundOn() { try { return localStorage.getItem("shy-sound") !== "off"; } catch (e) { return true; } }
  function info(n) {
    n = String(n || "");
    if (!/^\d{1,5}$/.test(n)) return Promise.resolve(null);
    if (!INFO[n]) INFO[n] = fetch("api/shadowcut.php?n=" + n).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.has) return null;
      var src = "api/shadowcut.php?n=" + n + "&img=1&v=" + j.v, dsrc = j.d ? "api/shadowcut.php?n=" + n + "&dep=1&v=" + j.v : "";
      var load = function (u) { return new Promise(function (res) { if (!u) return res(null); var im = new Image(); im.crossOrigin = "anonymous"; im.onload = function () { if (im.decode) im.decode().then(function () { res(im); }, function () { res(im); }); else res(im); }; im.onerror = function () { res(null); }; im.src = u; }); };   //MC 2026-10-25 decoded off the main thread first, so the first frame doesn't stall
      return Promise.all([load(src), load(dsrc)]).then(function (r) { return r[0] ? Object.assign({ src: src, img: r[0], dep: r[1] }, j) : null; });
    }).catch(function () { return null; });
    return INFO[n];
  }
  //MC 2026-10-25 lite stage: a live match on a weaker machine or phone was dropping frames through the cut-in. The stage
  //   now times its own frames; when one runs under 24 fps the rest of the session uses the lite stage (no rays, no
  //   blurred drop, no blended lights, 1x figure canvas), which keeps the move and loses only the polish. Remembered
  //   for the tab in sessionStorage so a slow device isn't retested on every play.
  var lite = false; try { lite = sessionStorage.getItem("shy-sp-lite") === "1"; } catch (e) {}
  function setLite(on) { lite = !!on; try { if (on) sessionStorage.setItem("shy-sp-lite", "1"); else sessionStorage.removeItem("shy-sp-lite"); } catch (e) {} }
  function within(p, ms) { return Promise.race([p, new Promise(function (r) { setTimeout(function () { r(null); }, ms); })]); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  // ---------------------------------------------------------------- sound, made on the spot
  var AC = null;
  function ac() { if (AC) return AC; try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; } return AC; }
  function noise(len) { var c = ac(), b = c.createBuffer(1, c.sampleRate * len, c.sampleRate), d = b.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; return b; }
  function tone(type, f0, f1, t, ms, vol, a) {
    var c = ac(), o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + ms / 1000);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + (a || 0.01)); g.gain.exponentialRampToValueAtTime(0.0001, t + ms / 1000);
    o.connect(g).connect(c.destination); o.start(t); o.stop(t + ms / 1000 + .05);
  }
  function hiss(t, ms, vol, f0, f1, q) {
    var c = ac(), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain(); s.buffer = noise(ms / 1000 + .1); f.type = "bandpass"; f.Q.value = q || 1.2;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + ms / 1000);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + .03); g.gain.exponentialRampToValueAtTime(0.0001, t + ms / 1000);
    s.connect(f).connect(g).connect(c.destination); s.start(t); s.stop(t + ms / 1000 + .1);
  }
  var SFX = {
    whoosh: function (t) { hiss(t, 420, .5, 300, 1400, .8); },
    sigil: function (t) { [1318, 1760, 2637].forEach(function (f, i) { tone("sine", f, f * 1.002, t + i * .06, 700, .12, .02); }); hiss(t, 300, .12, 3000, 6000, 2); },
    charge: function (t) { tone("sawtooth", 80, 420, t, 460, .18, .2); hiss(t, 460, .2, 400, 2600, 1); },
    snap: function (t) { hiss(t, 160, .7, 2500, 600, .7); tone("square", 900, 200, t, 90, .25); },
    impact: function (t) { tone("sine", 160, 38, t, 520, .9, .005); hiss(t, 260, .6, 180, 60, .5); tone("triangle", 1200, 300, t, 120, .2); },
    dome: function (t) { tone("sine", 220, 660, t, 600, .22, .25); [880, 1320].forEach(function (f, i) { tone("sine", f, f, t + .3 + i * .05, 900, .08, .05); }); },
    block: function (t) { hiss(t, 220, .6, 4000, 900, .5); tone("sine", 700, 180, t, 260, .5, .005); },
    rise: function (t) { tone("sine", 220, 880, t, 900, .16, .3); hiss(t, 900, .18, 500, 5000, 1.5); },
    burst: function (t) { tone("sine", 120, 30, t, 800, 1, .005); hiss(t, 600, .7, 6000, 200, .4); [523, 659, 784, 1046].forEach(function (f, i) { tone("sine", f, f, t + .05 + i * .04, 1400, .1, .05); }); },
    crack: function (t) { for (var i = 0; i < 4; i++) hiss(t + i * .045, 90, .5, 6000, 1200, 2); tone("square", 1800, 300, t, 120, .22); },
    burn: function (t) { hiss(t, 900, .45, 200, 900, .6); tone("sawtooth", 60, 140, t, 700, .14, .3); },
    coins: function (t) { for (var i = 0; i < 9; i++) tone("sine", 2200 + Math.random() * 1800, 1800, t + i * .07 + Math.random() * .03, 220, .12, .005); },
    spin: function (t) { for (var i = 0; i < 7; i++) tone("sine", 1400 + i * 120, 1200, t + i * .09, 150, .1, .005); hiss(t, 700, .15, 1500, 4000, 1.5); }
  };
  var BUZZ = { whoosh: [12], sigil: [8, 30, 8], charge: [10, 20, 10, 20, 10], snap: [25], impact: [60, 30, 40], dome: [15, 20, 15], block: [40, 20, 20], rise: [10, 30, 10, 30, 10], burst: [80, 40, 50], crack: [20, 10, 20, 10, 30], burn: [30, 20, 30], coins: [8, 8, 8, 8, 8], spin: [6, 6, 6, 6, 6, 6] };
  function buzz(name) { if (!navigator.vibrate) return; try { navigator.vibrate(BUZZ[name] || [15]); } catch (e) {} }
  function sfx(name, at) { if (at) setTimeout(function () { buzz(name); }, at); else buzz(name); if (!soundOn()) return; var c = ac(); if (!c) return; if (c.state === "suspended") { try { c.resume(); } catch (e) {} } try { SFX[name](c.currentTime + (at || 0) / 1000); } catch (e) {} }

  // ---------------------------------------------------------------- the figure on WebGL, with depth
  var GL = { vs: "attribute vec2 p;varying vec2 v;void main(){v=vec2(p.x*.5+.5,.5-p.y*.5);gl_Position=vec4(p,0.,1.);}",
    fs: "precision mediump float;varying vec2 v;uniform sampler2D img;uniform sampler2D dep;uniform vec2 tilt;uniform float amt;uniform float hasDep;" +
      "void main(){float d=hasDep>.5?texture2D(dep,v).r:.5;vec2 uv=v+tilt*amt*(d-.45);uv=clamp(uv,0.,1.);vec4 c=texture2D(img,uv);" +
      "float edge=smoothstep(0.,.02,uv.x)*smoothstep(0.,.02,1.-uv.x);gl_FragColor=vec4(c.rgb,c.a*edge);}" };
  function glFigure(cut, w, h, maxDpr) {
    var cv = document.createElement("canvas"), dpr = Math.min(maxDpr || 2, window.devicePixelRatio || 1); cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.className = "sp-bust";
    var gl = cv.getContext("webgl", { premultipliedAlpha: false, alpha: true, antialias: false }); if (!gl) return null;
    function sh(t, src) { var s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); return s; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, GL.vs)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, GL.fs)); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return null;
    gl.useProgram(pr);
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var loc = gl.getAttribLocation(pr, "p"); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    function tex(im, unit) { var t = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im); return t; }
    try { tex(cut.img, 0); if (cut.dep) tex(cut.dep, 1); } catch (e) { return null; }
    gl.uniform1i(gl.getUniformLocation(pr, "img"), 0); gl.uniform1i(gl.getUniformLocation(pr, "dep"), 1); gl.uniform1f(gl.getUniformLocation(pr, "hasDep"), cut.dep ? 1 : 0);
    var uT = gl.getUniformLocation(pr, "tilt"), uA = gl.getUniformLocation(pr, "amt");
    gl.viewport(0, 0, cv.width, cv.height); gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    var tx = 0, ty = 0, ox = 0, oy = 0, dead = false;
    var drawn = false;
    function draw() { if (dead) return; if (drawn && Math.abs(tx - ox) < .0015 && Math.abs(ty - oy) < .0015) return; drawn = true; ox += (tx - ox) * .18; oy += (ty - oy) * .18; gl.uniform2f(uT, ox, oy); gl.uniform1f(uA, .07); gl.clear(gl.COLOR_BUFFER_BIT); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }   //MC 2026-10-25 nothing to redraw once the turn has settled
    draw();
    return { el: cv, tilt: function (x, y) { tx = x; ty = y; }, draw: draw, stop: function () { dead = true; var e = gl.getExtension("WEBGL_lose_context"); if (e) try { e.loseContext(); } catch (x) {} } };
  }
  var SIGIL = (function () {
    var r = '<svg viewBox="-50 -50 100 100"><g fill="none" stroke="currentColor"><circle r="46" stroke-width="1.2" stroke-dasharray="3 5"/><circle r="38" stroke-width=".8" opacity=".7"/><path d="M0 -38L33 19L-33 19Z" stroke-width="1.4"/><path d="M0 38L33 -19L-33 -19Z" stroke-width=".8" opacity=".6"/><circle r="8" stroke-width="1.6"/></g>';
    for (var a = 0; a < 360; a += 30) r += '<circle cx="' + (42 * Math.cos(a * Math.PI / 180)).toFixed(1) + '" cy="' + (42 * Math.sin(a * Math.PI / 180)).toFixed(1) + '" r="1.6" fill="currentColor"/>';
    return r + "</svg>";
  })();

  // o: { root, n, au, kind: attack|defense|global, card (image url), name, mirror, target (element), onHit(pt, col), foe: {n, au} }
  var last = null;
  function play(o) {
    if (reduce || mode() === "off" || !o || !o.root) return Promise.resolve(false);
    return within(info(o.n), 600).then(function (cut) {
      if (!cut) return false;
      last = o;
      return within(o.foe && o.foe.n ? info(o.foe.n) : Promise.resolve(null), 200).then(function (foe) { return run(o, cut, foe); });
    });
  }
  var cur = null;
  function run(o, cut, foeCut) {
    if (cur) cur();   //MC 2026-10-25 one stage at a time: a second cut-in landing mid-play ends the first instead of stacking
    return new Promise(function (done) {
      var vw = window.innerWidth, vh = window.innerHeight, G = o.root.getBoundingClientRect();
      var R = { left: Math.max(0, G.left), top: Math.max(0, G.top), right: Math.min(vw, G.right), bottom: Math.min(vh, G.bottom) };
      R.width = R.right - R.left; R.height = R.bottom - R.top;
      if (R.width < 240 || R.height < 240) return done(false);
      var phone = R.width < 700, mir = !!o.mirror, kind = o.kind, auK = AURA[o.au] ? o.au : "none", au = AURA[auK], kc = KIND[kind] || KIND.attack;
      var H = Math.round(Math.min(phone ? R.height * .52 : R.height * .74, 560, (phone ? R.width * .78 : R.width * .5) / cut.ar)), W = Math.round(H * cut.ar);
      var st = document.createElement("div");
      st.className = "sp-stage" + (mir ? " mir" : "") + (phone ? " ph" : "") + (lite ? " lite" : "") + " au-" + auK;
      // the rays are sized to the stage (they were a 220vmax square before, a huge layer to keep redrawing)
      var rs = Math.ceil(Math.max(R.width, R.height) * 1.5);
      st.style.cssText = "left:" + R.left + "px;top:" + R.top + "px;width:" + R.width + "px;height:" + R.height + "px;--au:" + au + ";--kc:" + kc + ";--h:" + H + "px;--w:" + W + "px;--rs:" + rs + "px";
      var M = 'style="-webkit-mask-image:url(' + cut.src + ');mask-image:url(' + cut.src + ')"';
      st.innerHTML = '<div class="sp-dim"></div><div class="sp-bar t"></div><div class="sp-bar b"></div><div class="sp-rays"></div>' +
        '<div class="sp-cam"><div class="sp-fig"><div class="sp-figin">' +
        '<div class="sp-lay sp-drop" ' + M + '></div><div class="sp-lay sp-glow"></div>' +
        '<img class="sp-lay sp-ghost" src="' + cut.src + '" alt=""><img class="sp-lay sp-ghost g2" src="' + cut.src + '" alt="">' +
        '<span class="sp-bustwrap"></span>' +
        '<div class="sp-lay sp-rim" ' + M + '></div><div class="sp-lay sp-key" ' + M + '></div><div class="sp-lay sp-glint" ' + M + '><i></i></div>' +
        '</div></div></div>' +
        '<div class="sp-foe"></div>' +
        '<div class="sp-sigil">' + SIGIL + '</div>' +
        '<div class="sp-card"><img src="' + esc(o.card || "") + '" alt=""><i></i></div>' +
        '<div class="sp-fx"></div>' +
        '<div class="sp-name"><small>' + (mir ? "Rival" : "Your") + " Shadow</small><b>#" + esc(o.n) + (o.name ? " · " + esc(o.name) : "") + '</b></div><div class="sp-skip">Tap to skip</div>';
      document.body.appendChild(st);
      var $ = function (c) { return st.querySelector(c); };
      var cam = $(".sp-cam"), fig = $(".sp-fig"), figin = $(".sp-figin"), card = $(".sp-card"), sigil = $(".sp-sigil"), fx = $(".sp-fx"), rays = $(".sp-rays"), key = $(".sp-key"), rim = $(".sp-rim"), glint = $(".sp-glint i"), glow = $(".sp-glow"), g1 = $(".sp-ghost"), g2 = $(".sp-ghost.g2"), wrap = $(".sp-bustwrap");
      // the figure itself: WebGL with depth when the cut has one and the GPU plays along, the plain picture otherwise
      var gfig = null; try { gfig = glFigure(cut, W, H, lite ? 1 : 1.5); } catch (e) { gfig = null; }
      if (gfig) wrap.appendChild(gfig.el); else { var im = document.createElement("img"); im.className = "sp-bust"; im.src = cut.src; im.alt = ""; wrap.appendChild(im); }
      var anims = [], timers = [], ended = false, raf = 0, camRot = { y: 0, x: 0 }, held = false;
      //MC 2026-10-25 while the stage is up the rest of the page stands still: the 3D table stops rendering until the
      //   hit (o.hold), the seat figure stops drawing and the weather pauses (sp-busy on the game root)
      function hold(on) { if (held === on) return; held = on; if (o.hold) try { o.hold(on); } catch (e) {} if (window.ShyShadowLive && ShyShadowLive.hold) try { ShyShadowLive.hold(on); } catch (e) {} o.root.classList.toggle("sp-busy", on); }
      hold(true);
      var fN = 0, fT0 = performance.now();
      function A(el, frames, ms, delay, ease) { var a = el.animate(frames, { duration: ms, delay: delay || 0, easing: ease || "cubic-bezier(.4,0,.2,1)", fill: "forwards" }); anims.push(a); return a; }
      function T(ms, fn) { timers.push(setTimeout(fn, ms)); }
      function finish() {
        if (ended) return; ended = true;
        anims.forEach(function (a) { try { a.cancel(); } catch (e) {} }); timers.forEach(clearTimeout); cancelAnimationFrame(raf);
        if (gfig) gfig.stop(); st.remove(); cur = null; hold(false);
        var el = performance.now() - fT0; if (!lite && !document.hidden && el > 900 && fN / (el / 1000) < 24) setLite(true);
        done(true);
      }
      cur = finish;
      st.addEventListener("pointerdown", finish);
      var sx = mir ? -1 : 1, S = R, FX = function () { return fig.getBoundingClientRect(); };
      // the camera: one lean at a time, and the depth figure turns with it
      function camTo(y, x, extra, ms, ease) { camRot = { y: y, x: x }; A(cam, [{ transform: cam.style.transform || "perspective(1200px)" }, { transform: "perspective(1200px) rotateY(" + y + "deg) rotateX(" + x + "deg) " + (extra || "") }], ms, 0, ease); cam.style.transform = "perspective(1200px) rotateY(" + y + "deg) rotateX(" + x + "deg) " + (extra || ""); }
      (function tick() { if (ended) return; fN++; if (gfig) { gfig.tilt(-camRot.y / 14, camRot.x / 10); gfig.draw(); } raf = requestAnimationFrame(tick); })();
      // where the card lands: the war table if it's on screen, else the upper middle of the stage
      var tgt = (function () { var m = o.target && o.target.getBoundingClientRect(); if (m && m.width && m.bottom > S.top && m.top < S.bottom) { var t0 = Math.max(S.top, m.top), t1 = Math.min(S.bottom, m.bottom); return { x: m.left + m.width / 2 - S.left, y: (t0 + t1) / 2 - S.top }; } return { x: S.width * (mir ? .38 : .62), y: S.height * .32 }; })();
      function P(x, y) { card.style.left = x + "px"; card.style.top = y + "px"; }
      function mk(cls, x, y) { var e = document.createElement("i"); e.className = cls; e.style.left = x + "px"; e.style.top = y + "px"; fx.appendChild(e); return e; }
      function spark(x, y, col, n, spread, up) {
        if (lite) n = Math.ceil(n / 2);
        for (var i = 0; i < n; i++) {
          var a = Math.random() * 6.283, d = spread * (.4 + Math.random()), s = mk("sp-spark", x, y); s.style.background = col;
          A(s, [{ transform: "translate(0,0) scale(1)", opacity: 1 }, { transform: "translate(" + Math.cos(a) * d + "px," + (Math.sin(a) * d - (up || 0)) + "px) scale(.2)", opacity: 0 }], 500 + Math.random() * 400, 0, "cubic-bezier(.1,.6,.3,1)");
        }
      }
      function flash(ms, op) { var f = mk("sp-flash", 0, 0); A(f, [{ opacity: op || .9 }, { opacity: 0 }], ms || 360, 0, "ease-out"); }
      function ring(x, y, col, size, ms) { var r = mk("sp-ring", x, y); r.style.borderColor = col; r.style.width = r.style.height = size + "px"; A(r, [{ transform: "translate(-50%,-50%) scale(.1)", opacity: 1 }, { transform: "translate(-50%,-50%) scale(1)", opacity: 0 }], ms || 600, 0, "cubic-bezier(.1,.7,.2,1)"); }
      function chest() { var f = FX(); return { x: f.left - S.left + f.width * (mir ? .36 : .64), y: f.top - S.top + f.height * .66 }; }
      function raised() { var f = FX(), cw = H * (phone ? .32 : .27), x = f.left - S.left + (mir ? -cw * .35 : f.width + cw * .35); return { x: Math.max(cw * .8, Math.min(S.width - cw * .8, x)), y: f.top - S.top + f.height * .4 }; }
      function lightFrom(p) { var f = FX(); figin.style.setProperty("--lx", ((p.x + S.left - f.left) / f.width * 100).toFixed(1) + "%"); figin.style.setProperty("--ly", ((p.y + S.top - f.top) / f.height * 100).toFixed(1) + "%"); }
      function shake() { if (o.shake) o.shake(); }
      // the rays only turn while they're visible
      function raysOn() { rays.classList.add("on"); }
      function raysOff(ms) { T(ms || 0, function () { rays.classList.remove("on"); }); }
      // the hit on the table: the game lights the real table, and a rival Shadow takes it on its side
      function landed(p, col) {
        hold(false);
        if (o.onHit) try { o.onHit(p, col); } catch (e) {}
        if (foeCut) foeAnswer(col);
      }
      function foeAnswer(col) {
        var fh = Math.round(H * (phone ? .5 : .72)), fw = Math.round(fh * foeCut.ar), box = $(".sp-foe");
        box.style.cssText = "--fh:" + fh + "px;--fw:" + fw + "px;--au:" + (AURA[o.foe.au] || AURA.none);
        box.innerHTML = '<div class="sp-foein"><img class="sp-foeimg" src="' + foeCut.src + '" alt=""><div class="sp-lay sp-foehit" style="-webkit-mask-image:url(' + foeCut.src + ');mask-image:url(' + foeCut.src + ')"></div></div><small>Rival Shadow #' + esc(o.foe.n) + '</small>';
        A(box, [{ opacity: 0, transform: "translate3d(" + (sx * 30) + "%,8%,0)" }, { opacity: 1, transform: "translate3d(0,0,0)" }], 220, 0, "cubic-bezier(.2,.9,.3,1)");
        var fi = $(".sp-foein"), fh2 = $(".sp-foehit");
        A(fi, [{ transform: "rotate(0) translateX(0)" }, { transform: "rotate(" + (sx * 7) + "deg) translateX(" + (sx * 6) + "%)", offset: .3 }, { transform: "rotate(" + (sx * 2) + "deg) translateX(" + (sx * 2) + "%)" }], 600, 180, "cubic-bezier(.2,.9,.3,1)");
        A(fh2, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .25 }], 700, 180);
        T(200, function () { var r = fi.getBoundingClientRect(); spark(r.left - S.left + r.width * .5, r.top - S.top + r.height * .4, col, 16, 90); });
        A(box, [{ opacity: 1 }, { opacity: 0 }], 260, 1100, "ease-in");
      }

      // ---- 1. the cut-in: bars close, the table dims, the Shadow slides in with a trail
      sfx("whoosh");
      A($(".sp-dim"), [{ opacity: 0 }, { opacity: 1 }], 260, 0, "ease-out");
      A($(".sp-bar.t"), [{ transform: "translateY(-100%)" }, { transform: "translateY(0)" }], 300, 0, "cubic-bezier(.2,.8,.2,1)");
      A($(".sp-bar.b"), [{ transform: "translateY(100%)" }, { transform: "translateY(0)" }], 300, 0, "cubic-bezier(.2,.8,.2,1)");
      A(fig, [{ transform: "translate3d(" + (-sx * 60) + "%,6%,0) scale(.92)", opacity: 0 }, { transform: "translate3d(0,0,0) scale(1)", opacity: 1 }], 380, 40, "cubic-bezier(.15,.9,.25,1)");
      A(g1, [{ transform: "translate3d(" + (-sx * 22) + "%,0,0)", opacity: .35 }, { transform: "translate3d(0,0,0)", opacity: 0 }], 420, 140, "ease-out");
      A(g2, [{ transform: "translate3d(" + (-sx * 44) + "%,0,0)", opacity: .2 }, { transform: "translate3d(0,0,0)", opacity: 0 }], 460, 200, "ease-out");
      T(720, function () { g1.remove(); g2.remove(); });   //MC 2026-10-25 the trail layers are gone once the trail is
      cam.style.transform = "perspective(1200px) rotateY(" + (sx * -11) + "deg) rotateX(2deg)"; camRot = { y: sx * -11, x: 2 };
      T(300, function () { camTo(sx * -5, 1, "scale(1.03)", 700, "ease-in-out"); });
      A($(".sp-name"), [{ opacity: 0, transform: "translateY(8px)" }, { opacity: 1, transform: "translateY(0)" }], 300, 260);
      A($(".sp-skip"), [{ opacity: 0 }, { opacity: 1 }], 300, 700);
      A(figin, [{ transform: "translateY(0) scale(1)" }, { transform: "translateY(-.6%) scale(1.012)" }, { transform: "translateY(0) scale(1)" }], 2600, 0, "ease-in-out");
      // ---- 2. the summon: a sigil at the chest, the card rises out of it, the visor catches it
      var hasCard = !(kind === "enter" || kind === "win" || kind === "lose");
      if (hasCard) T(300, function () { var c = chest(); spark(c.x, c.y, au, 14, 70); sfx("sigil"); });
      if (hasCard) T(340, function () {
        var c = chest(); sigil.style.left = c.x + "px"; sigil.style.top = c.y + "px";
        A(sigil, [{ opacity: 0, transform: "translate(-50%,-50%) rotate(-40deg) scale(.3)" }, { opacity: 1, transform: "translate(-50%,-50%) rotate(0deg) scale(1)", offset: .35 }, { opacity: .85, transform: "translate(-50%,-50%) rotate(90deg) scale(1.08)" }], 1200, 0, "cubic-bezier(.2,.8,.2,1)");
        P(c.x, c.y); lightFrom(c);
        A(card, [{ opacity: 0, transform: "translate(-50%,-50%) perspective(600px) rotateX(70deg) scale(.3)" }, { opacity: 1, transform: "translate(-50%,-50%) perspective(600px) rotateX(0) scale(1)" }], 420, 0, "cubic-bezier(.2,.9,.25,1.2)");
        A(key, [{ opacity: 0 }, { opacity: .85 }], 420, 60);
        A(glow, [{ opacity: .35 }, { opacity: .8 }], 500, 0);
        A(glint, [{ transform: "translateX(-140%)" }, { transform: "translateX(140%)" }], 460, 240, "cubic-bezier(.3,0,.2,1)");
      });
      var total;
      if (kind === "enter" || kind === "win" || kind === "lose") {
        // the arrival at a live table, the winner's moment, and the loser turning away. No card: the Shadow and its Aura
        card.remove(); sigil.remove();
        if (kind === "lose") { st.classList.add("lose"); A(figin, [{ filter: "brightness(1)" }, { filter: "brightness(.45) saturate(.5)" }], 900, 500); T(700, function () { camTo(sx * 14, -1, "scale(.98) translateX(" + (-sx * 3) + "%)", 900, "ease-in-out"); }); total = 1900; }
        else {
          T(420, function () { var c = chest(); c.y -= H * .2; lightFrom(c); A(key, [{ opacity: 0 }, { opacity: .7 }], 400); A(glint, [{ transform: "translateX(-140%)" }, { transform: "translateX(140%)" }], 460, 100, "cubic-bezier(.3,0,.2,1)"); A(glow, [{ opacity: .35 }, { opacity: .9 }], 400); raysOn(); A(rays, [{ opacity: 0, transform: "scale(.6)" }, { opacity: kind === "win" ? .75 : .35, transform: "scale(1)" }], 500); sfx(kind === "win" ? "burst" : "sigil"); });
          if (kind === "win") T(620, function () { var f = FX(), c = { x: f.left - S.left + f.width * .5, y: f.top - S.top + f.height * .3 }, big = Math.min(S.width, S.height); flash(500, .85); ring(c.x, c.y, au, big * 1.2, 800); spark(c.x, c.y, au, 34, 220, 60); A(rim, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .5 }], 800); camTo(sx * -8, 3, "scale(1.08)", 500); shake(); });
          total = kind === "win" ? 2300 : 1500;
        }
        st.querySelector(".sp-name small").textContent = kind === "enter" ? "At the table" : kind === "win" ? "Victory" : "Defeat";
      } else {
      // the signature: how this Aura delivers the card
      var sig = { attack: auK === "lightning" ? "crack" : auK === "crimson" ? "burn" : auK === "btc" ? "coin" : auK === "money" ? "koban" : "throw",
        defense: auK === "cyan" || auK === "lightning" ? "dome" : auK === "crimson" ? "firewall" : "dome", global: auK === "money" || auK === "btc" ? "rain" : "pillar" }[kind];
      if (kind === "attack") {
        T(760, function () {
          var r = raised(); A(card, [{ left: card.style.left, top: card.style.top }, { left: r.x + "px", top: r.y + "px" }], 320, 0, "cubic-bezier(.3,.6,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateX(0) rotateY(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(" + (sx * -28) + "deg) rotateZ(" + (sx * 10) + "deg) scale(1.08)" }], 320, 0);
          camTo(sx * 6, -2, "scale(1) translateX(" + (-sx * 2) + "%)", 300, "ease-out");
          raysOn(); A(rays, [{ opacity: 0, transform: "scale(.6)" }, { opacity: .55, transform: "scale(1)" }], 320, 0);
          sfx("charge");
          T(330, function () { lightFrom(raised()); });
        });
        T(1180, function () {
          var a = raised();
          camTo(sx * -14, 3, "scale(1.07) translateX(" + (sx * 4) + "%)", 180, "cubic-bezier(.2,.9,.2,1)");
          A(rim, [{ opacity: 0 }, { opacity: 1, offset: .25 }, { opacity: .35 }], 500, 0);
          A(sigil, [{ opacity: .85, transform: "translate(-50%,-50%) rotate(90deg) scale(1.08)" }, { opacity: 0, transform: "translate(-50%,-50%) rotate(140deg) scale(1.6)" }], 300, 0);
          var mx = (a.x + tgt.x) / 2, my = Math.min(a.y, tgt.y) - S.height * .14;
          var at = function (t) { return { x: (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * mx + t * t * tgt.x, y: (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * my + t * t * tgt.y }; };
          P(a.x, a.y);
          var fl = 300, f = [];
          if (sig === "crack") {
            // Lightning: the card doesn't fly, it arcs. A bolt forks from the card to the table and the card snaps there
            sfx("crack"); fl = 140;
            var dx = tgt.x - a.x, dy = tgt.y - a.y, len = Math.hypot(dx, dy), ang = Math.atan2(dy, dx) * 180 / Math.PI;
            for (var bi = 0; bi < 3; bi++) { var bb = mk("sp-bolt", a.x, a.y); bb.style.width = len + "px"; bb.style.transform = "rotate(" + (ang + (bi - 1) * 4) + "deg) scaleX(0)"; bb.style.background = "linear-gradient(90deg,transparent,#dff1ff 30%,#fff)"; bb.style.boxShadow = "0 0 16px #9fd0ff"; A(bb, [{ transform: "rotate(" + (ang + (bi - 1) * 4) + "deg) scaleX(0)", opacity: 1 }, { transform: "rotate(" + (ang + (bi - 1) * 4) + "deg) scaleX(1)", opacity: 1, offset: .4 }, { transform: "rotate(" + (ang + (bi - 1) * 4) + "deg) scaleX(1)", opacity: 0 }], 360, bi * 40, "steps(6)"); }
            A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateY(" + (sx * -28) + "deg) scale(1.08)", opacity: 1 }, { transform: "translate(-50%,-50%) translate(" + (tgt.x - a.x) + "px," + (tgt.y - a.y) + "px) scale(.5)", opacity: 1 }], fl, 0, "steps(4)");
          } else {
            for (var i = 0; i <= 12; i++) { var t = i / 12, q = at(t); f.push({ transform: "translate(-50%,-50%) translate(" + (q.x - a.x).toFixed(1) + "px," + (q.y - a.y).toFixed(1) + "px) perspective(600px) rotateY(" + (sx * (-28 + t * (sig === "coin" ? 1440 : 720))) + "deg) scale(" + (1.08 - t * .55) + ")" }); }
            A(card, f, fl, 0, "cubic-bezier(.4,0,.6,1)");
            sfx(sig === "coin" ? "spin" : "snap");
            var t0 = performance.now(), tr = setInterval(function () { var k = (performance.now() - t0) / fl; if (k >= 1) { clearInterval(tr); return; } var e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2, q = at(e), g = mk("sp-streak", q.x, q.y); g.style.width = (H * .2 * (1 - e * .5)) + "px"; g.style.height = (H * .26 * (1 - e * .5)) + "px"; if (sig === "burn") { g.style.background = "#ff6a2a"; g.style.borderRadius = "50%"; } A(g, [{ opacity: .5, transform: "translate(-50%,-50%) scale(1)" }, { opacity: 0, transform: "translate(-50%,-50%) scale(.3) translateY(" + (sig === "burn" ? -40 : 0) + "px)" }], sig === "burn" ? 420 : 240); }, 24);
            timers.push(tr);
          }
          T(fl, function () {
            A(card, [{ opacity: 1 }, { opacity: 0 }], 60);
            var big = Math.min(S.width, S.height);
            if (sig === "burn") { sfx("burn"); flash(300, .5); var bn = mk("sp-burn", tgt.x, tgt.y); bn.style.width = bn.style.height = big * .5 + "px"; A(bn, [{ transform: "translate(-50%,-50%) scale(.2)", opacity: 0 }, { transform: "translate(-50%,-50%) scale(1)", opacity: 1, offset: .3 }, { transform: "translate(-50%,-60%) scale(1.3)", opacity: 0 }], 900, 0, "ease-out"); spark(tgt.x, tgt.y, "#ff8a3c", 26, 120, 120); }
            else if (sig === "koban") { sfx("coins"); flash(300, .6); ring(tgt.x, tgt.y, "#ffd166", big * .6, 500); for (var ci = 0; ci < 16; ci++) { var cn = mk("sp-coin", tgt.x + (Math.random() - .5) * 40, tgt.y - 10); A(cn, [{ transform: "translate(-50%,-50%) translateY(-" + (40 + Math.random() * 120) + "px) rotateY(0)", opacity: 1 }, { transform: "translate(-50%,-50%) translate(" + ((Math.random() - .5) * 180) + "px," + (60 + Math.random() * 120) + "px) rotateY(720deg)", opacity: 0 }], 700 + Math.random() * 400, ci * 25, "cubic-bezier(.3,0,.7,1)"); } }
            else if (sig === "coin") { sfx("impact"); flash(380, .8); ring(tgt.x, tgt.y, "#f7931a", big * .9, 650); ring(tgt.x, tgt.y, "#fff", big * .5, 450); spark(tgt.x, tgt.y, "#f7931a", 26, 150); var cz = mk("sp-coin big", tgt.x, tgt.y); A(cz, [{ transform: "translate(-50%,-50%) scale(.6) rotateY(0)", opacity: 1 }, { transform: "translate(-50%,-50%) scale(2.2) rotateY(540deg)", opacity: 0 }], 700, 0, "ease-out"); }
            else if (sig === "crack") { sfx("impact"); flash(260, .95); flash(500, .4); ring(tgt.x, tgt.y, "#dff1ff", big * .9, 500); spark(tgt.x, tgt.y, "#dff1ff", 30, 170); }
            else { sfx("impact"); flash(380, .75); ring(tgt.x, tgt.y, kc, big * .9, 650); ring(tgt.x, tgt.y, "#fff", big * .5, 450); spark(tgt.x, tgt.y, kc, 26, 150); spark(tgt.x, tgt.y, "#fff", 10, 90); }
            shake(); landed(tgt, sig === "crack" ? "#dff1ff" : sig === "burn" ? "#ff6a2a" : sig === "koban" || sig === "coin" ? "#ffd166" : kc);
            A(rays, [{ opacity: .55 }, { opacity: 0 }], 500, 100); raysOff(600);
            A(key, [{ opacity: .85 }, { opacity: 0 }], 400);
          });
        });
        total = foeCut ? 2700 : 2250;
      } else if (kind === "defense") {
        T(760, function () {
          var r = raised(); r.y += H * .08; A(card, [{ left: card.style.left, top: card.style.top }, { left: r.x + "px", top: r.y + "px" }], 320, 0, "cubic-bezier(.3,.6,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateX(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(" + (sx * 12) + "deg) scale(1.05)" }], 320, 0);
          T(330, function () {
            var p = { x: parseFloat(card.style.left), y: parseFloat(card.style.top) }; lightFrom(p); sfx("dome");
            var fr = FX(), dc = { x: fr.left - S.left + fr.width * .5, y: fr.top - S.top + fr.height * .42 };
            var d = mk(sig === "firewall" ? "sp-dome fire" : "sp-dome", dc.x, dc.y); d.style.width = d.style.height = (H * 1.15) + "px";
            A(d, [{ opacity: 0, transform: "translate(-50%,-50%) scale(.2)" }, { opacity: 1, transform: "translate(-50%,-50%) scale(1.06)", offset: .6 }, { opacity: .95, transform: "translate(-50%,-50%) scale(1)" }], 480, 0, "cubic-bezier(.2,.9,.25,1.15)");
            spark(p.x, p.y, sig === "firewall" ? "#ff8a3c" : kc, 18, 120);
            raysOn(); A(rays, [{ opacity: 0, transform: "scale(.6)" }, { opacity: .4, transform: "scale(1)" }], 400, 0);
            T(520, function () {
              var from = { x: mir ? S.width * .08 : S.width * .92, y: S.height * .1 }, dx = dc.x - from.x, dy = dc.y - from.y, len = Math.hypot(dx, dy), ang = Math.atan2(dy, dx) * 180 / Math.PI;
              var b = mk("sp-bolt", from.x, from.y); b.style.width = Math.max(40, len - H * .55) + "px";
              A(b, [{ transform: "rotate(" + ang + "deg) scaleX(0)", opacity: 1 }, { transform: "rotate(" + ang + "deg) scaleX(1)", opacity: 1, offset: .7 }, { transform: "rotate(" + ang + "deg) scaleX(1)", opacity: 0 }], 300, 0, "ease-in");
              T(210, function () {
                var hx = dc.x - Math.cos(ang * Math.PI / 180) * H * .55, hy = dc.y - Math.sin(ang * Math.PI / 180) * H * .55;
                sfx("block"); flash(300, .5); ring(hx, hy, "#fff", H * .6, 500); spark(hx, hy, sig === "firewall" ? "#ffb070" : "#d8f2ff", 22, 110); shake();
                A(sigil, [{ opacity: .85 }, { opacity: 0 }], 400);
                A(d, [{ transform: "translate(-50%,-50%) scale(1)", filter: "brightness(1)" }, { transform: "translate(-50%,-50%) scale(1.06)", filter: "brightness(1.8)", offset: .2 }, { transform: "translate(-50%,-50%) scale(1)", filter: "brightness(1)" }], 420);
                A(rim, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .3 }], 500);
                camTo(sx * -12, 2, "scale(1.02) translateX(" + (-sx * 2) + "%)", 160, "ease-out"); T(170, function () { camTo(sx * -6, 1, "scale(1.03)", 340, "ease-in-out"); });
                T(380, function () { A(d, [{ opacity: .95 }, { opacity: 0 }], 300); A(card, [{ opacity: 1 }, { opacity: 0 }], 300); A(key, [{ opacity: .85 }, { opacity: 0 }], 300); A(rays, [{ opacity: .4 }, { opacity: 0 }], 300); raysOff(300); });
              });
            });
          });
        });
        total = 2650;
      } else {
        T(760, function () {
          var f = FX(), top = { x: f.left - S.left + f.width * .5, y: Math.max(S.height * .12, f.top - S.top - H * .08) };
          A(card, [{ left: card.style.left, top: card.style.top }, { left: top.x + "px", top: top.y + "px" }], 520, 0, "cubic-bezier(.3,.5,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateY(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(360deg) scale(1.15)" }], 520, 0, "cubic-bezier(.3,.5,.2,1)");
          camTo(sx * -3, 5, "scale(1.06) translateY(2%)", 520);
          sfx("rise");
          var pl = mk("sp-pillar", top.x, 0);
          A(pl, [{ opacity: 0, transform: "translateX(-50%) scaleX(.1)" }, { opacity: 1, transform: "translateX(-50%) scaleX(1)" }], 480, 120, "cubic-bezier(.2,.8,.2,1)");
          raysOn(); A(rays, [{ opacity: 0, transform: "scale(.5)" }, { opacity: .7, transform: "scale(1.1)" }], 600, 100);
          T(300, function () { lightFrom(top); });
          T(620, function () {
            var big = Math.min(S.width, S.height);
            A(sigil, [{ opacity: .85 }, { opacity: 0 }], 300);
            sfx("burst"); flash(520, .95); ring(top.x, top.y, kc, big * 1.3, 800); ring(top.x, top.y, "#fff", big * .7, 600);
            spark(top.x, top.y, kc, 30, 220); spark(top.x, top.y, "#fff8e6", 16, 140); shake();
            if (sig === "rain") { sfx("coins", 150); for (var ci = 0; ci < 22; ci++) { var cn = mk("sp-coin", S.width * Math.random(), -20); A(cn, [{ transform: "translate(-50%,-50%) rotateY(0)", opacity: 0 }, { opacity: 1, offset: .1 }, { transform: "translate(-50%,-50%) translateY(" + (S.height + 40) + "px) rotateY(900deg)", opacity: .9 }], 900 + Math.random() * 700, 100 + ci * 40, "cubic-bezier(.4,0,.8,1)"); } }
            A(card, [{ opacity: 1, transform: "translate(-50%,-50%) perspective(600px) rotateY(360deg) scale(1.15)" }, { opacity: 0, transform: "translate(-50%,-50%) perspective(600px) rotateY(420deg) scale(2.2)" }], 260, 0, "ease-out");
            A(rim, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .4 }], 600);
            A(pl, [{ opacity: 1 }, { opacity: 0 }], 500, 100);
            A(rays, [{ opacity: .7 }, { opacity: 0 }], 600, 200); raysOff(800);
            A(key, [{ opacity: .85 }, { opacity: 0 }], 500, 100);
            landed(top, kc);
          });
        });
        total = sig === "rain" ? 2900 : 2500;
      }
      }
      // ---- out: the Shadow pulls back the way it came, the bars open
      A(fig, [{ transform: "translate3d(0,0,0) scale(1)", opacity: 1 }, { transform: "translate3d(" + (-sx * 30) + "%,4%,0) scale(.94)", opacity: 0 }], 280, total - 300, "cubic-bezier(.5,0,.8,.4)");
      A($(".sp-dim"), [{ opacity: 1 }, { opacity: 0 }], 260, total - 260, "ease-in");
      A($(".sp-bar.t"), [{ transform: "translateY(0)" }, { transform: "translateY(-100%)" }], 260, total - 260, "ease-in");
      A($(".sp-bar.b"), [{ transform: "translateY(0)" }, { transform: "translateY(100%)" }], 260, total - 260, "ease-in");
      A($(".sp-name"), [{ opacity: 1 }, { opacity: 0 }], 200, total - 260);
      A($(".sp-skip"), [{ opacity: 1 }, { opacity: 0 }], 200, total - 260);
      T(total, finish);
    });
  }
  // ---------------------------------------------------------------- the living portrait (profile and player pages)
  //MC 2026-10-24 the living portrait, take two. The first version emptied the avatar box and put the 3D figure in its
  //   place, so on a phone where the canvas didn't draw (seen on iPhone, Sovereign frame and Living Portrait unlock) the
  //   profile showed an empty halo and no NFT at all. Now the picture is never removed: the figure is laid over it, inside
  //   the same round crop, and only after its first frame is read back and has something in it. Until then, and if
  //   anything fails or the context is lost later, it's the normal picture.
  function portrait(sel, n, auK) {
    if (reduce || !sel) return;
    info(n).then(function (cut) {
      // the page may have redrawn while the cut loaded, so the box is found again now
      var el = typeof sel === "string" ? document.querySelector(sel) : sel;
      if (!cut || !el || !document.contains(el) || el.querySelector(".sp-portrait")) return;
      var img = el.querySelector("img"); if (!img) return;
      var r = img.getBoundingClientRect(); if (r.width < 40 || r.height < 40) return;
      var H = Math.round(r.height), W = Math.round(H * cut.ar), dpr = Math.min(2, window.devicePixelRatio || 1);
      var g; try { g = glFigure(cut, Math.round(W * dpr), Math.round(H * dpr)); } catch (e) { g = null; } if (!g) return;
      g.draw();
      // read the first frame back: a canvas that drew nothing must never stand in for the picture
      var ok = false;
      try {
        var gl = g.el.getContext("webgl"), px = new Uint8Array(4), cw = g.el.width, ch = g.el.height;
        for (var a = 1; a < 6 && !ok; a++) for (var b = 1; b < 6 && !ok; b++) { gl.readPixels(Math.round(cw * a / 6), Math.round(ch * b / 6), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px); if (px[3] > 8) ok = true; }
      } catch (e) { ok = false; }
      if (!ok) { g.stop(); return; }
      var cs = getComputedStyle(img), host = img.parentNode;
      if (getComputedStyle(host).position === "static") host.style.position = "relative";
      var box = document.createElement("div"); box.className = "sp-portrait au-" + (AURA[auK] ? auK : "none"); box.setAttribute("aria-hidden", "true");
      box.style.cssText = "--au:" + (AURA[auK] || AURA.none) + ";left:" + (img.offsetLeft) + "px;top:" + (img.offsetTop) + "px;width:" + img.offsetWidth + "px;height:" + img.offsetHeight + "px;border-radius:" + cs.borderRadius;
      var fig = document.createElement("div"); fig.className = "sp-pfig"; fig.style.cssText = "width:" + W + "px;height:" + H + "px";
      fig.appendChild(g.el); box.innerHTML = '<i class="sp-paura"></i>'; box.appendChild(fig);
      img.insertAdjacentElement("afterend", box); el.classList.add("sp-has-portrait");
      var tx = 0, ty = 0, t0 = performance.now(), dead = false;
      function undo() { if (dead) return; dead = true; try { g.stop(); } catch (e) {} box.remove(); el.classList.remove("sp-has-portrait"); document.removeEventListener("pointermove", onMove); }
      g.el.addEventListener("webglcontextlost", undo);
      function onMove(e) { var b = box.getBoundingClientRect(); tx = Math.max(-1, Math.min(1, (e.clientX - (b.left + b.width / 2)) / (b.width * 1.5))); ty = Math.max(-1, Math.min(1, (e.clientY - (b.top + b.height / 2)) / (b.height * 1.5))); }
      document.addEventListener("pointermove", onMove, { passive: true });
      (function tick(now) { if (dead) return; if (!document.contains(box)) { undo(); return; } var b = Math.sin((now - t0) / 1600); g.tilt(tx * .9, ty * .7 + b * .06); g.draw(); fig.style.transform = "translate(-50%," + (b * -1.5) + "px) rotate(" + (tx * 1.2) + "deg)"; requestAnimationFrame(tick); })(t0);
    });
  }
  // ---------------------------------------------------------------- a short clip to share: the cut-in re-played on one canvas
  function clip(o) {
    return info(o.n).then(function (cut) {
      if (!cut || !window.MediaRecorder) return null;
      var W = 720, H = 720, cv = document.createElement("canvas"); cv.width = W; cv.height = H; var x = cv.getContext("2d");
      var fh = Math.round(H * .78), fw = Math.round(fh * cut.ar), g = null; try { g = glFigure(cut, fw, fh); } catch (e) { g = null; }
      var au = AURA[o.au] || AURA.none, kc = KIND[o.kind] || KIND.attack, cardImg = new Image(); cardImg.src = o.card || "";
      var stream = cv.captureStream(30), rec, chunks = [], mime = ["video/mp4;codecs=avc1", "video/webm;codecs=vp9", "video/webm"].filter(function (m) { return MediaRecorder.isTypeSupported(m); })[0];
      if (!mime) return null;
      rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4000000 });
      rec.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
      var fig = cut.img, D = 3000, t0 = performance.now();
      return new Promise(function (res) {
        rec.onstop = function () { if (g) g.stop(); res({ blob: new Blob(chunks, { type: mime.split(";")[0] }), ext: mime.indexOf("mp4") >= 0 ? "mp4" : "webm" }); };
        rec.start(100);
        (function frame(now) {
          var t = Math.min(1, (now - t0) / D), el = now - t0;
          var bg = x.createRadialGradient(W * .5, H * .45, 40, W * .5, H * .45, W * .8); bg.addColorStop(0, "#2a1650"); bg.addColorStop(1, "#07040f"); x.fillStyle = bg; x.fillRect(0, 0, W, H);
          // rays
          x.save(); x.translate(W * .5, H * .4); x.rotate(el / 4000); x.globalAlpha = el > 700 ? Math.min(.5, (el - 700) / 600) : 0;
          for (var i = 0; i < 36; i++) { x.rotate(Math.PI / 18); x.fillStyle = kc; x.beginPath(); x.moveTo(0, 0); x.lineTo(W, -8); x.lineTo(W, 8); x.fill(); } x.restore(); x.globalAlpha = 1;
          // letterbox
          x.fillStyle = "#06040f"; x.fillRect(0, 0, W, H * .07); x.fillRect(0, H * .93, W, H * .07);
          // the figure slides in, tilts with the beat
          var inK = Math.min(1, el / 380), ease = 1 - Math.pow(1 - inK, 3), fx0 = -fw * .5 + (W * .06 + fw * .5) * ease;
          var lean = el > 1100 && el < 1500 ? -.5 : .2;
          if (g) { g.tilt(lean, .1); g.draw(); }
          x.save(); x.globalAlpha = ease; x.shadowColor = au; x.shadowBlur = 60; x.drawImage(g ? g.el : fig, fx0 - fw * .5 + fw * .5, H - fh, fw, fh); x.restore();
          // the card: appears at the chest, rises, fires, impact
          if (el > 500) {
            var cw = fh * .26, ch = cw * 1.4, cx0 = fx0 + fw * .62, cy0 = H - fh * .36, cx = cx0, cy = cy0, sc = Math.min(1, (el - 500) / 300);
            if (el > 1200 && el < 1500) { var k = (el - 1200) / 300; cx = cx0 + (W * .74 - cx0) * k; cy = cy0 + (H * .36 - cy0) * k - Math.sin(k * Math.PI) * 120; sc = 1 - k * .5; }
            if (el <= 1500 && cardImg.complete && cardImg.naturalWidth) { x.save(); x.translate(cx, cy); x.rotate(el > 1200 ? (el - 1200) / 120 : -.15); x.shadowColor = kc; x.shadowBlur = 40; x.drawImage(cardImg, -cw * sc / 2, -ch * sc / 2, cw * sc, ch * sc); x.strokeStyle = "#fff"; x.lineWidth = 3; x.strokeRect(-cw * sc / 2, -ch * sc / 2, cw * sc, ch * sc); x.restore(); }
            if (el >= 1500 && el < 2300) { var q = (el - 1500) / 800; x.save(); x.globalAlpha = 1 - q; x.strokeStyle = kc; x.lineWidth = 8 * (1 - q) + 1; x.beginPath(); x.arc(W * .74, H * .36, 40 + q * 320, 0, 7); x.stroke(); x.restore(); if (q < .25) { x.fillStyle = "rgba(255,255,255," + (1 - q * 4) * .8 + ")"; x.fillRect(0, 0, W, H); } }
          }
          // the tag
          x.font = "700 18px Inter, sans-serif"; x.fillStyle = au; x.textAlign = "right"; x.fillText("SHADOW #" + o.n, W - 36, H * .9 - 26);
          x.font = "800 26px Bricolage Grotesque, Inter, sans-serif"; x.fillStyle = "#fff"; x.fillText(o.name || "", W - 36, H * .9);
          x.textAlign = "left"; x.font = "700 14px Inter, sans-serif"; x.fillStyle = "rgba(255,255,255,.6)"; x.fillText("SHILLUMINATI ONLINE  shyonsol.io/play", 36, H * .9);
          if (t < 1) requestAnimationFrame(frame); else rec.stop();
        })(t0);
      });
    });
  }
  window.ShyShadowPlay = { lite: function (v) { if (v !== undefined) setLite(v); return lite; }, portrait: portrait, clip: clip, fig: glFigure, info: info, sfx: sfx, AURA: AURA, play: play, prep: function (n) { if (!reduce && mode() !== "off") info(n); }, mode: mode, setMode: setMode, on: function () { return mode() !== "off"; },
    skip: function () { if (cur) cur(); }, replay: function () { return last ? play(last) : Promise.resolve(false); }, last: function () { return last; } };
})();
