<?php
//MC 2026-10-12 The Shogun: a 1v1 boss match against the hardest bot in Shilluminati. Players start it from the Play page
//   or with /shilluminatiboss in Telegram, the server plays the Shogun's side (the same live room code as every live
//   match, so nothing a player sends can fake a win), and a win pays boss Koban (Admin > Economy > The Shogun).
//   How it plays: the normal bots look one card ahead with a score for each card. The Shogun tries every move it could
//   make, then plays each one out to the end of the game many times, with the cards it can't see dealt at random from
//   what's left (so it never peeks at your hand), and picks the move that won most often. It only knows what a player
//   at the table would know.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const BOSS_NAME = 'The Shogun';
const BOSS_AVATAR = 'assets/art/masks/shogun.svg';
//MC 2026-10-30 Shogun Elite: the Shogun's harder twin, side by side with it on the Play page. Same brain, one difference
//   that changes everything: it sees every card in your hand. The Shogun deals your hand at random in its playouts; the
//   Elite plays them out with your real cards, so a bluff or a held Blocker means nothing to it. The decks stay hidden
//   from it, so it is beatable, with luck and a plan. Players are told on the card and on the Fair play page. Its own
//   settings (Admin > Rewards > Shogun Elite), its own record file, its own mask (Admin > Art > Bot masks) and its own
//   voice: it names cards it can see. By default it unlocks after a first win over the Shogun (elite_gate).
const ELITE_NAME = 'Shogun Elite';
const ELITE_AVATAR = 'assets/art/masks/elite.svg';
function boss_name($elite = false) { return $elite ? ELITE_NAME : BOSS_NAME; }
function boss_avatar($elite = false) { return $elite ? ELITE_AVATAR : BOSS_AVATAR; }
function boss_is_elite($room) { return !empty($room['boss']['elite']); }
function elite_cfg() {
    $s = eco_settings();
    return ['on' => !isset($s['elite_on']) || !empty($s['elite_on']), 'elite' => true,
        'koban' => max(0, (int)($s['elite_koban'] ?? 1500)),
        'per' => ($s['elite_per'] ?? 'day') === 'week' ? 'week' : 'day',
        //MC 2026-10-31 night: measured against a Shogun-strength rival, seeing the hand alone tops out near 80% (the deck is
        //   random). Thinking time and extra cards together push it to 88% with a 5 Region margin, so those are the defaults:
        //   3 extra cards and 4 seconds a card, with the Elite's own cap at 6 seconds.
        'edge' => max(0, min(5, (int)($s['elite_edge'] ?? 3))),
        'think' => max(200, min(6000, (int)($s['elite_think'] ?? 4000))),
        'wcap' => max(0, min(7, (int)($s['elite_wcap'] ?? 2))),
        'games' => max(1, min(200, (int)($s['elite_games'] ?? 10))),
        'gate' => !isset($s['elite_gate']) || !empty($s['elite_gate']),   // a first win over the Shogun opens it
        'rand' => 0];   // never drops into quick matches
}
// has this player earned the Elite match? the gate is a setting; off, everyone may sit down
function elite_unlocked($pid) {
    if (!elite_cfg()['gate']) return true;
    return (int)(load(BOSS_DB)['p'][$pid]['w'] ?? 0) > 0;
}

function boss_cfg() {
    $s = eco_settings();
    return ['on' => !isset($s['boss_on']) || !empty($s['boss_on']),
        'koban' => max(0, (int)($s['boss_koban'] ?? 500)),
        'per' => ($s['boss_per'] ?? 'day') === 'week' ? 'week' : 'day',
        'edge' => max(0, min(5, (int)($s['boss_edge'] ?? 0))),          //MC 2026-10-14 extra cards, cap raised 3 to 5
        'think' => max(200, min(3500, (int)($s['boss_think'] ?? 700))), //MC 2026-10-14 ms per card, cap raised 2500 to 3500
        'wcap' => max(0, min(7, (int)($s['boss_wcap'] ?? 3))),           //MC 2026-10-18 paid bounties a week (0 = no weekly cap); the win itself always counts
        'games' => max(1, min(200, (int)($s['boss_games'] ?? 25))),
        //MC 2026-10-23 the chance (%) the Shogun takes one of the bot seats in a public quick match, with the same brain
        'rand' => max(0, min(100, (int)($s['boss_rand'] ?? 10)))];     // boss matches a player may start a day
}
//MC 2026-10-18 the Shogun remembers you: a challenger who keeps beating it earns its full attention. Every win past
//   the second buys it 300ms more thinking per card against that player, up to 1,200ms extra inside the usual cap.
//   A casual challenger feels nothing; the farmers get the harder Shogun their record earned.
function boss_mem($pid, $elite = false) {
    $w = (int)(load(boss_dbf($elite))['p'][$pid]['w'] ?? 0);
    return min(4, max(0, $w - 2));
}
//MC 2026-10-18 the Shogun speaks to each challenger by their record against it. One line at the gate when the match
//   opens, one over the result. Written to be read in its voice: cold, a little vain, and it keeps count.
function boss_taunt($pid, $moment = 'start', $won = false, $elite = false) {
    $me = load(boss_dbf($elite))['p'][$pid] ?? null;
    $w = (int)($me['w'] ?? 0); $g = (int)($me['g'] ?? 0);
    $times = $w === 1 ? 'once' : ($w === 2 ? 'twice' : number_format($w) . ' times');
    //MC 2026-10-30 the Elite's own voice: quieter than the Shogun, and every line comes back to what it can see
    if ($elite) {
        if ($moment === 'end') $pool = $won
            ? ($w <= 1 ? ['I saw every card you held, and you still won. Explain that to me.', 'The decks were kind to you. I was not. Remember which one it was.']
                : ['That makes ' . number_format($w) . ' against open cards. I am starting to believe you.', 'Again. Even knowing your hand. I will think about this.'])
            : ($w === 0 ? ['I knew your hand before you did. The ending was never in doubt.', 'Nothing hidden, nothing to fear. Come back with better luck.']
                : ['You have beaten me ' . $times . '. Not with those cards.', 'Your hand was an open book tonight. I read it to the end.']);
        elseif ($g === 0) $pool = ['Show me your hand. Oh. You do not need to.', 'The Shogun guesses. I do not. Sit.'];
        elseif ($w === 0) $pool = ['Back again, with cards I can already see.', 'Match ' . ($g + 1) . '. I remember your hands better than you do.'];
        else $pool = ['You beat me ' . $times . ' with your cards face up. That bothers me.', 'I have studied every hand you ever held against me.'];
        return $pool[mt_rand(0, count($pool) - 1)];
    }
    if ($moment === 'end') {
        $pool = $won
            ? ($w <= 1 ? ['Take your bounty. I will remember this one.', 'So you can bite. Noted.']
                : ['That makes ' . number_format($w) . '. I remember every one.', 'Enjoy it. I am already thinking about the next one.'])
            : ($w === 0 ? ['Did you expect a different ending?', 'Come back when you have learned something.']
                : ['You beat me ' . $times . '. Not tonight.', 'Your ' . ($w === 1 ? 'win' : number_format($w) . ' wins') . ' bought you nothing here.']);
    } elseif ($g === 0) $pool = ['A new face. They all look the same when they lose.', 'Sit down, challenger. This will not take long.'];
    elseif ($w === 0) $pool = ['Back again? The ending does not change.', 'You keep coming. I keep collecting.', $g >= 5 ? 'Match ' . ($g + 1) . '. I admire the stubbornness, nothing else.' : 'Another lesson, then.'];
    elseif ($w <= 2) $pool = ['You beat me ' . $times . '. Luck is not a strategy.', 'I remember that win of yours. I have forgotten nothing.', 'There will not be ' . ($w === 1 ? 'a second' : 'a third') . '.'];
    else $pool = ['You have beaten me ' . $times . '. I have studied every one.', number_format($w) . ' wins is chump change. Show me something new.', 'I thought about you between matches. That is not a compliment.', 'The others fear me. You I respect. Slightly.'];
    return $pool[mt_rand(0, count($pool) - 1)];
}
//MC 2026-10-23 the Shogun talks through the match, not just at the gate: when someone takes Regions from it, when its
//   own play lands hard, when the lead changes hands, as the endgame starts and as the round clock runs down, and now
//   and then at a quiet new round. It watches the board between ticks (counts and the turn), so it hears every play,
//   whoever made it. One line at a time, at least 18 seconds and a round apart (the endgame and the clock may cut in),
//   at most 9 a match. The line goes out in the room view as 'say' (play.js puts it in a bubble under its seat).
const SHOGUN_LINES = [
    'hit' => ['{n}. You will regret that.', 'A scratch. I have bled worse.', 'Bold, {n}. I keep count.', 'You took {k} from me. I take them back with interest.', 'Remember this moment, {n}. It is the last good one.'],
    'big' => ['Feel that, {n}?', 'Every move I make, I have already played a hundred times.', 'Your map is getting smaller, {n}.', 'That was not luck. That was arithmetic.', 'Another one for my collection.'],
    'lead' => ['The world is mine again. As it should be.', 'Look at the board. Then look at me.', 'Back where I belong.'],
    'lost' => ['Enjoy the view from the top, {n}. It does not last.', 'Lead all you like, {n}. I finish.', 'You are ahead. Interesting. It will not hold.'],
    'endgame' => ['{left} Regions left. Count them. Then count mine.', 'The end comes now. Mine always comes first.', 'This is the part where you lose, {n}.'],
    'clock' => ['The clock is my ally.', 'Time is running out, {n}. For you.', '{rl} rounds. I can wait. Can you?'],
    'idle' => ['Your move is taking a long time. I already know it.', 'Round {r}. I am still waiting to be surprised.', 'I see every card you could play.', 'Hesitation is a kind of answer, {n}.', 'Go on. Make your little move.'],
];
//MC 2026-10-30 the Elite's lines: it sees the hands, so it says so. {card} is a card the challenger is holding right now.
const ELITE_LINES = [
    'hit' => ['You took {k} with the {card} still in your hand. I counted on that.', 'A scratch, {n}. I know what you have left.', 'Bold. Your {card} will not save what comes next.'],
    'big' => ['I saw the {card}. I played around it.', 'Every card in your hand, {n}. I have already answered each one.', 'Your map shrinks, and your hand has no answer. I checked.'],
    'lead' => ['The world is mine. Your hand told me it would be.', 'Back on top. Your {card} changes nothing.'],
    'lost' => ['Ahead, {n}. With that hand? Enjoy the minute.', 'You lead. I know exactly how long that lasts.'],
    'endgame' => ['{left} Regions left, and I know every card you can play for them.', 'The end, {n}. Your {card} comes too late.'],
    'clock' => ['{rl} rounds, {n}. I have read your hand for all of them.', 'The clock runs. Your hand does not improve.'],
    'idle' => ['Play the {card}. Or do not. I have planned for both.', 'Take your time, {n}. I already know your move.', 'A {card}, hesitating. Interesting.', 'Nothing in your hand surprises me.'],
];
function shogun_voice(&$room) {
    $g = $room['g']; $bi = -1;
    foreach ($room['seats'] as $i => $s) if (!empty($s['boss'])) { $bi = $i; break; }
    if ($bi < 0 || empty($g['players'])) return;
    $c = array_map(fn($p) => count($p['regions']), $g['players']);
    $v = $room['sv'] ?? null; $now = microtime(true);
    //MC 2026-10-23 how far each real player has fallen behind the Shogun this match, for the comeback count (boss_result)
    foreach ($room['seats'] as $hi => $hs) if (!empty($hs['human'])) $room['sv']['def'][$hi] = max((int)($room['sv']['def'][$hi] ?? 0), $c[$bi] - $c[$hi]);
    $lead = function ($c) { $m = max($c); $w = array_keys($c, $m); return count($w) === 1 ? $w[0] : -1; };
    if (!$v) { $room['sv'] = ($room['sv'] ?? []) + ['c' => $c, 'round' => (int)$g['round'], 'at' => $now, 'n' => 0, 'eg' => 0, 'ck' => 0, 'r' => (int)$g['round'], 'lead' => $lead($c)]; return; }
    $ev = ''; $who = -1; $k = 0;
    $humans = array_keys(array_filter($room['seats'], fn($s) => !empty($s['human'])));
    $dB = $c[$bi] - $v['c'][$bi];
    $lossH = 0; $hurt = -1;
    foreach ($humans as $h) { $d = $c[$h] - ($v['c'][$h] ?? $c[$h]); if ($d < $lossH) { $lossH = $d; $hurt = $h; } }
    $deck = count($g['regionDeck'] ?? []); $n = count($c);
    $rl = (defined('MAX_ROUNDS') ? MAX_ROUNDS : 30) - (int)$g['round'];
    $L = $lead($c);
    // what happened since the last look, most telling first; a hard play only speaks 7 times in 10, so the next in line gets its turn
    $cand = [];
    if ($dB < 0) $cand[] = ['hit', $g['turn'] !== $bi ? $g['turn'] : ($humans[0] ?? -1), -$dB];
    if (($lossH <= -2 || $dB >= 2) && mt_rand(1, 100) <= 70) $cand[] = ['big', $hurt >= 0 ? $hurt : ($humans[0] ?? -1), 0];
    if ($L === $bi && $v['lead'] !== $bi && max($c) >= 3) $cand[] = ['lead', -1, 0];
    if ($L >= 0 && $L !== $bi && $v['lead'] !== $L && in_array($L, $humans, true) && $c[$L] >= 3) $cand[] = ['lost', $L, 0];
    if (!$v['eg'] && $deck > 0 && $deck <= $n * 2) { $cand[] = ['endgame', -1, 0]; $room['sv']['eg'] = 1; }
    if (!$v['ck'] && $rl <= 3 && $rl > 0) { $cand[] = ['clock', -1, 0]; $room['sv']['ck'] = 1; }
    if ((int)$g['round'] > $v['r'] && (int)$g['round'] >= 2 && mt_rand(1, 100) <= 30) $cand[] = ['idle', -1, 0];
    // the endgame and the clock may cut through the cooldown, everything else waits for it
    $cool = $now - $room['sv']['at'] < 18 || ((int)$g['round'] === $room['sv']['round'] && $room['sv']['n'] > 0);
    foreach ($cand as $cd) { if (!$cool || in_array($cd[0], ['endgame', 'clock'], true)) { [$ev, $who, $k] = $cd; break; } }
    $room['sv']['c'] = $c; $room['sv']['lead'] = $L; $room['sv']['r'] = (int)$g['round'];
    if (!$ev || $room['sv']['n'] >= 9) return;
    if ($who < 0) $who = $L >= 0 && $L !== $bi && in_array($L, $humans, true) ? $L : ($humans[0] ?? -1);
    $name = $who >= 0 ? preg_replace('/ \((bot|no show)\)$/', '', (string)($room['seats'][$who]['name'] ?? 'challenger')) : 'challenger';
    $elite = boss_is_elite($room);
    $pool = $elite ? ELITE_LINES[$ev] : SHOGUN_LINES[$ev];
    $card = '';
    if ($elite && $who >= 0) { $hand = (array)($g['players'][$who]['hand'] ?? []); if ($hand) $card = (string)(CARDS[$hand[array_rand($hand)]]['name'] ?? ''); }
    if ($elite && $card === '') $pool = array_values(array_filter($pool, fn($l) => strpos($l, '{card}') === false)) ?: ['Nothing in your hand surprises me.'];
    $t = strtr($pool[mt_rand(0, count($pool) - 1)], ['{n}' => $name, '{k}' => (string)$k . ($k === 1 ? ' Region' : ' Regions'), '{left}' => (string)$deck, '{r}' => (string)(int)$g['round'], '{rl}' => (string)$rl, '{card}' => $card]);
    $room['sv']['at'] = $now; $room['sv']['round'] = (int)$g['round']; $room['sv']['n']++;
    $room['say'] = ['n' => (int)$room['sv']['n'], 'i' => $bi, 't' => $t, 'at' => (int)$now];
    $room['ver']++;
}
//MC 2026-10-18 bounties already paid this ISO week, for the weekly cap: counts the daily payouts whose day falls
//   in the current week (paid keys look like d2026-10-18; the history keeps the last 10, plenty for 7 days)
function boss_week_paid($me) {
    $n = 0;
    foreach ((array)($me['paid'] ?? []) as $k => $v) if ($v && is_string($k) && $k[0] === 'd' && gmdate('o-W', strtotime(substr($k, 1) . ' 12:00:00 UTC')) === week_key()) $n++;
    return $n;
}
// the reward period a win falls in: today, or this week
function boss_period($per) { return $per === 'week' ? 'w' . week_key() : 'd' . today(); }

//MC 2026-10-31 the Elite's brain, second pass. The first Elite kept the real hands in its playouts but only its first
//   card was chosen with them in view: every later move inside a playout came from the plain bot heuristic, which never
//   looks at a hand, so the playouts kept attacking into Decoys and Failed Coups and the noise buried what the open hand
//   was worth. A player saw it attack straight into a blocker. Now:
//   - elite_bot picks every Elite move inside a playout with the hands in view: a card that a reaction or a wall would
//     stop (the engine counts a block when one fires) is never played, and what is played is what gains most on the
//     map right now, the heuristic only breaking ties.
//   - the rival inside a playout plays its best heuristic move (little noise), so the Elite plans against a rival who
//     plays well, not one who fumbles.
//   - at the root, a candidate that would be blocked is dropped before any thinking is spent on it (the pass is kept),
//     and the certain immediate gain of each candidate is added to its playout score as a prior.
//   Bench (boss/elite_bench.php): see the release note for the numbers.
function elite_wasted($g, $pi, $h, $t) {
    $id = $g['players'][$pi]['hand'][$h] ?? ''; if ($id === '' || CARDS[$id]['kind'] !== 'attack') return false;
    $try = $g; $try['log'] = []; $b = (int)($try['blocks'] ?? 0);
    if (!eng_play($try, $pi, $h, $t)) return true;
    return (int)($try['blocks'] ?? 0) > $b;
}
// the map after a move, as (my Regions - the best rival's), against (the same) before: the certain part of a move
function elite_gain($g, $pi, $h, $t) {
    $lead = function ($s) use ($pi) { $m = count($s['players'][$pi]['regions']); $top = 0; foreach ($s['players'] as $i => $p) if ($i !== $pi) $top = max($top, count($p['regions'])); return $m - $top; };
    $try = $g; $try['log'] = [];
    if (!eng_play($try, $pi, $h, $t)) return -9;
    return $lead($try) - $lead($g);
}
function elite_bait($g, $pi, $h, $t) {
    $try = $g; $try['log'] = [];
    if (!eng_play($try, $pi, $h, $t) || $try['plays'] <= 0) return false;
    foreach ($try['players'][$pi]['hand'] as $h2 => $id2) { if (!can_play($id2) || CARDS[$id2]['kind'] !== 'attack') continue; $tg = CARDS[$id2]['target'] === 'pick' ? rivals_of($try, $pi) : [null]; foreach ($tg as $t2) if (!elite_wasted($try, $pi, $h2, $t2) && elite_gain($try, $pi, $h2, $t2) > 0) return true; }
    return false;
}
function elite_bot(&$g, $pi) {
    $p = $g['players'][$pi]; $best = null; $bv = -99;
    $blocked = [];
    foreach ($p['hand'] as $h => $id) {
        if (!can_play($id)) continue;
        $tg = CARDS[$id]['target'] === 'pick' ? rivals_of($g, $pi) : [null];
        foreach ($tg as $t) {
            if (elite_wasted($g, $pi, $h, $t)) { $blocked[$h] = true; continue; }
            $v = elite_gain($g, $pi, $h, $t);
            if ($v > $bv) { $bv = $v; $best = ['hand' => $h, 'target' => $t]; }
        }
    }
    // nothing gains on the map right now: let the heuristic choose among the cards that would not be blocked
    if ($bv <= 0) {
        $gg = $g;
        foreach ($blocked as $h => $_) $gg['players'][$pi]['hand'][$h] = 'decoy';   // a reaction card can never be played, so the heuristic skips it
        $hb = eng_bot($gg, $pi, 0.15);
        if ($hb && !elite_wasted($g, $pi, $hb['hand'], $hb['target']) && elite_gain($g, $pi, $hb['hand'], $hb['target']) >= 0) return $hb;
        return $best !== null && $bv >= 0 ? $best : null;
    }
    return $best;
}
function elite_turn(&$g, $pi) {
    $guard = 0;
    while ($g['plays'] > 0 && !$g['over'] && $guard++ < 8) { $ch = elite_bot($g, $pi); if (!$ch) break; eng_play($g, $pi, $ch['hand'], $ch['target']); }
}
// one move for the Shogun: ['hand' => i, 'target' => t], or null to end the turn (claiming a Region if nothing was played)
function boss_pick($g, $pi, $budgetMs = 700, $see = false) {
    $hand = $g['players'][$pi]['hand'];
    $cands = [null]; $seen = []; $prior = [0.0];
    if ($see) { $try = $g; $try['log'] = []; $lead = function ($s) use ($pi) { $m = count($s['players'][$pi]['regions']); $top = 0; foreach ($s['players'] as $i => $p) if ($i !== $pi) $top = max($top, count($p['regions'])); return $m - $top; }; $l0 = $lead($try); eng_end_turn($try); $prior[0] = max(-3, min(3, $lead($try) - $l0)); }   // the pass claims a Region: its certain gain too
    foreach ($hand as $h => $id) {
        if (!can_play($id) || isset($seen[$id])) continue;
        $seen[$id] = 1;
        $tg = CARDS[$id]['target'] === 'pick' ? rivals_of($g, $pi) : [null];
        foreach ($tg as $t) {
            //MC 2026-10-31 a move the Elite can see being blocked is only kept as a bait: when the turn has another play left
            //   after it and a second attack in hand would then land. Otherwise it is never even considered (a player watched
            //   the first Elite attack straight into a Decoy; the playouts rated burning the Decoy about level with a free
            //   Region, which is arguable on paper and looks blind at the table).
            if ($see && elite_wasted($g, $pi, $h, $t) && !elite_bait($g, $pi, $h, $t)) continue;
            $try = $g; $try['log'] = []; if (eng_play($try, $pi, $h, $t)) { $cands[] = ['hand' => $h, 'target' => $t]; $prior[] = $see ? max(-3, min(3, elite_gain($g, $pi, $h, $t))) : 0.0; }
        }
    }
    if ($g['plays'] <= 0 || count($cands) === 1) return null;
    $keep = $GLOBALS['SHY_SEED'] ?? null;
    rnd_seed(random_int(1, 0x7fffffff));   // the seeded generator is far quicker than random_int for thousands of shuffles
    $sum = array_fill(0, count($cands), 0.0); $n = array_fill(0, count($cands), 0);
    $t0 = microtime(true); $budget = $budgetMs / 1000; $round = 0; $total = 0;
    //MC 2026-10-14 the thinking budget goes where the contest is. It used to be spread evenly over every candidate, so a
    //   clearly bad move got as many playouts as the two real contenders. Now every candidate gets four full looks, then
    //   each further playout goes to the move with the best upper bound (UCB1, c=0.4). Same budget, more looks at the
    //   moves that matter. With the shorter playout horizon below, won 38 of 60 (63%) head to head against the old
    //   picker at equal time; UCB alone tested about even, the two together carry it.
    while (true) {
        if ($round < 4) {
            foreach ($cands as $i => $c) { $sum[$i] += boss_rollout($g, $pi, $c, $see); $n[$i]++; $total++; }
            $round++;
        } else {
            $pick = 0; $bu = -1.0;
            foreach ($cands as $i => $c) { $u = $sum[$i] / $n[$i] + 0.4 * sqrt(log($total) / $n[$i]); if ($u > $bu) { $bu = $u; $pick = $i; } }
            $sum[$pick] += boss_rollout($g, $pi, $cands[$pick], $see); $n[$pick]++; $total++; $round++;
        }
        if ($round >= 6 && microtime(true) - $t0 > $budget) break;
        if ($total >= 400 * count($cands)) break;
    }
    rnd_seed($keep);
    $best = 0; $bv = -1;
    foreach ($cands as $i => $c) { $v = $sum[$i] / max(1, $n[$i]) + 0.1 * $prior[$i]; if ($v > $bv + 1e-9) { $bv = $v; $best = $i; } }   //MC 2026-10-31 the certain gain as a prior for the Elite
    $GLOBALS['BOSS_LAST'] = ['cands' => count($cands), 'rounds' => $round, 'ms' => (int)round((microtime(true) - $t0) * 1000), 'win' => round($bv, 3)];
    return $cands[$best];
}
// deal what the Shogun can't see at random: the other hands come from the unseen cards, the decks are reshuffled
//MC 2026-10-30 $see is Shogun Elite: the rivals' hands stay exactly as they are, only the decks are reshuffled
function boss_determinize(&$s, $pi, $see = false) {
    $pool = $s['chaosDeck'];
    if (!$see) {
        foreach ($s['players'] as $i => $p) if ($i !== $pi) foreach ($p['hand'] as $c) $pool[] = $c;
        $pool = shuf($pool);
        foreach ($s['players'] as $i => $p) if ($i !== $pi) { $k = count($p['hand']); $s['players'][$i]['hand'] = array_splice($pool, 0, $k); }
    } else $pool = shuf($pool);
    $s['chaosDeck'] = $pool;
    $s['regionDeck'] = shuf($s['regionDeck']);
}
// play one move, then the rest of the game with the normal bots on both sides; 1 a win, 0 a loss, between for close ones
function boss_rollout($g, $pi, $c, $see = false) {
    $s = $g; $s['log'] = [];
    boss_determinize($s, $pi, $see);
    if ($c !== null) {
        eng_play($s, $pi, $c['hand'], $c['target']);
        if (eng_more_plays($s, $pi)) { if ($see) elite_turn($s, $pi); else eng_bot_turn($s, $pi, 0.25); }
    }
    $s['log'] = [];
    $over = eng_end_turn($s);
    //MC 2026-10-14 playouts used to run to the end of the game (90 turns); now they run 36 turns and the lead is judged
    //   by the sigmoid below. Each look is cheaper, so the budget buys about twice as many, and the nearer horizon turned
    //   out to judge moves better than a noisy far one: this plus the UCB spread above is the measured 63% head to head.
    for ($guard = 0; !$over && $guard < 36; $guard++) {
        //MC 2026-10-31 inside the Elite's playouts it keeps its own brain, and the rival plays its best heuristic move
        //MC 2026-10-31 later the same day: the rival inside the Elite's playouts now plays the way the Elite itself does, its
        //   strongest certain move with every hand in view. The Elite plans for the best reply a rival could make, not a likely
        //   one, so a strong human finds the door it was counting on already shut.
        //   (Tried: the rival playing the Elite's own full-view policy inside the playouts. Worse, 72% against 76%, and slower.)
        if (!eng_start_turn($s)) { if ($see && $s['turn'] === $pi) elite_turn($s, $pi); else eng_bot_turn($s, $s['turn'], $see ? 0.1 : 0.4); }
        if (count($s['log']) > 40) $s['log'] = [];
        $over = eng_end_turn($s);
    }
    $mine = count($s['players'][$pi]['regions']); $top = 0;
    foreach ($s['players'] as $i => $p) if ($i !== $pi) $top = max($top, count($p['regions']));
    if ($s['over']) {
        $w = eng_winners($s);
        $r = in_array($pi, $w, true) ? (count($w) > 1 ? 0.5 : 1.0) : 0.0;
        return $r * 0.9 + 0.1 / (1 + exp(-($mine - $top) / 2));   // a bigger win scores a little higher, so it never coasts
    }
    return 1 / (1 + exp(-($mine - $top) / 2));
}

// ---------------------------------------------------------------- matches, records and the reward
define('BOSS_DB', DATA_DIR . '/boss.php');   // {t: {g, w, koban}, p: {pid: {g, w, best, paid: {period: koban}}}, s: {pid: [day, starts]}, recent: [...]}
define('ELITE_DB', DATA_DIR . '/boss-elite.php');   //MC 2026-10-30 Shogun Elite keeps the same shape in its own file
function boss_dbf($elite = false) { return $elite ? ELITE_DB : BOSS_DB; }

// can this player start another boss match today? counts the start
function boss_start_ok($pid, $max, $elite = false) {
    return with_lock(function () use ($pid, $max, $elite) {
        $db = load(boss_dbf($elite)); $d = today();
        $s = $db['s'][$pid] ?? ['', 0];
        if ($s[0] !== $d) $s = [$d, 0];
        if ($s[1] >= $max) return false;
        $s[1]++; $db['s'][$pid] = $s;
        //MC 2026-10-14 lifetime starts, for the Fair play table: finished matches plus quits should add up to this.
        //   Before this only today's starts were kept, so a record padded by walking away from bad matches was invisible.
        $db['p'][$pid] = ($db['p'][$pid] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'paid' => []];
        $db['p'][$pid]['st'] = (int)($db['p'][$pid]['st'] ?? 0) + 1;
        foreach ($db['s'] ?? [] as $k => $v) if (($v[0] ?? '') !== $d) unset($db['s'][$k]);   // only today's counts are kept
        save(boss_dbf($elite), $db);
        return true;
    });
}
//MC 2026-10-14 a boss match abandoned mid-game: the player stopped answering, the room froze, and cleanup (livelib) is
//   sweeping it. Written to the record as a quit with the score as it stood, so starts, finished matches and walk-aways
//   all add up in the Fair play table. Not counted as a loss on the public record: the table shows the pattern first.
//   $mt is the dead room file's mtime (its last real activity), so the length is the match, not the 3 hour wait.
function boss_quit($room, $mt = 0) {
    $pid = ''; $name = ''; $mine = 0; $boss = 0;
    foreach ($room['seats'] ?? [] as $i => $s) {
        if (!empty($s['boss'])) $boss = count($room['g']['players'][$i]['regions'] ?? []);
        elseif (!empty($s['human']) && !empty($s['pid'])) { $pid = (string)$s['pid']; $name = (string)($s['name'] ?? ''); $mine = count($room['g']['players'][$i]['regions'] ?? []); }
    }
    if ($pid === '') return;
    $elite = boss_is_elite($room);
    with_lock(function () use ($room, $pid, $name, $mine, $boss, $mt, $elite) {
        $db = load(boss_dbf($elite));
        $me = ($db['p'][$pid] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'paid' => []];
        $me['q'] = (int)($me['q'] ?? 0) + 1;
        if ($name !== '') $me['n'] = $name;
        $db['p'][$pid] = $me;
        $db['t'] = ($db['t'] ?? []) + ['g' => 0, 'w' => 0, 'koban' => 0];
        $db['t']['q'] = (int)($db['t']['q'] ?? 0) + 1;
        $db['log'] = $db['log'] ?? [];
        array_unshift($db['log'], ['t' => time(), 'pid' => $pid, 'name' => $name, 'res' => 'quit', 'r' => $mine, 'b' => $boss,
            'dur' => max(0, ($mt ?: time()) - (int)($room['created'] ?? 0)), 'own' => 1]);
        $db['log'] = array_slice($db['log'], 0, 80);
        save(boss_dbf($elite), $db);
    });
}
// a finished boss match: the record, and the Koban when it's a win the player played all of themselves and this
// period's reward is still open. Called inside end_game's lock.
function boss_result($room, $i, $pid, $name, $r) {
    $cfg = $room['boss'];
    $won = $r['result'] === 'win';
    //MC 2026-10-19 one covered turn is forgiven: a phone locking or one slow decision let a bot play a single
    //   turn and the win lost its bounty and its chat post, even though the player fought the whole match (it
    //   happened to a real win tonight). Two or more covered turns, or being away or gone at the end, still hold
    //   everything back, so a bot can never farm the Shogun for anyone.
    $cov = (int)($room['covered'][$i] ?? 0);
    $own = $cov <= 1 && empty($room['seats'][$i]['away']) && empty($room['seats'][$i]['gone']);
    $elite = boss_is_elite($room);
    $db = load(boss_dbf($elite)) + ['t' => ['g' => 0, 'w' => 0, 'koban' => 0], 'p' => [], 'recent' => []];
    $me = ($db['p'][$pid] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'paid' => []];
    $me['g']++; $db['t']['g']++;
    //MC 2026-10-12 for the Stats page: name for the boards, matches and wins by day, and how far apart each match ended
    $me['n'] = $name;
    $d = today(); $db['days'][$d] = ($db['days'][$d] ?? [0, 0]); $db['days'][$d][0]++;
    if (count($db['days']) > 120) { ksort($db['days']); $db['days'] = array_slice($db['days'], -120, null, true); }
    $out = ['won' => $won, 'koban' => 0, 'why' => '', 'per' => $cfg['per'] ?? 'day', 'elite' => $elite, 'name' => boss_name($elite)];
    $bossRegions = 0; foreach ($room['seats'] as $j => $s) if (!empty($s['boss'])) $bossRegions = count($room['g']['players'][$j]['regions']);
    $diff = max(-15, min(15, (int)$r['regions'] - $bossRegions)); $db['diff'][(string)$diff] = (int)($db['diff'][(string)$diff] ?? 0) + 1;
    //MC 2026-10-23 a flawless win leaves the Shogun with no Regions at all; a comeback win came from 3 or more Regions behind
    $flaw = $won && $bossRegions === 0; $down = (int)($room['sv']['def'][$i] ?? 0); $cb = $won && $down >= BOSS_COMEBACK;
    boss_seed($db);
    if ($flaw) { $db['t']['flaw'] = (int)($db['t']['flaw'] ?? 0) + 1; $me['flaw'] = (int)($me['flaw'] ?? 0) + 1; }
    if ($cb) { $db['t']['cb'] = (int)($db['t']['cb'] ?? 0) + 1; $me['cb'] = (int)($me['cb'] ?? 0) + 1; }
    $prevBig = 0; foreach ($db['recent'] ?? [] as $x) $prevBig = max($prevBig, (int)$x['r'] - (int)$x['b']);
    //MC 2026-10-14 every finished boss match goes in the log the Fair play table reads: result, score, how long it ran
    //   and whether the player played it all themselves. Quits land in the same log from boss_quit when the room is swept.
    $db['log'] = $db['log'] ?? [];
    array_unshift($db['log'], ['t' => time(), 'pid' => $pid, 'name' => $name, 'res' => (string)$r['result'], 'r' => (int)$r['regions'], 'b' => $bossRegions,
        'dur' => max(0, time() - (int)($room['created'] ?? 0)), 'own' => $own ? 1 : 0, 'cov' => $cov, 'down' => $down]);
    $db['log'] = array_slice($db['log'], 0, 80);
    if ($won) {
        $db['days'][$d][1]++;
        $me['w']++; $db['t']['w']++; $me['best'] = max($me['best'], $r['regions']);
        $me['big'] = max((int)($me['big'] ?? 0), $diff);
        $per = boss_period($out['per']);
        $out['wcap'] = (int)($cfg['wcap'] ?? 0);
        if (!$own) { $out['why'] = 'covered'; $out['cov'] = $cov; }
        elseif (!empty($me['paid'][$per])) $out['why'] = 'already';
        //MC 2026-10-18 the weekly bounty cap: three paid wins a week keeps the Koban faucet enclosed. The win still
        //   counts on every board and the record; only the payout waits for Monday.
        elseif (($cfg['per'] ?? 'day') === 'day' && $out['wcap'] > 0 && boss_week_paid($me) >= $out['wcap']) $out['why'] = 'weekcap';
        elseif ((int)($cfg['koban'] ?? 0) > 0) { $out['koban'] = (int)$cfg['koban']; $me['paid'][$per] = $out['koban']; $db['t']['koban'] += $out['koban']; }
        $me['paid'] = array_slice($me['paid'], -10, null, true);
        array_unshift($db['recent'], ['t' => time(), 'pid' => $pid, 'name' => $name, 'r' => $r['regions'], 'b' => $bossRegions, 'k' => $out['koban'], 'down' => $down]);
        $db['recent'] = array_slice($db['recent'], 0, 30);
    }
    $db['p'][$pid] = $me;
    save(boss_dbf($elite), $db);
    $out['record'] = [$me['w'], $me['g']];
    $out['taunt'] = boss_taunt($pid, 'end', $won, $elite);   //MC 2026-10-18 its word over the result, with the fresh count
    //MC 2026-10-12 a loss or draw always posts; a win only when the player played every turn (a bot covering a timed-out
    //   turn used to stop the loss post too, so a lost match with one slow turn never reached the chat)
    if (($own || !$won) && function_exists('tg_post')) boss_tg($pid, $name, $won, $r['result'] === 'tie', (int)$r['regions'], $bossRegions, $me, $db, $out, $prevBig ?? 0, $elite);
    return $out;
}
//MC 2026-10-12 every boss match goes to the Telegram chat. A win is an accomplishment post with the player's profile card
//   as the picture and is pinned (Admin > Telegram > Pin these, on by default; the last win is unpinned so only the latest
//   stays). It says when it is the first win ever, their first, a flawless one or the biggest margin so far. A loss or a
//   tie is a short line under its own switch, "Losses to the Shogun", not held back by the hourly cap for game posts
//   (a skipped loss looked like a bug). A win is posted only when the player played every turn themselves; a loss or draw is always posted.
//   The profile card URL carries the time so Telegram fetches it fresh; if Telegram can't load it the words still go out.
function boss_tg($pid, $name, $won, $tie, $mine, $boss, $me, $db, $out, $prevBig, $elite = false) {
    $n = '<b>' . tg_h($name ?: 'A player') . '</b>';
    $B = $elite ? 'Shogun Elite' : 'the Shogun'; $BN = boss_name($elite);   //MC 2026-10-30 the same posts, in the Elite's name
    $t = $db['t']; $rate = $t['g'] ? round($t['w'] / $t['g'] * 100) : 0;
    $rec = $BN . ' record: ' . number_format($t['g'] - $t['w']) . ' ' . (($t['g'] - $t['w']) === 1 ? 'win' : 'wins') . ', ' . number_format($t['w']) . ' ' . ($t['w'] === 1 ? 'loss' : 'losses') . '.';
    $go = tg_link($elite ? '/play?elite=1' : '/play?boss=1', 'Challenge ' . $B);
    if (!$won) {
        //MC 2026-10-12 level on Regions goes to whoever holds more cards, so "fell 14 to 14" read like a bug: say it was the tiebreak
        $head = $tie ? "🏯 $n fought $B to a draw, $mine to $boss." : ($mine === $boss ? "🏯 $BN holds. $n lost on the tiebreak, $mine Regions each, with $B holding more cards." : "🏯 $BN holds. $n fell $mine to $boss.");
        $line = $me['w'] > 0 ? 'Still ' . $me['w'] . ' ' . ($me['w'] === 1 ? 'win' : 'wins') . ' against it from ' . $me['g'] . ' matches.' : 'Match ' . $me['g'] . ' against ' . $B . '. Their first win is still out there.';
        if ($elite) $line .= ' It saw every card in their hand.';
        //MC 2026-10-13 the Shogun's own victory card rides on the post (share.php?sw=, drawn server side), asked for by
        //   the team: a bot win has one now, and the Shogun of all bots should gloat in pictures
        $cfg = $elite ? elite_cfg() : boss_cfg();
        $img = function_exists('tg_shogun_img') ? tg_shogun_img(['n' => (string)$name, 'mine' => (int)$mine, 'boss' => (int)$boss, 'tie' => (bool)$tie,
            'pw' => (int)$me['w'], 'pg' => (int)$me['g'], 'sw' => (int)$t['g'] - (int)$t['w'], 'sl' => (int)$t['w'],
            'koban' => $cfg['on'] ? (int)$cfg['koban'] : 0, 'per' => (string)$cfg['per'], 'elite' => $elite ? 1 : 0]) : '';
        tg_post('boss_loss', "$head\n$line\n$rec\n\n$go", '', null, $img ?: '');
        return;
    }
    $notes = [];
    if ((int)$t['w'] === 1) $notes[] = '🥇 The first player ever to beat ' . $B . '.';
    elseif ((int)$me['w'] === 1) $notes[] = '🎖 Their first win against ' . $B . '.';
    else $notes[] = '🎖 Win number ' . $me['w'] . ' against ' . $B . ', from ' . $me['g'] . ' matches.';
    if ($elite) $notes[] = '👁 It saw every card in their hand, and lost anyway.';
    if ($boss === 0) $notes[] = '💎 Flawless: ' . $B . ' ended with no Regions at all.';
    elseif ($mine - $boss > $prevBig && $t['w'] > 1) $notes[] = '🔥 The biggest win against it so far, by ' . ($mine - $boss) . ' Regions.';
    if ($out['koban'] > 0) $notes[] = '💰 +' . number_format($out['koban']) . ' Koban reward.';
    $html = "🏯 <b>" . ($elite ? 'SHOGUN ELITE HAS FALLEN' : 'THE SHOGUN HAS FALLEN') . "</b>\n\n⚔️ $n beat $B <b>$mine to $boss</b> in a 1v1 against " . ($elite ? 'the bot that sees your hand' : 'the hardest bot in Shilluminati') . ".\n\n" . implode("\n", $notes) .
        "\n\nPlayers have won " . number_format($t['w']) . ' of ' . number_format($t['g']) . ($t['g'] === 1 ? ' match' : ' matches') . " against it ($rate%).\n\n$go";
    $img = defined('TG_SITE') && preg_match('/^[a-f0-9]{16}$/', $pid) ? TG_SITE . '/api/share.php?p=' . substr($pid, 0, 6) . '&w=' . time() : '';
    tg_post('boss', $html, 'boss:' . $pid . ':' . time(), null, $img);
}
// what the Play page shows: the reward, whether yours is still open, your record and the Shogun's
function boss_info($pid, $elite = false) {
    $cfg = $elite ? elite_cfg() : boss_cfg(); $db = load(boss_dbf($elite));
    $me = $db['p'][$pid] ?? null;
    //MC 2026-10-12 the player's own last win over the Shogun, within a day, so the Play page can offer "Share your win"
    //   after the end screen is long gone (a player asked how to share one again). Score only, never other players' ids.
    $last = null;
    foreach ($db['recent'] ?? [] as $x) if (($x['pid'] ?? '') === $pid && (int)$x['t'] > time() - 86400) { $last = ['r' => (int)$x['r'], 'b' => (int)$x['b'], 't' => (int)$x['t']]; break; }
    //MC 2026-10-13 the day's matches against the cap the team set (boss_games), so the card can say 3/10 today
    $s = $db['s'][$pid] ?? ['', 0];
    $wpaid = $me ? boss_week_paid($me) : 0;
    return ['on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'], 'elite' => $elite, 'name' => boss_name($elite),
        'unlocked' => !$elite || $pid === '' || elite_unlocked($pid), 'gate' => $elite && $cfg['gate'],   //MC 2026-10-30 the Elite waits for a first win over the Shogun
        'open' => $cfg['koban'] > 0 && empty($me['paid'][boss_period($cfg['per'])]) && ($cfg['per'] !== 'day' || $cfg['wcap'] === 0 || $wpaid < $cfg['wcap']),
        'wcap' => $cfg['per'] === 'day' ? $cfg['wcap'] : 0, 'wleft' => max(0, $cfg['wcap'] - $wpaid),
        'mem' => boss_mem($pid, $elite),   //MC 2026-10-18 the Shogun remembers you: the panel says so from the third win
        'me' => $me ? [(int)$me['w'], (int)$me['g']] : [0, 0],
        'today' => $s[0] === today() ? (int)$s[1] : 0, 'max' => (int)$cfg['games'],
        'maskv' => (int)@filemtime(dirname(__DIR__) . '/' . boss_avatar($elite)),   //MC 2026-10-13 the panel refetches the mask when it changes

        'last' => $last,
        'all' => [(int)($db['t']['w'] ?? 0), (int)($db['t']['g'] ?? 0)],
        'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0))];
}

//MC 2026-10-12 the Shogun section on the Stats page (stats.php?a=boss): totals, the last 30 days, how close matches end,
//   the latest players to beat it and the most wins against it. Names only, never ids or wallets.
//MC 2026-10-23 the flawless count starts from the wins already on record (the match log and the latest wins, each match
//   once); comebacks need the gap tracked during the match, so they count from today. Runs once, then the totals carry on.
const BOSS_COMEBACK = 3;   // Regions behind the Shogun at some point, for a win to count as a comeback
function boss_seed(&$db) {
    if (isset($db['t']['flaw'])) return false;
    $seen = []; $n = 0;
    foreach (array_merge($db['log'] ?? [], $db['recent'] ?? []) as $x) {
        $k = ($x['t'] ?? 0) . '|' . ($x['pid'] ?? ''); if (isset($seen[$k])) continue; $seen[$k] = 1;
        $won = isset($x['res']) ? $x['res'] === 'win' : true;   // the latest-wins list only holds wins
        if ($won && (int)($x['b'] ?? -1) === 0) $n++;
    }
    $db['t']['flaw'] = $n; $db['t']['cb'] = (int)($db['t']['cb'] ?? 0); $db['t']['cbs'] = time();
    return true;
}
function boss_public($elite = false) {
    $cfg = $elite ? elite_cfg() : boss_cfg(); $db = load(boss_dbf($elite));
    if (!isset($db['t']['flaw'])) $db = with_lock(function () use ($elite) { $d = load(boss_dbf($elite)); if (boss_seed($d)) save(boss_dbf($elite), $d); return $d; });
    $t = ($db['t'] ?? []) + ['g' => 0, 'w' => 0, 'koban' => 0];
    $days = []; for ($i = 29; $i >= 0; $i--) { $d = gmdate('Y-m-d', time() - $i * 86400); $days[] = [$d, (int)($db['days'][$d][0] ?? 0), (int)($db['days'][$d][1] ?? 0)]; }
    $diff = []; for ($k = -15; $k <= 15; $k++) $diff[] = (int)($db['diff'][(string)$k] ?? 0);
    $ppl = array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0 && !empty($x['n']));
    uasort($ppl, fn($a, $b) => [$b['w'], -$b['g'], $b['best'] ?? 0] <=> [$a['w'], -$a['g'], $a['best'] ?? 0]);
    $top = array_values(array_map(fn($x) => ['n' => $x['n'], 'w' => (int)$x['w'], 'g' => (int)$x['g'], 'best' => (int)($x['best'] ?? 0), 'big' => (int)($x['big'] ?? 0)], array_slice($ppl, 0, 10)));
    $recent = array_map(fn($x) => ['n' => $x['name'], 'r' => (int)$x['r'], 'b' => (int)$x['b'], 't' => (int)$x['t'], 'k' => (int)$x['k'], 'f' => (int)$x['b'] === 0 ? 1 : 0, 'c' => (int)($x['down'] ?? 0) >= BOSS_COMEBACK ? 1 : 0], array_slice($db['recent'] ?? [], 0, 12));
    $big = null; foreach ($db['recent'] ?? [] as $x) if (!$big || $x['r'] - $x['b'] > $big['m']) $big = ['n' => $x['name'], 'r' => (int)$x['r'], 'b' => (int)$x['b'], 'm' => $x['r'] - $x['b']];
    return ['ok' => true, 'at' => time(), 'on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'], 'wcap' => $cfg['per'] === 'day' ? $cfg['wcap'] : 0, 'elite' => $elite, 'name' => boss_name($elite),
        'g' => (int)$t['g'], 'w' => (int)$t['w'], 'paid' => (int)$t['koban'], 'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0)),
        'players' => count($db['p'] ?? []), 'days' => $days, 'diff' => $diff, 'top' => $top, 'recent' => $recent, 'big' => $big,
        'flaw' => (int)($t['flaw'] ?? 0), 'cb' => (int)($t['cb'] ?? 0), 'cbs' => (int)($t['cbs'] ?? 0)];
}

//MC 2026-10-12 the "Can you beat the Shogun?" card for X (Admin > The Shogun > Share on X). What's on it: the reward as it is
//   set now and the Shogun's record. The hash of those goes in the card's file name and in the link, so a new record or a new
//   reward gives a new address and X and Telegram fetch a fresh picture instead of the one they cached.
function boss_card_data() {
    $cfg = boss_cfg(); $db = load(BOSS_DB); $t = ($db['t'] ?? []) + ['g' => 0, 'w' => 0, 'koban' => 0];
    $d = ['on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'], 'g' => (int)$t['g'], 'w' => (int)$t['w'],
        'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0)), 'players' => count($db['p'] ?? []),
        'mv' => (int)@filemtime(DATA_DIR . '/masks/av-shogun.png')];   //MC 2026-10-13 a new mask changes the hash, so the promo card redraws with it
    $d['h'] = substr(sha1(json_encode($d) . 'bc1'), 0, 10);
    return $d;
}
function boss_card_url($d) { return 'https://shyonsol.io/shogun?v=' . $d['h']; }
