<?php
// shyonsol.io admin. Password in shy-data/config.php as 'admin_hash' (a password_hash), never in this folder.
define('SHY_API', 1);
require dirname(__DIR__) . '/api/common.php';
require dirname(__DIR__) . '/api/holders.php';
require dirname(__DIR__) . '/api/economy.php';
require dirname(__DIR__) . '/api/ideas.php';
require dirname(__DIR__) . '/api/translate.php';
require dirname(__DIR__) . '/api/xtasks.php';
require __DIR__ . '/guide.php';
require __DIR__ . '/team.php';
require __DIR__ . '/art.php';
require __DIR__ . '/twofa.php';
require __DIR__ . '/tourneys.php';
require __DIR__ . '/fairplay.php';   //MC 2026-10-10
require __DIR__ . '/deploy.php';   //MC 2026-10-13 upload a release zip, the server swaps the site
require __DIR__ . '/marketing.php';   //MC 2026-10-14 hype posts for X, posted by hand
require_once dirname(__DIR__) . '/api/opslib.php';   //MC 2026-10-11 health, backups, payment check, League recovery
require __DIR__ . '/nav.php';   //MC 2026-10-13 the admin's pages and the Needs you list

define('DAILY', DATA_DIR . '/daily.php');
if (!defined('ROOMS')) define('ROOMS', DATA_DIR . '/rooms');   //MC 2026-10-11 livelib.php may have defined it already (a warning on every admin page)
define('LOBBY', DATA_DIR . '/lobby.php');
define('BACKUPS', DATA_DIR . '/backups');
const LOGS = ['mail-errors.log' => 'Emails that could not be sent', 'x-errors.log' => 'X connections and posts that failed', 'storage-errors.log' => 'Storage problems (should stay empty)', 'holder-errors.log' => 'Wallet verification errors', 'replay-errors.log' => 'Rejected solo scores', 'shop-errors.log' => 'Shop payments that could not be matched', 'telegram-errors.log' => 'Telegram messages that failed'];
const IDLE = 8 * 3600;

header('X-Robots-Tag: noindex, nofollow');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
session_name('shyadm');
session_set_cookie_params(['lifetime' => 0, 'path' => '/admin', 'secure' => $https, 'httponly' => true, 'samesite' => 'Strict']);
session_start();

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function admin_hash() { $c = shy_config(); return (string)($c['admin_hash'] ?? ''); }
function authed() { return !empty($_SESSION['ok']) && time() - ($_SESSION['seen'] ?? 0) < IDLE; }
function csrf() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
//MC 2026-10-13 back to the page the form was on (Payouts, Prize budget...), not just its tab
function go($tab, $msg = '', $at = '') { $_SESSION['flash'] = $msg; $p = function_exists('admin_page_from_post') ? admin_page_from_post($tab) : ''; header('Location: ./?' . ($p !== '' ? 'p=' . urlencode($p) : 'tab=' . urlencode($tab)) . ($at !== '' ? '#' . rawurlencode($at) : '')); exit; }   //MC 2026-10-12 $at: open at that section
function ago($ts) {
    if (!$ts) return '';
    $d = time() - (int)$ts;
    if ($d < 90) return 'just now';
    if ($d < 5400) return round($d / 60) . 'm ago';
    if ($d < 129600) return round($d / 3600) . 'h ago';
    return round($d / 86400) . 'd ago';
}
// a player by full id, 6-letter id, name (any case) or linked wallet
define('GRANTS', DATA_DIR . '/grants.php');   // Koban and items given by hand, newest first
const GRANT_MAX = 100000;
function find_player($q, $players, $holders = []) {
    $q = trim((string)$q); $lq = strtolower($q);
    if ($q === '') return null;
    if (isset($players[$q])) return $q;
    foreach ($players as $pid => $p) if (substr($pid, 0, 6) === $lq || strtolower($p['name'] ?? '') === $lq) return $pid;
    foreach ($holders as $pid => $h) if (!empty($h['wallet']) && ($h['wallet'] === $q || substr($pid, 0, 6) === $lq || $pid === $q)) return $pid;
    return null;
}
// Profiles that connected a wallet but never finished a game have no player record yet. The admin can still
// rename or combine them; this gives them an empty record (kept off the public boards until they play).
function connected_only($players, $holders) {
    $out = [];
    foreach ($holders as $pid => $h) if (!empty($h['wallet']) && !isset($players[$pid])) $out[$pid] = blank_player($h['kh'] ?? '') + ['since' => $h['ts'] ?? ($h['chk'] ?? time()), 'virtual' => 1];
    return $out;
}
function ensure_player(&$pl, $pid) {
    if (isset($pl[$pid])) return true;
    $h = load(HOLDERS)[$pid] ?? null;
    if (empty($h['wallet'])) return false;
    $pl[$pid] = blank_player($h['kh'] ?? '');
    return true;
}
// Fold player $from into player $into: scores, Daily runs, weekly history, shop account, devices and wallet.
//MC 2026-10-11 Combine players lost a lot: finishes, card mastery, Koban Moon, Scroll+, XP boosts, the motto and
//   showcase, missions, friends, House membership, Telegram link, page stamps and visits, push subscriptions, referrals
//   and Duels all stayed on the deleted profile (the flash still said everything moved). Every store keyed by player now
//   merges, or the merge is refused up front with the reason when it can't be done cleanly (a tournament still running,
//   two different Houses). A full copy of both profiles goes to merges.php first, so a merge can be undone by hand.
define('MERGES', DATA_DIR . '/merges.php');
function merge_refuse($into, $from, $pl) {
    $nb = $pl[$from]['name'] ?? substr($from, 0, 6);
    if (function_exists('tourney_db')) foreach (tourney_db()['list'] as $t) {
        if (in_array($t['status'] ?? '', ['done', 'cancelled', 'canceled'], true)) continue;
        if (isset($t['players'][$from])) return "$nb is in the tournament \"" . ($t['name'] ?? '') . "\", which hasn't finished. Combine them after it ends.";
    }
    $H = load(DATA_DIR . '/houses.php');
    $ha = $H['m'][$into] ?? ''; $hb = $H['m'][$from] ?? '';
    if ($ha !== '' && $hb !== '' && $ha !== $hb) return "Both players are in different Houses. $nb has to leave their House first.";
    return '';
}
// rename a pid inside a list of pids or a map keyed by pid
function merge_ren_keys($m, $from, $into, $how = 'keep') {
    if (!is_array($m) || !array_key_exists($from, $m)) return $m;
    if (array_is_list($m)) return array_values(array_unique(array_map(fn($x) => $x === $from ? $into : $x, $m)));
    if (!array_key_exists($into, $m)) $m[$into] = $m[$from];
    elseif ($how === 'min' && is_numeric($m[$from])) $m[$into] = min($m[$into], $m[$from]);
    elseif ($how === 'max' && is_numeric($m[$from])) $m[$into] = max($m[$into], $m[$from]);
    unset($m[$from]);
    return $m;
}
function merge_players($into, $from) {
    $pl = load(PLAYERS);
    if (!isset($pl[$into], $pl[$from]) || $into === $from) return 'Pick two different players.';
    if ($why = merge_refuse($into, $from, $pl)) return 'Not combined. ' . $why;
    $A = $pl[$into]; $B = $pl[$from];
    $label = ($A['name'] ?? '') !== '' ? $A['name'] : 'the connected profile ' . substr($into, 0, 6);
    $notes = [];
    // the undo record: both profiles as they were, in every store
    $snap = function ($pid) { $o = [];
        foreach (['players.php', 'economy.php', 'holders.php', 'keys.php', 'friends.php', 'notices.php', 'push-subs.php', 'stamps.php', 'visits.php', 'refs.php', 'x-accounts.php'] as $f) { $v = load(DATA_DIR . '/' . $f)[$pid] ?? null; if ($v !== null) $o[$f] = $v; }
        return $o; };
    $mg = load(MERGES);
    array_unshift($mg, ['t' => time(), 'by' => me()['username'] ?? '', 'into' => $into, 'from' => $from, 'a' => $snap($into), 'b' => $snap($from)]);
    save(MERGES, array_slice($mg, 0, 200));
    // device keys first, while both profiles still exist
    $keys = load(KEYS);
    $ka = $keys[$into] ?? keys_known($into); $kb = $keys[$from] ?? keys_known($from);
    foreach (['points', 'wins', 'games', 'pvp_w', 'pvp_g', 'lpts'] as $k) $A[$k] = ($A[$k] ?? 0) + ($B[$k] ?? 0);
    foreach (['best', 'badges', 'last'] as $k) $A[$k] = max($A[$k] ?? 0, $B[$k] ?? 0);
    $A['since'] = min($A['since'] ?? time(), $B['since'] ?? time());
    $A['holder'] = !empty($A['holder']) || !empty($B['holder']);
    if (empty($A['avatar']) && !empty($B['avatar'])) $A['avatar'] = $B['avatar'];
    foreach (['tz', 'lsh', 'hideon'] as $k) if (empty($A[$k]) && !empty($B[$k])) $A[$k] = $B[$k];
    // Ranked: the better record of the same season (adding two ladders up could skip a tier nobody earned)
    if (!empty($B['rk']) && (empty($A['rk']) || ($B['rk']['s'] ?? 0) > ($A['rk']['s'] ?? 0) || (($B['rk']['s'] ?? 0) === ($A['rk']['s'] ?? 0) && ($B['rk']['rp'] ?? 0) > ($A['rk']['rp'] ?? 0)))) $A['rk'] = $B['rk'];
    if (!empty($B['rkh'])) $A['rkh'] = array_merge($A['rkh'] ?? [], $B['rkh']);
    if (!empty($B['lgd']) && (empty($A['lgd']) || ($B['lgd']['d'] ?? '') > ($A['lgd']['d'] ?? ''))) $A['lgd'] = $B['lgd'];
    elseif (!empty($B['lgd']) && ($B['lgd']['d'] ?? '') === ($A['lgd']['d'] ?? '')) $A['lgd']['n'] = max((int)$A['lgd']['n'], (int)$B['lgd']['n']);
    if (!empty($B['lgp']) && (empty($A['lgp']) || ($B['lgp']['d'] ?? '') > ($A['lgp']['d'] ?? ''))) $A['lgp'] = $B['lgp'];
    elseif (!empty($B['lgp']) && ($B['lgp']['d'] ?? '') === ($A['lgp']['d'] ?? '')) foreach ((array)($B['lgp']['c'] ?? []) as $o => $n) $A['lgp']['c'][$o] = ($A['lgp']['c'][$o] ?? 0) + $n;
    // a linked X account follows the player
    $xf = DATA_DIR . '/x-accounts.php'; $xa = load($xf);
    if (empty($A['xu']) && !empty($B['xu'])) {
        $A['xu'] = $B['xu'];
        if (isset($xa[$from]) && !isset($xa[$into])) { $xa[$into] = $xa[$from]; unset($xa[$from]); save($xf, $xa); }
    } elseif (isset($xa[$from])) { unset($xa[$from]); save($xf, $xa); $notes[] = 'its X account was unlinked (the kept profile has its own)'; }
    // a connected profile that never played takes the other profile's name
    if (($A['name'] ?? '') === '' && ($B['name'] ?? '') !== '') { $A['name'] = $B['name']; foreach (['nlock', 'nprof'] as $k) if (!empty($B[$k])) $A[$k] = $B[$k]; }
    if (!empty($B['hist'])) { $A['hist'] = array_merge($A['hist'] ?? [], $B['hist']); usort($A['hist'], fn($x, $y) => $y['t'] <=> $x['t']); $A['hist'] = array_slice($A['hist'], 0, 25); }   //MC 2026-10-11 sorted before the cut, so the newest games stay
    // this week's points, League and Season points add up when they're for the same period
    $wk = week_key();
    if (($B['wk'] ?? '') === $wk) { if (($A['wk'] ?? '') !== $wk) { $A['wk'] = $wk; $A['wpts'] = 0; } $A['wpts'] += $B['wpts'] ?? 0; }
    foreach (['lg' => 'wk', 'sg' => 's'] as $k => $per) {
        if (empty($B[$k])) continue;
        if (empty($A[$k]) || $A[$k][$per] !== $B[$k][$per]) { if (empty($A[$k]) || $B[$k][$per] > $A[$k][$per]) $A[$k] = $B[$k]; }
        else { $A[$k]['pts'] += $B[$k]['pts']; $A[$k]['n'] += $B[$k]['n']; }
    }
    $pl[$into] = $A; unset($pl[$from]);
    save(PLAYERS, $pl);
    // Daily: keep the better run of each day
    $d = load(DAILY);
    foreach ($d as $day => $rows) if (isset($rows[$from])) {
        if (!isset($rows[$into]) || $rows[$from]['points'] > $rows[$into]['points']) $d[$day][$into] = $rows[$from];
        unset($d[$day][$from]);
    }
    save(DAILY, $d);
    // filed weeks
    $w = load(WEEKS);
    foreach ($w as $k => $wkr) {
        $rows = []; $seen = null;
        foreach ($wkr['rows'] as $r) { if ($r['pid'] === $from) $r['pid'] = $into; if (isset($rows[$r['pid']])) $rows[$r['pid']]['pts'] += $r['pts']; else $rows[$r['pid']] = $r; }
        $rows = array_values($rows); usort($rows, fn($x, $y) => $y['pts'] <=> $x['pts']);
        $w[$k]['rows'] = $rows;
    }
    if ($w) save(WEEKS, $w);
    // shop account: every field
    $eco = load(ECO);
    if (isset($eco[$from])) {
        $a = eco_get($eco, $into); $b = eco_get($eco, $from);
        if ($b['koban']) eco_credit($a, $b['koban'], 'Merged account');
        foreach ($b['items'] as $it => $ts) if (!isset($a['items'][$it])) $a['items'][$it] = $ts;
        foreach ($b['once'] as $o => $ts) $a['once'][$o] = $ts;
        foreach ($b['eq'] as $slot => $id) if (empty($a['eq'][$slot])) $a['eq'][$slot] = $id;   // fill empty slots only
        if ($a['sc']['s'] === $b['sc']['s']) {
            $a['sc']['xp'] = max($a['sc']['xp'], $b['sc']['xp']); $a['sc']['prem'] = $a['sc']['prem'] || $b['sc']['prem'];
            $a['sc']['plus'] = !empty($a['sc']['plus']) || !empty($b['sc']['plus']);
            if (!empty($a['sc']['hp']) || !empty($b['sc']['hp'])) $a['sc']['hp'] = 1;
            $a['sc']['cf'] = array_values(array_unique(array_merge($a['sc']['cf'], $b['sc']['cf']))); $a['sc']['cp'] = array_values(array_unique(array_merge($a['sc']['cp'], $b['sc']['cp'])));
        }
        if (($b['st']['n'] ?? 0) > ($a['st']['n'] ?? 0)) $a['st'] = $b['st'];
        if (($b['xd']['d'] ?? '') === ($a['xd']['d'] ?? '')) $a['xd']['solo'] = max((int)$a['xd']['solo'], (int)$b['xd']['solo']);
        $a['saver'] = min(2, (int)($a['saver'] ?? 0) + (int)($b['saver'] ?? 0));
        $a['rrb'] = (int)($a['rrb'] ?? 0) + (int)($b['rrb'] ?? 0); if (!$a['rrb']) unset($a['rrb']);
        $a['spent_usd'] = round(($a['spent_usd'] ?? 0) + ($b['spent_usd'] ?? 0), 2);
        $a['since'] = min((int)$a['since'], (int)$b['since']);
        // card finishes: every one owned on either; the worn one stays unless the card had none
        foreach ((array)$b['vf'] as $c => $fs) foreach ((array)$fs as $f => $v) if ($v) $a['vf'][$c][$f] = $v;
        foreach ((array)$b['veq'] as $c => $f) if (empty($a['veq'][$c])) $a['veq'][$c] = $f;
        // mastery: the higher count and the higher level already collected (no rewards paid twice)
        foreach ((array)$b['cm'] as $c => $n) $a['cm'][$c] = max((int)($a['cm'][$c] ?? 0), (int)$n);
        foreach ((array)$b['cml'] as $c => $n) $a['cml'][$c] = max((int)($a['cml'][$c] ?? 0), (int)$n);
        $a['cl'] = array_values(array_unique(array_merge((array)$a['cl'], (array)$b['cl'])));
        foreach ((array)$b['boost'] as $k => $t) $a['boost'][$k] = max((int)($a['boost'][$k] ?? 0), (int)$t);
        foreach ((array)$b['fp'] as $k => $t) if (!isset($a['fp'][$k])) $a['fp'][$k] = $t;
        foreach ((array)($b['rkp'] ?? []) as $k => $t) if (!isset($a['rkp'][$k])) $a['rkp'][$k] = $t;
        if ((int)($b['moon'] ?? 0) > (int)($a['moon'] ?? 0)) $a['moon'] = (int)$b['moon'];
        foreach (['gift', 'stip'] as $k) if (($b[$k] ?? '') > ($a[$k] ?? '')) $a[$k] = $b[$k];   // a day or week already collected stays collected
        if (empty($a['pg']['motto']) && !empty($b['pg']['motto'])) $a['pg']['motto'] = $b['pg']['motto'];
        if (empty($a['pg']['show']) && !empty($b['pg']['show'])) $a['pg']['show'] = $b['pg']['show'];
        if (empty($a['xh']) && !empty($b['xh'])) $a['xh'] = $b['xh'];
        // missions: the same week keeps the kept profile's board; the Bounty Board stays open if either had it
        if (!empty($b['ms'])) { if (empty($a['ms']) || ($b['ms']['wk'] ?? '') > ($a['ms']['wk'] ?? '')) $a['ms'] = $b['ms']; elseif (($b['ms']['wk'] ?? '') === ($a['ms']['wk'] ?? '') && !empty($b['ms']['b'])) $a['ms']['b'] = 1; }
        if (!empty($b['xt']) && (empty($a['xt']) || ($b['xt']['d'] ?? '') > ($a['xt']['d'] ?? ''))) $a['xt'] = $b['xt'];
        elseif (!empty($b['xt']) && ($b['xt']['d'] ?? '') === ($a['xt']['d'] ?? '')) $a['xt']['done'] = (array)($a['xt']['done'] ?? []) + (array)($b['xt']['done'] ?? []);
        $a['ledger'] = array_slice(array_values($a['ledger']), 0, 60);
        $eco[$into] = $a; unset($eco[$from]);
        save(ECO, $eco);
    }
    // orders, payment help, swaps and ideas follow the account
    foreach ([ORDERS, DATA_DIR . '/pay-help.php', DATA_DIR . '/swaps.php', DATA_DIR . '/ideas.php'] as $f) {
        $all = load($f); $ch = false;
        foreach ($all as $id => $o) if (is_array($o) && ($o['pid'] ?? '') === $from) { $all[$id]['pid'] = $into; $ch = true; }
        if ($ch) save($f, $all);
    }
    // every device signed in as either player now signs in as the merged one
    $keys = load(KEYS);
    $keys[$into] = array_slice(array_values(array_unique(array_merge($ka, $kb))), -12); unset($keys[$from]);
    save(KEYS, $keys);
    // wallet: keep the merged player's own, or take the other one's if it had none
    $h = load(HOLDERS);
    if (!empty($h[$from]['wallet']) && empty($h[$into]['wallet'])) $h[$into] = $h[$from];
    elseif (!empty($h[$from]['wallet']) && $h[$from]['wallet'] !== ($h[$into]['wallet'] ?? '')) $notes[] = 'its wallet ' . short_w($h[$from]['wallet']) . ' was unlinked (the kept profile has its own; it can be linked again)';
    unset($h[$from]);
    save(HOLDERS, $h);
    // friends: lists joined, and everyone who had the old profile as a friend now has the kept one
    $fr = load(DATA_DIR . '/friends.php');
    if ($fr) {
        $fa = ($fr[$into] ?? []) + ['f' => [], 'in' => [], 'out' => [], 'bl' => []]; $fb = ($fr[$from] ?? []) + ['f' => [], 'in' => [], 'out' => [], 'bl' => []];
        foreach (['f', 'in', 'out', 'bl'] as $k) {
            if (array_is_list((array)$fa[$k]) && array_is_list((array)$fb[$k])) $fa[$k] = array_values(array_unique(array_merge((array)$fa[$k], (array)$fb[$k])));
            else $fa[$k] = (array)$fa[$k] + (array)$fb[$k];
        }
        unset($fr[$from]);
        if (isset($fr[$into]) || array_filter([$fa['f'], $fa['in'], $fa['out'], $fa['bl']])) $fr[$into] = $fa;
        foreach ($fr as $p => $r) foreach (['f', 'in', 'out', 'bl'] as $k) if (isset($r[$k])) $fr[$p][$k] = merge_ren_keys($r[$k], $from, $into, 'min');
        foreach (['f', 'in', 'out', 'bl'] as $k) if (isset($fr[$into][$k])) { $m = $fr[$into][$k]; if (array_is_list($m)) $m = array_values(array_diff($m, [$into])); else unset($m[$into]); $fr[$into][$k] = $m; }
        save(DATA_DIR . '/friends.php', $fr);
    }
    $no = load(DATA_DIR . '/notices.php');
    if (isset($no[$from])) { $l = array_merge($no[$into] ?? [], $no[$from]); usort($l, fn($x, $y) => ($y['ts'] ?? 0) <=> ($x['ts'] ?? 0)); $no[$into] = array_slice($l, 0, 30); unset($no[$from]); save(DATA_DIR . '/notices.php', $no); }
    $pr = load(DATA_DIR . '/presence.php'); if (isset($pr[$from])) { unset($pr[$from]); save(DATA_DIR . '/presence.php', $pr); }
    $ps = load(DATA_DIR . '/push-subs.php'); if (isset($ps[$from])) { $ps[$into] = (array)($ps[$into] ?? []) + (array)$ps[$from]; unset($ps[$from]); save(DATA_DIR . '/push-subs.php', $ps); }
    // page stamps and visits add up
    $st = load(DATA_DIR . '/stamps.php');
    if (isset($st[$from])) { $x = $st[$into] ?? ['c' => [], 'by' => []]; foreach ((array)$st[$from]['c'] as $k => $n) $x['c'][$k] = (int)($x['c'][$k] ?? 0) + (int)$n; $x['by'] = (array)$x['by'] + (array)$st[$from]['by']; unset($x['by'][$into]); $st[$into] = $x; unset($st[$from]); save(DATA_DIR . '/stamps.php', $st); }
    $vi = load(DATA_DIR . '/visits.php');
    if (isset($vi[$from])) { $x = $vi[$into] ?? ['n' => 0, 'd' => '', 'v' => []]; $x['n'] = (int)$x['n'] + (int)$vi[$from]['n']; if (($vi[$from]['d'] ?? '') === $x['d']) $x['v'] = (array)$x['v'] + (array)$vi[$from]['v']; elseif (($vi[$from]['d'] ?? '') > $x['d']) { $x['d'] = $vi[$from]['d']; $x['v'] = $vi[$from]['v']; } $vi[$into] = $x; unset($vi[$from]); save(DATA_DIR . '/visits.php', $vi); }
    // referrals: who invited them, and everyone they invited
    $rf = load(REFS);
    if ($rf) {
        if (isset($rf[$from]) && !isset($rf[$into]) && ($rf[$from]['by'] ?? '') !== $into) $rf[$into] = $rf[$from];
        unset($rf[$from]);
        foreach ($rf as $p => $r) if ($p !== '_wk' && ($r['by'] ?? '') === $from) $rf[$p]['by'] = $into;
        if (isset($rf['_wk'][$from])) { foreach ($rf['_wk'][$from] as $k => $n) $rf['_wk'][$into][$k] = (int)($rf['_wk'][$into][$k] ?? 0) + (int)$n; unset($rf['_wk'][$from]); }
        save(REFS, $rf);
    }
    // House: the membership (and ownership or officer role) moves across when the kept profile has none
    $H = load(DATA_DIR . '/houses.php'); $hb = $H['m'][$from] ?? '';
    if ($hb !== '') {
        if (!isset($H['m'][$into])) $H['m'][$into] = $hb;
        unset($H['m'][$from]);
        if (isset($H['h'][$hb])) {
            $H['h'][$hb]['members'] = merge_ren_keys($H['h'][$hb]['members'] ?? [], $from, $into, 'min');
            $H['h'][$hb]['officers'] = merge_ren_keys($H['h'][$hb]['officers'] ?? [], $from, $into);
            if (($H['h'][$hb]['owner'] ?? '') === $from) { $H['h'][$hb]['owner'] = $into; unset($H['h'][$hb]['officers'][$into]); }
            if (isset($H['h'][$hb]['reqs'])) $H['h'][$hb]['reqs'] = merge_ren_keys($H['h'][$hb]['reqs'], $from, $into);
        }
    }
    if (isset($H['cool'][$from])) $H['cool'] = merge_ren_keys($H['cool'], $from, $into, 'max');
    if ($hb !== '' || isset($H['cool'][$into])) save(DATA_DIR . '/houses.php', $H);
    // Telegram: the link moves across when the kept profile has none
    $tl = load(DATA_DIR . '/tg-links.php');
    if (isset($tl['p'][$from])) {
        $uid = $tl['p'][$from]; unset($tl['p'][$from]);
        if (!isset($tl['p'][$into])) { $tl['p'][$into] = $uid; if (isset($tl['u'][$uid])) $tl['u'][$uid]['pid'] = $into; }
        else { if (($tl['u'][$uid]['pid'] ?? '') === $from && (string)$tl['p'][$into] !== (string)$uid) { unset($tl['u'][$uid]); $notes[] = 'its Telegram link was dropped (the kept profile has its own)'; } elseif (isset($tl['u'][$uid])) $tl['u'][$uid]['pid'] = $into; }
        save(DATA_DIR . '/tg-links.php', $tl);
    }
    // Duels and the 15 Club point at the kept profile
    $du = load(DATA_DIR . '/duels.php'); $ch = false;
    foreach ($du as $id => $x) foreach (['a', 'b'] as $k) if (($x[$k] ?? '') === $from) { $du[$id][$k] = $into; $ch = true; }
    if ($ch) save(DATA_DIR . '/duels.php', $du);
    $bd = load(DATA_DIR . '/bounty.php'); $ch = false;
    foreach ($bd['m'] ?? [] as $m => $x) if (($x['pid'] ?? '') === $from) { $bd['m'][$m]['pid'] = $into; $ch = true; }
    foreach ($bd['best'] ?? [] as $m => $rows) if (isset($rows[$from])) { if (!isset($rows[$into]) || ($rows[$from]['r'] ?? 0) > ($rows[$into]['r'] ?? 0)) $bd['best'][$m][$into] = $rows[$from]; unset($bd['best'][$m][$from]); $ch = true; }
    if ($ch) save(DATA_DIR . '/bounty.php', $bd);
    $xt = load(DATA_DIR . '/x-tasks.php'); $ch = false;
    foreach ($xt['h'] ?? [] as $hk => $p) if ($p === $from) { $xt['h'][$hk] = $into; $ch = true; }
    if ($ch) save(DATA_DIR . '/x-tasks.php', $xt);
    return 'Merged ' . ($B['name'] ?? '') . ' into ' . $label . ($label !== $A['name'] ? ', which now goes by ' . $A['name'] : '') . '. Points, Daily runs, history, Koban, items, finishes, mastery, Scroll, boosts, page, friends, House, Telegram and devices moved across.' . ($notes ? ' Note: ' . implode('; ', $notes) . '.' : '');
}
function wallet_of($pid, $holders) { return $holders[$pid]['wallet'] ?? ''; }
function short_w($w) { return $w ? substr($w, 0, 4) . '...' . substr($w, -4) : ''; }

// ---------- login / logout ----------
$err = '';
if (($_POST['do'] ?? '') === 'login') { unset($_SESSION['tfa']); $err = team_login((string)($_POST['login'] ?? ''), (string)($_POST['pw'] ?? '')); }
if (($_POST['do'] ?? '') === 'login-cancel') unset($_SESSION['tfa']);
if (($_POST['do'] ?? '') === 'login-2fa') { $err = tfa_login_step((string)($_POST['code'] ?? '')); if (tfa_pending()) { page_tfa($err); exit; } }
if (!authed() && tfa_pending() && ($_POST['do'] ?? '') !== 'login-cancel') { page_tfa(''); exit; }
if (authed()) $ME = load_me();
if (($_POST['do'] ?? '') === 'logout' && authed() && hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) { if ($ME) audit('logout'); $_SESSION = []; session_destroy(); header('Location: ./'); exit; }

if (!authed() || !$ME) {
    // signed out, timed out, switched off, or the password was changed somewhere else
    if (authed() && !$ME) $err = 'You were signed out. Sign in again.';
    $_SESSION = []; page_login($err); exit;
}
$_SESSION['seen'] = time();
// a new admin picks their own password before anything else
if (!empty($ME['must_change']) && !isset($_GET['api'])) {
    $doNow = (string)($_POST['do'] ?? '');
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $doNow !== 'account-save') go('account', 'Pick your own password first.');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && ($_GET['tab'] ?? '') !== 'account') { header('Location: ./?tab=account'); exit; }
}
// owners and anyone who can send payouts set up two-step sign-in before anything else
$NEED_TFA = empty($ME['key']) && empty($ME['must_change']) && tfa_required($ME) && empty($ME['tfa']);
if ($NEED_TFA) {
    if (isset($_GET['api'])) { header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => 'Set up two-step sign-in in My account first.']); exit; }
    $doNow = (string)($_POST['do'] ?? '');
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && strpos($doNow, 'tfa-') !== 0 && $doNow !== 'account-save' && $doNow !== 'logout') go('account', 'Set up two-step sign-in first. Your role needs it.');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' && ($_GET['tab'] ?? '') !== 'account') { header('Location: ./?tab=account#tfa'); exit; }
}

if (isset($_GET['art_src'])) art_serve_src();

// ---------- JSON calls from the payout sender ----------
if (isset($_GET['api'])) {
    header('Content-Type: application/json');
    $b = json_decode(file_get_contents('php://input'), true) ?: [];
    if (!hash_equals(csrf(), (string)($b['csrf'] ?? ''))) out(['ok' => false, 'error' => 'Session expired. Reload the page.'], 403);
    if (!can('payouts', 2)) out(['ok' => false, 'error' => 'You can view payouts but not send them.'], 403);
    $act = (string)($b['act'] ?? '');
    if ($act === 'rpc') {
        $m = (string)($b['method'] ?? '');
        if ($m === 'getLatestBlockhash') {
            $per = (string)($b['period'] ?? '');
            $blk = payout_block(with_lock(fn() => load(REWARDS)), $per);
            if ($blk) out(['ok' => false, 'error' => $blk === 'changed' ? 'The list changed after it was approved. It needs approving again.' : 'This payout needs a second admin to approve it first.'], 403);
            out(['ok' => true, 'result' => rpc('getLatestBlockhash', [['commitment' => 'confirmed']])]);
        }
        if ($m === 'getAccountInfo' && valid_wallet((string)($b['addr'] ?? ''))) out(['ok' => true, 'result' => rpc('getAccountInfo', [$b['addr'], ['encoding' => 'base64']])]);
        out(['ok' => false, 'error' => 'not allowed'], 403);
    }
    if ($act === 'payout-sent') {
        // the admin's wallet sent a batch: check every transfer in it on chain before marking anyone paid
        $period = (string)($b['period'] ?? ''); $sig = (string)($b['sig'] ?? '');
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) out(['ok' => false, 'error' => 'bad signature'], 400);
        //MC 2026-10-11 the signature is put on hold the moment it arrives, the same way Pay everything owed does it
        //   (payall_pending). Before, a batch Solana hadn't confirmed after 12 s got a 202 and nothing was written down, so
        //   after the reload Send and Pay everything owed both offered the same prizes again and could pay them twice.
        //   Every open priced row of the list is held (the amount check in payall_mark only marks the rows this
        //   transaction really paid); the hold is settled here, or by payall-check the next time Rewards opens.
        $items = with_lock(function () use ($period, $sig) {
            $rw = load(REWARDS);
            $ref = &payout_list($rw, $period);
            if ($ref === null) return null;
            $items = [];
            foreach ($ref as $i => $w) if (empty($w['sig']) && empty($w['skip']) && !empty($w['units'])) $items[] = ['k' => 'list', 'period' => $period, 'i' => $i, 'label' => payout_label($period), 'name' => $w['name'] ?? ''];
            unset($ref);
            if (!isset($rw['payall_pending'][$sig])) { $rw['payall_pending'][$sig] = ['items' => $items, 'burns' => [], 'at' => time(), 'by' => me()['username'], 'list' => $period]; save(REWARDS, $rw); }
            return $rw['payall_pending'][$sig]['items'];
        });
        if ($items === null) out(['ok' => false, 'error' => 'That prize list is gone. Reload the page.'], 404);
        $tx = null;
        for ($i = 0; $i < 6 && !$tx; $i++) { $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]); if (!$tx) sleep(2); }
        if (!$tx) out(['ok' => false, 'wait' => true, 'error' => 'Sent, but Solana hasn\'t confirmed it yet. Those prizes stay on hold and are checked again each time you open Rewards.'], 202);
        if (!empty($tx['meta']['err'])) { with_lock(fn() => payall_unpend($sig)); out(['ok' => false, 'error' => 'That transaction failed on Solana, so nothing was paid. You can send again.'], 409); }
        $r = with_lock(fn() => payall_mark($tx, $sig, $items, []));
        if (($r['error'] ?? '') === 'already counted') {
            // settled a moment ago by payall-check (another tab): that's a success, not a second payment
            $mine = array_filter(payout_rows_by_sig($sig)['paid'], fn($x) => ($x['period'] ?? '') === $period);
            if ($mine) out(['ok' => true, 'paid' => count($mine)]);
            out(['ok' => false, 'error' => 'That transaction was already counted for a payout.'], 409);
        }
        $n = (int)$r['paid'];
        audit('payout-sent', ['period' => $period, 'sig' => substr($sig, 0, 20), 'paid' => $n]);
        $paidRows = $_SESSION['payall'][$sig]['paid'] ?? [];   // payall_mark already sent the confirmation email
        //MC 2026-10-10 the single-list payout posts to Telegram too (pinned), like Pay everything owed. It never did.
        if ($paidRows) tg_payout(payout_tg_html($paidRows, 0, [$sig]), 'payall:' . $sig);
        out(['ok' => true, 'paid' => $n]);
    }
    //MC 2026-10-10 one button for everything owed: every open prize list, the 15 Club bounty and any burn still owed from
    //   the shop. 'payall-plan' prices what isn't priced yet and returns the transfers; the browser builds the transactions,
    //   the marketing wallet signs them all in one Phantom approval, 'send' passes each to Solana, 'payall-sent' checks
    //   each one on chain before anyone is marked paid, and 'payall-done' posts the summary to Telegram and hands back
    //   the X post. No key is kept here: nothing moves without the wallet's own approval.
    if ($act === 'payall-plan') {
        $px = price_usd(SHY_MINT); $dec = mint_decimals(SHY_MINT);
        if (!$px || $dec === null) out(['ok' => false, 'error' => "Couldn't get the \$SHY price from the market. Try again in a minute."], 502);
        out(['ok' => true] + with_lock(fn() => payall_plan($px, $dec)));
    }
    if ($act === 'send') {
        $raw = (string)($b['tx'] ?? '');
        if ($raw === '' || strlen($raw) > 2000 || base64_decode($raw, true) === false) out(['ok' => false, 'error' => 'bad transaction'], 400);
        $r = http_json(rpc_url(), json_encode(['jsonrpc' => '2.0', 'id' => 1, 'method' => 'sendTransaction', 'params' => [$raw, ['encoding' => 'base64', 'preflightCommitment' => 'confirmed', 'maxRetries' => 5]]]), ['Content-Type: application/json'], 20);
        if (function_exists('rpc_mock')) $r = ['result' => rpc_mock('sendTransaction', [$raw])];
        if (!empty($r['result'])) out(['ok' => true, 'sig' => $r['result']]);
        //MC 2026-10-10 say why, in full: the RPC's message and the last program log line (usually the real reason)
        $logs = (array)($r['error']['data']['logs'] ?? []); $last = '';
        foreach (array_reverse($logs) as $l) if (stripos($l, 'error') !== false || stripos($l, 'insufficient') !== false || stripos($l, 'failed') !== false) { $last = $l; break; }
        out(['ok' => false, 'error' => 'Solana refused it: ' . mb_substr((string)($r['error']['message'] ?? 'no answer from the RPC'), 0, 240) . ($last !== '' ? ' (' . mb_substr($last, 0, 200) . ')' : '')], 502);
    }
    //MC 2026-10-10 the moment Phantom hands back a signature it is written down here, so those prizes leave the plan until
    //   Solana says yes or no. Nothing can be paid twice by pressing the button again while a batch is still landing.
    if ($act === 'payall-pending') {
        $sig = (string)($b['sig'] ?? '');
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) out(['ok' => false, 'error' => 'bad signature'], 400);
        with_lock(function () use ($sig, $b) {
            $rw = load(REWARDS);
            $rw['payall_pending'][$sig] = ['items' => array_values(array_map(fn($it) => array_intersect_key((array)$it, array_flip(['k', 'period', 'i', 'm', 'label', 'name'])), (array)($b['items'] ?? []))), 'burns' => array_values(array_map('strval', (array)($b['burns'] ?? []))), 'at' => time(), 'by' => me()['username']];
            save(REWARDS, $rw);
        });
        out(['ok' => true]);
    }
    if ($act === 'payall-sent') {
        $sig = (string)($b['sig'] ?? '');
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) out(['ok' => false, 'error' => 'bad signature'], 400);
        $tx = null;
        for ($i = 0; $i < 10 && !$tx; $i++) { $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]); if (!$tx) sleep(2); }
        if (!$tx) out(['ok' => false, 'wait' => true, 'error' => 'Sent, but Solana hasn\'t confirmed it yet. It stays on hold and is checked again each time you open Rewards.'], 202);
        if (!empty($tx['meta']['err'])) { with_lock(fn() => payall_unpend($sig)); out(['ok' => false, 'error' => 'That transaction failed on Solana, so nothing was paid. You can send again.'], 409); }
        $r = with_lock(fn() => payall_mark($tx, $sig, (array)($b['items'] ?? []), (array)($b['burns'] ?? [])));
        audit('payall-sent', ['sig' => substr($sig, 0, 20), 'paid' => $r['paid'], 'burned' => $r['burned']]);
        out(['ok' => true] + $r);
    }
    //MC 2026-10-10 Rewards opened: settle every batch still on hold (paid, failed, or never landed)
    if ($act === 'payall-check') {
        $pend = with_lock(fn() => load(REWARDS)['payall_pending'] ?? []); $res = [];
        foreach ($pend as $sig => $p) {
            $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]);
            if ($tx && empty($tx['meta']['err'])) { $r = with_lock(fn() => payall_mark($tx, $sig, $p['items'], $p['burns'])); $res[] = ['sig' => $sig, 'state' => 'paid', 'paid' => $r['paid'], 'burned' => $r['burned']]; }
            elseif ($tx) { with_lock(fn() => payall_unpend($sig)); $res[] = ['sig' => $sig, 'state' => 'failed']; }
            elseif (time() - (int)$p['at'] > 180) { with_lock(fn() => payall_unpend($sig)); $res[] = ['sig' => $sig, 'state' => 'dropped']; }   // its blockhash is long gone: it can never land
            else $res[] = ['sig' => $sig, 'state' => 'waiting'];
        }
        out(['ok' => true, 'runs' => $res]);
    }
    //MC 2026-10-10 a payout sent some other way (or one this page lost track of): paste its signature and every open prize
    //   and owed burn that it really paid is marked paid, checked on chain the same way
    if ($act === 'payall-settle') {
        $sig = trim((string)($b['sig'] ?? ''));
        if (preg_match('~/tx/([1-9A-HJ-NP-Za-km-z]{60,100})~', $sig, $mm)) $sig = $mm[1];
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) out(['ok' => false, 'error' => 'That isn\'t a Solana transaction signature or Solscan link.'], 400);
        $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]);
        if (!$tx) out(['ok' => false, 'error' => 'Solana doesn\'t know that transaction (yet). Check the signature, or try again in a minute.'], 404);
        if (!empty($tx['meta']['err'])) out(['ok' => false, 'error' => 'That transaction failed on Solana, so it paid nothing.'], 409);
        $r = with_lock(function () use ($tx, $sig) { $o = payall_open(); return payall_mark($tx, $sig, $o['items'], $o['burns']); });
        audit('payall-settle', ['sig' => substr($sig, 0, 20), 'paid' => $r['paid'], 'burned' => $r['burned']]);
        out(['ok' => true] + $r);
    }
    if ($act === 'payall-done') {
        $sigs = array_values(array_filter((array)($b['sigs'] ?? []), fn($s) => is_string($s) && preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $s)));
        out(['ok' => true] + payall_announce($sigs));
    }
    out(['ok' => false, 'error' => 'unknown'], 400);
}
//MC 2026-10-11 the plain-words cards at the top of Players, Rewards and Telegram: what's going on, in sentences, before the tables
function glance($cards) {
    echo '<div class="glance">';
    foreach ($cards as $c) echo '<div class="' . h($c[2] ?? '') . '"><b>' . $c[0] . '</b><span>' . $c[1] . '</span></div>';
    echo '</div>';
}
function ago_short($t) { if (!$t) return 'never'; $d = time() - $t; return $d < 90 ? 'just now' : ($d < 5400 ? round($d / 60) . ' min ago' : ($d < 129600 ? round($d / 3600) . ' h ago' : round($d / 86400) . ' days ago')); }
// every list with someone still to pay: [period, label, &list]
function payall_lists(&$rw) {
    $out = [];
    foreach ($rw['weeks'] ?? [] as $wk => $w) foreach (['league' => 'Weekly League', 'cup' => 'Holder Cup'] as $k => $lab) $out[] = ['week:' . $wk . ':' . $k, $lab . ', week ' . (int)explode('-', $wk)[1]];
    foreach ($rw['seasons'] ?? [] as $sn => $se) $out[] = ['season:' . $sn, 'Season ' . $sn . ' Championship'];
    foreach ($rw['tourneys'] ?? [] as $tid => $tx) $out[] = ['tourney:' . $tid, (string)($tx['label'] ?? 'Tournament')];   //MC 2026-10-13 paid events: pools and refunds
    return $out;
}
//MC 2026-10-10 batches sent but not settled yet: what's in them, as keys ("l:period:i", "b:2026-10", "o:orderid")
function payall_held($rw) {
    $h = [];
    foreach ($rw['payall_pending'] ?? [] as $p) {
        foreach ($p['items'] ?? [] as $it) $h[($it['k'] ?? '') === 'bounty' ? 'b:' . ($it['m'] ?? '') : 'l:' . ($it['period'] ?? '') . ':' . (int)($it['i'] ?? -1)] = 1;
        foreach ($p['burns'] ?? [] as $o) $h['o:' . $o] = 1;
    }
    return $h;
}
function payall_unpend($sig) { $rw = load(REWARDS); if (isset($rw['payall_pending'][$sig])) { unset($rw['payall_pending'][$sig]); save(REWARDS, $rw); } }
// every prize that is priced and still open, and every burn still owed (for settling a pasted transaction)
function payall_open() {
    $rw = load(REWARDS); $items = [];
    foreach (payall_lists($rw) as [$period, $label]) {
        $ref = &payout_list($rw, $period);
        if ($ref) foreach ($ref as $i => $w) if (empty($w['sig']) && empty($w['skip']) && !empty($w['units']) && !empty($w['wallet'])) $items[] = ['k' => 'list', 'period' => $period, 'i' => $i];
        unset($ref);
    }
    foreach (bounty_db()['m'] as $m => $bw) if (empty($bw['paid']) && !empty($bw['units'])) $items[] = ['k' => 'bounty', 'm' => $m];
    $burns = [];
    foreach (load(ORDERS) as $id => $o) if (($o['status'] ?? '') === 'paid' && !empty($o['burn_owed']) && empty($o['burn_sig'])) $burns[] = $id;
    return ['items' => $items, 'burns' => $burns];
}
// what the button will send, pricing anything not priced yet at today's price (inside with_lock)
function payall_plan($px, $dec) {
    $rw = load(REWARDS); $holders = load(HOLDERS); $items = []; $skipped = []; $changed = false; $held = payall_held($rw);
    foreach (payall_lists($rw) as [$period, $label]) {
        $ref = &payout_list($rw, $period);
        if (!$ref) { unset($ref); continue; }
        $open = array_filter($ref, fn($w) => empty($w['sig']) && empty($w['skip']));
        if (!$open) { unset($ref); continue; }
        $priced = false;
        foreach ($ref as &$w) {
            if (!empty($w['sig']) || !empty($w['skip']) || !empty($w['units'])) continue;
            $shy = floor($w['usd'] / $px); $w['shy'] = $shy; $w['units'] = sprintf('%.0f', $shy * pow(10, $dec)); $w['px'] = $px; $w['dec'] = $dec; $priced = $changed = true;
        }
        unset($w);
        if ($priced) $rw['appr'][$period] = ['prep' => me()['username'], 'prepId' => me()['id'], 'at' => time()];
        if ($blk = payout_block($rw, $period)) { $skipped[] = ['label' => $label, 'why' => $blk === 'changed' ? 'changed after it was approved: needs approving again' : 'over $' . number_format((float)eco_settings()['payout_approve_usd']) . ', so a second admin approves it first']; unset($ref); continue; }
        foreach ($ref as $i => $w) {
            if (!empty($w['sig']) || !empty($w['skip'])) continue;
            if (empty($w['wallet']) || !valid_wallet($w['wallet'])) { $skipped[] = ['label' => $label . ': ' . ($w['name'] ?? ''), 'why' => 'no wallet connected']; continue; }
            if (isset($held['l:' . $period . ':' . $i])) { $skipped[] = ['label' => $label . ': ' . ($w['name'] ?? ''), 'why' => 'already sent, waiting for Solana to confirm it', 'held' => 1]; continue; }
            $items[] = ['k' => 'list', 'period' => $period, 'i' => $i, 'label' => $label, 'name' => $w['name'] ?? '', 'pid' => $w['pid'] ?? '', 'wallet' => $w['wallet'], 'units' => (string)$w['units'], 'dec' => (int)($w['dec'] ?? $dec), 'usd' => (float)$w['usd'], 'shy' => (float)($w['shy'] ?? 0)];
        }
        unset($ref);
    }
    if ($changed) save(REWARDS, $rw);
    // the 15 Club: every month won and not paid yet, priced from bounty_usd
    $d = bounty_db(); $bchg = false; $busd = (float)eco_settings()['bounty_usd'];
    foreach ($d['m'] as $m => $bw) {
        if (!empty($bw['paid'])) continue;
        $label = '15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01'));
        $wal = (string)($holders[$bw['pid']]['wallet'] ?? '');
        if (!valid_wallet($wal)) { $skipped[] = ['label' => $label . ': ' . $bw['name'], 'why' => 'no wallet connected yet']; continue; }
        if ($busd <= 0) { $skipped[] = ['label' => $label, 'why' => 'no prize amount set (Rewards settings)']; continue; }
        if (isset($held['b:' . $m])) { $skipped[] = ['label' => $label . ': ' . $bw['name'], 'why' => 'already sent, waiting for Solana to confirm it', 'held' => 1]; continue; }
        if (!empty($bw['units']) && time() - (int)($bw['pt'] ?? 0) > 86400) { unset($d['m'][$m]['units'], $d['m'][$m]['shy'], $d['m'][$m]['usd'], $d['m'][$m]['px'], $d['m'][$m]['dec']); $bchg = true; }   //MC 2026-10-10 a day-old price is re-priced, so $50 stays $50
        if (empty($d['m'][$m]['units'])) { $shy = floor($busd / $px); $d['m'][$m] = ['units' => sprintf('%.0f', $shy * pow(10, $dec)), 'shy' => $shy, 'usd' => $busd, 'px' => $px, 'dec' => $dec, 'pt' => time()] + $d['m'][$m]; $bchg = true; }
        $bw = $d['m'][$m];
        $items[] = ['k' => 'bounty', 'm' => $m, 'label' => $label, 'name' => $bw['name'], 'pid' => $bw['pid'], 'wallet' => $wal, 'units' => (string)$bw['units'], 'dec' => (int)$bw['dec'], 'usd' => (float)$bw['usd'], 'shy' => (float)$bw['shy']];
    }
    if ($bchg) save(BOUNTY, $d);
    // burns still owed: $SHY payments that came as a plain transfer of the whole price
    $burn = ['units' => 0, 'orders' => []];
    foreach (load(ORDERS) as $id => $o) if (($o['status'] ?? '') === 'paid' && !empty($o['burn_owed']) && empty($o['burn_sig']) && !isset($held['o:' . $id])) { $burn['units'] += (int)$o['burn_owed']; $burn['orders'][] = $id; }
    $burn['units'] = (string)$burn['units'];
    $tot = ['usd' => round(array_sum(array_column($items, 'usd')), 2), 'shy' => array_sum(array_column($items, 'shy')), 'n' => count($items)];
    return ['items' => $items, 'skipped' => $skipped, 'burn' => $burn, 'total' => $tot, 'px' => $px, 'dec' => $dec, 'mw' => mw_address(), 'mint' => SHY_MINT, 'held' => count($rw['payall_pending'] ?? [])];
}
// one confirmed transaction: mark every transfer in it that really landed, and the burns (inside with_lock)
function payall_mark($tx, $sig, $items, $burnOrders) {
    $pre = []; $got = [];
    foreach ($tx['meta']['preTokenBalances'] ?? [] as $x) if (($x['mint'] ?? '') === SHY_MINT) $pre[$x['accountIndex']] = (int)$x['uiTokenAmount']['amount'];
    foreach ($tx['meta']['postTokenBalances'] ?? [] as $x) if (($x['mint'] ?? '') === SHY_MINT) $got[$x['owner'] ?? ''] = ($got[$x['owner'] ?? ''] ?? 0) + (int)$x['uiTokenAmount']['amount'] - ($pre[$x['accountIndex']] ?? 0);
    $rw = load(REWARDS); $d = bounty_db(); $paid = []; $n = 0;
    // a transaction counts once
    $seen = false;
    foreach (($rw['weeks'] ?? []) as $w0) foreach (array_merge($w0['league'] ?? [], $w0['cup'] ?? []) as $x) if (($x['sig'] ?? '') === $sig) $seen = true;
    foreach (($rw['seasons'] ?? []) as $w0) foreach ((array)($w0['winners'] ?? []) as $x) if (($x['sig'] ?? '') === $sig) $seen = true;
    foreach (($rw['tourneys'] ?? []) as $w0) foreach ((array)($w0['list'] ?? []) as $x) if (($x['sig'] ?? '') === $sig) $seen = true;   //MC 2026-10-13 paid events count once too
    foreach ($d['m'] as $x) if (($x['tx'] ?? '') === $sig) $seen = true;
    foreach (load(ORDERS) as $x) if (($x['burn_sig'] ?? '') === $sig) $seen = true;
    unset($rw['payall_pending'][$sig]);
    if ($seen) { save(REWARDS, $rw); return ['paid' => 0, 'burned' => 0, 'error' => 'already counted']; }
    foreach ($items as $it) {
        $k = (string)($it['k'] ?? '');
        if ($k === 'list') {
            $ref = &payout_list($rw, (string)($it['period'] ?? ''));
            $i = (int)($it['i'] ?? -1);
            if ($ref !== null && isset($ref[$i]) && empty($ref[$i]['sig']) && !empty($ref[$i]['units']) && ($got[$ref[$i]['wallet']] ?? 0) >= (int)$ref[$i]['units']) {
                $got[$ref[$i]['wallet']] -= (int)$ref[$i]['units'];   // the same wallet can win twice in one batch
                $ref[$i]['sig'] = $sig; $ref[$i]['paidAt'] = time(); $n++;
                $paid[] = ['label' => payout_label($it['period']), 'period' => $it['period']] + $ref[$i];
                payout_status($rw, $it['period']);
            }
            unset($ref);
        } elseif ($k === 'bounty') {
            $m = (string)($it['m'] ?? ''); $bw = $d['m'][$m] ?? null;
            $wal = (string)(load(HOLDERS)[$bw['pid'] ?? '']['wallet'] ?? '');
            if ($bw && empty($bw['paid']) && !empty($bw['units']) && ($got[$wal] ?? 0) >= (int)$bw['units']) {
                $got[$wal] -= (int)$bw['units'];
                $d['m'][$m]['paid'] = time(); $d['m'][$m]['tx'] = $sig; $n++;
                $paid[] = ['label' => '15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')), 'period' => 'bounty:' . $m, 'name' => $bw['name'], 'wallet' => $wal, 'usd' => (float)$bw['usd'], 'shy' => (float)$bw['shy'], 'units' => $bw['units']];
            }
        }
    }
    save(REWARDS, $rw); save(BOUNTY, $d);
    // burns from the community wallet for payments that came without one
    $burned = tx_burned($tx, SHY_MINT, mw_address()); $bn = 0;
    if ($burned > 0 && $burnOrders) {
        $orders = load(ORDERS); $left = $burned;
        foreach ($burnOrders as $oid) {
            if (!isset($orders[$oid]) || empty($orders[$oid]['burn_owed']) || !empty($orders[$oid]['burn_sig']) || $left < (int)$orders[$oid]['burn_owed']) continue;
            $left -= (int)$orders[$oid]['burn_owed'];
            $orders[$oid]['burn_done'] = (int)$orders[$oid]['burn_owed']; $orders[$oid]['burn_sig'] = $sig; $orders[$oid]['burn_at'] = time(); $bn++;
        }
        save(ORDERS, $orders);
    }
    @unlink(DATA_DIR . '/treasury-cache.php'); @unlink(DATA_DIR . '/cache-rewards.php');
    if ($bn) tg_burn((int)round($burned / (10 ** (mint_decimals(SHY_MINT) ?? 6))), $sig, 'the community wallet, for shop payments that came without their burn');   //MC 2026-10-10
    // the confirmation email, one per prize list
    $by = []; foreach ($paid as $p) $by[$p['label']][] = $p;
    foreach ($by as $lab => $rows) alert_paid($lab, $rows, $sig);
    $_SESSION['payall'][$sig] = ['paid' => $paid, 'burned' => $bn ? $burned : 0];
    return ['paid' => $n, 'burned' => $bn ? $burned : 0, 'orders' => $bn];
}
// after the last batch: one Telegram post for the whole run, and the X post text
//MC 2026-10-10 the run is read from this session when it's there, and otherwise from the saved prize lists, bounty and
//   orders by signature, so a batch settled later (or from another admin's session) still gets its post. The post itself
//   is built by payout_tg_html and goes out pinned through tg_payout.
function payall_announce($sigs) {
    $runs = $_SESSION['payall'] ?? []; $paid = []; $burned = 0;
    foreach ($sigs as $s) { $r = $runs[$s] ?? payout_rows_by_sig($s); $paid = array_merge($paid, $r['paid']); $burned += $r['burned']; }
    if (!$paid && !$burned) return ['text' => '', 'tg' => false];
    $dec = mint_decimals(SHY_MINT) ?? 6;
    $shy = 0; $by = []; $who = [];
    foreach ($paid as $p) { $shy += payout_row_shy($p, $dec); $by[$p['label']][] = $p; $who[$p['pid'] ?? $p['name']] = 1; }
    tg_payout(payout_tg_html($paid, $burned, $sigs), 'payall:' . $sigs[0]);
    //MC 2026-10-10 an X post the admin opens and sends from the project account (sending it from here would cost X credits)
    $kinds = implode(', ', array_keys($by));
    $text = '💸 ' . number_format($shy) . ' $SHY just paid out to ' . count($who) . (count($who) === 1 ? ' Shilluminati player' : ' Shilluminati players') . ($kinds !== '' ? ' (' . (mb_strlen($kinds) > 90 ? count($by) . ' prize lists' : $kinds) . ')' : '') . ".\n\n" .
        ($burned ? '🔥 ' . number_format($burned / (10 ** $dec)) . " \$SHY burned too.\n\n" : '') . "Every payout is on chain. Play free and win the next one 👇\nshyonsol.io/treasury?p=" . substr($sigs[0], 0, 6);   //MC 2026-10-12 a new address each time, so X draws today's preview instead of a cached old one
    return ['text' => $text, 'x' => 'https://x.com/intent/post?text=' . rawurlencode($text), 'tg' => tg_ready() && tg_on(tg_cfg(), 'payout')];   //MC 2026-10-10 only says posted when the Prize payouts switch is on
}
//MC 2026-10-12 X posts for winners: opened in X from the admin, sent from the project account (posting from the server
//   costs X credits). The weekly winners text keeps to X's 280 characters: the top 3 with prizes, then the site and tags.
function x_intent($text) { return 'https://x.com/intent/post?text=' . rawurlencode($text); }
function x_tags_line() { $t = trim((string)(eco_settings()['x_tags'] ?? '')); $al = trim((string)(eco_settings()['x_always'] ?? '')); return ($t !== '' ? ' ' . $t : ' $SHY') . ($al !== '' ? ' ' . $al : ''); }   //MC 2026-10-12 + the always-tag accounts
function x_week_text($wk, $league, $fixed = false) {
    $medal = ['🥇', '🥈', '🥉'];
    $rows = []; foreach (array_slice($league, 0, 3) as $i => $w) $rows[] = $medal[$i] . ' ' . $w['name'] . ': $' . number_format((float)$w['usd'], 2);
    $t = '🏆 Shilluminati Weekly League, week ' . (int)substr($wk, 5) . ($fixed ? ' (corrected)' : '') . " winners\n\n" . implode("\n", $rows) . "\n\n" . count($league) . ' players win $SHY this week. Play free, win the next one 👇' . "\nshyonsol.io/treasury?w=" . (int)substr($wk, 5) . ($fixed ? 'c' : '') . x_tags_line();   //MC 2026-10-12 its own address per week (X caches previews by address)
    return mb_strlen($t) > 280 ? mb_substr($t, 0, 277) . '…' : $t;
}
// any Telegram post as an X post: plain text, links kept as plain addresses, cut to fit with the site link at the end
function x_from_tg($html) {
    $t = preg_replace('#<a href="https?://(?:www\.)?([^"]+)">[^<]*</a>#', '$1', (string)$html);
    $t = trim(html_entity_decode(strip_tags(str_replace(['🌐 '], '', $t)), ENT_QUOTES));
    $t = preg_replace("/\n{3,}/", "\n\n", $t);
    $tail = "\nshyonsol.io" . x_tags_line();
    if (mb_strlen($t . $tail) > 280) $t = rtrim(mb_substr($t, 0, 278 - mb_strlen($tail))) . '…';
    return $t . (strpos($t, 'shyonsol.io') === false ? $tail : '');
}
//MC 2026-10-10 one prize row's $SHY: from its raw units when priced here, otherwise what the admin typed
function payout_row_shy($r, $dec = 6) { return !empty($r['units']) ? (int)$r['units'] / (10 ** (int)($r['dec'] ?? $dec)) : (float)($r['shy'] ?? 0); }
//MC 2026-10-10 the Telegram payout post, shared by Pay everything owed, the single-list payout and a bounty marked paid.
//   $paid rows carry label, name, place, usd and units (or shy); $burnedUnits is raw units burned in the same run.
function payout_tg_html($paid, $burnedUnits = 0, $sigs = []) {
    $dec = mint_decimals(SHY_MINT) ?? 6;
    $shy = 0; $usd = 0; $by = []; $who = [];
    foreach ($paid as $p) { $shy += payout_row_shy($p, $dec); $usd += (float)($p['usd'] ?? 0); $by[$p['label']][] = $p; $who[$p['pid'] ?? $p['name']] = 1; }
    $blocks = [];
    foreach ($by as $lab => $rows) {
        usort($rows, fn($a, $b) => ($a['place'] ?? 99) <=> ($b['place'] ?? 99));
        $lines = array_map(fn($r) => (!empty($r['place']) ? (int)$r['place'] . '. ' : '') . tg_h($r['name'] ?? 'Player') . ': ' . number_format(payout_row_shy($r, $dec)) . ' $SHY' . (!empty($r['usd']) ? ' ($' . number_format((float)$r['usd'], 2) . ')' : ''), array_slice($rows, 0, 5));
        if (count($rows) > 5) $lines[] = 'and ' . (count($rows) - 5) . ' more';
        $blocks[] = '🏆 <b>' . tg_h($lab) . "</b>\n" . implode("\n", $lines);
    }
    $n = count($who);
    $tx = array_values(array_filter((array)$sigs));
    $proof = count($tx) === 1 ? ' (<a href="https://solscan.io/tx/' . tg_h($tx[0]) . '">transaction</a>)' : '';
    return '💸 <b>' . number_format($shy) . ' $SHY in prizes just went out</b> to ' . $n . ($n === 1 ? ' player' : ' players') . ($usd ? ', about $' . number_format($usd, 2) : '') . ".\n\n" .
        implode("\n\n", $blocks) .
        ($burnedUnits ? "\n\n🔥 " . number_format($burnedUnits / (10 ** $dec)) . ' $SHY burned for shop payments.' : '') .
        "\n\nPaid from the community marketing wallet" . $proof . '. Every payout and its Solana transaction is on the ' . tg_link('/treasury', 'Treasury') . '.';
}
//MC 2026-10-10 what one transaction paid, read back from the saved lists (for a run this session didn't see)
function payout_rows_by_sig($sig) {
    $rw = load(REWARDS); $paid = []; $burned = 0;
    foreach (payall_lists($rw) as [$period, $label]) {
        $ref = &payout_list($rw, $period);
        if ($ref) foreach ($ref as $w) if (($w['sig'] ?? '') === $sig) $paid[] = ['label' => payout_label($period), 'period' => $period] + $w;
        unset($ref);
    }
    foreach (bounty_db()['m'] as $m => $bw) if (($bw['tx'] ?? '') === $sig)
        $paid[] = ['label' => '15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')), 'period' => 'bounty:' . $m, 'name' => $bw['name'], 'pid' => $bw['pid'] ?? '', 'usd' => (float)($bw['usd'] ?? 0), 'shy' => (float)($bw['shy'] ?? 0), 'units' => $bw['units'] ?? '', 'dec' => $bw['dec'] ?? null];
    foreach (load(ORDERS) as $o) if (($o['burn_sig'] ?? '') === $sig) $burned += (int)($o['burn_done'] ?? 0);
    return ['paid' => $paid, 'burned' => $burned];
}
//MC 2026-10-09 a prize list in words, for the "paid" email
function payout_label($period) {
    $p = explode(':', $period);
    if ($p[0] === 'season') return 'Season ' . ($p[1] ?? '') . ' Championship';
    if ($p[0] === 'tourney') return (string)(load(REWARDS)['tourneys'][$p[1] ?? '']['label'] ?? 'Tournament');   //MC 2026-10-13 paid events
    return (($p[2] ?? '') === 'cup' ? 'Holder Cup' : 'Weekly League') . ', week ' . (int)(explode('-', (string)($p[1] ?? ''))[1] ?? 0);   //MC 2026-10-10 "week 41", not "week 2026-41"
}
// the winners list for a period: week:YYYY-WW:league | week:YYYY-WW:cup | season:N
function &payout_list(&$rw, $period) {
    $null = null;
    $p = explode(':', $period);
    if ($p[0] === 'week' && isset($rw['weeks'][$p[1]]) && in_array($p[2] ?? '', ['league', 'cup'], true)) return $rw['weeks'][$p[1]][$p[2]];
    if ($p[0] === 'season' && isset($rw['seasons'][$p[1]])) return $rw['seasons'][$p[1]]['winners'];
    if ($p[0] === 'tourney' && isset($rw['tourneys'][$p[1]])) return $rw['tourneys'][$p[1]]['list'];   //MC 2026-10-13 paid events
    return $null;
}
// what a second admin approves: exactly these wallets and amounts. Any change after approval needs a new one.
function payout_hash($list) { return sha1(json_encode(array_map(fn($w) => [$w['wallet'], $w['units'] ?? '', !empty($w['skip']), !empty($w['sig'])], $list ?? []))); }
function payout_open_usd($list) { $t = 0; foreach ($list ?? [] as $w) if (empty($w['sig']) && empty($w['skip'])) $t += (float)$w['usd']; return round($t, 2); }
// null when this list can be sent now, otherwise why not
function payout_block($rw, $period) {
    $lim = (float)eco_settings()['payout_approve_usd'];
    $list = payout_list($rw, $period);
    if ($lim <= 0 || payout_open_usd($list) < $lim) return null;
    $ap = $rw['appr'][$period] ?? null;
    if (!$ap || empty($ap['by'])) return 'needs';
    if (($ap['hash'] ?? '') !== payout_hash($list)) return 'changed';
    return null;
}
function payout_status(&$rw, $period) {
    $p = explode(':', $period);
    //MC 2026-10-13 paid events keep their status on their own entry, never under a bogus season key
    $lists = $p[0] === 'week' ? [$rw['weeks'][$p[1]]['league'] ?? [], $rw['weeks'][$p[1]]['cup'] ?? []] : ($p[0] === 'tourney' ? [$rw['tourneys'][$p[1]]['list'] ?? []] : [$rw['seasons'][$p[1]]['winners'] ?? []]);
    $all = 0; $done = 0;
    foreach ($lists as $l) foreach ($l as $w) { if (!empty($w['skip'])) continue; $all++; if (!empty($w['sig'])) $done++; }
    $st = $all && $done === $all ? 'paid' : ($done ? 'partly paid' : 'pending');
    if ($p[0] === 'week') $rw['weeks'][$p[1]]['status'] = $st; elseif ($p[0] === 'tourney') $rw['tourneys'][$p[1]]['status'] = $st; else $rw['seasons'][$p[1]]['status'] = $st;
}

// ---------- suggestion screenshots (kept outside the website) ----------
if (isset($_GET['idea_file'])) {
    if (!can('ideas')) { http_response_code(403); exit; }
    $f = basename((string)$_GET['idea_file']);
    $path = IDEA_FILES . '/' . $f;
    if (!preg_match('/^[a-f0-9]{10}\.(png|jpg|webp)$/', $f) || !is_file($path)) { http_response_code(404); exit; }
    header('Content-Type: ' . ['png' => 'image/png', 'jpg' => 'image/jpeg', 'webp' => 'image/webp'][pathinfo($f, PATHINFO_EXTENSION)]);
    header('Cache-Control: private, max-age=3600');
    header('X-Content-Type-Options: nosniff');
    readfile($path); exit;
}

// ---------- downloads ----------
if (isset($_GET['dl'])) {
    $dl = (string)$_GET['dl'];
    $need = ['players' => 'players', 'week' => 'boards', 'backup' => 'backups', 'allzip' => 'backups'][$dl] ?? 'team';
    if (!can($need)) { http_response_code(403); exit; }
    audit('download', ['file' => $dl] + ($dl === 'allzip' && !empty($_GET['art']) ? ['art' => 1] : []));
    //MC 2026-10-11 owners only: every data file in one zip (it includes config.php with the private keys)
    if ($dl === 'allzip') {
        if (!is_owner()) { http_response_code(403); exit; }
        $err = backup_zip_stream(!empty($_GET['art']));
        go('backups', $err);   // only reached when the zip couldn't be made
    }
    $holders = with_lock(fn() => load(HOLDERS));
    $csv = function ($name, $head, $rows) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        $f = fopen('php://output', 'w');
        fputcsv($f, $head);
        //MC 2026-10-11 a cell starting with = + - @ (or a tab or carriage return) is run as a formula by spreadsheet apps; a
        //   player could name themselves "-A1-B1". Those cells get a leading apostrophe so they stay plain text.
        foreach ($rows as $r) fputcsv($f, array_map(fn($v) => is_string($v) && $v !== '' && strpos("=+-@\t\r", $v[0]) !== false ? "'" . $v : $v, $r));
        exit;
    };
    if ($dl === 'players') {
        $pl = with_lock(fn() => load(PLAYERS));
        uasort($pl, fn($a, $b) => ($b['points'] ?? 0) <=> ($a['points'] ?? 0));
        $rows = []; $i = 0;
        foreach ($pl as $pid => $p) $rows[] = [++$i, $p['name'] ?? '', $p['points'] ?? 0, $p['wins'] ?? 0, $p['games'] ?? 0, $p['lpts'] ?? 0, !empty($p['holder']) ? 'yes' : '', $p['avatar'] ?? '', wallet_of($pid, $holders), $pid, gmdate('Y-m-d', $p['since'] ?? time())];
        $csv('players-' . today() . '.csv', ['rank', 'name', 'points', 'wins', 'games', 'live_points', 'holder', 'shadow', 'wallet', 'player_id', 'joined'], $rows);
    }
    if ($dl === 'week') {
        $wk = (string)($_GET['wk'] ?? '');
        $rows = week_rows($wk);
        $out = []; $onlyH = !empty($_GET['holders']); $i = 0;
        foreach ($rows as $r) { if ($onlyH && !$r['holder']) continue; $out[] = [++$i, $r['name'], $r['pts'], $r['holder'] ? 'yes' : '', $r['avatar'], wallet_of($r['pid'], $holders), $r['pid']]; }
        $csv('week-' . preg_replace('/[^0-9W-]/', '', $wk) . ($onlyH ? '-holders' : '') . '.csv', ['rank', 'name', 'points', 'holder', 'shadow', 'wallet', 'player_id'], $out);
    }
    if ($dl === 'backup') {
        $f = basename((string)($_GET['f'] ?? ''));
        if (!preg_match('/^players-[0-9A-Za-z-]+\.php$/', $f) || !is_file(BACKUPS . '/' . $f)) { http_response_code(404); exit; }
        $raw = file_get_contents(BACKUPS . '/' . $f);
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . str_replace('.php', '.json', $f) . '"');
        echo substr($raw, strpos($raw, "\n") + 1);
        exit;
    }
    http_response_code(404); exit;
}
function week_rows($wk) {
    if ($wk === week_key()) {
        $pl = with_lock(fn() => load(PLAYERS));
        $rows = [];
        foreach ($pl as $pid => $p) if (($p['wk'] ?? '') === $wk && !empty($p['wpts'])) $rows[] = ['pid' => $pid, 'name' => $p['name'] ?? '', 'pts' => $p['wpts'], 'holder' => !empty($p['holder']), 'avatar' => $p['avatar'] ?? ''];
        usort($rows, fn($a, $b) => $b['pts'] <=> $a['pts']);
        return $rows;
    }
    $weeks = with_lock(fn() => load(WEEKS));
    return $weeks[$wk]['rows'] ?? [];
}

// an idea's English translation under the original, or a button to get one
function idea_en_html($id, $x) {
    $lang = $x['lang'] ?? tr_lang($x['text']);
    if ($lang === 'en') return '';
    $name = h(TR_NAMES[$lang] ?? strtoupper($lang));
    if (($x['en'] ?? '') !== '') return '<div class="idea-en"><small>English translation, from ' . $name . '</small><p>' . nl2br(h($x['en'])) . '</p></div>';
    return can('ideas', 2) ? '<form method="post" class="idea-en"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="id" value="' . h($id) . '"><small>Looks like ' . $name . '.</small> <button name="do" value="idea-translate">Translate to English</button></form>' : '';
}

// ---------- actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //MC 2026-10-13 a POST bigger than post_max_size reaches PHP with $_POST and $_FILES empty, so it used to read as an
    //   expired form. Seen with the Deploy zip. Say what actually happened and where to raise the limit.
    if (!$_POST && !$_FILES && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) go('deploy', 'That upload is bigger than the server accepts (post limit ' . ini_get('post_max_size') . ', upload limit ' . ini_get('upload_max_filesize') . '). Raise both in hPanel under PHP configuration.');
    if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) go('overview', 'That form expired. Try again.');
    $do = (string)($_POST['do'] ?? '');
    $pid = (string)($_POST['pid'] ?? '');
    // every change checks the admin's access first, and lands in the activity log
    if (isset(ACTION_NEEDS[$do])) {
        [$area, $lvl] = ACTION_NEEDS[$do];
        if (!can($area, $lvl)) { audit('denied', ['action' => $do]); go((string)($_POST['back'] ?? 'overview'), 'You don\'t have access to do that. Ask an owner if you need it.'); }
        if (strpos($do, 'team-') !== 0) audit($do, action_note($do));
    } elseif ($do !== 'account-save' && strpos($do, 'tfa-') !== 0) go('overview');
    if (strpos($do, 'team-') === 0) team_actions($do);
    if ($do === 'account-save') account_actions($do);
    if (strpos($do, 'tfa-') === 0) tfa_actions($do);
    if (strpos($do, 'art-') === 0) art_actions($do);
    if (strpos($do, 'mask-') === 0) mask_actions($do);   //MC 2026-10-13 bot masks
    if (strpos($do, 'tourney-') === 0) tourney_actions($do);
    if (strpos($do, 'fp-') === 0) fairplay_actions($do);
    if (strpos($do, 'deploy-') === 0) deploy_actions($do);   //MC 2026-10-13
    if (strpos($do, 'hype-') === 0) mkt_actions($do);   //MC 2026-10-14 the Solana gaming tag list
    if ($do === 'rename') {
        $name = trim(preg_replace('/\s+/', ' ', (string)($_POST['name'] ?? '')));
        if (!preg_match('/^[A-Za-z0-9 _.\-]{2,20}$/', $name)) go('players', 'Names are 2 to 20 letters, numbers, spaces, dots, dashes or underscores.');
        $msg = with_lock(function () use ($pid, $name) {
            $pl = load(PLAYERS);
            if (!ensure_player($pl, $pid)) return 'Player not found.';
            foreach ($pl as $id => $p) if ($id !== $pid && strcasecmp($p['name'] ?? '', $name) === 0) return 'Another player already has that name.';
            $old = $pl[$pid]['name'] !== '' ? $pl[$pid]['name'] : 'the connected profile ' . substr($pid, 0, 6);
            $pl[$pid]['name'] = $name; $pl[$pid]['nlock'] = 1; save(PLAYERS, $pl);   // the player's next game keeps this name
            return "Renamed $old to $name. The player keeps this name from now on." . (name_blocked($name) ? ' Heads up: the name filter would block this one for players.' : '');
        });
        go('players', $msg);
    }
    if ($do === 'clear-motto') {
        $msg = with_lock(function () use ($pid) {
            $eco = load(ECO);
            if (empty($eco[$pid]['pg']['motto'])) return 'That player has no motto.';
            $was = $eco[$pid]['pg']['motto']; $eco[$pid]['pg']['motto'] = ''; save(ECO, $eco);
            return 'Cleared the motto "' . $was . '". They can write a new one, and the filter still checks it.';
        });
        go('players', $msg);
    }
    //MC 2026-10-11 Ban and Unban (see player_banned in economy.php). The wallet and every device key of the profile go on
    //   the list too, so a new profile on the same phone or wallet is caught. Both land in the activity log.
    if ($do === 'ban' || $do === 'unban') {
        $msg = with_lock(function () use ($do) {
            $pl = load(PLAYERS); $hol = load(HOLDERS);
            $who = find_player($_POST['who'] ?? ($_POST['pid'] ?? ''), $pl, $hol);
            $b = load(BANS) + ['p' => [], 'w' => [], 'k' => []];
            if ($do === 'unban') {
                $p = (string)($_POST['pid'] ?? '');
                if (!isset($b['p'][$p])) return 'That player isn\'t banned.';
                $name = $b['p'][$p]['name'] ?? substr($p, 0, 6);
                unset($b['p'][$p]); foreach (['w', 'k'] as $k) foreach ($b[$k] as $x => $q) if ($q === $p) unset($b[$k][$x]);
                save(BANS, $b); bans(true);
                return 'Lifted the ban on ' . $name . '.';
            }
            if (!$who) return 'Couldn\'t find that player. Use a name, the 6-letter id or their wallet.';
            $why = mb_substr(trim(preg_replace('/\s+/u', ' ', (string)($_POST['why'] ?? ''))), 0, 80);
            if ($why === '') return 'Give a reason for the ban (it\'s kept in the log).';
            $name = $pl[$who]['name'] ?? substr($who, 0, 6);
            $w = (string)($hol[$who]['wallet'] ?? '');
            $b['p'][$who] = ['t' => time(), 'by' => me()['username'] ?? '', 'why' => $why, 'name' => $name, 'w' => $w];
            if ($w !== '') $b['w'][$w] = $who;
            foreach (keys_known($who, $pl, $hol) as $kh) $b['k'][$kh] = $who;
            save(BANS, $b); bans(true);
            return 'Banned ' . $name . '. They can\'t play, buy or show on the boards until the ban is lifted.';
        });
        go('players', $msg);
    }
    if ($do === 'remove') {
        $msg = with_lock(function () use ($pid) {
            $pl = load(PLAYERS);
            if (!isset($pl[$pid])) return 'Player not found.';
            $name = $pl[$pid]['name'] ?? '';
            unset($pl[$pid]); save(PLAYERS, $pl);
            $d = load(DAILY); foreach ($d as $day => $rows) unset($d[$day][$pid]); save(DAILY, $d);
            $w = load(WEEKS); foreach ($w as $k => $wk) $w[$k]['rows'] = array_values(array_filter($wk['rows'], fn($r) => $r['pid'] !== $pid)); if ($w) save(WEEKS, $w);
            return "Removed $name from every board.";
        });
        go('players', $msg);
    }
    if ($do === 'merge') {
        $msg = with_lock(function () {
            $pl = load(PLAYERS); $hol = load(HOLDERS);
            $from = find_player($_POST['from'] ?? '', $pl, $hol); $into = find_player($_POST['into'] ?? '', $pl, $hol);
            if (!$from || !$into) return 'Couldn\'t find ' . (!$from ? 'the first' : 'the second') . ' player. Use a name, the 6-letter id or their wallet.';
            if (!isset($pl[$from]) || !isset($pl[$into])) { ensure_player($pl, $from); ensure_player($pl, $into); save(PLAYERS, $pl); }
            return merge_players($into, $from);
        });
        go('players', $msg);
    }
    if ($do === 'blocked-words') {
        $words = array_values(array_unique(array_filter(array_map(fn($w) => strtolower(preg_replace('/[^a-z0-9]/i', '', $w)), preg_split('/[\s,]+/', (string)($_POST['words'] ?? ''))), fn($w) => strlen($w) >= 3)));
        with_lock(function () use ($words) { save(BLOCKED_NAMES, array_slice($words, 0, 500)); });
        go('players', count($words) . ' extra blocked words saved. New names are checked against them right away.');
    }
    if ($do === 'close-room') {
        $code = (string)($_POST['code'] ?? '');
        if (preg_match('/^[A-Z0-9]{5}$/', $code)) {
            @unlink(ROOMS . '/' . $code . '.php'); @unlink(ROOMS . '/' . $code . '.php.lock');
            with_lock(function () use ($code) { $l = load(LOBBY); unset($l[$code]); save(LOBBY, $l); });
        }
        go('live', "Closed room $code.");
    }
    if ($do === 'payout-approve') {
        $period = (string)($_POST['period'] ?? '');
        $msg = with_lock(function () use ($period) {
            $me = me();
            if (!empty($me['key'])) return 'The setup key can\'t approve payouts. Sign in with your own account.';
            $rw = load(REWARDS);
            $list = payout_list($rw, $period);
            if ($list === null) return 'Not found.';
            foreach ($list as $w) if (empty($w['sig']) && empty($w['skip']) && empty($w['units'])) return 'Set the amounts first, then approve.';
            $ap = $rw['appr'][$period] ?? [];
            if (($ap['prepId'] ?? '') === $me['id']) return 'You set these amounts, so someone else has to approve them.';
            $rw['appr'][$period] = $ap + ['prep' => '', 'prepId' => ''];
            $rw['appr'][$period]['by'] = $me['username']; $rw['appr'][$period]['byId'] = $me['id']; $rw['appr'][$period]['byAt'] = time(); $rw['appr'][$period]['hash'] = payout_hash($list);
            save(REWARDS, $rw);
            return 'Approved. ' . ($ap['prep'] ?? '') . ($ap['prep'] ?? '' ? ' or anyone with payout access' : 'Anyone with payout access') . ' can send it now.';
        });
        go('rewards', $msg);
    }
    if ($do === 'payout-prepare' || $do === 'payout-skip') {
        $period = (string)($_POST['period'] ?? '');
        $px = $do === 'payout-prepare' ? price_usd(SHY_MINT) : 1;
        $dec = $do === 'payout-prepare' ? mint_decimals(SHY_MINT) : 6;
        if (!$px || $dec === null) go('rewards', "Couldn't get the \$SHY price from the market. Try again in a minute.");
        $msg = with_lock(function () use ($period, $px, $dec, $do) {
            $rw = load(REWARDS);
            $ref = &payout_list($rw, $period);
            if ($ref === null) return 'Not found.';
            if ($do === 'payout-skip') {
                $i = (int)($_POST['i'] ?? -1);
                if (!isset($ref[$i]) || !empty($ref[$i]['sig'])) return 'Can\'t change that one.';
                $ref[$i]['skip'] = empty($ref[$i]['skip']);
                payout_status($rw, $period); save(REWARDS, $rw);
                return $ref[$i]['skip'] ? 'Left out of this payout.' : 'Back in the payout.';
            }
            foreach ($ref as &$w) {
                if (!empty($w['sig'])) continue;
                $shy = floor($w['usd'] / $px);       // whole tokens, rounded down
                $w['shy'] = $shy; $w['units'] = sprintf('%.0f', $shy * pow(10, $dec)); $w['px'] = $px; $w['dec'] = $dec;
            }
            unset($w);
            $rw['appr'][$period] = ['prep' => me()['username'], 'prepId' => me()['id'], 'at' => time()];   // new amounts need a fresh approval
            save(REWARDS, $rw);
            return 'Amounts set at $' . rtrim(rtrim(number_format($px, 10, '.', ''), '0'), '.') . ' per $SHY. Check them, then send with Phantom.';
        });
        go('rewards', $msg);
    }
    if ($do === 'eco-settings') {
        $num = fn($k, $min = 0, $max = 1e9) => max($min, min($max, (float)($_POST[$k] ?? 0)));
        $msg = with_lock(function () use ($num) {
            $s = is_file(ECOSET) ? load(ECOSET) : [];
            foreach (['league_usd', 'cup_usd', 'season_usd'] as $k) $s[$k] = round($num($k, 0, 100000), 2);
            $s['league_share'] = (int)$num('league_share', 0, 100);
            $s['min_games'] = (int)$num('min_games', 0, 50);
            $s['shop_open'] = !empty($_POST['shop_open']);
            if (is_owner() && isset($_POST['payout_approve_usd'])) $s['payout_approve_usd'] = round($num('payout_approve_usd', 0, 1000000), 2);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_POST['founder_until'] ?? ''))) $s['founder_until'] = $_POST['founder_until'];
            //MC 2026-10-10 the nine $SHY Army Ranks (each above the one before) and their weekly Koban; the burn and the 15 Club prize.
            //   Old bronze..kami keys in the saved file are swapped for the ranks first, so a save never mixes the two.
            holder_settings_fix($s);
            if (isset($_POST['htier_sapling'])) {
                $prev = 0; $ht = [];
                foreach (HOLDER_LADDER as $t) { $v = (int)$num('htier_' . $t, 1, 1e12); if ($v <= $prev) return 'Each rank needs more $SHY than the one below it. Nothing was saved.'; $ht[$t] = $prev = $v; }
                $s['htiers'] = $ht;
            }
            foreach (array_merge(['shadow'], HOLDER_LADDER) as $t) if (isset($_POST['hstip_' . $t])) $s['hstip'][$t] = (int)$num('hstip_' . $t, 0, 100000);
            if (isset($_POST['burn_pct'])) $s['burn_pct'] = (int)$num('burn_pct', 0, 50);
            if (isset($_POST['bounty_usd'])) $s['bounty_usd'] = round($num('bounty_usd', 0, 100000), 2);
            //MC 2026-10-12 prize budget: pools from shop sales, $SHY places, Koban per $1 for the places below, the runway warning
            if (isset($_POST['prize_mode'])) {
                $s['prize_mode'] = $_POST['prize_mode'] === 'sales' ? 'sales' : 'fixed';
                foreach (['league', 'cup', 'season'] as $k) {
                    $fl = round($num('pp_' . $k . '_floor', 0, 100000), 2); $mx = round($num('pp_' . $k . '_max', 0, 100000), 2);
                    if ($mx < $fl) return 'A pool\'s max can\'t be below its floor (' . $k . '). Nothing was saved.';
                    $s['pp'][$k] = ['floor' => $fl, 'pct' => round($num('pp_' . $k . '_pct', 0, 100), 2), 'max' => $mx];
                    $s['cash_top'][$k] = (int)$num('cash_' . $k, 1, 10);
                }
                $s['kswap'] = (int)$num('kswap', 0, 100000);
                $s['runway_warn'] = (int)$num('runway_warn', 0, 52);
            }
            //MC 2026-10-12 Koban prizes per place, League and Holder Cup
            foreach (['league_koban', 'cup_koban'] as $k) if (isset($_POST[$k]) && is_array($_POST[$k])) { $v = []; for ($i = 0; $i < 10; $i++) $v[] = max(0, min(1000000, (int)str_replace([',', ' '], '', (string)($_POST[$k][$i] ?? 0)))); $s[$k] = $v; }
            foreach (['league_split', 'cup_split', 'season_split'] as $k) {
                $parts = array_values(array_filter(array_map('floatval', explode(',', (string)($_POST[$k] ?? ''))), fn($x) => $x > 0));
                if ($parts && abs(array_sum($parts) - 100) < 0.01) $s[$k] = $parts;
            }
            save(ECOSET, $s);
            return 'Saved. Splits that did not add up to 100 were left as they were.';
        });
        go('rewards', $msg);
    }
    if ($do === 'league-credit' || $do === 'league-skip') {
        $day = (string)($_POST['day'] ?? '');
        $msg = with_lock(function () use ($do, $day, $pid) {
            $d = load(DAILY); $run = $d[$day][$pid] ?? null;
            if (!$run || !empty($run['lg']) || !empty($run['lgx'])) return 'That run is already sorted.';
            if ($do === 'league-skip') { $d[$day][$pid]['lgx'] = 1; save(DAILY, $d); return 'Marked as not needed.'; }
            if (strtotime($day . ' 00:00:00 UTC') < strtotime('monday this week 00:00:00 UTC')) return 'That week is already final.';
            $pl = load(PLAYERS);
            if (!isset($pl[$pid])) return 'Player not found.';
            $wk = week_key(); $p = $pl[$pid];
            if (($p['lg']['wk'] ?? '') !== $wk) $p['lg'] = ['wk' => $wk, 'pts' => 0, 'n' => 0];
            $p['lg']['pts'] += (int)$run['points']; $p['lg']['n']++;
            if (($p['sg']['s'] ?? 0) !== season_no()) $p['sg'] = ['s' => season_no(), 'pts' => 0, 'n' => 0];
            $p['sg']['pts'] += (int)$run['points']; $p['sg']['n']++;
            $pl[$pid] = $p; save(PLAYERS, $pl);
            $d[$day][$pid]['lg'] = 1; save(DAILY, $d);
            return 'Counted ' . (int)$run['points'] . ' League points for ' . ($p['name'] ?? '') . '.';
        });
        go('rewards', $msg);
    }
    if ($do === 'shop-reroll') {
        $n = with_lock(function () { $s = is_file(ECOSET) ? load(ECOSET) : []; $r = $s['shop_roll'] ?? [];
            $r[today()] = (int)($r[today()] ?? 0) + 1; $r = array_filter($r, fn($d) => $d >= gmdate('Y-m-d', time() - 7 * 86400), ARRAY_FILTER_USE_KEY);
            $s['shop_roll'] = $r; save(ECOSET, $s); return $r[today()]; });
        go('shop', 'Today\'s shop has new items. Players see them the next time the shop opens.');
    }
    //MC 2026-10-13 limited finish drops: schedule one, stop one early, or remove one that never sold
    if ($do === 'drop-add') {
        $card = (string)($_POST['card'] ?? ''); $fin = (string)($_POST['fin'] ?? '');
        if (!deck_card($card) || !isset(FINISHES[$fin])) go('shop', 'Pick a card and a finish.');
        if (!empty(FINISHES[$fin]['earned'])) go('shop', FINISHES[$fin]['name'] . ' is earned, never sold. The promise holds for drops too.');
        $n = max(1, min(10000, (int)($_POST['n'] ?? 50)));
        $shy = max(1, round((float)($_POST['shy'] ?? 0), 2));
        $start = strtotime((string)($_POST['start'] ?? '') . ' UTC'); $end = strtotime((string)($_POST['end'] ?? '') . ' UTC');
        if (!$start || !$end || $end <= $start) go('shop', 'Give the drop a start and an end, with the end after the start.');
        if ($end < time()) go('shop', 'That drop would already be over.');
        if (!eco_settings()['shop_open']) go('shop', 'The shop is closed, so a drop can\'t sell. Open the shop first.');
        $id = bin2hex(random_bytes(5));
        $d = ['id' => $id, 'card' => $card, 'fin' => $fin, 'n' => $n, 'shy' => $shy, 'start' => $start, 'end' => $end, 'sold' => 0, 'off' => 0, 'by' => me()['username'], 'created' => time()];
        with_lock(function () use ($id, $d) { $drops = load(DROPS); $drops[$id] = $d; if (count($drops) > 50) { uasort($drops, fn($a, $b) => $b['created'] <=> $a['created']); $drops = array_slice($drops, 0, 50, true); } save(DROPS, $drops); });
        audit('drop-add', ['id' => $id, 'card' => $card, 'fin' => $fin, 'n' => $n, 'shy' => $shy]);
        $nm = deck_card($card)['name'] . ' in ' . FINISHES[$fin]['name'];
        if (!empty($_POST['announce'])) tg_post('drop', '🔥 <b>Limited drop: ' . tg_h($nm) . '.</b> Only ' . $n . ' copies, ever, numbered as they sell. ' . number_format($shy) . ' $SHY each, ' . ($start > time() ? 'from ' . gmdate('M j, H:i', $start) . ' UTC ' : '') . 'until ' . gmdate('M j, H:i', $end) . " UTC or sold out.\n" . tg_link('/play#shop', 'To the shop'), 'dropnew:' . $id);
        go('shop', 'Drop scheduled: ' . $nm . ', ' . $n . ' copies at ' . number_format($shy) . ' $SHY.');
    }
    if ($do === 'drop-off') {
        $id = (string)($_POST['id'] ?? '');
        with_lock(function () use ($id) { $drops = load(DROPS); if (isset($drops[$id])) { $drops[$id]['off'] = time(); save(DROPS, $drops); } });
        audit('drop-off', ['id' => $id]);
        go('shop', 'Drop stopped. Copies already sold stay with their owners.');
    }
    if ($do === 'drop-del') {
        $id = (string)($_POST['id'] ?? '');
        $gone = with_lock(function () use ($id) { $drops = load(DROPS); if (isset($drops[$id]) && (int)$drops[$id]['sold'] === 0) { unset($drops[$id]); save(DROPS, $drops); return true; } return false; });
        audit('drop-del', ['id' => $id]);
        go('shop', $gone ? 'Removed.' : 'A drop that sold copies is stopped, not removed, so the numbering stays on record.');
    }
    if ($do === 'cardset-public') {
        require_once dirname(__DIR__) . '/api/cardsetlib.php';
        $on = !empty($_POST['on']);
        with_lock(function () use ($on) { $c = cs_data(); $c['public'] = $on; save(CARDSET, $c); });
        go('art', $on ? 'The ballot is revealed to everyone on the cards page.' : 'The ballot is back to holders only.');
    }
    if ($do === 'house-settings') {
        with_lock(function () { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['house_on'] = !empty($_POST['house_on']);
            $s['house_cost'] = max(0, min(100000, (int)($_POST['house_cost'] ?? 300))); $s['house_games'] = max(0, min(100, (int)($_POST['house_games'] ?? 5)));
            $s['house_prize'] = array_map(fn($k) => max(0, min(100000, (int)($_POST['hp' . $k] ?? 0))), [1, 2, 3]); save(ECOSET, $s); });
        go('rewards', 'House settings saved.');
    }
    //MC 2026-10-11 clear a House's About text without closing the House
    if ($do === 'house-clear') {
        $hid = (string)($_POST['id'] ?? '');
        $msg = with_lock(function () use ($hid) { $H = houses(); if (!isset($H['h'][$hid])) return 'Not found.'; $H['h'][$hid]['desc'] = ''; save(HOUSES, $H); return 'Cleared the About text of ' . $H['h'][$hid]['name'] . '.'; });
        go('rewards', $msg);
    }
    if ($do === 'house-del') {
        $hid = (string)($_POST['id'] ?? '');
        $msg = with_lock(function () use ($hid) { $H = houses(); if (!isset($H['h'][$hid])) return 'Not found.'; $n = $H['h'][$hid]['name']; foreach ($H['h'][$hid]['members'] as $p => $_) unset($H['m'][$p]); unset($H['h'][$hid]); save(HOUSES, $H); return 'Closed the House ' . $n . '. Its members can join another one.'; });
        go('rewards', $msg);
    }
    //MC 2026-10-09 the 15 Club bounty: switch it on or off, set the prize text, mark a month paid (which also lists the
    //payout on the Treasury page), or take a win back for a fair play problem so the month opens again
    if ($do === 'bounty-save' || $do === 'bounty-paid' || $do === 'bounty-void') {
        $msg = with_lock(function () use ($do) {
            $d = bounty_db();
            if ($do === 'bounty-save') {
                $pr = trim(mb_substr((string)($_POST['prize'] ?? ''), 0, 40));
                $d['cfg'] = ['on' => !empty($_POST['on']), 'prize' => $pr !== '' ? $pr : '$50 in $SHY'];
                save(BOUNTY, $d); return 'Saved.';
            }
            $m = (string)($_POST['m'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}$/', $m) || empty($d['m'][$m])) return 'Not found.';
            if ($do === 'bounty-void') { unset($d['m'][$m]); save(BOUNTY, $d); return 'Win taken back. The bounty is open again for the next qualifying player this month.'; }
            $sig = trim((string)($_POST['sig'] ?? ''));
            if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) return 'Paste the Solana transaction signature (from Solscan), so anyone can check it.';
            $w = &$d['m'][$m]; $w['paid'] = time(); $w['tx'] = $sig; $name = $w['name']; unset($w);
            save(BOUNTY, $d);
            $log = load(DATA_DIR . '/treasury-log.php'); $log = is_array($log) ? array_values($log) : [];
            $dup = false; foreach ($log as $x) if (($x['sig'] ?? '') === $sig) $dup = true;
            if (!$dup) {
                $log[] = ['t' => time(), 'kind' => 'other', 'shy' => max(0, (float)($_POST['shy'] ?? 0)), 'usd' => max(0, round((float)($_POST['usd'] ?? 0), 2)), 'sig' => $sig,
                    'note' => mb_substr('15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')) . ': ' . $name, 0, 140)];
                save(DATA_DIR . '/treasury-log.php', $log); @unlink(DATA_DIR . '/treasury-cache.php');
            }
            $bw = $d['m'][$m];
            alert_paid('15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')) . ': ' . $name, [['name' => $name, 'usd' => max(0, round((float)($_POST['usd'] ?? 0), 2)), 'amount' => $bw['prize'] ?? '', 'wallet' => (string)(load(HOLDERS)[$bw['pid']]['wallet'] ?? '')]], $sig);   //MC 2026-10-09
            //MC 2026-10-10 a bounty marked paid by hand is posted (and pinned) like every other payout
            tg_payout(payout_tg_html([['label' => '15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')), 'name' => $name, 'pid' => $bw['pid'] ?? '', 'usd' => max(0, round((float)($_POST['usd'] ?? 0), 2)), 'shy' => max(0, (float)($_POST['shy'] ?? 0))]], 0, [$sig]), 'payall:' . $sig);
            return 'Marked paid. The payout is on the Treasury page.';
        });
        go('rewards', $msg);
    }
    //MC 2026-10-13 Find past burns: scan a wallet's $SHY history on chain for burn transactions the Treasury page never
    //   heard about. Burns happened from more than one wallet over time, so the wallet is an input. The first press
    //   collects the wallet's $SHY transaction signatures into a queue; every press works through it on a time budget
    //   (hosts cut long requests), skipping transactions already on the Treasury page or recorded on orders. Found burns
    //   wait in the session until Add puts them on the Treasury page as burn moves.
    if ($do === 'burn-scan') {
        @set_time_limit(120);
        $w = trim((string)($_POST['wallet'] ?? ''));
        if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $w)) go('rewards', 'Paste a Solana wallet address.', 'treasury');
        $B = $_SESSION['bscan'] ?? null;
        if (!$B || $B['w'] !== $w) {
            $atas = [];
            $r = rpc('getTokenAccountsByOwner', [$w, ['mint' => SHY_MINT], ['encoding' => 'jsonParsed']]);
            foreach ($r['value'] ?? [] as $a) if (!empty($a['pubkey'])) $atas[] = $a['pubkey'];
            if (!$atas) go('rewards', 'That wallet holds no $SHY token account, so there is no history to scan.', 'treasury');
            $queue = [];
            foreach ($atas as $ata) foreach (rpc('getSignaturesForAddress', [$ata, ['limit' => 1000]]) ?? [] as $s0)
                if (empty($s0['err']) && !empty($s0['signature'])) $queue[$s0['signature']] = 1;
            $B = ['w' => $w, 'queue' => array_keys($queue), 'found' => [], 'scanned' => 0];
        }
        $known = [];
        foreach (load(DATA_DIR . '/treasury-log.php') ?: [] as $x) if (!empty($x['sig'])) $known[$x['sig']] = 1;
        foreach (load(ORDERS) as $o) { if (!empty($o['proof'])) $known[$o['proof']] = 1; if (!empty($o['burn_sig'])) $known[$o['burn_sig']] = 1; }
        $dec = 10 ** (mint_decimals(SHY_MINT) ?? 6);
        $INC = '1nc1nerator11111111111111111111111111111111';
        $t0 = microtime(true);
        while ($B['queue'] && microtime(true) - $t0 < 18) {
            $sig = array_shift($B['queue']); $B['scanned']++;
            if (isset($known[$sig]) || isset($B['found'][$sig])) continue;
            $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]);
            if (!is_array($tx) || !empty($tx['meta']['err'])) continue;
            $amt = 0;
            $sets = [$tx['transaction']['message']['instructions'] ?? []];
            foreach ($tx['meta']['innerInstructions'] ?? [] as $ii) $sets[] = $ii['instructions'] ?? [];
            foreach ($sets as $ixs) foreach ($ixs as $ix) {
                $p = $ix['parsed'] ?? null;
                if (!$p || !in_array($p['type'] ?? '', ['burn', 'burnChecked'], true)) continue;
                $i = $p['info'] ?? [];
                if (($i['mint'] ?? '') !== SHY_MINT) continue;
                $by = $i['authority'] ?? ($i['owner'] ?? ($i['multisigAuthority'] ?? ''));
                if ($by !== '' && $by !== $w) continue;
                $amt += (int)($i['amount'] ?? ($i['tokenAmount']['amount'] ?? 0));
            }
            if (!$amt) {
                // tokens sent to the incinerator count as burned too
                $pre = [];
                foreach ($tx['meta']['preTokenBalances'] ?? [] as $b0) if (($b0['mint'] ?? '') === SHY_MINT && ($b0['owner'] ?? '') === $INC) $pre[$b0['accountIndex']] = (int)$b0['uiTokenAmount']['amount'];
                foreach ($tx['meta']['postTokenBalances'] ?? [] as $b0) if (($b0['mint'] ?? '') === SHY_MINT && ($b0['owner'] ?? '') === $INC) $amt += max(0, (int)$b0['uiTokenAmount']['amount'] - ($pre[$b0['accountIndex']] ?? 0));
            }
            if ($amt > 0) $B['found'][$sig] = ['t' => (int)($tx['blockTime'] ?? 0), 'shy' => round($amt / $dec, 2)];
        }
        $_SESSION['bscan'] = $B;
        $n = count($B['found']); $left = count($B['queue']);
        go('rewards', 'Scanned ' . $B['scanned'] . ' transactions, found ' . $n . ($n === 1 ? ' burn' : ' burns') . ' not on the Treasury page.' . ($left ? ' ' . $left . ' transactions to go: press Scan again to continue.' : ' The whole history is scanned.'), 'treasury');
    }
    if ($do === 'burn-log') {
        $B = $_SESSION['bscan'] ?? null;
        if (!$B || !$B['found']) go('rewards', 'Nothing scanned to add. Run Find past burns first.', 'treasury');
        $msg = with_lock(function () use ($B) {
            $log = load(DATA_DIR . '/treasury-log.php'); $log = is_array($log) ? array_values($log) : [];
            $have = []; foreach ($log as $x) if (!empty($x['sig'])) $have[$x['sig']] = 1;
            $n = 0;
            foreach ($B['found'] as $sig => $f) {
                if (isset($have[$sig])) continue;
                $log[] = ['t' => $f['t'] ?: time(), 'kind' => 'burn', 'shy' => (float)$f['shy'], 'usd' => 0, 'sig' => $sig, 'note' => 'On-chain burn, found by the wallet scan'];
                $n++;
            }
            usort($log, fn($a, $b) => ($a['t'] ?? 0) <=> ($b['t'] ?? 0));
            save(DATA_DIR . '/treasury-log.php', $log);
            @unlink(DATA_DIR . '/treasury-cache.php');
            return $n;
        });
        $_SESSION['bscan']['found'] = [];
        go('rewards', $msg ? 'Added ' . $msg . ($msg === 1 ? ' burn' : ' burns') . ' to the Treasury page. The burn tracker picks them up within a few minutes.' : 'Those burns were already on the list.', 'treasury');
    }
    if ($do === 'burn-clear') { unset($_SESSION['bscan']); go('rewards', 'Scan cleared.', 'treasury'); }
    // treasury moves shown on the public Treasury page: buys for the prize pool, burns, liquidity, marketing
    if ($do === 'treasury-add' || $do === 'treasury-del') {
        $msg = with_lock(function () use ($do) {
            $log = load(DATA_DIR . '/treasury-log.php'); $log = is_array($log) ? array_values($log) : [];
            if ($do === 'treasury-del') { $i = (int)($_POST['i'] ?? -1); if (!isset($log[$i])) return 'Not found.'; array_splice($log, $i, 1); }
            else {
                $kind = (string)($_POST['kind'] ?? '');
                if (!in_array($kind, ['buy', 'burn', 'lp', 'marketing', 'other'], true)) return 'Pick what kind of move it was.';
                $sig = trim((string)($_POST['sig'] ?? ''));
                if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) return 'Paste the Solana transaction signature (from Solscan), so anyone can check it.';
                foreach ($log as $x) if (($x['sig'] ?? '') === $sig) return 'That transaction is already on the list.';
                $day = (string)($_POST['day'] ?? ''); $t = preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) ? strtotime($day . ' 12:00 UTC') : time();
                $log[] = ['t' => $t, 'kind' => $kind, 'shy' => max(0, (float)($_POST['shy'] ?? 0)), 'usd' => max(0, round((float)($_POST['usd'] ?? 0), 2)), 'sig' => $sig, 'note' => mb_substr(trim((string)($_POST['note'] ?? '')), 0, 140)];
            }
            save(DATA_DIR . '/treasury-log.php', $log);
            @unlink(DATA_DIR . '/treasury-cache.php');
            return $do === 'treasury-add' ? 'Added. It shows on the Treasury page now.' : 'Removed from the Treasury page.';
        });
        go('rewards', $msg);
    }
    if ($do === 'event-add' || $do === 'event-del') {
        $msg = with_lock(function () use ($do) {
            $s = is_file(ECOSET) ? load(ECOSET) : [];
            $ev = $s['events'] ?? eco_settings()['events'];
            if ($do === 'event-del') { array_splice($ev, (int)($_POST['i'] ?? -1), 1); $s['events'] = $ev; save(ECOSET, $s); return 'Event removed.'; }
            $from = strtotime((string)($_POST['from'] ?? '') . ' UTC');
            $hours = max(1, min(24 * 14, (int)($_POST['hours'] ?? 48)));
            $name = trim(preg_replace('/[^A-Za-z0-9 \-!\'&]/', '', (string)($_POST['name'] ?? '')));
            if (!$from || $name === '') return 'Give the event a name and a start time.';
            $ev[] = ['name' => substr($name, 0, 40), 'from' => $from, 'to' => $from + $hours * 3600, 'mult' => max(1, min(5, (float)($_POST['mult'] ?? 2)))];
            $ev = array_values(array_filter($ev, fn($e) => $e['to'] > time() - 86400));
            $s['events'] = $ev; save(ECOSET, $s);
            return 'Event added.';
        });
        go('rewards', $msg);
    }
    if ($do === 'grant') {
        //MC 2026-10-08 award Koban by hand from the Players tab (and the old form in Shop). Finds a player by name, a name
        //   with underscores, a /p/ link, a 6-letter id or a wallet. Amounts are capped so a typo can't mint a fortune, a
        //   minus takes Koban back (never below 0), and every award is kept in grants.php for the Recent awards list.
        $back = ($_POST['back'] ?? '') === 'shop' ? 'shop' : 'players';
        $raw = trim((string)($_POST['who'] ?? ''));
        $k = (int)($_POST['koban'] ?? 0); $item = (string)($_POST['item'] ?? '');
        $why = mb_substr(trim(preg_replace('/\s+/u', ' ', (string)($_POST['why'] ?? ''))), 0, 60) ?: 'Gift from the team';
        if ($k > GRANT_MAX || $k < -GRANT_MAX) go($back, 'Awards are capped at ' . number_format(GRANT_MAX) . ' Koban at a time.');
        if (!$k && !$item) go($back, 'Enter an amount of Koban or pick an item.');
        if ($item && !eco_item($item)) go($back, 'That item doesn\'t exist.');
        $msg = with_lock(function () use ($raw, $k, $item, $why) {
            $pl = load(PLAYERS); $hol = load(HOLDERS); $eco = load(ECO);
            $q = preg_replace('~^(https?://[^/]+)?/?p/~i', '', $raw); $q = ltrim(rawurldecode($q), '@');
            $target = find_player($q, $pl, $hol) ?? find_player(str_replace('_', ' ', $q), $pl, $hol);
            if (!$target && isset($eco[$q])) $target = $q;
            if (!$target) return 'Player not found. Use their name, their page link, the 6-letter id or their wallet.';
            $a = eco_get($eco, $target); $before = (int)$a['koban']; $gave = 0; $gotItem = '';
            if ($k) { eco_credit($a, $k, $why); $gave = (int)$a['koban'] - $before; if ($gave !== $k) $a['ledger'][0]['n'] = $gave; }
            if ($item && !isset($a['items'][$item])) { eco_grant_item($a, $item); $gotItem = $item; }
            $eco[$target] = $a; save(ECO, $eco);
            $name = ($pl[$target]['name'] ?? '') !== '' ? $pl[$target]['name'] : substr($target, 0, 6);
            $log = is_file(GRANTS) ? load(GRANTS) : [];
            array_unshift($log, ['t' => time(), 'pid' => $target, 'name' => $name, 'k' => $gave, 'item' => $gotItem, 'why' => $why, 'by' => me()['username'] ?? '']);
            save(GRANTS, array_slice($log, 0, 300));
            $parts = [];
            if ($k) $parts[] = $gave >= 0 ? 'gave ' . number_format($gave) . ' Koban' : 'took back ' . number_format(-$gave) . ' Koban';
            if ($item) $parts[] = $gotItem ? 'gave ' . eco_item($item)['name'] : 'they already own ' . eco_item($item)['name'];
            return ucfirst(implode(' and ', $parts)) . ' to ' . $name . '. They now have ' . number_format($a['koban']) . ' Koban.';
        });
        go($back, $msg);
    }
    //MC 2026-10-15 trophies on Solana (api/trophylib.php): the minting service key and collection, owner only
    if ($do === 'trophy-save' && is_owner()) {
        with_lock(function () {
            $c = is_file(TROPHY_CFG) ? load(TROPHY_CFG) : [];
            $c['on'] = !empty($_POST['t_on']);
            $k = trim((string)($_POST['t_key'] ?? ''));
            if ($k !== '' && preg_match('/^[A-Za-z0-9_\-.]{20,300}$/', $k)) $c['key'] = $k;
            if (!empty($_POST['t_clear'])) $c['key'] = '';
            $col = trim((string)($_POST['t_col'] ?? ''));
            $c['col'] = preg_match('/^[A-Za-z0-9_\-]{3,80}$/', $col) ? $col : 'default-solana';
            $c['env'] = ($_POST['t_env'] ?? '') === 'staging' ? 'staging' : 'prod';
            save(TROPHY_CFG, $c);
        });
        go('shop', 'Trophy settings saved.', 'trophies');
    }
    //MC 2026-10-15 embedded wallets: the Phantom app id (public, it ships to every browser), owner only
    if ($do === 'ew-save' && is_owner()) {
        //MC 2026-10-15 Crossmint client key (ck_..., public by design: it ships to browsers, locked to shyonsol.io in the console)
        $bad = false;
        with_lock(function () use (&$bad) { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['ew_on'] = !empty($_POST['ew_on']); $k = trim((string)($_POST['ew_ck'] ?? ''));
            if ($k !== '') { if (preg_match('/^ck_(production|staging)_[A-Za-z0-9]{20,}$/', $k)) $s['ew_ck'] = $k; else $bad = true; }
            unset($s['ew_app']); save(ECOSET, $s); });
        go('shop', $bad ? 'That is not a client key. It starts with ck_production_ (or ck_staging_ for testing).' : 'Email wallets saved.', 'ewallet');
    }
    if ($do === 'trophy-run' && can('shop', 2)) {
        $n = trophy_tick(10, true);
        go('shop', $n ? "Sent or checked $n trophies." : 'Nothing to send right now (no key, nothing waiting, or the waiting ones have no wallet yet).', 'trophies');
    }
    if ($do === 'trophy-retry' && can('shop', 2)) {
        with_lock(function () { $all = load(TROPHIES); foreach ($all as &$r) if ($r['st'] === 'fail' || !empty($r['err'])) { $r['st'] = 'wait'; $r['tries'] = 0; unset($r['err'], $r['next']); } unset($r); save(TROPHIES, $all); });
        go('shop', 'Failed trophies are queued again.', 'trophies');
    }
    if ($do === 'ref-settings') {
        with_lock(function () { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['ref_on'] = !empty($_POST['ref_on']);
            foreach (['ref_koban' => [0, 5000], 'ref_new' => [0, 5000], 'ref_holder' => [0, 10000], 'ref_games' => [1, 50], 'ref_cap' => [0, 500]] as $k => [$lo, $hi]) $s[$k] = max($lo, min($hi, (int)($_POST[$k] ?? 0)));
            save(ECOSET, $s); });
        go('shop', 'Invite rewards saved.');
    }
    if ($do === 'xt-settings') {
        with_lock(function () { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['xt_on'] = !empty($_POST['xt_on']); $s['xt_koban'] = max(0, min(1000, (int)($_POST['xt_koban'] ?? 15))); $s['xt_bonus'] = max(0, min(5000, (int)($_POST['xt_bonus'] ?? 25))); save(ECOSET, $s); });
        go('shop', 'Daily X tasks saved.');
    }
    if ($do === 'xt-revoke') {
        $i = (int)($_POST['i'] ?? -1); $t = (int)($_POST['t'] ?? 0);
        $msg = with_lock(function () use ($i, $t) {
            $all = load(XTASKS); $row = $all['log'][$i] ?? null;
            if (!$row || $row['t'] !== $t) return 'That claim moved. Reload and try again.';
            if (!empty($row['rev'])) return 'Already taken back.';
            $eco = load(ECO); $a = eco_get($eco, $row['pid']);
            eco_credit($a, -$row['k'], 'X task taken back: ' . (XT_POOL[$row['task']]['text'] ?? $row['task']));
            $eco[$row['pid']] = $a; save(ECO, $eco);
            $all['log'][$i]['rev'] = time(); save(XTASKS, $all);
            return 'Took back ' . $row['k'] . ' Koban. The task stays done for that day.';
        });
        go('shop', $msg);
    }
    if ($do === 'xt-free') {
        $hk = strtolower(ltrim(trim((string)($_POST['handle'] ?? '')), '@'));
        $msg = with_lock(function () use ($hk) {
            $all = load(XTASKS); $pid = $all['h'][$hk] ?? null;
            if (!$pid) return 'No player uses @' . $hk . ' for X tasks.';
            unset($all['h'][$hk]); save(XTASKS, $all);
            $eco = load(ECO); if (isset($eco[$pid])) { unset($eco[$pid]['xh']); save(ECO, $eco); }
            return '@' . $hk . ' is free. The player\'s next counted post ties a new X account.';
        });
        go('shop', $msg);
    }
    if ($do === 'payhelp-close') {
        $hid = (string)($_POST['help'] ?? '');
        with_lock(function () use ($hid) { $f = DATA_DIR . '/pay-help.php'; $t = load($f); if (isset($t[$hid])) { $t[$hid]['status'] = 'closed'; $t[$hid]['by'] = me()['username']; $t[$hid]['at'] = time(); save($f, $t); } });
        go('shop', 'Marked as sorted.');
    }
    if ($do === 'order-paid') {
        $oid = (string)($_POST['order'] ?? '');
        $msg = with_lock(function () use ($oid) {
            $orders = load(ORDERS);
            if (!isset($orders[$oid]) || $orders[$oid]['status'] === 'paid') return 'Nothing to do.';
            fulfill($orders, $oid, 'manual:' . gmdate('Y-m-d'));
            return 'Delivered order ' . $oid . ' by hand.';
        });
        go('shop', $msg);
    }
    if ($do === 'order-check') {
        // look the payment up on Solana again, with a signature from the buyer if they sent one
        $oid = (string)($_POST['order'] ?? ''); $sig = trim((string)($_POST['sig'] ?? ''));
        if (preg_match('#solscan\.io/tx/([1-9A-HJ-NP-Za-km-z]+)#', $sig, $mm)) $sig = $mm[1];
        $o = load(ORDERS)[$oid] ?? null;
        if (!$o || $o['status'] === 'paid' || $o['cur'] === 'CARD') go('shop', 'Nothing to check.');
        if (!empty($_POST['late'])) $o['late_ok'] = 1;   //MC 2026-10-11 the admin chose to honour a late payment at the quoted price
        $v = verify_payment($o, $sig ?: ($o['sig'] ?? ''));
        // a payment the buyer pointed to that doesn't carry the order's reference: the admin vouches for the sender
        if (empty($v['paid']) && $sig !== '' && preg_match('/^[1-9A-HJ-NP-Za-km-z]{64,90}$/', $sig)) { $m2 = tx_pays_manual($o, $sig, [], true); if (!empty($m2['paid']) || isset($m2['short']) || isset($m2['late'])) $v = $m2; }
        if (!empty($v['paid'])) {
            $hid = (string)($_POST['help'] ?? '');
            if ($hid !== '') with_lock(function () use ($hid) { $f = DATA_DIR . '/pay-help.php'; $t = load($f); if (isset($t[$hid])) { $t[$hid]['status'] = 'closed'; $t[$hid]['by'] = me()['username']; $t[$hid]['at'] = time(); save($f, $t); } });
            $msg = with_lock(function () use ($oid, $v) {
                $orders = load(ORDERS);
                foreach ($orders as $x => $y) if ($x !== $oid && ($y['proof'] ?? '') === $v['paid']) return 'That payment already paid for order ' . $x . '.';
                if (!empty($v['selfpay'])) $orders[$oid]['selfpay'] = 1;
                fulfill($orders, $oid, $v['paid'], $v);
                return 'Found the payment on Solana and delivered order ' . $oid . '.';
            });
            go('shop', $msg);
        }
        $why = isset($v['self']) ? 'That transaction was sent from the marketing wallet to itself, so nothing was paid.'
            : (isset($v['nopay']) ? 'That transaction is confirmed but sent nothing to the marketing wallet.'
            : (isset($v['dropped']) ? 'Solana has no record of that payment. It was dropped before it landed, so nothing was paid.' : ''));
        if ($why) go('shop', $why);
        $why = isset($v['failed']) ? 'The transaction failed on Solana (' . ($v['why'] ?? '') . '). Nothing reached the marketing wallet.'
            : (isset($v['short']) ? 'A payment was found but it was short: ' . $v['got'] . ' of ' . $o['units'] . ' units.'
            : (isset($v['late']) ? 'A payment was found, but it landed ' . (int)$v['mins'] . ' minutes after the price hold ran out and covers ' . $v['got'] . ' of the ' . $v['need'] . ' units today\'s price needs. Use "Deliver at the quoted price" under Payment help to honour it anyway.'
            : (!empty($v['hint']) ? 'No payment for this order yet. The signature you gave: ' . $v['hint'] . '.'
            : 'No payment for this order on Solana yet' . (($v['wait'] ?? '') === 'rpc' ? ' (Solana could not be reached, try again)' : '') . '.')));
        go('shop', $why);
    }
    if ($do === 'idea-publish') {
        $id = (string)($_POST['id'] ?? ''); $on = !empty($_POST['on']);
        $msg = with_lock(function () use ($id, $on) {
            $ideas = load(IDEAS);
            if (!isset($ideas[$id])) return 'That suggestion is gone.';
            $ideas[$id]['public'] = $on;
            if ($on && $ideas[$id]['status'] === 'new') $ideas[$id]['status'] = 'reviewing';
            save(IDEAS, $ideas);
            @unlink(DATA_DIR . '/cache-ideas-board.php');   //MC 2026-10-13 the public board rebuilds on its next read
            return $on ? 'It\'s on the Ideas board now. It can take up to a minute to show.' : 'Taken off the Ideas board.';
        });
        go('ideas', $msg);
    }
    if ($do === 'idea-translate') {
        $id = (string)($_POST['id'] ?? '');
        $x = with_lock(fn() => load(IDEAS)[$id] ?? null);
        if (!$x) go('ideas', 'That suggestion is gone.');
        $t = idea_translate($id, $x, $x['lang'] ?? 'en');
        if ($t['lang'] === 'en') go('ideas', 'That one is already in English.');
        $_SESSION['flash'] = $t['en'] !== '' ? 'Translated from ' . (TR_NAMES[$t['lang']] ?? $t['lang']) . '.' : "The translation service didn't answer. Try again in a minute.";
        header('Location: ./?tab=ideas#idea-' . rawurlencode($id)); exit;
    }
    if ($do === 'idea-save' || $do === 'idea-delete') {
        $id = (string)($_POST['id'] ?? '');
        $msg = with_lock(function () use ($do, $id) {
            $ideas = load(IDEAS);
            if (!isset($ideas[$id])) return 'That suggestion is gone.';
            if ($do === 'idea-delete') {
                if (!empty($ideas[$id]['file'])) @unlink(IDEA_FILES . '/' . $ideas[$id]['file']);
                unset($ideas[$id]); save(IDEAS, $ideas);
                @unlink(DATA_DIR . '/cache-ideas-board.php');   //MC 2026-10-13
                return 'Suggestion deleted.';
            }
            $st = (string)($_POST['status'] ?? 'new');
            $wasSt = $ideas[$id]['status'] ?? 'new';   //MC 2026-10-13 for the approval post below
            $ideas[$id]['status'] = isset(IDEA_STATUS[$st]) ? $st : 'new';
            $ideas[$id]['public'] = !empty($_POST['public']);
            $ideas[$id]['title'] = mb_substr(trim((string)($_POST['title'] ?? '')), 0, 90);
            $ideas[$id]['ptext'] = mb_substr(trim((string)($_POST['ptext'] ?? '')), 0, 600);
            $ideas[$id]['reply'] = mb_substr(trim((string)($_POST['reply'] ?? '')), 0, 400);
            $ideas[$id]['credit'] = !empty($_POST['credit']) ? ($ideas[$id]['name'] ?: '') : '';
            $ideas[$id]['note'] = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 600);
            save(IDEAS, $ideas);
            @unlink(DATA_DIR . '/cache-ideas-board.php');   //MC 2026-10-13 status and text changes reach the board at once
            //MC 2026-10-13 every status change of a public idea goes to the Telegram chat (it was Planned and Building
            //   only), worded per status, once per idea and status so toggling back and forth never reposts. 'vote' is
            //   the loud one: the chat is asked to go vote on the board.
            if ($ideas[$id]['status'] !== $wasSt && $ideas[$id]['status'] !== 'new' && !empty($ideas[$id]['public']) && function_exists('tg_post')) {
                $stx = $ideas[$id]['status'];
                $ttl = $ideas[$id]['title'] !== '' ? $ideas[$id]['title'] : idea_title($ideas[$id]['text'] ?? '');
                $who = $ideas[$id]['credit'] !== '' ? 'Suggested by <b>' . tg_h($ideas[$id]['credit']) . '</b>.' : 'Suggested by a player.';
                $body = $ideas[$id]['ptext'] !== '' ? "\n" . tg_h(mb_substr($ideas[$id]['ptext'], 0, 300)) : '';
                $rep = $ideas[$id]['reply'] !== '' ? "\n\n" . tg_h(mb_substr($ideas[$id]['reply'], 0, 300)) : '';
                $head = ['reviewing' => "\u{1F440} <b>Under review: ", 'vote' => "\u{1F5F3} <b>Put to a community vote: ", 'planned' => "\u{1F4A1} <b>Idea approved: ",
                    'building' => "\u{1F528} <b>Now building: ", 'shipped' => "\u{2705} <b>Shipped: ", 'declined' => "\u{1F64F} <b>Not for now: "][$stx] ?? '';
                $cta = $stx === 'vote' ? 'Cast your vote' : ($stx === 'shipped' ? 'See it on the board' : 'Vote on the Ideas board');
                if ($head !== '') tg_post('idea', $head . tg_h($ttl) . "</b>" . $body . "\n" . $who . $rep . "\n\n" . tg_link('/updates#ideas', $cta), 'idea:' . $id . ':' . $stx);
            }
            return 'Saved.' . ($ideas[$id]['public'] ? ' It shows on the Ideas board.' : '');
        });
        go('ideas', $msg);
    }
    if ($do === 'hash-tool') {
        $p1 = (string)($_POST['pw1'] ?? ''); $p2 = (string)($_POST['pw2'] ?? '');
        if ($p1 !== $p2) go('guide', 'The two passwords don\'t match. Try again.');
        if (strlen($p1) < 12) go('guide', 'Use at least 12 characters.');
        $_SESSION['hashline'] = "'admin_hash' => '" . password_hash($p1, PASSWORD_BCRYPT) . "',";
        header('Location: ./?tab=guide#g-hash'); exit;
    }
    if ($do === 'tg-save') {
        $msg = with_lock(fn() => tg_locked(function () {   //MC 2026-10-11 also under tg-lock (see tg_locked)
            $c = tg_cfg();
            $tok = trim((string)($_POST['tg_token'] ?? ''));
            // a browser can drop the saved admin password into this box; with a token already saved, ignore anything that isn't one
            if ($tok !== '' && !preg_match('/^\d{5,}:[A-Za-z0-9_-]{30,}$/', $tok) && $c['token'] !== '') $tok = '';
            if ($tok !== '') { if (!preg_match('/^\d{5,}:[A-Za-z0-9_-]{30,}$/', $tok)) return 'That bot token doesn\'t look right. It looks like 123456789:ABC... from @BotFather.'; $c['token'] = $tok; }
            if (!empty($_POST['forget'])) { $c['token'] = ''; $c['chat'] = ''; $c['title'] = ''; $c['design_chat'] = ''; $c['design_title'] = ''; $c['design_topic'] = ''; }
            // the team's Game Design channel: a chat id, @channel, or a link to any message in it (a topic's link sets the topic too)
            if (array_key_exists('design_chat', $_POST)) {
                $dc = trim((string)$_POST['design_chat']); $dt = trim((string)($_POST['design_topic'] ?? ''));
                if (preg_match('~t\.me/c/(\d{5,20})(?:/(\d+))?(?:/(\d+))?~', $dc, $m)) { $dc = '-100' . $m[1]; if (!empty($m[3])) $dt = $m[2]; }
                // a public group's link: t.me/groupname/45, or t.me/groupname/12/345 from inside topic 12
                elseif (preg_match('~(?:https?://)?t\.me/([A-Za-z][A-Za-z0-9_]{4,})(?:/(\d+))?(?:/(\d+))?/?$~', $dc, $m) && $m[1] !== 'c') { $dc = '@' . $m[1]; if (!empty($m[3])) $dt = $m[2]; }
                if ($dc !== '' && !preg_match('/^-?\d{5,20}$|^@[A-Za-z0-9_]{5,}$/', $dc)) return 'The Game Design channel should be a number like -1001234567890, an @channelname, or a link to a message in it.';
                if ($dt !== '' && !preg_match('/^\d{1,10}$/', $dt)) return 'The topic is the number in a topic message link: t.me/c/1234567890/12/345 (here 12). Leave it empty if the group has no topics.';
                if ($dc !== $c['design_chat']) $c['design_title'] = '';
                $c['design_chat'] = $dc; $c['design_topic'] = $dc === '' ? '' : $dt;
                foreach (['art_up', 'art_pub'] as $k) $c['design_on'][$k] = !empty($_POST['ds_' . $k]);
            }
            $chat = trim((string)($_POST['chat'] ?? ''));
            if ($chat !== '') { if (!preg_match('/^-?\d{5,20}$|^@[A-Za-z0-9_]{5,}$/', $chat)) return 'The chat should be a number like -1001234567890 or an @channelname.'; $c['chat'] = $chat; $c['title'] = trim((string)($_POST['title'] ?? $c['title'])); }
            foreach (TG_KINDS as $k => $_) $c['on'][$k] = !empty($_POST['on_' . $k]);
            //MC 2026-10-12 which posts get pinned when they go out
            if (isset($_POST['pins_form'])) { $c['pins'] = []; foreach (TG_KINDS as $k => $_) if (!in_array($k, ['payout', 'burn'], true)) $c['pins'][$k] = !empty($_POST['pin_' . $k]); }
            $c['buy_min'] = max(0, (float)($_POST['buy_min'] ?? 9.99));
            $c['hour_cap'] = max(1, min(60, (int)($_POST['hour_cap'] ?? 8)));
            $app = trim((string)($_POST['app'] ?? ''), " /");
            if (preg_match('~t\.me/[A-Za-z0-9_]+/([A-Za-z0-9_]{3,30})~', $app, $m)) $app = $m[1];   // a pasted t.me link works too
            if ($app !== '' && !preg_match('/^[A-Za-z0-9_]{3,30}$/', $app)) return 'The Mini App short name is the last part of its link, like play in t.me/yourbot/play.';
            $c['app'] = $app;
            $c['dm_on'] = !empty($_POST['dm_on']);
            $c['remind_hour'] = max(0, min(23, (int)($_POST['remind_hour'] ?? 18)));
            $c['remind_min'] = max(1, min(30, (int)($_POST['remind_min'] ?? 2)));
            $c['daily_hour'] = max(0, min(23, (int)($_POST['daily_hour'] ?? 13)));
            save(TGCFG, $c);
            return '';
        }));
        if ($msg) go('telegram', $msg);
        // a new token: point Telegram at the site so the bot answers /start, /daily, /top… and finds its chats
        $j = tg_rehook();
        if ($j !== null && empty($j['ok'])) go('telegram', 'Saved, but Telegram did not accept the bot token: ' . ($j['description'] ?? 'no answer') . '. Check it and paste it again.');
        if (!empty($_POST['test'])) {
            $c = tg_cfg();
            if (!tg_ready($c)) go('telegram', 'Saved. Add the bot token and pick the chat before sending a test.');
            $j = tg_api($c['token'], 'sendMessage', ['chat_id' => $c['chat'], 'parse_mode' => 'HTML', 'text' => "👋 <b>Shy on Solana is connected.</b>\nGame results, the Daily and Weekly wrap-ups and big shop purchases will show up here. " . tg_link('/play', 'Play free')]);
            $msg = !empty($j['ok']) ? 'Saved. A test message is in the chat.' : 'Saved, but Telegram refused the test: ' . ($j['description'] ?? 'no answer') . '. Make sure the bot is in the chat and allowed to post.';
            tg_sent_note([['t' => time(), 'k' => 'test', 'ok' => empty($j['ok']) ? 0 : 1] + (empty($j['ok']) ? ['err' => mb_substr((string)($j['description'] ?? 'no answer from Telegram'), 0, 200)] : [])], []);   //MC 2026-10-11 a test that gets through clears the "last 3 failed" line
            if ($c['design_chat'] !== '') {
                $d = tg_api($c['token'], 'sendMessage', tg_design_to($c) + ['parse_mode' => 'HTML', 'text' => "🎨 <b>Game Design channel connected.</b>\nNew card art will show up here with who uploaded it, and again when it goes live."]);
                $msg .= !empty($d['ok']) ? ' One is in the Game Design channel too.' : ' Telegram refused the Game Design test: ' . ($d['description'] ?? 'no answer') . '. Add the bot to that chat and let it post' . ((string)$c['design_topic'] !== '' ? ', and check the topic number.' : '.');
            }
            go('telegram', $msg);
        }
        go('telegram', 'Telegram settings saved.');
    }
    if ($do === 'tg-release') {
        $c = tg_cfg();
        if (!tg_ready($c)) go('telegram', 'Connect the bot and pick the chat first.');
        $r = tg_release_latest();
        if (!$r) go('telegram', 'No release notes found. Upload the full site zip again.');
        with_lock(function () use ($r) { save(DATA_DIR . '/tg-release.php', ['v' => $r['v'], 't' => time()]); });
        $j = tg_api($c['token'], 'sendMessage', ['chat_id' => $c['chat'], 'text' => tg_release_text($r), 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]]);
        go('telegram', !empty($j['ok']) ? 'Posted "' . $r['title'] . '" to the chat.' : 'Telegram refused: ' . ($j['description'] ?? 'no answer') . '.');
    }
    //MC 2026-10-12 delete the old burn tracker and post a fresh one at the bottom of the chat, pinned (tg_burn_repost)
    if ($do === 'tg-burn') {
        $err = tg_burn_repost();
        go('telegram', $err === '' ? 'Posted a fresh burn tracker at the bottom of the chat and pinned it.' : $err);
    }
    if ($do === 'tg-app') {
        // the Play button next to the message box in the bot's private chat opens the game inside Telegram
        $c = tg_cfg();
        if ($c['token'] === '') go('telegram', 'Save the bot token first.');
        tg_rehook();
        $j = tg_api($c['token'], 'setChatMenuButton', ['menu_button' => ['type' => 'web_app', 'text' => 'Play', 'web_app' => ['url' => TG_SITE . '/play?tgapp=1']]]);
        tg_commands($c['token']);
        go('telegram', !empty($j['ok']) ? 'Done. Open a private chat with the bot: the Play button next to the message box opens the game inside Telegram.' : 'Telegram refused: ' . ($j['description'] ?? 'no answer') . '.');
    }
    if ($do === 'tg-find') {
        $c = tg_cfg();
        if ($c['token'] === '') go('telegram', 'Save the bot token first.');
        $j = tg_api($c['token'], 'getUpdates', ['limit' => 50]);   // only answers before the bot is hooked up
        $found = $c['seen'] ?? [];
        foreach ($j['result'] ?? [] as $u) foreach (['message', 'channel_post', 'my_chat_member'] as $k) if (isset($u[$k]['chat'])) { $ch = $u[$k]['chat']; $found[(string)$ch['id']] = $ch['title'] ?? ($ch['username'] ?? ($ch['first_name'] ?? 'Chat')); }
        $_SESSION['tg_found'] = $found;
        go('telegram', $found ? 'Found ' . count($found) . ' chat(s). Pick yours below.' : 'No chats found yet. In your group, send /start (the bot answers once it\'s hooked up), then press Find my chat again.');
    }
    if ($do === 'tg-pick') {
        $id = (string)($_POST['chat'] ?? ''); $title = (string)($_POST['title'] ?? ''); $design = ($_POST['role'] ?? '') === 'design';
        if (!preg_match('/^-?\d{5,20}$/', $id)) go('telegram', 'Pick a chat from the list.');
        with_lock(fn() => tg_locked(function () use ($id, $title, $design) {   //MC 2026-10-11 also under tg-lock (see tg_locked)
            $c = tg_cfg();
            if ($design) { if ($c['design_chat'] !== $id) $c['design_topic'] = ''; $c['design_chat'] = $id; $c['design_title'] = mb_substr($title, 0, 80); }
            else { $c['chat'] = $id; $c['title'] = mb_substr($title, 0, 80); }
            save(TGCFG, $c);
        }));
        unset($_SESSION['tg_found']);
        go('telegram', ($design ? 'Game Design channel set to ' : 'Chat set to ') . $title . '. Send a test to check the bot can post there.');
    }
    if ($do === 'x-settings') {
        with_lock(function () {
            $s = is_file(ECOSET) ? load(ECOSET) : []; $s['x_links'] = !empty($_POST['x_links']); $s['x_post'] = !empty($_POST['x_post']); $s['x_month_cap'] = max(0, min(100000, (int)($_POST['x_month_cap'] ?? 300)));
            //MC 2026-10-11 automatic win posts, tags, and the hand-tag list
            $s['x_autopost'] = !empty($_POST['x_autopost']); $s['x_auto_day'] = max(1, min(10, (int)($_POST['x_auto_day'] ?? 3)));
            preg_match_all('/[#$][A-Za-z][A-Za-z0-9_]{0,30}/', (string)($_POST['x_tags'] ?? ''), $m); $s['x_tags'] = implode(' ', array_slice(array_values(array_unique($m[0])), 0, 5));
            //MC 2026-10-11 one account per line or comma; a pasted profile link (x.com/name, twitter.com/name) keeps just the
            //   name. Matching every word on the line split a link into @https, @x, @com.
            $kl = [];
            foreach (preg_split('/[\r\n,]+/', (string)($_POST['x_kols'] ?? '')) as $ln) {
                $ln = trim(preg_replace('#^https?://(www\.)?(x|twitter)\.com/#i', '', trim($ln)));
                if (preg_match('/^@?([A-Za-z0-9_]{1,15})(?:[\/?]|$)/', $ln, $mm)) $kl[] = '@' . $mm[1];
            }
            $s['x_kols'] = implode("\n", array_slice(array_values(array_unique($kl)), 0, 200));
            $s['x_kol_share'] = !empty($_POST['x_kol_share']);   //MC 2026-10-12
            $al = []; foreach (preg_split('/[\s,]+/', (string)($_POST['x_always'] ?? '')) as $hh) { $hh = '@' . ltrim(trim($hh), '@'); if (preg_match('/^@[A-Za-z0-9_]{1,15}$/', $hh)) $al[] = $hh; }
            $s['x_always'] = implode(' ', array_slice(array_unique($al), 0, 3)); $s['x_always_auto'] = !empty($_POST['x_always_auto']);
            save(ECOSET, $s);
        });
        go('players', 'X posting settings saved.');
    }
    //MC 2026-10-09 team email: where it goes, which alerts, the report hour; a test; a report sent on demand
    if ($do === 'mail-save') {
        $raw = trim((string)($_POST['to'] ?? ''));
        $list = array_values(array_filter(array_map('trim', preg_split('/[,;\s]+/', $raw))));
        foreach ($list as $e) if (!filter_var($e, FILTER_VALIDATE_EMAIL)) go('email', $e . " doesn't look like an email address.");
        $off = []; foreach (array_keys(MAIL_TYPES) as $k) if (empty($_POST['on'][$k])) $off[$k] = 1;
        $hour = max(0, min(23, (int)($_POST['hour'] ?? 12)));
        $tz = in_array($_POST['tz'] ?? '', DateTimeZone::listIdentifiers(), true) ? $_POST['tz'] : 'America/New_York';
        //MC 2026-10-12 the grid: which kinds each person gets (rp[i] = their address, rt[i][kind] = ticked)
        $route = null;
        if (isset($_POST['rp'])) { $route = []; foreach ((array)$_POST['rp'] as $i => $em) { $em = strtolower(trim((string)$em)); if (!filter_var($em, FILTER_VALIDATE_EMAIL)) continue; $route[$em] = ['_k' => array_keys(MAIL_TYPES)]; foreach (array_keys(MAIL_TYPES) as $k) if (!empty($_POST['rt'][$i][$k])) $route[$em][$k] = 1; } }
        with_lock(function () use ($list, $off, $hour, $tz, $route) { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['mail_to'] = implode(', ', $list); $s['mail_off'] = $off; $s['mail_hour'] = $hour; $s['mail_tz'] = $tz; if ($route !== null) $s['mail_route'] = $route; save(ECOSET, $s); });
        go('email', $list || mail_people() ? 'Saved. Each kind of email now goes to the people ticked for it in the grid.' : 'Saved. With no address, team emails go to the Ideas address, or nowhere if that is empty too.');
    }
    if ($do === 'mail-test') {
        if (!mail_people()) go('email', 'Add an address first.');
        $ok = mail_send('test', '✉️ Test from the shyonsol.io admin', 'Test', 'Team email works', 'If you can read this, sales, prize and report emails will reach you here. Check that it didn\'t land in spam, and mark it Not spam if it did.',
            [['facts' => [['Sent by', h($ME['name'] ?? 'an admin')], ['Sent at', mh(m_when(time()))], ['Going to', mh(implode(', ', array_keys(mail_people())))]]], ['callout' => 'Sales, $SHY bought on the site, prize winners and payment problems arrive the moment they happen. The daily report arrives every morning and the weekly one on Mondays.', 'tone' => 'good']],
            [['Email settings', mail_site() . '/admin/?tab=email']]);
        go('email', $ok ? 'Test sent. It should arrive within a few minutes; check spam if it doesn\'t.' : 'The server could not send it. Check Logs, Email errors.');
    }
    if ($do === 'mail-report') {
        if (!mail_people()) go('email', 'Add an address first.');
        $which = ($_POST['which'] ?? '') === 'week' ? 'week' : 'daily';
        if ($which === 'week') { $mon = gmdate('Y-m-d', strtotime('monday last week')); $r = report_build($mon, gmdate('Y-m-d', strtotime($mon . ' UTC') + 6 * 86400), 'week'); }
        else { $y = gmdate('Y-m-d', time() - 86400); $r = report_build($y, $y, 'daily'); }
        $ok = mail_send($which, ...$r);
        go('email', $ok ? ($which === 'week' ? 'Last week\'s report is on its way.' : 'Yesterday\'s report is on its way.') : 'The server could not send it. Check Logs, Email errors.');
    }
    if ($do === 'idea-email') {
        $to = trim((string)($_POST['email'] ?? ''));
        if ($to !== '' && !filter_var($to, FILTER_VALIDATE_EMAIL)) go('ideas', "That doesn't look like an email address.");
        with_lock(function () use ($to) { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['idea_email'] = $to; save(ECOSET, $s); });
        if (!empty($_POST['test']) && $to !== '') {
            $ok = idea_email('test', ['name' => 'Admin', 'x' => '', 'wallet' => '', 'cat' => 'other', 'text' => "This is a test from the admin. If you can read this, new suggestions will reach you here.", 'contact' => '', 'page' => '/admin', 'file' => '']);
            go('ideas', $ok ? "Saved. A test email is on its way to $to. Check spam if it doesn't show up in a few minutes." : 'Saved, but the server could not send the test email. Check Logs.');
        }
        go('ideas', $to === '' ? 'Saved. Suggestions will only show here, with no email.' : "Saved. New suggestions go to $to.");
    }
    if ($do === 'clear-log') {
        $f = (string)($_POST['log'] ?? '');
        if (isset(LOGS[$f])) @file_put_contents(DATA_DIR . '/' . $f, '');
        go('logs', 'Log cleared.');
    }
    //MC 2026-10-11 Admin > Telegram: send the last weekly results post or the last prize payout post again (after the bot
    //   was kicked, or the chat missed it). It goes through the normal queue, so it's retried if Telegram fails again, and a
    //   payout post is pinned like the first time. The post's own switch still has to be on.
    //MC 2026-10-12 the Shogun boss bot: on or off, the Koban a win pays and how often, its edge, think time, matches a day
    if ($do === 'boss-settings') {
        $num = fn($k, $min, $max) => max($min, min($max, (int)($_POST[$k] ?? 0)));
        $new = ['boss_on' => !empty($_POST['boss_on']), 'boss_koban' => $num('boss_koban', 0, 1000000), 'boss_per' => ($_POST['boss_per'] ?? '') === 'week' ? 'week' : 'day',
            'boss_edge' => $num('boss_edge', 0, 5), 'boss_think' => $num('boss_think', 200, 3500), 'boss_games' => $num('boss_games', 1, 200)];
        with_lock(function () use ($new) { $s = is_file(ECOSET) ? load(ECOSET) : []; $s = $new + $s; save(ECOSET, $s); });
        audit('boss-settings', $new);
        go('rewards', $new['boss_on'] ? 'Saved. New boss matches use these settings; matches already running keep theirs.' : 'Saved, and the Shogun is OFF: players can\'t start boss matches. Tick "The Shogun takes challenges" and save to turn it back on.', 'boss');
    }
    if ($do === 'chat-settings') {   //MC 2026-10-12 live chat on or off
        with_lock(function () { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['live_chat'] = !empty($_POST['live_chat']); save(ECOSET, $s); });
        audit('chat-settings', ['on' => !empty($_POST['live_chat'])]);
        go('players', !empty($_POST['live_chat']) ? 'Live chat is on.' : 'Live chat is off. Players see "Chat is off for now".', 'livechat');
    }
    //MC 2026-10-12 Admin > Shop > Shop prices: %s for the whole shop, each kind and each rarity, and a price typed in for
    //   any one thing. See shop_px() in api/collection.php.
    if ($do === 'shop-prices') {
        $msg = with_lock(function () {
            if (!empty($_POST['reset'])) { save(SHOP_PRICES, ['all' => 100, 'slot' => [], 'rarity' => [], 'fin' => 100, 'goods' => 100, 'fixed' => [], 'at' => time(), 'by' => me()['username']]); return 'Every price is back to the price in the code.'; }
            $pct = function ($v) { $v = trim((string)$v); if ($v === '') return 100; $n = (float)$v; return $n >= 10 && $n <= 1000 ? round($n, 1) : null; };
            $p = ['all' => $pct($_POST['all'] ?? ''), 'fin' => $pct($_POST['fin'] ?? ''), 'goods' => $pct($_POST['goods'] ?? ''), 'slot' => [], 'rarity' => [], 'fixed' => [], 'at' => time(), 'by' => me()['username']];
            foreach ((array)($_POST['slot'] ?? []) as $k => $v) if (preg_match('/^[a-z]{2,10}$/', (string)$k)) { $x = $pct($v); if ($x === null) return 'Percentages go from 10 to 1000 (100 = the price in the code).'; if ($x != 100) $p['slot'][$k] = $x; }
            foreach ((array)($_POST['rar'] ?? []) as $k => $v) if (in_array($k, ['rare', 'epic', 'legendary', 'mythic'], true)) { $x = $pct($v); if ($x === null) return 'Percentages go from 10 to 1000 (100 = the price in the code).'; if ($x != 100) $p['rarity'][$k] = $x; }
            if (in_array(null, [$p['all'], $p['fin'], $p['goods']], true)) return 'Percentages go from 10 to 1000 (100 = the price in the code).';
            foreach ((array)($_POST['fix'] ?? []) as $k => $v) {
                $v = trim(str_replace([',', ' '], '', (string)$v)); if ($v === '') continue;
                if (!preg_match('/^(item|fin|good):[a-z0-9_]{1,40}$/', (string)$k)) continue;
                if (!ctype_digit($v) || (int)$v < 10 || (int)$v > 1000000) return 'A price typed in should be a whole number of Koban from 10 to 1,000,000.';
                $p['fixed'][$k] = (int)$v;
            }
            save(SHOP_PRICES, $p);
            return 'Prices saved. The shop shows them right away' . ($p['fixed'] ? ', with ' . count($p['fixed']) . ' set by hand' : '') . '.';
        });
        audit('shop-prices', ['all' => $_POST['all'] ?? '', 'reset' => !empty($_POST['reset'])]);
        go('shop', $msg, 'shop-prices');
    }
    //MC 2026-10-12 Admin > Telegram, Messages sent: pin, unpin, change or delete a post the bot made, or send it again
    if ($do === 'tg-msg') {
        $id = preg_replace('/\D/', '', (string)($_POST['id'] ?? '')); $op = (string)($_POST['op'] ?? '');
        $all = tg_posts(); $r = $all[$id] ?? null;
        if (!$r) go('telegram', 'That post isn\'t in the list any more.', 'tg-posts');
        if ($op === 'resend') {
            $c = tg_cfg();
            $j = tg_send_now($r['k'] ?: 'other', (string)$r['h'], tg_pin_on($c, $r['k'] ?: 'other'));
            audit('tg-msg', ['op' => 'resend', 'k' => $r['k']]);
            go('telegram', !empty($j['ok']) ? 'Sent again as a new post.' : 'Telegram refused: ' . ($j['description'] ?? 'no answer') . '.', 'tg-posts');
        }
        if (!in_array($op, ['delete', 'pin', 'unpin', 'edit'], true)) go('telegram', 'Unknown action.', 'tg-posts');
        $msg = tg_post_act($id, $op, (string)($_POST['html'] ?? ''));
        audit('tg-msg', ['op' => $op, 'k' => $r['k']]);
        go('telegram', $msg, 'tg-posts');
    }
    // a post from before the list existed: by its message link
    if ($do === 'tg-link') {
        $mid = tg_msg_from_link($_POST['link'] ?? ''); $op = (string)($_POST['op'] ?? '');
        if (!$mid) go('telegram', 'Paste the message link: in Telegram, right-click the post and pick Copy Message Link.', 'tg-posts');
        if (!in_array($op, ['delete', 'pin', 'unpin'], true)) go('telegram', 'Unknown action.', 'tg-posts');
        $msg = tg_post_act((string)$mid, $op);
        audit('tg-link', ['op' => $op, 'msg' => $mid]);
        go('telegram', $msg, 'tg-posts');
    }
    //MC 2026-10-12 Admin > Rewards, Fix a final week: take League points off a player after the week froze, rebuild the
    //   prize lists, and post the corrected results (taking the old post down and pinning the new one)
    if ($do === 'lg-week') {
        $wk = (string)($_POST['wk'] ?? ''); $op = (string)($_POST['op'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}$/', $wk)) go('rewards', 'Pick a week.', 'lgfix');
        if ($op === 'adjust' || $op === 'rebuild') {
            $msg = with_lock(function () use ($wk, $op) {
                $rw = load(REWARDS); if (!isset($rw['weeks'][$wk])) return 'That week isn\'t final yet.';
                if (league_week_paid($rw, $wk)) return 'Part of that week is already paid, so it can\'t be changed here.';
                if ($op === 'adjust') {
                    $tag = preg_replace('/[^a-f0-9]/', '', (string)($_POST['tag'] ?? '')); $pts = (int)($_POST['pts'] ?? 0); $n = max(0, (int)($_POST['n'] ?? 0));
                    $why = trim(mb_substr((string)($_POST['why'] ?? ''), 0, 120));
                    if (strlen($tag) !== 6 || $pts === 0) return 'Pick the player and how many points to take off (a minus number gives points back).';
                    if ($why === '') return 'Add a short reason, so the team can see why later.';
                    league_week_adjust($rw, $wk, $tag, $pts, $n, $why . ' (' . me()['username'] . ')');
                }
                $rb = league_week_rebuild($rw, $wk, load(PLAYERS));
                if (!$rb['ok']) return $rb['msg'];
                save(REWARDS, $rw); @unlink(DATA_DIR . '/cache-rewards.php');
                return 'Week ' . (int)substr($wk, 5) . ' corrected. ' . $rb['msg'];
            });
            audit('lg-week', ['op' => $op, 'wk' => $wk]);
            go('rewards', $msg, 'lgfix');
        }
        if ($op === 'post') {
            $rw = load(REWARDS); $w = $rw['weeks'][$wk] ?? null;
            if (!$w || empty($w['league'])) go('rewards', 'Nothing to post for that week.', 'lgfix');
            $c = tg_cfg(); if (!tg_ready($c)) go('rewards', 'Connect the Telegram bot first (Admin > Telegram).', 'lgfix');
            $note = '';
            if (!empty($_POST['del_old'])) {
                $old = 0;
                foreach (array_reverse(tg_posts(), true) as $pid => $pr) if (($pr['k'] ?? '') === 'weekly' && empty($pr['del']) && (($pr['o'] ?? '') === 'week:' . $wk || strpos((string)($pr['h'] ?? ''), 'week ' . substr($wk, 5)) !== false)) { $old = (int)$pid; break; }
                $link = tg_msg_from_link($_POST['old_link'] ?? '');
                if ($link) $old = $link;
                if ($old) { $tp = tg_posts(); if (!isset($tp[(string)$old])) tg_post_log(['id' => (string)$old, 'ids' => [$old], 'k' => 'weekly', 'o' => 'week:' . $wk, 't' => 0, 'h' => '', 'photo' => '', 'chat' => $c['chat'], 'pin' => 0]); $note = ' ' . tg_post_act((string)$old, 'delete'); }
                else $note = ' The old post isn\'t in the list (it went out before posts were kept): paste its link to take it down, or delete it by hand in Telegram.';
            }
            $j = tg_send_now('weekly', tg_weekly_html($wk, $w['league'], $w['pool']['total'] ?? 0, true), !empty($_POST['pin']), 'fix:' . $wk);
            audit('lg-week', ['op' => 'post', 'wk' => $wk]);
            go('rewards', (!empty($j['ok']) ? 'The corrected results are in the chat' . (!empty($_POST['pin']) ? ' and pinned.' : '.') : 'Telegram refused: ' . ($j['description'] ?? 'no answer') . '.') . $note, 'lgfix');
        }
        go('rewards', 'Unknown action.', 'lgfix');
    }
    if ($do === 'tg-resend') {
        $kind = ($_POST['kind'] ?? '') === 'payout' ? 'payout' : 'weekly';
        $c = tg_cfg();
        if (!tg_ready($c)) go('telegram', 'Connect the bot and pick the chat first.');
        if (!tg_on($c, $kind)) go('telegram', 'Switch on "' . TG_KINDS[$kind] . '" under What gets posted first.');
        $last = tg_health()['last'][$kind] ?? null;
        $html = (string)($last['h'] ?? '');
        if ($html === '' && $kind === 'weekly') {
            // posted before this was recorded: rebuilt from the newest final week
            $rw = load(REWARDS); $wks = array_keys($rw['weeks'] ?? []); rsort($wks);
            foreach ($wks as $wk) if (!empty($rw['weeks'][$wk]['league'])) { $html = tg_weekly_html($wk, $rw['weeks'][$wk]['league'], $rw['weeks'][$wk]['pool']['total'] ?? 0); break; }
        }
        if ($html === '') go('telegram', $kind === 'payout' ? 'No payout post to send again yet. Payout posts are kept from this update on.' : 'No weekly results to send yet.');
        if ($kind === 'payout') tg_payout($html, 'resend:payout:' . time()); else tg_post('weekly', $html, 'resend:weekly:' . time());
        go('telegram', ($kind === 'payout' ? 'The last payout post' : 'The last weekly results post') . ' is on its way to the chat. If it fails, it shows in the line at the top of this page.');
    }
    //MC 2026-10-11 Admin > Shop: run the nightly payment check now
    if ($do === 'recon-run') {
        $r = recon_run(true);
        if (!$r) go('shop', 'The check is already running. Give it a minute.');
        go('shop', 'Checked ' . $r['checked'] . ' open ' . ($r['checked'] === 1 ? 'order' : 'orders') . ' on Solana. Delivered ' . $r['delivered'] . ', ' . $r['listed'] . ' to look at.' . (!empty($r['rpc_down']) ? ' Solana could not be reached for ' . $r['rpc_down'] . ' of them; try again later.' : ''));
    }
    //MC 2026-10-11 Admin > Rewards, owners only: put back League and Season points lost to bug #35 (see lg_recover_plan)
    if ($do === 'lg-recover') {
        if (!is_owner()) go('rewards', 'Only an owner can do this.');
        $f = basename((string)($_POST['f'] ?? ''));
        $plan = lg_recover_apply($f);
        if ($plan === null) go('rewards', 'Backup not found.');
        audit('lg-recover-done', ['f' => $f, 'n' => count($plan), 'rows' => array_map(fn($r) => mb_substr($r['name'], 0, 20) . ' ' . substr($r['pid'], 0, 6) . (isset($r['lg']) ? ' league ' . (int)$r['lg'][1] . '>' . $r['lg'][2]['pts'] : '') . (isset($r['sg']) ? ' season ' . (int)$r['sg'][1] . '>' . $r['sg'][2]['pts'] : ''), array_values(array_slice($plan, 0, 60)))]);
        go('rewards', $plan ? 'Put back League points for ' . count($plan) . ' ' . (count($plan) === 1 ? 'player' : 'players') . ' from ' . str_replace(['players-', '.php'], '', $f) . '. Nothing was lowered. It\'s in the activity log (Team tab).' : 'Nothing to put back: nobody has fewer League or Season points now than in that backup.');
    }
    if ($do === 'restore') {
        $f = basename((string)($_POST['f'] ?? ''));
        if (!preg_match('/^players-\d{4}-(\d{2}-\d{2}|W\d{2})\.php$/', $f) || !is_file(BACKUPS . '/' . $f)) go('backups', 'Backup not found.');
        //MC 2026-10-11 weekly copies can be restored too. The copy goes to a temp file first and is renamed into place, so
        //   nobody reads half a file (that showed up as a 503 for players loading the boards during a restore), and the
        //   cached boards are dropped so they show the restored scores straight away. A copy that isn't readable is refused.
        if (!is_array(load(BACKUPS . '/' . $f)) || !load(BACKUPS . '/' . $f)) go('backups', 'That backup can\'t be read, so nothing was changed.');
        $msg = with_lock(function () use ($f) {
            if (!backup_copy(PLAYERS, BACKUPS . '/players-before-restore-' . gmdate('Ymd-His') . '.php')) return 'Could not save the current scores first, so nothing was changed.';
            if (!backup_copy(BACKUPS . '/' . $f, PLAYERS)) return 'The restore didn\'t go through. The scores are as they were.';
            $memo = &load_memo(); unset($memo[PLAYERS]);
            foreach (glob(DATA_DIR . '/cache-board-*.php') ?: [] as $c) @unlink($c);
            @unlink(DATA_DIR . '/cache-rewards.php');
            return 'Restored scores from ' . str_replace(['players-', '.php'], '', $f) . '. The scores from just before are saved as a backup too.';
        });
        go('backups', $msg);
    }
    go('overview');
}

//MC 2026-10-12 the player picker on Give Koban or items and Award Koban: matches for what's typed so far (name, the
//   6-letter id or a wallet), best players first. Only for admins who can give Koban.
if (isset($_GET['pq'])) {
    header('Content-Type: application/json; charset=utf-8');
    if (!can('gifts')) { echo '{"ok":false}'; exit; }
    $q = strtolower(trim((string)$_GET['pq'])); $q = preg_replace('#^.*/p/#', '', $q); $q2 = str_replace('_', ' ', $q);
    $out = [];
    if (mb_strlen($q) >= 1) {
        $pl = load(PLAYERS); $hol = load(HOLDERS); $hit = [];
        foreach ($pl as $pid => $p) {
            $n = strtolower((string)($p['name'] ?? '')); if ($n === '') continue;
            $w = strtolower((string)($hol[$pid]['wallet'] ?? ''));
            $sc = $n === $q2 ? 0 : (strpos($n, $q2) === 0 ? 1 : (strpos($n, $q2) !== false ? 2 : (strpos($pid, $q) === 0 ? 1 : ($w !== '' && strlen($q) >= 4 && strpos($w, $q) === 0 ? 1 : 9))));
            if ($sc < 9) $hit[] = [$sc, -(int)($p['points'] ?? 0), $pid, $p];
        }
        usort($hit, fn($a, $b) => [$a[0], $a[1]] <=> [$b[0], $b[1]]);
        foreach (array_slice($hit, 0, 12) as [, , $pid, $p]) $out[] = ['n' => $p['name'], 'id' => substr($pid, 0, 6), 'pts' => (int)($p['points'] ?? 0), 'g' => (int)($p['games'] ?? 0), 'h' => !empty($p['holder'])];
    }
    echo json_encode(['ok' => true, 'p' => $out]); exit;
}

// ---------- pages ----------
$tab = (string)($_GET['tab'] ?? 'overview');
$ideaNew = count(array_filter(with_lock(fn() => load(IDEAS)), fn($x) => ($x['status'] ?? '') === 'new'));
$helpOpen = count(array_filter(load(DATA_DIR . '/pay-help.php'), fn($x) => ($x['status'] ?? '') === 'open'));
// every tab: [label, page title, one-line description, icon, group, guide section]
$TABS = [
    'overview' => ['Overview', 'Overview', 'The numbers at a glance and a health check of the setup.', 'grid', 'Run the game', 'overview'],
    'ideas' => ['Ideas', 'Ideas', 'Player suggestions, the public Ideas board and the email alerts.', 'bulb', 'Run the game', 'ideas'],
    'players' => ['Players', 'Players', 'Rename, remove and combine players, review names, and X posting.', 'users', 'Run the game', 'players'],
    'fairplay' => ['Fair Play', 'Fair Play', 'Accounts that keep playing together, share a network or never attack each other. Strike a match from the League.', 'shield', 'Run the game', 'players'],
    'tourneys' => ['Tournaments', 'Tournaments', 'Schedule knockout tournaments, follow the bracket and pay the winners.', 'flag', 'Run the game', 'tourneys'],
    'art' => ['Card art', 'Card art', 'Give any card new art: upload, set the focus, preview it like players see it, then publish.', 'image', 'Run the game', 'art'],
    'telegram' => ['Telegram', 'Telegram', 'Post games, the daily and weekly wrap-ups and big purchases to the $SHY chat.', 'send', 'Run the game', 'telegram'],
    'shop' => ['Shop', 'Shop', 'Sales, orders, payment checks and giving Koban or items.', 'bag', 'Money', 'shop'],
    'rewards' => ['Rewards', 'Rewards', 'Pay prize winners, set prize pools and holder perks, run events.', 'trophy', 'Money', 'rewards'],
    'weekly' => ['Weekly', 'Weekly boards', 'Each week\'s final board, with CSV downloads.', 'cal', 'Boards', 'boards'],
    'daily' => ['Daily', 'Daily Challenge', 'Who played each day\'s Daily Challenge.', 'sun', 'Boards', 'boards'],
    'holders' => ['Holders', 'Holders', 'Connected wallets and the Shadows they hold.', 'gem', 'Boards', 'boards'],
    'live' => ['Live rooms', 'Live rooms', 'Live matches running now. Close one only if it looks stuck.', 'live', 'Boards', 'boards'],
    'email' => ['Email', 'Email', 'Alerts for sales and prizes, the daily and weekly reports, and every email sent.', 'mail', 'System', 'system'],
    'logs' => ['Logs', 'Logs', 'Problems the site recorded. Most should stay empty.', 'log', 'System', 'system'],
    'backups' => ['Backups', 'Backups', 'Daily copies of the data for 14 days and weekly copies for 8 weeks, and a download of everything.', 'safe', 'System', 'system'],
    'deploy' => ['Deploy', 'Deploy an update', 'Upload a release zip and the server swaps the site files itself.', 'safe', 'System', 'system'],   //MC 2026-10-13
    'team' => ['Team', 'Team', 'Admins, what each one can see and change, and a log of every sign-in and change.', 'shield', 'System', 'team'],
    'guide' => ['Guide', 'How-to guide', 'Everything the admin can do, step by step.', 'book', 'Help and account', 'start'],
    'account' => ['My account', 'My account', 'Your details, your password and your access.', 'user', 'Help and account', 'team'],
];
// which access each tab needs to be seen (null = everyone)
const TAB_AREA = ['overview' => 'overview', 'ideas' => 'ideas', 'players' => 'players', 'fairplay' => 'players', 'shop' => 'shop', 'rewards' => ['rewards', 'payouts'], 'weekly' => 'boards', 'daily' => 'boards',
    'holders' => 'boards', 'live' => 'boards', 'telegram' => 'telegram', 'art' => 'art', 'tourneys' => 'tourney', 'email' => 'overview', 'logs' => 'logs', 'backups' => 'backups', 'deploy' => 'backups', 'team' => 'team', 'guide' => null, 'account' => null];   //MC 2026-10-13 deploy rides on backups access; the page itself takes an owner
function tab_ok($k) { $a = TAB_AREA[$k] ?? null; if ($a === null) return true; foreach ((array)$a as $x) if (can($x)) return true; return false; }
foreach (array_keys($TABS) as $k) if (!tab_ok($k)) unset($TABS[$k]);
$ideaNew = count(array_filter(with_lock(fn() => load(IDEAS)), fn($x) => ($x['status'] ?? '') === 'new'));
$tabs = array_map(fn($t) => $t[0], $TABS);
//MC 2026-10-13 pages (nav.php): ?p=payouts picks the page and its tab; an old ?tab= link lands on that tab's main page
$PAGES = admin_pages_ok();
$pg = (string)($_GET['p'] ?? '');
if (isset($PAGES[$pg])) $tab = $PAGES[$pg][5];
else { if (!isset($tabs[$tab])) $tab = array_key_first($TABS); $pg = admin_main_page($tab, $PAGES) ?? ''; }
if (!isset($PAGES[$pg])) { $pg = array_key_first($PAGES); $tab = $PAGES[$pg][5]; }
$PG = $PAGES[$pg];
//MC 2026-10-09 Admin > Email: see any team email exactly as it arrives, built from the live data
if ($tab === 'email' && isset($_GET['preview'])) {
    $pv = mail_preview((string)$_GET['preview']);
    header('Content-Type: text/html; charset=utf-8');
    echo $pv ? $pv[1] : '<p style="font:15px Arial;padding:30px">Nothing to show yet for that email (no data of that kind so far).</p>';
    exit;
}
if (!empty($ME['key']) && !team() && $tab === 'overview') $_SESSION['flash'] = $_SESSION['flash'] ?? 'Welcome. Set up personal sign-ins for your team on the Team page, starting with your own owner account.';
$flash = $_SESSION['flash'] ?? ''; unset($_SESSION['flash']);
[$players, $holders, $reg, $daily, $weeks] = with_lock(function () { $pl = load(PLAYERS); archive_weeks($pl); rewards_freeze($pl); return [$pl, load(HOLDERS), load(SHADOWREG), load(DAILY), load(WEEKS)]; });

$inbox = admin_inbox($players, $ideaNew, $helpOpen);
head_html($PG[1] . ' · Shy admin');
$ICONS = ['flag' => '<path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/>', 'image' => '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>', 'send' => '<path d="M21 3 3 10.5l7 2.5 2.5 7L21 3Z"/><path d="m10 13 4.5-4.5"/>', 'grid' => '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    'bulb' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3Z"/>',
    'users' => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.6 3.4-5.5 6.5-5.5s5.7 1.9 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c1.9.7 3.1 2.4 3.5 5.2"/>',
    'bag' => '<path d="M5 8h14l-1 12H6L5 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
    'trophy' => '<path d="M8 4h8v5a4 4 0 0 1-8 0V4Z"/><path d="M8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 13v4M8 21h8M9 17h6"/>',
    'cal' => '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    'sun' => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.4 1.4M17.6 17.6 19 19M5 19l1.4-1.4M17.6 6.4 19 5"/>',
    'gem' => '<path d="M6 3h12l4 6-10 12L2 9l4-6Z"/><path d="M2 9h20M12 21 8 9l4-6 4 6-4 12"/>',
    'live' => '<circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8 8 0 0 0 0 11.4M17.7 6.3a8 8 0 0 1 0 11.4"/>',
    'log' => '<path d="M6 3h9l4 4v14H6V3Z"/><path d="M14 3v5h5M9 13h7M9 17h7"/>',
    'mail' => '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
    'safe' => '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="12" cy="12" r="3.5"/><path d="M12 8.5v1M7 20v1M17 20v1"/>',
    'shield' => '<path d="M12 3 4 6v6c0 4.5 3.4 8.3 8 9 4.6-.7 8-4.5 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
    'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
    'book' => '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5v-17Z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>',
    'home' => '<path d="m3 11 9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>', 'wallet' => '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/><path d="M6 6 16 3l1 3"/>',
    'wrench' => '<path d="M14.7 6.3a4 4 0 0 0 5 5L21 13l-8 8-3-3 8-8-1.3-1.3a4 4 0 0 1-5-5L14 2"/><path d="M14.7 6.3 17.5 3.5"/>', 'receipt' => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
    'chat' => '<path d="M4 5h16v11H9l-5 4V5Z"/><path d="M8 10h8M8 13h5"/>', 'house' => '<path d="M3 21h18M5 21V10l7-6 7 6v11"/><path d="M10 21v-6h4v6"/>', 'undo' => '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
    'chart' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>', 'store' => '<path d="M4 9 5.5 4h13L20 9M4 9v11h16V9M4 9h16"/><path d="M4 9a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0M10 20v-5h4v5"/>',
    'drop' => '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Z"/><path d="M9.5 15a2.5 2.5 0 0 0 2.5 2.5"/>', 'tag' => '<path d="M3 12V4h8l10 10-8 8L3 12Z"/><circle cx="7.5" cy="8.5" r="1.5"/>', 'gift' => '<rect x="3" y="8" width="18" height="5" rx="1"/><path d="M5 13v8h14v-8M12 8v13M12 8S10 3 7.5 4 9 8 12 8Zm0 0s2-5 4.5-4S15 8 12 8Z"/>',
    'spark' => '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/>', 'x' => '<path d="M4 4l16 16M20 4 4 20"/>', 'pulse' => '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    'list' => '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>', 'key' => '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M14 9l2 2"/>', 'box' => '<path d="M3 7l9-4 9 4v10l-9 4-9-4V7Z"/><path d="m3 7 9 4 9-4M12 11v10"/>',
    'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', 'bell' => '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4l2-2Z"/><path d="M10 20a2 2 0 0 0 4 0"/>', 'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
    'chev' => '<path d="m6 9 6 6 6-6"/>', 'ext' => '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>', 'out' => '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>'];
$ic = fn($k) => '<svg viewBox="0 0 24 24" aria-hidden="true">' . ($ICONS[$k] ?? '') . '</svg>';
//MC 2026-10-13 the new frame. Desktop: a sidebar of pages in groups (each group folds away), a top bar with where you
//   are, search (Ctrl K or /) and Needs you. Phones: the top bar keeps search and Needs you, the menu button slides the
//   sidebar in over the page. The page's own content is unchanged below the header.
$badge = []; foreach ($inbox as $it) { if (preg_match('/^(\d[\d,]*)/', $it[1], $m)) $badge[$it[3]] = ($badge[$it[3]] ?? 0) + (int)str_replace(',', '', $m[1]); elseif ($it[0] !== 'info') $badge[$it[3]] = $badge[$it[3]] ?? -1; }
$needN = count(array_filter($inbox, fn($x) => $x[0] !== 'info'));
$navJs = []; foreach ($PAGES as $k => $p) $navJs[$k] = ['l' => $p[0], 't' => $p[1], 'd' => $p[2], 'g' => ADMIN_GROUPS[$p[4]], 'tab' => $p[5], 's' => $p[6], 'main' => ($p[9] ?? '') === 'main' || admin_main_page($p[5], $PAGES) === $k, 'guide' => $p[7]];
echo '<a class="skip" href="#main">Skip to the page</a><div class="app"><aside class="side" id="side" aria-label="Admin pages"><div class="side-top"><a class="brand" href="./"><span class="seal">管</span><span><b>Shy admin</b><small>shyonsol.io</small></span></a>' .
    '<button type="button" class="iconbtn side-x" data-side-close aria-label="Close the menu">' . $ic('x') . '</button></div>' .
    '<button type="button" class="sk" data-palette>' . $ic('search') . '<span>Search</span><kbd>Ctrl K</kbd></button><nav class="snav" id="snav">';
$byG = []; foreach ($PAGES as $k => $p) $byG[$p[4]][$k] = $p;
foreach (ADMIN_GROUPS as $gk => $gl) {
    if (empty($byG[$gk])) continue;
    $links = '';
    foreach ($byG[$gk] as $k => $p) {
        $b = $badge[$k] ?? 0;
        $links .= '<a href="?p=' . $k . '" data-p="' . $k . '"' . ($k === $pg ? ' class="on" aria-current="page"' : '') . '>' . $ic($p[3]) . '<span>' . h($p[0]) . '</span>' . ($b > 0 ? '<i class="count">' . ($b > 99 ? '99+' : $b) . '</i>' : ($b < 0 ? '<i class="dot" aria-label="needs a look"></i>' : '')) . '</a>';
    }
    if ($gk === '') { echo '<div class="sg sg-top">' . $links . '</div>'; continue; }
    echo '<div class="sg" data-g="' . $gk . '"><button type="button" class="sgh" aria-expanded="true"><span>' . h($gl) . '</span>' . $ic('chev') . '</button><div class="sgl">' . $links . '</div></div>';
}
echo '</nav><div class="sfoot"><a class="meline" href="?p=account"><span class="av">' . h(mb_strtoupper(mb_substr($ME['name'], 0, 1))) . '</span><span><b>' . h($ME['name']) . '</b><small>' . h(ROLES[$ME['role']][0] ?? '') . '</small></span></a>' .
    '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="logout" class="iconbtn" title="Log out" aria-label="Log out">' . $ic('out') . '</button></form></div></aside><div class="scrim" data-side-close></div>';
// top bar
echo '<div class="page"><header class="top"><button type="button" class="iconbtn mnav" data-side-open aria-label="Open the menu" aria-controls="side" aria-expanded="false">' . $ic('menu') . ($needN ? '<i class="dot"></i>' : '') . '</button>' .
    '<nav class="crumbs" aria-label="You are here"><a href="./">Admin</a>' . ($PG[4] !== '' ? '<span>' . h(ADMIN_GROUPS[$PG[4]]) . '</span>' : '') . '<b data-crumb>' . h($PG[1]) . '</b></nav>' .
    '<div class="top-r"><button type="button" class="iconbtn" data-palette aria-label="Search pages and settings" title="Search (Ctrl K)">' . $ic('search') . '</button>' .
    '<div class="needs"><button type="button" class="iconbtn" data-needs aria-expanded="false" aria-controls="needs-p" aria-label="Needs you: ' . count($inbox) . '">' . $ic('bell') . ($inbox ? '<i class="count' . ($needN ? '' : ' info') . '">' . count($inbox) . '</i>' : '') . '</button>' .
    '<div class="needs-p" id="needs-p" hidden><div class="needs-h"><b>Needs you</b><small>' . ($inbox ? count($inbox) . ($needN ? ', ' . $needN . ' important' : '') : 'nothing waiting') . '</small></div>' . admin_inbox_html($inbox, 6) . '<a class="needs-all" href="./?p=home#needs">Open Home</a></div></div>' .
    '<a class="iconbtn" href="/" target="_blank" rel="noopener" title="Open the site" aria-label="Open the site">' . $ic('ext') . '</a></div></header>';
echo '<div class="phead"><div><h1 data-title>' . h($PG[1]) . '</h1><p data-desc>' . h($PG[2]) . '</p></div>' .
    ($tab !== 'guide' ? '<a class="howto" data-howto href="?p=guide#g-' . h($PG[7]) . '">' . $ic('book') . 'How this works</a>' : '') . '</div><main id="main">';
if ($flash) echo '<p class="flash">' . h($flash) . '</p>';
// Home: the full Needs you list first
if ($pg === 'home') echo '<section class="needs-home" id="needs"><div class="nh-h"><b>Needs you</b><small>' . ($inbox ? count($inbox) . ' ' . (count($inbox) === 1 ? 'thing' : 'things') . ' waiting' : 'All clear') . '</small></div>' . ($inbox ? admin_inbox_html($inbox, 50) : '<p class="muted nh-ok">Nothing is waiting on the team. Payouts, payments, Fair Play and the health checks are all clear.</p>') . '</section>';
echo '<script>window.ADM=' . json_encode(['p' => $pg, 'tab' => $tab, 'pages' => $navJs, 'idx' => 'search-index.json?v=' . (int)@filemtime(__DIR__ . '/search-index.json')], JSON_HEX_TAG | JSON_HEX_AMP) . ';</script>';
// view-only pages: everything shows, nothing can be changed (the server checks too)
$tabArea = TAB_AREA[$tab] ?? null;
$roMain = is_string($tabArea) && !can($tabArea, 2) && (int)(role_perms('owner')[$tabArea] ?? 0) >= 2;   // pages with nothing to change (like Overview) never say "view only"
if ($roMain) echo '<p class="viewonly">View only. You can see this page but not change anything on it. Ask an owner if you need more.</p>';
echo '<div class="' . ($roMain ? 'ro' : 'rw') . '">';

if ($tab === 'team') page_team();
if ($tab === 'deploy') page_deploy();   //MC 2026-10-13
if ($tab === 'art') {
    page_art();
    if (!isset($_GET['card'])) {
        // season cards: the ones in play, the next season's ballot with its balance results, and the reveal switch
        require_once dirname(__DIR__) . '/api/cardsetlib.php';
        $cs = cs_data(); $act = cs_active($cs); $nx = cs_next_set();
        echo '<h2 id="nextset">Season cards <small><a href="/cards#next-set" target="_blank" rel="noopener">see them &#8599;</a></small></h2>';
        echo '<p class="muted">The original 71 cards never change. Each season adds one card on top of them: the winner of the $SHY holders\' vote, which joins the game the moment the season starts (a Monday, 00:00 UTC). Before a card can go on the ballot it plays 500,000 test games added to the deck, and it has to land inside the original deck\'s range on every check.</p>';
        if ($act) echo '<div class="tw"><table><thead><tr><th>Season</th><th>Card</th><th>In the game</th><th>Chosen by</th></tr></thead><tbody>' . implode('', array_map(fn($a) => '<tr><td>' . (int)$a['season'] . '</td><td><b>' . h(SEASON_CARDS[$a['id']]['name'] ?? $a['id']) . '</b></td><td>' . ($a['from'] <= time() ? 'Since ' : 'From ') . gmdate('M j, Y', $a['from']) . '</td><td>' . ($a['by'] === 'vote' ? (int)$a['votes'] . ' holder votes' : 'No votes, so the best-balanced card') . '</td></tr>', $act)) . '</tbody></table></div>';
        if ($nx) {
            $s = $nx['season']; $votes = $cs['votes'][$s] ?? []; $bal = cs_balance($s);
            $voters = []; foreach ($votes as $v) foreach ($v as $p => $_) $voters[$p] = 1;
            $lead = cs_winner($s, $cs);
            echo '<h3>Season ' . $s . ': ' . h($nx['name']) . ' <small>vote closes ' . gmdate('D M j, H:i', $nx['opens']) . ' UTC &middot; ' . count($voters) . ' holders voted</small></h3>';
            $rows = $nx['cards']; usort($rows, fn($a, $b) => count($votes[$b] ?? []) <=> count($votes[$a] ?? []));
            echo '<div class="tw"><table><thead><tr><th>On the ballot</th><th>Votes</th><th>Balance test</th></tr></thead><tbody>';
            foreach ($rows as $id) {
                $b = $bal['cards'][$id] ?? null;
                echo '<tr' . ($lead && $lead['id'] === $id ? ' class="lead"' : '') . '><td><a href="?tab=art&amp;card=' . h($id) . '"><b>' . h(SEASON_CARDS[$id]['name']) . '</b></a>' . ($lead && $lead['id'] === $id ? ' <span class="pill on">' . ($lead['by'] === 'vote' ? 'Winning' : 'Pick if no one votes') . '</span>' : '') . '</td><td>' . count($votes[$id] ?? []) . '</td><td>' .
                    ($b ? '<span class="pill on">Passed</span> <small>wins ' . number_format($b['winUsed'], 1) . '% when used (originals ' . number_format($b['band'][0], 1) . ' to ' . number_format($b['band'][1], 1) . '%), played in ' . number_format($b['inGames'], 1) . '% of games</small>' : '<span class="pill warn">Not tested</span>') . '</td></tr>';
            }
            echo '</tbody></table></div>';
            $out = array_filter($bal['cards'] ?? [], fn($b, $id) => empty($b['pass']), ARRAY_FILTER_USE_BOTH);
            if ($out) {
                echo '<p class="muted">Left off the ballot because the balance test showed they would hurt the game:</p><ul class="muted">';
                foreach ($out as $id => $b) { $why = array_values(array_filter($b['checks'], fn($c) => !$c[1])); echo '<li><b>' . h(SEASON_CARDS[$id]['name'] ?? $id) . '</b>: ' . h(implode('; ', array_map(fn($c) => $c[0] . ', ' . $c[2], $why))) . '</li>'; }
                echo '</ul>';
            }
            if (!empty($bal['games'])) echo '<p class="muted small">Test: ' . number_format($bal['games']) . ' games with the original deck alone, then ' . number_format($bal['games']) . ' more for each card added to it. All four seats are the game\'s own bots, three of them with the hawk, builder and wild styles from solo games.</p>';
            if (can('art', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="on" value="' . (empty($cs['public']) ? 1 : 0) . '"><button name="do" value="cardset-public">' . (empty($cs['public']) ? 'Reveal the ballot to everyone' : 'Back to holders only') . '</button></form>';
        } else echo '<p class="muted">No ballot is planned yet. The next season\'s candidates come with a site update, after their balance tests.</p>';
    }
}
if ($tab === 'tourneys') page_tourneys();
if ($tab === 'fairplay') page_fairplay();
if ($tab === 'account') page_account();

if ($tab === 'guide') {
    if (!empty($_SESSION['hashline'])) {
        echo '<div class="hashline"><b>Your new password line</b><p>Replace the <code>admin_hash</code> line in <code>shy-data/config.php</code> with this, then save. It only shows once.</p><code id="hl">' . h($_SESSION['hashline']) . '</code><button type="button" onclick="navigator.clipboard.writeText(document.getElementById(\'hl\').textContent);this.textContent=\'Copied\'">Copy</button></div>';
        unset($_SESSION['hashline']);
    }
    admin_guide(csrf());
}

if ($tab === 'overview') {
    $wk = week_key(); $today = today();
    $weekly = count(array_filter($players, fn($p) => ($p['wk'] ?? '') === $wk && !empty($p['wpts'])));
    $active7 = count(array_filter($players, fn($p) => ($p['wk'] ?? '') === $wk));
    $hcount = count(array_filter($holders, fn($x) => !empty($x['shadows'])));
    $rooms = is_dir(ROOMS) ? glob(ROOMS . '/*.php') : [];
    $playing = 0; foreach ($rooms as $f) { $r = load($f); if (($r['status'] ?? '') === 'playing') $playing++; }
    $games = array_sum(array_map(fn($p) => $p['games'] ?? 0, $players));
    $live = array_sum(array_map(fn($p) => $p['pvp_g'] ?? 0, $players));
    $shares = is_dir(DATA_DIR . '/shares') ? count(glob(DATA_DIR . '/shares/*.json')) : 0;
    $cards = [['Players', count($players)], ['Games played', $games], ['Live games', $live], ['Played this week', $weekly],
        ["Today's Daily", count($daily[$today] ?? [])], ['Verified holders', $hcount], ['Live matches now', $playing], ['Shared results', $shares]];
    //MC 2026-10-11 the health check, owners only: green, amber or red, what needs a look, and every check under Details.
    //   Uses the check the cron job saved in the last 5 minutes when there is one, so this page stays quick.
    if (is_owner()) {
        $hh = null; try { $hh = health_get(300); } catch (Throwable $e) {}
        if ($hh) {
            $col = ['ok' => '#2ef0b0', 'warn' => '#ffd166', 'bad' => '#ff5d73']; $word = ['ok' => 'All good', 'warn' => 'Needs a look', 'bad' => 'Needs attention'];
            $off = array_filter($hh['checks'], fn($x) => $x[1] !== 'ok');
            echo '<section class="hcard" style="border:1px solid var(--line);border-left:4px solid ' . $col[$hh['level']] . ';border-radius:14px;background:var(--card);padding:12px 16px;margin:0 0 16px">' .
                '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span aria-hidden="true" style="width:11px;height:11px;border-radius:50%;background:' . $col[$hh['level']] . '"></span><b>Health: ' . h($word[$hh['level']]) . '</b><small class="muted">checked ' . h(ago($hh['t'])) . '</small></div>';
            //MC 2026-10-13 what needs a look is in Needs you at the top of Home now, so the card keeps just its colour and the Details
            if ($off) echo '<p style="margin:6px 0 0;font-size:14px" class="muted">' . count($off) . (count($off) === 1 ? ' check needs' : ' checks need') . ' a look. They are listed in Needs you above.</p>';
            echo '<details><summary>Details</summary><ul class="facts" style="margin-top:8px">';
            foreach ($hh['checks'] as $x) echo '<li><b style="color:' . $col[$x[1]] . '">' . h($x[0]) . '</b><br><small>' . h($x[2]) . '</small></li>';
            echo '</ul><p class="muted small">The same check as JSON, for a monitoring service: <code>' . h(TG_SITE) . '/api/health.php?k=</code> followed by the cron key from the Telegram page. It answers 503 when something is red.</p></details></section>';
        }
    }
    echo '<section class="grid">';
    foreach ($cards as $c) echo '<div class="stat"><b>' . number_format($c[1]) . '</b><span>' . h($c[0]) . '</span></div>';
    echo '</section>';
    //MC 2026-10-10 When and where players play: the same section as the Stats page, with the team's detail (every place
    //   with no minimum, the raw time zones). Read only here, the hour backfill runs from the public page or the next game.
    require_once dirname(__DIR__) . '/api/statslib.php';
    require_once dirname(__DIR__) . '/api/whenlib.php';
    $rxAt = fn($f) => (int)@filemtime(dirname(__DIR__) . '/assets/' . $f);
    echo '<h2>When and where players play <small><a href="/stats#when" target="_blank" rel="noopener">public view &#8599;</a></small></h2>';
    echo '<link rel="stylesheet" href="../assets/stats2.css?v=' . $rxAt('stats2.css') . '"><div class="rx rx-admin" id="rx-mount"></div>';
    echo '<script>window.SHY_RX=' . json_encode(['admin' => true, 'data' => rx_build($players, load(STATS), true)], JSON_HEX_TAG | JSON_HEX_AMP) . ';</script><script src="../assets/stats2.js?v=' . $rxAt('stats2.js') . '" defer></script>';
    // where players drop off: first visits in the chosen period, and how far each got
    $fd = (int)($_GET['fd'] ?? 30); if (!in_array($fd, [7, 30, 90], true)) $fd = 30;
    $since = gmdate('Y-m-d', time() - ($fd - 1) * 86400);
    $fun = load(FUNNEL)['p'] ?? [];
    $coh = array_filter($fun, fn($x) => ($x['v'] ?? '') >= $since);
    $STEPS = ['v' => 'Visited the site', 's' => 'Started a game', 'f' => 'Finished a game', 'r' => 'Came back another day', 'w' => 'Connected a wallet', 'b' => 'Bought something'];
    $cnt = []; foreach ($STEPS as $k => $_) $cnt[$k] = count(array_filter($coh, fn($x) => !empty($x[$k])));
    echo '<h2>Where players drop off <small>' . implode(' ', array_map(fn($d) => '<a href="?p=analytics&amp;fd=' . $d . '"' . ($d === $fd ? ' class="on"' : '') . '>' . $d . ' days</a>', [7, 30, 90])) . '</small></h2>';
    if (!$coh) echo '<p class="muted">New visitors show up here from this release on: each browser\'s first visit, then whether it started a game, finished one, came back, connected a wallet and bought something.</p>';
    else {
        echo '<div class="fun">';
        $prev = null;
        foreach ($STEPS as $k => $label) {
            $n = $cnt[$k]; $pct = $cnt['v'] ? $n / $cnt['v'] * 100 : 0; $step = $prev !== null && $cnt[$prev] ? $n / $cnt[$prev] * 100 : null;
            echo '<div class="fun-r"><span class="fun-l">' . h($label) . '</span><span class="fun-bar"><i style="width:' . round($pct, 1) . '%"></i></span><b>' . number_format($n) . '</b><small>' . round($pct) . '% of visitors' . ($step !== null ? ' &middot; ' . round($step) . '% of the step before' : '') . '</small></div>';
            $prev = $k;
        }
        echo '</div>';
        $by = [];
        foreach ($coh as $x) { $sk = $x['src'] ?? 'direct'; $by[$sk]['v'] = ($by[$sk]['v'] ?? 0) + 1; foreach (['f', 'w', 'b'] as $k) if (!empty($x[$k])) $by[$sk][$k] = ($by[$sk][$k] ?? 0) + 1; }
        uasort($by, fn($a, $b) => $b['v'] <=> $a['v']);
        echo '<div class="tw"><table><thead><tr><th>Came from</th><th>Visitors</th><th>Finished a game</th><th>Connected a wallet</th><th>Bought</th></tr></thead><tbody>';
        foreach (array_slice($by, 0, 12, true) as $sk => $x) { $pc = fn($k) => number_format($x[$k] ?? 0) . ' <small class="muted">' . round(($x[$k] ?? 0) / $x['v'] * 100) . '%</small>'; echo '<tr><td>' . h($sk) . '</td><td>' . number_format($x['v']) . '</td><td>' . $pc('f') . '</td><td>' . $pc('w') . '</td><td>' . $pc('b') . '</td></tr>'; }
        echo '</tbody></table></div>';
    }
    $rows = week_rows($wk);
    echo '<h2>This week so far</h2>';
    rows_table(array_slice($rows, 0, 5), $holders);
    echo '<h2>Setup</h2><ul class="facts">';
    echo '<li>Wallet checks: ' . (holders_enabled() ? '<i class="ok">On</i>' : '<i class="bad">Off (no Helius key)</i>') . '</li>';
    echo '<li>Signature check: ' . (function_exists('sodium_crypto_sign_verify_detached') ? 'built-in' : 'bundled library') . '</li>';
    echo '<li>Image cards: ' . (function_exists('imagettftext') ? '<i class="ok">Ready</i>' : '<i class="bad">PHP GD with FreeType missing</i>') . '</li>';
    echo '<li>Data folder: <code>' . h(DATA_DIR) . '</code>' . (strpos(DATA_DIR, 'public_html') !== false ? ' <i class="bad">inside the website folder</i>' : ' <i class="ok">safe from site updates</i>') . '</li>';
    echo '<li>PHP ' . h(PHP_VERSION) . '</li></ul>';
}


if ($tab === 'shop') {
    [$orders, $eco, $rw] = with_lock(fn() => [load(ORDERS), load(ECO), load(REWARDS)]);
    uasort($orders, fn($a, $b) => $b['ts'] <=> $a['ts']);
    $paid = array_filter($orders, fn($o) => $o['status'] === 'paid');
    $wk = week_key();
    $byCur = [];
    foreach ($paid as $o) $byCur[$o['cur']] = ($byCur[$o['cur']] ?? 0) + $o['usd'];
    $kobanOut = array_sum(array_map(fn($a) => $a['koban'] ?? 0, $eco));
    $cards = [['Revenue this week', '$' . number_format($rw['rev'][$wk] ?? 0, 2)], ['Revenue all time', '$' . number_format(array_sum(array_column($paid, 'usd')), 2)],
        ['Paid orders', count($paid)], ['Buyers', count(array_unique(array_column($paid, 'pid')))], ['Koban held by players', number_format($kobanOut)], ['Shop accounts', count($eco)]];
    // the numbers up top refresh in place (button, or every minute while the page is open), without reloading the page
    echo '<div class="bar shop-live"><span class="muted small">Updated <b data-shop-at>' . gmdate('H:i:s') . ' UTC</b> &middot; refreshes every minute while open</span><button type="button" class="ghost" data-shop-refresh>Refresh</button></div>';
    echo '<div id="shop-stats"><section class="grid">';
    foreach ($cards as $c) echo '<div class="stat"><b>' . h($c[1]) . '</b><span>' . h($c[0]) . '</span></div>';
    echo '</section>';
    echo '<p class="muted">By currency: ' . ($byCur ? implode(' &middot; ', array_map(fn($k, $v) => h($k) . ' $' . number_format($v, 2), array_keys($byCur), $byCur)) : 'no sales yet') . '. Crypto lands in the marketing wallet <a href="https://solscan.io/account/' . h(mw_address()) . '" target="_blank" rel="noopener">' . h(short_w(mw_address())) . '</a>.' . (empty(shy_config()['stripe_secret']) ? ' Card payments are off until a Stripe key is added to config.php.' : '') . '</p>';
    echo '</div>';
    // what sells: paid orders by product, and what players spend Koban on (from their recent activity)
    $byProd = [];
    foreach ($paid as $o) { $k = $o['name']; $byProd[$k] = ['n' => ($byProd[$k]['n'] ?? 0) + 1, 'usd' => ($byProd[$k]['usd'] ?? 0) + $o['usd']]; }
    uasort($byProd, fn($a, $b) => $b['usd'] <=> $a['usd']);
    $sink = [];
    foreach ($eco as $acc) foreach ($acc['ledger'] ?? [] as $l) if ($l['n'] < 0) {
        $w = preg_match('/^(XP Boost|Tier Skip|Mission Reroll|Bounty Board|Streak Saver|Season Scroll)/', $l['w'], $m) ? $m[1] : (strpos($l['w'], ', ') !== false && preg_match('/, (Gold Leaf|Blood Moon|Neon Shrine|Holo Foil)$/', $l['w'], $m2) ? 'Card finish: ' . $m2[1] : (preg_match('/^\w+ Shade$/', $l['w']) ? 'Shadow skins' : (preg_match('/^\w+ Halo$/', $l['w']) ? 'Shadow halos' : $l['w'])));
        $sink[$w] = ($sink[$w] ?? 0) - $l['n'];
    }
    arsort($sink);
    $td = shop_today(); $bn = bundle_now(); $dk = deck_cards();
    $lab = function ($x) use ($dk) { if ($x['kind'] === 'fin') return ($dk[$x['card']]['name'] ?? $x['card']) . ', ' . FINISHES[$x['fin']]['name']; $it = eco_item($x['id']); return $it ? $it['name'] : $x['id']; };
    //MC 2026-10-15 Today's shop and Sales by product were side by side in one box; they're on different pages now
    echo '<section><h2>Today\'s shop <small>changes 00:00 UTC' . ($td['roll'] ? ' &middot; refreshed ' . (int)$td['roll'] . ($td['roll'] === 1 ? ' time' : ' times') . ' today' : '') . '</small></h2><ul class="plain">' .
        '<li><b>Deal, &minus;' . (int)$td['deal']['off'] . '%:</b> ' . h($lab($td['deal'])) . ' &middot; ' . number_format((int)$td['deal']['price']) . ' Koban</li>' .
        '<li><b>Holo Foil:</b> ' . h(implode(', ', array_map($lab, $td['holo']))) . '</li>' .
        '<li><b>Picks, &minus;15%:</b> ' . h(implode(', ', array_map($lab, $td['picks']))) . '</li>' .
        '<li><b>Bundle this week:</b> ' . h($bn['name']) . ' (' . count($bn['items']) . ' items and ' . count($bn['cards']) . ' cards in ' . h(FINISHES[$bn['fin']]['name']) . ')</li></ul>' .
        (can('shop', 2) ? '<form method="post" class="bar" onsubmit="return confirm(\'Roll a new deal, Holo Foil cards and picks for today? Players see them the next time the shop opens. Anything already bought stays theirs.\')"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="shop-reroll">Refresh today\'s shop</button><span class="muted">New deal, Holo Foil cards and picks until 00:00 UTC. The weekly bundle stays.</span></form>' : '') . '</section>';
    echo '<section><h2>Sales by product <small>' . (count($byProd) > 25 ? 'top 25 of ' . count($byProd) : count($byProd)) . ' products</small></h2>' . ($byProd ? '<div class="tw"><table><thead><tr><th>Product</th><th>Sold</th><th>Revenue</th></tr></thead><tbody>' . implode('', array_map(fn($k, $v) => '<tr><td>' . h($k) . '</td><td>' . (int)$v['n'] . '</td><td>$' . number_format($v['usd'], 2) . '</td></tr>', array_keys(array_slice($byProd, 0, 25, true)), array_slice($byProd, 0, 25, true))) . '</tbody></table></div>' : '<p class="muted">No sales yet.</p>') . '</section>';
    //MC 2026-10-13 the Koban faucet: every Koban is counted on the account as it moves (earned, bought or spent), so this
    //   is one sum over accounts. It shows whether the free faucet is drowning the shop. Counters started Oct 13, 2026.
    $kin = 0; $kbuy = 0; $kout = 0;
    foreach ($eco as $acc) { $kin += (int)($acc['kin'] ?? 0); $kbuy += (int)($acc['kbuy'] ?? 0); $kout += (int)($acc['kout'] ?? 0); }
    $kall = $kin + $kbuy;
    //MC 2026-10-15 was Koban faucet in the summary up top; now its own part of Sales with What Koban buys under it,
    //   and it refreshes with the summary (#koban-flow)
    echo '<section id="koban-flow"><h2>Koban flow <small>since Oct 13, 2026</small></h2><section class="grid">';
    foreach ([['Earned free', number_format($kin)], ['Bought', number_format($kbuy)], ['Spent', number_format($kout)], ['Bought share', $kall ? round(100 * $kbuy / $kall, 1) . '%' : 'no flow yet']] as $c)
        echo '<div class="stat"><b>' . h($c[1]) . '</b><span>' . h($c[0]) . '</span></div>';
    echo '</section><p class="muted">Earned free counts gifts, streaks, missions, X tasks, bounties, rewards and refunds. Bought counts Koban from packs and bundles, bonuses and the $SHY bonus included. If the bought share sits near zero while spending is high, the free faucet is feeding the whole economy and prices or payouts need a look.</p>';
    //MC 2026-10-15 a ranked list with a bar each instead of one long run of text
    if ($sink) { $top = max($sink); echo '<h3>What Koban buys <small class="muted">top 14, from players\' recent activity</small></h3><ol class="kbuy">' . implode('', array_map(fn($k, $v) => '<li><span>' . h($k) . '</span><b>' . number_format($v) . '</b><i style="width:' . max(2, round(100 * $v / max(1, $top))) . '%"></i></li>', array_keys(array_slice($sink, 0, 14, true)), array_slice($sink, 0, 14, true))) . '</ol>'; }
    echo '</section>';
    //MC 2026-10-13 limited finish drops: schedule, follow and stop them. Sold copies are numbered and can't be unsold.
    $allDrops = load(DROPS); uasort($allDrops, fn($x, $y) => $y['created'] <=> $x['created']);
    echo '<h2 id="drops">Limited drops</h2><p class="muted">A drop sells one card\'s finish for a set $SHY price, a set number of copies, between a start and an end. Copies are numbered as they sell (copy 7 of 50). Paid like every $SHY purchase: the burn share burns in the buyer\'s own transaction, the rest lands in the marketing wallet. Finishes marked earned (Shadow Ink) can never drop; that promise holds.</p>';
    if (can('shop', 2)) {
        $dk = deck_cards();
        echo '<details class="addbox"><summary class="btnish primary">Schedule a drop</summary><form method="post" class="tform"><input type="hidden" name="csrf" value="' . h(csrf()) . '">' .
            '<div class="grid3"><label>Card<select name="card">' . implode('', array_map(fn($id, $c) => '<option value="' . h($id) . '">' . h($c['name']) . '</option>', array_keys($dk), $dk)) . '</select></label>' .
            '<label>Finish<select name="fin">' . implode('', array_map(fn($k, $f) => empty($f['earned']) ? '<option value="' . h($k) . '">' . h($f['name']) . '</option>' : '', array_keys(FINISHES), FINISHES)) . '</select></label>' .
            '<label>Copies<input name="n" type="number" min="1" max="10000" value="50"></label></div>' .
            '<div class="grid3"><label>Price ($SHY each)<input name="shy" type="number" step="any" min="1" value="1000" required></label>' .
            '<label>Starts (UTC)<input name="start" type="datetime-local" value="' . gmdate('Y-m-d\TH:i', time() + 600) . '" required></label><label>Ends (UTC)<input name="end" type="datetime-local" value="' . gmdate('Y-m-d\TH:i', time() + 3 * 86400) . '" required></label></div>' .
            '<label class="chk"><input type="checkbox" name="announce" value="1" checked> Announce it in the Telegram chat</label>' .
            '<div class="bar"><button name="do" value="drop-add">Schedule the drop</button></div></form></details>';
    }
    if ($allDrops) {
        echo '<div class="tw"><table><thead><tr><th>Drop</th><th>Price</th><th>Sold</th><th>Window (UTC)</th><th>State</th><th></th></tr></thead><tbody>';
        foreach ($allDrops as $did => $d) {
            $nm = (deck_cards()[$d['card']]['name'] ?? $d['card']) . ' in ' . (FINISHES[$d['fin']]['name'] ?? $d['fin']);
            $st = !empty($d['off']) ? '<span class="pill off">Stopped</span>' : ((int)$d['sold'] >= (int)$d['n'] ? '<span class="pill on">Sold out</span>' : (time() < $d['start'] ? '<span class="pill">Scheduled</span>' : (time() < $d['end'] ? '<span class="pill warn">Live</span>' : '<span class="pill off">Ended</span>')));
            echo '<tr><td><b>' . h($nm) . '</b></td><td>' . number_format($d['shy']) . ' $SHY</td><td>' . (int)$d['sold'] . ' / ' . (int)$d['n'] . '</td><td class="nw">' . h(gmdate('M j H:i', $d['start'])) . ' to ' . h(gmdate('M j H:i', $d['end'])) . '</td><td>' . $st . '</td><td>';
            if (can('shop', 2)) {
                echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="id" value="' . h($did) . '">';
                if (empty($d['off']) && time() < $d['end'] && (int)$d['sold'] < (int)$d['n']) echo '<button name="do" value="drop-off" class="ghost danger" data-confirm="Stop this drop? Nobody else can buy it, and copies already sold stay with their owners.">Stop</button>';
                if ((int)$d['sold'] === 0) echo '<button name="do" value="drop-del" class="ghost" data-confirm="Remove this drop from the list?">Remove</button>';
                echo '</form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    } else echo '<p class="muted">No drops yet.</p>';
    //MC 2026-10-12 Shop prices: the % controls on top, every priced thing below with its code price, today's price and a box
    //   to type its own price. The New column is worked out in the browser as you type (same rules as shop_px), so you see
    //   what changes before saving.
    if (can('shop', 2)) {
        $sp = shop_prices();
        $kindN = ['frame' => 'Card frames', 'back' => 'Card backs', 'table' => 'Tables', 'fx' => 'Victory effects', 'cap' => 'Region effects', 'turn' => 'Turn auras', 'felt' => 'Table felt', 'land' => 'Land finish', 'piece' => 'Command pieces', 'air' => 'Table air', 'emote' => 'Reactions', 'ring' => 'Name rings', 'title' => 'Titles', 'share' => 'Share cards', 'skin' => 'Shadow skins', 'halo' => 'Halos',
            'banner' => 'Page banners', 'plate' => 'Nameplates', 'pfx' => 'Page effects', 'accent' => 'Page accents', 'unlock' => 'Page unlocks', 'pframe' => 'Portrait frames', 'seal' => 'Page seals'];
        $rarN = ['rare' => 'Rare', 'epic' => 'Epic', 'legendary' => 'Legendary', 'mythic' => 'Mythic'];
        $rows = []; $slotsUsed = [];
        foreach (eco_catalog()['items'] as $it) if (!empty($it['base'])) { $rows[] = ['k' => 'item:' . $it['id'], 'n' => $it['name'], 'g' => $it['slot'] ?? '', 'r' => $it['rarity'] ?? '', 'b' => (int)$it['base'], 'now' => (int)$it['koban']]; $slotsUsed[$it['slot'] ?? ''] = ($slotsUsed[$it['slot'] ?? ''] ?? 0) + 1; }
        foreach (finishes_priced() as $id => $f) if (!empty($f['base'])) $rows[] = ['k' => 'fin:' . $id, 'n' => $f['name'] . ' finish', 'g' => '_fin', 'r' => $f['rar'] ?? '', 'b' => (int)$f['base'], 'now' => (int)$f['koban']];
        foreach (eco_goods_priced() as $g) $rows[] = ['k' => 'good:' . $g['id'], 'n' => $g['name'], 'g' => '_good', 'r' => '', 'b' => (int)$g['base'], 'now' => (int)$g['koban']];
        $kindN['_fin'] = 'Card finishes'; $kindN['_good'] = 'Boosts and tools';
        $pc = fn($v) => rtrim(rtrim(number_format((float)$v, 1, '.', ''), '0'), '.');
        echo '<div class="rw"><h2 id="shop-prices">Shop prices <small>' . count($rows) . ' things for Koban</small></h2>';
        echo '<p class="muted">Raise or lower Koban prices without touching the code. <b>100%</b> is the price in the code. The %s stack: the whole shop, then the kind, then the rarity, and each price is rounded to a clean number. A price typed into the <b>Set price</b> box wins over every %. The <b>New</b> column updates as you type, so you can see the result before saving. Holder discounts still come off at checkout, and today\'s deals stay a % off the new price.' . (!empty($sp['at']) ? ' Last changed ' . h(ago($sp['at'])) . ' by ' . h($sp['by']) . '.' : '') . '</p>';
        echo '<form method="post" class="sp-form" id="sp-form"><input type="hidden" name="csrf" value="' . h(csrf()) . '">';
        echo '<div class="sp-top"><label class="sp-all">Whole shop<span><input name="all" type="number" min="10" max="1000" step="1" value="' . h($pc($sp['all'])) . '" data-sp="all">%</span></label>';
        echo '<div class="sp-grp"><b>By rarity</b>'; foreach ($rarN as $k => $l) echo '<label><span class="pill r-' . $k . '">' . $l . '</span><span><input name="rar[' . $k . ']" type="number" min="10" max="1000" step="1" value="' . h($pc($sp['rarity'][$k] ?? 100)) . '" data-sp="rar:' . $k . '">%</span></label>'; echo '</div></div>';
        echo '<div class="sp-grp sp-kinds"><b>By kind</b>';
        foreach ($kindN as $k => $l) { if ($k[0] !== '_' && empty($slotsUsed[$k])) continue; $name = $k === '_fin' ? 'fin' : ($k === '_good' ? 'goods' : 'slot[' . $k . ']'); $val = $k === '_fin' ? $sp['fin'] : ($k === '_good' ? $sp['goods'] : ($sp['slot'][$k] ?? 100));
            echo '<label>' . h($l) . '<small>' . ($k === '_fin' ? count(FINISHES) : ($k === '_good' ? count(eco_goods()) : $slotsUsed[$k])) . '</small><span><input name="' . $name . '" type="number" min="10" max="1000" step="1" value="' . h($pc($val)) . '" data-sp="g:' . h($k) . '">%</span></label>'; }
        echo '</div>';
        echo '<div class="sp-bar"><input type="search" id="sp-q" placeholder="Find an item" aria-label="Find an item"><select id="sp-k" aria-label="Kind"><option value="">Every kind</option>'; foreach ($kindN as $k => $l) if ($k[0] === '_' || !empty($slotsUsed[$k])) echo '<option value="' . h($k) . '">' . h($l) . '</option>'; echo '</select><span class="sp-sum" id="sp-sum" aria-live="polite"></span></div>';
        echo '<div class="tw sp-tw"><table class="sp-tbl"><thead><tr><th>Item</th><th>Kind</th><th class="num">Code price</th><th class="num">Now</th><th class="num">New</th><th>Set price</th></tr></thead><tbody>';
        usort($rows, fn($a, $b) => [$a['g'], $a['b']] <=> [$b['g'], $b['b']]);
        foreach ($rows as $r) { $fx = $sp['fixed'][$r['k']] ?? '';
            echo '<tr data-g="' . h($r['g']) . '" data-r="' . h($r['r']) . '" data-b="' . $r['b'] . '" data-now="' . $r['now'] . '" data-n="' . h(strtolower($r['n'])) . '"><td><b>' . h($r['n']) . '</b>' . ($r['r'] ? ' <span class="pill r-' . h($r['r']) . '">' . h($rarN[$r['r']] ?? $r['r']) . '</span>' : '') . '</td><td class="muted">' . h($kindN[$r['g']] ?? $r['g']) . '</td><td class="num">' . number_format($r['b']) . '</td><td class="num">' . number_format($r['now']) . '</td><td class="num sp-new"></td>' .
                '<td><input class="sp-fix" name="fix[' . h($r['k']) . ']" value="' . h($fx) . '" inputmode="numeric" placeholder="auto" aria-label="Set price for ' . h($r['n']) . '"></td></tr>'; }
        echo '</tbody></table></div>';
        echo '<div class="bar"><button name="do" value="shop-prices" data-confirm="Save these Koban prices? Players see them right away.">Save prices</button><button name="do" value="shop-prices" class="ghost danger" onclick="this.form.reset_all.value=1" data-confirm="Put every price back to the price in the code?">Reset to code prices</button><input type="hidden" name="reset" value="" id="sp-reset"></div></form></div>';
        echo '<script>(function(){var f=document.getElementById("sp-form");if(!f)return;f.reset_all=document.getElementById("sp-reset");
var v=function(s){var e=f.querySelector("[data-sp=\""+s+"\"]");var n=e?parseFloat(e.value):100;return isFinite(n)&&n>0?n:100;};
var rnd=function(n){n=Math.max(10,n);return n<1000?Math.round(n/10)*10:Math.round(n/50)*50;};
var fmt=function(n){return n.toLocaleString("en-US");};
function calc(){var ch=0,up=0,dn=0,rows=f.querySelectorAll(".sp-tbl tbody tr");rows.forEach(function(tr){var b=+tr.dataset.b,g=tr.dataset.g,r=tr.dataset.r,now=+tr.dataset.now,fx=tr.querySelector(".sp-fix").value.replace(/[, ]/g,"");
var p=v("all")*v("g:"+g)/100*(r?v("rar:"+r)/100:1);var n=/^\d+$/.test(fx)?Math.max(10,+fx):(Math.abs(p-100)<.001?b:rnd(b*p/100));
var c=tr.querySelector(".sp-new");c.textContent=fmt(n);c.className="num sp-new"+(n>now?" up":n<now?" dn":"");if(n!==now){ch++;if(n>now)up++;else dn++;}});
document.getElementById("sp-sum").textContent=ch?ch+" price"+(ch===1?"":"s")+" change: "+up+" up, "+dn+" down":"No changes yet";}
function filt(){var q=document.getElementById("sp-q").value.trim().toLowerCase(),k=document.getElementById("sp-k").value;f.querySelectorAll(".sp-tbl tbody tr").forEach(function(tr){tr.hidden=(q&&tr.dataset.n.indexOf(q)<0)||(k&&tr.dataset.g!==k);});}
f.addEventListener("input",function(e){if(e.target.id==="sp-q")filt();else calc();});f.addEventListener("change",function(e){if(e.target.id==="sp-k")filt();});calc();})();</script>';
    }
    //MC 2026-10-12 the player box dropped down the browser's own list of past entries and, on Award Koban, the top 500
    //   names. Both replaced by a picker (data-pick, admin.js): type part of a name and pick the player from the matches.
    if (can('gifts', 2)) echo '<div class="rw"><h2>Give Koban or an item <small><a href="?p=players#award">Award Koban on All players</a></small></h2><form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="back" value="shop"><input name="who" placeholder="Search a player by name or id" required autocomplete="off" spellcheck="false" data-pick="players"><input name="koban" type="number" min="-' . GRANT_MAX . '" max="' . GRANT_MAX . '" placeholder="Koban" style="width:110px"><select name="item"><option value="">No item</option>';
    if (can('gifts', 2)) foreach (eco_catalog()['items'] as $it) if (empty($it['dev'])) echo '<option value="' . h($it['id']) . '">' . h($it['name']) . ' (' . h($it['slot']) . ')</option>';
    if (can('gifts', 2)) echo '</select><input name="why" placeholder="Reason (shows in their history)" autocomplete="off"><button name="do" value="grant">Give</button></form></div>';
    // invite rewards: settings and the latest invites
    $rs = eco_settings(); $refs = load(REFS); $rpl = load(PLAYERS);
    $rl = array_filter($refs, fn($r, $k) => $k !== '_wk', ARRAY_FILTER_USE_BOTH); uasort($rl, fn($a, $b) => $b['t'] <=> $a['t']);
    $rPaid = count(array_filter($rl, fn($r) => !empty($r['paid'])));
    //MC 2026-10-15 email wallets (Crossmint): a free Solana wallet for players without one
    if (is_owner()) {
        $es = eco_settings();
        echo '<h2 id="ewallet">Email wallets <small>' . (!empty($es['ew_on']) && !empty($es['ew_ck']) ? 'on' : 'off') . '</small></h2><p class="muted">Players with no wallet app (Telegram, phones, desktops without an extension) get a <b>Use my email</b> button: they type their email, enter a 6-digit code and have a free Solana wallet from Crossmint, linked like any other wallet. The button only shows while this is on and a key is saved.</p><ol class="ew-steps"><li>In the Crossmint console, on Production, open <b>Integrate</b>, then <b>API Keys</b>, and create a <b>client-side key</b>.</li><li>Give it the scopes <code>users.create</code>, <code>wallets.create</code> and <code>wallets.read</code>.</li><li>Add <code>https://shyonsol.io</code> as an authorized origin, and make sure email sign-in is on.</li><li>Paste the key below (it starts with ck_production_), tick On and save. Then try it once yourself from your profile.</li></ol><p class="muted small">The client key is meant to be public. The server key for trophies is a different key and stays on the Trophies on Solana page.</p>';
        echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="ew_on" value="1"' . (!empty($es['ew_on']) ? ' checked' : '') . '> On</label><span class="muted">Client key</span><input name="ew_ck" autocomplete="off" placeholder="' . (!empty($es['ew_ck']) ? 'Saved, ends in ' . h(substr((string)$es['ew_ck'], -4)) : 'ck_production_...') . '" style="width:320px"><button name="do" value="ew-save">Save</button></form>';
    }
    //MC 2026-10-15 trophies minted to winners' wallets
    if (can('shop', 2)) {
        $tc = trophy_cfg(); $tall = load(TROPHIES); $tpl = load(PLAYERS); $tho = load(HOLDERS);
        $cnt = ['wait' => 0, 'mint' => 0, 'done' => 0, 'fail' => 0]; foreach ($tall as $r) $cnt[$r['st']] = ($cnt[$r['st']] ?? 0) + 1;
        echo '<h2 id="trophies">Trophies on Solana <small>' . (int)$cnt['done'] . ' minted &middot; ' . ((int)$cnt['wait'] + (int)$cnt['mint']) . ' waiting' . ($cnt['fail'] ? ' &middot; ' . (int)$cnt['fail'] . ' failed' : '') . '</small></h2>';
        echo '<p class="muted">League Champions, tournament winners, the 15 Club, Grandmasters, Jade and Shogun ranked finishes and Diamond Hands holders get a compressed NFT in their own wallet. Minted through Crossmint: they cover the network fee and hold no key of ours. Until a key is set and switched on, trophies are recorded and wait. A winner with no wallet connected gets theirs the first time they connect one.</p>';
        if (is_owner()) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="t_on" value="1"' . ($tc['on'] ? ' checked' : '') . '> On</label>' .
            '<span class="muted">API key</span><input name="t_key" type="password" autocomplete="new-password" placeholder="' . ($tc['key'] !== '' ? 'Saved, ends in ' . h(substr($tc['key'], -4)) : 'Server-side key with nfts.create') . '" style="width:260px">' .
            '<span class="muted">Collection</span><input name="t_col" value="' . h($tc['col']) . '" style="width:200px">' .
            '<select name="t_env"><option value="prod"' . ($tc['env'] === 'prod' ? ' selected' : '') . '>Mainnet</option><option value="staging"' . ($tc['env'] === 'staging' ? ' selected' : '') . '>Staging (devnet test)</option></select>' .
            ($tc['key'] !== '' ? '<label class="chk"><input type="checkbox" name="t_clear" value="1"> Remove key</label>' : '') . '<button name="do" value="trophy-save">Save</button></form>';
        echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="trophy-run">Send waiting trophies now</button>' . ($cnt['fail'] ? '<button name="do" value="trophy-retry">Retry failed</button>' : '') . '</form>';
        if ($tall) {
            uasort($tall, fn($a, $b) => $b['t'] <=> $a['t']);
            echo '<div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Trophy</th><th>Wallet</th><th>Status</th></tr></thead><tbody>';
            foreach (array_slice($tall, 0, 40, true) as $id => $r) {
                $w = $r['wallet'] ?? ($tho[$r['pid']]['wallet'] ?? '');
                $st = $r['st'] === 'done' ? '<a href="https://solscan.io/token/' . h($r['mint']) . '" target="_blank" rel="noopener">Minted</a>' : ($r['st'] === 'fail' ? 'Failed: ' . h($r['err'] ?? '') : ($w ? ($r['st'] === 'mint' ? 'Minting' : 'Waiting') . (!empty($r['err']) ? ' (' . h($r['err']) . ')' : '') : 'Waiting for a wallet'));
                echo '<tr><td>' . h(ago($r['t'])) . '</td><td>' . h($tpl[$r['pid']]['name'] ?? substr($r['pid'], 0, 6)) . '</td><td>' . h(TROPHY_KINDS[$r['kind']][0] . ($r['what'] !== '' ? ', ' . $r['what'] : '')) . '</td><td>' . ($w ? h(substr($w, 0, 4) . '...' . substr($w, -4)) : '<span class="muted">none</span>') . '</td><td>' . $st . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
    }
    echo '<h2>Invite rewards <small>' . count($rl) . ' invited &middot; ' . $rPaid . ' rewarded</small></h2><p class="muted">A player opens a friend\'s invite link before their first game. Once they finish the set number of games, the inviter gets Koban and the new player a welcome gift. If the new player later connects a wallet holding $SHY (or a Shadow), the inviter gets a bonus. Inviters are paid for a limited number of invites a week, so nobody farms it with fake profiles.</p>';
    if (can('shop', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="ref_on" value="1"' . (!empty($rs['ref_on']) ? ' checked' : '') . '> On</label>' .
        '<span class="muted">Inviter gets</span><input name="ref_koban" type="number" min="0" value="' . (int)$rs['ref_koban'] . '" style="width:80px"><span class="muted">New player gets</span><input name="ref_new" type="number" min="0" value="' . (int)$rs['ref_new'] . '" style="width:80px">' .
        '<span class="muted">Holder bonus</span><input name="ref_holder" type="number" min="0" value="' . (int)$rs['ref_holder'] . '" style="width:80px"><span class="muted">after games</span><input name="ref_games" type="number" min="1" value="' . (int)$rs['ref_games'] . '" style="width:64px">' .
        '<span class="muted">most a week</span><input name="ref_cap" type="number" min="0" value="' . (int)$rs['ref_cap'] . '" style="width:64px"><button name="do" value="ref-settings">Save</button></form>';
    if ($rl) {
        echo '<div class="tw"><table><thead><tr><th>When</th><th>New player</th><th>Invited by</th><th>Games</th><th>Reward</th><th>Holder bonus</th></tr></thead><tbody>';
        foreach (array_slice($rl, 0, 30, true) as $p => $r) echo '<tr><td>' . h(ago($r['t'])) . '</td><td>' . h($rpl[$p]['name'] ?? substr($p, 0, 6)) . '</td><td>' . h($rpl[$r['by']]['name'] ?? substr($r['by'], 0, 6)) . '</td><td>' . (int)($r['g'] ?? 0) . '</td><td>' . (!empty($r['paid']) ? '<i class="ok">Paid</i>' : '<span class="muted">Waiting</span>') . '</td><td>' . (!empty($r['hb']) ? '<i class="ok">Paid</i>' : '') . '</td></tr>';
        echo '</tbody></table></div>';
    }
    //MC 2026-10-09 ambassadors: invites counted per inviter for a month, so the monthly $SHY bonus can be paid without
    //counting by hand. The list above only shows the latest 30 invites, which a busy month blows past. An invite counts
    //in the month it got paid (the new player finished their games); a holder bonus counts again in the month it landed.
    //Old records saved paid as 1 instead of a time, so those fall back to when the invite was made.
    $AMB = [15 => 'Recruiter', 5 => 'Scout'];
    $months = [gmdate('Y-m'), gmdate('Y-m', strtotime(gmdate('Y-m-01') . ' -1 month')), gmdate('Y-m', strtotime(gmdate('Y-m-01') . ' -2 months'))];
    $rm = (string)($_GET['rm'] ?? ''); if (!in_array($rm, $months, true)) $rm = $months[0];
    $inM = fn($ts) => $ts > 0 && gmdate('Y-m', (int)$ts) === $rm;
    $amb = []; $rholders = load(HOLDERS);
    foreach ($rl as $p => $r) {
        $by = (string)($r['by'] ?? ''); if ($by === '') continue;
        $pt = (int)($r['paid'] ?? 0); if ($pt === 1) $pt = (int)$r['t'];
        $ht = (int)($r['hb'] ?? 0); if ($ht === 1) $ht = $pt;
        if ($inM($pt)) { $amb[$by]['n'] = ($amb[$by]['n'] ?? 0) + 1; $ip = (string)($r['ip'] ?? ''); if ($ip !== '') $amb[$by]['ip'][$ip] = ($amb[$by]['ip'][$ip] ?? 0) + 1; }
        if ($inM($ht)) $amb[$by]['h'] = ($amb[$by]['h'] ?? 0) + 1;
        if (!$pt) $amb[$by]['w'] = ($amb[$by]['w'] ?? 0) + 1;
    }
    $amb = array_filter($amb, fn($a) => ($a['n'] ?? 0) + ($a['h'] ?? 0) > 0);
    foreach ($amb as $k => $a) $amb[$k]['s'] = ($a['n'] ?? 0) + ($a['h'] ?? 0);
    uasort($amb, fn($a, $b) => $b['s'] <=> $a['s'] ?: ($b['h'] ?? 0) <=> ($a['h'] ?? 0));
    $topS = $amb ? reset($amb)['s'] : 0;
    echo '<h2 id="ambassadors">Ambassadors by month <small>' . implode(' ', array_map(fn($m) => '<a href="?tab=shop&amp;rm=' . $m . '#ambassadors"' . ($m === $rm ? ' class="on"' : '') . '>' . h(gmdate('M Y', strtotime($m . '-01'))) . '</a>', $months)) . '</small></h2>';
    echo '<p class="muted">Score is invites that finished their games this month plus holder bonuses that landed this month, so a new holder counts twice. Scout at 5, Recruiter at 15, and the top score of the month (5 or more) is the top ambassador. Same network shows the most of their counted invites that came from one internet connection: a high number there is worth a look before paying.</p>';
    if (!$amb) echo '<p class="muted">No counted invites in ' . h(gmdate('F Y', strtotime($rm . '-01'))) . ' yet.</p>';
    else {
        echo '<div class="tw"><table><thead><tr><th>Inviter</th><th>Counted invites</th><th>Holder bonuses</th><th>Score</th><th>Still playing</th><th>Same network</th><th>Tier</th><th>Wallet</th></tr></thead><tbody>';
        foreach (array_slice($amb, 0, 50, true) as $by => $a) {
            $tier = ''; foreach ($AMB as $min => $lab) if ($a['s'] >= $min) { $tier = $lab; break; }
            if ($a['s'] === $topS && $a['s'] >= 5) $tier = 'Top ambassador';
            $same = !empty($a['ip']) ? max($a['ip']) : 0;
            $wal = (string)($rholders[$by]['wallet'] ?? '');
            echo '<tr><td><b>' . h($rpl[$by]['name'] ?? substr($by, 0, 6)) . '</b></td><td>' . (int)($a['n'] ?? 0) . '</td><td>' . (int)($a['h'] ?? 0) . '</td><td><b>' . (int)$a['s'] . '</b></td><td>' . (int)($a['w'] ?? 0) . '</td><td>' . ($same >= 3 ? '<i class="warn">' . $same . '</i>' : (int)$same) . '</td><td>' . ($tier !== '' ? '<i class="ok">' . h($tier) . '</i>' : '<span class="muted">-</span>') . '</td><td>' . ($wal !== '' ? '<code style="white-space:nowrap;user-select:all;font-size:12px">' . h($wal) . '</code>' : '<span class="muted">No wallet</span>') . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    // Daily X tasks: settings, and the latest posts that earned Koban, to spot-check
    $xs = eco_settings(); $xall = load(XTASKS) + ['log' => [], 'h' => []]; $xpl = load(PLAYERS);
    $xToday = array_filter($xall['log'], fn($r) => $r['t'] >= strtotime(today() . ' 00:00:00 UTC'));
    echo '<h2>Daily X tasks <small>' . count($xToday) . ' posts counted today &middot; ' . count(array_unique(array_column($xToday, 'pid'))) . ' players &middot; ' . count($xall['h']) . ' X accounts tied</small></h2>';
    echo '<p class="muted">Players post on X, paste the link in the Dojo, and the site checks the post with X\'s free embed service (no X credits): it has to be public, from the player\'s X account, made today (UTC), and say what the task asks. Each post counts once and each X account belongs to one player. Today: ' . h(implode(', ', array_map(fn($id) => XT_POOL[$id]['text'], xt_today()))) . '. Holders earn double.</p>';
    if (can('shop', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="xt_on" value="1"' . (!empty($xs['xt_on']) ? ' checked' : '') . '> X tasks on</label><span class="muted">Koban per task</span><input name="xt_koban" type="number" min="0" value="' . (int)$xs['xt_koban'] . '" style="width:90px"><span class="muted">Bonus for all three</span><input name="xt_bonus" type="number" min="0" value="' . (int)$xs['xt_bonus'] . '" style="width:90px"><button name="do" value="xt-settings">Save</button></form>';
    if ($xall['log']) {
        echo '<div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Task</th><th>Post</th><th>Koban</th><th></th></tr></thead><tbody>';
        foreach (array_slice($xall['log'], 0, 40, true) as $i => $r) {
            $back = !empty($r['rev']) ? '<i class="warn">Taken back</i>' : (can('gifts', 2) ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="i" value="' . (int)$i . '"><input type="hidden" name="t" value="' . (int)$r['t'] . '"><button name="do" value="xt-revoke" class="danger" data-confirm="Take back ' . (int)$r['k'] . ' Koban for this post?">Take back</button></form>' : '');
            echo '<tr><td>' . h(gmdate('M j H:i', $r['t'])) . '</td><td><b>' . h($xpl[$r['pid']]['name'] ?? substr($r['pid'], 0, 6)) . '</b></td><td>' . h(XT_POOL[$r['task']]['text'] ?? $r['task']) . '</td><td><a href="' . h($r['url']) . '" target="_blank" rel="noopener">' . h(preg_replace('#^https://x\.com/#', '@', preg_replace('#/status/(\d+)$#', '', $r['url']))) . '</a></td><td>' . (int)$r['k'] . '</td><td class="acts">' . $back . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    if (can('shop', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input name="handle" placeholder="@handle" required><button name="do" value="xt-free" data-confirm="Free this X account so its player can tie a different one?">Free this X account</button><span class="muted">Lets its player tie a different X account (for example after they change accounts).</span></form>';
    // payments players pointed us to that couldn't be matched on their own
    $help = array_filter(load(DATA_DIR . '/pay-help.php'), fn($x) => $x['status'] === 'open');
    if ($help) {
        uasort($help, fn($a, $b) => $b['ts'] <=> $a['ts']);
        $whyL = ['late' => 'Paid after the price hold, below today\'s price', 'short' => 'Paid less than the price', 'wallet' => 'Sent from a wallet not linked to the player', 'failed' => 'Failed on Solana', '' => 'No matching order found'];
        echo '<h2>Payment help <small>' . count($help) . ' open</small></h2><p class="muted">Players pasted these payments from their wallet after an order didn\'t arrive, and the site couldn\'t match them on its own. Open the transaction, check who sent what, then press <b>Check with this payment</b> on the right order, or <b>Deliver by hand</b> once you\'re sure.</p><div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Payment</th><th>Why it needs a look</th><th></th></tr></thead><tbody>';
        foreach ($help as $hid => $x) {
            $forms = '';
            foreach (array_slice($x['orders'], 0, 4) as $oid) if (isset($orders[$oid]) && $orders[$oid]['status'] !== 'paid') $forms .= '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($oid) . '"><input type="hidden" name="sig" value="' . h($x['sig']) . '"><input type="hidden" name="help" value="' . h($hid) . '"><button name="do" value="order-check">Check with this payment: ' . h($orders[$oid]['name']) . ' $' . number_format($orders[$oid]['usd'], 2) . '</button></form>';
            //MC 2026-10-11 a late payment can be honoured at the price it was quoted at
            if (($x['why'] ?? '') === 'late') foreach (array_slice($x['orders'], 0, 4) as $oid) if (isset($orders[$oid]) && $orders[$oid]['status'] !== 'paid') $forms .= '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($oid) . '"><input type="hidden" name="sig" value="' . h($x['sig']) . '"><input type="hidden" name="help" value="' . h($hid) . '"><input type="hidden" name="late" value="1"><button name="do" value="order-check" class="ghost" data-confirm="Deliver this order at the price it was quoted at, even though the payment came after the price hold?">Deliver at the quoted price</button></form>';
            echo '<tr><td>' . h(gmdate('M j H:i', $x['ts'])) . '<small>#' . h($hid) . '</small></td><td><b>' . h($players[$x['pid']]['name'] ?? substr($x['pid'], 0, 6)) . '</b><small>' . h(short_w(load(HOLDERS)[$x['pid']]['wallet'] ?? '')) . '</small></td>' .
                '<td><a href="https://solscan.io/tx/' . h($x['sig']) . '" target="_blank" rel="noopener">' . h(substr($x['sig'], 0, 10)) . '…</a>' . ($x['note'] !== '' ? '<small>&ldquo;' . h($x['note']) . '&rdquo;</small>' : '') . '</td><td class="small">' . h($whyL[$x['why']] ?? $x['why']) . '</td>' .
                '<td class="acts">' . $forms . '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="help" value="' . h($hid) . '"><button name="do" value="payhelp-close" class="ghost" data-confirm="Mark this payment request sorted? It leaves the list.">Mark sorted</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }
    //MC 2026-10-11 the nightly payment check (recon_run in opslib.php): payments found on Solana for orders that weren't
    //   delivered. Delivered ones are listed for the record; the rest wait for a person, with the same buttons as above.
    $rcAll = load(OPS_RECON); $rcOpen = recon_open();
    echo '<h2 id="recon">Nightly payment check <small>' . (!empty($rcAll['t']) ? 'last run ' . h(ago($rcAll['t'])) . ' &middot; ' . (int)($rcAll['checked'] ?? 0) . ' checked' : 'not run yet') . '</small></h2>';
    echo '<p class="muted">Every night after 03:00 UTC the cron job looks up open orders that have a wallet signature or a Payment help request on Solana again. It delivers only what the shop would have delivered on its own (the payment carries the order\'s reference, covers the price and came within a day). Anything else that found money is listed here for you to decide.' .
        (!empty($rcAll['rpc']) ? ' <i class="warn">Solana could not be reached for ' . (int)$rcAll['rpc'] . ' of them last time.</i>' : '') . (!empty($rcAll['waiting']) ? ' ' . (int)$rcAll['waiting'] . ' more wait for the next run.' : '') . '</p>';
    if (can('shop', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="recon-run" class="ghost">Run the check now</button><span class="muted small">Takes up to a couple of minutes with many open orders.</span></form>';
    if ($rcOpen) {
        echo '<div class="tw"><table><thead><tr><th>Order</th><th>Player</th><th>Item</th><th>What the check found</th><th></th></tr></thead><tbody>';
        foreach ($rcOpen as $x) {
            $sig = (string)($x['sig'] ?? '');
            $f = '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($x['id']) . '"><input type="hidden" name="sig" value="' . h($sig) . '">' . ($x['help'] !== '' ? '<input type="hidden" name="help" value="' . h(explode(',', $x['help'])[0]) . '">' : '') . '<button name="do" value="order-check">Check with this payment</button></form>';
            if (($x['kind'] ?? '') === 'late') $f .= '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($x['id']) . '"><input type="hidden" name="sig" value="' . h($sig) . '"><input type="hidden" name="late" value="1">' . ($x['help'] !== '' ? '<input type="hidden" name="help" value="' . h(explode(',', $x['help'])[0]) . '">' : '') . '<button name="do" value="order-check" class="ghost" data-confirm="Deliver this order at the price it was quoted at?">Deliver at the quoted price</button></form>';
            echo '<tr><td class="nw">' . h(gmdate('M j H:i', $x['ts'])) . '<small>' . h($x['id']) . '</small></td><td><b>' . h($players[$x['pid']]['name'] ?? substr($x['pid'], 0, 6)) . '</b></td><td>' . h($x['name']) . '<small>$' . number_format($x['usd'], 2) . ' in ' . h($x['cur']) . '</small></td>' .
                '<td class="small">' . h($x['what']) . ($sig !== '' ? ' <a href="https://solscan.io/tx/' . h($sig) . '" target="_blank" rel="noopener">tx</a>' : '') . ($x['help'] !== '' ? '<small>Payment help #' . h($x['help']) . '</small>' : '') . '</td><td class="acts">' . (can('shop', 2) ? $f : '') . '</td></tr>';
        }
        echo '</tbody></table></div>';
    } elseif (!empty($rcAll['t'])) echo '<p class="muted">Nothing paid and undelivered.</p>';
    if (!empty($rcAll['done'])) echo '<p class="muted small">Delivered by the last check: ' . h(implode(', ', array_map(fn($x) => $x['name'] . ' for ' . ($players[$x['pid']]['name'] ?? substr($x['pid'], 0, 6)) . ' (' . $x['id'] . ')', $rcAll['done']))) . '.</p>';
    echo '<h2>Orders <small>latest 150</small></h2><div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Item</th><th>Paid with</th><th>Status</th><th></th></tr></thead><tbody>';
    foreach (array_slice($orders, 0, 150, true) as $id => $o) {
        $amt = $o['cur'] === 'CARD' ? 'Card' : rtrim(rtrim(number_format($o['units'] / pow(10, $o['dec']), $o['dec'], '.', ''), '0'), '.') . ' ' . $o['cur'];
        $proof = $o['proof'] ?? '';
        $link = $proof && strpos($proof, 'manual') !== 0 ? (strpos($proof, 'cs_') === 0 ? '<small>Stripe ' . h(substr($proof, 0, 14)) . '</small>' : '<a href="https://solscan.io/tx/' . h($proof) . '" target="_blank" rel="noopener">tx</a>') : h($proof);
        echo '<tr><td>' . h(gmdate('M j H:i', $o['ts'])) . '<small>' . h($id) . '</small></td><td><b>' . h($players[$o['pid']]['name'] ?? substr($o['pid'], 0, 6)) . '</b><small>' . h(short_w($o['wallet'] ?? '')) . '</small></td><td>' . h($o['name']) . '<small>$' . number_format($o['usd'], 2) . '</small></td><td>' . h($amt) . '</td>' .
            '<td>' . ($o['status'] === 'paid' ? '<i class="ok">Paid</i> ' . $link : h(ucfirst($o['status'])) . ($o['ts'] < time() - 1200 ? ' <small>expired quote</small>' : '')) . '</td>' .
            '<td class="acts">' . ($o['status'] !== 'paid' && $o['cur'] !== 'CARD' ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($id) . '"><input name="sig" placeholder="Tx signature or Solscan link (optional)" value="' . h($o['sig'] ?? '') . '"><button name="do" value="order-check">Check on Solana</button></form>' : '') . ($o['status'] !== 'paid' ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="order" value="' . h($id) . '"><button name="do" value="order-paid" class="ghost" data-confirm="Deliver this order without an on-chain check? Only do this after you have confirmed the payment yourself.">Deliver by hand</button></form>' : '') . '</td></tr>';
    }
    if (!$orders) echo '<tr><td colspan="6" class="muted">No orders yet.</td></tr>';
    echo '</tbody></table></div>';
}

if ($tab === 'rewards') {
    $set = eco_settings();
    $rw = with_lock(fn() => load(REWARDS));
    $pool = league_pool_usd();
    $px = price_usd(SHY_MINT);
    //MC 2026-10-11 what's owed and what's next, in words
    $owedN = 0; $owedUsd = 0;
    foreach (payall_lists($rw) as [$per, $lab]) { $ref = &payout_list($rw, $per); foreach ((array)$ref as $w) if (empty($w['sig']) && empty($w['skip'])) { $owedN++; $owedUsd += (float)($w['usd'] ?? 0); } unset($ref); }
    $bd0 = bounty_db(); $bOwed = 0; foreach ($bd0['m'] as $bw) if (empty($bw['paid'])) $bOwed++;
    $closes = strtotime('next monday 00:00:00 UTC');
    glance([
        [$owedN ? number_format($owedN) . ' to pay' : 'All paid', $owedN ? 'prizes waiting, $' . number_format($owedUsd, 2) . ' in total. Payouts, then Review and pay' : 'every frozen prize list is paid', $owedN ? 'warn' : 'ok'],
        ['$' . number_format($pool['total'], 2), 'this week\'s Weekly League prize pool'],
        [gmdate('D M j', $closes), 'this week closes (00:00 UTC), ' . (($dl = max(1, (int)ceil(($closes - time()) / 86400))) === 1 ? 'tomorrow or sooner' : 'in ' . $dl . ' days')],   //MC 2026-10-11 said "in 1 days"
        [$bOwed ? $bOwed . ' unpaid' : 'Nothing owed', '15 Club bounty' . ($bOwed ? ': pay it from Payouts' : ''), $bOwed ? 'warn' : ''],
        [$px ? '$' . rtrim(rtrim(number_format($px, 8), '0'), '.') : 'unknown', 'price of 1 $SHY used for payouts'],
    ]);
    echo '<p class="muted">Prizes are paid in $SHY from the marketing wallet. When a week or season ends its results freeze here. Press <b>Set amounts</b> to price them in $SHY, check the list, then <b>Send with Phantom</b> with the marketing wallet connected. Each batch is checked on Solana before winners are marked paid.' . ($px ? ' $SHY now: $' . h(rtrim(rtrim(number_format($px, 10, '.', ''), '0'), '.')) . '.' : ' <i class="bad">No $SHY price right now.</i>') . '</p>';
    //MC 2026-10-12 Fix a final week: League points taken off after the week froze (alts, a struck match), the prize lists
    //   worked out again, and the corrected results posted to Telegram in place of the old post
    if (can('rewards', 2)) {
        $fw = array_keys($rw['weeks'] ?? []); rsort($fw); $fw = array_slice($fw, 0, 3);
        $plN = load(PLAYERS);
        echo '<div class="rw"><h2 id="lgfix">Fix a final week</h2><p class="muted">When a week has ended and its results need changing before anyone is paid: take League points off a player (alt accounts, a match that shouldn\'t count), or strike single matches on the <a href="?tab=fairplay">Fair Play</a> page, which lands here too. The prize lists are worked out again, the in-game Koban for the top 10 is evened up, and you can post the corrected results to Telegram, taking down the old post. A week that is already paid can\'t be changed.</p>';
        if (!$fw) echo '<p class="muted">No final weeks yet.</p>';
        foreach ($fw as $wk) {
            $w = $rw['weeks'][$wk]; $paid = league_week_paid($rw, $wk);
            echo '<div class="lgfix"><h3>Week ' . (int)substr($wk, 5) . ' <small>' . h(week_label($wk)) . '</small> ' . ($paid ? '<span class="pill">Paid, locked</span>' : (!empty($w['fixed']) ? '<span class="pill warn">Corrected ' . h(ago($w['fixed'])) . '</span>' : '<span class="pill on">Not paid yet</span>')) . '</h3>';
            echo '<div class="tw"><table><thead><tr><th>#</th><th>Player</th><th>League points</th><th>Prize</th></tr></thead><tbody>';
            $inPrize = []; foreach ($w['league'] ?? [] as $i => $x) $inPrize[$x['tag'] ?? substr($x['pid'], 0, 6)] = $x;
            foreach (array_slice($w['top'] ?? [], 0, 15) as $i => $r) {
                $a = $w['adj'][$r['tag']] ?? null; $pz = $inPrize[$r['tag']] ?? null;
                echo '<tr><td>' . ($i + 1) . '</td><td><b>' . h($r['name']) . '</b>' . ($a ? '<small>' . h(-$a['pts'] > 0 ? '+' . (-$a['pts']) : (string)(-$a['pts'])) . ' pts: ' . h(implode('; ', array_slice($a['why'], -3))) . '</small>' : '') . '</td><td>' . number_format($r['pts']) . '</td><td>' . ($pz ? '#' . (int)$pz['place'] . ', $' . number_format((float)$pz['usd'], 2) : '<span class="muted">no prize</span>') . '</td></tr>';
            }
            echo '</tbody></table></div>';
            if (!$paid) {
                $opts = ''; foreach ($w['top0'] ?? $w['top'] ?? [] as $r) $opts .= '<option value="' . h($r['tag']) . '">' . h($r['name']) . ' (' . number_format($r['pts']) . ' pts)</option>';
                echo '<form method="post" class="lgfix-f"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="wk" value="' . h($wk) . '"><input type="hidden" name="op" value="adjust">' .
                    '<div class="grid2"><label>Player<select name="tag">' . $opts . '</select></label><label>League points to take off<input name="pts" type="number" step="5" placeholder="665"><small class="muted">A minus number gives points back.</small></label>' .
                    '<label>League games to take off<input name="n" type="number" min="0" value="0"><small class="muted">How many of their counted games go with the points (for the minimum games rule).</small></label><label>Reason<input name="why" maxlength="120" placeholder="Alt accounts: Rhnkyrshy, Moppazant"></label></div>' .
                    '<div class="bar"><button name="do" value="lg-week" data-confirm="Take these points off and work out the prize lists again?">Take off and rebuild</button></div></form>' .
                    '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="wk" value="' . h($wk) . '"><input type="hidden" name="op" value="rebuild"><button name="do" value="lg-week" class="ghost">Rebuild the prize lists</button><span class="muted small">After banning a player, so they drop out and the next player moves up.</span></form>';
            }
            echo '<form method="post" class="lgfix-post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="wk" value="' . h($wk) . '"><input type="hidden" name="op" value="post">' .
                '<label class="chk"><input type="checkbox" name="del_old" value="1" checked> Take the old results post out of the chat</label>' .
                '<label class="chk"><input type="checkbox" name="pin" value="1" checked> Pin the corrected post</label>' .
                '<label>Old post link <small class="muted">(only if it went out before Oct 12)</small><input name="old_link" placeholder="https://t.me/c/.../123" spellcheck="false"></label>' .
                '<div class="bar"><button name="do" value="lg-week" data-confirm="Post the corrected week ' . (int)substr($wk, 5) . ' results to the Telegram chat?">Post the corrected results to Telegram</button>' .
                (!empty($w['league']) ? '<a class="btn ghost" href="' . h(x_intent(x_week_text($wk, $w['league'], !empty($w['fixed'])))) . '" target="_blank" rel="noopener">Post the winners on X</a>' : '') . '</div></form></div>';
        }
        echo '</div>';
    }
    $periods = [];
    foreach ($rw['weeks'] ?? [] as $wk => $w) { $periods[] = ['week:' . $wk . ':league', 'Weekly League, ' . week_label($wk), $w['league'], $w['pool']['total'] ?? 0]; $periods[] = ['week:' . $wk . ':cup', 'Holder Cup, ' . week_label($wk), $w['cup'], $w['cupPool'] ?? 0]; }
    foreach ($rw['seasons'] ?? [] as $sn => $se) $periods[] = ['season:' . $sn, 'Season ' . $sn . ' Championship', $se['winners'], $se['pool']];
    if (!can('payouts')) $periods = [];
    else echo '<div class="' . (can('payouts', 2) ? 'rw' : 'ro') . '"><h2>Payouts' . (can('payouts', 2) ? '' : ' <small>view only</small>') . '</h2>';
    //MC 2026-10-10 the one button: everything owed in one Phantom approval
    if (can('payouts', 2)) echo '<div class="payall" id="payall"><div class="payall-hd"><div><b>Pay everything owed</b><p class="muted">Prices any list that isn\'t priced yet at today\'s $SHY price, then sends every prize still owed (Weekly League, Holder Cup, Seasons and the 15 Club bounty) and any burn the shop still owes, all in one approval in Phantom with the marketing wallet connected. Each transaction is checked on Solana before anyone is marked paid. Then it posts the payouts to Telegram and gives you a ready X post.</p></div><button class="send" data-payall>Review and pay</button></div><div class="payall-out" hidden></div><details class="payall-settle"><summary>Paid a prize another way? Settle it with its transaction</summary><p class="muted">Paste the Solana signature or Solscan link. Every prize still owed that it really paid, and any owed burn in it, is checked on chain and marked paid.</p><div class="payall-act"><input id="payall-sig" placeholder="Signature or solscan.io/tx/&hellip; link" autocomplete="off"><button class="ghost" data-payall-settle>Check and settle</button></div><p class="payall-settle-msg" aria-live="polite"></p></details></div>';
    if (can('payouts') && !$periods) echo '<p class="muted">Nothing to pay yet. The first week freezes Monday 00:00 UTC.</p>';
    $heldRows = payall_held($rw);   //MC 2026-10-11 prizes in a batch Solana hasn't confirmed yet: no Send for them
    foreach (array_slice($periods, 0, 12) as [$pk, $label, $list, $pl]) {
        if (!$list) { echo '<details><summary>' . h($label) . ' <small class="muted">no eligible winners</small></summary></details>'; continue; }
        $open = 0; foreach ($list as $w) if (empty($w['sig']) && empty($w['skip'])) $open++;
        echo '<details' . ($open ? ' open' : '') . '><summary>' . h($label) . ' &middot; $' . number_format($pl, 2) . ' &middot; ' . ($open ? $open . ' to pay' : '<i class="ok">all paid</i>') . '</summary>';
        echo '<div class="tw"><table data-period="' . h($pk) . '"><thead><tr><th>#</th><th>Winner</th><th>Wallet</th><th>USD</th><th>$SHY</th><th>Status</th><th></th></tr></thead><tbody>';
        foreach ($list as $i => $w) {
            echo '<tr data-wallet="' . h($w['wallet']) . '" data-dec="' . (int)($w['dec'] ?? 6) . '" data-units="' . h($w['units'] ?? '') . '" data-paid="' . (!empty($w['sig']) || !empty($w['skip']) ? 1 : 0) . '"' . (empty($w['sig']) && isset($heldRows['l:' . $pk . ':' . $i]) ? ' data-held="1"' : '') . '><td>' . (int)$w['place'] . '</td><td><b>' . h($w['name']) . '</b><small>' . (int)($w['pts'] ?? 0) . ' pts, ' . (int)($w['n'] ?? 0) . ' games</small></td><td><a href="https://solscan.io/account/' . h($w['wallet']) . '" target="_blank" rel="noopener">' . h(short_w($w['wallet'])) . '</a></td>' .
                '<td>$' . number_format($w['usd'], 2) . '</td><td>' . (isset($w['shy']) ? number_format($w['shy']) : '<span class="muted">not set</span>') . '</td>' .
                '<td>' . (!empty($w['sig']) ? '<i class="ok">Paid</i> <a href="https://solscan.io/tx/' . h($w['sig']) . '" target="_blank" rel="noopener">tx</a>' : (!empty($w['skip']) ? '<span class="muted">Left out</span>' : (isset($heldRows['l:' . $pk . ':' . $i]) ? '<span class="muted">Sent, waiting for Solana</span>' : 'Waiting'))) . '</td>' .
                '<td class="acts">' . (empty($w['sig']) ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="period" value="' . h($pk) . '"><input type="hidden" name="i" value="' . (int)$i . '"><button name="do" value="payout-skip" class="ghost" data-confirm="' . (!empty($w['skip']) ? 'Put ' . h($w['name']) . ' back on this prize list?' : 'Leave ' . h($w['name']) . ' out of this prize list? They won\'t be paid for it.') . '">' . (!empty($w['skip']) ? 'Include' : 'Leave out') . '</button></form>' : '') . '</td></tr>';
        }
        echo '</tbody></table></div>';
        if ($open) {
            $blk = payout_block($rw, $pk); $ap = $rw['appr'][$pk] ?? [];
            $priced = true; foreach ($list as $w) if (empty($w['sig']) && empty($w['skip']) && empty($w['units'])) $priced = false;
            $mineToApprove = $priced && $blk && ($ap['prepId'] ?? '') !== ($ME['id'] ?? '') && empty($ME['key']);
            echo '<div class="bar" style="margin-top:8px"><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="period" value="' . h($pk) . '"><button name="do" value="payout-prepare"' . ($priced ? ' class="ghost"' : '') . '>Set amounts at today\'s price</button></form>';
            if ($blk && $mineToApprove) echo '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="period" value="' . h($pk) . '"><button name="do" value="payout-approve" data-confirm="Approve sending ' . h(number_format(payout_open_usd($list), 2)) . ' USD of $SHY to these winners? Check the wallets and amounts first.">Approve this payout</button></form>';
            echo '<button class="send" data-send="' . h($pk) . '"' . ($blk ? ' disabled' : '') . '>Send with Phantom</button><span class="muted send-msg">';
            if ($blk === 'needs') echo $priced ? 'Over $' . h(number_format((float)eco_settings()['payout_approve_usd'], 0)) . ', so a second admin approves it before it can be sent' . (!empty($ap['prep']) ? ' (priced by ' . h($ap['prep']) . ')' : '') . '.' : 'Set the amounts, then a second admin approves.';
            elseif ($blk === 'changed') echo 'The list changed after ' . h($ap['by']) . ' approved it, so it needs approving again.';
            elseif (!empty($ap['by'])) echo 'Approved by ' . h($ap['by']) . ' ' . h(ago($ap['byAt'] ?? 0)) . '.';
            echo '</span></div>';
        }
        echo '</details>';
    }

    if (can('payouts')) echo '</div>';
    if (!can('rewards')) { echo '</div>'; goto rewards_done; }
    echo '<div class="' . (can('rewards', 2) ? 'rw' : 'ro') . '">';
    echo '<h2>Prize pools and rules' . (can('rewards', 2) ? '' : ' <small>view only</small>') . '</h2><form method="post" class="settings"><input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    $f = function ($name, $label, $val, $hint = '', $type = 'number') { echo '<label><span>' . h($label) . '</span><input name="' . h($name) . '" type="' . $type . '" step="any" value="' . h($val) . '">' . ($hint ? '<small>' . h($hint) . '</small>' : '') . '</label>'; };
    //MC 2026-10-11 the same fields, grouped so each block says what it's for; the Army Ranks are one table (rank, $SHY needed, weekly Koban)
    $fs = function ($t, $d) { echo '<fieldset class="fs"><legend>' . h($t) . '</legend>' . ($d ? '<p class="fs-d">' . h($d) . '</p>' : ''); };
    //MC 2026-10-12 Prize budget: the runway first (wallet, prizes a week, shop a week), then how each pool is sized
    $run = prize_runway(shy_balance(mw_address()));
    $wkTxt = $run['weeks'] === null ? 'unknown (wallet balance not available)' : (is_finite($run['weeks']) ? number_format($run['weeks'], 1) . ' weeks' : 'the shop covers the prizes');
    $low = $run['weeks'] !== null && is_finite($run['weeks']) && $run['weeks'] < $run['warn'];
    echo '<fieldset class="fs" id="budget"><legend>Prize budget</legend><p class="fs-d">How long the marketing wallet lasts at this week\'s pools, and how each pool is sized. Shop payments land in the same wallet, so they count against what goes out.</p>';
    $st = fn($label, $big, $sub = '', $warn = false) => '<div class="stat"' . ($warn ? ' style="border-color:#e8a23a"' : '') . '><b' . ($warn ? ' style="color:#ffb44a"' : '') . '>' . h($big) . '</b><span>' . h($label) . ($sub ? ' · ' . h($sub) : '') . '</span></div>';
    echo '<div class="grid" style="grid-column:1/-1">' . $st('Runway', $wkTxt, '', $low) . $st('Wallet', $run['usd'] === null ? '?' : '$' . number_format($run['usd'], 2), $run['shy'] !== null ? number_format($run['shy']) . ' $SHY' : '') .
        $st('Prizes a week', '$' . number_format($run['out'], 2), 'League, Cup, Season, 15 Club') . $st('Shop a week', '$' . number_format($run['in'], 2), 'last 4 weeks') . '</div>';
    $sales = ($set['prize_mode'] ?? 'fixed') === 'sales';
    echo '<label style="grid-column:1/-1"><span>How pools are sized</span><select name="prize_mode"><option value="sales"' . ($sales ? ' selected' : '') . '>From shop sales: floor + a % of sales, up to a max</option><option value="fixed"' . ($sales ? '' : ' selected') . '>Fixed amounts (the pool fields below)</option></select><small>From shop sales: the League and Cup use the week before\'s sales, the Season uses its own. A quiet week costs only the floor.</small></label>';
    echo '<div class="tw" style="grid-column:1/-1"><table class="ranks"><thead><tr><th>Pool</th><th>Floor (USD)</th><th>% of shop sales</th><th>Max (USD)</th><th>Places paid in $SHY</th><th>Now</th></tr></thead><tbody>';
    foreach (['league' => ['Weekly League', league_pool_usd()['total'], count($set['league_split'])], 'cup' => ['Holder Cup', cup_pool_usd(), count($set['cup_split'])], 'season' => ['Season Championship', season_pool_usd(), count($set['season_split'])]] as $k => [$lab, $nowUsd, $places]) {
        $c = prize_cfg($k);
        echo '<tr><td><b>' . h($lab) . '</b></td><td><input name="pp_' . $k . '_floor" type="number" min="0" step="any" value="' . h($c['floor']) . '"></td><td><input name="pp_' . $k . '_pct" type="number" min="0" max="100" step="any" value="' . h($c['pct']) . '"></td><td><input name="pp_' . $k . '_max" type="number" min="0" step="any" value="' . h($c['max']) . '"></td>' .
            '<td><input name="cash_' . $k . '" type="number" min="1" max="10" step="1" value="' . (int)($set['cash_top'][$k] ?? $places) . '"><small>of ' . $places . '</small></td><td>$' . number_format($nowUsd, 2) . '</td></tr>';
    }
    echo '</tbody></table></div>';
    $f('kswap', 'Koban per $1 for places below the $SHY places', $set['kswap'] ?? 150, 'Those places win Koban instead: their share of the pool times this, on top of their usual Koban. A $1 pack is 120 Koban. Only in "From shop sales".');
    $f('runway_warn', 'Email the team when the wallet covers fewer weeks than', $set['runway_warn'] ?? 4, 'Checked every Monday when the week is final. 0 turns it off.');
    echo '</fieldset>';
    $fs('Weekly League', 'Paid every Monday to the top 10 of the week. Splits are percentages of the pool, top place first, and must add up to 100. The pool fields here are used in "Fixed amounts".');
    $f('league_usd', 'Base prize pool (USD)', $set['league_usd'], 'This week: $' . number_format($pool['total'], 2) . ', including $' . number_format($pool['share'], 2) . ' from last week\'s shop');
    $f('league_share', 'Add this % of last week\'s shop sales', $set['league_share']);
    $f('league_split', 'Split for places 1 to 10 (%)', implode(',', $set['league_split']), '', 'text');
    $f('min_games', 'Games a player needs that week to win a prize', $set['min_games'], 'A Season needs twice this');
    echo '</fieldset>';
    $fs('Holder Cup and Season Championship', 'The Holder Cup is a weekly prize for $SHY holders only. The Season Championship pays at the end of each season.');
    $f('cup_usd', 'Holder Cup prize pool (USD)', $set['cup_usd']);
    $f('cup_split', 'Holder Cup split (%)', implode(',', $set['cup_split']), '', 'text');
    $f('season_usd', 'Season Championship prize pool (USD)', $set['season_usd']);
    $f('season_split', 'Season split (%)', implode(',', $set['season_split']), '', 'text');
    echo '</fieldset>';
    //MC 2026-10-12 Koban prizes: one row per place, the League and the Holder Cup side by side. Paid into the game the moment
    //   a week is final, on top of the $SHY. Places past a list's split get nothing, whatever is typed.
    echo '<fieldset class="fs"><legend>Koban prizes</legend><p class="fs-d">In-game Koban paid the moment a week is final, on top of the $SHY. Set 0 for none. The Holder Cup only pays as many places as its split has (' . count($set['cup_split']) . ' now).</p>';
    echo '<div class="tw" style="grid-column:1/-1"><table class="ranks kob"><thead><tr><th>Place</th><th>Weekly League</th><th>Holder Cup</th></tr></thead><tbody>';
    for ($i = 0; $i < 10; $i++) echo '<tr><td><b>#' . ($i + 1) . '</b></td><td><input name="league_koban[' . $i . ']" type="number" min="0" step="10" value="' . (int)($set['league_koban'][$i] ?? 0) . '" aria-label="League place ' . ($i + 1) . ' Koban"></td><td><input name="cup_koban[' . $i . ']" type="number" min="0" step="10" value="' . (int)($set['cup_koban'][$i] ?? 0) . '" aria-label="Holder Cup place ' . ($i + 1) . ' Koban"' . ($i >= count($set['cup_split']) ? ' disabled title="The Cup pays ' . count($set['cup_split']) . ' places"' : '') . '></td></tr>';
    echo '</tbody></table></div></fieldset>';
    echo '<fieldset class="fs"><legend>$SHY Army Ranks</legend><p class="fs-d">How much $SHY a wallet needs for each rank, and the Koban each rank collects every week. Each rank must need more $SHY than the one above it in this list.</p>';
    echo '<div class="tw" style="grid-column:1/-1"><table class="ranks"><thead><tr><th>Rank</th><th>$SHY needed</th><th>Weekly Koban</th><th>Also gets</th></tr></thead><tbody>';
    echo '<tr><td><b>Shadow holder</b><small>holds a Shytoshi Shadow</small></td><td class="muted">any</td><td><input name="hstip_shadow" type="number" step="any" value="' . h($set['hstip']['shadow']) . '"></td><td class="muted">NFT holders with no rank</td></tr>';
    foreach (HOLDER_LADDER as $t) { $hp = holder_perks($t);
        echo '<tr><td><b>' . h(HOLDER_NAMES[$t]) . '</b><small>' . h(HOLDER_CIRCLE[$t]) . '</small></td><td><input name="htier_' . h($t) . '" type="number" step="any" value="' . h($set['htiers'][$t]) . '"></td><td><input name="hstip_' . h($t) . '" type="number" step="any" value="' . h($set['hstip'][$t]) . '"></td><td class="muted">' . (int)$hp['disc'] . '% off, ' . h($hp['gift']) . 'x daily gift</td></tr>'; }
    echo '</tbody></table></div></fieldset>';
    $fs('Shop and payouts', '');
    $f('burn_pct', 'Burned from every $SHY shop payment (%)', $set['burn_pct'], 'Burned on Solana in the buyer\'s own payment. 0 turns it off. Up to 50.');
    $f('bounty_usd', '15 Club bounty prize (USD, paid in $SHY)', $set['bounty_usd'], 'What the payout button sends the month\'s winner.');
    $f('founder_until', 'Founder\'s Bundle on sale until (UTC date)', $set['founder_until'], '', 'date');
    if (is_owner()) $f('payout_approve_usd', 'Prize lists from this many USD need a second admin to approve', $set['payout_approve_usd'], 'Owners only. 0 turns approvals off.');
    echo '<label class="chk"><input type="checkbox" name="shop_open" value="1"' . ($set['shop_open'] ? ' checked' : '') . '> Shop open</label></fieldset>';
    echo '<button name="do" value="eco-settings" data-confirm="Save the prize pools and rules? Players see the new numbers right away.">Save</button></form>';

    // Daily runs from before the League existed earned no League points: count them once, by hand
    $wkStart = strtotime('monday this week 00:00:00 UTC');
    $missing = [];
    foreach ($daily as $day => $rows) {
        if (strtotime($day . ' 00:00:00 UTC') < $wkStart) continue;
        foreach ($rows as $dpid => $d) if (empty($d['lg']) && empty($d['lgx'])) $missing[] = [$day, $dpid, $d];
    }
    if ($missing) {
        echo '<h2>Daily runs not in the League <small>' . count($missing) . '</small></h2><p class="muted">These runs this week were played before the Weekly League started counting Daily runs, so they earned no League points. Runs from after the League went live on Oct 7, 2026 already count, so press <b>Not needed</b> on those. <b>Count it</b> adds the run\'s points to that player\'s League total once.</p><div class="tw"><table><thead><tr><th>Day</th><th>Player</th><th>Run</th><th>League now</th><th></th></tr></thead><tbody>';
        foreach ($missing as [$day, $dpid, $d]) {
            $p = $players[$dpid] ?? [];
            $lg = ($p['lg']['wk'] ?? '') === week_key() ? $p['lg'] : ['pts' => 0, 'n' => 0];
            echo '<tr><td>' . h($day) . '<small>' . h(gmdate('H:i', $d['ts'])) . ' UTC</small></td><td><b>' . h($p['name'] ?? substr($dpid, 0, 6)) . '</b></td><td>' . (int)$d['points'] . ' pts<small>' . (int)$d['regions'] . ' Regions, ' . h($d['result']) . '</small></td><td>' . (int)$lg['pts'] . ' pts<small>' . (int)$lg['n'] . ' games</small></td>' .
                '<td class="acts"><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="day" value="' . h($day) . '"><input type="hidden" name="pid" value="' . h($dpid) . '"><button name="do" value="league-credit" data-confirm="Give out this week\'s League Koban now?">Count it</button><button name="do" value="league-skip" class="ghost">Not needed</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }
    echo '<h2>Events</h2><p class="muted">Multiply League points for a set time, like a Double Points Weekend. Players see a countdown before and during it.</p><div class="tw"><table><thead><tr><th>Event</th><th>Starts (UTC)</th><th>Ends (UTC)</th><th>Points</th><th></th></tr></thead><tbody>';
    foreach ($set['events'] as $i => $e) echo '<tr><td><b>' . h($e['name']) . '</b></td><td>' . h(gmdate('M j H:i', $e['from'])) . '</td><td>' . h(gmdate('M j H:i', $e['to'])) . '</td><td>x' . h($e['mult']) . '</td><td><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="i" value="' . (int)$i . '"><button name="do" value="event-del" class="ghost">Remove</button></form></td></tr>';
    if (!$set['events']) echo '<tr><td colspan="5" class="muted">No events scheduled.</td></tr>';
    echo '</tbody></table></div><form method="post" class="bar" style="margin-top:8px"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input name="name" placeholder="Double Points Weekend" required><input name="from" type="datetime-local" required><input name="hours" type="number" value="48" style="width:90px" title="Hours"><input name="mult" type="number" step="0.5" value="2" style="width:80px" title="Multiplier"><button name="do" value="event-add">Add event</button></form>';
    echo '</div>';
    rewards_done:
    if (can('payouts', 2)) echo '<script src="../assets/vendor/solana-web3.min.js"></script><script>window.SHY = ' . json_encode(['csrf' => csrf(), 'mint' => SHY_MINT, 'mw' => mw_address(), 'kols' => array_values(array_filter(explode("\n", (string)(eco_settings()['x_kols'] ?? ''))))]) . ';</script>';
}

if ($tab === 'rewards') {
    $hs = house_settings(); $H = houses(); $hb = house_board($players, $H);
    echo '<h2 id="houses">Houses <small>' . count($H['h']) . ' Houses &middot; <a href="/houses" target="_blank" rel="noopener">open the page &#8599;</a></small></h2><p class="muted">Teams of up to ' . HOUSE_MAX . '. Members\' weekly points add up; when the week ends, every member of the top 3 Houses who played that week gets the Koban below. Founding one costs Koban (a sink) and needs a few games first.</p>';
    if (can('rewards', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="house_on" value="1"' . ($hs['on'] ? ' checked' : '') . '> Prizes on</label>' .
        '<span class="muted">Founding costs</span><input name="house_cost" type="number" min="0" value="' . $hs['cost'] . '" style="width:80px"><span class="muted">games first</span><input name="house_games" type="number" min="0" value="' . $hs['games'] . '" style="width:64px">' .
        '<span class="muted">Koban per member: 1st</span><input name="hp1" type="number" min="0" value="' . (int)$hs['prize'][0] . '" style="width:72px"><span class="muted">2nd</span><input name="hp2" type="number" min="0" value="' . (int)$hs['prize'][1] . '" style="width:72px"><span class="muted">3rd</span><input name="hp3" type="number" min="0" value="' . (int)$hs['prize'][2] . '" style="width:72px"><button name="do" value="house-settings">Save</button></form>';
    if ($hb) {
        echo '<div class="tw"><table><thead><tr><th>#</th><th>House</th><th>Members</th><th>This week</th><th>Head</th><th></th></tr></thead><tbody>';
        foreach (array_slice($hb, 0, 40) as $i => $r) { $hd = $H['h'][$r['id']]; echo '<tr><td>' . ($r['pts'] ? $i + 1 : '') . '</td><td><b>' . h($r['name']) . '</b> <small class="muted">' . h($r['tag']) . '</small></td><td>' . $r['size'] . '</td><td>' . number_format($r['pts']) . '</td><td>' . h($players[$hd['owner']]['name'] ?? '') . '</td><td>' . (can('rewards', 2) ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="id" value="' . h($r['id']) . '"><button name="do" value="house-del" class="danger" data-confirm="Close ' . h($r['name']) . '? Everyone in it is let go.">Close</button>' . (($hd['desc'] ?? '') !== '' ? '<button name="do" value="house-clear" class="ghost" title="' . h($hd['desc']) . '" data-confirm="Clear the About text of ' . h($r['name']) . '?">Clear About</button>' : '') . '</form>' : '') . '</td></tr>'; }
        echo '</tbody></table></div>';
    }
}

//MC 2026-10-11 owners only, one time: League points lost to bug #35. api/where.php saved each player's browser language
//   into 'lg', the key that holds their League week, so a League player who opened the site lost that week's points.
//   Pick a daily copy of the scores from before the bug; the table shows who has fewer League (this week) or Season points
//   now than in that copy. "Put them back" takes the higher of the two for each player, so nothing is ever lowered, and a
//   game played since the copy is never undone. It's logged in the activity log. Tried first: restoring the whole copy,
//   but that undoes every game and name change since, so only these two values come back.
//MC 2026-10-12 the Shogun: settings, the totals and the latest players to beat it
if ($tab === 'rewards' && can('rewards')) {
    require_once dirname(__DIR__) . '/api/bosslib.php';
    $bc = boss_cfg(); $bd = load(BOSS_DB); $bt = $bd['t'] ?? ['g' => 0, 'w' => 0, 'koban' => 0];
    echo '<div class="' . (can('rewards', 2) ? 'rw' : 'ro') . '"><h2 id="boss">The Shogun <small>' . ($bc['on'] ? '<i class="ok">On</i>' : '<i class="bad">Off</i>') . ' &middot; boss bot</small></h2>';
    echo '<p class="muted">A 1v1 against the hardest bot. Players start it from the Play page or with <b>/shilluminatiboss</b> in Telegram. The server plays the Shogun, so a win can\'t be faked, and a win only pays when the player played every turn themselves (no bot covering for them). Boss matches only go on the Shogun record: no leaderboard points, games or wins, and nothing toward the League or Ranked.</p>';
    glance([[number_format((int)$bt['g']), 'boss matches played'], [number_format((int)$bt['w']), 'won by players (' . ($bt['g'] ? round($bt['w'] / $bt['g'] * 100) : 0) . '%)'], [number_format(count(array_filter($bd['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0))), 'players have beaten it'], [number_format((int)$bt['koban']), 'Koban paid for boss wins']]);
    echo '<form method="post" class="settings"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><fieldset class="fs"><legend>Settings</legend>' .
        '<label class="chk" style="grid-column:1/-1;justify-self:start;width:max-content"><input type="checkbox" name="boss_on" value="1"' . ($bc['on'] ? ' checked' : '') . '> The Shogun takes challenges</label>' .   //MC 2026-10-12 the label ran the full width of the form, so a click anywhere on that row unticked it
        '<label><span>Koban for a win</span><input name="boss_koban" type="number" min="0" step="50" value="' . (int)$bc['koban'] . '"><small>0 pays nothing, wins still count on the record.</small></label>' .
        '<label><span>A player can win it</span><select name="boss_per"><option value="day"' . ($bc['per'] === 'day' ? ' selected' : '') . '>Once a day</option><option value="week"' . ($bc['per'] === 'week' ? ' selected' : '') . '>Once a week</option></select><small>Later wins in the same day or week count, but pay nothing.</small></label>' .
        '<label><span>Extra cards the Shogun starts with</span><input name="boss_edge" type="number" min="0" max="5" value="' . (int)$bc['edge'] . '"><small>0 to 5. Players are told. Each card makes it harder.</small></label>' .
        '<label><span>Thinking time per card (ms)</span><input name="boss_think" type="number" min="200" max="3500" step="100" value="' . (int)$bc['think'] . '"><small>More time, stronger play. 700 is a good balance on the host.</small></label>' .
        '<label><span>Boss matches a player can start a day</span><input name="boss_games" type="number" min="1" max="200" value="' . (int)$bc['games'] . '"></label>' .
        '</fieldset><button name="do" value="boss-settings">Save</button></form>';
    //MC 2026-10-12 Share on X: the "Can you beat the Shogun?" card with the reward as set above and the record right now
    //   (api/share.php?b=1), the post words to edit, and a button that opens X with them and the shyonsol.io/shogun link.
    //   The link carries ?v= with the hash of what is on the card, so X shows today's card, not one it cached last week.
    $bk = boss_card_data(); $bkUrl = boss_card_url($bk); $bkImg = '../api/share.php?b=1&h=' . $bk['h'];
    $bkTxt = "Can you beat the Shogun? \u{2694}\u{FE0F}\n\nThe hardest bot in Shilluminati. A 1v1, you against it." .
        ($bk['g'] ? "\nPlayers have won " . number_format($bk['w']) . ' of ' . number_format($bk['g']) . ' matches so far.' : '') .
        ($bk['on'] && $bk['koban'] > 0 ? "\nBeat it for " . number_format($bk['koban']) . ' Koban, once a ' . ($bk['per'] === 'week' ? 'week' : 'day') . '.' : '') . "\n\n\$SHY";
    echo '<h3 id="boss-share">Share on X</h3><div class="bsx"><a class="bsx-img" href="' . h($bkImg) . '" target="_blank" rel="noopener"><img src="' . h($bkImg) . '" alt="The Shogun share card" width="1200" height="630" loading="lazy"></a>' .
        '<div class="bsx-r"><label><span>What the post says</span><textarea id="bsx-t" rows="8" maxlength="250">' . h($bkTxt) . '</textarea><small>The link and its card go under it. Card and numbers update on their own as the record changes.</small></label>' .
        '<div class="bsx-b"><a class="btn bsx-x" id="bsx-x" target="_blank" rel="noopener" data-url="' . h($bkUrl) . '" href="https://x.com/intent/post?url=' . rawurlencode($bkUrl) . '&amp;text=' . rawurlencode($bkTxt) . '">Post on X</a>' .
        '<button type="button" class="ghost" id="bsx-c" data-url="' . h($bkUrl) . '">Copy link</button><a class="ghost btn" href="' . h($bkImg) . '" download="shogun-card.jpg">Download card</a></div>' .
        '<p class="muted bsx-u">' . h($bkUrl) . '</p></div></div>';
    echo '<script>(function(){var t=document.getElementById("bsx-t"),x=document.getElementById("bsx-x"),c=document.getElementById("bsx-c");if(!t||!x)return;' .
        'function up(){x.href="https://x.com/intent/post?url="+encodeURIComponent(x.dataset.url)+"&text="+encodeURIComponent(t.value);}t.addEventListener("input",up);' .
        'c.addEventListener("click",function(){var u=c.dataset.url;(navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(function(){c.textContent="Copied";setTimeout(function(){c.textContent="Copy link";},1500);},function(){prompt("Copy this link",u);});});})();</script>';
    $rec = array_slice($bd['recent'] ?? [], 0, 15);
    echo '<h3>Latest players to beat it</h3>' . ($rec ? '<div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Score</th><th>Koban</th></tr></thead><tbody>' . implode('', array_map(fn($x) => '<tr><td class="nw">' . h(ago($x['t'])) . '</td><td><b>' . h($x['name']) . '</b></td><td>' . (int)$x['r'] . ' to ' . (int)$x['b'] . '</td><td>' . ($x['k'] ? number_format($x['k']) : '<span class="muted">none</span>') . '</td></tr>', $rec)) . '</tbody></table></div>' : '<p class="muted">Nobody yet.</p>');
    //MC 2026-10-14 Fair play: the one way to pad a Shogun record is walking away from a match that is going badly (the
    //   room dies without a result). Those are now swept onto the record as quits, lifetime starts are counted, and this
    //   table puts starts, finished matches and quits side by side so the pattern shows. Asked for by the team after a
    //   player's 6 of 15 raised eyebrows; the server plays and checks every move, so wins themselves can't be faked.
    $fpP = array_filter($bd['p'] ?? [], fn($x) => !empty($x['n']) && (($x['g'] ?? 0) > 0 || ($x['st'] ?? 0) > 0 || ($x['q'] ?? 0) > 0));
    uasort($fpP, fn($a, $b) => [(int)($b['q'] ?? 0), (int)($b['g'] ?? 0)] <=> [(int)($a['q'] ?? 0), (int)($a['g'] ?? 0)]);
    echo '<h3 id="boss-fair">Fair play</h3><p class="muted">Wins can\'t be faked: the server plays the Shogun and checks every move, and a win with a bot covering a turn pays nothing. What a player can do is quit a match that is going badly and let the room die. Those count below as quits (swept onto the record within a few hours). Starts and quits are counted from the Oct 14, 2026 release on, so older matches show finished games with fewer starts behind them.</p>';
    if ($fpP) {
        echo '<div class="tw"><table><thead><tr><th>Player</th><th>Starts</th><th>Finished</th><th>Quits</th><th>Wins</th><th>Win rate</th><th>Best game</th><th>Biggest margin</th><th></th></tr></thead><tbody>';
        foreach (array_slice($fpP, 0, 20, true) as $x) {
            $q = (int)($x['q'] ?? 0); $g = (int)($x['g'] ?? 0);
            $note = $q >= 3 && $q * 2 >= max(1, $g) ? '<i class="bad">quits when losing?</i>' : ($q > 0 ? '<i class="warn">walked away ' . $q . ($q === 1 ? ' time' : ' times') . '</i>' : '');
            echo '<tr><td><b>' . h($x['n']) . '</b></td><td>' . (int)($x['st'] ?? 0) . '</td><td>' . $g . '</td><td>' . $q . '</td><td>' . (int)($x['w'] ?? 0) . '</td><td>' . ($g ? round(($x['w'] ?? 0) / $g * 100) : 0) . '%</td><td>' . (int)($x['best'] ?? 0) . '</td><td>' . (!empty($x['big']) ? '+' . (int)$x['big'] : '<span class="muted">none</span>') . '</td><td>' . $note . '</td></tr>';
        }
        echo '</tbody></table></div>';
    } else echo '<p class="muted">Nobody has played the Shogun yet.</p>';
    $blog = array_slice($bd['log'] ?? [], 0, 15);
    echo '<h3>Latest boss matches</h3>' . ($blog ? '<div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Result</th><th>Score</th><th>Length</th><th>Played it all</th></tr></thead><tbody>' .
        implode('', array_map(function ($x) {
            $res = ['win' => '<i class="ok">won</i>', 'tie' => 'draw', 'loss' => 'lost', 'quit' => '<i class="bad">quit</i>'][$x['res']] ?? h($x['res']);
            $dur = (int)($x['dur'] ?? 0);
            return '<tr><td class="nw">' . h(ago($x['t'])) . '</td><td><b>' . h($x['name']) . '</b></td><td>' . $res . '</td><td>' . (int)$x['r'] . ' to ' . (int)$x['b'] . '</td><td>' . ($dur >= 60 ? round($dur / 60) . ' min' : $dur . 's') . '</td><td>' . (!empty($x['own']) ? 'yes' : '<span class="muted">a bot covered a turn</span>') . '</td></tr>';
        }, $blog)) . '</tbody></table></div>' : '<p class="muted">Matches land here from the Oct 14, 2026 release on; a quit follows when its dead room is swept.</p>');
    echo '</div>';
}
if ($tab === 'rewards' && is_owner()) {
    $lgFiles = lg_recover_files();
    $lgSel = (string)($_GET['lgrec'] ?? '');
    echo '<h2 id="lgrec">Recover lost League points <small>owners only</small></h2><p class="muted">On Oct 11, 2026 a bug replaced some players\' League points for this week with their browser language when they opened the site. Pick a daily copy of the scores from <b>before</b> that happened. The list shows each player who has fewer League points this week (week ' . h(substr(week_key(), 5)) . ') or fewer Season ' . (int)season_no() . ' points now than in that copy. <b>Put them back</b> gives each of them the higher of the two numbers, so nobody loses anything and games played since still count. Only points for the current week and season can come back this way.</p>';
    echo '<form method="get" class="bar"><input type="hidden" name="p" value="recover"><select name="lgrec"><option value="">Pick a copy</option>' . implode('', array_map(fn($f) => '<option value="' . h($f) . '"' . ($f === $lgSel ? ' selected' : '') . '>' . h(str_replace(['players-', '.php'], '', $f)) . '</option>', $lgFiles)) . '</select><button>Compare</button></form>';
    if ($lgSel !== '') {
        if (!in_array($lgSel, $lgFiles, true)) echo '<p class="muted">That copy isn\'t there any more.</p>';
        else {
            $plan = lg_recover_plan(load(BACKUPS . '/' . $lgSel), $players, week_key(), season_no());
            if (!$plan) echo '<p class="muted">Nobody has fewer League or Season points now than in the copy from ' . h(str_replace(['players-', '.php'], '', $lgSel)) . '. Nothing to put back.</p>';
            else {
                $pts = fn($v) => $v === null ? '<span class="muted">none</span>' : number_format($v);
                echo '<div class="tw"><table><thead><tr><th>Player</th><th>League in the copy</th><th>League now</th><th>After</th><th>Season in the copy</th><th>Season now</th><th>After</th></tr></thead><tbody>';
                foreach ($plan as $r) echo '<tr><td><b>' . h($r['name'] !== '' ? $r['name'] : substr($r['pid'], 0, 6)) . '</b>' . (isset($r['lgwas']) && $r['lgwas'] !== 'week ' . week_key() ? '<small>League now: ' . h($r['lgwas']) . '</small>' : '') . '</td>' .
                    (isset($r['lg']) ? '<td>' . $pts($r['lg'][0]) . '</td><td>' . $pts($r['lg'][1]) . '</td><td><b>' . number_format($r['lg'][2]['pts']) . '</b></td>' : '<td colspan="3" class="muted">no change</td>') .
                    (isset($r['sg']) ? '<td>' . $pts($r['sg'][0]) . '</td><td>' . $pts($r['sg'][1]) . '</td><td><b>' . number_format($r['sg'][2]['pts']) . '</b></td>' : '<td colspan="3" class="muted">no change</td>') . '</tr>';
                echo '</tbody></table></div>';
                echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="f" value="' . h($lgSel) . '"><button name="do" value="lg-recover" data-confirm="Put back League and Season points for ' . count($plan) . ' ' . (count($plan) === 1 ? 'player' : 'players') . ' from ' . h(str_replace(['players-', '.php'], '', $lgSel)) . '? Nobody\'s points go down.">Put them back (' . count($plan) . ')</button><span class="muted small">Checked again against the scores at the moment you press it.</span></form>';
            }
        }
    }
}
if ($tab === 'rewards' && can('payouts')) {
    //MC 2026-10-09 the 15 Club bounty: this month and past winners, with the wallet to pay
    $bd = with_lock(fn() => bounty_db()); $bc = bounty_cfg($bd); $bh = load(HOLDERS); $bm = $bd['m']; krsort($bm);
    $csrfIn = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    echo '<h2 id="bounty">15 Club bounty <small>' . (empty($bc['on']) ? '<i class="bad">Off</i>' : '<i class="ok">On</i>') . ' &middot; ' . count($bd['club']) . ' in the club</small></h2>';
    echo '<p class="muted">The first player each month (UTC) to win holding all ' . bounty_at() . ' Regions in a qualifying game wins it: Normal with hints off, a first Daily run, or a live match they finished themselves. The server records the winner; pay them from the marketing wallet, then mark it paid here with the transaction, which also lists it on the Treasury page.</p>';
    if (can('payouts', 2)) echo '<form method="post" class="bar">' . $csrfIn . '<label class="chk"><input type="checkbox" name="on" value="1"' . (!empty($bc['on']) ? ' checked' : '') . '> On</label><span class="muted">Prize shown to players</span><input name="prize" maxlength="40" value="' . h($bc['prize']) . '" style="width:180px"><button name="do" value="bounty-save">Save</button></form>';
    if (!isset($bm[bounty_month()])) echo '<p class="muted"><b>' . h(gmdate('F Y')) . ':</b> still open.</p>';
    if ($bm) {
        echo '<div class="tw"><table><thead><tr><th>Month</th><th>Winner</th><th>Game</th><th>When</th><th>Wallet</th><th>Paid</th><th></th></tr></thead><tbody>';
        foreach ($bm as $m => $w) {
            $wal = (string)($bh[$w['pid']]['wallet'] ?? '');
            echo '<tr><td>' . h(gmdate('M Y', strtotime($m . '-01'))) . '</td><td><b>' . h($w['name']) . '</b></td><td>' . h(['live' => 'Live match', 'daily' => 'Daily', 'normal' => 'Solo, Normal'][$w['mode']] ?? $w['mode']) . ', ' . (int)$w['regions'] . ' Regions</td><td>' . h(gmdate('M j H:i', $w['t'])) . ' UTC</td>' .
                '<td>' . ($wal !== '' ? '<code style="white-space:nowrap;user-select:all;font-size:12px">' . h($wal) . '</code>' : '<span class="warn">No wallet yet</span>') . '</td>' .
                '<td>' . (!empty($w['paid']) ? '<a href="https://solscan.io/tx/' . h($w['tx']) . '" target="_blank" rel="noopener"><i class="ok">Paid</i></a>' : '<span class="muted">Not yet</span>') . '</td><td>';
            if (can('payouts', 2) && empty($w['paid'])) echo '<form method="post" class="bar">' . $csrfIn . '<input type="hidden" name="m" value="' . h($m) . '"><input name="sig" placeholder="Transaction signature" spellcheck="false" style="width:170px"><input name="shy" type="number" step="any" min="0" placeholder="$SHY sent" style="width:110px"><input name="usd" type="number" step="0.01" min="0" placeholder="USD" style="width:80px"><button name="do" value="bounty-paid">Mark paid</button><button name="do" value="bounty-void" class="ghost danger" data-confirm="Take this win back? The bounty opens again this month.">Take back</button></form>';
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
    $log = with_lock(fn() => load(DATA_DIR . '/treasury-log.php')); $log = is_array($log) ? array_values($log) : [];
    $KL = ['buy' => 'Bought $SHY for the prize pool', 'burn' => 'Burned $SHY', 'lp' => 'Added liquidity', 'marketing' => 'Marketing', 'other' => 'Other'];
    echo '<h2 id="treasury">Treasury page <small><a href="/treasury" target="_blank" rel="noopener">open it &#8599;</a></small></h2><p class="muted">Prize payouts show on the public Treasury page by themselves. Add the other moves here (a $SHY buy for the prize pool, a burn, liquidity) with their Solana transaction, so the community can check every one.</p>';
    //MC 2026-10-13 Find past burns: the scan box, its found-but-not-yet-logged list, and the continue button
    if (can('payouts', 2)) {
        $B = $_SESSION['bscan'] ?? null;
        echo '<h3 id="burnscan">Find past burns</h3><p class="muted">Paste any wallet that burned $SHY over time (burns came from more than one). The scan reads its $SHY history on chain and lists burn transactions that are not on the Treasury page yet, shop-sale burns excluded. Long histories take a few presses.</p>';
        echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input name="wallet" required placeholder="Wallet address" spellcheck="false" value="' . h($B['w'] ?? mw_address()) . '" style="min-width:min(420px,80vw)">' .
            '<button name="do" value="burn-scan">' . ($B && $B['queue'] ? 'Scan more (' . count($B['queue']) . ' to go)' : 'Scan the wallet') . '</button>' .
            ($B ? '<button name="do" value="burn-clear" class="ghost">Clear the scan</button>' : '') . '</form>';
        if ($B && $B['found']) {
            echo '<div class="tw"><table><thead><tr><th>Date</th><th>$SHY burned</th><th>Transaction</th></tr></thead><tbody>';
            $rows = $B['found']; uasort($rows, fn($a, $b) => ($b['t'] ?? 0) <=> ($a['t'] ?? 0));
            foreach ($rows as $sig => $f) echo '<tr><td class="nw">' . h($f['t'] ? gmdate('M j, Y', $f['t']) : 'unknown') . '</td><td>' . number_format($f['shy']) . '</td><td><a href="https://solscan.io/tx/' . h($sig) . '" target="_blank" rel="noopener">' . h(substr($sig, 0, 10)) . '…</a></td></tr>';
            echo '</tbody></table></div>';
            echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="burn-log" data-confirm="Add these ' . count($B['found']) . ' burns to the public Treasury page?">Add ' . count($B['found']) . ($B && count($B['found']) === 1 ? ' burn' : ' burns') . ' to the Treasury page</button></form>';
        } elseif ($B && !$B['queue']) echo '<p class="muted small">Nothing new found in this wallet. Every burn in its history is already on the Treasury page or belongs to a shop sale.</p>';
    }
    echo '<div class="tw"><table><thead><tr><th>Date</th><th>Move</th><th>$SHY</th><th>USD</th><th>Note</th><th>Transaction</th><th></th></tr></thead><tbody>';
    foreach ($log as $i => $x) echo '<tr><td>' . h(gmdate('M j, Y', $x['t'])) . '</td><td>' . h($KL[$x['kind']] ?? $x['kind']) . '</td><td>' . ($x['shy'] ? number_format($x['shy']) : '') . '</td><td>' . ($x['usd'] ? '$' . number_format($x['usd'], 2) : '') . '</td><td>' . h($x['note']) . '</td><td><a href="https://solscan.io/tx/' . h($x['sig']) . '" target="_blank" rel="noopener">' . h(substr($x['sig'], 0, 10)) . '…</a></td>' .
        '<td>' . (can('payouts', 2) ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="i" value="' . (int)$i . '"><button name="do" value="treasury-del" class="danger" data-confirm="Remove this move from the Treasury page?">Remove</button></form>' : '') . '</td></tr>';
    if (!$log) echo '<tr><td colspan="7" class="muted">Nothing recorded yet.</td></tr>';
    echo '</tbody></table></div>';
    if (can('payouts', 2)) echo '<form method="post" class="ts-add"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><div class="grid2">' .
        '<label>What happened<select name="kind">' . implode('', array_map(fn($k, $v) => '<option value="' . $k . '">' . h($v) . '</option>', array_keys($KL), $KL)) . '</select></label>' .
        '<label>Date (UTC)<input type="date" name="day" value="' . gmdate('Y-m-d') . '"></label>' .
        '<label>$SHY amount<input name="shy" type="number" step="any" min="0" placeholder="1500000"></label><label>USD at the time<input name="usd" type="number" step="0.01" min="0" placeholder="250"></label>' .
        '<label>Transaction signature<input name="sig" required placeholder="From Solscan" spellcheck="false"></label><label>Note (shown publicly)<input name="note" maxlength="140" placeholder="Week 41 prize pool"></label></div>' .
        '<div class="bar"><button name="do" value="treasury-add">Add to the Treasury page</button></div></form>';
}

if ($tab === 'players') {
    $waiting = connected_only($players, $holders);
    $today = 0; $week = 0; $live24 = 0;
    foreach ($players as $p) { if (($p['last'] ?? 0) > time() - 86400) $today++; if (($p['since'] ?? 0) > time() - 7 * 86400) $week++; }
    $bansN = count(bans()['p']);
    $review = count(array_filter($players, fn($p) => name_blocked($p['name'] ?? '')));
    glance([
        [number_format(count($players)), 'players with a game on record, plus ' . number_format(count($waiting)) . ' who connected a wallet but haven\'t played'],
        [number_format($today), 'played in the last 24 hours', $today ? 'ok' : ''],
        [number_format($week), 'new players this week'],
        [$review ? $review . ' to check' : 'All clear', $review ? 'names fail the name filter (Names to review)' : 'no names need checking', $review ? 'warn' : 'ok'],
        [number_format($bansN), $bansN === 1 ? 'player banned' : 'players banned'],
    ]);
    $list = $players; uasort($list, fn($a, $b) => ($b['points'] ?? 0) <=> ($a['points'] ?? 0));
    $ecoAll = load(ECO);
    $list += $waiting;
    $flagged = array_filter($players, fn($p) => name_blocked($p['name'] ?? ''));
    if ($flagged) {
        echo '<h2>Names to review <small>' . count($flagged) . ' on the board fail the name filter</small></h2><div class="tw"><table class="review"><tbody>';
        foreach ($flagged as $pid => $p) echo '<tr><td><b>' . h($p['name']) . '</b><small>' . h(substr($pid, 0, 6)) . '</small></td><td class="acts"><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="pid" value="' . h($pid) . '"><input name="name" placeholder="New name" maxlength="20" required><button name="do" value="rename">Rename</button></form> <form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="pid" value="' . h($pid) . '"><button name="do" value="remove" class="danger" data-confirm="Remove ' . h($p['name']) . ' from every board?">Remove</button></form></td></tr>';
        echo '</tbody></table></div>';
    }
    if (can('gifts', 2)) {
        $grants = is_file(GRANTS) ? load(GRANTS) : [];
        echo '<section class="rw award" id="award"><h2>Award Koban <small>shows in the player\'s Koban history with your reason</small></h2>' .
            '<form method="post" class="bar award-f"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="back" value="players">' .
            '<input name="who" placeholder="Search a player: name, page link, id or wallet" required autocomplete="off" spellcheck="false" data-pick="players" style="min-width:240px">' .
            '<input name="koban" type="number" min="-' . GRANT_MAX . '" max="' . GRANT_MAX . '" step="1" placeholder="Koban" required style="width:120px" data-award-amt>' .
            '<span class="award-q">' . implode('', array_map(fn($n) => '<button type="button" class="sm" data-award-set="' . $n . '">' . number_format($n) . '</button>', [50, 100, 250, 500, 1000, 5000])) . '</span>' .
            '<input name="why" placeholder="Reason, e.g. Bug report reward" maxlength="60" required style="min-width:220px">' .
            '<button name="do" value="grant" data-confirm="Give this Koban? It lands in their balance right away.">Award</button></form>' .
            '<p class="muted">A minus amount takes Koban back (never below 0). Up to ' . number_format(GRANT_MAX) . ' at a time. To give an item instead, use <a href="?p=gifts">Give Koban or items</a>.</p>';
        if ($grants) {
            echo '<div class="tw"><table><thead><tr><th>When</th><th>Player</th><th>Koban</th><th>Reason</th><th>By</th></tr></thead><tbody>';
            foreach (array_slice($grants, 0, 15) as $g) echo '<tr><td class="nw">' . h(gmdate('M j, H:i', $g['t'])) . ' UTC</td><td><b>' . h($g['name']) . '</b><small>' . h(substr($g['pid'], 0, 6)) . '</small></td><td>' . ($g['k'] ? ($g['k'] > 0 ? '+' : '&minus;') . number_format(abs($g['k'])) : '') . ($g['item'] ? ' <i class="ok">' . h(eco_item($g['item'])['name'] ?? $g['item']) . '</i>' : '') . '</td><td>' . h($g['why']) . '</td><td>' . h($g['by']) . '</td></tr>';
            echo '</tbody></table></div>';
            $wk = array_sum(array_map(fn($g) => max(0, $g['k']), array_filter($grants, fn($g) => $g['t'] > time() - 7 * 86400)));
            echo '<p class="muted">' . number_format($wk) . ' Koban awarded by hand in the last 7 days.</p>';
        }
        echo '</section>';
    }
    echo '<h2>Combine two players</h2><p class="muted">For someone who ended up with two profiles. Everything from the first moves into the second: points, wins, Daily runs, weekly history, Koban, items, purchases and every device they signed in on. The first one disappears from the boards.</p>';
    echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input name="from" placeholder="Move this player (name or id)" list="pnames" required><span class="muted">into</span><input name="into" placeholder="This player (name or id)" list="pnames" required><button name="do" value="merge" data-confirm="Combine these two players? This can\'t be undone (a daily backup is kept).">Combine</button></form>';
    //MC 2026-10-11 the name suggestions list the top 500 by points (it listed everyone); any name or id still works when typed
    echo '<datalist id="pnames">'; $dl = 0; foreach ($list as $pid => $p) if (($p['name'] ?? '') !== '' && $dl++ < 500) echo '<option value="' . h($p['name']) . '">' . h(substr($pid, 0, 6)) . '</option>';
    $dl = 0; foreach ($list as $pid => $p) if (($p['name'] ?? '') === '' && $dl++ < 100) echo '<option value="' . h(substr($pid, 0, 6)) . '">Connected, no name yet</option>';
    echo '</datalist>';
    echo '<h2>All players <small>' . count($players) . ' with records' . ($waiting ? ' &middot; ' . count($waiting) . ' connected but no games yet' : '') . '</small></h2>';
    echo '<p class="muted">Everyone with a record or a linked wallet. Profiles that haven\'t finished a game stay off the public boards, but you can rename or combine them here. Search by name, id or wallet.</p>';
    //MC 2026-10-09 the Players tab took 20 to 27s to open and froze about 2s per letter typed in search. The server answers
    //   in 0.1s, the time was all in the browser: 1,783 rows each carried a <details> with 3 or 4 forms (5,359 forms, 60k
    //   elements, 2.9MB), and the .tw:has() rule for the Team table made Chrome re-check style across that whole table.
    //   Now each row only has its summary and the forms are built from one <template> when the row is opened, the
    //   :has() rule is gone, only the first 200 rows show until you search or press Show all, and search waits
    //   for a short pause in typing. Rename, Give Koban, Clear motto, Remove and Combine post exactly the same fields.
    //MC 2026-10-11 the page itself was still 1.1 MB with every player in it (about 4.5 MB at four times the players). Now the
    //   server sends 50 rows a page; search (Enter) looks through everyone on the server, and typing still narrows the
    //   rows on the page you're on.
    $per = 50; $qq = strtolower(trim((string)($_GET['q'] ?? ''))); $pg = max(1, (int)($_GET['pg'] ?? 1));
    $rankOf = []; $ri = 0; foreach ($list as $rpid => $_) $rankOf[$rpid] = ++$ri;
    $match = $qq === '' ? $list : array_filter($list, fn($p, $mp) => strpos(strtolower(($p['name'] ?? '') . ' ' . substr($mp, 0, 6) . ' ' . wallet_of($mp, $holders)), $qq) !== false, ARRAY_FILTER_USE_BOTH);
    $pages = max(1, (int)ceil(count($match) / $per)); $pg = min($pg, $pages);
    $shown = $per;
    echo '<form method="get" class="bar"><input type="hidden" name="tab" value="players"><input id="q" name="q" type="search" placeholder="Search names, ids or wallets, then Enter" autocomplete="off" value="' . h($qq) . '"><a class="btn" href="?dl=players">Download CSV</a></form>';
    echo '<div class="tw"><table id="t" data-shown="' . $shown . '"><thead><tr><th>#</th><th>Player</th><th>Points</th><th title="Games won out of games played">Wins / games</th><th title="Live matches won out of live matches played">Live wins</th><th>Shadow</th><th>Joined</th><th></th></tr></thead><tbody>';
    $n = 0;
    foreach (array_slice($match, ($pg - 1) * $per, $per, true) as $pid => $p) {
        $i = $rankOf[$pid]; $n++;
        $w = wallet_of($pid, $holders);
        $nog = empty($p['games']);
        $motto = (string)($ecoAll[$pid]['pg']['motto'] ?? '');
        echo '<tr data-n="' . h(strtolower(($p['name'] ?? '') . ' ' . substr($pid, 0, 6) . ' ' . $w)) . '"' . ($n > $shown ? ' hidden' : '') . '><td>' . ($nog ? '&ndash;' : $i) . '</td><td><b>' . (($p['name'] ?? '') !== '' ? h($p['name']) : '<span class="muted">No name yet</span>') . '</b>' . ($nog ? ' <i class="warn">' . (!empty($p['virtual']) ? 'Connected, no games' : 'No games yet') . '</i>' : '') . (!empty($p['xu']) ? ' <a class="xh" href="https://x.com/' . h($p['xu']) . '" target="_blank" rel="noopener">@' . h($p['xu']) . '</a>' : '') . '<small>' . h(substr($pid, 0, 6)) . ($w ? ' &middot; ' . h(short_w($w)) : '') . '</small></td>' .
            '<td>' . number_format($p['points'] ?? 0) . '</td><td>' . (int)($p['wins'] ?? 0) . ' / ' . (int)($p['games'] ?? 0) . '</td><td>' . (int)($p['pvp_w'] ?? 0) . ' / ' . (int)($p['pvp_g'] ?? 0) . '</td>' .
            '<td>' . (!empty($p['avatar']) ? '#' . h($p['avatar']) : '') . (!empty($p['holder']) ? ' <i class="ok">Holder</i>' : '') . '</td><td>' . h(gmdate('M j', $p['since'] ?? time())) . '</td>' .
            '<td class="acts"><details data-pid="' . h($pid) . '" data-name="' . h($p['name'] ?? '') . '" data-kb="' . number_format((int)($ecoAll[$pid]['koban'] ?? 0)) . '"' . ($motto !== '' ? ' data-motto="' . h($motto) . '"' : '') . '><summary>Manage</summary></details></td></tr>';
    }
    echo '</tbody></table></div>';
    echo '<p class="muted" id="q-none" hidden>No players match that search.</p>';
    $pgUrl = fn($x) => '?tab=players&pg=' . $x . ($qq !== '' ? '&q=' . rawurlencode($qq) : '');
    echo '<p class="bar"><span class="muted">' . ($qq !== '' ? number_format(count($match)) . ' match &ldquo;' . h($qq) . '&rdquo;. ' : '') . 'Page ' . $pg . ' of ' . $pages . ' (' . number_format(count($match)) . ' players).</span>' .
        ($pg > 1 ? ' <a class="btn" href="' . h($pgUrl($pg - 1)) . '">Previous</a>' : '') . ($pg < $pages ? ' <a class="btn" href="' . h($pgUrl($pg + 1)) . '">Next</a>' : '') . ($qq !== '' ? ' <a class="btn" href="?tab=players">Clear search</a>' : '') . '</p>';
    // the row actions, filled in by the script below when a row is opened. {n} becomes the player's name
    $csrfIn = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    echo '<template id="pacts"><form method="post">' . $csrfIn . '<input type="hidden" name="pid" data-f="pid">' .
        '<input name="name" maxlength="20" data-f="name"><button name="do" value="rename">Rename</button>' .
        '<button name="do" value="remove" class="danger" data-confirm-t="Remove {n} from every board? Their points are gone for good.">Remove</button></form>' .
        (can('gifts', 2) ? '<form method="post" class="award-row">' . $csrfIn . '<input type="hidden" name="back" value="players"><input type="hidden" name="who" data-f="pid"><small class="muted" data-f="kb"></small> <input name="koban" type="number" min="-' . GRANT_MAX . '" max="' . GRANT_MAX . '" placeholder="Amount" required style="width:96px"><input name="why" placeholder="Reason" maxlength="60" required style="width:150px"><button name="do" value="grant" data-confirm-t="Give this Koban to {n}?">Give Koban</button></form>' : '') .
        '<form method="post" data-f="motto-f">' . $csrfIn . '<input type="hidden" name="pid" data-f="pid"><small class="muted" data-f="motto"></small> <button name="do" value="clear-motto" data-confirm="Clear this player\'s motto?">Clear motto</button></form>' .
        '<form method="post">' . $csrfIn . '<input type="hidden" name="from" data-f="pid"><input name="into" placeholder="Combine into (name)" list="pnames" required><button name="do" value="merge" data-confirm-t="Move everything from {n} into that player?">Combine</button></form>' .
        '<form method="post">' . $csrfIn . '<input type="hidden" name="pid" data-f="pid"><input name="why" placeholder="Reason for the ban" maxlength="80" required style="width:170px"><button name="do" value="ban" class="danger" data-confirm-t="Ban {n}? They can\'t play, buy or show on the boards until you lift it.">Ban</button></form></template>';
    //MC 2026-10-11 who is banned, and the way back
    $bans = (load(BANS) + ['p' => []])['p'];
    if ($bans) {
        echo '<h2>Banned <small>' . count($bans) . '</small></h2><div class="tw"><table><thead><tr><th>Player</th><th>Why</th><th>By</th><th>When</th><th></th></tr></thead><tbody>';
        foreach ($bans as $bp => $x) echo '<tr><td><b>' . h($x['name'] ?? '') . '</b><small>' . h(substr($bp, 0, 6)) . (!empty($x['w']) ? ' &middot; ' . h(short_w($x['w'])) : '') . '</small></td><td>' . h($x['why'] ?? '') . '</td><td>' . h($x['by'] ?? '') . '</td><td class="nw">' . h(gmdate('M j, H:i', (int)($x['t'] ?? 0))) . ' UTC</td><td class="acts"><form method="post">' . $csrfIn . '<input type="hidden" name="pid" value="' . h($bp) . '"><button name="do" value="unban" class="ghost" data-confirm="Lift the ban on ' . h($x['name'] ?? '') . '?">Lift ban</button></form></td></tr>';
        echo '</tbody></table></div>';
    }
    //MC 2026-10-12 Live chat: the switch, and what was said at tables in the last 24 hours (rooms still on the server),
    //   newest first, so a problem player can be found and banned
    $chatOn = !empty(eco_settings()['live_chat']);
    $recent = [];
    $rdir = DATA_DIR . '/rooms';
    if (is_dir($rdir)) foreach (glob($rdir . '/*.php') ?: [] as $rf) {
        if (filemtime($rf) < time() - 86400) continue;
        $rm = load($rf); if (empty($rm['chat'])) continue;
        foreach ($rm['chat'] as $m) { $st = $rm['seats'][$m['seat']] ?? []; $recent[] = ['ts' => $m['ts'], 'room' => $rm['code'] ?? basename($rf, '.php'), 'name' => $st['name'] ?? '', 'pid' => $st['pid'] ?? '', 't' => $m['t']]; }
    }
    usort($recent, fn($a, $b) => $b['ts'] <=> $a['ts']);
    echo '<h2 id="livechat">Live chat <small>' . ($chatOn ? 'on' : 'off') . ' &middot; ' . count($recent) . ' messages in the last day</small></h2><p class="muted">Players at a live table can chat (spectators can\'t). Swear words from the blocked list show as stars, links and @handles are cut, and each player can send about one message a second. Anyone can mute a player for themselves by tapping their name in the chat. To stop someone for good, ban them above.</p>';
    if (can('players', 2)) echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><label class="chk"><input type="checkbox" name="live_chat" value="1"' . ($chatOn ? ' checked' : '') . '> Chat in live matches is on</label><button name="do" value="chat-settings">Save</button></form>';
    if ($recent) {
        echo '<div class="tw" style="max-height:380px;overflow:auto"><table><thead><tr><th>When</th><th>Room</th><th>Player</th><th>Message</th></tr></thead><tbody>';
        foreach (array_slice($recent, 0, 150) as $m) echo '<tr><td class="nw">' . h(ago((int)$m['ts'])) . '</td><td>' . h($m['room']) . '</td><td><b>' . h($m['name']) . '</b><small>' . h(substr($m['pid'], 0, 6)) . '</small></td><td>' . h($m['t']) . '</td></tr>';
        echo '</tbody></table></div>';
    }
    $xs = eco_settings(); $xu = load(DATA_DIR . '/x-usage.php'); $xn = $xu[gmdate('Y-m')] ?? 0;
    $xlinked = count(array_filter($players, fn($p) => !empty($p['xu'])));
    $xpause = load(DATA_DIR . '/x-usage.php')['paused'] ?? 0;
    if ($xpause > time()) echo '<p class="flash bad">X says the developer account is out of credits, so posting from the site is paused (players see Open in X instead). Add credits at console.x.com under Billing, and posting turns back on within an hour.</p>';
    echo '<h2>Posting to X <small>' . $xlinked . ' players connected &middot; ' . $xn . ' posts this month</small></h2><p class="muted">With posting from the site off (the default), Share on X opens X in the player\'s own account with their result text and the result card image underneath. That costs nothing. Turn posting on and players who connected X can post without leaving the site, but every post is billed to the X developer account, and those posts go out as text only unless you also include the link (which costs more). The monthly limit counts every player together.</p>';
    //MC 2026-10-11 X settings in plain groups: posting from the site, automatic win posts, tags, and the KOL list for posting by hand
    $autoN = 0; foreach ((is_file(DATA_DIR . '/x-accounts.php') ? load(DATA_DIR . '/x-accounts.php') : []) as $xa) if (!empty($xa['auto'])) $autoN++;
    echo '<form method="post" class="xset"><input type="hidden" name="csrf" value="' . h(csrf()) . '">' .
      '<fieldset class="fs"><legend>Posting from the site</legend><p class="fs-d">Players who connected X can post their result without leaving the site. Every post is billed to the X developer account.</p>' .
      '<label class="chk"><input type="checkbox" name="x_post" value="1"' . (!empty($xs['x_post']) ? ' checked' : '') . '> Let players post from the site</label>' .
      '<label class="chk"><input type="checkbox" name="x_links" value="1"' . (!empty($xs['x_links']) ? ' checked' : '') . '> Include the result link and card (costs more per post, but the post shows the card)</label>' .
      '<label><span>Most posts a month, all players together</span><input name="x_month_cap" type="number" min="0" value="' . (int)($xs['x_month_cap'] ?? 300) . '"></label></fieldset>' .
      '<fieldset class="fs"><legend>Automatic win posts</legend><p class="fs-d">When this is on, players can switch on "Post my wins to X" on their profile. Their wins then post to their own X by themselves, and the results screen tells them it happened. ' . $autoN . ($autoN === 1 ? ' player has' : ' players have') . ' it switched on. Needs posting from the site on.</p>' .
      '<label class="chk"><input type="checkbox" name="x_autopost" value="1"' . (!empty($xs['x_autopost']) ? ' checked' : '') . '> Automatic win posts on</label>' .
      '<label><span>Most automatic posts per player a day</span><input name="x_auto_day" type="number" min="1" max="10" value="' . (int)($xs['x_auto_day'] ?? 3) . '"></label></fieldset>' .
      '<fieldset class="fs"><legend>Tags and accounts</legend><p class="fs-d">Tags go on every result post (automatic or not). Accounts are never tagged automatically: X treats automated @mentions as spam and can limit the account. Keep your list of KOLs and Solana accounts here and add one or two by hand when you post.</p>' .
      '<label><span>Tags on result posts ($cashtags and #hashtags, up to 5)</span><input name="x_tags" maxlength="120" value="' . h($xs['x_tags'] ?? '') . '" placeholder="$SHY #Solana #SolanaGaming"></label>' .
      '<label style="grid-column:1/-1"><span>KOLs and accounts to tag by hand (one per line)</span><textarea name="x_kols" rows="4" placeholder="@account">' . h($xs['x_kols'] ?? '') . '</textarea></label>' .
      '<label><span>Always tag (up to 3 accounts)</span><input name="x_always" maxlength="60" value="' . h($xs['x_always'] ?? '') . '" placeholder="@ShytoshiKusama"><small class="muted">In every post a person sends themselves: players\' own shares and the X buttons in this admin.</small></label>' .
      '<label class="chk" style="grid-column:1/-1"><input type="checkbox" name="x_always_auto" value="1"' . (!empty($xs['x_always_auto']) ? ' checked' : '') . '> Also put them in automatic win posts <small class="muted">(not recommended: X treats the same @mention posted again and again by an app as spam, which can hide the posts from that account and limit the app)</small></label>' .
      '<label class="chk" style="grid-column:1/-1"><input type="checkbox" name="x_kol_share" value="1"' . (!empty($xs['x_kol_share']) ? ' checked' : '') . '> Put one account from this list, picked at random, in the post when a player shares a result themselves <small class="muted">(they see it and can take it out before posting; automatic win posts never tag anyone)</small></label></fieldset>' .
      '<button name="do" value="x-settings">Save</button></form>';
    mkt_section();   //MC 2026-10-14 Hype posts for X (its own admin page claims the heading)
    $extra = is_file(BLOCKED_NAMES) ? load(BLOCKED_NAMES) : [];
    echo '<h2>Blocked words</h2><p class="muted">The name filter already blocks slurs, sexual words, insults and names pretending to be the team, including l33t spellings like n1gg4 or sh1t. Add your own words here (separated by spaces or commas). Names that contain them are refused.</p>';
    echo '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><textarea name="words" rows="3" style="width:100%" placeholder="scamcoin rugpull">' . h(implode(' ', $extra)) . '</textarea><button name="do" value="blocked-words" style="margin-top:8px">Save words</button></form>';
}

if ($tab === 'ideas') {
    $ideas = with_lock(fn() => load(IDEAS));
    $filter = (string)($_GET['st'] ?? 'open');
    $counts = ['open' => 0, 'all' => count($ideas)]; foreach (IDEA_STATUS as $k => $_) $counts[$k] = 0;
    foreach ($ideas as $x) { $counts[$x['status']] = ($counts[$x['status']] ?? 0) + 1; if (!in_array($x['status'], ['shipped', 'declined'], true)) $counts['open']++; }
    $email = eco_settings()['idea_email'] ?? '';
    echo '<h2>Suggestions <small>from the Suggest an idea button on every page</small></h2>';
    echo '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><span class="muted">Email new ones to</span><input name="email" type="email" value="' . h($email) . '" placeholder="Leave blank for no email" style="min-width:260px"><button name="do" value="idea-email">Save</button><button name="do" value="idea-email" class="ghost" onclick="this.form.test.value=1">Save and send a test</button><input type="hidden" name="test" value=""></form>';
    echo '<div class="bar">';
    foreach (['open' => 'Open'] + IDEA_STATUS + ['all' => 'All'] as $k => $v) echo '<a class="btn' . ($k === $filter ? '' : ' ghost') . '" href="?tab=ideas&st=' . $k . '">' . h($v) . ' <small>' . (int)($counts[$k] ?? 0) . '</small></a>';
    echo '</div><p class="muted">Tick <b>Show on the Ideas board</b> to put a suggestion on the public board at shyonsol.io/updates, where players vote. You can give it a cleaner title and text for the board; the original stays here. Contact details and wallets are never shown publicly.</p>';
    $shown = 0;
    foreach ($ideas as $id => $x) {
        if ($filter === 'open' && in_array($x['status'], ['shipped', 'declined'], true)) continue;
        if ($filter !== 'open' && $filter !== 'all' && $x['status'] !== $filter) continue;
        $shown++;
        $who = ($x['name'] !== '' ? h($x['name']) : '<span class="muted">Guest</span>') . ' <small>' . h(substr($x['pid'], 0, 6)) . '</small>' . ($x['x'] ? ' <a href="https://x.com/' . h($x['x']) . '" target="_blank" rel="noopener">@' . h($x['x']) . '</a>' : '') . ($x['wallet'] ? ' <small>' . h(short_w($x['wallet'])) . '</small>' : '');
        echo '<article class="idea" id="idea-' . h($id) . '"><div class="idea-top"><span class="pill st-' . h($x['status']) . '">' . h(IDEA_STATUS[$x['status']] ?? $x['status']) . '</span><b>' . h(IDEA_CATS[$x['cat']] ?? $x['cat']) . '</b><span class="muted">' . h(ago($x['ts'])) . ' &middot; ' . $who . '</span>' . (!empty($x['public']) ? '<span class="pill pub">On the board &middot; ' . (count($x['votes'] ?? []) + 1) . ' votes</span>' : '<span class="pill">Not on the board</span>') .
            '<form method="post" style="margin-left:auto"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="id" value="' . h($id) . '"><input type="hidden" name="on" value="' . (empty($x['public']) ? '1' : '') . '"><button name="do" value="idea-publish"' . (empty($x['public']) ? '' : ' class="ghost"') . '>' . (empty($x['public']) ? 'Put on the board' : 'Take off the board') . '</button></form></div>' .
            '<p class="idea-text">' . nl2br(h($x['text'])) . '</p>' .
            idea_en_html($id, $x) .
            '<div class="idea-meta">' . ($x['contact'] !== '' ? '<span>Contact: <b>' . h($x['contact']) . '</b></span>' : '<span class="muted">No contact left</span>') . ($x['page'] !== '' ? '<span>Sent from ' . h($x['page']) . '</span>' : '') . '</div>' .
            ($x['file'] ? '<a href="?idea_file=' . h($x['file']) . '" target="_blank" rel="noopener"><img class="idea-shot" src="?idea_file=' . h($x['file']) . '" alt="Screenshot"></a>' : '') .
            '<details' . ($x['status'] === 'new' ? ' open' : '') . '><summary>Respond and publish</summary><form method="post" class="idea-form"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="id" value="' . h($id) . '">' .
            '<label>Status <select name="status">' . implode('', array_map(fn($k, $v) => '<option value="' . $k . '"' . ($k === $x['status'] ? ' selected' : '') . '>' . h($v) . '</option>', array_keys(IDEA_STATUS), IDEA_STATUS)) . '</select></label>' .
            '<label class="chk"><input type="checkbox" name="public" value="1"' . (!empty($x['public']) ? ' checked' : '') . '> <b>Show on the Ideas board</b> (status alone doesn\'t publish it)</label>' .
            '<label class="chk"><input type="checkbox" name="credit" value="1"' . (!empty($x['credit']) ? ' checked' : '') . '> Credit the player by name</label>' .
            '<label class="wide">Board title <input name="title" value="' . h($x['title'] ?? '') . '" placeholder="' . h(idea_title($x['text'])) . '" maxlength="90"></label>' .
            '<label class="wide">Board text <textarea name="ptext" rows="2" maxlength="600" placeholder="Leave blank to show their words">' . h($x['ptext'] ?? '') . '</textarea></label>' .
            '<label class="wide">Public reply from the team <textarea name="reply" rows="2" maxlength="400" placeholder="Optional. Shows under the idea on the board.">' . h($x['reply'] ?? '') . '</textarea></label>' .
            '<label class="wide">Private note <textarea name="note" rows="2" maxlength="600" placeholder="Only admins see this">' . h($x['note'] ?? '') . '</textarea></label>' .
            '<div class="bar"><button name="do" value="idea-save">Save</button><button name="do" value="idea-delete" class="danger" data-confirm="Delete this suggestion for good?">Delete</button></div></form></details></article>';
    }
    if (!$shown) echo '<p class="muted">Nothing here yet.</p>';
}

if ($tab === 'weekly') {
    $wk = (string)($_GET['wk'] ?? week_key());
    $all = array_unique(array_merge([week_key()], array_keys($weeks)));
    echo '<div class="bar"><form><input type="hidden" name="tab" value="weekly"><select name="wk" onchange="this.form.submit()">';
    foreach ($all as $k) echo '<option value="' . h($k) . '"' . ($k === $wk ? ' selected' : '') . '>' . h(week_label($k)) . ($k === week_key() ? ' (now)' : '') . '</option>';
    echo '</select></form><a class="btn" href="?dl=week&wk=' . urlencode($wk) . '">All players CSV</a><a class="btn" href="?dl=week&holders=1&wk=' . urlencode($wk) . '">Holders CSV</a></div>';
    echo '<p class="muted">Weekly points reset Monday 00:00 UTC. Each finished week is filed automatically. The CSVs include wallet addresses for verified holders, handy for prizes.</p>';
    $rows = week_rows($wk);
    rows_table($rows, $holders);
}

if ($tab === 'daily') {
    $days = array_keys($daily); rsort($days);
    $day = (string)($_GET['day'] ?? ($days[0] ?? today()));
    echo '<div class="bar"><form><input type="hidden" name="tab" value="daily"><select name="day" onchange="this.form.submit()">';
    foreach ($days ?: [today()] as $d) echo '<option' . ($d === $day ? ' selected' : '') . '>' . h($d) . '</option>';
    echo '</select></form></div>';
    $rows = [];
    foreach ($daily[$day] ?? [] as $pid => $d) $rows[] = ['pid' => $pid, 'name' => $players[$pid]['name'] ?? '(removed)', 'pts' => $d['points'], 'regions' => $d['regions'], 'result' => $d['result'], 'ts' => $d['ts'], 'holder' => !empty($players[$pid]['holder'])];
    usort($rows, fn($a, $b) => [$b['pts'], $b['regions'], $a['ts']] <=> [$a['pts'], $a['regions'], $b['ts']]);
    echo '<div class="tw"><table><thead><tr><th>#</th><th>Player</th><th>Points</th><th>Regions</th><th>Result</th><th>When (UTC)</th></tr></thead><tbody>';
    foreach ($rows as $i => $r) echo '<tr><td>' . ($i + 1) . '</td><td><b>' . h($r['name']) . '</b>' . ($r['holder'] ? ' <i class="ok">Holder</i>' : '') . '</td><td>' . $r['pts'] . '</td><td>' . $r['regions'] . '</td><td>' . h(ucfirst($r['result'])) . '</td><td>' . gmdate('H:i', $r['ts']) . '</td></tr>';
    if (!$rows) echo '<tr><td colspan="6" class="muted">Nobody has played this Daily yet.</td></tr>';
    echo '</tbody></table></div>';
}

if ($tab === 'holders') {
    //MC 2026-10-12 Holdings: every player with $SHY in a linked wallet or Koban in their account, on one board. Balances come from
    //   the wallet checks in holders.php (every 6 hours) and the Koban from economy.php, so the page reads files only and never
    //   calls Solana. The rows go to the page as JSON and admin/holdings.js draws, sorts and filters them, so 3,000
    //   players stay quick; only 60 rows are drawn at a time. The old wallet table moved under its own heading below.
    $eco = load(ECO); $hx = []; $tSum = []; $shyT = 0; $usdT = 0; $kobT = 0; $nShy = 0; $nKob = 0; $nW = 0;
    foreach ($holders as $pid => $x) { if (!empty($x['wallet'])) $nW++; }
    foreach (array_keys($holders + $eco) as $pid) {
        $x = $holders[$pid] ?? []; $kb = (int)($eco[$pid]['koban'] ?? 0);
        $w = (string)($x['wallet'] ?? ''); $bal = $w ? (float)($x['shy_bal'] ?? 0) : 0;
        if ($bal <= 0 && $kb <= 0 && empty($x['shadows'])) continue;
        $tier = $w ? holder_tier($x) : '';
        if ($tier !== '') $tSum[$tier] = ($tSum[$tier] ?? 0) + 1;
        if ($bal > 0) { $nShy++; $shyT += $bal; $usdT += (float)($x['shy_usd'] ?? 0); }
        if ($kb > 0) { $nKob++; $kobT += $kb; }
        $hx[] = [(string)$pid, (string)($players[$pid]['name'] ?? ''), round($bal), round((float)($x['shy_usd'] ?? 0), 2), $kb, $tier, count($x['shadows'] ?? []), $w, (int)($x['chk'] ?? 0), (int)($players[$pid]['last'] ?? 0)];
    }
    usort($hx, fn($a, $b) => $b[2] <=> $a[2] ?: $b[4] <=> $a[4]);
    $top10 = array_sum(array_slice(array_column($hx, 2), 0, 10));
    $ladder = []; foreach (array_merge(['shadow'], HOLDER_LADDER) as $k) $ladder[] = [$k, HOLDER_NAMES[$k], (int)($tSum[$k] ?? 0), $k === 'shadow' ? 0 : (float)(eco_settings()['htiers'][$k] ?? 0)];
    echo '<h2 id="holdings">$SHY and Koban <small>' . number_format(count($hx)) . ' players &middot; wallets checked every 6 hours</small></h2>';
    echo '<div class="hx" id="hx"><p class="muted">Who holds what: the $SHY in each linked wallet, its Army Rank, and the Koban each player has to spend. Sort, search, or tap a rank to see only those players.</p>';
    echo '<div class="hx-kpis">' .
        '<div class="hx-k gold"><small>$SHY held by players</small><b title="' . number_format($shyT) . ' $SHY">' . ($shyT >= 1e9 ? round($shyT / 1e9, 2) . 'B' : ($shyT >= 1e6 ? round($shyT / 1e6, 2) . 'M' : number_format($shyT))) . '</b><span>about $' . number_format($usdT, 2) . ' &middot; ' . number_format($nShy) . ' wallets</span></div>' .
        '<div class="hx-k"><small>Top 10 wallets hold</small><b>' . ($shyT ? round($top10 / $shyT * 100, 1) : 0) . '%</b><span>of all $SHY linked here</span></div>' .
        '<div class="hx-k mint"><small>Koban in players hands</small><b>' . number_format($kobT) . '</b><span>' . number_format($nKob) . ' players hold Koban</span></div>' .
        '<div class="hx-k"><small>Average Koban</small><b>' . number_format($nKob ? $kobT / $nKob : 0) . '</b><span>per player who holds any</span></div>' .
        '<div class="hx-k"><small>Wallets linked</small><b>' . number_format($nW) . '</b><span>' . number_format($nW ? $nShy / $nW * 100 : 0) . '% hold $SHY</span></div>' .
        '</div>';
    echo '<div class="hx-card"><div class="hx-h"><b>Army Ranks</b><small>Tap a rank to filter the list</small></div><div class="hx-lad" id="hx-lad"></div></div>';
    echo '<div class="hx-card"><div class="hx-bar"><input type="search" id="hx-q" placeholder="Search a name, player id or wallet" autocomplete="off" spellcheck="false">' .
        '<div class="hx-seg" id="hx-sort" role="tablist" aria-label="Sort by"><button data-s="2" class="on">$SHY</button><button data-s="4">Koban</button><button data-s="6">Shadows</button></div>' .
        '<div class="hx-seg" id="hx-only" role="tablist" aria-label="Show"><button data-o="" class="on">Everyone</button><button data-o="shy">$SHY holders</button><button data-o="kob">Koban</button></div>' .
        '<button type="button" class="hx-csv" id="hx-csv">Download CSV</button></div>' .
        '<p class="hx-count" id="hx-count"></p><div class="hx-list" id="hx-list" role="list"></div><button type="button" class="hx-more" id="hx-more" hidden>Show more</button></div></div>';
    echo '<script>window.HX=' . json_encode(['rows' => $hx, 'ladder' => $ladder, 'now' => time()], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS) . ';</script>';
    echo '<script src="holdings.js?v=' . h(@filemtime(__DIR__ . '/holdings.js')) . '" defer></script>';

    echo '<h2 id="wallets">Wallets and Shadows</h2>';
    echo '<p class="muted">Players who linked a wallet. Ownership is checked again every 6 hours.</p>';
    echo '<div class="tw"><table><thead><tr><th>Player</th><th>Wallet</th><th>Shadows</th><th>Last check</th></tr></thead><tbody>';
    $n = 0;
    foreach ($holders as $pid => $x) {
        if (empty($x['wallet'])) continue; $n++;
        $sh = array_map(function ($s) use ($reg) { $r = $reg[$s] ?? []; return '#' . h($s) . (!empty($r['aura']) ? ' <small>' . h($r['aura']) . '</small>' : '') . (!empty($r['games']) ? ' <small>' . (int)$r['wins'] . 'W/' . (int)$r['games'] . 'G</small>' : ''); }, $x['shadows'] ?? []);
        echo '<tr><td><b>' . h($players[$pid]['name'] ?? '(no scores yet)') . '</b></td><td><a href="https://solscan.io/account/' . h($x['wallet']) . '" target="_blank" rel="noopener">' . h(short_w($x['wallet'])) . '</a></td><td>' . ($sh ? implode('<br>', $sh) : '<span class="muted">None held now</span>') . '</td><td>' . h(ago($x['chk'] ?? 0)) . '</td></tr>';
    }
    if (!$n) echo '<tr><td colspan="4" class="muted">No wallets linked yet.</td></tr>';
    echo '</tbody></table></div>';
}

if ($tab === 'live') {
    $rooms = is_dir(ROOMS) ? glob(ROOMS . '/*.php') : [];
    usort($rooms, fn($a, $b) => filemtime($b) <=> filemtime($a));
    echo '<p class="muted">Rooms tidy themselves up after they go quiet. Close one by hand only if it looks stuck.</p>';
    echo '<div class="tw"><table><thead><tr><th>Room</th><th>Status</th><th>Seats</th><th>Round</th><th>Updated</th><th></th></tr></thead><tbody>';
    foreach (array_slice($rooms, 0, 60) as $f) {
        $r = load($f); $code = basename($f, '.php');
        $seats = array_map(fn($s) => h(preg_replace('/ \(bot\)$/', '', $s['name'])) . (!empty($s['human']) ? '' : ' <small>bot</small>'), $r['seats'] ?? []);
        echo '<tr><td><b>' . h($code) . '</b><small>' . (!empty($r['public']) ? 'Quick match' : 'Private') . '</small></td><td>' . h(ucfirst($r['status'] ?? '')) . '</td><td>' . implode(', ', $seats) . '</td><td>' . (int)($r['g']['round'] ?? 0) . '</td><td>' . h(ago(filemtime($f))) . '</td>' .
            '<td><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="code" value="' . h($code) . '"><button name="do" value="close-room" class="danger" data-confirm="Close room ' . h($code) . '? Anyone in it is sent back to the menu.">Close</button></form></td></tr>';
    }
    if (!$rooms) echo '<tr><td colspan="6" class="muted">No rooms right now.</td></tr>';
    echo '</tbody></table></div>';
}

if ($tab === 'telegram') {
    if (can('telegram', 2)) tg_rehook();   // a bot set up before reminders existed gets the new kinds of updates
    $c = tg_cfg();
    $ready = tg_ready($c);
    //MC 2026-10-11 is it working, in words
    $th = tg_health(); $lastOk = 0; foreach ($th['r'] as $x) if (!empty($x['ok'])) { $lastOk = (int)$x['t']; break; }
    $down = tg_health_down(); $cronT = (int)(load(OPS_CRON)['t'] ?? 0);
    $onN = 0; foreach (TG_KINDS as $k => $_) if (tg_on($c, $k)) $onN++;
    glance([
        [$ready ? 'Connected' : 'Not set up', $ready ? 'the bot posts to ' . h($c['title'] ?: $c['chat']) : 'add the bot token and pick the chat under Bot', $ready ? 'ok' : 'bad'],
        [$down ? 'Failing' : ago_short($lastOk), $down ? 'the last 3 posts failed: ' . h(mb_substr($down['err'], 0, 80)) : 'last post that went through', $down ? 'bad' : ''],
        [$onN . ' of ' . count(TG_KINDS), 'kinds of posts switched on (What gets posted)'],
        [$cronT ? ago_short($cronT) : 'Not running', $cronT && time() - $cronT < 900 ? 'the 5-minute timer last ran' : 'set up the 5-minute timer (last section)', $cronT && time() - $cronT < 900 ? 'ok' : 'warn'],
    ]);
    echo '<div class="tg-status ' . ($ready ? 'on' : '') . '"><b>' . ($ready ? 'Connected to ' . h($c['title'] ?: $c['chat']) : 'Not connected yet') . (!empty($c['bot']) ? ' as @' . h($c['bot']) : '') . '</b><span>' . ($ready ? 'Messages post as your bot. Change anything below and save.' : 'Follow the three steps below. It takes about five minutes and costs nothing.') . '</span></div>';
    //MC 2026-10-11 the last 3 posts to the chat all failed: say so here with Telegram's reason (a kicked bot went unnoticed)
    if ($ready && ($down = tg_health_down())) {
        $rq = count(load(DATA_DIR . '/tg-retry.php'));
        echo '<p class="viewonly bad">The last 3 posts to the chat failed, the latest ' . h(ago($down['t'])) . '. Telegram said: ' . h($down['err']) . '. ' .
            (preg_match('/kicked|not a member|chat not found|have no rights|not enough rights/i', $down['err']) ? 'Add the bot back to the group (and let it send messages), then press Save and send a test below. ' : '') .
            ($rq ? $rq . ' ' . ($rq === 1 ? 'post is' : 'posts are') . ' waiting and will be tried again on their own.' : '') . '</p>';
    }
    if (!$ready) echo '<ol class="tg-steps"><li><b>Make the bot.</b> In Telegram, open <code>@BotFather</code>, send <code>/newbot</code>, give it a name (for example Shy Scoreboard) and a username ending in bot. BotFather replies with a token like <code>123456789:AAF…</code>. Paste it below and save.</li><li><b>Add it to the chat.</b> Add the bot to the $SHY group. It only needs to send messages, so if you make it an admin, turn every other permission off. In the group, send <code>/start</code>: once the token is saved, the bot answers with its menu.</li><li><b>Pick the chat.</b> Press <b>Find my chat</b>, choose the group, then press <b>Save and send a test</b>.</li></ol>';
    $found = $_SESSION['tg_found'] ?? [];
    if ($found) {
        echo '<h2>Chats the bot can see</h2><div class="tg-found">';
        foreach ($found as $id => $t) echo '<form method="post" class="tg-pick"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="chat" value="' . h($id) . '"><input type="hidden" name="title" value="' . h($t) . '"><button name="do" value="tg-pick">' . h($t) . ' <small>' . h($id) . '</small></button><button name="do" value="tg-pick" class="ghost" onclick="this.form.role.value=\'design\'" title="Post new card art here">Use for Game Design</button><input type="hidden" name="role" value=""></form>';
        echo '</div><p class="muted small">The first button makes it the main chat for game posts. <b>Use for Game Design</b> sends new card art there instead.</p>';
    }
    echo '<form method="post" class="tg-form"><input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    echo '<h2>Bot</h2><div class="grid2"><label>Bot token<input name="tg_token" type="password" autocomplete="new-password" data-lpignore="true" data-1p-ignore spellcheck="false" placeholder="' . ($c['token'] !== '' ? 'Saved. Paste a new one to replace it' : '123456789:AAF…') . '"></label>';
    echo '<label>Chat<input name="chat" value="' . h($c['chat']) . '" placeholder="Use Find my chat, or type -100… or @channel"></label></div>';
    echo '<div class="bar"><button name="do" value="tg-find" class="ghost">Find my chat</button>' . ($c['token'] !== '' ? '<label class="chk"><input type="checkbox" name="forget" value="1"> Disconnect the bot</label>' : '') . '</div>';
    echo '<h2>What gets posted</h2><div class="tg-kinds">';
    $desc = ['boss' => 'Each player who beats the Shogun, the boss bot, with the Koban they won.', 'live' => 'Every live match with 2 or more real players: who won and the final table.', 'daily_run' => 'Each player\'s first Daily Challenge run, as it happens.', 'solo' => 'Solo games a player wins.',
        'daily' => 'Once a day after midnight UTC: yesterday\'s Daily top 5 and how many played.', 'weekly' => 'When the week ends: the Weekly League top 10 and their prizes.', 'daily_am' => 'Once a day at the Daily hour below: today\'s Daily is up, who leads and how many have played, with a Play button.', 'release' => 'When a new site version is uploaded: its release notes, posted once, the first time the site runs after the upload.', 'buy' => 'Purchases at or above the amount below: player name and what they bought. Amounts and wallets are never shown.', 'idea' => 'When a public suggestion changes status (Under review, Community vote, Planned, Building, Shipped, Not for now): its title, who suggested it and the board link. Each idea posts once per status.', 'tourney' => 'When one is scheduled, an hour before it starts, the start, each new round and the champion.', 'partner' => 'Joint events, posted in the partner community\'s group too.', 'bounty' => 'When someone wins the 15 Club bounty.', 'payout' => 'When prizes are paid (any payout button, or a bounty marked paid): who won what, with the Treasury link. Pinned quietly; the next payout replaces the pin.', 'drop' => 'Limited finish drops: when one is scheduled (if you tick Announce) and when it sells out.', 'burn' => 'One message pinned in the chat with the total $SHY burned by the game and the latest burn, updated in place after every burn. The bot needs to be an admin with Pin messages.']; //MC 2026-10-09 the two newer kinds had no description
    foreach (TG_KINDS as $k => $label) echo '<label class="tg-kind"><input type="checkbox" name="on_' . $k . '" value="1"' . (tg_on($c, $k) ? ' checked' : '') . '><span><b>' . h($label) . '</b><small>' . h($desc[$k] ?? '') . '</small></span></label>';
    //MC 2026-10-12 where the burn tracker is and when it last changed, with a button to post it again at the bottom
    $bm = (int)($c['burn_msg'] ?? 0); $bcid = preg_match('/^-100(\d+)$/', (string)$c['chat'], $bmm) ? $bmm[1] : '';
    echo '</div><div class="tg-burn"><span><b>Burn tracker</b><small>' . ($bm ? 'One pinned message, edited on every burn' . (!empty($c['burn_at']) ? ', last changed ' . h(ago_short((int)$c['burn_at'])) : '') . ($bcid !== '' ? '. <a href="https://t.me/c/' . h($bcid) . '/' . $bm . '" target="_blank" rel="noopener">Open it in Telegram</a>' : '') : 'Not posted yet. It goes up with the next burn, or post it now.') . '</small></span>' .
        (can('telegram', 2) ? '<button name="do" value="tg-burn" class="ghost" data-confirm="Delete the old burn tracker and post a fresh one at the bottom of the chat, pinned?">Post the burn tracker again</button>' : '') . '</div><div>';
    //MC 2026-10-10 if the burn tracker couldn't be pinned, say why here
    if (!empty($c['burn_pin'])) echo '</div><p class="viewonly">The burn tracker posted but couldn\'t be pinned: ' . h($c['burn_pin']) . '. Make the bot an admin of the group with Pin messages, and it pins the next one.</p><div>';
    if (!empty($c['payout_pin'])) echo '</div><p class="viewonly">The last payout post couldn\'t be pinned: ' . h($c['payout_pin']) . '. Make the bot an admin of the group with Pin messages. It tries again every 15 minutes.</p><div>';   //MC 2026-10-10
    echo '</div><div class="grid2"><label>Post purchases from (USD)<input name="buy_min" type="number" step="0.01" min="0" value="' . h($c['buy_min']) . '"></label><label>Most game posts per hour<input name="hour_cap" type="number" min="1" max="60" value="' . (int)$c['hour_cap'] . '"></label></div>';
    echo '<p class="muted">Game posts stop for the rest of the hour once the limit is reached, so a busy night never floods the chat. The daily and weekly wrap-ups and purchases always go out, once each.</p>';
    //MC 2026-10-12 which posts get pinned when they go out (one of each kind stays pinned)
    $pinsOn = tg_pin_set($c);   //MC 2026-10-12 kinds added since the pins were saved show their default
    echo '<h3 class="tg-pins-h">Pin these when they go out</h3><input type="hidden" name="pins_form" value="1"><div class="tg-pins">';
    foreach (TG_KINDS as $k => $label) if (!in_array($k, ['payout', 'burn'], true)) echo '<label class="chk"><input type="checkbox" name="pin_' . $k . '" value="1"' . (!empty($pinsOn[$k]) ? ' checked' : '') . '> ' . h($label) . '</label>';
    echo '</div><p class="muted small">The chat keeps one pinned post of each kind: a new one takes over the pin from the last one. Prize payouts and the burn tracker always pin. The bot needs the Pin messages right in the group.</p>';
    echo '<h2>Game Design channel</h2><p class="muted">A team chat for new card art. When someone uploads art in <b>Card art</b>, the bot posts the picture with the card, who uploaded it and the file, and again when it goes live. Add the bot to that chat first. Players never see these posts.</p>';
    echo '<div class="grid2"><label>Game Design chat<input name="design_chat" value="' . h($c['design_chat']) . '" placeholder="-100…, @channel, or a link to a message there" spellcheck="false">' .
        '<small class="muted">' . ($c['design_chat'] !== '' ? 'Posting to ' . h($c['design_title'] ?: $c['design_chat']) . ((string)$c['design_topic'] !== '' ? ', topic ' . h($c['design_topic']) : '') . '. Empty it to stop.' : 'Use Find my chat, or paste a link to any message in it (right-click a message, Copy Message Link).') . '</small></label>' .
        '<label>Topic (only for groups with topics)<input name="design_topic" value="' . h($c['design_topic']) . '" inputmode="numeric" placeholder="Leave empty if none" spellcheck="false"><small class="muted">A message link from inside the topic fills this in.</small></label></div>';
    echo '<div class="tg-kinds">';
    foreach (['art_up' => ['New card art uploaded', 'The uploaded picture, the card, who uploaded it, the file name and size. Sent for every upload, before anything is published.'], 'art_pub' => ['Card art published', 'The card as players will see it and who published it.']] as $k => [$label, $d])
        echo '<label class="tg-kind"><input type="checkbox" name="ds_' . $k . '" value="1"' . (!empty($c['design_on'][$k]) ? ' checked' : '') . '><span><b>' . h($label) . '</b><small>' . h($d) . '</small></span></label>';
    echo '</div>';
    $bot = $c['bot'] ?? '';
    echo '<h2>Play inside Telegram</h2><p class="muted">The game runs as a Telegram Mini App, so players can play without leaving Telegram. Opening it signs them in and links their Telegram to their profile.</p>' .
        '<ol class="tg-steps"><li>Press <b>Turn on the Play button</b> below. A Play button appears next to the message box in the bot\'s private chat.</li>' .
        '<li>For a link that also works in the group: in <code>@BotFather</code> send <code>/newapp</code>, pick ' . ($bot ? '<code>@' . h($bot) . '</code>' : 'your bot') . ', give it the title <i>Shilluminati Online</i>, a short description and a 640 x 360 picture, skip the GIF, and use this web address: <code>' . h(TG_SITE) . '/play?tgapp=1</code>. Pick a short name such as <code>play</code> and paste it below.</li>' .
        '<li>With the short name saved, every post in the chat gets a <b>Play in Telegram</b> button, and live room invites open straight into the room.</li></ol>';
    echo '<div class="grid2"><label>Mini App short name<input name="app" value="' . h($c['app']) . '" placeholder="play" spellcheck="false"><small class="muted">' . ($c['app'] && $bot ? 'Link: t.me/' . h($bot) . '/' . h($c['app']) : 'The last part of t.me/yourbot/<b>play</b>') . '</small></label></div>';
    $links = tgl(); $nl = count($links['u']); $ndm = count(array_filter($links['u'], fn($x) => !empty($x['dm'])));
    echo '<h2>Reminders to players</h2><p class="muted">' . $nl . ' ' . ($nl === 1 ? 'player has' : 'players have') . ' linked Telegram, ' . $ndm . ' can be messaged. Players pick what they get with <code>/notify</code> in the bot or on their profile. Each reminder goes out once a day at most.</p>';
    echo '<label class="tg-kind"><input type="checkbox" name="dm_on" value="1"' . (!empty($c['dm_on']) ? ' checked' : '') . '><span><b>Send reminders</b><small>Streak reminders, new Daily Challenge and tournament messages to players who asked for them.</small></span></label>';
    echo '<div class="grid2"><label>Streak reminder from (hour, UTC)<input name="remind_hour" type="number" min="0" max="23" value="' . (int)$c['remind_hour'] . '"><small class="muted">Streaks end at midnight UTC. 18 means 6 PM UTC.</small></label><label>Only for streaks of at least (days)<input name="remind_min" type="number" min="1" max="30" value="' . (int)$c['remind_min'] . '"></label></div>' .
        '<div class="grid2"><label>Daily Challenge call (hour, UTC)<input name="daily_hour" type="number" min="0" max="23" value="' . (int)$c['daily_hour'] . '"><small class="muted">The morning post in the chat and the nudge to linked players who haven\'t played yet. 13 means 9 AM in New York.</small></label></div>';
    echo '<div class="bar"><button name="do" value="tg-save">Save</button><button name="do" value="tg-save" class="ghost" onclick="this.form.test.value=1">Save and send a test</button><input type="hidden" name="test" value=""></div></form>';
    if ($c['token'] !== '') echo '<form method="post" class="bar" style="margin-top:10px"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="tg-release" class="ghost" data-confirm="Post this release to the Telegram chat?">Post the latest release notes</button><button name="do" value="tg-app" class="ghost">Turn on the Play button</button><span class="muted small">Sets the button in the bot\'s private chat and the command list.</span></form>';
    //MC 2026-10-11 send the last weekly results or payout post again
    if ($c['token'] !== '') {
        $tl = tg_health()['last'];
        $lastLine = function ($k) use ($tl) { $x = $tl[$k] ?? null; return $x ? 'last one ' . ago($x['t']) . (isset($x['ok']) && !$x['ok'] ? ', it failed' : '') : 'none recorded yet'; };
        echo '<h2>Send again</h2><p class="muted">If the chat missed a post (the bot was removed for a while, or Telegram was down), send it again here. It posts exactly the same text, once. A payout post is pinned again and takes over the pin.</p>' .
            '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="kind" value="weekly"><button name="do" value="tg-resend" class="ghost" data-confirm="Post the last weekly results to the Telegram chat again?">Resend the last weekly results</button><span class="muted small">' . h($lastLine('weekly')) . '</span></form>' .
            '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="kind" value="payout"><button name="do" value="tg-resend" class="ghost" data-confirm="Post the last prize payout to the Telegram chat again and pin it?"' . (empty($tl['payout']) ? ' disabled' : '') . '>Resend the last payout post</button><span class="muted small">' . h($lastLine('payout')) . '</span></form>';
    }
    //MC 2026-10-12 every post the bot made in the chat, newest first, with Pin, Change, Delete and Send again
    if ($c['token'] !== '') {
        $posts = array_reverse(tg_posts(), true);
        $csrfIn = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
        echo '<h2 id="tg-posts">Messages sent <small>' . count($posts) . '</small></h2><p class="muted">What the bot posted in the chat, newest first (the last 100). <b>Change</b> edits the post where it is. <b>Delete</b> takes it out of the chat (Telegram lets a bot delete its own posts for 48 hours). <b>Send again</b> posts the same words as a new message. Posts from before Oct 12 aren\'t listed: use the box at the bottom with the post\'s link.</p>';
        if (!$posts) echo '<p class="muted">Nothing yet. The next post shows up here.</p>';
        else {
            echo '<div class="tw"><table class="tg-posts"><thead><tr><th>When</th><th>Kind</th><th>Message</th><th></th></tr></thead><tbody>';
            foreach (array_slice($posts, 0, 40, true) as $id => $r) {
                $txt = trim(html_entity_decode(strip_tags((string)($r['h'] ?? '')), ENT_QUOTES)); $del = !empty($r['del']);
                $state = $del ? '<span class="pill">Deleted ' . h(ago($r['del'])) . '</span>' : (!empty($r['pin']) ? '<span class="pill on">Pinned</span>' : '') . (!empty($r['ed']) ? ' <span class="pill">Changed ' . h(ago($r['ed'])) . '</span>' : '');
                $f = '<form method="post" class="inl">' . $csrfIn . '<input type="hidden" name="id" value="' . h($id) . '">';
                echo '<tr class="' . ($del ? 'gone' : '') . '"><td class="nw">' . h(!empty($r['t']) ? ago($r['t']) : 'before Oct 12') . '</td><td class="nw">' . h(TG_KINDS[$r['k'] ?? ''] ?? ($r['k'] ?: 'Other')) . ($r['photo'] ?? '' ? '<small>with picture</small>' : '') . '</td>' .
                    '<td class="tg-txt"><div>' . h(mb_substr($txt, 0, 220)) . (mb_strlen($txt) > 220 ? '…' : '') . '</div>' . $state .
                    (!$del && ($r['h'] ?? '') !== '' ? '<details class="tg-edit"><summary>Change</summary>' . $f . '<textarea name="html" rows="8" spellcheck="true">' . h((string)$r['h']) . '</textarea><small class="muted">Telegram formatting: &lt;b&gt;bold&lt;/b&gt;, &lt;i&gt;italic&lt;/i&gt;, &lt;a href="https://..."&gt;link&lt;/a&gt;.</small><div class="bar"><button name="do" value="tg-msg" onclick="this.form.op.value=\'edit\'">Save the change in the chat</button></div><input type="hidden" name="op" value="edit"></form></details>' : '') . '</td>' .
                    '<td class="nw tg-acts">' . (!$del ? $f . '<input type="hidden" name="op" value="' . (!empty($r['pin']) ? 'unpin' : 'pin') . '"><button name="do" value="tg-msg" class="ghost sm">' . (!empty($r['pin']) ? 'Unpin' : 'Pin') . '</button></form>' .
                        $f . '<input type="hidden" name="op" value="delete"><button name="do" value="tg-msg" class="danger sm" data-confirm="Delete this post from the Telegram chat? This can\'t be undone.">Delete</button></form>' : '') .
                    (($r['h'] ?? '') !== '' ? $f . '<input type="hidden" name="op" value="resend"><button name="do" value="tg-msg" class="ghost sm" data-confirm="Post this again as a new message in the chat?">Send again</button></form>' .
                        '<a class="btn ghost sm" href="' . h(x_intent(x_from_tg($r['h']))) . '" target="_blank" rel="noopener" title="Opens X with this post ready to send from the project account">Post on X</a>' : '') . '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        echo '<form method="post" class="bar tg-linkf">' . $csrfIn . '<label>An older post<input name="link" placeholder="Paste its link: right-click the post in Telegram, Copy Message Link" spellcheck="false"></label>' .
            '<button name="do" value="tg-link" class="danger sm" onclick="this.form.op.value=\'delete\'" data-confirm="Delete that post from the Telegram chat?">Delete</button><button name="do" value="tg-link" class="ghost sm" onclick="this.form.op.value=\'pin\'">Pin</button><button name="do" value="tg-link" class="ghost sm" onclick="this.form.op.value=\'unpin\'">Unpin</button><input type="hidden" name="op" value=""></form>';
    }
    echo '<h2>On time, even when the site is quiet</h2><p class="muted">Reminders and tournament rounds run whenever people are on the site. To make them punctual, add a cron job in Hostinger: <b>hPanel, Advanced, Cron Jobs</b>, every 5 minutes, with this command:</p><div class="hashline"><code id="cronline">wget -q -O /dev/null "' . h(TG_SITE) . '/api/cron.php?k=' . h(cron_key()) . '"</code><button type="button" class="ghost" data-copy="cronline">Copy</button></div>';
}


//MC 2026-10-09 Admin > Email: where team emails go, which ones, previews, the log of every email, and the day by day counters
if ($tab === 'email') {
    $mc = mail_cfg(); $edit = can('team', 2); $csrfIn = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    $log = load(MAILLOG)['l'] ?? [];
    $sent7 = array_filter($log, fn($m) => $m['at'] > time() - 7 * 86400);
    $open7 = count(array_filter($sent7, fn($m) => $m['opened']));
    $fail7 = count(array_filter($sent7, fn($m) => !$m['ok']));
    echo '<section class="grid"><div class="stat"><b style="font-size:15px;overflow-wrap:anywhere">' . ($mc['to'] ? implode('<br>', array_map('h', $mc['to'])) : 'Nobody yet') . '</b><span>Sending to</span></div>' .
        '<div class="stat"><b>' . count($sent7) . '</b><span>Sent, last 7 days</span></div><div class="stat"><b>' . $open7 . '</b><span>Opened</span></div><div class="stat"><b>' . $fail7 . '</b><span>Failed</span></div></section>';
    if (!$mc['to']) echo '<p class="viewonly">No address yet, so nothing is sent. Add one below. Until then, the address in Ideas is used if there is one.</p>';
    echo '<h2>Settings</h2>';
    echo '<form method="post" class="mailset">' . $csrfIn . '<label>Send to <small class="muted">(one or more addresses, separated by commas)</small><input name="to" type="text" value="' . h(trim((string)(eco_settings()['mail_to'] ?? ''))) . '" placeholder="' . h(trim((string)(eco_settings()['idea_email'] ?? 'you@example.com'))) . '"' . ($edit ? '' : ' disabled') . '></label>';
    //MC 2026-10-12 who gets what: one row per kind of email, a column per person (the Send to addresses and every admin
    //   with an email on their account). "On" switches a kind off for everyone. All / None under a name ticks a column.
    $ppl = array_values(mail_people()); $dis = $edit ? '' : ' disabled';
    echo '<p class="muted">Tick who gets each kind of email. Admins show here once they have an email on their account (Team). Someone new starts with: Send to addresses get everything, other admins get only the farming alert.</p>';
    echo '<div class="tw mr-tw"><table class="mr"><thead><tr><th>Kind of email</th><th class="c">On</th>';
    foreach ($ppl as $i => $pp) echo '<th class="c"><span class="mr-who">' . h($pp['name'] !== '' ? $pp['name'] : 'Alert address') . '</span><small>' . h($pp['email']) . '</small><input type="hidden" name="rp[' . $i . ']" value="' . h($pp['email']) . '">' . ($edit ? '<span class="mr-all"><button type="button" data-mr="' . $i . ':1">All</button><button type="button" data-mr="' . $i . ':0">None</button></span>' : '') . '</th>';
    echo '</tr></thead><tbody>';
    foreach (MAIL_TYPES as $k => [$lab, $desc]) {
        echo '<tr><td><b>' . h($lab) . '</b><small>' . h($desc) . '</small></td><td class="c"><input type="checkbox" name="on[' . h($k) . ']" value="1" aria-label="' . h($lab) . ' on"' . (empty($mc['off'][$k]) ? ' checked' : '') . $dis . '></td>';
        foreach ($ppl as $i => $pp) echo '<td class="c"><input type="checkbox" name="rt[' . $i . '][' . h($k) . ']" value="1" data-col="' . $i . '" aria-label="' . h($lab) . ' to ' . h($pp['email']) . '"' . (mail_gets($pp, $k) ? ' checked' : '') . $dis . '></td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
    if (!$ppl) echo '<p class="viewonly">Nobody to send to yet: add an address in Send to, or an email on an admin account in Team.</p>';
    echo '<script>document.addEventListener("click",function(e){var b=e.target.closest("[data-mr]");if(!b)return;var p=b.dataset.mr.split(":");document.querySelectorAll(\'.mr input[data-col="\'+p[0]+\'"]\').forEach(function(c){c.checked=p[1]==="1";});});</script>';
    echo '<div class="bar"><label>Reports go out after <select name="hour"' . ($edit ? '' : ' disabled') . '>';
    for ($hr = 0; $hr < 24; $hr++) { $loc = (new DateTime('@' . (strtotime('today UTC') + $hr * 3600)))->setTimezone(new DateTimeZone($mc['tz']))->format('g A'); echo '<option value="' . $hr . '"' . ($hr === $mc['hour'] ? ' selected' : '') . '>' . sprintf('%02d:00 UTC', $hr) . ' (' . h($loc) . ')</option>'; }
    echo '</select></label><label>Times shown in <select name="tz"' . ($edit ? '' : ' disabled') . '>';
    foreach (['America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles', 'Europe/London', 'Europe/Berlin', 'Asia/Dubai', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney', 'UTC'] as $z) echo '<option' . ($z === $mc['tz'] ? ' selected' : '') . '>' . h($z) . '</option>';
    echo '</select></label>' . ($edit ? '<button name="do" value="mail-save">Save</button>' : '<span class="muted">Only admins who manage the team can change these.</span>') . '</div></form>';
    echo '<div class="bar"><form method="post">' . $csrfIn . '<button name="do" value="mail-test" class="ghost">Send a test email</button></form>' .
        '<form method="post">' . $csrfIn . '<input type="hidden" name="which" value="daily"><button name="do" value="mail-report" class="ghost">Send yesterday\'s report now</button></form>' .
        '<form method="post">' . $csrfIn . '<input type="hidden" name="which" value="week"><button name="do" value="mail-report" class="ghost">Send last week\'s report now</button></form></div>';
    echo '<h2>See them as they arrive</h2><p class="muted">Each one opens in a new tab, built from the site\'s real data.</p><div class="bar">';
    foreach (['daily' => 'Daily report', 'week' => 'Weekly report', 'sale' => 'A sale', 'swap' => '$SHY bought on the site', 'weekly' => 'Weekly winners', 'bounty' => '15 Club winner'] as $k => $lab) echo '<a class="btnl" target="_blank" rel="noopener" href="?tab=email&amp;preview=' . h($k) . '">' . h($lab) . ' &#8599;</a>';
    echo '</div>';
    echo '<h2>Every email sent <small>' . count($log) . ' kept</small></h2>';
    echo '<div class="tw"><table><thead><tr><th>Sent</th><th>Kind</th><th>Subject</th><th>To</th><th>Status</th></tr></thead><tbody>';
    foreach (array_slice($log, 0, 80) as $m) echo '<tr><td>' . h(gmdate('M j H:i', $m['at'])) . ' <small class="muted">UTC</small></td><td>' . h(MAIL_TYPES[$m['type']][0] ?? ucfirst($m['type'])) . '</td><td>' . h($m['subject']) . '</td><td><small>' . h($m['to']) . '</small></td><td>' .
        (!$m['ok'] ? '<i class="bad">Failed</i>' : ($m['opened'] ? '<i class="ok">Opened</i> <small class="muted">' . h(ago($m['opened'])) . ($m['opens'] > 1 ? ', ' . (int)$m['opens'] . ' times' : '') . '</small>' : '<i>Sent</i> <small class="muted">not opened yet</small>')) . '</td></tr>';
    if (!$log) echo '<tr><td colspan="5" class="muted">Nothing sent yet.</td></tr>';
    echo '</tbody></table></div><p class="muted">"Opened" shows once the email\'s pictures load. Some mail apps block pictures, so an email can be read without showing as opened.</p>';
    // the counters behind the reports, day by day
    $tr = load(TRACK)['d'] ?? []; $stt = load(STATS)['d'] ?? [];
    echo '<h2>Day by day <small>the counters behind the reports</small></h2><div class="tw"><table><thead><tr><th>Day (UTC)</th><th>Games</th><th>Players</th><th>Most online</th><th>Sales</th><th>$SHY swaps</th><th>Friend requests</th><th>Invites</th><th>Live matches</th><th>Shares</th><th>Wallets</th><th>Ideas</th></tr></thead><tbody>';
    for ($i = 0; $i < 14; $i++) {
        $d = gmdate('Y-m-d', time() - $i * 86400); $t = $tr[$d] ?? []; $g = $stt[$d] ?? [];
        echo '<tr><td>' . h(gmdate('D M j', strtotime($d . ' UTC'))) . '</td><td>' . (int)($g['g'] ?? 0) . '</td><td>' . count($g['p'] ?? []) . '</td><td>' . (int)($t['peak_online'] ?? 0) . '</td><td>' . (int)($t['sales'] ?? 0) . '</td><td>' . (int)($t['swaps'] ?? 0) . '</td><td>' . (int)($t['fr_req'] ?? 0) . '</td><td>' . (int)($t['fr_live'] ?? 0) . '</td><td>' . (int)($t['live_rooms'] ?? 0) . '</td><td>' . (int)($t['shares'] ?? 0) . '</td><td>' . (int)($t['wallets'] ?? 0) . '</td><td>' . (int)($t['ideas'] ?? 0) . '</td></tr>';
    }
    echo '</tbody></table></div>';
}
if ($tab === 'logs') {
    foreach (LOGS as $f => $label) {
        $path = DATA_DIR . '/' . $f;
        $lines = is_file($path) ? array_slice(file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [], -60) : [];
        echo '<h2>' . h($label) . ' <small>' . count($lines) . ' recent</small></h2>';
        echo '<pre class="log">' . ($lines ? h(implode("\n", array_reverse($lines))) : 'Nothing logged.') . '</pre>';
        if ($lines) echo '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="log" value="' . h($f) . '"><button name="do" value="clear-log" class="ghost" data-confirm="Clear this log? What\'s in it now is gone for good.">Clear</button></form>';
    }
}

if ($tab === 'backups') {
    $files = is_dir(BACKUPS) ? glob(BACKUPS . '/players-*.php') : [];
    rsort($files);
    //MC 2026-10-11 more files are backed up (see OPS_BACKUP in api/opslib.php), daily for 14 days plus weekly for 8 weeks,
    //   by the cron job. This tab now says what each copy holds and how it comes back, and owners can download everything.
    echo '<p class="muted">After midnight UTC the cron job copies every important data file into shy-data/backups. Daily copies are kept for ' . OPS_KEEP_DAYS . ' days and weekly copies (made on the first night of each week) for ' . OPS_KEEP_WEEKS . ' weeks. The scores, shop accounts, orders and rewards are also copied by the site itself on the first save of the day, so they\'re kept even if the cron job stops.</p>';
    if (is_owner()) {
        $zipOk = class_exists('ZipArchive');
        [$artSz] = ops_dir_size(DATA_DIR . '/card-art-src'); [$keepSz] = ops_dir_size(DATA_DIR . '/card-art-keep');
        echo '<h2>Download all data</h2><p class="muted">One zip of everything in shy-data: players, shop, orders, rewards, settings, logs and config.php with the private keys, so keep it somewhere private. Live rooms, share pictures, the backups folder and caches the site rebuilds by itself are left out. A README inside says what each file is.</p>';
        echo $zipOk ? '<div class="bar"><a class="btn" href="?dl=allzip">Download all data (zip)</a><a class="btn ghost" href="?dl=allzip&amp;art=1">With the card art pictures (+' . h(ops_bytes($artSz + $keepSz)) . ')</a></div>'
            : '<p class="viewonly">This server\'s PHP has no zip support, so the one-click download is off. Download the score copies below one by one, or ask Hostinger to switch on the PHP zip extension.</p>';
    }
    $bst = backup_status();
    echo '<h2>What is backed up <small>and how it comes back</small></h2><div class="tw"><table><thead><tr><th>File</th><th>What it holds</th><th>Newest daily</th><th>Daily / weekly copies</th><th>To restore</th></tr></thead><tbody>';
    foreach ($bst as $name => $b) echo '<tr><td class="nw"><code>' . h($b['file']) . '</code></td><td class="small">' . h($b['what']) . '</td><td class="nw">' . ($b['last'] !== '' ? h($b['last']) : '<span class="muted">' . ($b['exists'] ? 'not yet' : 'no file yet') . '</span>') . '</td><td>' . (int)$b['days'] . ' / ' . (int)$b['weeks'] . '</td><td class="small">' . ($name === 'players' ? 'Restore button below' : 'By hand') . '</td></tr>';
    echo '</tbody></table></div>';
    echo '<p class="muted small"><b>By hand</b>: in Hostinger File Manager open shy-data/backups, copy the file you need (for example <code>holders-2026-10-10.php</code>), then in shy-data rename it to the name in the File column (<code>holders.php</code>) over the old one. Do it at a quiet time. The shop files belong together: if you put back <code>economy.php</code>, put back <code>orders.php</code> and <code>rewards.php</code> from the same day too, or ask the developer first.</p>';
    echo '<h2>Score copies</h2>';
    echo '<p class="muted">Restoring replaces every player\'s scores, League and Season points with that copy (the current scores are saved first as a before-restore copy, so you can undo it). Shop accounts, orders and rewards stay as they are. For League points lost to the Oct 11 bug, use Recover lost League points in Rewards instead: it only adds back what was lost.</p>';
    echo '<div class="tw"><table><thead><tr><th>Copy</th><th>Players</th><th>Size</th><th></th></tr></thead><tbody>';
    foreach ($files as $f) {
        $b = basename($f); $n = count(load($f));
        $isDay = preg_match('/^players-\d{4}-(\d{2}-\d{2}|W\d{2})\.php$/', $b);   //MC 2026-10-11 weekly copies restore too
        $lab = str_replace(['players-', '.php'], '', $b); if (preg_match('/^\d{4}-W(\d{2})$/', $lab, $wm)) $lab = 'Week ' . (int)$wm[1] . ', ' . substr($lab, 0, 4);
        //MC 2026-10-09 nw: dates and sizes split across lines on phones ("2026-10- / 09", "471.1 / KB")
        echo '<tr><td class="nw"><b>' . h($lab) . '</b></td><td>' . $n . '</td><td class="nw">' . round(filesize($f) / 1024, 1) . ' KB</td><td class="acts"><a class="btn sm" href="?dl=backup&f=' . urlencode($b) . '">Download</a>' .
            ($isDay ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="f" value="' . h($b) . '"><button name="do" value="restore" class="danger" data-confirm="Replace all current scores with the copy from ' . h($lab) . '?">Restore</button></form>' : '') . '</td></tr>';
    }
    if (!$files) echo '<tr><td colspan="4" class="muted">The first copy is made the next time someone saves a score.</td></tr>';
    echo '</tbody></table></div>';
}

echo '</div></main></div></div>';
echo '<script src="admin.js?v=' . h(@filemtime(__DIR__ . '/admin.js')) . '"></script>';   //MC 2026-10-13 pages, tabs, search and the menu (was sections.js)
// view-only parts: switch off every control in them, so it's clear nothing can be changed there
$presets = []; foreach (array_keys(ROLES) as $r) if ($r !== 'custom') $presets[$r] = role_perms($r);
echo '<script>(function(){document.querySelectorAll("form").forEach(function(f){var w=f.closest(".ro, .rw");if(w&&w.classList.contains("ro")&&f.method==="post")f.querySelectorAll("input,select,textarea,button").forEach(function(e){if(e.type!=="hidden")e.disabled=true;});});' .
  'document.querySelectorAll(".ro button.send").forEach(function(b){b.disabled=true;});' .
  'var P=' . json_encode($presets) . ';' .
  'function sync(sel){var f=sel.closest("form"),r=sel.value,g=f.querySelector(".pwrap");if(!g)return;if(r==="custom"){g.removeAttribute("data-preset");g.querySelectorAll("input[type=radio]").forEach(function(i){if(!i.closest("label.dis"))i.disabled=false;});return;}g.setAttribute("data-preset","");var p=P[r]||{};g.querySelectorAll("input[type=radio]").forEach(function(i){var a=i.name.slice(2);i.checked=String(p[a]||0)===i.value;i.disabled=true;});}' .
  'document.querySelectorAll("select[data-role]").forEach(function(s){sync(s);s.addEventListener("change",function(){sync(s);});});' .
  'document.addEventListener("submit",function(e){e.target.querySelectorAll(".pwrap input[type=radio]:disabled").forEach(function(i){i.disabled=false;});},true);' .
  'document.addEventListener("click",function(e){var c=e.target.closest("[data-copy]");if(c&&c.dataset.copy){var el=document.getElementById(c.dataset.copy);if(el){navigator.clipboard.writeText(el.textContent);c.textContent="Copied";}}});})();</script>';
?>
<script>
(function(){
  // two-step sign-in: draw the QR code for the authenticator app
  var qr=document.getElementById("tfa-qr");
  if(qr){var sc=document.createElement("script");sc.src="../assets/vendor/qrcode.js";sc.onload=function(){try{var q=window.qrcode(0,"M");q.addData(qr.dataset.uri);q.make();qr.innerHTML=q.createSvgTag({cellSize:4,margin:2,scalable:true});}catch(e){}};document.head.appendChild(sc);}
  // tournaments: the partner fields show only for a joint event
  document.querySelectorAll("[data-gate]").forEach(function(sel){var box=sel.form.querySelector("[data-pt]");function sync(){if(box)box.hidden=sel.value!=="partner";}sel.addEventListener("change",sync);sync();});
  // card art: filter chips
  var sr=document.querySelector("[data-shop-refresh]");
  if(sr){var busy=false;async function shopRefresh(){if(busy)return;busy=true;sr.disabled=true;sr.textContent="Refreshing...";
    try{var t=await (await fetch(location.href,{cache:"no-store",credentials:"same-origin"})).text();var d=new DOMParser().parseFromString(t,"text/html");var at=d.querySelector("[data-shop-at]");
      ["shop-stats","koban-flow"].forEach(function(id){var n=d.getElementById(id),o=document.getElementById(id);if(n&&o)o.innerHTML=n.innerHTML;});if(at)document.querySelector("[data-shop-at]").textContent=at.textContent;}catch(e){}
    sr.disabled=false;sr.textContent="Refresh";busy=false;}
    sr.addEventListener("click",shopRefresh);setInterval(function(){if(!document.hidden)shopRefresh();},60000);}
  var f=document.querySelector(".artfilter");
  if(f){var ak="",aq="";function artShow(){document.querySelectorAll(".artcard").forEach(function(c){var okK=!ak||c.dataset.kind===ak||c.dataset.st===ak||(ak==="season"&&!!c.dataset.season);var q=aq.replace(/^#/,"");var okQ=!q||(/^\d+$/.test(q)?c.dataset.no===String(+q):c.dataset.name.indexOf(q)>=0);c.hidden=!(okK&&okQ);});var an=document.getElementById("art-none");if(an)an.hidden=!!document.querySelector(".artcard:not([hidden])");}
    f.addEventListener("click",function(e){var b=e.target.closest("button");if(!b)return;f.querySelectorAll("button").forEach(function(x){x.classList.toggle("on",x===b);});ak=b.dataset.k;artShow();});
    var fi=f.querySelector(".artfind");if(fi)fi.addEventListener("input",function(){aq=fi.value.trim().toLowerCase();artShow();});}
  // card art: click where the card should focus; the dashed box is the part that will show
  var box=document.querySelector("[data-focus]");
  if(box){var img=box.querySelector("img"),dot=box.querySelector(".dot"),fr=box.querySelector(".frame"),form=box.closest("form");
    function draw(fx,fy){dot.style.left=fx+"%";dot.style.top=fy+"%";var w=img.naturalWidth,h=img.naturalHeight;if(!w)return;var want=13/8,cw,ch;if(w/h>want){ch=h;cw=h*want;}else{cw=w;ch=w/want;}var cx=Math.max(0,Math.min(w-cw,fx/100*w-cw/2)),cy=Math.max(0,Math.min(h-ch,fy/100*h-ch/2));fr.style.left=cx/w*100+"%";fr.style.top=cy/h*100+"%";fr.style.width=cw/w*100+"%";fr.style.height=ch/h*100+"%";}
    function cur(){return [+form.fx.value,+form.fy.value];}
    if(img.complete)draw.apply(null,cur());else img.addEventListener("load",function(){draw.apply(null,cur());});
    box.addEventListener("click",function(e){var r=img.getBoundingClientRect();var fx=Math.round((e.clientX-r.left)/r.width*100),fy=Math.round((e.clientY-r.top)/r.height*100);form.fx.value=fx;form.fy.value=fy;draw(fx,fy);});}
})();
</script>
<script>
// guide: section tabs, with links straight to a section (#g-shop)
(function () {
  var tabs = document.querySelectorAll(".g-tabs [data-g]"); if (!tabs.length) return;
  function show(k) {
    if (!document.getElementById("g-" + k)) return false;
    tabs.forEach(function (t) { var on = t.dataset.g === k; t.classList.toggle("on", on); t.setAttribute("aria-selected", on); });
    document.querySelectorAll(".g-panel").forEach(function (p) { p.hidden = p.id !== "g-" + k; });
    return true;
  }
  tabs.forEach(function (t) { t.addEventListener("click", function () { show(t.dataset.g); history.replaceState(null, "", "#g-" + t.dataset.g); }); });
  var h = location.hash.replace(/^#g-/, "");
  if (h === "hash") { show("start"); var el = document.getElementById("g-hash"); if (el) el.scrollIntoView(); } else if (h) show(h);
})();
document.addEventListener("click", function (e) {
  var q = e.target.closest("[data-award-set]");
  if (q) { var f = q.closest("form"), i = f && f.querySelector("[data-award-amt]"); if (i) { i.value = q.getAttribute("data-award-set"); i.focus(); } return; }
});
document.addEventListener("click", function (e) {
  var b = e.target.closest("[data-confirm]");
  if (!b) return;
  var msg = b.getAttribute("data-confirm");
  //MC 2026-10-11 a Koban award names the amount and the player in the prompt (up to 100,000 either way)
  if (b.value === "grant" && b.form) {
    var k = +(b.form.elements.koban && b.form.elements.koban.value || 0), w = b.form.elements.who && b.form.elements.who.value || "";
    var d = b.closest("details"), nm = (d && d.dataset.name) || w;
    if (k) msg = (k > 0 ? "Give " + k.toLocaleString("en-US") + " Koban to " : "Take " + (-k).toLocaleString("en-US") + " Koban back from ") + nm + "?";
  }
  if (!confirm(msg)) e.preventDefault();
});
// ---------- payouts: built here, signed by the marketing wallet in Phantom ----------
(function () {
  var S = window.SHY, W = window.solanaWeb3;
  if (!S || !W) return;
  var ATA = new W.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"), MEMO = new W.PublicKey("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");
  async function api(b) { var r = await fetch("./?api=1", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ csrf: S.csrf }, b)) }); return r.json(); }
  function ata(owner, mint, prog) { return W.PublicKey.findProgramAddressSync([owner.toBytes(), prog.toBytes(), mint.toBytes()], ATA)[0]; }
  function u64(n) { var b = new Uint8Array(8), v = BigInt(n); for (var i = 0; i < 8; i++) { b[i] = Number(v & 255n); v >>= 8n; } return b; }
  document.addEventListener("click", async function (e) {
    var btn = e.target.closest("[data-send]"); if (!btn) return;
    var period = btn.dataset.send, box = btn.parentNode, msg = box.querySelector(".send-msg");
    var say = function (t) { msg.textContent = t; };
    var all = Array.prototype.slice.call(document.querySelectorAll('table[data-period="' + period + '"] tbody tr')).filter(function (r) { return r.dataset.paid !== "1"; });
    //MC 2026-10-11 rows already sent in a batch Solana hasn't confirmed yet are never sent again from here
    var rows = all.filter(function (r) { return r.dataset.held !== "1"; });
    if (!rows.length) return say(all.length ? "These prizes were already sent and are waiting for Solana to confirm. Reload in a minute." : "Nothing left to pay here.");
    if (rows.some(function (r) { return !r.dataset.units; })) return say("Set the amounts first.");
    var prov = window.phantom && window.phantom.solana; if (!prov) return say("Open this page in a browser with Phantom.");
    try {
      btn.disabled = true;
      var c = await prov.connect(), from = c.publicKey;
      if (from.toString() !== S.mw && !confirm("The connected wallet is " + from.toString() + ", not the marketing wallet. Send from it anyway?")) { btn.disabled = false; return say("Cancelled."); }
      var mint = new W.PublicKey(S.mint);
      var info = await api({ act: "rpc", method: "getAccountInfo", addr: S.mint });
      var prog = new W.PublicKey(info.result.value.owner);
      var src = ata(from, mint, prog);
      // up to 5 winners per transaction keeps each one well under the size limit
      for (var k = 0; k < rows.length; k += 5) {
        var part = rows.slice(k, k + 5);
        var bh = await api({ act: "rpc", method: "getLatestBlockhash", period: period });
        if (!bh.ok) throw new Error(bh.error || "Couldn't start the payout.");
        var tx = new W.Transaction({ feePayer: from, recentBlockhash: bh.result.value.blockhash });
        part.forEach(function (r) {
          var to = new W.PublicKey(r.dataset.wallet), dst = ata(to, mint, prog);
          tx.add(new W.TransactionInstruction({ programId: ATA, data: Uint8Array.of(1), keys: [{ pubkey: from, isSigner: true, isWritable: true }, { pubkey: dst, isSigner: false, isWritable: true }, { pubkey: to, isSigner: false, isWritable: false }, { pubkey: mint, isSigner: false, isWritable: false }, { pubkey: W.SystemProgram.programId, isSigner: false, isWritable: false }, { pubkey: prog, isSigner: false, isWritable: false }] }));
          var d = new Uint8Array(10); d[0] = 12; d.set(u64(r.dataset.units), 1); d[9] = +r.dataset.dec;
          tx.add(new W.TransactionInstruction({ programId: prog, data: d, keys: [{ pubkey: src, isSigner: false, isWritable: true }, { pubkey: mint, isSigner: false, isWritable: false }, { pubkey: dst, isSigner: false, isWritable: true }, { pubkey: from, isSigner: true, isWritable: false }] }));
        });
        tx.add(new W.TransactionInstruction({ programId: MEMO, keys: [], data: new TextEncoder().encode("shyonsol prizes " + period) }));
        say("Approve batch " + (k / 5 + 1) + " of " + Math.ceil(rows.length / 5) + " in Phantom...");
        var res = await prov.signAndSendTransaction(tx);
        say("Checking batch " + (k / 5 + 1) + " on Solana...");
        var v = await api({ act: "payout-sent", period: period, sig: res.signature });
        say(v.ok ? "Batch " + (k / 5 + 1) + ": " + v.paid + " paid." : (v.error || "Couldn't confirm yet."));
      }
      setTimeout(function () { location.reload(); }, 1500);
    } catch (err) { say((err && err.message) || "Something went wrong."); btn.disabled = false; }
  });
})();
//MC 2026-10-10 Pay everything owed: plan on the server, build here, Phantom signs and sends, the server holds each
//   signature until it's checked on Solana, then one Telegram post and an X post to open
(function () {
  var S = window.SHY, W = window.solanaWeb3, box = document.getElementById("payall");
  if (!S || !W || !box) return;
  var out = box.querySelector(".payall-out"), plan = null;
  var ATA = new W.PublicKey("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL"), MEMO = new W.PublicKey("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");
  function esc(t) { return String(t == null ? "" : t).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function n(x) { return Number(x || 0).toLocaleString("en-US"); }
  async function api(b) { var r = await fetch("./?api=1", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ csrf: S.csrf }, b)) }); return r.json(); }
  function ata(owner, mint, prog) { return W.PublicKey.findProgramAddressSync([owner.toBytes(), prog.toBytes(), mint.toBytes()], ATA)[0]; }
  function u64(v) { var b = new Uint8Array(8); v = BigInt(v); for (var i = 0; i < 8; i++) { b[i] = Number(v & 255n); v >>= 8n; } return b; }
  function draw(h) { out.hidden = false; out.innerHTML = h; }
  function log(t, cls) { var ul = out.querySelector(".payall-log"); if (!ul) { out.insertAdjacentHTML("beforeend", '<ul class="payall-log"></ul>'); ul = out.querySelector(".payall-log"); } ul.insertAdjacentHTML("beforeend", '<li class="' + (cls || "") + '">' + t + '</li>'); }
  box.addEventListener("click", async function (e) {
    var b;
    if ((b = e.target.closest("[data-payall]"))) {
      b.disabled = true; draw('<p class="muted">Pricing everything owed at today\'s $SHY price&hellip;</p>');
      var j = await api({ act: "payall-plan" }); b.disabled = false;
      if (!j.ok) return draw('<p class="bad">' + esc(j.error || "Couldn't build the payout.") + '</p>');
      plan = j;
      var burnShy = +j.burn.units / Math.pow(10, j.dec);
      var h = !j.items.length && !burnShy ? (j.held ? '<p>Nothing new to pay. A batch sent earlier is still waiting for Solana to confirm it.</p>' : ((j.skipped || []).length ? '<p>Nothing ready to pay. ' + (j.skipped.length === 1 ? 'One prize is' : j.skipped.length + ' prizes are') + ' waiting, see below.</p>' : '<p>Nothing to pay right now. Everyone is paid.</p>')) :
        '<div class="tw"><table class="payall-t"><thead><tr><th>Prize and winner</th><th>$SHY</th><th>USD</th></tr></thead><tbody>' + j.items.map(function (it) {
          return '<tr><td>' + esc(it.label) + '<br><b>' + esc(it.name) + '</b> <small>' + esc(it.wallet.slice(0, 4) + "…" + it.wallet.slice(-4)) + '</small></td><td>' + n(Math.round(+it.units / Math.pow(10, it.dec))) + '</td><td>$' + (+it.usd).toFixed(2) + '</td></tr>';
        }).join("") + (burnShy ? '<tr><td>Burn owed by the shop<br><small>' + j.burn.orders.length + (j.burn.orders.length === 1 ? ' payment' : ' payments') + ' that came without their burn</small></td><td>' + n(Math.round(burnShy)) + '</td><td></td></tr>' : "") +
        '<tr class="tot"><td>Total: ' + j.total.n + (j.total.n === 1 ? ' prize' : ' prizes') + '</td><td>' + n(j.total.shy) + (burnShy ? '<br><small>+ ' + n(Math.round(burnShy)) + ' burned</small>' : "") + '</td><td>$' + j.total.usd.toFixed(2) + '</td></tr></tbody></table></div>' +
        '<div class="payall-act"><button class="send" data-payall-go>Approve in Phantom (' + Math.max(1, Math.ceil(j.items.length / 5)) + (Math.ceil(j.items.length / 5) > 1 ? ' transactions' : ' transaction') + ')</button><button class="ghost" data-payall-x>Cancel</button><span class="muted">At $' + Number(j.px).toPrecision(4) + ' per $SHY.</span></div>';
      if (j.skipped.length) h += '<ul class="payall-skip">' + j.skipped.map(function (s) { return '<li' + (s.held ? ' class="held"' : '') + '><b>' + (s.held ? 'On hold:' : 'Not included:') + '</b> ' + esc(s.label) + ', ' + esc(s.why) + '</li>'; }).join("") + '</ul>';
      return draw(h);
    }
    if (e.target.closest("[data-payall-x]")) { plan = null; out.hidden = true; out.innerHTML = ""; return; }
    if ((b = e.target.closest("[data-payall-go]")) && plan) {
      var prov = window.phantom && window.phantom.solana || window.solana; if (!prov) return log("Open this page in a browser with Phantom.", "bad");
      b.disabled = true;
      try {
        var c = await prov.connect(), from = c.publicKey;
        if (from.toString() !== plan.mw && !confirm("The connected wallet is " + from.toString() + ", not the marketing wallet. Send from it anyway?")) { b.disabled = false; return log("Cancelled.", "bad"); }
        var mint = new W.PublicKey(plan.mint);
        var info = await api({ act: "rpc", method: "getAccountInfo", addr: plan.mint });
        var prog = new W.PublicKey(info.result.value.owner), src = ata(from, mint, prog);
        var bh = await api({ act: "rpc", method: "getLatestBlockhash" });
        if (!bh.ok) throw new Error(bh.error || "Couldn't reach Solana.");
        // up to 5 winners a transaction keeps each one well under the size limit; the burn rides in the first
        var groups = []; for (var k = 0; k < plan.items.length; k += 5) groups.push(plan.items.slice(k, k + 5));
        if (!groups.length) groups.push([]);
        var txs = groups.map(function (g, gi) {
          var tx = new W.Transaction({ feePayer: from, recentBlockhash: bh.result.value.blockhash });
          g.forEach(function (it) {
            var to = new W.PublicKey(it.wallet), dst = ata(to, mint, prog);
            tx.add(new W.TransactionInstruction({ programId: ATA, data: Uint8Array.of(1), keys: [{ pubkey: from, isSigner: true, isWritable: true }, { pubkey: dst, isSigner: false, isWritable: true }, { pubkey: to, isSigner: false, isWritable: false }, { pubkey: mint, isSigner: false, isWritable: false }, { pubkey: W.SystemProgram.programId, isSigner: false, isWritable: false }, { pubkey: prog, isSigner: false, isWritable: false }] }));
            var d = new Uint8Array(10); d[0] = 12; d.set(u64(it.units), 1); d[9] = it.dec;
            tx.add(new W.TransactionInstruction({ programId: prog, data: d, keys: [{ pubkey: src, isSigner: false, isWritable: true }, { pubkey: mint, isSigner: false, isWritable: false }, { pubkey: dst, isSigner: false, isWritable: true }, { pubkey: from, isSigner: true, isWritable: false }] }));
          });
          if (gi === 0 && +plan.burn.units > 0) {
            var bd = new Uint8Array(10); bd[0] = 15; bd.set(u64(plan.burn.units), 1); bd[9] = plan.dec;
            tx.add(new W.TransactionInstruction({ programId: prog, data: bd, keys: [{ pubkey: src, isSigner: false, isWritable: true }, { pubkey: mint, isSigner: false, isWritable: true }, { pubkey: from, isSigner: true, isWritable: false }] }));
          }
          tx.add(new W.TransactionInstruction({ programId: MEMO, keys: [], data: new TextEncoder().encode("shyonsol prizes " + new Date().toISOString().slice(0, 10)) }));
          return tx;
        });
        //MC 2026-10-10 Phantom signs AND sends (its own RPC, its own retries): the same path the single-list payout and
        //   the shop use. The old "sign here, send through the server" path is only a fallback for wallets without it.
        //   Each signature is written down on the server the moment it exists, so a second press can't pay twice.
        log("Approve " + txs.length + (txs.length === 1 ? " transaction" : " transactions") + " in Phantom&hellip;");
        var sent = [];
        //MC 2026-10-12 one approval per transaction, never the batch call: Phantom's safety check blocked a 2-transaction
        //   payout sent with signAndSendAllTransactions as "could be malicious" (many token transfers approved at once is
        //   what wallet drainers do), while the same payouts one at a time went through. Kept below for other wallets only.
        if (false && txs.length > 1 && prov.signAndSendAllTransactions) {
          var all = await prov.signAndSendAllTransactions(txs);
          (all.signatures || []).forEach(function (sg, i) { if (sg) sent.push([i, typeof sg === "string" ? sg : W.bs58 ? W.bs58.encode(sg) : String(sg)]); });
          for (var q = 0; q < sent.length; q++) await api({ act: "payall-pending", sig: sent[q][1], items: groups[sent[q][0]], burns: sent[q][0] === 0 ? plan.burn.orders : [] });
        } else if (prov.signAndSendTransaction) {
          for (var i = 0; i < txs.length; i++) {
            var res = await prov.signAndSendTransaction(txs[i]);
            sent.push([i, res.signature]);
            await api({ act: "payall-pending", sig: res.signature, items: groups[i], burns: i === 0 ? plan.burn.orders : [] });
          }
        } else {
          var signed = await prov.signAllTransactions(txs);
          for (var i2 = 0; i2 < txs.length; i2++) {
            var raw = signed[i2].serialize(), b64 = btoa(String.fromCharCode.apply(null, raw));
            var s = await api({ act: "send", tx: b64 });
            if (!s.ok) { log("Batch " + (i2 + 1) + ": " + esc(s.error), "bad"); continue; }
            sent.push([i2, s.sig]);
            await api({ act: "payall-pending", sig: s.sig, items: groups[i2], burns: i2 === 0 ? plan.burn.orders : [] });
          }
        }
        // anything sent is final: this plan can't be sent a second time (the next plan leaves held prizes out)
        var pl = plan; if (sent.length) { plan = null; b.remove(); }
        var sigs = [];
        for (var x = 0; x < sent.length; x++) {
          var gi2 = sent[x][0], sig = sent[x][1], lk = ' <a href="https://solscan.io/tx/' + esc(sig) + '" target="_blank" rel="noopener">Solscan</a>';
          log("Batch " + (gi2 + 1) + " sent. Checking it on Solana&hellip;");
          var v = await api({ act: "payall-sent", sig: sig, items: groups[gi2], burns: gi2 === 0 ? pl.burn.orders : [] });
          if (v.ok) { sigs.push(sig); log("Batch " + (gi2 + 1) + ": " + v.paid + " paid" + (v.burned ? ", " + n(Math.round(v.burned / Math.pow(10, pl.dec))) + " $SHY burned" : "") + "." + lk, "ok"); }
          else log("Batch " + (gi2 + 1) + ": " + esc(v.error || "not confirmed yet") + lk, v.wait ? "" : "bad");
        }
        if (!sigs.length) { b.disabled = false; return; }
        var dn = await api({ act: "payall-done", sigs: sigs });
        if (dn.ok && dn.text) {
          out.insertAdjacentHTML("beforeend", '<div class="payall-act">' + (dn.tg ? '<span class="ok">Posted to Telegram.</span>' : '<span class="muted">Nothing went to Telegram: the bot isn\'t set up or Prize payouts is switched off.</span>') +
            '<a class="payall-x" href="' + esc(dn.x) + '" target="_blank" rel="noopener">Post it on X</a><button class="ghost" onclick="location.reload()">Done</button></div><div class="payall-xt">' + esc(dn.text) + '</div>' + kolHint());
        }
      } catch (err) { log(esc(why(err)), "bad"); b.disabled = false; }
    }
    if ((b = e.target.closest("[data-payall-settle]"))) {
      var inp = box.querySelector("#payall-sig"), msg = box.querySelector(".payall-settle-msg");
      if (!inp.value.trim()) return inp.focus();
      b.disabled = true; msg.className = "payall-settle-msg muted"; msg.textContent = "Checking it on Solana…";
      var r = await api({ act: "payall-settle", sig: inp.value.trim() }); b.disabled = false;
      if (!r.ok) { msg.className = "payall-settle-msg bad"; msg.textContent = r.error || "Couldn't check that one."; return; }
      if (!r.paid && !r.burned) { msg.className = "payall-settle-msg bad"; msg.textContent = r.error === "already counted" ? "That transaction was already counted." : "That transaction didn't pay any prize still owed, so nothing changed."; return; }
      msg.className = "payall-settle-msg ok"; msg.textContent = r.paid + (r.paid === 1 ? " prize" : " prizes") + " marked paid" + (r.burned ? " and the burn recorded" : "") + ". Reloading…";
      setTimeout(function () { location.reload(); }, 1400);
    }
  });
  //MC 2026-10-10 the real reason, in words: Phantom's own message, or what Solana said
  //MC 2026-10-11 two accounts from the KOL list to add by hand when posting (never tagged automatically)
  function kolHint() {
    var k = (S.kols || []).slice(); if (!k.length) return "";
    for (var i = k.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = k[i]; k[i] = k[j]; k[j] = t; }
    return '<p class="muted" style="margin-top:6px">Tag by hand if it fits: <b>' + esc(k.slice(0, 2).join(" ")) + '</b></p>';
  }
  function why(err) {
    if (!err) return "Something went wrong.";
    if (err.code === 4001 || /reject|cancel/i.test(err.message || "")) return "Cancelled in Phantom. Nothing was sent.";
    var m = err.message || String(err);
    if (/insufficient|0x1\b/i.test(m)) m += " (the marketing wallet needs enough $SHY, plus a little SOL for fees and new token accounts)";
    return m + (err.code ? " [" + err.code + "]" : "");
  }
  // batches sent before and still on hold: settle them now, then post them like a normal run
  (async function () {
    var j = await api({ act: "payall-check" }).catch(function () { return null; });
    if (!j || !j.ok || !j.runs.length) return;
    var paid = j.runs.filter(function (r) { return r.state === "paid"; }), wait = j.runs.filter(function (r) { return r.state === "waiting"; }), gone = j.runs.filter(function (r) { return r.state !== "paid" && r.state !== "waiting"; });
    draw("");
    paid.forEach(function (r) { log("A batch sent earlier landed: " + r.paid + " paid. " + '<a href="https://solscan.io/tx/' + esc(r.sig) + '" target="_blank" rel="noopener">Solscan</a>', "ok"); });
    wait.forEach(function (r) { log("A batch is still waiting for Solana to confirm it. Those prizes stay off the list until it does. " + '<a href="https://solscan.io/tx/' + esc(r.sig) + '" target="_blank" rel="noopener">Solscan</a>'); });
    gone.forEach(function (r) { log("A batch sent earlier never landed on Solana, so nothing was paid and those prizes are back on the list.", "bad"); });
    if (paid.length) {
      var dn = await api({ act: "payall-done", sigs: paid.map(function (r) { return r.sig; }) });
      if (dn.ok && dn.text) out.insertAdjacentHTML("beforeend", '<div class="payall-act">' + (dn.tg ? '<span class="ok">Posted to Telegram.</span>' : "") + '<a class="payall-x" href="' + esc(dn.x) + '" target="_blank" rel="noopener">Post it on X</a></div><div class="payall-xt">' + esc(dn.text) + '</div>');
    }
  })();
})();
//MC 2026-10-09 Players search used to flip hidden on all 1,783 heavy rows on every key (1.5 to 2.4s each). Now it waits
//   150ms after the last key, shows at most 200 matches (Show all lifts that), and says so when nothing matches.
(function () {
  var q = document.getElementById("q"), t = document.getElementById("t");
  if (!q || !t) return;
  var rows = Array.prototype.slice.call(t.tBodies[0].rows), cap = +t.dataset.shown || 200, all = false, timer;
  var none = document.getElementById("q-none"), more = document.getElementById("q-more"), cnt = more && more.querySelector("[data-q-count]");
  function run() {
    var v = q.value.trim().toLowerCase(), hits = 0;
    rows.forEach(function (tr) { var ok = !v || tr.dataset.n.indexOf(v) >= 0; if (ok) hits++; var show = ok && (all || hits <= cap); if (tr.hidden === show) tr.hidden = !show; });
    if (none) none.hidden = hits > 0;
    if (more) { more.hidden = all || hits <= cap; if (cnt) cnt.textContent = "Showing the first " + cap + " of " + hits.toLocaleString("en-US") + (v ? " matches." : "."); }
  }
  q.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(run, 150); });
  //MC 2026-10-11 Enter searches every player on the server (the page holds 50 rows)
  q.addEventListener("keydown", function (e) { if (e.key === "Enter") { clearTimeout(timer); } });
  if (more) more.querySelector("[data-q-all]").addEventListener("click", function () { all = true; run(); });
  // row actions: build the forms the first time a row is opened
  var tpl = document.getElementById("pacts");
  t.addEventListener("toggle", function (e) {
    var d = e.target; if (!tpl || !d.open || d.dataset.built || !d.dataset.pid) return;
    d.dataset.built = "1";
    var frag = tpl.content.cloneNode(true), nm = d.dataset.name || "";
    frag.querySelectorAll('[data-f="pid"]').forEach(function (i) { i.value = d.dataset.pid; });
    frag.querySelectorAll('[data-f="name"]').forEach(function (i) { i.value = nm; });
    frag.querySelectorAll('[data-f="kb"]').forEach(function (i) { i.textContent = "Koban: " + (d.dataset.kb || "0"); });
    var mf = frag.querySelector('[data-f="motto-f"]');
    if (mf) { if (d.dataset.motto) mf.querySelector('[data-f="motto"]').textContent = "Motto: \u201c" + d.dataset.motto + "\u201d"; else mf.remove(); }
    frag.querySelectorAll("[data-confirm-t]").forEach(function (b) { b.setAttribute("data-confirm", b.getAttribute("data-confirm-t").replace("{n}", nm)); b.removeAttribute("data-confirm-t"); });
    if (d.closest(".ro")) frag.querySelectorAll("input,select,textarea,button").forEach(function (i) { if (i.type !== "hidden") i.disabled = true; });
    d.appendChild(frag);
  }, true);
})();
</script>
</body></html>
<?php
// point Telegram at the site (new token, or the bot needs new kinds of updates). null = nothing to do
function tg_rehook() {
    $c = tg_cfg();
    if ($c['token'] === '' || (($c['hook_for'] ?? '') === hash('sha256', $c['token']) && (int)($c['hook_v'] ?? 1) >= TG_HOOK_V)) return null;
    $secret = bin2hex(random_bytes(24));
    $url = 'https://' . preg_replace('/[^a-z0-9.\-:]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') . '/api/tgbot.php';
    if (!empty(shy_config()['tg_api'])) $url = 'http://' . $_SERVER['HTTP_HOST'] . '/api/tgbot.php';   // local testing
    $j = tg_api($c['token'], 'setWebhook', ['url' => $url, 'secret_token' => $secret, 'allowed_updates' => ['message', 'channel_post', 'my_chat_member', 'callback_query'], 'drop_pending_updates' => false]);
    $me = tg_api($c['token'], 'getMe', []);
    tg_commands($c['token']);
    with_lock(fn() => tg_locked(function () use ($j, $me, $secret) {   //MC 2026-10-11 also under tg-lock (see tg_locked)
        $c = tg_cfg();
        if (!empty($j['ok'])) { $c['hook_secret'] = $secret; $c['hook_for'] = hash('sha256', $c['token']); $c['hook_v'] = TG_HOOK_V; }
        if (!empty($me['result']['username'])) $c['bot'] = $me['result']['username'];
        save(TGCFG, $c);
    }));
    return $j;
}
function week_label($wk) {
    if (!preg_match('/^(\d{4})-(\d{2})$/', $wk, $m)) return $wk;
    $d = new DateTime(); $d->setISODate((int)$m[1], (int)$m[2]);
    return 'Week of ' . $d->format('M j, Y');
}
function rows_table($rows, $holders) {
    echo '<div class="tw"><table><thead><tr><th>#</th><th>Player</th><th>Points</th><th>Holder</th><th>Wallet</th></tr></thead><tbody>';
    foreach ($rows as $i => $r) {
        $w = wallet_of($r['pid'], $holders);
        echo '<tr><td>' . ($i + 1) . '</td><td><b>' . h($r['name']) . '</b></td><td>' . number_format($r['pts']) . '</td><td>' . ($r['holder'] ? '<i class="ok">' . (!empty($r['avatar']) ? '#' . h($r['avatar']) : 'Holder') . '</i>' : '') . '</td><td>' . ($w ? '<a href="https://solscan.io/account/' . h($w) . '" target="_blank" rel="noopener">' . h(short_w($w)) . '</a>' : '') . '</td></tr>';
    }
    if (!$rows) echo '<tr><td colspan="5" class="muted">No scores for this week.</td></tr>';
    echo '</tbody></table></div>';
}
function head_html($title) {
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . h($title) . '</title>';
    echo '<link rel="icon" href="../favicon.ico"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,700;12..96,800&family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet"><style>
:root{--bg:#0d0920;--bg2:#130d2c;--card:#1a1338;--card2:#211847;--line:rgba(255,255,255,.09);--line2:rgba(255,255,255,.16);--text:#f4f1ff;--muted:#a49cc9;--sun:#ffd166;--mint:#2ef0b0;--coral:#ff5d73;--violet:#8b5cf6;--seal:#b3261e;
  --grad:linear-gradient(120deg,#ff5d73,#ff9f43);--r:16px;--shadow:0 18px 40px -24px rgba(0,0,0,.9)}
*{box-sizing:border-box}html{-webkit-font-smoothing:antialiased}
body{margin:0;background:radial-gradient(60% 50% at 100% 0%,rgba(139,92,246,.13),transparent 70%),radial-gradient(50% 40% at 0% 100%,rgba(255,93,115,.08),transparent 70%),var(--bg);background-attachment:fixed;color:var(--text);font:14.5px/1.5 Inter,system-ui,sans-serif}
a{color:var(--sun)}code{font:500 12px "JetBrains Mono",monospace;color:#d8d0ff;word-break:break-all}
h1,h2,h3{font-family:"Bricolage Grotesque",Inter,sans-serif;letter-spacing:-.01em}
.seal{width:40px;height:40px;display:grid;place-items:center;border-radius:9px;background:var(--seal);color:#fff4e0;font:800 21px serif;transform:rotate(-4deg);box-shadow:0 10px 22px -8px rgba(179,38,30,.8);flex:none}
h2{font-size:19px;margin:34px 0 12px;display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}h2 small{color:var(--muted);font:500 13px Inter,sans-serif}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px}
.stat{position:relative;overflow:hidden;background:linear-gradient(160deg,var(--card2),var(--card));border:1px solid var(--line);border-radius:var(--r);padding:18px;box-shadow:var(--shadow)}
.stat::after{content:"";position:absolute;right:-30px;top:-30px;width:90px;height:90px;border-radius:50%;background:radial-gradient(closest-side,rgba(255,93,115,.18),transparent)}
.stat b{display:block;font:800 28px/1.15 "Bricolage Grotesque",sans-serif;font-variant-numeric:tabular-nums}.stat span{color:var(--muted);font-size:12.5px;font-weight:600}
.tw{overflow-x:auto;border:1px solid var(--line);border-radius:var(--r);background:var(--card);box-shadow:var(--shadow)}
table{width:100%;border-collapse:collapse;min-width:560px}th,td{text-align:left;padding:11px 14px;border-bottom:1px solid var(--line);vertical-align:top}
thead th{position:sticky;top:0;background:#1d1540;font:700 11px Inter,sans-serif;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
tbody tr:hover td{background:rgba(255,255,255,.025)}tr:last-child td{border-bottom:0}
td small{display:block;color:var(--muted);font-size:12px}td b{font-weight:700}
.idea{padding:20px 22px;border-radius:var(--r);background:linear-gradient(160deg,var(--card2),var(--card));border:1px solid var(--line);margin-bottom:12px;box-shadow:var(--shadow)}
.idea-top{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center}
.idea-text{margin:14px 0;font-size:15px;line-height:1.6}
.idea-en{margin:-4px 0 14px;padding:10px 14px;border-left:3px solid #4cc9f0;background:rgba(76,201,240,.08);border-radius:0 10px 10px 0}.idea-en small{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.06em}.idea-en p{margin:6px 0 0;font-size:15px;line-height:1.6}
.idea-meta{display:flex;flex-wrap:wrap;gap:14px;font-size:13px;margin-bottom:10px}
.idea-shot{max-width:320px;max-height:220px;border-radius:12px;border:1px solid var(--line2);display:block;margin:6px 0 10px}
.pill{display:inline-block;padding:3px 10px;border-radius:99px;font-size:11.5px;font-weight:800;background:rgba(255,255,255,.08);color:var(--muted)}
.pill.st-new{background:var(--coral);color:#fff}.pill.st-planned,.pill.st-building{background:var(--sun);color:#2d1806}.pill.st-shipped{background:var(--mint);color:#062a1e}.pill.st-reviewing{background:rgba(139,92,246,.3);color:#e3d8ff}.pill.pub{background:rgba(46,240,176,.14);color:var(--mint)}
.idea-form{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:12px}
.idea-form label{display:grid;gap:5px;font-size:12.5px;color:var(--muted)}.idea-form .wide{grid-column:1/-1}.idea-form .chk{display:flex;align-items:center;gap:8px;color:var(--text)}
.idea-form input:not([type=checkbox]),.idea-form textarea,.idea-form select{width:100%}
i.warn{font-style:normal;color:var(--sun);font-size:12px;font-weight:700}i.ok{font-style:normal;color:var(--mint);font-size:12px;font-weight:700}i.bad{font-style:normal;color:var(--coral);font-weight:700}
.muted{color:var(--muted)}
.flash{display:flex;align-items:center;gap:10px;background:rgba(46,240,176,.08);border:1px solid rgba(46,240,176,.3);padding:12px 16px;border-radius:14px;font-weight:600}
.flash::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--mint);flex:none;box-shadow:0 0 10px var(--mint)}
.flash.bad{background:rgba(255,93,115,.1);border-color:rgba(255,93,115,.4)}.flash.bad::before{background:var(--coral,#ff5d73);box-shadow:0 0 10px #ff5d73}
.bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;align-items:center}
.mailset{display:grid;gap:14px;margin-bottom:14px}.mailset label{display:grid;gap:6px;font-weight:600}.mailset input[type=text]{max-width:640px}
.mailtypes{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:8px}
.chk.mt{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.03);font-weight:500}
.chk.mt span{display:grid;gap:2px}.chk.mt small{color:var(--muted);font-size:12.5px;line-height:1.4}.chk.mt input{margin-top:3px}
.btnl{display:inline-block;padding:9px 14px;border-radius:999px;border:1px solid var(--line);font-weight:700;font-size:13px;text-decoration:none}

.award{padding:16px 18px;border:1px solid rgba(242,195,91,.35);border-radius:14px;background:rgba(242,195,91,.05);margin:0 0 22px}.award h2{margin-top:0}.award-q{display:inline-flex;flex-wrap:wrap;gap:4px}.award-q button{padding:6px 10px;font-size:12px}.award-row{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:8px}
.tg-status{display:grid;gap:4px;padding:18px 20px;border-radius:18px;margin-bottom:18px;background:rgba(255,93,115,.08);border:1px solid rgba(255,93,115,.35)}.tg-status.on{background:rgba(46,240,176,.08);border-color:rgba(46,240,176,.35)}.tg-status span{color:var(--muted);font-size:13.5px}
.tg-steps{margin:0 0 22px 20px;display:grid;gap:10px;line-height:1.55}.tg-steps code{background:rgba(255,255,255,.08);padding:1px 6px;border-radius:6px}
.fun{display:grid;gap:8px;margin:6px 0 18px}.fun-r{display:grid;grid-template-columns:200px 1fr 70px 230px;gap:12px;align-items:center}.fun-l{font-weight:700}.fun-bar{height:14px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden}.fun-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--coral),var(--sun))}.fun-r b{text-align:right;font-variant-numeric:tabular-nums}.fun-r small{color:var(--muted)}
h2 small a{margin-left:8px;font-weight:600}h2 small a.on{color:var(--sun);text-decoration:underline}
@media (max-width:820px){.fun-r{grid-template-columns:1fr 60px;}.fun-bar{grid-column:1/-1;grid-row:2}.fun-r small{grid-column:1/-1}}
.pt-box{border:1px solid var(--line);border-radius:14px;padding:14px 16px;margin:10px 0;display:grid;gap:10px}
/*MC 2026-10-09 display:grid beat the hidden attribute, so the partner fields showed even for Open to everyone */
.pt-box[hidden]{display:none}.pt-box legend{font-weight:800;padding:0 6px}
.tg-found{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px}.tg-found small{opacity:.6;margin-left:6px}
.tg-found .tg-pick{display:flex;gap:4px;flex-wrap:wrap}
.tg-form .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}.tg-form label{display:grid;gap:5px;font-size:12.5px;color:var(--muted)}
.tg-kinds{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px}.tg-kind{display:flex!important;gap:10px;align-items:flex-start;padding:12px 14px;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.03);cursor:pointer}.tg-kind b{display:block;color:var(--text);font-size:14px}.tg-kind small{color:var(--muted);font-size:12.5px;line-height:1.4}.tg-kind input{margin-top:3px}
@media (max-width:760px){.tg-form .grid2,.tg-kinds{grid-template-columns:1fr}}
input,select,textarea,button,.btn{font:inherit;font-size:14px;border-radius:11px;border:1px solid var(--line2);background:rgba(0,0,0,.28);color:var(--text);padding:9px 13px;transition:border-color .15s,background .15s,transform .1s}
input:focus,select:focus,textarea:focus{outline:0;border-color:var(--coral);box-shadow:0 0 0 3px rgba(255,93,115,.15)}
input[type=search]{flex:1 1 220px}input[type=checkbox]{accent-color:var(--coral);width:16px;height:16px}
button,.btn{cursor:pointer;background:linear-gradient(160deg,#2c2266,#231a52);border-color:rgba(255,255,255,.14);font-weight:700;text-decoration:none;display:inline-block;color:#fff}
button:hover,.btn:hover{border-color:rgba(255,255,255,.3)}button:active{transform:scale(.98)}
.btn.sm{padding:6px 11px;font-size:13px}.btn.ghost,button.ghost{background:transparent}
button.danger{background:rgba(255,93,115,.12);border-color:rgba(255,93,115,.4);color:#ffb3bd}button.danger:hover{background:rgba(255,93,115,.22)}
.acts{white-space:normal;min-width:280px}.acts form{display:inline-flex;gap:6px;margin:6px 6px 0 0;flex-wrap:wrap}.acts form input{width:160px}
/*MC 2026-10-09 Players: W / G and Live broke mid-value on desktop ("300 / / 500"), and the award box sat flush on the Names to review table */
#t td:nth-child(4),#t td:nth-child(5),#t td:nth-child(7){white-space:nowrap}.tw+.award{margin-top:22px}#q-more[hidden]{display:none}#q-more{margin-top:12px}
@media (max-width:760px){
  /*MC 2026-10-09 phones: each player is a card now. Opening the actions used to scroll the 777px table sideways so you could not see whose row it was */
  #t{min-width:0}#t thead{display:none}
  #t tbody tr{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 10px;padding:12px 14px 12px 58px;border-bottom:1px solid var(--line)}#t tbody tr[hidden]{display:none}
  #t td{padding:0;border:0}#t tbody tr:hover td{background:none}#t td:first-child{flex:0 0 34px;margin-left:-44px;color:var(--muted)}#t td:nth-child(2){flex:1 1 0;min-width:0}#t td:nth-child(3){flex:none;font-weight:700;text-align:right}
  #t tbody tr::before{content:"";flex-basis:100%;order:1}#t td:nth-child(n+4){order:2}#t td:nth-child(4),#t td:nth-child(5),#t td:nth-child(6),#t td:nth-child(7){font-size:12px;color:var(--muted)}#t td:empty{display:none}
  #t td:nth-child(4)::before{content:"W/G "}#t td:nth-child(5)::before{content:"Live "}#t td:nth-child(7)::before{content:"Joined "}
  #t td.acts{flex:1 1 100%;min-width:0}#t .acts form{display:flex;width:100%}#t .acts form input:not([type=hidden]){flex:1 1 140px;width:auto!important;min-width:0}#t .acts form small{flex-basis:100%}
  /*MC 2026-10-09 the Award Koban fields had fixed inline widths (240, 120, 220) and ragged edges on phones */
  .award-f input:not([type=hidden]){flex:1 1 100%;min-width:0!important;width:100%!important}
  /*MC 2026-10-11 Names to review: the Rename button was cut off at the edge of the card; each name now sits above its form */
  .review,.review tbody{display:block;min-width:0!important;width:100%}.review tr{display:block;padding:10px 12px;border-bottom:1px solid var(--line)}.review td{display:block;padding:0;border:0}.review td.acts{min-width:0;margin-top:6px}
  .review .acts form{display:flex;width:100%}.review .acts form input:not([type=hidden]){flex:1 1 120px;width:auto;min-width:0}
}
details summary{cursor:pointer;color:var(--sun);font-weight:700;font-size:13px;list-style:none}details summary::-webkit-details-marker{display:none}details summary::before{content:"\25B8";display:inline-block;margin-right:6px;transition:transform .15s}details[open]>summary::before{transform:rotate(90deg)}
.facts{list-style:none;padding:0;margin:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px}.facts li{padding:12px 14px;border-radius:12px;background:var(--card);border:1px solid var(--line)}
pre.log{background:#0a0619;border:1px solid var(--line);border-radius:14px;padding:14px;font:500 12px/1.6 "JetBrains Mono",monospace;overflow-x:auto;max-height:340px;white-space:pre-wrap;word-break:break-all}
.login{max-width:380px;margin:14vh auto;padding:32px;background:linear-gradient(160deg,var(--card2),var(--card));border:1px solid var(--line2);border-radius:24px;box-shadow:0 40px 80px -30px #000;text-align:center}
.login .seal{margin:0 auto 14px;width:52px;height:52px;font-size:28px}
.login h1{margin:0 0 4px;font-size:26px}.login input{width:100%;margin:0}.login button{width:100%;background:var(--grad);color:#fff;border:0;padding:12px;margin-top:6px}
.login .lf{display:grid;gap:6px;text-align:left;margin:14px 0 4px;font-size:12.5px;color:var(--muted)}.login .small{font-size:12px;margin-top:14px}
/* team and account */
.artbk{align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 10px}.artbk .muted{flex:1;min-width:240px;font-size:13px}.artmiss{display:block;font-weight:500;line-height:1.5}.artmiss .bar{margin-top:10px}.viewonly{display:flex;gap:10px;align-items:center;padding:12px 16px;border-radius:14px;margin-bottom:16px;background:rgba(255,209,102,.08);border:1px solid rgba(255,209,102,.35);font-weight:600;font-size:14px}
.viewonly::before{content:"";width:8px;height:8px;border-radius:50%;background:#ffd166;flex:none}
/*MC 2026-10-09 .viewonly{display:flex} came after .artmiss{display:block}, so the missing-images banner put its dot beside the whole paragraph */
.viewonly.artmiss{display:block;position:relative;padding-left:32px}.viewonly.artmiss::before{position:absolute;left:15px;top:19px}
.ro form button:disabled,.ro form input:disabled,.ro form select:disabled,.ro form textarea:disabled,.ro button.send:disabled{opacity:.45;cursor:not-allowed}
.av{width:32px;height:32px;border-radius:50%;display:grid;place-items:center;flex:none;background:linear-gradient(135deg,#ff5d73,#8b5cf6);color:#fff;font:800 14px Bricolage Grotesque,Inter,sans-serif}
.team .who{display:flex;align-items:center;gap:10px}.team .who b{display:block}.team .who small{color:var(--muted);font-size:12px}
.role{display:inline-block;font:700 11px Inter,sans-serif;letter-spacing:.06em;text-transform:uppercase;padding:4px 9px;border-radius:999px;border:1px solid var(--line2);white-space:nowrap}
.r-owner{background:rgba(255,209,102,.14);border-color:rgba(255,209,102,.5);color:#ffd166}.r-admin{background:rgba(255,93,115,.12);border-color:rgba(255,93,115,.45);color:#ff8fa0}
.r-moderator{background:rgba(46,240,176,.1);border-color:rgba(46,240,176,.4);color:#7ff2c9}.r-support{background:rgba(76,201,240,.1);border-color:rgba(76,201,240,.4);color:#8fdcf5}
.r-treasurer{background:rgba(255,159,67,.12);border-color:rgba(255,159,67,.45);color:#ffbf85}.r-viewer,.r-custom{color:var(--muted)}
.pill{font:700 11.5px Inter,sans-serif;padding:3px 9px;border-radius:999px}.pill.on{background:rgba(46,240,176,.12);color:#7ff2c9}.pill.off{background:rgba(255,255,255,.06);color:var(--muted)}.pill.warn{background:rgba(255,209,102,.12);color:#ffd166}
.small{font-size:12.5px}
/*MC 2026-10-09 dates, times and sizes in tables stay on one line */
.nw{white-space:nowrap}
.btnish{display:inline-block;cursor:pointer;list-style:none;font:700 13px Inter,sans-serif;padding:8px 14px;border-radius:10px;border:1px solid var(--line2);background:rgba(255,255,255,.04)}
.btnish::-webkit-details-marker{display:none}.btnish.primary{background:var(--grad);border:0;color:#fff}
/*MC 2026-10-09 was .tw:has(table.team). :has() on every .tw made the 1,783-row Players table re-check style while it parsed, so the Team wrapper gets its own class now */
.tw.tw-team{overflow:visible}.tedit form.tform{display:grid;flex-wrap:nowrap}.tedit .tehead{display:flex;align-items:center;justify-content:space-between;gap:10px}.tedit .tclose{padding:6px 12px;font-size:13px}
.tedit[open]{position:relative}.tedit .tform{position:absolute;right:0;top:calc(100% + 8px);z-index:20;width:min(620px,86vw);text-align:left}
.tform{display:grid;gap:12px;margin-top:12px;padding:18px;border-radius:18px;background:var(--card2,#1b1340);border:1px solid var(--line2);box-shadow:0 30px 60px -30px #000}
.tform label{display:grid;gap:5px;font-size:12.5px;color:var(--muted)}.tform label.chk{display:flex;align-items:center;gap:8px;color:var(--text)}
.grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}ul.plain{list-style:none;padding:0;margin:0;display:grid;gap:6px;font-size:13.5px}.grid2>*{min-width:0}@media (max-width:760px){.grid2{grid-template-columns:1fr}}.grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.tform input:not([type=radio]):not([type=checkbox]):not([type=hidden]),.tform select,.tedit form.tform input[name]:not([type=radio]):not([type=checkbox]){width:100%;max-width:none;min-width:0;box-sizing:border-box}.tform h2{margin:6px 0 0}.tform h2+*{margin-top:0}
.tform.acct{max-width:780px;margin:0 0 28px;padding:24px}.tform.acct h2:not(:first-of-type){margin-top:14px;padding-top:18px;border-top:1px solid var(--line)}
.addbox{margin:18px 0 6px}
.pgrid{display:grid;gap:6px}
.prow{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;padding:9px 12px;border-radius:12px;background:rgba(255,255,255,.03);border:1px solid var(--line)}
.prow b{display:block;font-size:13.5px;color:var(--text)}.prow small{color:var(--muted);font-size:11.5px;line-height:1.35}
.pseg{display:inline-flex;padding:3px;border-radius:999px;background:rgba(0,0,0,.25);border:1px solid var(--line)}
.pseg label{display:block!important;cursor:pointer}.pseg input{position:absolute;opacity:0;pointer-events:none}
.pseg span{display:block;font:700 12px Inter,sans-serif;padding:5px 11px;border-radius:999px;color:var(--muted);white-space:nowrap}
.pseg input:checked+span{background:#fff;color:#1a1340}.pseg input[value="0"]:checked+span{background:rgba(255,255,255,.14);color:var(--text)}
.pseg input:focus-visible+span{outline:2px solid #ff5d73}
.pseg label.dis span{opacity:.3;cursor:not-allowed}
.pwrap[data-preset] .pseg{opacity:.7}
.matrix td.lv{text-align:center;font:700 12px Inter,sans-serif}.matrix td.l2{color:#7ff2c9}.matrix td.l1{color:#ffd166}.matrix td.l0{color:var(--muted)}
.matrix th{text-align:center}.matrix .rdesc td{vertical-align:top;color:var(--muted);font-size:11.5px;line-height:1.4}
.reveal{padding:18px 20px;border-radius:18px;margin-bottom:18px;background:rgba(46,240,176,.07);border:1px solid rgba(46,240,176,.35)}
.reveal .hashline{display:flex;gap:10px;align-items:center;margin-top:10px}.reveal code#tmp-pw{font-size:20px;letter-spacing:.06em;padding:8px 14px}
.acct{position:static;box-shadow:none;max-width:760px}
.danger{color:#ff8fa0!important;border-color:rgba(255,93,115,.45)!important}
@media (max-width:760px){.grid2,.grid3{grid-template-columns:1fr}.prow{grid-template-columns:1fr}}
.err{color:var(--coral);font-weight:600}
.settings{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;background:linear-gradient(160deg,var(--card2),var(--card));border:1px solid var(--line);border-radius:var(--r);padding:20px;box-shadow:var(--shadow)}
.settings label{display:grid;gap:5px;font-size:13px;color:var(--muted)}.settings label small{font-size:11.5px}
.settings .chk{display:flex;align-items:center;gap:8px;color:var(--text)}.settings button{align-self:end;background:var(--grad);color:#fff;border:0}
button.send{background:linear-gradient(120deg,#2ef0b0,#4cc9f0);color:#06221a;border:0}
/*MC 2026-10-10 Pay everything owed */
.payall{border:1px solid rgba(46,240,176,.35);background:linear-gradient(135deg,rgba(46,240,176,.08),rgba(76,201,240,.05));border-radius:var(--r);padding:16px;margin:10px 0 18px}
.payall-hd{display:flex;gap:16px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap}.payall-hd>div{flex:1 1 320px}.payall-hd p{margin:4px 0 0;font-size:13px}
.payall-out{margin-top:14px}.payall-out table{width:100%}table.payall-t{min-width:0}.payall-t td:nth-child(n+2),.payall-t th:nth-child(n+2){text-align:right;white-space:nowrap}.payall-out .tot td{font-weight:800;border-top:2px solid var(--line)}
.payall-skip{margin:8px 0 0;padding:0;list-style:none;font-size:13px}.payall-skip li{padding:3px 0;color:var(--muted)}.payall-skip li b{color:#ffd166}
.payall-act{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px}
/*MC 2026-10-10 settle by transaction, held batches*/
.payall-settle{margin-top:12px;font-size:13px}.payall-settle summary{cursor:pointer;color:var(--muted)}.payall-settle input{flex:1 1 260px;min-width:0}.payall-settle-msg{margin:6px 0 0}.payall-settle-msg.ok{color:#7ff7cf}.payall-settle-msg.bad{color:#ff8a9a}
.payall-skip li.held b{color:#4cc9f0}
/*MC 2026-10-10 Fair Play*/
.fp-top{display:grid;gap:12px;margin:0 0 8px}.fp-top p{margin:0 0 6px;max-width:80ch}
.fp-set{display:grid;gap:10px;justify-items:start;padding:14px 16px;border:1px solid var(--line);border-radius:var(--r);background:rgba(255,255,255,.03)}.fp-set label{font-weight:600;display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center}.fp-set label small{font-weight:400}.fp-set p{margin:0;font-size:13px}.fp-set-h{font-size:15px}.fp-set label.fp-cb{display:grid;grid-template-columns:auto 1fr;align-items:start}.fp-cb small{display:block}.fp-cb input{margin-top:3px}input.fp-n{width:70px}
table.fp-t{min-width:0}.fp-t td{vertical-align:top}.fp-t small{display:block;color:var(--muted)}
.fp-why{margin:0;padding-left:16px;font-size:13px}.fp-why li{margin:2px 0}
tr.fp-hot td{background:rgba(255,92,92,.08)}tr.fp-bot td{color:var(--muted)}
.fp-k{display:inline-block;min-width:22px;padding:1px 6px;border-radius:6px;background:rgba(76,201,240,.15);color:#9fe3ff;font-weight:800;text-align:center;font-size:12px}
.fp-m{border:1px solid var(--line);border-radius:var(--r);padding:10px 12px;margin:10px 0}.fp-m header{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:6px}.fp-m header form{margin-left:auto}
.fp-m.struck{opacity:.6}.fp-who{padding:10px 12px;border-radius:10px;background:rgba(255,255,255,.04);margin:6px 0;line-height:1.7}
a.btnl{white-space:nowrap}
@media (max-width:760px){table.fp-cards thead{display:none}table.fp-cards,table.fp-cards tbody,table.fp-cards tr,table.fp-cards td{display:block;width:100%}table.fp-cards tr{border-bottom:1px solid var(--line);padding:8px 0}table.fp-cards td{border:0;padding:3px 12px;display:flex;gap:10px}table.fp-cards td[data-l]::before{content:attr(data-l);flex:0 0 110px;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em}table.fp-cards td small{display:inline;margin-left:6px}table.fp-cards td:empty{display:none}}
.payall-log{margin:10px 0 0;padding:0;list-style:none;font-size:13px}.payall-log li{padding:4px 0}.payall-log .ok{color:#7ff7cf}.payall-log .bad{color:#ff8a9a}
.payall-x{display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:999px;background:#000;color:#fff;font-weight:700;text-decoration:none;border:1px solid #333}
.payall-xt{white-space:pre-wrap;font-size:13px;background:rgba(0,0,0,.25);border-radius:10px;padding:10px 12px;margin:8px 0 0}
details{margin:8px 0}details>summary{padding:6px 0}
/* guide */
.g-tabs{position:sticky;top:0;z-index:3;display:flex;flex-wrap:wrap;gap:6px;padding:10px 0 14px;background:linear-gradient(180deg,var(--bg) 82%,transparent)}
.g-tabs button{flex:none;border-radius:999px;background:rgba(255,255,255,.04);color:var(--muted);padding:9px 15px;font-size:13.5px}
.g-tabs button.on{background:#fff;color:#1a1338;border-color:#fff}
.g-head h2{font-size:26px;margin:8px 0 4px}.g-head p{margin:0 0 18px;color:var(--muted)}
.g-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:14px}
.g-card{padding:22px 24px;border-radius:var(--r);background:linear-gradient(160deg,var(--card2),var(--card));border:1px solid var(--line);box-shadow:var(--shadow)}
.g-card h3{margin:0 0 10px;font-size:18px}.g-card p{margin:0 0 10px;color:#d9d3f2}.g-card p:last-child{margin-bottom:0}
.g-card p.g-step{padding-left:4px;border-left:2px solid rgba(255,93,115,.5);padding-left:12px}
.g-card b{color:#fff}
.g-tool{border-color:rgba(255,209,102,.35)}.g-tool .bar{margin:14px 0 0}.g-tool input{flex:1 1 180px}
.hashline{padding:18px 20px;border-radius:var(--r);border:1px solid rgba(255,209,102,.5);background:rgba(255,209,102,.08);margin-bottom:18px}.hashline p{margin:4px 0 10px;color:var(--muted)}.hashline code{display:block;padding:12px;border-radius:10px;background:#0a0619;margin-bottom:10px;font-size:12.5px}
/*MC 2026-10-09 the global code{word-break:break-all} split prompt words in half ("throu / gh"). Prompts wrap at spaces now */
code[id^="mj-"]{word-break:normal;overflow-wrap:anywhere}
@media (max-width:980px){
  /*MC 2026-10-13 the phone/iPad frame moved to the shell rules at the end of this file; the rest here is per page */
  table.team{min-width:720px}table.matrix{min-width:640px}
  /*MC 2026-10-09 Team on iPad portrait pushed the page sideways (table min-width 720 plus the overflow:visible wrapper and an absolute Edit popover). The phone setup now starts at 980: scrolling wrapper, full screen editor */
  table.team th,table.team .pill{white-space:nowrap}.tw.tw-team{overflow-x:auto}.tedit .tform{position:fixed;inset:0;z-index:60;width:auto;margin:0;border-radius:0;overflow-y:auto;align-content:start;padding-bottom:calc(24px + env(safe-area-inset-bottom,0px))}
  .g-cards{grid-template-columns:1fr}.g-tabs{top:58px;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}.g-tabs::-webkit-scrollbar{display:none}
  .idea-form{grid-template-columns:1fr}
}

/* card art */
.shop-live{justify-content:space-between;align-items:center;margin:0 0 10px}/*MC 2026-10-15 Sales: the six totals three a row (two on phones); What Koban buys as ranked bars*/#shop-stats .grid{grid-template-columns:repeat(3,minmax(0,1fr))}@media (max-width:560px){#shop-stats .grid{grid-template-columns:repeat(2,minmax(0,1fr))}}#shop-stats>p{margin:10px 0 22px}#koban-flow{margin-top:26px}.ew-steps{margin:6px 0 14px;padding-left:22px;display:grid;gap:6px;line-height:1.5}.kbuy{list-style:none;margin:8px 0 0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:6px 18px}.kbuy li{position:relative;display:flex;justify-content:space-between;gap:12px;padding:8px 12px;border-radius:10px;background:var(--card);border:1px solid var(--line);overflow:hidden;font-size:14px}.kbuy li span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;position:relative}.kbuy li b{position:relative;font-variant-numeric:tabular-nums}.kbuy li i{position:absolute;left:0;top:0;bottom:0;background:rgba(255,190,90,.10);pointer-events:none}.artcard[hidden]{display:none!important}.artfilter{flex-wrap:wrap;margin:6px 0 14px}.artfilter .on{background:rgba(255,255,255,.12);color:#fff}
.artfind{margin-left:auto;width:200px;max-width:100%}
.artimg{position:relative}.artno{position:absolute;left:8px;top:8px;z-index:1;padding:3px 9px;border-radius:99px;background:rgba(10,8,20,.82);color:#fff;font:800 12.5px/1.2 Inter,system-ui,sans-serif;letter-spacing:.02em;box-shadow:0 2px 8px rgba(0,0,0,.35)}
.artno.inl{position:static;display:inline-block;vertical-align:middle;font-size:15px;background:var(--card2,rgba(255,255,255,.1))}
.artgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px}
/*MC 2026-10-14 hype posts for X: ten option cards, each with the card art it talks about, the post text and the buttons */
.mkt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px;margin:10px 0 18px}
.mkt-c{display:flex;flex-direction:column;gap:10px;border:1px solid var(--line);border-radius:14px;background:var(--card);padding:14px}
.mkt-cards{display:flex;flex-direction:column;gap:10px}
.mkt-cards a{display:block;border-radius:10px;overflow:hidden;border:1px solid var(--line);box-shadow:0 10px 24px -14px rgba(0,0,0,.8);transition:border-color .2s}
.mkt-cards a:hover{border-color:rgba(255,255,255,.4)}
.mkt-cards img{display:block;width:100%;aspect-ratio:1200/630;background:#efe3c8}
.mkt-t{margin:0;white-space:pre-wrap;word-break:break-word;font:500 13.5px/1.5 Inter,system-ui,sans-serif;color:var(--text);background:rgba(255,255,255,.04);border:1px solid var(--line);border-radius:10px;padding:10px 12px;flex:1}
.mkt-b{display:flex;align-items:center;gap:10px}
.mkt-b small{margin-left:auto}
@media (max-width:560px){.mkt-grid{grid-template-columns:1fr}.mkt-cards img{width:76px}}
/*MC 2026-10-13 bot masks: image left, name, wearers, the Midjourney prompt and the upload row right */
.maskgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:12px;margin:10px 0 4px}
.maskcard{display:flex;gap:14px;align-items:flex-start;border:1px solid var(--line);border-radius:14px;background:var(--card);padding:14px}
.mask-im{flex:0 0 auto;width:96px;height:96px;border-radius:12px;overflow:hidden;background:#120c2c;border:1px solid var(--line)}
.mask-im img{width:100%;height:100%;object-fit:cover;display:block}
.mask-t{flex:1;min-width:0}
.mask-t .pill{margin-left:6px}
.mask-t p{margin:4px 0 8px}
.mask-prompt{display:block;font-size:11.5px;line-height:1.5;padding:8px 10px;border-radius:8px;background:rgba(0,0,0,.25);border:1px solid var(--line);margin:0 0 10px;word-break:break-word;max-height:76px;overflow:auto}
.maskcard .bar{flex-wrap:wrap}
.maskcard input[type=file]{max-width:220px;font-size:12px}
@media (max-width:560px){.maskgrid{grid-template-columns:1fr}.maskcard{flex-direction:column}.mask-im{width:120px;height:120px}}
.artcard{display:flex;flex-direction:column;border-radius:14px;overflow:hidden;border:1px solid var(--line);background:var(--card);text-decoration:none;color:inherit;transition:transform .15s,border-color .15s}
.artcard:hover{transform:translateY(-2px);border-color:var(--line2)}
.artimg{display:block;aspect-ratio:13/8;background:#120c2c;overflow:hidden}.artimg img{width:100%;height:100%;object-fit:cover;display:block}
.artmeta{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 11px;font-size:13px}.artmeta b{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.artmeta b{flex:1 1 auto}.artmeta .pill{flex:none;white-space:nowrap;line-height:1.35}
/*MC 2026-10-09 on phones the status pill took half the tile and every name ended in "...". Name gets its own line there */
@media (max-width:560px){.artmeta{flex-wrap:wrap;gap:4px}.artmeta b{white-space:normal;flex-basis:100%}}
.artcard[data-st=new]{border-color:rgba(46,240,176,.3)}.artcard[data-st=draft]{border-color:rgba(255,209,102,.35)}
.artdetail{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);gap:28px;align-items:start}
.pv-big{position:relative;aspect-ratio:13/8;border-radius:18px;overflow:hidden;background:#120c2c;box-shadow:0 20px 50px -25px #000;border:2px solid rgba(255,255,255,.12)}
.pv-big img{width:100%;height:100%;object-fit:cover;display:block}
.pv-name{position:absolute;left:0;right:0;bottom:0;padding:22px 16px 12px;font-weight:800;font-size:18px;background:linear-gradient(transparent,rgba(10,6,25,.85))}
.pv-row{display:flex;gap:16px;flex-wrap:wrap;margin:16px 0 8px;align-items:flex-end}.pv-row figure{margin:0;display:grid;gap:6px;justify-items:start}.pv-row figcaption{font-size:12px;color:var(--muted)}
.pv-hand{width:150px;border-radius:16px;overflow:hidden;background:#241b55;display:flex;flex-direction:column}.pv-hand b{padding:8px 10px;font-size:12.5px}
.pv-hand .pv-art{display:block;aspect-ratio:260/150;overflow:hidden}.pv-hand img,.pv-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.pv-phone{width:132px}.pv-phone .pv-art{aspect-ratio:auto;height:58px}
.pv-thumb{width:44px;height:44px;border-radius:10px;overflow:hidden}
.focus{position:relative;border-radius:12px;overflow:hidden;cursor:crosshair;background:#0a0619;line-height:0}.focus img{width:100%;height:auto;display:block}
.focus .dot{position:absolute;width:18px;height:18px;margin:-9px 0 0 -9px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 2px rgba(0,0,0,.6);pointer-events:none}
.focus .frame{position:absolute;border:2px dashed rgba(255,255,255,.9);box-shadow:0 0 0 9999px rgba(10,6,25,.55);pointer-events:none}
.upbox{margin-top:0}
@media (max-width:980px){.artdetail{grid-template-columns:minmax(0,1fr)}.artgrid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr))}}
/* two-step sign-in */
.tfa-setup{display:grid;grid-template-columns:200px minmax(0,1fr);gap:20px;align-items:start;padding:18px;border-radius:18px;background:var(--card);border:1px solid var(--line)}
.tfa-qr{width:200px;height:200px;padding:10px;border-radius:14px;background:#fff}.tfa-qr svg{width:100%;height:100%;display:block}
.tfa-key{font-size:14px;letter-spacing:.06em;word-break:break-all}
code.rc{white-space:pre;font-size:15px;line-height:1.8;letter-spacing:.05em}
.linkish{background:none;border:0;padding:0;color:var(--gold,#f2c35b);text-decoration:underline;font:inherit;cursor:pointer}
@media (max-width:700px){.tfa-setup{grid-template-columns:1fr}.tfa-qr{margin:0 auto}}
/* tournaments */
.grid4{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}
.tcard{margin:14px 0;padding:16px 18px;border-radius:18px;background:var(--card);border:1px solid var(--line)}
.tc-head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap}.tc-head h2{margin:0 0 4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.tc-places{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0 0;padding:0;list-style:none;counter-reset:pl}.tc-places li{counter-increment:pl;padding:8px 12px;border-radius:12px;background:rgba(255,255,255,.05)}.tc-places li::before{content:"#" counter(pl) " ";color:var(--muted)}.tc-places small{display:block;color:var(--muted)}
.tc-rounds{display:flex;gap:14px;overflow-x:auto;margin-top:12px;padding-bottom:4px}.tc-round{display:grid;gap:8px;align-content:start;min-width:170px}
.tc-table{display:grid;gap:3px;padding:9px 11px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid var(--line);font-size:13px}.tc-table small{color:var(--muted);font-size:11px}
.tc-table.done{opacity:.85}.tc-table .win{font-weight:800;color:var(--mint,#2ef0b0)}
@media (max-width:760px){.grid4{grid-template-columns:repeat(2,minmax(0,1fr))}}
/* extra */
/*MC 2026-10-11 section chips on the long pages, and the plain-words summary at the top */
.page main [hidden]{display:none!important}
.glance{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin:0 0 6px}
.glance div{padding:14px 16px;border-radius:14px;border:1px solid var(--line);background:rgba(255,255,255,.03)}
.glance b{display:block;font-size:22px;line-height:1.15;font-variant-numeric:tabular-nums}.glance span{display:block;font-size:13px;color:var(--muted);margin-top:3px}
.glance div.warn{border-color:rgba(255,209,102,.5);background:rgba(255,209,102,.07)}.glance div.ok b{color:#7ff7cf}
.glance div.bad{border-color:rgba(255,92,92,.5);background:rgba(255,92,92,.07)}
/*MC 2026-10-11 two cards a row on a phone: one a row filled the whole first screen before any section */
@media (max-width:560px){.glance{grid-template-columns:1fr 1fr;gap:8px}.glance div{padding:11px 12px}.glance b{font-size:18px}.glance span{font-size:12px;line-height:1.35}.glance div:last-child:nth-child(odd){grid-column:1/-1}}
fieldset.fs{border:1px solid var(--line);border-radius:14px;padding:12px 14px 14px;margin:0 0 12px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}
form.settings fieldset.fs{grid-column:1/-1}fieldset.fs legend{font-weight:800;padding:0 6px}fieldset.fs p.fs-d{grid-column:1/-1;margin:-4px 0 0;font-size:13px;color:var(--muted)}
table.ranks td,table.ranks th{white-space:nowrap}table.ranks input{width:120px}

/*MC 2026-10-12 Telegram Messages sent, pin choices, and Fix a final week */
.tg-pins{display:flex;flex-wrap:wrap;gap:6px 16px;margin:4px 0}
.tg-pins-h{margin:18px 0 4px;font-size:15px}
table.tg-posts td{vertical-align:top}
table.tg-posts tr.gone td{opacity:.55}
.tg-txt div{white-space:pre-line;max-width:520px;font-size:13px;line-height:1.4}
.tg-txt .pill{margin-top:6px;display:inline-block}
.tg-edit{margin-top:6px}.tg-edit summary{cursor:pointer;color:var(--accent,#7ff7cf);font-weight:700;font-size:13px}
.tg-edit textarea{width:100%;min-width:260px;font:13px/1.45 ui-monospace,monospace;margin:6px 0}
.tg-acts form.inl{display:inline-block;margin:0 4px 4px 0}
.tg-linkf{margin-top:12px;align-items:flex-end;flex-wrap:wrap}.tg-linkf label{flex:1 1 280px}
.lgfix{border:1px solid var(--line);border-radius:14px;padding:14px 16px;margin:12px 0}
.lgfix h3{margin:0 0 8px;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.lgfix td small{display:block;color:var(--muted);font-size:12px}
.lgfix-f,.lgfix-post{margin-top:10px}.lgfix-post .chk{display:block;margin:4px 0}
@media (max-width:640px){.tg-txt div{max-width:none}.tg-acts{white-space:normal}}

/*MC 2026-10-12 Shop prices */
.fp-why{margin:0;padding-left:16px;font-size:13px;line-height:1.4}
.sp-top{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:flex-end;margin:6px 0 10px}
.sp-all{font-weight:800}.sp-all input{width:90px;font-size:18px;font-weight:800}
.sp-form label span{display:inline-flex;align-items:center;gap:4px}
.sp-grp{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;margin:6px 0}
.sp-grp > b{flex:0 0 100%;font-size:13px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
.sp-grp label{display:flex;align-items:center;gap:6px;font-size:13px}
.sp-grp label small{color:var(--muted)}
.sp-grp input{width:72px;padding:6px 8px}
.sp-kinds label{background:rgba(255,255,255,.03);border:1px solid var(--line);border-radius:10px;padding:5px 8px}
.sp-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:12px 0 8px}.sp-bar input{flex:1 1 200px}
.sp-sum{font-weight:700;color:#ffd166}
.sp-tw{max-height:560px;overflow:auto}
.sp-tbl td.num,.sp-tbl th.num{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.sp-tbl .sp-new{font-weight:800}.sp-tbl .sp-new.up{color:#ff8a8a}.sp-tbl .sp-new.dn{color:#7ff7cf}
.sp-tbl .sp-fix{width:96px;padding:5px 8px}
.pill.r-rare{color:#8ec5ff}.pill.r-epic{color:#c9a2ff}.pill.r-legendary{color:#ffd166}.pill.r-mythic{color:#ff8ad8}
@media (max-width:640px){.sp-grp input{width:64px}.sp-tbl .sp-fix{width:80px}}

/*MC 2026-10-12 Emails: who gets what */
.mr-tw{max-height:640px;overflow:auto;margin:8px 0}
table.mr td small,table.mr th small{display:block;color:var(--muted);font-size:12px;font-weight:500;line-height:1.35}
table.mr th.c,table.mr td.c{text-align:center;min-width:110px}
table.mr td:first-child{min-width:240px;max-width:380px}
table.mr thead th{position:sticky;top:0;background:var(--card,#16112e);z-index:1;vertical-align:top}
table.mr .mr-who{display:block;font-weight:800}
table.mr .mr-all{display:flex;gap:4px;justify-content:center;margin-top:6px}
table.mr .mr-all button{padding:3px 8px;font-size:12px}
table.mr input[type=checkbox]{width:18px;height:18px}
/*MC 2026-10-13 the admin frame: sidebar of pages in folding groups, a sticky top bar (where you are, search, Needs you),
  the page header and underline tabs for pages with several parts. Under 1100px the sidebar becomes a drawer. */
.skip{position:absolute;left:-9999px;top:8px;z-index:100;padding:10px 14px;border-radius:10px;background:#fff;color:#16112e;font-weight:700}.skip:focus{left:12px}
.app{display:grid;grid-template-columns:264px minmax(0,1fr);min-height:100vh;min-height:100dvh}
.side{position:sticky;top:0;height:100vh;height:100dvh;display:flex;flex-direction:column;gap:12px;padding:16px 12px 12px;background:#0f0a25;border-right:1px solid var(--line);z-index:40;min-width:0}
.side-top{display:flex;align-items:center;justify-content:space-between;gap:8px}
.brand{display:flex;align-items:center;gap:11px;padding:2px 6px;color:#fff;text-decoration:none;min-width:0}
.brand b{display:block;font:800 16px "Bricolage Grotesque",sans-serif}.brand small{color:var(--muted);font-size:11.5px}
.side .seal{width:34px;height:34px;font-size:18px;border-radius:8px}
.side-x{display:none!important}
.sk{display:flex;align-items:center;gap:8px;width:100%;padding:9px 10px;border-radius:10px;background:rgba(255,255,255,.045);border:1px solid var(--line);color:var(--muted);font-weight:600;font-size:13px;text-align:left}
.sk:hover{border-color:var(--line2);color:#fff}.sk svg{width:16px;height:16px;flex:none;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round}
.sk kbd{margin-left:auto;font:600 10.5px Inter,sans-serif;padding:2px 6px;border-radius:6px;border:1px solid var(--line2);color:var(--muted);white-space:nowrap}
.snav{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:4px;margin:0 -6px;padding:0 6px;scrollbar-width:thin}
.sg{display:flex;flex-direction:column;gap:1px}.sg-top{padding-bottom:4px;border-bottom:1px solid var(--line);margin-bottom:2px}
.sgh{display:flex;align-items:center;justify-content:space-between;width:100%;padding:9px 8px 5px;background:none;border:0;border-radius:6px;color:#8279ad;font:700 10.5px Inter,sans-serif;letter-spacing:1.2px;text-transform:uppercase}
.sgh:hover{color:#fff;background:none}.sgh svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;transition:transform .15s}.sgh[aria-expanded=false] svg{transform:rotate(-90deg)}
.sgh[aria-expanded=false]+.sgl{display:none}.sgl{display:flex;flex-direction:column;gap:1px}
.snav a{position:relative;display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:9px;color:#bfb7e2;text-decoration:none;font-weight:600;font-size:13.5px;line-height:1.3}
.snav a svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none;opacity:.85}
.snav a:hover{background:rgba(255,255,255,.05);color:#fff}
.snav a.on{background:rgba(255,93,115,.14);color:#fff;box-shadow:inset 0 0 0 1px rgba(255,93,115,.3)}.snav a.on svg{opacity:1;color:#ff8fa0}
.snav a.on::before{content:"";position:absolute;left:-12px;top:8px;bottom:8px;width:3px;border-radius:0 3px 3px 0;background:var(--grad)}
.count{margin-left:auto;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:var(--coral);color:#fff;font:800 11px/20px Inter,sans-serif;text-align:center;font-style:normal}.count.info{background:#54489a}
i.dot{margin-left:auto;width:8px;height:8px;border-radius:50%;background:var(--sun);flex:none}
.sfoot{display:flex;align-items:center;gap:6px;padding-top:10px;border-top:1px solid var(--line)}
.sfoot form{margin:0}
.meline{flex:1;min-width:0;display:flex;align-items:center;gap:10px;padding:6px 8px;border-radius:10px;text-decoration:none}.meline:hover{background:rgba(255,255,255,.05)}
.meline span:last-child{min-width:0}.meline b{display:block;font-size:13px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.meline small{color:var(--muted);font-size:11.5px}
.iconbtn{position:relative;display:inline-grid;place-items:center;width:38px;height:38px;padding:0;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid var(--line);color:var(--text);flex:none}
.iconbtn:hover{border-color:var(--line2);background:rgba(255,255,255,.08)}
.iconbtn svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.iconbtn .count{position:absolute;top:-6px;right:-7px;margin:0;height:18px;min-width:18px;font-size:10.5px;line-height:18px;padding:0 5px}
.iconbtn i.dot{position:absolute;top:6px;right:6px;margin:0;background:var(--coral)}
.page{min-width:0;display:flex;flex-direction:column}
.top{position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:12px;padding:10px 28px;min-height:58px;background:rgba(13,9,32,.88);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border-bottom:1px solid var(--line)}
.mnav{display:none!important}
.crumbs{display:flex;align-items:center;gap:8px;min-width:0;font-size:13px;color:var(--muted);white-space:nowrap;overflow:hidden}
.crumbs a{color:var(--muted);text-decoration:none}.crumbs a:hover{color:#fff}.crumbs>*+*::before{content:"/";margin-right:8px;color:#5b5286}
.crumbs b{color:#fff;font-weight:700;overflow:hidden;text-overflow:ellipsis}
.top-r{margin-left:auto;display:flex;align-items:center;gap:8px}
.needs{position:relative}
.needs-p{position:absolute;right:0;top:calc(100% + 8px);width:min(400px,calc(100vw - 24px));max-height:70vh;overflow:auto;padding:6px;border-radius:14px;background:#1b1440;border:1px solid var(--line2);box-shadow:0 30px 60px -20px #000;z-index:50}
.needs-h{display:flex;justify-content:space-between;align-items:baseline;gap:10px;padding:8px 10px 6px}.needs-h small{color:var(--muted)}
.needs-l{list-style:none;margin:0;padding:0;display:grid;gap:2px}
.needs-l a{display:flex;gap:10px;padding:10px;border-radius:10px;color:var(--text);text-decoration:none}.needs-l a:hover{background:rgba(255,255,255,.05)}
.needs-l i{width:9px;height:9px;border-radius:50%;margin-top:6px;flex:none;background:#8b80c4}.nd-bad i{background:var(--coral)}.nd-warn i{background:var(--sun)}
.needs-l b{display:block;font-size:13.5px;line-height:1.35}.needs-l small{display:block;color:var(--muted);font-size:12.5px;line-height:1.4;margin-top:2px}
.nd-more{padding:4px 10px 8px;color:var(--muted)}
.needs-all{display:block;text-align:center;padding:10px;font-weight:700;font-size:13px;text-decoration:none;border-top:1px solid var(--line);margin-top:4px}
.needs-none{padding:6px 10px 12px;color:var(--muted);margin:0}
.needs-home{border:1px solid var(--line);border-radius:var(--r);background:var(--card);padding:6px;margin:0 0 18px}
.nh-h{display:flex;gap:10px;align-items:baseline;padding:10px 12px 4px}.nh-h b{font:800 17px "Bricolage Grotesque",sans-serif}.nh-h small{color:var(--muted)}.nh-ok{margin:4px 12px 12px}
.needs-home .needs-l{grid-template-columns:repeat(auto-fill,minmax(300px,1fr))}
.phead{display:flex;align-items:flex-end;justify-content:space-between;gap:12px 16px;flex-wrap:wrap;width:100%;max-width:1240px;margin:0 auto;padding:26px 28px 4px}
.phead h1{font-size:30px;margin:0 0 4px;line-height:1.15}.phead p{margin:0;color:var(--muted);max-width:72ch}
.howto{display:inline-flex;align-items:center;gap:8px;padding:8px 13px;border-radius:999px;border:1px solid var(--line2);background:rgba(255,255,255,.04);color:#fff;text-decoration:none;font-weight:700;font-size:13px;white-space:nowrap}
.howto svg{width:16px;height:16px;fill:none;stroke:var(--sun);stroke-width:1.8}.howto:hover{border-color:var(--sun)}
main{width:100%;max-width:1240px;margin:0 auto;padding:16px 28px 80px}
.secnav{position:sticky;top:58px;z-index:20;display:flex;gap:2px;overflow-x:auto;margin:0 0 18px;padding:0;border-bottom:1px solid var(--line);background:var(--bg);scrollbar-width:none}
.secnav::-webkit-scrollbar{display:none}
.secnav a{flex:none;display:inline-flex;align-items:center;gap:6px;padding:12px 14px 11px;color:var(--muted);text-decoration:none;font-weight:700;font-size:13.5px;border-bottom:2px solid transparent;margin-bottom:-1px}
.secnav a:hover{color:#fff}.secnav a.on{color:#fff;border-bottom-color:var(--coral)}
.secnav a i{font-style:normal;font-size:11px;padding:1px 7px;border-radius:999px;background:rgba(255,255,255,.1)}
.pg-first{margin-top:6px!important}
[id]{scroll-margin-top:124px}
.hl{animation:admHl 2.6s ease-out;border-radius:10px}
@keyframes admHl{0%,45%{box-shadow:0 0 0 3px rgba(255,209,102,.85);background-color:rgba(255,209,102,.12)}100%{box-shadow:0 0 0 3px rgba(255,209,102,0)}}
/*MC 2026-10-13 a hidden part of a page stayed on screen when its own class set display (the prize settings form is a grid) */
[hidden]{display:none!important}
main select{max-width:100%;text-overflow:ellipsis}main fieldset{min-width:0}main fieldset>label,main form>label{min-width:0;grid-template-columns:minmax(0,1fr)}main label>select{min-width:0}
.dirty{position:fixed;left:50%;bottom:calc(16px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:60;display:flex;align-items:center;gap:10px;width:min(560px,calc(100vw - 24px));padding:10px 10px 10px 16px;border-radius:14px;background:#231a4f;border:1px solid rgba(255,209,102,.45);box-shadow:0 20px 50px -12px #000}
.dirty span{flex:1;min-width:0}.dirty b{display:block;font-size:14px}.dirty small{display:block;color:var(--muted);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dirty .primary{background:var(--grad);border:0;color:#fff}
@media (min-width:1101px){.dirty{left:calc(50% + 132px)}}
.snav a:focus-visible,.iconbtn:focus-visible,.sk:focus-visible,.secnav a:focus-visible,.sgh:focus-visible,.needs-l a:focus-visible,.howto:focus-visible{outline:2px solid var(--sun);outline-offset:2px}
.pick-wrap{position:relative;display:inline-flex;flex:1 1 220px;min-width:0}.pick-wrap>input{width:100%;min-width:0!important}
.pick{position:absolute;left:0;right:0;top:calc(100% + 6px);z-index:40;min-width:260px;max-height:340px;overflow-y:auto;padding:5px;border-radius:12px;background:#1b1440;border:1px solid var(--line2);box-shadow:0 24px 50px -16px #000}
.pick button{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:2px 8px;width:100%;padding:8px 10px;border:0;border-radius:9px;background:none;text-align:left;font-weight:600}
.pick button:hover,.pick button.on{background:rgba(255,93,115,.16)}.pick b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pick em{font-style:normal;font-size:11px;color:#7ff2c9}
.pick small{grid-column:1/-1;color:var(--muted);font-size:12px;font-weight:500}.pick-none{margin:6px 8px;color:var(--muted);font-size:13px}
input.picked{border-color:rgba(46,240,176,.55)!important}
.pg-empty{padding:28px;border:1px dashed var(--line2);border-radius:var(--r);color:var(--muted);text-align:center}
.pal{position:fixed;inset:0;z-index:90;display:grid;justify-items:center;align-items:start;padding:10vh 16px 16px;background:rgba(5,3,14,.62);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)}
.pal[hidden]{display:none}
.pal-b{width:min(660px,100%);max-height:74vh;display:flex;flex-direction:column;border-radius:16px;background:#17112f;border:1px solid var(--line2);box-shadow:0 40px 80px -20px #000;overflow:hidden}
.pal-i{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--line)}
.pal-i svg{width:18px;height:18px;flex:none;fill:none;stroke:var(--muted);stroke-width:2;stroke-linecap:round}
.pal-i input{flex:1;min-width:0;border:0;background:none;padding:8px 0;font-size:16px;border-radius:0}.pal-i input:focus{box-shadow:none}
.pal-i kbd{font:600 10.5px Inter,sans-serif;padding:2px 6px;border-radius:6px;border:1px solid var(--line2);color:var(--muted)}
.pal-r{list-style:none;margin:0;padding:6px;overflow-y:auto;overscroll-behavior:contain}
.pal-r a{display:flex;align-items:center;gap:12px;padding:9px 10px;border-radius:10px;color:var(--text);text-decoration:none}
.pal-r li.on a{background:rgba(255,93,115,.16)}
.pal-r .k{flex:none;width:68px;font:700 10px Inter,sans-serif;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)}
.pal-r span{min-width:0}.pal-r b{display:block;font-size:14px;font-weight:700}.pal-r small{display:block;color:var(--muted);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pal-r mark{background:none;color:var(--sun)}
.tg-burn{display:flex;align-items:center;justify-content:space-between;gap:10px 16px;flex-wrap:wrap;margin:12px 0;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,140,60,.35);background:rgba(255,120,40,.07)}.tg-burn span{display:grid;gap:2px;min-width:0}.tg-burn small{color:var(--muted)}
.bsx{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:16px;align-items:start;padding:14px;border-radius:16px;border:1px solid rgba(243,201,105,.3);background:linear-gradient(150deg,rgba(243,201,105,.08),rgba(255,255,255,.02))}
.bsx-img{display:block;border-radius:12px;overflow:hidden;box-shadow:0 14px 34px -14px rgba(0,0,0,.8);border:1px solid rgba(243,201,105,.35)}.bsx-img img{display:block;width:100%;height:auto}
.bsx-r{display:grid;gap:10px;min-width:0}.bsx-r label{display:grid;gap:6px}.bsx-r textarea{width:100%;min-height:150px;resize:vertical}
.bsx-b{display:flex;flex-wrap:wrap;gap:8px}.bsx-x{background:#000!important;color:#fff!important;border:1px solid rgba(255,255,255,.3)!important}.bsx-u{margin:0;font-size:12px;overflow-wrap:anywhere}
@media (max-width:860px){.bsx{grid-template-columns:minmax(0,1fr)}}
/*MC 2026-10-12 Holdings ($SHY and Koban per player, admin/holdings.js). Gold for $SHY, mint for Koban, and one color per Army Rank
  running from sapling green up to Supreme gold, shared by the ladder, the avatars and the rank pills. Rows turn into cards on a phone. */
.hx{--t0:#8b5cf6;--t1:#7bd88f;--t2:#5ec8c0;--t3:#58a6ff;--t4:#7c8cff;--t5:#c084fc;--t6:#f472b6;--t7:#ff8a5c;--t8:#ffb547;--t9:#ffd166;display:grid;gap:14px}
.hx>p{margin:0}
.hx-kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}
.hx-k{position:relative;overflow:hidden;padding:16px;border-radius:16px;border:1px solid var(--line);background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.015));min-width:0}
.hx-k small{display:block;font:700 10.5px Inter,sans-serif;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.hx-k b{display:block;font-size:clamp(20px,2.1vw,27px);line-height:1.15;margin:6px 0 3px;font-variant-numeric:tabular-nums;overflow:hidden;text-overflow:ellipsis}
.hx-k span{display:block;font-size:12.5px;color:var(--muted)}
.hx-k.gold{border-color:rgba(255,209,102,.4);background:radial-gradient(120% 120% at 100% 0%,rgba(255,209,102,.2),transparent 60%),linear-gradient(160deg,rgba(255,209,102,.09),rgba(255,255,255,.015))}
.hx-k.gold b{background:linear-gradient(100deg,#ffd166,#fff1c4 50%,#ffd166);-webkit-background-clip:text;background-clip:text;color:transparent}
.hx-k.mint{border-color:rgba(46,240,176,.32);background:radial-gradient(120% 120% at 100% 0%,rgba(46,240,176,.15),transparent 60%),rgba(255,255,255,.02)}
.hx-k.mint b{color:#7ff7cf}
.hx-card{padding:16px;border-radius:16px;border:1px solid var(--line);background:rgba(255,255,255,.025);min-width:0}
.hx-h{display:flex;justify-content:space-between;align-items:baseline;gap:10px;margin-bottom:10px}.hx-h small{color:var(--muted)}
.hx-strip{display:flex;height:14px;border-radius:99px;overflow:hidden;gap:2px;background:rgba(255,255,255,.05)}
.hx-strip i{display:block;min-width:4px}.hx-strip i.none{background:rgba(255,255,255,.06)}
.hx .t0{--c:var(--t0)}.hx .t1{--c:var(--t1)}.hx .t2{--c:var(--t2)}.hx .t3{--c:var(--t3)}.hx .t4{--c:var(--t4)}.hx .t5{--c:var(--t5)}.hx .t6{--c:var(--t6)}.hx .t7{--c:var(--t7)}.hx .t8{--c:var(--t8)}.hx .t9{--c:var(--t9)}
.hx-strip i[class^=t]{background:var(--c)}
.hx-chips{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-top:12px}
.hx-chip{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--text);text-align:left;cursor:pointer;min-width:0;font-weight:600}
.hx-chip>i{flex:none;width:10px;height:10px;border-radius:3px;background:var(--c);box-shadow:0 0 10px var(--c)}
.hx-chip span{flex:1;min-width:0;font-size:13px;line-height:1.25;overflow-wrap:anywhere}.hx-chip small{display:block;font-size:11px;color:var(--muted);font-weight:500}
.hx-chip b{font-variant-numeric:tabular-nums}
.hx-chip:hover{border-color:var(--line2)}.hx-chip.on{border-color:var(--c);background:rgba(255,255,255,.07)}.hx-chip:disabled{opacity:.4;cursor:default}
.hx-bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.hx-bar input[type=search]{flex:1 1 240px;min-width:0}
.hx-seg{display:inline-flex;padding:3px;border-radius:999px;background:rgba(0,0,0,.25);border:1px solid var(--line);gap:2px;max-width:100%;overflow-x:auto}
.hx-seg button{border:0;background:none;color:var(--muted);padding:7px 13px;border-radius:999px;font-weight:700;font-size:13px;white-space:nowrap;cursor:pointer;min-height:34px}
.hx-seg button.on{background:#fff4dc;color:#1b1612}
.hx-csv,.hx-more{border:1px solid var(--line2);background:rgba(255,255,255,.04);color:var(--text);padding:8px 14px;border-radius:999px;font-weight:700;cursor:pointer}
.hx-more{display:block;margin:12px auto 0}
.hx-count{margin:12px 0 8px;color:var(--muted);font-size:13px}.hx-count b{color:var(--text)}
.hx-list{display:grid;gap:4px}
.hx-row{display:grid;grid-template-columns:40px minmax(0,1.7fr) minmax(0,1fr) minmax(0,1fr) 92px 150px;gap:12px;align-items:center;padding:9px 12px;border-radius:12px;background:rgba(255,255,255,.025);border:1px solid transparent}
.hx-row:hover{border-color:var(--line);background:rgba(255,255,255,.045)}
.hx-head{background:none;padding-block:4px;font:700 10.5px Inter,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}.hx-head:hover{background:none;border-color:transparent}
.hx-n{font-weight:800;color:var(--muted);font-variant-numeric:tabular-nums;text-align:center}
.hx-row.top .hx-n{display:grid;place-items:center;width:30px;height:30px;border-radius:9px;color:#1b1612;justify-self:center}
.hx-row.top1 .hx-n{background:linear-gradient(150deg,#fff1c4,#ffd166)}.hx-row.top2 .hx-n{background:linear-gradient(150deg,#f4f4f8,#b9bccb)}.hx-row.top3 .hx-n{background:linear-gradient(150deg,#ffd0a8,#d98a4e)}
.hx-row.top1{border-color:rgba(255,209,102,.35);background:linear-gradient(90deg,rgba(255,209,102,.1),rgba(255,255,255,.02) 60%)}
.hx-who{display:flex;align-items:center;gap:10px;min-width:0}
.hx-av{flex:none;display:grid;place-items:center;width:34px;height:34px;border-radius:50%;font-weight:800;background:rgba(255,255,255,.08);color:var(--text);box-shadow:inset 0 0 0 2px var(--c,rgba(255,255,255,.12))}
.hx-nm{min-width:0;display:grid}.hx-nm a,.hx-nm>span{font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text);text-decoration:none}.hx-nm a:hover{color:var(--sun)}
.hx-nm small{display:flex;gap:6px;align-items:center;min-width:0;font-size:11.5px;color:var(--muted)}.hx-nm code{font-size:11px;opacity:.75;overflow:hidden;text-overflow:ellipsis}
.hx-tier{font-style:normal;font-weight:700;color:var(--c);white-space:nowrap}
.hx-v{position:relative;display:grid;min-width:0;padding-bottom:6px}
.hx-v b{font-variant-numeric:tabular-nums;font-size:15px}.hx-v small{font-size:11.5px;color:var(--muted)}
.hx-v i{position:absolute;left:0;bottom:0;height:3px;border-radius:9px;max-width:100%}
.hx-shy b{color:#ffe08a}.hx-shy i{background:linear-gradient(90deg,#b8862b,#ffd166)}
.hx-kob b{color:#7ff7cf}.hx-kob i{background:linear-gradient(90deg,#14a37a,#2ef0b0)}
.hx-sh{font-size:13px}
.hx-w{display:grid;min-width:0;font-size:13px}.hx-w a{font-family:ui-monospace,monospace}.hx-w small{font-size:11px;color:var(--muted)}
.hx-none{margin:0;padding:24px;text-align:center;color:var(--muted)}
@media (max-width:1100px){.hx-kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.hx-chips{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:760px){
  .hx-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.hx-kpis .hx-k:first-child{grid-column:1/-1}
  .hx-chips{grid-template-columns:repeat(2,minmax(0,1fr))}
  .hx-head{display:none}
  .hx-row{grid-template-columns:32px minmax(0,1fr) minmax(0,1fr);grid-template-areas:"n who who" "n shy kob" "n sh w";row-gap:8px;padding:12px}
  .hx-n{grid-area:n;align-self:start}.hx-who{grid-area:who}.hx-shy{grid-area:shy}.hx-kob{grid-area:kob}.hx-sh{grid-area:sh}.hx-w{grid-area:w}
  .hx-bar .hx-seg,.hx-csv{flex:1 1 auto;justify-content:center}
}
.pal-none{padding:18px 12px;color:var(--muted)}
.pal-f{display:flex;flex-wrap:wrap;gap:6px 14px;padding:8px 14px;border-top:1px solid var(--line);font-size:11.5px;color:var(--muted)}
.scrim{display:none}
body.side-open{overflow:hidden}
@media (max-width:1100px){
  .app{grid-template-columns:minmax(0,1fr)}
  .side{position:fixed;left:0;top:0;bottom:0;width:min(300px,86vw);height:auto;transform:translateX(-102%);visibility:hidden;transition:transform .22s ease,visibility 0s .22s;box-shadow:30px 0 60px -20px #000;padding-bottom:calc(12px + env(safe-area-inset-bottom,0px))}
  body.side-open .side{transform:none;visibility:visible;transition:transform .22s ease}
  .scrim{position:fixed;inset:0;z-index:35;background:rgba(5,3,14,.55);display:block;opacity:0;pointer-events:none;transition:opacity .2s}
  body.side-open .scrim{opacity:1;pointer-events:auto}
  .side-x{display:inline-grid!important}.mnav{display:inline-grid!important}
  .top{padding:8px 16px;min-height:54px}.phead{padding:20px 16px 4px}.phead h1{font-size:25px}main{padding:14px 16px 70px}
  .secnav{top:54px;margin-left:-16px;margin-right:-16px;padding:0 10px}
  .snav a{padding:10px 10px}
}
@media (max-width:600px){.crumbs a,.crumbs span{display:none}.crumbs>*+*::before{display:none}.crumbs b{font-size:15px}.top-r .iconbtn[href]{display:none}.howto{padding:7px 12px}.needs-home .needs-l{grid-template-columns:1fr}.pal{padding-top:8px}.pal-b{max-height:calc(100dvh - 16px)}.pal-r .k{display:none}.pal-f{display:none}}
@media (prefers-reduced-motion:reduce){.side,.scrim,.sgh svg{transition:none}.hl{animation:none;box-shadow:0 0 0 3px rgba(255,209,102,.85)}}
</style></head><body>';
}
function page_login($err) {
    head_html('Admin sign in');
    echo '<form class="login" method="post"><span class="seal">管</span><h1>Shy admin</h1><p class="muted">Sign in to run shyonsol.io.</p>' . ($err ? '<p class="err">' . h($err) . '</p>' : '') .
        '<label class="lf"><span>Username or email</span><input name="login" autocomplete="username" autofocus value="' . h($_POST['login'] ?? '') . '"></label>' .
        '<label class="lf"><span>Password</span><input type="password" name="pw" autocomplete="current-password" required></label><button name="do" value="login">Sign in</button>' .
        '<p class="muted small">Setting up for the first time? Leave the name empty and use the setup password from config.php.</p></form></body></html>';
}
