// The two token cards on the home page.
// The burn: a wall of 100 coins, one for every 1% of the 1 billion $SHY. When it comes into view the launch-day half
// catches fire coin by coin from the bottom up and burns down to glowing coal, embers drift up, and the count climbs to
// 500,000,000 plus everything burned since (the game and community burns, api/treasury.php), shown as the next coin,
// partly burned.
// Tap or hover a coin to see what it stands for; Light it again replays the burn.
// 0 / 0 / 0: three tiles that spin like a slot reel and land on zero when they come into view; tap one to flip it over.
//MC 2026-10-16 first version (the cards were a static ring and a line of text)
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var phone = matchMedia("(max-width: 640px)").matches;
  var SUPPLY = 1e9, LAUNCH = 5e8, PER = 1e7;
  function fmt(n) { return Math.round(n).toLocaleString("en-US"); }
  function short(n) { return n >= 1e9 ? (n / 1e9).toFixed(n % 1e9 ? 2 : 0) + "B" : n >= 1e6 ? (n / 1e6).toFixed(n % 1e6 ? 1 : 0).replace(/\.0$/, "") + "M" : n >= 1e3 ? Math.round(n / 1e3) + "K" : fmt(n); }

  // ---------------------------------------------------------------- the burn
  var card = document.getElementById("burnfx");
  if (card) (function () {
    var wall = card.querySelector("[data-bf=wall]"), tip = wall.querySelector(".bf-tip"), cv = wall.querySelector(".bf-embers");
    var totalEl = card.querySelector("[data-bf=total]"), gameEl = card.querySelector("[data-bf=game]"), leftEl = card.querySelector("[data-bf=left]");
    var game = 0, coins = [], lit = false, raf = 0, embers = [], onScreen = false;
    // 100 coins, filled from the bottom row up so the burned half is the fire's base
    var frag = document.createDocumentFragment();
    for (var i = 0; i < 100; i++) {
      var c = document.createElement("i"); c.className = "bf-c"; c.dataset.i = i;
      var row = 9 - Math.floor(i / 10), col = i % 10;
      c.style.gridRow = row + 1; c.style.gridColumn = col + 1;
      frag.appendChild(c); coins.push(c);
    }
    wall.insertBefore(frag, cv);
    function state() {
      var gameCoins = game / PER;
      coins.forEach(function (c, i) {
        c.classList.remove("burn", "part", "gb"); c.style.removeProperty("--p");
        if (i < 50) c.classList.add("burn");
        else if (i < 50 + Math.floor(gameCoins)) c.classList.add("burn", "gb");
        else if (i === 50 + Math.floor(gameCoins) && gameCoins % 1 > 0.004) { c.classList.add("part"); c.style.setProperty("--p", Math.max(6, Math.round(gameCoins % 1 * 100)) + "%"); }
      });
    }
    function count(to, ms) {
      var t0 = performance.now();
      (function step(now) { var k = Math.min(1, (now - t0) / ms), e = 1 - Math.pow(1 - k, 3); totalEl.textContent = fmt(to * e); if (k < 1) requestAnimationFrame(step); })(t0);
      setTimeout(function () { totalEl.textContent = fmt(to); }, ms + 120);   // lands on the number even if frames are paused
    }
    function ignite() {
      lit = true;
      card.classList.remove("done"); card.classList.add("lighting");
      coins.forEach(function (c) { c.classList.remove("fire", "coal"); });
      if (reduce) { coins.forEach(function (c, i) { if (c.classList.contains("burn")) c.classList.add("coal"); }); card.classList.add("done"); totalEl.textContent = fmt(LAUNCH + game); return; }
      var order = coins.filter(function (c) { return c.classList.contains("burn"); });
      // bottom rows first, a little shuffled within a row, like fire climbing
      order.sort(function (a, b) { var ra = Math.floor(+a.dataset.i / 10), rb = Math.floor(+b.dataset.i / 10); return ra - rb || (Math.sin(+a.dataset.i * 9.1) - Math.sin(+b.dataset.i * 9.1)); });
      var step = 1700 / Math.max(1, order.length);
      order.forEach(function (c, k) {
        setTimeout(function () { c.classList.add("fire"); burst(c, 5); }, k * step);
        setTimeout(function () { c.classList.add("coal"); c.classList.remove("fire"); }, k * step + 900);
      });
      count(LAUNCH + game, 1700 + 600);
      setTimeout(function () { card.classList.remove("lighting"); card.classList.add("done"); }, 1700 + 1000);
      kick();
    }
    // embers: a few sparks always drifting off the coal, a burst from each coin as it catches
    var ctx = cv.getContext("2d"), W = 0, H = 0, dpr = Math.min(phone ? 1.5 : 2, window.devicePixelRatio || 1);
    function size() { var r = wall.getBoundingClientRect(); W = r.width; H = r.height; cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
    function burst(c, n) {
      if (reduce) return;
      var wr = wall.getBoundingClientRect(), r = c.getBoundingClientRect();
      for (var k = 0; k < n; k++) embers.push({ x: r.left - wr.left + r.width * Math.random(), y: r.top - wr.top + r.height * .4, vx: (Math.random() - .5) * .6, vy: -(.6 + Math.random() * 1.2), life: 1, s: 1 + Math.random() * 2.2, hue: Math.random() < .7 ? 30 : 10 });
    }
    function idle() {
      if (reduce || !card.classList.contains("done") || embers.length > (phone ? 26 : 50)) return;
      var burned = coins.filter(function (c) { return c.classList.contains("coal"); });
      if (burned.length && Math.random() < .5) burst(burned[Math.floor(Math.random() * burned.length)], 1);
    }
    var last = 0;
    function frame(now) {
      raf = 0;
      if (now - last > (phone ? 40 : 28)) {
        last = now; idle();
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, W, H);
        ctx.globalCompositeOperation = "lighter";
        for (var k = embers.length - 1; k >= 0; k--) {
          var e = embers[k];
          e.x += e.vx + Math.sin(now / 400 + k) * .25; e.y += e.vy; e.life -= .012;
          if (e.life <= 0 || e.y < -10) { embers.splice(k, 1); continue; }
          var g = ctx.createRadialGradient(e.x, e.y, 0, e.x, e.y, e.s * 3);
          g.addColorStop(0, "hsla(" + (e.hue + 20) + ",100%,75%," + e.life + ")"); g.addColorStop(1, "hsla(" + e.hue + ",100%,50%,0)");
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(e.x, e.y, e.s * 3, 0, 6.283); ctx.fill();
        }
        ctx.globalCompositeOperation = "source-over";
      }
      if (onScreen && !document.hidden && (embers.length || card.classList.contains("done") || card.classList.contains("lighting"))) raf = requestAnimationFrame(frame);
    }
    function kick() { if (!raf && !reduce) raf = requestAnimationFrame(frame); }
    // what a coin stands for
    function showTip(c) {
      var i = +c.dataset.i, what;
      if (i < 50) what = "<b>Burned on launch day</b>Gone for good";
      else if (c.classList.contains("gb")) what = "<b>Burned since launch</b>By the game and the community";
      else if (c.classList.contains("part")) what = "<b>Burning now</b>" + short(game % PER) + " of it burned since launch";
      else what = "<b>Still out there</b>Held and traded by the community";
      tip.innerHTML = '<span class="bf-tn">1% of all $SHY &middot; <span data-i18n-skip>10,000,000</span></span>' + what;
      tip.hidden = false;
      var wr = wall.getBoundingClientRect(), r = c.getBoundingClientRect(), tw = tip.offsetWidth;
      var x = Math.max(4, Math.min(wr.width - tw - 4, r.left - wr.left + r.width / 2 - tw / 2)), y = r.top - wr.top - tip.offsetHeight - 8;
      if (y < 0) y = r.bottom - wr.top + 8;
      tip.style.transform = "translate(" + Math.round(x) + "px," + Math.round(y) + "px)";
      coins.forEach(function (o) { o.classList.toggle("sel", o === c); });
    }
    function hideTip() { tip.hidden = true; coins.forEach(function (o) { o.classList.remove("sel"); }); }
    wall.addEventListener("pointerover", function (e) { var c = e.target.closest(".bf-c"); if (c && e.pointerType === "mouse") showTip(c); });
    wall.addEventListener("pointerleave", function (e) { if (e.pointerType === "mouse") hideTip(); });
    // a mouse already opened the tip on hover, so its click keeps it open; a finger taps it open and taps it shut
    var lastPtr = "mouse";
    wall.addEventListener("pointerdown", function (e) { lastPtr = e.pointerType || "mouse"; }, { passive: true });
    wall.addEventListener("click", function (e) {
      var c = e.target.closest(".bf-c"); if (!c) return;
      if (lastPtr !== "mouse" && c.classList.contains("sel")) { hideTip(); return; }
      showTip(c); if (c.classList.contains("coal")) { burst(c, 6); kick(); }
    });
    document.addEventListener("pointerdown", function (e) { if (!wall.contains(e.target)) hideTip(); }, { passive: true });
    card.querySelector("[data-bf=replay]").addEventListener("click", function () { hideTip(); embers = []; ignite(); });
    state(); size();
    window.addEventListener("resize", function () { size(); });
    if ("IntersectionObserver" in window) new IntersectionObserver(function (es) {
      onScreen = es[0].isIntersecting;
      if (onScreen && !lit) ignite(); else if (onScreen) kick();
    }, { threshold: .35 }).observe(card);
    else ignite();
    // what the game has burned so far
    fetch("/api/treasury.php").then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok || !j.burns) return;
      game = Math.max(0, +j.burns.shy || 0);
      gameEl.textContent = short(game); leftEl.textContent = short(SUPPLY - LAUNCH - game);
      state();
      if (card.classList.contains("done")) { coins.forEach(function (c) { if (c.classList.contains("burn")) c.classList.add("coal"); }); count(LAUNCH + game, 600); }
    }).catch(function () {});
  })();

  // ---------------------------------------------------------------- 0 / 0 / 0
  var tax = document.getElementById("taxfx");
  if (tax) (function () {
    var nums = tax.querySelectorAll(".tx-n"), rolled = false;
    function roll() {
      rolled = true;
      nums.forEach(function (n, k) {
        var to = n.dataset.to, pct = /%$/.test(to);
        if (reduce) { n.textContent = to; return; }
        var t0 = performance.now(), dur = 900 + k * 350;
        n.classList.add("spin");
        (function step(now) {
          var p = (now - t0) / dur;
          if (p >= 1) { n.textContent = to; n.classList.remove("spin"); n.classList.add("land"); setTimeout(function () { n.classList.remove("land"); }, 500); return; }
          if (Math.random() < .6) n.textContent = (pct ? Math.floor(Math.random() * 30) + "%" : String(Math.floor(Math.random() * 99) + 1) + (Math.random() < .5 ? "M" : ""));
          requestAnimationFrame(step);
        })(t0);
        setTimeout(function () { n.textContent = to; n.classList.remove("spin"); }, dur + 150);
      });
    }
    tax.addEventListener("click", function (e) {
      var t = e.target.closest(".tx-t"); if (!t) return;
      var on = !t.classList.contains("flip"); t.classList.toggle("flip", on); t.setAttribute("aria-pressed", String(on));
    });
    if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { if (es[0].isIntersecting && !rolled) roll(); }, { threshold: .5 }).observe(tax);
    else roll();
  })();
})();
