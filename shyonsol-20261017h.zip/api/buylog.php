<?php
//MC 2026-10-09 $SHY bought through the swap box on the Token page. The swap itself happens between the buyer's wallet
//   and Jupiter; the page tells us the transaction afterwards so the team hears about it and it counts in the reports.
//   We check it on Solana before believing it: confirmed, recent, and the signer's wallet ended up with more $SHY.
// POST {sig, pid?}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
//MC 2026-10-17 every confirmed buy also goes to the Telegram group on its own card (share.php ?ns=). The buyer shows as
//   their player name when this wallet or browser belongs to one, otherwise as a shortened wallet, never both.
function swap_tg($rec) {
    if (!function_exists('tg_post')) return;
    $c = tg_cfg(); if (!tg_ready($c) || !tg_on($c, 'swap')) return;
    $players = load(PLAYERS); $name = '';
    if ($rec['pid'] !== '' && !empty($players[$rec['pid']]['name'])) $name = (string)$players[$rec['pid']]['name'];
    if ($name === '' && $rec['wallet'] !== '') foreach ((array)load(HOLDERS) as $p => $h) if (($h['wallet'] ?? '') === $rec['wallet'] && !empty($players[$p]['name'])) { $name = (string)$players[$p]['name']; break; }
    $short = $rec['wallet'] !== '' ? substr($rec['wallet'], 0, 4) . '…' . substr($rec['wallet'], -4) : 'a new holder';
    $n = 0; foreach ((array)load(SWAPS) as $x) if (!empty($x['ok']) && ($x['t'] ?? 0) > time() - 7 * 86400) $n++;
    $mk = (array)(load(defined('MARKET') ? MARKET : DATA_DIR . '/market.php')['pair']['d'] ?? []);
    $px = (float)($mk['price'] ?? 0); $mcap = (float)($mk['mcap'] ?? 0);
    $card = ['shy' => (float)$rec['shy'], 'usd' => (float)$rec['usd'], 'paid' => (string)$rec['paid'], 'who' => $name !== '' ? $name : $short,
        'price' => $px, 'mcap' => $mcap, 'n' => $n, 'sig' => $rec['sig']];
    $img = function_exists('tg_card_rec') ? tg_card_rec('swapc', $card, 'ns') : '';
    $amt = number_format($rec['shy'] >= 100 ? round($rec['shy']) : $rec['shy'], $rec['shy'] >= 100 ? 0 : 2);
    $html = '🟢 <b>New $SHY buy on Shy Swap!</b>' . "\n"
        . '<b>+' . $amt . ' $SHY</b>' . ($rec['usd'] ? ' (about $' . number_format($rec['usd'], $rec['usd'] >= 100 ? 0 : 2) . ')' : '') . ($rec['paid'] !== '' ? ' for ' . tg_h($rec['paid']) : '') . "\n"
        . 'Bought by ' . ($name !== '' ? tg_link(tg_pslug($name), $name) : '<code>' . tg_h($short) . '</code>') . "\n"
        . '<a href="https://solscan.io/tx/' . tg_h($rec['sig']) . '">See it on Solscan</a> · ' . tg_link('/swap', 'Buy $SHY on Shy Swap');
    tg_post('swap', $html, 'swap:' . $rec['sig'], null, $img);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$sig = (string)($b['sig'] ?? ''); $pid = (string)($b['pid'] ?? '');
if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) fail('bad signature');
if (!preg_match('/^[a-f0-9]{16}$/', $pid)) $pid = '';
$ok = with_lock(function () use ($sig) {
    $l = load(LIMITS); $r = rate_ok($l, 'swap:' . client_ip(), 20, 3600); save(LIMITS, $l);
    return $r && !isset(load(SWAPS)[$sig]);
});
if (!$ok) out(['ok' => true]);
// the swap can take a few seconds to show up on the RPC
$tx = null;
for ($i = 0; $i < 5 && !$tx; $i++) { $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]); if (!$tx) sleep(2); }
$rec = ['sig' => $sig, 't' => time(), 'bt' => 0, 'pid' => $pid, 'wallet' => '', 'shy' => 0, 'usd' => 0, 'paid' => '', 'ok' => 0];
if ($tx && empty($tx['meta']['err'])) {
    $keys = $tx['transaction']['message']['accountKeys'] ?? [];
    $signer = is_array($keys[0] ?? null) ? ($keys[0]['pubkey'] ?? '') : (string)($keys[0] ?? '');
    $rec['wallet'] = $signer; $rec['bt'] = (int)($tx['blockTime'] ?? 0);
    $pre = []; $delta = [];
    foreach ($tx['meta']['preTokenBalances'] ?? [] as $x) if (($x['owner'] ?? '') === $signer) $pre[$x['accountIndex']] = [$x['mint'], (float)($x['uiTokenAmount']['uiAmountString'] ?? ($x['uiTokenAmount']['amount'] / pow(10, $x['uiTokenAmount']['decimals'] ?? 0)))];
    foreach ($tx['meta']['postTokenBalances'] ?? [] as $x) {
        if (($x['owner'] ?? '') !== $signer) continue;
        $v = (float)($x['uiTokenAmount']['uiAmountString'] ?? ($x['uiTokenAmount']['amount'] / pow(10, $x['uiTokenAmount']['decimals'] ?? 0)));
        $delta[$x['mint']] = ($delta[$x['mint']] ?? 0) + $v - ($pre[$x['accountIndex']][1] ?? 0);
        unset($pre[$x['accountIndex']]);
    }
    foreach ($pre as [$mint, $v]) $delta[$mint] = ($delta[$mint] ?? 0) - $v;   // a token account closed in the swap
    $shy = $delta[SHY_MINT] ?? 0;
    $sol = ((int)($tx['meta']['preBalances'][0] ?? 0) - (int)($tx['meta']['postBalances'][0] ?? 0)) / 1e9;
    $paid = [];
    if ($sol > 0.00001) $paid[] = rtrim(rtrim(number_format($sol, 4, '.', ''), '0'), '.') . ' SOL';
    foreach ($delta as $mint => $v) if ($mint !== SHY_MINT && $v < 0) $paid[] = rtrim(rtrim(number_format(-$v, 4, '.', ''), '0'), '.') . ' ' . ($mint === USDC_MINT ? 'USDC' : substr($mint, 0, 4) . '…');
    $recent = !$rec['bt'] || $rec['bt'] > time() - 3 * 3600;
    if ($shy > 0 && $recent) {
        $px = price_usd(SHY_MINT);
        $rec['shy'] = round($shy, 2); $rec['usd'] = $px ? round($shy * $px, 2) : 0; $rec['paid'] = implode(' + ', $paid); $rec['ok'] = 1;
    }
}
with_lock(function () use ($sig, $rec) { $s = load(SWAPS); if (isset($s[$sig])) return; $s[$sig] = $rec; if (count($s) > 3000) $s = array_slice($s, -2500, null, true); save(SWAPS, $s); });
if ($rec['ok']) { track('swaps'); track('swap_shy', (int)$rec['shy']); alert_swap($rec); swap_tg($rec); }
out(['ok' => true, 'counted' => (bool)$rec['ok']]);
