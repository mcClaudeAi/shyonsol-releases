<?php
//MC 2026-10-15 /r/<version>: the link in a release post on X. Its job is the unfurl: X reads the tags here and shows that
//   release's card (api/share.php?rl=). Anyone who taps it lands on that release in the release notes.
define('SHY_API', 1);
require __DIR__ . '/common.php';

function rp_h($x) { return htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8'); }

$v = (string)($_GET['v'] ?? '');
$rel = null;
if (preg_match('/^[a-z0-9]{2,24}$/', $v)) {
    $f = __DIR__ . '/lib/releases-all.php';
    foreach ((is_file($f) ? (array)(require $f) : []) as $r) if (($r['v'] ?? '') === $v) { $rel = $r; break; }
}
if (!$rel) { header('Cache-Control: no-store'); header('Location: /updates', true, 302); exit; }

$h = preg_replace('/[^a-z0-9.:\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') ?: 'shyonsol.io';
$site = (strpos($h, '127.0.0.1') === false ? 'https' : 'http') . '://' . $h;
$go = '/updates#v' . rawurlencode($v);
$title = $rel['title'] . ' | Shilluminati Online update';
$desc = (string)$rel['summary'];
$img = $site . '/api/share.php?rl=' . rawurlencode($v) . '&k=' . substr(sha1(json_encode($rel)), 0, 8);
$url = $site . '/r/' . rawurlencode($v);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=600');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
    . '<title>' . rp_h($title) . '</title>'
    . '<meta name="description" content="' . rp_h($desc) . '">'
    . '<link rel="canonical" href="' . rp_h($site . $go) . '">'
    . '<meta name="robots" content="noindex">'
    . '<meta property="og:type" content="article"><meta property="og:site_name" content="Shy on Solana">'
    . '<meta property="og:title" content="' . rp_h($title) . '"><meta property="og:description" content="' . rp_h($desc) . '">'
    . '<meta property="og:url" content="' . rp_h($url) . '">'
    . '<meta property="og:image" content="' . rp_h($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
    . '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@ShyOnSol_"><meta name="twitter:title" content="' . rp_h($title) . '">'
    . '<meta name="twitter:description" content="' . rp_h($desc) . '"><meta name="twitter:image" content="' . rp_h($img) . '">'
    . '</head><body style="margin:0;background:#140d33;color:#fff;font:600 16px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh">'
    . '<p><a href="' . rp_h($go) . '" style="color:#ff5d73">Taking you to the release notes&hellip;</a></p>'
    . '<script>location.replace(' . json_encode($go) . ');</script></body></html>';
