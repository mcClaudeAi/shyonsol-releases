<?php
// Result cards for sharing on X. The server draws the image itself from the game result (no uploads).
// POST {a: create, ...result}  -> {id, url}
// GET  ?s=ID  -> page with a large image preview for X, then on to the game
// GET  ?i=ID  -> the 1200x630 PNG

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';   // for the Region list

define('SHARES', DATA_DIR . '/shares');
const COLORS = ['#ff5d73', '#8b5cf6', '#2ef0b0', '#ff9f43'];
const MASKS = ['unbound', 'oni', 'kitsune', 'ronin', 'monk', 'tiger', 'crane'];
const SITE = 'https://shyonsol.io';

function share_file($id, $ext) { return SHARES . '/' . $id . '.' . $ext; }
//MC 2026-10-10 bump SHARE_LOOK when the card design changes: the PNG cache and the image address X keeps both move with it
const SHARE_LOOK = 'w3';
function share_png($id) { return SHARES . '/' . $id . '.' . SHARE_LOOK . '.png'; }
function share_jpg($id) { return SHARES . '/' . $id . '.' . SHARE_LOOK . '.jpg'; }
//MC 2026-10-11 draw a card once, whole, and never more than two at a time (see the image section below). Returns the file.
function share_draw_once($rec, $out, $id) {
    if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
    $lf = @fopen(SHARES . '/' . $id . '.lock', 'c');
    if ($lf) flock($lf, LOCK_EX);
    try {
        if (is_file($out)) return $out;   // drawn by the request we waited for
        $slot = null;
        for ($i = 0; $i < 2 && !$slot; $i++) { $f = @fopen(SHARES . '/draw-slot-' . $i . '.lock', 'c'); if ($f && flock($f, LOCK_EX | LOCK_NB)) $slot = $f; elseif ($f) fclose($f); }
        if (!$slot) { $slot = @fopen(SHARES . '/draw-slot-' . (crc32($id) % 2) . '.lock', 'c'); if ($slot) flock($slot, LOCK_EX); }
        $tmp = SHARES . '/' . $id . '.tmp' . getmypid() . bin2hex(random_bytes(3)) . '.jpg';
        try { draw_card($rec, $tmp, $id); } finally { if ($slot) { flock($slot, LOCK_UN); fclose($slot); } }
        if (!is_file($tmp) || !filesize($tmp) || !rename($tmp, $out)) { @unlink($tmp); return ''; }
        foreach (glob(SHARES . '/' . $id . '.*') ?: [] as $f) if ($f !== $out && preg_match('/\.(png|jpg)$/', $f) && strpos($f, '.tmp') === false) @unlink($f);   // older looks
        return $out;
    } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }   // the .lock file stays (removing it could let a third request draw too); cron clears old ones
}
//MC 2026-10-15 a card that couldn't be drawn used to answer 503. X and Telegram keep a failed picture for that link
//   for days, so the post showed a broken preview long after the card was fine. Now they get the game's own preview
//   picture instead (never cached), and the next fetch of a new link gets the real card.
function share_fail() {
    $f = dirname(__DIR__) . '/assets/art/og-play.png';
    header('Cache-Control: no-store');
    if (!is_file($f)) { http_response_code(503); header('Retry-After: 5'); exit; }
    header('Content-Type: image/png'); header('Content-Length: ' . filesize($f));
    readfile($f); exit;
}
function share_img_url($id) { return SITE . '/api/share.php?i=' . $id . '&v=' . SHARE_LOOK; }
//MC 2026-10-10 card pools for the share card art (see share_card_pick; top-level consts must sit above the exits)
const SHARE_POOLS = [
    'win'  => ['space', 'empire', 'reinforce', 'rebellion', 'awakening', 'galactic', 'era', 'galconsp', 'atlantis', 'stronghold', 'coop', 'surge'],
    'tie'  => ['tides', 'coop', 'irondome', 'quantum', 'cern', 'stronghold', 'atlantis', 'decoy', 'bunker'],
    'loss' => ['flood', 'meteor', 'blackhole', 'nuclear', 'ww3', 'winter', 'plasma', 'extinction', 'alien', 'unicoup', 'superweapon', 'drones'],
];
// which mask a bot persona wears on the machine-victory card (?bw=), mirrored from PERSONAS in assets/game.js
//   (a new persona falls back by name hash). Sits up here with SHARE_POOLS: top-level consts must sit above the exits.
const BOT_MASKS = ['Neon Ronin' => 'ronin', 'Iron Monk' => 'monk', 'Paper Tiger' => 'tiger', 'Night Crane' => 'crane', 'Jade Fox' => 'kitsune', 'Silent Oni' => 'oni',
    'Ash Kitsune' => 'kitsune', 'Velvet Shogun' => 'ronin', 'Static Monk' => 'monk', 'Copper Crane' => 'crane', 'Hollow Ronin' => 'ronin',
    'Rain Tiger' => 'tiger', 'Ember Oni' => 'oni', 'Glass Fox' => 'kitsune', 'Midnight Heron' => 'crane', 'Cobalt Samurai' => 'ronin',
    'Lantern Monk' => 'monk', 'Golden Tanuki' => 'kitsune', 'Thunder Kappa' => 'oni', 'Frost Ninja' => 'ronin', 'Red Daruma' => 'monk',
    'Shadow Tengu' => 'oni', 'Ivory Tiger' => 'tiger', 'Obsidian Crane' => 'crane', 'Moon Kitsune' => 'kitsune', 'Storm Oni' => 'oni',
    'Rust Shogun' => 'ronin', 'Smoke Daimyo' => 'ronin', 'Silk Viper' => 'tiger', 'Ghost Lantern' => 'monk', 'Willow Sage' => 'monk',
    'Koi Ronin' => 'ronin', 'Dusk Tiger' => 'tiger', 'Paper Crane' => 'crane'];
//MC 2026-10-13 the mask a victory card draws: the custom one from Admin > Card art > Bot masks when there is one,
//   else the stock drawing that ships with the site
function mask_card_img($key) {
    $custom = DATA_DIR . '/masks/av-' . $key . '.png';
    if (is_file($custom)) { $im = @imagecreatefrompng($custom); if ($im) return $im; }
    return @imagecreatefrompng(__DIR__ . '/share/av-' . $key . '.png');
}
function clean_label($s) {
    $s = trim(preg_replace('/\s+/', ' ', (string)$s));
    $s = preg_replace('/[^A-Za-z0-9 #._\'()\-]/', '', $s);
    $s = mb_substr($s, 0, 20);
    $low = strtolower(preg_replace('/[^a-z0-9]/i', '', $s));
    foreach (['fuck', 'shit', 'bitch', 'cunt', 'nigg', 'fag', 'rape', 'nazi', 'hitler', 'porn', 'slut', 'whore', 'dick', 'pussy', 'retard'] as $b) if (strpos($low, $b) !== false) return 'Player';
    return $s !== '' ? $s : 'Player';
}

// ---------- create ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    if (($body['a'] ?? '') !== 'create') fail('unknown action');
    $pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
    $kind = in_array($body['kind'] ?? '', ['solo', 'daily', 'live'], true) ? $body['kind'] : 'solo';
    $result = in_array($body['result'] ?? '', ['win', 'tie', 'loss'], true) ? $body['result'] : 'loss';
    $owners = (string)($body['owners'] ?? '');
    if (!preg_match('/^[0-3og]{' . count(REGIONS) . '}$/', $owners)) fail('bad map');
    $standings = [];
    foreach (array_slice((array)($body['standings'] ?? []), 0, 4) as $row) {
        $standings[] = ['n' => clean_label($row['n'] ?? ''), 'r' => max(0, min(count(REGIONS), (int)($row['r'] ?? 0))), 'c' => max(0, min(3, (int)($row['c'] ?? 0))), 'me' => !empty($row['me'])];
    }
    $mask = in_array($body['mask'] ?? '', MASKS, true) ? $body['mask'] : 'unbound';
    $rec = ['kind' => $kind, 'result' => $result, 'regions' => max(0, min(count(REGIONS), (int)($body['regions'] ?? 0))),
        'mode' => ($body['mode'] ?? '') === 'easy' ? 'easy' : 'normal', 'daily' => max(0, min(99999, (int)($body['dailyNo'] ?? 0))),
        'humans' => max(1, min(4, (int)($body['humans'] ?? 1))), 'rounds' => preg_replace('/[^uds]/', '', substr((string)($body['rounds'] ?? ''), 0, 12)),
        'name' => clean_label($body['name'] ?? 'Player'), 'owners' => $owners, 'standings' => $standings, 'ts' => time()];
    //MC 2026-10-10 optional: the card that won it, shown on the share card when the game sends it (else one is picked)
    if (isset($body['card']) && is_string($body['card']) && isset(CARDS[$body['card']])) $rec['card'] = $body['card'];
    //MC 2026-10-12 a boss match: the headline and mode line name the Shogun instead of reading like a lobby of strangers
    if (!empty($body['boss'])) $rec['boss'] = true;
    //MC 2026-10-11 any Shadow / $SHY lookup that's due happens here, before the lock (see holder_prefetch)
    if (is_string($pid) && preg_match('/^[a-f0-9]{16}$/', $pid) && is_string($key)) holder_prefetch($pid, false, hash('sha256', $key));
    //MC 2026-10-11 numbers that can't come from a real game are turned away: your own row has to show the Regions on the
    //   card, the table can't hold more Regions than the map, and the map has to show at least that many owned.
    $mine = array_values(array_filter($standings, fn($r) => $r['me']));
    if (($mine && $mine[0]['r'] !== $rec['regions']) || array_sum(array_column($standings, 'r')) > count(REGIONS) || preg_match_all('/[0-3]/', $owners) < $rec['regions']) fail("That result doesn't add up, so no card was made.", 422);
    $res = with_lock(function () use ($pid, $key, $body, $rec, $mask) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'share:' . client_ip(), 60, 3600)) { save(LIMITS, $limits); return null; }
        save(LIMITS, $limits);
        // a Shadow on the card only if this player really holds it (and really is this player)
        $players = load(PLAYERS);
        $holders = load(HOLDERS); $kh = hash('sha256', $key);
        $known = (bool)keys_known($pid, $players, $holders);
        $owns = $known && key_ok($pid, $kh, $players, $holders);
        //MC 2026-10-11 a card is made only for the signed-in player, and only for a result the server has seen. Anyone
        //   could make a card with any name and an impossible score on our domain (the audit made "Kenji22: Took the
        //   world. 40 Regions"). Now: a known profile needs its own key; the name on the card is the profile's saved name
        //   (a guest who never saved one shows as Player); a live match has to be in the player's game history; a Daily
        //   needs this player's Daily today (on the board, in their history, or a Daily started with their key). Solo
        //   cards are made as the end screen opens, before the score is saved, so for them the checks above have to do.
        if ($known && !$owns) return ['err' => 'not your profile', 'code' => 403];
        $rec['name'] = $owns && ($players[$pid]['name'] ?? '') !== '' ? clean_label($players[$pid]['name']) : ($owns ? $rec['name'] : 'Player');
        $seen = false;
        //MC 2026-10-12 the window was a day, which blocked sharing an older match from the profile's All matches list. The
        //   history holds 25 trusted entries the server itself wrote, so a 30-day window is no weaker, just more useful.
        foreach ($owns ? array_slice($players[$pid]['hist'] ?? [], 0, 25) : [] as $h)
            if ((int)($h['t'] ?? 0) > time() - 30 * 86400 && ($h['r'] ?? '') === $rec['result'] && (int)($h['g'] ?? -1) === $rec['regions'] && (($h['m'] ?? '') === 'live') === ($rec['kind'] === 'live') && (($h['m'] ?? '') === 'daily' || $rec['kind'] !== 'daily')) { $seen = true; break; }
        //MC 2026-10-13 a Shogun win can also be vouched for by the Shogun's own record: wins from before boss matches were
        //   written to hist live only there, and the profile shows them from it, so their share button has to work too
        if (!$seen && $owns && !empty($rec['boss']) && $rec['result'] === 'win')
            foreach (load(DATA_DIR . '/boss.php')['recent'] ?? [] as $x)
                if (($x['pid'] ?? '') === $pid && (int)$x['r'] === $rec['regions'] && (int)($x['t'] ?? 0) > time() - 30 * 86400) { $seen = true; break; }
        if ($rec['kind'] === 'live' && !$seen) return ['err' => "That match isn't on your record, so no card was made.", 'code' => 409];
        if ($rec['kind'] === 'daily' && !$seen) {
            $day = today(); $ok = isset(load(DATA_DIR . '/daily.php')[$day][$pid]);
            if (!$ok && $owns) foreach (load(TOKENS) as $t) if (($t['day'] ?? '') === $day && ($t['dp'] ?? '') === $pid) { $ok = true; break; }
            if (!$ok) return ['err' => "Today's Daily isn't on your record, so no card was made.", 'code' => 409];
        }
        [$avatar, $holder] = $owns ? verified_avatar($pid, (string)($body['avatar'] ?? '')) : ['', false];
        $rec['avatar'] = $avatar; $rec['holder'] = $holder; $rec['mask'] = $mask;
        $rec['aura'] = $avatar && $holder ? shadow_aura($avatar) : '';
        // a Daily card opens the replay of this run
        if ($owns && $rec['kind'] === 'daily') $rec['rp'] = today() . ':' . substr($pid, 0, 6);
        // the player's share card theme from the shop, if they own and wear one
        $rec['theme'] = '';
        if ($owns) {
            $eco = load(ECO);
            if (isset($eco[$pid])) {
                $acc = eco_get($eco, $pid); $id = $acc['eq']['share'] ?? '';
                if ($id && isset(eco_owned($acc, holder_tier($holders[$pid] ?? null))[$id])) $rec['theme'] = substr($id, 6);
                // a holder's Shadow wears its aura colour, and a Halo if they bought one
                $hl = $acc['eq']['halo'] ?? '';
                if ($avatar && $hl && isset(eco_owned($acc, holder_tier($holders[$pid] ?? null))[$hl])) $rec['halo'] = substr($hl, 5);
                // a Shadow skin stands in for the Unbound hood (a real Shadow always comes first)
                $sk = $acc['eq']['skin'] ?? '';
                if (!$avatar && $sk && isset(eco_owned($acc, holder_tier($holders[$pid] ?? null))[$sk]) && is_file(__DIR__ . '/share/av-' . $sk . '.png')) { $rec['skin'] = $sk; $rec['skinName'] = eco_item($sk)['name']; }
            }
        }
        if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
        //MC 2026-10-11 the 60-day cleanup of old cards moved to cron.php (share_prune); it scanned the whole folder inside the lock
        $id = substr(bin2hex(random_bytes(6)), 0, 10);
        file_put_contents(share_file($id, 'json'), json_encode($rec));
        track('shares');
        // a player's latest win (or Daily run) is the picture on their public page's link preview
        if ($owns && isset($players[$pid]) && ($rec['kind'] === 'daily' || $rec['result'] === 'win')) { $pl = load(PLAYERS); if (isset($pl[$pid])) { $pl[$pid]['lsh'] = $id; save(PLAYERS, $pl); } }
        // a win or a Daily run posted to the Telegram chat goes out with this card
        //MC 2026-10-13 a boss card never pairs with a live match post (same kind, very different picture)
        if ($owns && ($rec['kind'] === 'daily' || $rec['result'] === 'win')) tg_pend_card($pid, $rec['kind'] === 'live' && !empty($rec['boss']) ? 'boss' : $rec['kind'], $id);
        return $id;
    });
    if (is_array($res)) fail($res['err'], $res['code']);
    if (!$res) fail('Slow down a little and try again.', 429);
    //MC 2026-10-13 the card is drawn now, not on its first view. X posts went out with no card: the crawler was the first
    //   visitor, paid for the whole draw on shared hosting, timed out and cached the post as card-less. Drawing here means
    //   every crawler hit serves a finished file. If the draw fails the ?i= route still draws on demand as before.
    $made = json_decode((string)@file_get_contents(share_file($res, 'json')), true);
    if ($made) @share_draw_once($made, share_jpg($res), $res);
    out(['ok' => true, 'id' => $res, 'url' => SITE . '/s/' . $res, 'img' => share_img_url($res)]);
}

//MC 2026-10-12 the profile card: the link preview for shyonsol.io/p/<name> shows who the player is (their Shadow, title,
//   House, rank, motto, record and the card they're known for) instead of the last game they shared. ?p=<6-letter id>.
//   Drawn once per version of the profile: the hash of what's on it is in the file name and in the address player.php
//   puts in the preview, so a new rank or motto gives a new picture and X/Telegram fetch it fresh.
//MC 2026-10-12 ?b=1: the Shogun card (boss_card_data in bosslib.php), drawn once per version and kept as boss-<hash>.jpg
//MC 2026-10-14 ?c=<card>: the promo card for one Chaos card, built for the hype posts on X. The card sits framed on
//   the woodblock paper exactly as it does on a result card, with a hype line, the card's own effect text and a
//   vermilion PLAY IT FREE stamp. Drawn once per look and per published art, so X always unfurls a finished file.
const CARDPROMO_LOOK = 'c2';   //MC 2026-10-14 c2: the win-card footer signature
if (isset($_GET['c'])) {
    $cid = (string)$_GET['c'];
    if (!preg_match('/^[a-z0-9]{2,30}$/', $cid) || !isset(CARDS[$cid]) || (CARDS[$cid]['n'] ?? 0) < 1) { http_response_code(404); exit; }
    $db = load(DATA_DIR . '/card-art.php');
    $h = substr(sha1(CARDPROMO_LOOK . '|' . ($db[$cid]['live']['f'] ?? '') . '|' . card_effect($cid)), 0, 10);
    $out = SHARES . '/cardp-' . $cid . '-' . $h . '.jpg';
    if (!is_file($out)) {
        if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
        $lf = @fopen(SHARES . '/cardp-' . $cid . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_cardpromo($cid, $tmp);
                if (is_file($tmp) && filesize($tmp) && rename($tmp, $out)) { foreach (glob(SHARES . '/cardp-' . $cid . '-*.jpg') ?: [] as $f) if ($f !== $out && strpos($f, '.tmp') === false) @unlink($f); }
                else @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}

//MC 2026-10-14 ?hp=<tag>&v=1..3: a player's own hype card, the picture under the posts the profile page writes for them.
//   Same woodblock stock as the card promos, but about the player: their Shadow, their name, a headline per angle (the
//   record, the signature card, the climb) and the tiles that back the boast. Drawn once per look, angle and state of
//   the record (pc_hash), so X always unfurls a finished file and a changed record gets a fresh picture.
const PLAYERHYPE_LOOK = 'h1';
if (isset($_GET['hp'])) {
    require_once __DIR__ . '/houselib.php';
    $tag = (string)$_GET['hp'];
    $v = max(1, min(3, (int)($_GET['v'] ?? 1)));
    if (!preg_match('/^[a-f0-9]{6}$/', $tag)) { http_response_code(404); exit; }
    $prec = pc_record($tag);
    if (!$prec) { http_response_code(404); exit; }
    $h = substr(sha1(pc_hash($prec) . '|' . $v . '|' . PLAYERHYPE_LOOK), 0, 10);
    $out = SHARES . '/hype-' . $tag . '-' . $v . '-' . $h . '.jpg';
    if (!is_file($out)) {
        if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
        $lf = @fopen(SHARES . '/hype-' . $tag . '-' . $v . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_playerhype($prec, $v, $tmp);
                if (is_file($tmp) && filesize($tmp) && rename($tmp, $out)) { foreach (glob(SHARES . '/hype-' . $tag . '-' . $v . '-*.jpg') ?: [] as $f) if ($f !== $out && strpos($f, '.tmp') === false) @unlink($f); }
                else @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}

if (isset($_GET['b'])) {
    require_once __DIR__ . '/bosslib.php';
    $bd = boss_card_data();
    $out = SHARES . '/boss-' . $bd['h'] . '.jpg';
    if (!is_file($out)) {
        if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
        $lf = @fopen(SHARES . '/boss.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_boss($bd, $tmp);
                if (is_file($tmp) && filesize($tmp) && rename($tmp, $out)) { foreach (glob(SHARES . '/boss-*.jpg') ?: [] as $f) if ($f !== $out && strpos($f, '.tmp') === false) @unlink($f); }
                else @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}
//MC 2026-10-15 ?nj= / ?nh= / ?tw=: the cards under the Telegram hype posts (tg_join, tg_nft, tg_trophy in tg.php write the
//   record). A new player gets a dawn on washi paper, a Shadow holder the night and their Shadow's own Aura, a trophy the
//   gold of a display case. Drawn once and kept, like the bot-win card.
//MC 2026-10-16 ?nm=: the card under the Telegram post for a newly minted Shadow (mt_announce in mints.php)
foreach (['nj' => ['join', 'draw_join'], 'nh' => ['holdr', 'draw_holdr'], 'tw' => ['troph', 'draw_trophy'], 'mc' => ['match', 'draw_match'], 'nm' => ['mintc', 'draw_mintc'], 'ne' => ['expfd', 'draw_expfd'], 'nb' => ['offr', 'draw_offr'], 'nk' => ['burnc', 'draw_burnc'], 'ns' => ['swapc', 'draw_swapc']] as $q => [$pre, $drawFn]) if (isset($_GET[$q])) {
    $cid = (string)$_GET[$q];
    if (!preg_match('/^[a-f0-9]{10}$/', $cid)) { http_response_code(404); exit; }
    $crec = json_decode((string)@file_get_contents(SHARES . '/' . $pre . '-' . $cid . '.json'), true);
    if (!$crec || empty($crec['n'])) { http_response_code(404); exit; }
    $out = SHARES . '/' . $pre . '-' . $cid . '.jpg';
    if (!is_file($out)) {
        $lf = @fopen(SHARES . '/' . $pre . '-' . $cid . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                $drawFn($crec, $tmp);
                if (!is_file($tmp) || !filesize($tmp) || !rename($tmp, $out)) @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); @unlink(SHARES . '/' . $pre . '-' . $cid . '.lock'); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=604800');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}
//MC 2026-10-13 ?bw=<id>: the machine-victory card for a live match a bot won (tg_botwin_img writes the record when the
//   post goes out). Drawn once and kept as botwin-<id>.jpg; the id is the hash of what's on it, so Telegram always gets
//   a finished file. Deliberately styled nothing like a player's card: cold steel instead of warm paper.
if (isset($_GET['bw'])) {
    $bid = (string)$_GET['bw'];
    if (!preg_match('/^[a-f0-9]{10}$/', $bid)) { http_response_code(404); exit; }
    $brec = json_decode((string)@file_get_contents(SHARES . '/botwin-' . $bid . '.json'), true);
    if (!$brec || empty($brec['w'])) { http_response_code(404); exit; }
    $out = SHARES . '/botwin-' . $bid . '.jpg';
    if (!is_file($out)) {
        $lf = @fopen(SHARES . '/botwin-' . $bid . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_botwin($brec, $tmp);
                if (!is_file($tmp) || !filesize($tmp) || !rename($tmp, $out)) @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}
//MC 2026-10-13 ?sw=<id>: the Shogun's victory card for a boss match it won or drew (tg_shogun_img writes the record).
//   Drawn once and kept as shwin-<id>.jpg. Warm lacquer and gold, the Shogun's own look, nothing like the cold bot card.
if (isset($_GET['sw'])) {
    $sid = (string)$_GET['sw'];
    if (!preg_match('/^[a-f0-9]{10}$/', $sid)) { http_response_code(404); exit; }
    $srec = json_decode((string)@file_get_contents(SHARES . '/shwin-' . $sid . '.json'), true);
    if (!$srec || !isset($srec['mine'])) { http_response_code(404); exit; }
    $out = SHARES . '/shwin-' . $sid . '.jpg';
    if (!is_file($out)) {
        $lf = @fopen(SHARES . '/shwin-' . $sid . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_shogunwin($srec, $tmp);
                if (!is_file($tmp) || !filesize($tmp) || !rename($tmp, $out)) @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}
if (isset($_GET['p'])) {
    require_once __DIR__ . '/houselib.php';
    $tag = (string)$_GET['p'];
    if (!preg_match('/^[a-f0-9]{6}$/', $tag)) { http_response_code(404); exit; }
    $prec = pc_record($tag);
    if (!$prec) { http_response_code(404); exit; }
    $h = pc_hash($prec);
    $out = SHARES . '/pc-' . $tag . '-' . $h . '.jpg';
    if (!is_file($out)) {
        $f = share_draw_profile_once($prec, $out, 'pc-' . $tag);
        if ($f === '') { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=3600');
    header('Content-Length: ' . filesize($out));
    readfile($out);
    exit;
}
//MC 2026-10-15 a release's own card (?rl=<version>), for the X release posts in admin and the /r/ links (api/relpage.php).
//   Drawn once per release and look, then served from the shares folder.
const RELEASE_LOOK = 'r4';
function release_find($v) {
    $f = __DIR__ . '/lib/releases-all.php';
    foreach ((is_file($f) ? (array)(require $f) : []) as $r) if (($r['v'] ?? '') === $v) return $r;
    return null;
}
if (isset($_GET['rl'])) {
    $v = (string)$_GET['rl'];
    $rel = preg_match('/^[a-z0-9]{2,24}$/', $v) ? release_find($v) : null;
    if (!$rel) { http_response_code(404); exit; }
    $out = SHARES . '/rel-' . $v . '-' . RELEASE_LOOK . '-' . substr(sha1(json_encode($rel)), 0, 8) . '.jpg';
    if (!is_file($out)) {
        if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
        $lf = @fopen(SHARES . '/rel-' . $v . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
        try {
            if (!is_file($out)) {
                $tmp = $out . '.tmp' . getmypid() . '.jpg';
                draw_release($rel, $tmp);
                if (is_file($tmp) && filesize($tmp) && rename($tmp, $out)) { foreach (glob(SHARES . '/rel-' . $v . '-*.jpg') ?: [] as $f) if ($f !== $out && strpos($f, '.tmp') === false) @unlink($f); }
                else @unlink($tmp);
            }
        } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
        if (!is_file($out)) { share_fail(); }
    }
    header('Content-Type: image/jpeg');
    header('Cache-Control: public, max-age=86400');
    header('Content-Length: ' . filesize($out));
    if (isset($_GET['dl'])) header('Content-Disposition: attachment; filename="shilluminati-update-' . $v . '.jpg"');
    readfile($out);
    exit;
}

$id = (string)($_GET['s'] ?? $_GET['i'] ?? '');
if (!preg_match('/^[a-f0-9]{10}$/', $id) || !is_file(share_file($id, 'json'))) {
    // a dead or mistyped share link is a real "not found" (search engines drop it), shown as the site's own 404 page
    http_response_code(404);
    if (isset($_GET['s'])) { header('Content-Type: text/html; charset=utf-8'); header('X-Robots-Tag: noindex'); @readfile(dirname(__DIR__) . '/404.html'); }
    exit;
}
$rec = json_decode(file_get_contents(share_file($id, 'json')), true);

function headline($rec) {
    if (!empty($rec['boss'])) return $rec['result'] === 'win' ? 'Beat the Shogun.' : ($rec['result'] === 'tie' ? 'Matched the Shogun.' : 'Faced the Shogun.');
    return $rec['result'] === 'win' ? 'Took the world.' : ($rec['result'] === 'tie' ? 'Split the world.' : 'Fought for the world.');
}
function mode_label($rec) {
    if (!empty($rec['boss'])) return 'Boss match vs the Shogun';
    if ($rec['kind'] === 'daily') return 'Daily Challenge #' . $rec['daily'];
    if ($rec['kind'] === 'live') return 'Live match' . ($rec['humans'] > 1 ? ' vs ' . ($rec['humans'] - 1) . ' real ' . ($rec['humans'] === 2 ? 'player' : 'players') : '');
    return 'Solo game, ' . ($rec['mode'] === 'easy' ? 'Easy' : 'Normal');
}

// ---------- share page (what X reads for the preview) ----------
if (isset($_GET['s'])) {
    header('Content-Type: text/html; charset=utf-8');
    $title = htmlspecialchars($rec['name'] . ': ' . headline($rec) . ' ' . $rec['regions'] . ' Regions', ENT_QUOTES);
    $desc = htmlspecialchars(mode_label($rec) . ' in Shilluminati Online, the $SHY card game. Free to play at shyonsol.io.', ENT_QUOTES);
    $img = htmlspecialchars(share_img_url($id), ENT_QUOTES);
    $alt = htmlspecialchars($rec['name'] . ' ' . strtolower(rtrim(headline($rec), '.')) . ' with ' . $rec['regions'] . ' Regions in Shilluminati Online', ENT_QUOTES);
    $go = SITE . '/play?ref=share' . (!empty($rec['rp']) && preg_match('/^\d{4}-\d{2}-\d{2}:[a-f0-9]{6}$/', $rec['rp']) ? '&replay=' . $rec['rp'] : '');
    //MC 2026-10-13 people move on to the game by script (and the link for anyone without it), never by meta refresh:
    //   Telegram's preview bot follows a refresh, so shared cards unfurled as the plain play page instead of the card
    echo "<!doctype html><html><head><meta charset=\"utf-8\"><title>$title</title>
<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<meta property=\"og:type\" content=\"website\"><meta property=\"og:site_name\" content=\"Shy on Solana\">
<meta property=\"og:title\" content=\"$title\"><meta property=\"og:description\" content=\"$desc\">
<meta property=\"og:image\" content=\"$img\"><meta property=\"og:image:width\" content=\"1200\"><meta property=\"og:image:height\" content=\"630\"><meta property=\"og:image:alt\" content=\"$alt\">
<meta property=\"og:url\" content=\"" . SITE . "/s/$id\">
<meta name=\"twitter:card\" content=\"summary_large_image\"><meta name=\"twitter:site\" content=\"@ShyOnSol_\">
<meta name=\"twitter:title\" content=\"$title\"><meta name=\"twitter:description\" content=\"$desc\"><meta name=\"twitter:image\" content=\"$img\"><meta name=\"twitter:image:alt\" content=\"$alt\">
<style>body{margin:0;background:#efe3c8;color:#1c1510;font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:100vh}a{color:#c42a1f}</style>
</head><body><p><a href=\"$go\">Opening Shilluminati Online...</a></p><script>location.replace(" . json_encode($go) . ");</script></body></html>";
    exit;
}

// ---------- the image ----------
//MC 2026-10-10 the image is cached under the look's version (SHARE_LOOK), so moving to the woodblock cards redraws every
//   old share once on its next view instead of serving the neon picture forever. The old file is removed when the new
//   one is drawn. Within one look a card is still drawn once, so cards shared before a map change keep their picture.
//MC 2026-10-11 three changes. (1) The card is drawn into a temp file and renamed into place, so a request arriving
//   mid-draw never gets half a picture (the audit saw 24 KB and 65 KB responses cached for a week). (2) One draw per card:
//   requests for the same card wait on its lock and then serve the finished file, and at most two cards are drawn at
//   once on the whole site. (3) New cards are JPEG at quality 88: about 230 KB instead of 0.6 to 1 MB as PNG, with no
//   visible difference in the X or Telegram preview (checked side by side). Cards already drawn as PNG keep being served.
$png = share_png($id); $jpg = share_jpg($id);
$file = is_file($jpg) ? $jpg : (is_file($png) ? $png : '');
if ($file === '') $file = share_draw_once($rec, $jpg, $id);
if ($file === '' || !is_file($file)) { share_fail(); }
header('Content-Type: ' . (substr($file, -4) === '.jpg' ? 'image/jpeg' : 'image/png'));
header('Cache-Control: public, max-age=604800');
header('Content-Length: ' . filesize($file));
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($file)) . ' GMT');
readfile($file);
exit;

function hexcol($im, $hex, $alpha = 0) {
    $hex = ltrim($hex, '#');
    return imagecolorallocatealpha($im, hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)), $alpha);
}
function text($im, $size, $x, $y, $col, $font, $s) { imagettftext($im, $size, 0, (int)$x, (int)$y, $col, __DIR__ . '/share/' . $font, $s); }
function text_w($size, $font, $s) { $b = imagettfbbox($size, 0, __DIR__ . '/share/' . $font, $s); return $b[2] - $b[0]; }
function fit_size($start, $min, $font, $s, $maxW) { $z = $start; while ($z > $min && text_w($z, $font, $s) > $maxW) $z -= 2; return $z; }
function rounded_copy($dst, $src, $x, $y, $size, $radius) {
    $tile = imagecreatetruecolor($size, $size);
    imagealphablending($tile, false); imagesavealpha($tile, true);
    imagecopyresampled($tile, $src, 0, 0, 0, 0, $size, $size, imagesx($src), imagesy($src));
    $clear = imagecolorallocatealpha($tile, 0, 0, 0, 127);
    for ($py = 0; $py < $size; $py++) for ($px = 0; $px < $size; $px++) {
        $cx = $px < $radius ? $radius : ($px >= $size - $radius ? $size - $radius - 1 : $px);
        $cy = $py < $radius ? $radius : ($py >= $size - $radius ? $size - $radius - 1 : $py);
        if (($px - $cx) ** 2 + ($py - $cy) ** 2 > $radius * $radius) imagesetpixel($tile, $px, $py, $clear);
    }
    imagealphablending($dst, true);
    imagecopy($dst, $tile, $x, $y, 0, 0, $size, $size);
}
function avatar_image($rec) {
    if (!empty($rec['avatar'])) {
        $url = shadow_img($rec['avatar']);
        $cache = SHARES . '/nft-' . preg_replace('/\D/', '', $rec['avatar']) . '.img';
        if ($url && !is_file($cache)) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 8, CURLOPT_MAXFILESIZE => 6000000]);
            $data = curl_exec($ch); curl_close($ch);
            if ($data && @imagecreatefromstring($data)) { $t = $cache . '.tmp' . getmypid(); if (file_put_contents($t, $data) === strlen($data)) rename($t, $cache); else @unlink($t); }   //MC 2026-10-11 whole or not at all
        }
        if (is_file($cache)) { $im = @imagecreatefromstring(file_get_contents($cache)); if ($im) return $im; }
    }
    if (!empty($rec['skin']) && preg_match('/^skin_[a-z]+$/', $rec['skin']) && is_file(__DIR__ . '/share/av-' . $rec['skin'] . '.png')) return imagecreatefrompng(__DIR__ . '/share/av-' . $rec['skin'] . '.png');
    return imagecreatefrompng(__DIR__ . '/share/av-' . (in_array($rec['mask'] ?? '', MASKS, true) ? $rec['mask'] : 'unbound') . '.png');
}
//MC 2026-10-10 the map is drawn in the woodblock palette of the card's theme ($pal: four player colours, open, gone, edge).
//   It used to be the neon purple of the old cards.
function draw_map($im, $rec, $x0, $y0, $w, $h, $pal) {
    $map = json_decode(file_get_contents(dirname(__DIR__) . '/assets/map.json'), true);
    $ss = 2;  // draw at double size, then shrink for smooth edges
    $W = $w * $ss; $H = $h * $ss;
    $c = imagecreatetruecolor($W, $H);
    imagealphablending($c, false); imagesavealpha($c, true);
    imagefill($c, 0, 0, imagecolorallocatealpha($c, 0, 0, 0, 127));
    imagealphablending($c, true);
    $scale = min($W / $map['w'], $H / $map['h']);
    $ox = ($W - $map['w'] * $scale) / 2; $oy = ($H - $map['h'] * $scale) / 2;
    $cols = [hexcol($c, $pal['p'][0]), hexcol($c, $pal['p'][1]), hexcol($c, $pal['p'][2]), hexcol($c, $pal['p'][3])];
    $open = hexcol($c, $pal['open']); $gone = hexcol($c, $pal['gone']); $edge = hexcol($c, $pal['edge']); $mine = hexcol($c, $pal['mine']);
    foreach (REGIONS as $i => $name) {
        $o = $rec['owners'][$i] ?? 'o';
        $fill = $o === 'o' ? $open : ($o === 'g' ? $gone : $cols[(int)$o]);
        if (empty($map['regions'][$name]['d'])) continue;
        preg_match_all('/M([^M]+)/', $map['regions'][$name]['d'], $subs);
        foreach ($subs[1] as $sp) {
            preg_match_all('/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/', $sp, $m, PREG_SET_ORDER);
            if (count($m) < 3) continue;
            $pts = [];
            foreach ($m as $pt) { $pts[] = (int)round($ox + $pt[1] * $scale); $pts[] = (int)round($oy + $pt[2] * $scale); }
            imagefilledpolygon($c, $pts, $fill);
            imagesetthickness($c, $o === '0' ? 4 : 2);
            imagepolygon($c, $pts, $o === '0' ? $mine : $edge);
        }
    }
    imagealphablending($im, true);
    imagecopyresampled($im, $c, $x0, $y0, 0, 0, $w, $h, $W, $H);
}
// a rounded square outline, $t pixels thick
function rounded_ring($im, $x, $y, $size, $r, $col, $t) {
    imagesetthickness($im, 1);
    for ($i = 0; $i < $t; $i++) {
        $X = $x + $i; $Y = $y + $i; $S = $size - 2 * $i; $R = max(2, $r - $i); $d = 2 * $R;
        imageline($im, $X + $R, $Y, $X + $S - $R, $Y, $col); imageline($im, $X + $R, $Y + $S, $X + $S - $R, $Y + $S, $col);
        imageline($im, $X, $Y + $R, $X, $Y + $S - $R, $col); imageline($im, $X + $S, $Y + $R, $X + $S, $Y + $S - $R, $col);
        imagearc($im, $X + $R, $Y + $R, $d, $d, 180, 270, $col); imagearc($im, $X + $S - $R, $Y + $R, $d, $d, 270, 360, $col);
        imagearc($im, $X + $R, $Y + $S - $R, $d, $d, 90, 180, $col); imagearc($im, $X + $S - $R, $Y + $S - $R, $d, $d, 0, 90, $col);
    }
}
// capitals with a little air between them (GD has no letter spacing of its own); returns the width drawn
function text_spaced($im, $size, $x, $y, $col, $font, $s, $gap) {
    $x0 = $x;
    foreach (preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) { text($im, $size, $x, $y, $col, $font, $ch); $x += text_w($size, $font, $ch) + ($ch === ' ' ? $size * .3 : 0) + $gap; }
    return $x - $x0 - $gap;
}
function spaced_w($size, $font, $s, $gap) { $w = 0; foreach (preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) $w += text_w($size, $font, $ch) + ($ch === ' ' ? $size * .3 : 0) + $gap; return $w - $gap; }
// a black PNG with soft edges (the brush stroke) laid down in any colour
function tinted_png($im, $file, $hex, $x, $y) {
    $p = @imagecreatefrompng($file); if (!$p) return;
    imagealphablending($p, false); imagesavealpha($p, true);
    [$r, $g, $b] = sscanf($hex, '#%02x%02x%02x');
    imagefilter($p, IMG_FILTER_COLORIZE, $r, $g, $b);
    imagealphablending($im, true);
    imagecopy($im, $p, $x, $y, 0, 0, imagesx($p), imagesy($p));
}

//MC 2026-10-10 the card art on a share card. The game doesn't say which card won it, so the card comes from a pool that
//   fits the result (a triumph for a win, a calm or a stand-off for a tie, a disaster for a loss), picked by the share id so
//   the same link always shows the same card. A 'card' saved on the share (if the game ever sends one) wins over the pool.
//   Cards with figures that read as real people are kept out of the pools on purpose.
function share_card_pick($rec, $id) {
    $db = load(DATA_DIR . '/card-art.php');
    $have = function ($k) use ($db) {
        $f = $db[$k]['live']['f'] ?? '';
        if (!preg_match('/^[a-z0-9]+-[a-f0-9]{8}\.(webp|jpg)$/', $f)) return '';
        foreach ([dirname(__DIR__) . '/card-art/' . $f, DATA_DIR . '/card-art-keep/' . $f] as $p) if (is_file($p)) return $p;
        return '';
    };
    $want = (string)($rec['card'] ?? '');
    if ($want !== '' && isset(CARDS[$want]) && ($p = $have($want))) return [$want, $p];
    $pool = SHARE_POOLS[$rec['result']] ?? SHARE_POOLS['win'];
    $n = count($pool); $start = crc32($id) % $n;
    for ($i = 0; $i < $n; $i++) { $k = $pool[($start + $i) % $n]; if (isset(CARDS[$k]) && ($p = $have($k))) return [$k, $p]; }
    return ['', ''];
}

//MC 2026-10-10 the woodblock look for the new card art: washi paper, a vermilion sun behind the card, a sumi brush stroke
//   under the Region count and a red 影 seal. Each shop theme is its own paper and ink (Hanami pink washi, War Banner red
//   with a black sun, Gilded gold leaf, Neon Tokyo night, Moonrise indigo with a moon, Archive Scroll old paper, Holder
//   Seal black lacquer and gold). The paper, sun and seal are baked images in share/wb-*; everything with data is drawn here.
function share_theme($th) {
    $base = ['bg' => 'wb-default.jpg', 'ink' => '#1c1510', 'muted' => '#6b5a48', 'acc' => '#c42a1f', 'win' => '#cf3426', 'tie' => '#2b4f86', 'loss' => '#1f1814',
        'on' => '#fbf1dc', 'mat' => '#f8efdb', 'line' => '#1c1510', 'seal' => 'wb-seal.png', 'tab' => '#1c1510', 'tabtx' => '#fbf1dc',
        'map' => ['p' => ['#cf3426', '#2b4f86', '#2f8a6e', '#d4952a'], 'open' => '#e3d3b1', 'gone' => '#4a3f36', 'edge' => '#f6ecd6', 'mine' => '#1c1510'],
        'up' => '#2f8a6e', 'down' => '#cf3426', 'same' => '#d4952a'];
    $dark = ['ink' => '#f7eedd', 'muted' => '#bfb2a0', 'mat' => '#efe4cc', 'line' => '#000000', 'tab' => '#f3e7cf', 'tabtx' => '#1c1510', 'loss' => '#5a4c40',
        'map' => ['p' => ['#e2452f', '#5b82c4', '#3fae8c', '#e2a93a'], 'open' => '#4a4150', 'gone' => '#17121a', 'edge' => '#100c12', 'mine' => '#fff6e4']];
    $t = [
        'sakura'  => ['bg' => 'wb-sakura.jpg', 'acc' => '#c23a5c', 'win' => '#d24467', 'ink' => '#2a1418', 'muted' => '#7b5a5f', 'map' => ['p' => ['#d24467', '#2b4f86', '#2f8a6e', '#d4952a'], 'open' => '#ecd2cf', 'gone' => '#4d3a3d', 'edge' => '#fbeeea', 'mine' => '#2a1418']],
        'crimson' => ['bg' => 'wb-crimson.jpg', 'acc' => '#ffd9a0', 'win' => '#16100d', 'tie' => '#16100d', 'loss' => '#16100d', 'muted' => '#f2c6b4', 'seal' => 'wb-seal-light.png',
                     'map' => ['p' => ['#16100d', '#f3e2c0', '#e9a23b', '#7a1612'], 'open' => '#c4473c', 'gone' => '#5e110d', 'edge' => '#8d1a15', 'mine' => '#fff6e4'], 'up' => '#f3e2c0', 'down' => '#16100d', 'same' => '#e9a23b'] + $dark,
        'gold'    => ['bg' => 'wb-gold.jpg', 'acc' => '#8f1d16', 'win' => '#a8231b', 'muted' => '#5e4520', 'map' => ['p' => ['#a8231b', '#1e3a66', '#1f6b55', '#f6e7b4'], 'open' => '#c7a253', 'gone' => '#3a2b14', 'edge' => '#ead391', 'mine' => '#1c1510']],
        'neon'    => ['bg' => 'wb-neon.jpg', 'acc' => '#3ff6ff', 'win' => '#ff2e63', 'tie' => '#2a7f9c', 'map' => ['p' => ['#ff2e63', '#3ff6ff', '#2ef0b0', '#ffd166'], 'open' => '#3a2f4a', 'gone' => '#120e18', 'edge' => '#0d0a12', 'mine' => '#ffffff'], 'up' => '#2ef0b0', 'down' => '#ff2e63', 'same' => '#ffd166'] + $dark,
        'moon'    => ['bg' => 'wb-moon.jpg', 'acc' => '#f3d38b', 'win' => '#c9452f', 'tie' => '#4a6db0', 'muted' => '#b9c0da', 'map' => ['p' => ['#e2552f', '#9db4ea', '#3fae8c', '#f3d38b'], 'open' => '#3a4670', 'gone' => '#0f1430', 'edge' => '#151c3c', 'mine' => '#fff6e4']] + $dark,
        'archive' => ['bg' => 'wb-archive.jpg', 'acc' => '#8e2a1a', 'win' => '#b4432b', 'ink' => '#2a1c10', 'muted' => '#6e5536', 'map' => ['p' => ['#b4432b', '#2c4a6e', '#3d7a5c', '#c68a2e'], 'open' => '#cdb184', 'gone' => '#4a3a26', 'edge' => '#ead8b2', 'mine' => '#2a1c10']],
        'holder'  => ['bg' => 'wb-holder.jpg', 'acc' => '#2ef0b0', 'win' => '#17785d', 'tie' => '#9c7526', 'loss' => '#4a443d', 'map' => ['p' => ['#d9b45c', '#2ef0b0', '#5b82c4', '#e2452f'], 'open' => '#33302c', 'gone' => '#0c0b0a', 'edge' => '#0a0908', 'mine' => '#fff6e4'], 'up' => '#2ef0b0', 'down' => '#e2452f', 'same' => '#d9b45c'] + $dark,
    ][$th] ?? [];
    return $t + $base;
}

function draw_card($rec, $out, $id = '') {
    $th = preg_match('/^[a-z]+$/', (string)($rec['theme'] ?? '')) && is_file(__DIR__ . '/share/wb-' . $rec['theme'] . '.jpg') ? $rec['theme'] : '';
    $T = share_theme($th);
    $im = imagecreatefromjpeg(__DIR__ . '/share/' . $T['bg']);
    if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    $ink = hexcol($im, $T['ink']); $muted = hexcol($im, $T['muted']); $acc = hexcol($im, $T['acc']);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';

    // ---- the card art, matted and framed, sitting on the sun (the shadow is baked into the paper)
    [$ck, $cpath] = share_card_pick($rec, $id);
    $px = 620; $py = 62; $pw = 520; $ph = 320; $mat = 8;
    imagefilledrectangle($im, $px - 2, $py - 2, $px + $pw + 1, $py + $ph + 1, hexcol($im, $T['line']));
    imagefilledrectangle($im, $px, $py, $px + $pw - 1, $py + $ph - 1, hexcol($im, $T['mat']));
    $art = $cpath ? @imagecreatefromstring((string)@file_get_contents($cpath)) : false;
    if ($art) {
        $aw = $pw - 2 * $mat; $ah = $ph - 2 * $mat;
        $sw = imagesx($art); $sh = imagesy($art);
        $k = max($aw / $sw, $ah / $sh); $cw = $aw / $k; $ch = $ah / $k;
        imagecopyresampled($im, $art, $px + $mat, $py + $mat, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $aw, $ah, (int)$cw, (int)$ch);
        imagerectangle($im, $px + $mat, $py + $mat, $px + $pw - $mat - 1, $py + $ph - $mat - 1, hexcol($im, '#000000', 90));
    }
    // the card's name on a tab hanging off the bottom of the frame
    if ($ck) {
        $kind = strtoupper(CARDS[$ck]['kind']); $cname = CARDS[$ck]['name'];
        $kc = ['ATTACK' => '#e2452f', 'GAIN' => '#3fae8c', 'DEFENSE' => '#5b82c4', 'GLOBAL' => '#e2a93a', 'TRICK' => '#b07ad8', 'PASSIVE' => '#9a9a9a'][$kind] ?? '#e2a93a';
        $kw = spaced_w(12, $B, $kind, 2); $nz = fit_size(19, 14, $D, $cname, 330); $nw = text_w($nz, $D, $cname);
        $tw = 18 + $kw + 14 + $nw + 18; $tx = $px + 22; $ty = $py + $ph - 16;
        imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $tw + 3, $ty + 40, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 36, hexcol($im, $T['tab']));
        imagefilledrectangle($im, $tx, $ty, $tx + 4, $ty + 36, hexcol($im, $kc));
        text_spaced($im, 12, $tx + 18, $ty + 24, hexcol($im, $kc), $B, $kind, 2);
        text($im, $nz, $tx + 18 + $kw + 14, $ty + 26, hexcol($im, $T['tabtx']), $D, $cname);
    }

    // ---- who: the Shadow in a matted frame, the name, what they played as
    $av = avatar_image($rec);
    $auc = ['cyan' => '#4cc9f0', 'crimson' => '#ff3b5c', 'lightning' => '#ffe066', 'money' => '#f2c35b', 'btc' => '#f7931a', 'none' => '#a78bfa'][$rec['aura'] ?? ''] ?? '';
    $ax = 60; $ay = 60; $as = 100;
    //MC 2026-10-10 the victory burst for a verified holder's win stays, now as ink-print rays in the Aura colour behind the frame
    if ($auc && $rec['result'] === 'win') {
        [$cr, $cg, $cb] = sscanf($auc, '#%02x%02x%02x');
        $cx = $ax + $as / 2; $cy = $ay + $as / 2;
        $ray = imagecolorallocatealpha($im, $cr, $cg, $cb, 70);
        for ($i = 0; $i < 16; $i++) {
            $a0 = deg2rad($i * 22.5 - 3); $a1 = deg2rad($i * 22.5 + 5);
            imagefilledpolygon($im, [(int)$cx, (int)$cy, (int)round($cx + cos($a0) * 104), (int)round($cy + sin($a0) * 104), (int)round($cx + cos($a1) * 104), (int)round($cy + sin($a1) * 104)], $ray);
        }
    }
    imagefilledrectangle($im, $ax - 8, $ay - 8, $ax + $as + 7, $ay + $as + 7, hexcol($im, $T['line']));
    imagefilledrectangle($im, $ax - 6, $ay - 6, $ax + $as + 5, $ay + $as + 5, hexcol($im, $auc ?: $T['mat']));
    rounded_copy($im, $av, $ax, $ay, $as, 4);
    if ($auc && !empty($rec['halo'])) rounded_ring($im, $ax - 14, $ay - 14, $as + 28, 6, hexcol($im, ['kami' => '#ffe29a', 'storm' => '#fff3a3', 'sakura' => '#ff9ec4', 'moon' => '#dbe3ff', 'shogun' => '#f2c35b'][$rec['halo']] ?? '#ffe29a'), 3);
    $z = fit_size(44, 24, $D, $rec['name'], 372);
    text($im, $z, 194, 104, $ink, $D, $rec['name']);
    $tag = !empty($rec['avatar']) ? 'Shadow #' . $rec['avatar'] . ($rec['holder'] ? '  ·  Verified holder' : '') : (!empty($rec['skinName']) ? $rec['skinName'] . '  ·  Shadow skin' : 'Unbound Shadow');
    text($im, fit_size(18, 13, $B, $tag, 372), 196, 140, !empty($rec['avatar']) ? $acc : $muted, $B, $tag);

    // ---- what happened: the mode as a small caps line, then the headline in mincho
    text_spaced($im, 15, 62, 214, $acc, $B, strtoupper(mode_label($rec)), 3);
    $head = headline($rec);
    $z = fit_size(58, 34, $M, $head, 520);
    text($im, $z, 58, 280, $ink, $M, $head);

    // ---- the Region count, in paper colour on a brush stroke (red for a win, indigo for a tie, sumi for a loss)
    tinted_png($im, __DIR__ . '/share/wb-brush.png', $T[$rec['result']] ?? $T['win'], 30, 304);
    $on = hexcol($im, $T['on']);
    $n = (string)$rec['regions'];
    text($im, 104, 70, 436, $on, $D, $n);
    $nw = text_w(104, $D, $n);
    //MC 2026-10-11 "of 40" sat low under "Regions" where the brush thins out, so on some cards it fell off the red. Both
    //   lines moved up into the thick middle of the stroke (tried "of 40" on the same line: that lands on the faded tail).
    text($im, 30, 90 + $nw, 392, $on, $B, 'Regions');
    $of = 'of ' . count(REGIONS);
    text($im, 21, 92 + $nw, 422, $on, $B, $of);

    // ---- round by round: little stamped squares (up, down, held)
    if ($rec['rounds'] !== '') {
        $x = 64;
        foreach (str_split($rec['rounds']) as $r) {
            imagefilledrectangle($im, $x, 474, $x + 22, 496, hexcol($im, $r === 'u' ? $T['up'] : ($r === 'd' ? $T['down'] : $T['same'])));
            imagerectangle($im, $x, 474, $x + 22, 496, hexcol($im, $T['line'], 60));
            $x += 30;
        }
    }

    // ---- footer: the 影 seal and where to play
    $seal = @imagecreatefrompng(__DIR__ . '/share/' . $T['seal']);
    if ($seal) { imagealphablending($im, true); imagecopyresampled($im, $seal, 56, 518, 0, 0, 62, 62, imagesx($seal), imagesy($seal)); }
    text_spaced($im, 17, 132, 546, $ink, $B, 'SHILLUMINATI ONLINE', 3);
    text($im, 17, 132, 574, $muted, $R, 'Play free at shyonsol.io  ·  $SHY');

    // ---- the final world map and the standings under the card
    // with no standings (a solo game saved without them) the map gets the whole space under the card
    //MC 2026-10-11 map moved left and made a little smaller so the standings panel is ~110px wider: names up to about
    //   20 letters fit on one line now. A longer one wraps onto a second line in smaller type (3 lines max room, the
    //   rest ends in "…"), instead of being cut to "MrvRhnSh…" or "M…".
    if (!$rec['standings']) { draw_map($im, $rec, 700, 412, 360, 190, $T['map']); }
    else draw_map($im, $rec, 498, 432, 292, 160, $T['map']);
    if ($rec['standings']) {
        $cx = 806; $cwid = 356; $py0 = 414; $maxH = 192;
        $tab = hexcol($im, $T['tab']); $tx2 = hexcol($im, $T['tabtx']);
        // lay each row out first: one line at 19, or two lines at 16
        $rows = [];
        foreach ($rec['standings'] as $k => $row) {
            $f = $row['me'] ? $B : $R; $rs = (string)$row['r'];
            $room = $cwid - 16 - 14 - text_w(19, $B, $rs) - 14;
            $label = ($k + 1) . '. ' . $row['n'];
            if (text_w(19, $f, $label) <= $room) { $rows[] = ['f' => $f, 'z' => 19, 'l' => [$label], 'h' => 38, 'r' => $rs, 'row' => $row]; continue; }
            $words = preg_split('/(?<=\s)/u', $label); $l1 = ''; $rest = '';
            foreach ($words as $i => $wd) { if ($rest === '' && text_w(16, $f, rtrim($l1 . $wd)) <= $room) $l1 .= $wd; else $rest .= $wd; }
            if (trim($l1) === '' || mb_strlen(trim($l1)) < 4) {   // one long word: break it where it fills the line
                $l1 = ''; $chars = preg_split('//u', $label, -1, PREG_SPLIT_NO_EMPTY); $i = 0;
                while ($i < count($chars) && text_w(16, $f, $l1 . $chars[$i]) <= $room) $l1 .= $chars[$i++];
                $rest = implode('', array_slice($chars, $i));
            }
            $l2 = trim($rest); $room2 = $room - text_w(16, $f, ($k + 1) . '. ');   // the second line sits under the name, not the number
            if (text_w(16, $f, $l2) > $room2) { while (mb_strlen($l2) > 1 && text_w(16, $f, $l2 . '…') > $room2) $l2 = rtrim(mb_substr($l2, 0, -1)); $l2 .= '…'; }
            $rows[] = ['f' => $f, 'z' => 16, 'l' => [rtrim($l1), $l2], 'h' => 46, 'r' => $rs, 'row' => $row, 'in' => text_w(16, $f, ($k + 1) . '. ')];
        }
        $ph2 = array_sum(array_column($rows, 'h')) + 12;
        if ($ph2 > $maxH) { foreach ($rows as &$rw) if ($rw['h'] === 46) $rw['h'] = 44; unset($rw); $ph2 = array_sum(array_column($rows, 'h')) + 12; }
        imagefilledrectangle($im, $cx + 4, $py0 + 5, $cx + $cwid + 4, $py0 + $ph2 + 5, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $cx, $py0, $cx + $cwid, $py0 + $ph2, $tab);
        $top = $py0 + 6;
        foreach ($rows as $rw) {
            $row = $rw['row']; $rh = $rw['h'];
            $pc = $T['map']['p'][$row['c']] ?? $T['map']['p'][0];
            if ($row['me']) imagefilledrectangle($im, $cx, $top, $cx + $cwid, $top + $rh - 1, hexcol($im, $T['tabtx'], 108));
            imagefilledrectangle($im, $cx, $top + 6, $cx + 5, $top + $rh - 7, hexcol($im, $pc));
            if (count($rw['l']) === 1) text($im, 19, $cx + 16, $top + 26, $tx2, $rw['f'], $rw['l'][0]);
            else { text($im, 16, $cx + 16, $top + 20, $tx2, $rw['f'], $rw['l'][0]); text($im, 16, $cx + 16 + $rw['in'], $top + 39, $tx2, $rw['f'], $rw['l'][1]); }
            text($im, 19, $cx + $cwid - 14 - text_w(19, $B, $rw['r']), $top + ($rh / 2) + 8, $tx2, $B, $rw['r']);
            $top += $rh;
        }
    }
    if (!is_dir(dirname($out))) @mkdir(dirname($out), 0755, true);
    if (substr($out, -4) === '.jpg') imagejpeg($im, $out, 88); else imagepng($im, $out, 6);   //MC 2026-10-11 JPEG for new cards
}


//MC 2026-10-12 ---------------------------------------------------------------- profile cards (see ?p= above)
// what the card shows, from the player's public record only (nothing a player didn't already show on their page)
function pc_record($tag) {
    $players = load(PLAYERS); $pid = '';
    foreach ($players as $id => $p) if (strpos($id, $tag) === 0 && !empty($p['games'])) { $pid = $id; break; }
    if ($pid === '' || !empty($players[$pid]['hide'])) return null;
    $p = $players[$pid];
    $hol = load(HOLDERS); $hd = $hol[$pid] ?? null; $tier = holder_tier($hd);
    $eco = load(ECO); $acc = isset($eco[$pid]) ? eco_get($eco, $pid) : null;
    $cos = $acc ? eco_public($acc, $tier) : [];
    $holder = !empty($p['holder']) && !empty($p['avatar']);
    $rows = []; foreach ($players as $id => $x) if (!empty($x['games'])) $rows[] = [$id, [$x['points'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]];
    usort($rows, fn($a, $b) => $b[1] <=> $a[1]); $rank = 0; foreach ($rows as $i => $r) if ($r[0] === $pid) { $rank = $i + 1; break; }
    $H = houses(); $hid = house_of($pid, $H);
    $pg = $acc ? page_public($acc, $tier) : [];
    // the card they're known for: the first card in their showcase, else their most played
    $card = ''; $cardWhy = '';
    if (!empty($pg['show'][0]['id'])) { $card = $pg['show'][0]['id']; $cardWhy = 'SHOWCASE'; }
    elseif ($acc && !empty($acc['cm'])) { $cm = $acc['cm']; arsort($cm); $card = (string)array_key_first($cm); $cardWhy = 'SIGNATURE CARD'; $cardPlays = (int)reset($cm); }
    $rk = rank_show($p);
    $motto = trim(preg_replace('/[^\x{0020}-\x{024F}\x{2018}-\x{201D}\x{2026}]/u', '', (string)($pg['motto'] ?? '')));
    return ['tag' => $tag, 'name' => (string)$p['name'], 'avatar' => $holder ? (string)$p['avatar'] : '', 'aura' => $holder ? shadow_aura($p['avatar']) : '', 'holder' => $holder,
        'verified' => !empty($p['holder']), 'skin' => $acc['eq']['skin'] ?? '', 'mask' => 'unbound', 'title' => (string)($cos['title'] ?? ''),
        'tierName' => $tier !== '' ? (HOLDER_NAMES[$tier] ?? '') : '', 'house' => $hid ? ['tag' => $H['h'][$hid]['tag'], 'name' => $H['h'][$hid]['name']] : null,
        'rank' => $rank, 'of' => count($rows), 'pts' => (int)($p['points'] ?? 0), 'wins' => (int)($p['wins'] ?? 0), 'games' => (int)($p['games'] ?? 0), 'best' => (int)($p['best'] ?? 0),
        'live' => [(int)($p['pvp_w'] ?? 0), (int)($p['pvp_g'] ?? 0)], 'ranked' => $rk ? $rk['name'] : '', 'streak' => $acc ? (int)($acc['st']['best'] ?? ($acc['st']['n'] ?? 0)) : 0,
        'motto' => $motto, 'card' => $card, 'cardWhy' => $cardWhy, 'cardPlays' => $cardPlays ?? 0, 'x' => (string)($p['xu'] ?? ''),
        'theme' => $holder ? 'holder' : ''];
}
function pc_hash($r) { return substr(sha1(json_encode($r) . SHARE_LOOK . 'pc1'), 0, 10); }
function share_draw_profile_once($r, $out, $key) {
    if (!is_dir(SHARES)) @mkdir(SHARES, 0755, true);
    $lf = @fopen(SHARES . '/' . $key . '.lock', 'c'); if ($lf) flock($lf, LOCK_EX);
    try {
        if (is_file($out)) return $out;
        $tmp = $out . '.tmp' . getmypid() . '.jpg';
        draw_profile($r, $tmp);
        if (!is_file($tmp) || !filesize($tmp) || !rename($tmp, $out)) { @unlink($tmp); return ''; }
        foreach (glob(SHARES . '/' . $key . '-*.jpg') ?: [] as $f) if ($f !== $out && strpos($f, '.tmp') === false) @unlink($f);   // the old versions of this profile
        return $out;
    } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
}
function draw_profile($r, $out) {
    $T = share_theme($r['theme']);
    $im = imagecreatefromjpeg(__DIR__ . '/share/' . $T['bg']);
    if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    $ink = hexcol($im, $T['ink']); $muted = hexcol($im, $T['muted']); $acc = hexcol($im, $T['acc']);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';

    // ---- the card they're known for, framed on the sun, with its name on a tab
    $px = 620; $py = 62; $pw = 520; $ph = 320; $mat = 8;
    $cpath = '';
    if ($r['card'] !== '' && isset(CARDS[$r['card']])) { [, $cpath] = share_card_pick(['card' => $r['card'], 'result' => 'win'], $r['tag']); }
    if (!$cpath) { [$ck, $cpath] = share_card_pick(['result' => 'win'], $r['tag']); $r['card'] = $ck; $r['cardWhy'] = ''; }
    imagefilledrectangle($im, $px - 2, $py - 2, $px + $pw + 1, $py + $ph + 1, hexcol($im, $T['line']));
    imagefilledrectangle($im, $px, $py, $px + $pw - 1, $py + $ph - 1, hexcol($im, $T['mat']));
    $art = $cpath ? @imagecreatefromstring((string)@file_get_contents($cpath)) : false;
    if ($art) {
        $aw = $pw - 2 * $mat; $ah = $ph - 2 * $mat; $sw = imagesx($art); $sh = imagesy($art);
        $k = max($aw / $sw, $ah / $sh); $cw = $aw / $k; $ch = $ah / $k;
        imagecopyresampled($im, $art, $px + $mat, $py + $mat, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $aw, $ah, (int)$cw, (int)$ch);
    }
    if ($r['card'] !== '' && isset(CARDS[$r['card']])) {
        $kind = $r['cardWhy'] !== '' ? $r['cardWhy'] : strtoupper(CARDS[$r['card']]['kind']); $cname = CARDS[$r['card']]['name'];
        $kw = spaced_w(12, $B, $kind, 2); $nz = fit_size(19, 14, $D, $cname, 300); $nw = text_w($nz, $D, $cname);
        $tw = 18 + $kw + 14 + $nw + 18; $tx = $px + 22; $ty = $py + $ph - 16;
        imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $tw + 3, $ty + 40, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 36, hexcol($im, $T['tab']));
        imagefilledrectangle($im, $tx, $ty, $tx + 4, $ty + 36, $acc);
        text_spaced($im, 12, $tx + 18, $ty + 24, $acc, $B, $kind, 2);
        text($im, $nz, $tx + 18 + $kw + 14, $ty + 26, hexcol($im, $T['tabtx']), $D, $cname);
    }

    // ---- who: the Shadow, the name, what they are
    $av = avatar_image($r);
    $auc = ['cyan' => '#4cc9f0', 'crimson' => '#ff3b5c', 'lightning' => '#ffe066', 'money' => '#f2c35b', 'btc' => '#f7931a', 'none' => '#a78bfa'][$r['aura'] ?? ''] ?? '';
    $ax = 60; $ay = 58; $as = 132;
    imagefilledrectangle($im, $ax - 8, $ay - 8, $ax + $as + 7, $ay + $as + 7, hexcol($im, $T['line']));
    imagefilledrectangle($im, $ax - 6, $ay - 6, $ax + $as + 5, $ay + $as + 5, hexcol($im, $auc ?: $T['mat']));
    rounded_copy($im, $av, $ax, $ay, $as, 4);
    $nx = 222; $nmax = 380;
    $z = fit_size(50, 24, $D, $r['name'], $nmax);
    text($im, $z, $nx, 112, $ink, $D, $r['name']);
    $who = !empty($r['avatar']) ? 'Shadow #' . $r['avatar'] . ($r['verified'] ? '  ·  Verified holder' : '') : ($r['verified'] ? 'Verified $SHY holder' : 'Shilluminati player');
    text($im, fit_size(18, 13, $B, $who, $nmax), $nx + 2, 146, !empty($r['avatar']) || $r['verified'] ? $acc : $muted, $B, $who);
    $chips = array_values(array_filter([$r['title'] !== '' ? strtoupper($r['title']) : '', $r['house'] ? 'HOUSE ' . strtoupper($r['house']['tag']) : '', $r['tierName'] !== '' ? strtoupper($r['tierName']) : '', $r['ranked'] !== '' ? strtoupper($r['ranked']) . ' RANKED' : '']));
    $cx = $nx; $cy = 164;
    foreach ($chips as $c) {
        $w = spaced_w(11, $B, $c, 1.5) + 20;
        if ($cx + $w > $nx + $nmax + 10) break;
        imagefilledrectangle($im, $cx, $cy, $cx + $w, $cy + 24, hexcol($im, $T['tab']));
        text_spaced($im, 11, $cx + 10, $cy + 17, hexcol($im, $T['tabtx']), $B, $c, 1.5);
        $cx += $w + 8;
    }

    // ---- the motto, in mincho, up to two lines
    $y = 252;
    if ($r['motto'] !== '') {
        $m = '“' . $r['motto'] . '”';
        $mz = fit_size(30, 20, $M, $m, 530);
        if (text_w($mz, $M, $m) > 530) {
            $words = explode(' ', $m); $l1 = ''; $l2 = '';
            foreach ($words as $wd) { if ($l2 === '' && text_w($mz, $M, trim($l1 . ' ' . $wd)) <= 530) $l1 = trim($l1 . ' ' . $wd); else $l2 = trim($l2 . ' ' . $wd); }
            while ($l2 !== '' && text_w($mz, $M, $l2) > 530) $l2 = mb_substr($l2, 0, -2) . '…';
            text($im, $mz, 60, $y, $ink, $M, $l1); text($im, $mz, 60, $y + $mz + 14, $ink, $M, $l2);
        } else text($im, $mz, 60, $y, $ink, $M, $m);
    } else {
        $line = $r['wins'] ? 'Fights for the world.' : 'New to the world.';
        text($im, 40, 58, $y + 8, $ink, $M, $line);
    }

    // ---- the all-time rank on the brush stroke
    tinted_png($im, __DIR__ . '/share/wb-brush.png', $T['win'], 30, 304);
    $on = hexcol($im, $T['on']);
    $n = $r['rank'] ? '#' . number_format($r['rank']) : number_format($r['pts']);
    // the number and its two short lines stay inside the thick part of the stroke (about 470px wide)
    $l2 = $r['rank'] ? 'of ' . number_format($r['of']) : '';
    $nz = fit_size(96, 56, $D, $n, 440 - max(text_w(26, $B, 'all time'), text_w(21, $B, $l2)));
    text($im, $nz, 70, 432, $on, $D, $n);
    $nw = text_w($nz, $D, $n);
    text($im, 26, 90 + $nw, 392, $on, $B, $r['rank'] ? 'all time' : 'points');
    if ($l2 !== '') text($im, 21, 92 + $nw, 422, $on, $B, $l2);

    // ---- the record, as stamped tiles
    $wr = $r['games'] ? round($r['wins'] / $r['games'] * 100) : 0;
    $tiles = [[number_format($r['pts']), 'POINTS'], [number_format($r['wins']), 'WINS'], [number_format($r['games']), 'GAMES'], [$wr . '%', 'WIN RATE']];
    $tx = 60; $ty = 462;
    foreach ($tiles as [$big, $lab]) {
        $w = max(96, text_w(26, $D, $big) + 28, spaced_w(10, $B, $lab, 1.5) + 28);
        imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $w + 3, $ty + 64, hexcol($im, '#000000', 100));
        imagefilledrectangle($im, $tx, $ty, $tx + $w, $ty + 60, hexcol($im, $T['tab']));
        text($im, 26, $tx + 14, $ty + 34, hexcol($im, $T['tabtx']), $D, $big);
        text_spaced($im, 10, $tx + 14, $ty + 52, hexcol($im, $T['tabtx'], 40), $B, $lab, 1.5);
        $tx += $w + 10;
    }

    // ---- under the card: the rest of the record
    $lines = array_values(array_filter([
        $r['live'][1] ? ['Live matches', number_format($r['live'][0]) . ' won of ' . number_format($r['live'][1])] : null,
        $r['best'] ? ['Best game', $r['best'] . ' Regions'] : null,
        $r['house'] ? ['House', $r['house']['name']] : null,
        $r['streak'] > 1 ? ['Best streak', $r['streak'] . ' days'] : null,
        $r['x'] !== '' ? ['On X', '@' . $r['x']] : null,
    ]));
    $lines = array_slice($lines, 0, 4);
    if ($lines) {
        $bx = 806; $bw = 334; $by = 414; $bh = 12 + 40 * count($lines);
        imagefilledrectangle($im, $bx + 4, $by + 5, $bx + $bw + 4, $by + $bh + 5, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $bx, $by, $bx + $bw, $by + $bh, hexcol($im, $T['tab']));
        $yy = $by + 6;
        foreach ($lines as [$k, $v]) {
            imagefilledrectangle($im, $bx, $yy + 8, $bx + 4, $yy + 32, $acc);
            text($im, 15, $bx + 16, $yy + 26, hexcol($im, $T['tabtx'], 40), $R, $k);
            $vz = fit_size(17, 12, $B, $v, $bw - 30 - text_w(15, $R, $k) - 10);
            text($im, $vz, $bx + $bw - 14 - text_w($vz, $B, $v), $yy + 26, hexcol($im, $T['tabtx']), $B, $v);
            $yy += 40;
        }
    }

    // ---- footer: the seal and where to find them
    $seal = @imagecreatefrompng(__DIR__ . '/share/' . $T['seal']);
    if ($seal) { imagealphablending($im, true); imagecopyresampled($im, $seal, 56, 546, 0, 0, 56, 56, imagesx($seal), imagesy($seal)); }
    text_spaced($im, 15, 126, 570, $ink, $B, 'SHILLUMINATI ONLINE', 3);
    $u = 'shyonsol.io/p/' . str_replace(' ', '_', $r['name']);
    text($im, fit_size(16, 12, $R, $u, 440), 126, 596, $muted, $R, $u);
    if (!is_dir(dirname($out))) @mkdir(dirname($out), 0755, true);
    imagejpeg($im, $out, 88);
}

//MC 2026-10-14 the player hype card (?hp= above): the promo card's voice, but about one player. Their signature card
//   framed on the sun with its effect under it, a mincho headline per angle, the Shadow and name as the byline, the
//   numbers that back the boast as stamped tiles, and the same footer signature every card from the site wears.
function draw_playerhype($r, $v, $out) {
    $T = share_theme($r['theme']);
    $im = imagecreatefromjpeg(__DIR__ . '/share/' . $T['bg']);
    if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    $ink = hexcol($im, $T['ink']); $muted = hexcol($im, $T['muted']); $acc = hexcol($im, $T['acc']);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';

    // ---- the signature card, framed on the sun exactly as the promos frame theirs
    $px = 620; $py = 62; $pw = 520; $ph = 320; $mat = 8;
    $cpath = '';
    if ($r['card'] !== '' && isset(CARDS[$r['card']])) { [, $cpath] = share_card_pick(['card' => $r['card'], 'result' => 'win'], $r['tag']); }
    if (!$cpath) { [$ck, $cpath] = share_card_pick(['result' => 'win'], $r['tag']); if ($ck !== '') { $r['card'] = $ck; $r['cardWhy'] = ''; } }
    imagefilledrectangle($im, $px - 2, $py - 2, $px + $pw + 1, $py + $ph + 1, hexcol($im, $T['line']));
    imagefilledrectangle($im, $px, $py, $px + $pw - 1, $py + $ph - 1, hexcol($im, $T['mat']));
    $art = $cpath ? @imagecreatefromstring((string)@file_get_contents($cpath)) : false;
    if ($art) {
        $aw = $pw - 2 * $mat; $ah = $ph - 2 * $mat; $sw = imagesx($art); $sh = imagesy($art);
        $k = max($aw / $sw, $ah / $sh); $cw = $aw / $k; $ch = $ah / $k;
        imagecopyresampled($im, $art, $px + $mat, $py + $mat, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $aw, $ah, (int)$cw, (int)$ch);
        imagerectangle($im, $px + $mat, $py + $mat, $px + $pw - $mat - 1, $py + $ph - $mat - 1, hexcol($im, '#000000', 90));
    }
    if ($r['card'] !== '' && isset(CARDS[$r['card']])) {
        // a player with no signature yet gets a card from the deck, labelled as the deck's, never as theirs
        $kind = $r['cardWhy'] !== '' ? $r['cardWhy'] : 'FROM THE CHAOS DECK'; $cname = CARDS[$r['card']]['name'];
        $kw = spaced_w(12, $B, $kind, 2); $nz = fit_size(19, 14, $D, $cname, 300); $nw = text_w($nz, $D, $cname);
        $tw = 18 + $kw + 14 + $nw + 18; $tx = $px + 22; $ty = $py + $ph - 16;
        imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $tw + 3, $ty + 40, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 36, hexcol($im, $T['tab']));
        imagefilledrectangle($im, $tx, $ty, $tx + 4, $ty + 36, $acc);
        text_spaced($im, 12, $tx + 18, $ty + 24, $acc, $B, $kind, 2);
        text($im, $nz, $tx + 18 + $kw + 14, $ty + 26, hexcol($im, $T['tabtx']), $D, $cname);
        // under the card: how often they reach for it, else what it does
        $sub = $r['cardPlays'] > 1 ? 'Played ' . number_format($r['cardPlays']) . ' times and counting.' : card_effect($r['card']);
        $ey = $ty + 72;
        foreach (array_slice(cardpromo_wrap(17, $R, $sub, $pw - 10), 0, 2) as $ln) { text($im, 17, $px + 4, $ey, $ink, $R, $ln); $ey += 27; }
    }

    // ---- the angle: kicker, headline pair and the tiles that back it
    $wr = $r['games'] ? round($r['wins'] / $r['games'] * 100) : 0;
    $A = [
        1 => ['k' => 'THE RECORD SO FAR', 'h' => ['The table', 'remembers.'],
              't' => [[number_format($r['pts']), 'POINTS'], [number_format($r['wins']), 'WINS'], [$wr . '%', 'WIN RATE']]],
        2 => ['k' => $r['cardWhy'] !== '' ? 'THE SIGNATURE CARD' : 'THE CHAOS DECK', 'h' => $r['cardWhy'] !== '' ? ['One card', 'says it all.'] : ['71 cards.', 'One table.'],
              't' => [[$r['cardPlays'] > 0 ? number_format($r['cardPlays']) : number_format($r['games']), $r['cardPlays'] > 0 ? 'TIMES PLAYED' : 'GAMES'], [number_format($r['wins']), 'WINS'], [$wr . '%', 'WIN RATE']]],
        3 => ['k' => 'THE CLIMB', 'h' => ['Watch this', 'name rise.'],
              't' => [[$r['rank'] ? '#' . number_format($r['rank']) : number_format($r['pts']), $r['rank'] ? 'ALL TIME' : 'POINTS'], [number_format($r['pts']), 'POINTS'], [$r['streak'] > 1 ? number_format($r['streak']) : (string)$r['best'], $r['streak'] > 1 ? 'DAY STREAK' : 'BEST GAME']]],
    ][$v];
    text_spaced($im, 13, 62, 104, $acc, $B, $A['k'] . '  ·  SHILLUMINATI ONLINE', 2);
    text($im, 58, 58, 196, $ink, $M, $A['h'][0]);
    text($im, 58, 58, 268, hexcol($im, $T['win']), $M, $A['h'][1]);

    // ---- the byline: the Shadow and the name the post is signed with
    $av = avatar_image($r);
    $auc = ['cyan' => '#4cc9f0', 'crimson' => '#ff3b5c', 'lightning' => '#ffe066', 'money' => '#f2c35b', 'btc' => '#f7931a', 'none' => '#a78bfa'][$r['aura'] ?? ''] ?? '';
    $ax = 62; $ay = 300; $as = 84;
    imagefilledrectangle($im, $ax - 6, $ay - 6, $ax + $as + 5, $ay + $as + 5, hexcol($im, $T['line']));
    imagefilledrectangle($im, $ax - 4, $ay - 4, $ax + $as + 3, $ay + $as + 3, hexcol($im, $auc ?: $T['mat']));
    rounded_copy($im, $av, $ax, $ay, $as, 4);
    $nx = $ax + $as + 20; $nmax = 620 - $nx - 10;
    $z = fit_size(36, 20, $D, $r['name'], $nmax);
    text($im, $z, $nx, $ay + 40, $ink, $D, $r['name']);
    $who = !empty($r['avatar']) ? 'Shadow #' . $r['avatar'] . ($r['verified'] ? '  ·  Verified holder' : '') : ($r['verified'] ? 'Verified $SHY holder' : 'Shilluminati player');
    text($im, fit_size(16, 12, $B, $who, $nmax), $nx + 1, $ay + 70, !empty($r['avatar']) || $r['verified'] ? $acc : $muted, $B, $who);

    // ---- the tiles, stamped like the profile card's
    $tx = 62; $ty = 430;
    foreach ($A['t'] as [$big, $lab]) {
        $w = max(96, text_w(26, $D, $big) + 28, spaced_w(10, $B, $lab, 1.5) + 28);
        imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $w + 3, $ty + 64, hexcol($im, '#000000', 100));
        imagefilledrectangle($im, $tx, $ty, $tx + $w, $ty + 60, hexcol($im, $T['tab']));
        text($im, 26, $tx + 14, $ty + 34, hexcol($im, $T['tabtx']), $D, $big);
        text_spaced($im, 10, $tx + 14, $ty + 52, hexcol($im, $T['tabtx'], 40), $B, $lab, 1.5);
        $tx += $w + 10;
    }

    // ---- the footer every card from the site wears
    $seal = @imagecreatefrompng(__DIR__ . '/share/' . $T['seal']);
    if ($seal) imagecopyresampled($im, $seal, 56, 518, 0, 0, 62, 62, imagesx($seal), imagesy($seal));
    text_spaced($im, 17, 132, 546, $ink, $B, 'SHILLUMINATI ONLINE', 3);
    text($im, 17, 132, 574, $muted, $R, 'Play free at shyonsol.io  ·  $SHY on Solana');

    if (!is_dir(dirname($out))) @mkdir(dirname($out), 0755, true);
    imagejpeg($im, $out, 88);
    imagedestroy($im);
}

//MC 2026-10-12 the Shogun card: black lacquer, a red glow and gold rays behind the mask, the challenge in mincho, the reward
//   on a vermilion stamp, the record as four tiles and the tug of war between its wins and the players'. Drawn from nothing
//   but the fonts and the mask, so it never depends on a background file. Tried the crimson woodblock background first,
//   but the mask disappeared into it.
//MC 2026-10-13 ---------------------------------------------------------------- the machine-victory card (see ?bw= above)
//MC 2026-10-13 the Shogun's victory card (see ?sw= above): the warm lacquer of its promo card, but about one match it won
function draw_shogunwin($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    // the Shogun's lacquer, darker than the promo card: it just won, the room goes quiet
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(26 - 16 * $k), (int)(14 - 8 * $k), (int)(13 - 8 * $k))); }
    for ($r = 460; $r > 0; $r -= 8) imagefilledellipse($im, 1100, 40, $r * 2, $r * 2, hexcol($im, '#e0453a', (int)(127 - 9 * (1 - $r / 460))));
    for ($r = 280; $r > 0; $r -= 6) imagefilledellipse($im, 215, 290, $r * 2, $r * 2, hexcol($im, '#f3c969', (int)(127 - 8 * (1 - $r / 280))));
    // gold rays behind the mask, tighter than the promo card
    $cx = 215; $cy = 290;
    foreach ([[0, 180, 106], [180, 250, 114], [250, 310, 121]] as [$r0, $r1, $al]) {
        $ray = hexcol($im, '#f3c969', $al);
        for ($i = 0; $i < 24; $i++) {
            $a = $i * M_PI / 12; $b2 = $a + M_PI / 48;
            imagefilledpolygon($im, [(int)($cx + cos($a) * $r0), (int)($cy + sin($a) * $r0), (int)($cx + cos($a) * $r1), (int)($cy + sin($a) * $r1), (int)($cx + cos($b2) * $r1), (int)($cy + sin($b2) * $r1), (int)($cx + cos($b2) * $r0), (int)($cy + sin($b2) * $r0)], $ray);
        }
    }
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#f3c969', 80)); imagesetthickness($im, 1);

    // the mask, framed in gold
    $mask = mask_card_img('shogun');
    $ms = 280; $mx = $cx - $ms / 2; $my = $cy - $ms / 2 - 14;
    imagefilledrectangle($im, $mx - 7 + 6, $my - 7 + 10, $mx + $ms + 6 + 6, $my + $ms + 6 + 10, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $mx - 7, $my - 7, $mx + $ms + 6, $my + $ms + 6, hexcol($im, '#f3c969'));
    if ($mask) rounded_copy($im, $mask, (int)$mx, (int)$my, $ms, 10);
    $tn = 'THE SHOGUN'; $tw = spaced_w(15, $B, $tn, 4) + 36; $tx = (int)($cx - $tw / 2); $ty = (int)($my + $ms + 24);
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#120b0a'));
    imagerectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#f3c969', 40));
    text_spaced($im, 15, $tx + 18, $ty + 26, hexcol($im, '#ffe6a3'), $B, $tn, 4);

    // the verdict
    $x = 430; $gold = hexcol($im, '#f3c969'); $cream = hexcol($im, '#fbf1dc'); $muted = hexcol($im, '#d8cfc0');
    text_spaced($im, 13, $x, 82, $gold, $B, 'BOSS MATCH  ·  SHILLUMINATI ONLINE', 3);
    $tie = !empty($rec['tie']); $tb = !$tie && (int)$rec['mine'] === (int)$rec['boss'];
    text($im, 46, $x - 2, 150, $cream, $M, $tie ? 'A draw with' : 'The Shogun');
    text($im, 70, $x - 4, 234, hexcol($im, '#ffd98a'), $M, $tie ? 'the Shogun.' : 'holds.');
    $nm = clean_label((string)$rec['n']);
    $line = $tie ? $nm . ' matched it, ' . (int)$rec['mine'] . ' Regions to ' . (int)$rec['boss'] . '. Nobody bowed.'
        : ($tb ? $nm . ' lost on the tiebreak, ' . (int)$rec['mine'] . ' Regions each.' : $nm . ' fell, ' . (int)$rec['mine'] . ' Regions to its ' . (int)$rec['boss'] . '.');
    text($im, fit_size(22, 17, $R, $line, 700), $x, 284, $muted, $R, $line);
    $pline = (int)$rec['pw'] > 0 ? 'Their record against it: ' . (int)$rec['pw'] . ' ' . ((int)$rec['pw'] === 1 ? 'win' : 'wins') . ' from ' . (int)$rec['pg'] . ' matches.' : 'Match ' . (int)$rec['pg'] . '. Their first win is still out there.';
    text($im, 20, $x, 316, $muted, $R, $pline);

    // the Shogun's record as two tiles
    $tiles = [[number_format((int)$rec['sw']), 'SHOGUN WINS'], [number_format((int)$rec['sl']), 'TIMES BEATEN']];
    $ty2 = 356; $tw2 = 210; $gap = 12;
    foreach ($tiles as $i => [$v, $l]) {
        $X = $x + $i * ($tw2 + $gap);
        imagefilledrectangle($im, $X, $ty2, $X + $tw2, $ty2 + 86, hexcol($im, '#ffffff', 118));
        imagerectangle($im, $X, $ty2, $X + $tw2, $ty2 + 86, hexcol($im, '#f3c969', 95));
        text($im, 34, $X + 18, $ty2 + 48, $i === 0 ? hexcol($im, '#ffd98a') : hexcol($im, '#ff7a6b'), $D, $v);
        text_spaced($im, 10, $X + 18, $ty2 + 70, $muted, $B, $l, 1.5);
    }

    // the stamp: avenge them
    if ((int)$rec['koban'] > 0) { $big = 'WIN ' . number_format((int)$rec['koban']) . ' KOBAN'; $small = 'beat it, once a ' . (($rec['per'] ?? 'day') === 'week' ? 'week' : 'day'); }
    else { $big = 'CHALLENGE IT'; $small = 'for glory and the Hall'; }
    $sw2 = max(text_w(26, $D, $big), text_w(15, $B, $small)) + 44; $sy = 486;
    imagefilledrectangle($im, $x + 5, $sy + 6, $x + $sw2 + 5, $sy + 76, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $x, $sy, $x + $sw2, $sy + 70, hexcol($im, '#e0453a'));
    imagerectangle($im, $x + 5, $sy + 5, $x + $sw2 - 5, $sy + 65, hexcol($im, '#fff0dc', 70));
    text($im, 26, $x + 22, $sy + 38, hexcol($im, '#fff7e8'), $D, $big);
    text($im, 15, $x + 22, $sy + 59, hexcol($im, '#ffd9c8'), $B, $small);
    $site = 'Play free at shyonsol.io  ·  $SHY';
    text($im, 15, $W - 60 - text_w(15, $B, $site), $sy + 44, $gold, $B, $site);

    imagejpeg($im, $out, 90);
    imagedestroy($im);
}
function draw_botwin($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    // cold steel: a vertical fade from slate to near black, nothing like the warm paper of a player's card
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(24 - 13 * $k), (int)(23 - 13 * $k), (int)(34 - 16 * $k))); }
    // a red alert glow behind the mask and a faint cold one top right
    for ($r = 340; $r > 0; $r -= 7) imagefilledellipse($im, 215, 290, $r * 2, $r * 2, hexcol($im, '#e0453a', (int)(127 - 9 * (1 - $r / 340))));
    for ($r = 420; $r > 0; $r -= 9) imagefilledellipse($im, 1120, 60, $r * 2, $r * 2, hexcol($im, '#5b82c4', (int)(127 - 6 * (1 - $r / 420))));
    // thin horizontal scanlines, the machine reading the world
    $sl = hexcol($im, '#e0453a', 121); for ($y = 34; $y < $H; $y += 42) imageline($im, 0, $y, $W, $y, $sl);
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#ff6b5d', 88)); imagesetthickness($im, 1);

    // the winner's mask, framed in vermilion with a glitch-doubled edge
    $maskKey = BOT_MASKS[$rec['w']] ?? ['ronin', 'monk', 'tiger', 'crane', 'kitsune', 'oni'][crc32((string)$rec['w']) % 6];
    $mask = mask_card_img($maskKey);
    $ms = 290; $mx = 215 - $ms / 2; $my = 290 - $ms / 2 - 14;
    imagefilledrectangle($im, $mx - 11, $my - 3, $mx + $ms + 2, $my + $ms + 10, hexcol($im, '#4cc9f0', 96));   // the cold ghost edge
    imagefilledrectangle($im, $mx + 1, $my - 11, $mx + $ms + 12, $my + $ms + 2, hexcol($im, '#ff3b5c', 96));   // the hot one
    imagefilledrectangle($im, $mx - 7, $my - 7, $mx + $ms + 6, $my + $ms + 6, hexcol($im, '#e0453a'));
    if ($mask) rounded_copy($im, $mask, (int)$mx, (int)$my, $ms, 10);
    // the bot's name on a black tab under the mask
    $tn = strtoupper(mb_substr((string)$rec['w'], 0, 20)); $lbl = 'BOT';
    $tw = spaced_w(15, $B, $tn, 3) + 30 + spaced_w(11, $B, $lbl, 2) + 30; $tx = (int)(215 - $tw / 2); $ty = (int)($my + $ms + 24);
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#0b0a14'));
    imagerectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#ff6b5d', 50));
    text_spaced($im, 15, $tx + 16, $ty + 26, hexcol($im, '#ffb3aa'), $B, $tn, 3);
    text_spaced($im, 11, $tx + $tw - 14 - spaced_w(11, $B, $lbl, 2), $ty + 25, hexcol($im, '#7f8aa8'), $B, $lbl, 2);

    // the taunt
    $x = 430; $red = hexcol($im, '#ff6b5d'); $cream = hexcol($im, '#eef1fa'); $muted = hexcol($im, '#aab3c9');
    text_spaced($im, 13, $x, 82, $red, $B, 'MACHINE VICTORY  ·  SHILLUMINATI ONLINE', 3);
    text($im, 46, $x - 2, 150, $cream, $M, 'The bots took');
    text($im, 70, $x - 4, 234, hexcol($im, '#ff8d80'), $M, 'the world.');
    $hm = array_filter($rec['standings'] ?? [], fn($r) => !empty($r['h']));
    $line = count($hm) === 1 ? 'One player stood against the machines. It was not enough.' : (count($hm) ? count($hm) . ' players stood against the machines. It was not enough.' : 'The machines played each other. The machines won.');
    text($im, fit_size(21, 17, $R, $line, 700), $x, 282, $muted, $R, $line);
    text($im, 21, $x, 312, $muted, $R, 'Every seat a bot holds is a seat a human could take.');

    // the standings, humans in cream, machines in red
    $ty2 = 352; $cwid = 710;
    imagefilledrectangle($im, $x, $ty2, $x + $cwid, $ty2 + 1, hexcol($im, '#ff6b5d', 95));
    $top = $ty2 + 16;
    foreach (array_slice($rec['standings'] ?? [], 0, 4) as $k => $row) {
        $nm = ($k + 1) . '. ' . $row['n'] . (empty($row['h']) ? '  ·  bot' : '');
        text($im, 19, $x, $top + 20, empty($row['h']) ? hexcol($im, '#ff9d92') : $cream, empty($row['h']) ? $B : $R, $nm);
        $rs = $row['r'] . ($row['r'] === 1 ? ' Region' : ' Regions');
        text($im, 19, $x + $cwid - text_w(19, $B, $rs), $top + 20, empty($row['h']) ? hexcol($im, '#ff9d92') : $cream, $B, $rs);
        $top += 38;
    }

    // the stamp: the way back for humanity
    $big = 'AVENGE HUMANITY'; $small = 'join a live match, free';
    $sw = max(text_w(26, $D, $big), text_w(15, $B, $small)) + 44; $sy = $top + 14;
    imagefilledrectangle($im, $x + 5, $sy + 6, $x + $sw + 5, $sy + 76, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $x, $sy, $x + $sw, $sy + 70, hexcol($im, '#e0453a'));
    imagerectangle($im, $x + 5, $sy + 5, $x + $sw - 5, $sy + 65, hexcol($im, '#fff0dc', 70));
    text($im, 26, $x + 22, $sy + 38, hexcol($im, '#fff7e8'), $D, $big);
    text($im, 15, $x + 22, $sy + 59, hexcol($im, '#ffd9c8'), $B, $small);
    $site = 'Play free at shyonsol.io  ·  $SHY';
    text($im, 15, $x + $cwid - text_w(15, $B, $site), $sy + 44, $muted, $B, $site);

    imagejpeg($im, $out, 90);
    imagedestroy($im);
}


//MC 2026-10-14 the card promo for the hype posts: helpers and the drawer
// the card's effect line, read from the game the way the Shilluminati page reads it (the rules engine keeps no text)
function card_effect($id) {
    static $tx = null;
    if ($tx === null) {
        $tx = [];
        $src = (string)@file_get_contents(dirname(__DIR__) . '/assets/game.js');
        if (preg_match_all('/^\s*(\w+):\s*\{ no: \d+, name: "(?:[^"\\\\]|\\\\.)*", kind: "\w+", target: "\w+", text: "((?:[^"\\\\]|\\\\.)*)" \}/m', $src, $m, PREG_SET_ORDER))
            foreach ($m as $x) $tx[$x[1]] = stripcslashes($x[2]);
    }
    return $tx[$id] ?? '';
}
// the art for one specific card: the published community art when there is one, else the original drawing
function cardpromo_art($cid) {
    $f = load(DATA_DIR . '/card-art.php')[$cid]['live']['f'] ?? '';
    if (preg_match('/^[a-z0-9]+-[a-f0-9]{8}\.(webp|jpg)$/', $f))
        foreach ([dirname(__DIR__) . '/card-art/' . $f, DATA_DIR . '/card-art-keep/' . $f] as $p) if (is_file($p)) return $p;
    foreach (['.webp', '.svg'] as $e) { $p = dirname(__DIR__) . '/assets/cards/' . $cid . $e; if (is_file($p)) return $p; }
    return '';
}
function cardpromo_wrap($size, $font, $s, $maxW) {
    $out = []; $line = '';
    foreach (preg_split('/\s+/', trim($s)) as $w) {
        $try = $line === '' ? $w : $line . ' ' . $w;
        if ($line !== '' && text_w($size, $font, $try) > $maxW) { $out[] = $line; $line = $w; }
        else $line = $try;
    }
    if ($line !== '') $out[] = $line;
    return $out;
}
function draw_cardpromo($cid, $out) {
    $T = share_theme('');
    $im = imagecreatefromjpeg(__DIR__ . '/share/' . $T['bg']);
    if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    $ink = hexcol($im, $T['ink']); $muted = hexcol($im, $T['muted']); $acc = hexcol($im, $T['acc']);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';

    // the card itself, framed on the baked sun exactly as a result card frames it
    $px = 620; $py = 62; $pw = 520; $ph = 320; $mat = 8;
    imagefilledrectangle($im, $px - 2, $py - 2, $px + $pw + 1, $py + $ph + 1, hexcol($im, $T['line']));
    imagefilledrectangle($im, $px, $py, $px + $pw - 1, $py + $ph - 1, hexcol($im, $T['mat']));
    $ap = cardpromo_art($cid);
    $art = $ap !== '' ? @imagecreatefromstring((string)@file_get_contents($ap)) : false;
    if ($art) {
        $aw = $pw - 2 * $mat; $ah = $ph - 2 * $mat;
        $sw = imagesx($art); $sh = imagesy($art);
        $k = max($aw / $sw, $ah / $sh); $cw = $aw / $k; $ch = $ah / $k;
        imagecopyresampled($im, $art, $px + $mat, $py + $mat, (int)(($sw - $cw) / 2), (int)(($sh - $ch) / 2), $aw, $ah, (int)$cw, (int)$ch);
        imagerectangle($im, $px + $mat, $py + $mat, $px + $pw - $mat - 1, $py + $ph - $mat - 1, hexcol($im, '#000000', 90));
    }
    $kind = strtoupper(CARDS[$cid]['kind']); $cname = CARDS[$cid]['name'];
    $kc = ['ATTACK' => '#e2452f', 'GAIN' => '#3fae8c', 'DEFENSE' => '#5b82c4', 'GLOBAL' => '#e2a93a', 'TRICK' => '#b07ad8', 'PASSIVE' => '#9a9a9a'][$kind] ?? '#e2a93a';
    $kw = spaced_w(12, $B, $kind, 2); $nz = fit_size(19, 14, $D, $cname, 330); $nw = text_w($nz, $D, $cname);
    $tw = 18 + $kw + 14 + $nw + 18; $tx = $px + 22; $ty = $py + $ph - 16;
    imagefilledrectangle($im, $tx + 3, $ty + 4, $tx + $tw + 3, $ty + 40, hexcol($im, '#000000', 90));
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 36, hexcol($im, $T['tab']));
    imagefilledrectangle($im, $tx, $ty, $tx + 4, $ty + 36, hexcol($im, $kc));
    text_spaced($im, 12, $tx + 18, $ty + 24, hexcol($im, $kc), $B, $kind, 2);
    text($im, $nz, $tx + 18 + $kw + 14, $ty + 26, hexcol($im, $T['tabtx']), $D, $cname);
    // the effect line under the card, so the unfurl teaches the card at a glance
    $ey = $ty + 72;
    foreach (array_slice(cardpromo_wrap(17, $R, card_effect($cid), $pw - 10), 0, 3) as $ln) { text($im, 17, $px + 4, $ey, $ink, $R, $ln); $ey += 27; }

    // the left column: kicker, a hype line in mincho per kind, and the stamp
    //MC 2026-10-14 the game's name moved into the same footer the win cards carry (seal, name, where to play), so every
    //   card that leaves the site wears the same signature; the kicker up here names the deck instead
    text_spaced($im, 13, 62, 104, $acc, $B, 'THE CHAOS DECK  ·  71 CARDS, HAND-INKED', 2);
    $hl = ['attack' => ['Built to', 'take worlds.'], 'gain' => ['Grow first.', 'Gloat after.'], 'defense' => ['The wall', 'holds.'],
           'global' => ['Everyone', 'pays.'], 'trick' => ['Bend the', 'rules.'], 'passive' => ['It waits in', 'your hand.']];
    $h2 = $hl[CARDS[$cid]['kind']] ?? ['Your turn to', 'rule the world.'];
    text($im, 58, 58, 196, $ink, $M, $h2[0]);
    text($im, 58, 58, 268, hexcol($im, $T['win']), $M, $h2[1]);
    text($im, 20, 62, 320, $muted, $R, 'Live matches, a Daily Challenge and');
    text($im, 20, 62, 348, $muted, $R, 'a weekly league. No wallet needed.');

    // the vermilion stamp: the call to play
    $big = 'PLAY IT FREE'; $small = 'shyonsol.io/play';
    $sw2 = max(text_w(26, $D, $big), text_w(15, $B, $small)) + 44; $sx = 62; $sy = 396;
    imagefilledrectangle($im, $sx + 5, $sy + 6, $sx + $sw2 + 5, $sy + 76, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $sx, $sy, $sx + $sw2, $sy + 70, hexcol($im, $T['win']));
    imagerectangle($im, $sx + 5, $sy + 5, $sx + $sw2 - 5, $sy + 65, hexcol($im, '#fff0dc', 70));
    text($im, 26, $sx + 22, $sy + 38, hexcol($im, '#fff7e8'), $D, $big);
    text($im, 15, $sx + 22, $sy + 59, hexcol($im, '#ffd9c8'), $B, $small);
    // the footer the win share cards carry: the seal, the game's name and where to play
    $seal = @imagecreatefrompng(__DIR__ . '/share/' . $T['seal']);
    if ($seal) imagecopyresampled($im, $seal, 56, 518, 0, 0, 62, 62, imagesx($seal), imagesy($seal));
    text_spaced($im, 17, 132, 546, $ink, $B, 'SHILLUMINATI ONLINE', 3);
    text($im, 17, 132, 574, $muted, $R, 'Play free at shyonsol.io  ·  $SHY on Solana');

    imagejpeg($im, $out, 90);
    imagedestroy($im);
}

function draw_boss($d, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);   // no imageantialias: with see-through colours it outlines every ray band
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    // lacquer: a soft vertical fade
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(31 - 18 * $k), (int)(18 - 10 * $k), (int)(16 - 9 * $k))); }
    // a red glow top right and a gold one behind the mask
    for ($r = 520; $r > 0; $r -= 8) imagefilledellipse($im, 1080, 40, $r * 2, $r * 2, hexcol($im, '#e0453a', (int)(127 - 10 * (1 - $r / 520))));
    for ($r = 300; $r > 0; $r -= 6) imagefilledellipse($im, 215, 300, $r * 2, $r * 2, hexcol($im, '#f3c969', (int)(127 - 9 * (1 - $r / 300))));
    // gold rays from the mask
    //   in bands that fade out, so they stay around the mask and never run through the words on the right
    $cx = 215; $cy = 300;
    foreach ([[0, 190, 104], [190, 260, 112], [260, 320, 119], [320, 370, 124]] as [$r0, $r1, $al]) {
        $ray = hexcol($im, '#f3c969', $al);
        for ($i = 0; $i < 24; $i++) {
            $a = $i * M_PI / 12; $b = $a + M_PI / 48;
            imagefilledpolygon($im, [(int)($cx + cos($a) * $r0), (int)($cy + sin($a) * $r0), (int)($cx + cos($a) * $r1), (int)($cy + sin($a) * $r1), (int)($cx + cos($b) * $r1), (int)($cy + sin($b) * $r1), (int)($cx + cos($b) * $r0), (int)($cy + sin($b) * $r0)], $ray);
        }
    }
    // fine vertical lines, like the Stats panel
    $fl = hexcol($im, '#f3c969', 122); for ($x = 46; $x < $W; $x += 47) imageline($im, $x, 0, $x, $H, $fl);
    // gold frame around the whole card
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#f3c969', 80)); imagesetthickness($im, 1);

    // the mask, framed
    $mask = mask_card_img('shogun');
    $ms = 300; $mx = $cx - $ms / 2; $my = $cy - $ms / 2 - 10;
    imagefilledrectangle($im, $mx - 7 + 6, $my - 7 + 10, $mx + $ms + 6 + 6, $my + $ms + 6 + 10, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $mx - 7, $my - 7, $mx + $ms + 6, $my + $ms + 6, hexcol($im, '#f3c969'));
    if ($mask) rounded_copy($im, $mask, (int)$mx, (int)$my, $ms, 10);
    // the boss name under the mask, on a black tab
    $tn = 'THE SHOGUN'; $tw = spaced_w(15, $B, $tn, 4) + 36; $tx = (int)($cx - $tw / 2); $ty = (int)($my + $ms + 22);
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#120b0a'));
    imagerectangle($im, $tx, $ty, $tx + $tw, $ty + 38, hexcol($im, '#f3c969', 40));
    text_spaced($im, 15, $tx + 18, $ty + 26, hexcol($im, '#ffe6a3'), $B, $tn, 4);

    // the challenge
    $x = 430; $gold = hexcol($im, '#f3c969'); $cream = hexcol($im, '#fbf1dc'); $muted = hexcol($im, '#d8cfc0'); $ver = hexcol($im, '#e0453a');
    text_spaced($im, 13, $x, 82, $gold, $B, 'BOSS MATCH  ·  SHILLUMINATI ONLINE', 3);
    text($im, 46, $x - 2, 150, $cream, $M, 'Can you beat');
    text($im, fit_size(70, 50, $M, 'the Shogun?', 700), $x - 4, 236, hexcol($im, '#ffd98a'), $M, 'the Shogun?');
    text($im, 21, $x, 282, $muted, $R, 'The hardest bot in Shilluminati. A 1v1, you against it.');
    text($im, 21, $x, 312, $muted, $R, 'It plays every move out to the end before it chooses.');

    // the reward, as it is set now, on a vermilion stamp
    if (!$d['on']) { $big = 'RESTING'; $small = 'back soon'; }
    elseif ($d['koban'] > 0) { $big = 'WIN ' . number_format($d['koban']) . ' KOBAN'; $small = $d['per'] === 'week' ? 'once a week' : 'once a day'; }
    else { $big = 'FOR GLORY'; $small = 'and the Hall of victors'; }
    $sw = max(text_w(26, $D, $big), text_w(15, $B, $small)) + 44; $sy = 338;
    imagefilledrectangle($im, $x + 5, $sy + 6, $x + $sw + 5, $sy + 76, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $x, $sy, $x + $sw, $sy + 70, $ver);
    imagerectangle($im, $x + 5, $sy + 5, $x + $sw - 5, $sy + 65, hexcol($im, '#fff0dc', 70));
    text($im, 26, $x + 22, $sy + 38, hexcol($im, '#fff7e8'), $D, $big);
    text($im, 15, $x + 22, $sy + 59, hexcol($im, '#ffd9c8'), $B, $small);
    if ($d['edge'] > 0) { $e = 'It starts with ' . $d['edge'] . ' extra ' . ($d['edge'] === 1 ? 'card' : 'cards'); text($im, 16, $x + $sw + 22, $sy + 44, $gold, $B, $e); }

    // the record as four tiles
    $sg = $d['g'] - $d['w']; $rate = $d['g'] ? round($d['w'] / $d['g'] * 100) : 0;
    $tiles = [[number_format($d['g']), 'MATCHES'], [number_format($sg), 'SHOGUN WINS'], [number_format($d['w']), 'PLAYER WINS'], [$rate . '%', 'PLAYERS WIN']];
    $tx = $x; $ty = 436; $tw = 170; $gap = 12;
    foreach ($tiles as $i => [$v, $l]) {
        $X = $tx + $i * ($tw + $gap);
        imagefilledrectangle($im, $X, $ty, $X + $tw, $ty + 82, hexcol($im, '#ffffff', 118));
        imagerectangle($im, $X, $ty, $X + $tw, $ty + 82, hexcol($im, '#f3c969', 95));
        text($im, fit_size(32, 20, $D, $v, $tw - 30), $X + 16, $ty + 46, $i === 2 || $i === 3 ? hexcol($im, '#ffd98a') : ($i === 1 ? hexcol($im, '#ff7a6b') : $cream), $D, $v);
        text_spaced($im, 10, $X + 16, $ty + 68, $muted, $B, $l, 1.5);
    }

    // the tug of war
    $by = 540; $bw = 4 * $tw + 3 * $gap; $tot = max(1, $d['g']);
    $sp = $d['g'] ? $sg / $tot : .5; $split = (int)($x + $bw * $sp);
    imagefilledrectangle($im, $x, $by, $x + $bw, $by + 12, hexcol($im, '#ffffff', 115));
    if ($split > $x) imagefilledrectangle($im, $x, $by, max($x, $split - 2), $by + 12, $ver);
    if ($split < $x + $bw) imagefilledrectangle($im, min($x + $bw, $split + 2), $by, $x + $bw, $by + 12, $gold);
    $beat = $d['beaten'] ? number_format($d['beaten']) . ' ' . ($d['beaten'] === 1 ? 'player has' : 'players have') . ' beaten it' : 'Nobody has beaten it yet';
    text($im, 15, $x, $by + 40, $muted, $B, $beat);
    $site = 'Play free at shyonsol.io  ·  $SHY';
    text($im, 15, $x + $bw - text_w(15, $B, $site), $by + 40, $gold, $B, $site);

    imagejpeg($im, $out, 90);
    imagedestroy($im);
}


//MC 2026-10-15 ---------------------------------------------------------------- the Telegram hype cards (see ?nj= ?nh= ?tw=)
// a red stamp box with a big line and a small one, the call to action on every card
function hype_stamp($im, $x, $y, $big, $small, $fill = '#e0453a') {
    $D = 'brico-800.ttf'; $B = 'inter-700.ttf';
    $w = max(text_w(26, $D, $big), text_w(15, $B, $small)) + 44;
    imagefilledrectangle($im, $x + 5, $y + 6, $x + $w + 5, $y + 76, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $x, $y, $x + $w, $y + 70, hexcol($im, $fill));
    imagerectangle($im, $x + 5, $y + 5, $x + $w - 5, $y + 65, hexcol($im, '#fff0dc', 70));
    text($im, 26, $x + 22, $y + 38, hexcol($im, '#fff7e8'), $D, $big);
    text($im, 15, $x + 22, $y + 59, hexcol($im, '#ffe3d6'), $B, $small);
    return $w;
}
function paste_png($im, $file, $x, $y, $w, $h) {
    $src = @imagecreatefrompng($file); if (!$src) return;
    imagealphablending($im, true); imagecopyresampled($im, $src, (int)$x, (int)$y, 0, 0, (int)$w, (int)$h, imagesx($src), imagesy($src)); imagedestroy($src);
}
// wrap a line to at most two lines that fit $maxW
function hype_lines($size, $font, $s, $maxW) {
    if (text_w($size, $font, $s) <= $maxW) return [$s];
    $l1 = ''; $l2 = '';
    foreach (explode(' ', $s) as $wd) { if ($l2 === '' && text_w($size, $font, trim($l1 . ' ' . $wd)) <= $maxW) $l1 = trim($l1 . ' ' . $wd); else $l2 = trim($l2 . ' ' . $wd); }
    while ($l2 !== '' && text_w($size, $font, $l2) > $maxW) $l2 = mb_substr($l2, 0, -2) . '…';
    return [$l1, $l2];
}

// a new player: dawn over washi paper. A vermilion sun rises behind their mask, the 新 (new) seal is stamped on the frame,
// and their recruit number sits on a brush stroke like a fresh tally on the dojo wall.
function draw_join($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatefromjpeg(__DIR__ . '/share/wb-default.jpg'); if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    // clean paper: the left half of the washi (the right half has the profile card's sun baked in), mirrored across
    $half = imagecreatetruecolor(600, $H); imagecopy($half, $im, 0, 0, 0, 0, 600, $H); imageflip($half, IMG_FLIP_HORIZONTAL);
    imagecopy($im, $half, 600, 0, 0, 0, 600, $H); imagedestroy($half);
    imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $ink = hexcol($im, '#1c1510'); $muted = hexcol($im, '#6b5a48'); $red = hexcol($im, '#c42a1f');
    // the rising sun, soft at the edge, and thin cloud bands across it
    $sx = 905; $sy = 300;
    for ($r = 300; $r > 200; $r -= 4) imagefilledellipse($im, $sx, $sy, $r * 2, $r * 2, hexcol($im, '#e0453a', (int)(127 - 4 * (1 - ($r - 200) / 100))));
    imagefilledellipse($im, $sx, $sy, 400, 400, hexcol($im, '#d8382a', 8));
    // sun rays as thin ink spokes from the horizon
    $ray = hexcol($im, '#c42a1f', 112);
    for ($i = 0; $i < 18; $i++) { $a = M_PI + $i * M_PI / 17; imageline($im, $sx, $sy + 150, (int)($sx + cos($a) * 720), (int)($sy + 150 + sin($a) * 720), $ray); }
    $cloud = hexcol($im, '#f6ecd6', 20);
    foreach ([[730, 400, 300, 14], [800, 430, 360, 10], [690, 460, 260, 8], [860, 220, 230, 9]] as [$cx, $cy, $cw, $ch]) imagefilledrectangle($im, $cx, $cy, $cx + $cw, $cy + $ch, $cloud);
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#1c1510', 70)); imagesetthickness($im, 1);

    // the mask on the sun, framed in ink with a cream mat, tilted a touch like a pinned print
    $mask = $rec['mask'] !== '' && in_array($rec['mask'], MASKS, true) ? $rec['mask'] : ['ronin', 'monk', 'tiger', 'crane', 'kitsune', 'oni', 'unbound'][crc32($rec['n']) % 7];
    $mi = mask_card_img($mask) ?: @imagecreatefrompng(__DIR__ . '/share/av-' . $mask . '.png');
    $ms = 250; $frame = imagecreatetruecolor($ms + 28, $ms + 28);
    imagefilledrectangle($frame, 0, 0, $ms + 27, $ms + 27, imagecolorallocate($frame, 28, 21, 16));
    imagefilledrectangle($frame, 5, 5, $ms + 22, $ms + 22, imagecolorallocate($frame, 248, 239, 219));
    if ($mi) imagecopyresampled($frame, $mi, 14, 14, 0, 0, $ms, $ms, imagesx($mi), imagesy($mi));
    $rot = imagerotate($frame, -4, imagecolorallocatealpha($frame, 0, 0, 0, 127)); imagesavealpha($rot, true);
    $fx = (int)($sx - imagesx($rot) / 2); $fy = (int)($sy - imagesy($rot) / 2 - 10);
    imagefilledrectangle($im, $fx + 18, $fy + 22, $fx + imagesx($rot) - 6, $fy + imagesy($rot) + 2, hexcol($im, '#000000', 95));
    imagecopy($im, $rot, $fx, $fy, 0, 0, imagesx($rot), imagesy($rot));
    paste_png($im, __DIR__ . '/share/seal-new.png', $fx + imagesx($rot) - 92, $fy - 34, 118, 118);
    // their name on a black tab under the print
    $nm = clean_label($rec['n']); $nz = fit_size(24, 15, $D, $nm, 330); $tw = text_w($nz, $D, $nm) + 40;
    $tx = (int)($sx - $tw / 2); $ty = $fy + imagesy($rot) + 14;
    imagefilledrectangle($im, $tx + 4, $ty + 5, $tx + $tw + 4, $ty + 47, hexcol($im, '#000000', 90));
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 42, $ink);
    imagefilledrectangle($im, $tx, $ty, $tx + 5, $ty + 42, $red);
    text($im, $nz, $tx + 22, $ty + 30, hexcol($im, '#fbf1dc'), $D, $nm);

    // the words
    $x = 64;
    text_spaced($im, 13, $x, 84, $red, $B, 'NEW RECRUIT  ·  SHILLUMINATI ONLINE', 3);
    text($im, 52, $x - 2, 160, $ink, $M, 'A new player');
    text($im, 64, $x - 4, 242, $red, $M, 'has joined.');
    // the recruit number on the brush stroke
    tinted_png($im, __DIR__ . '/share/wb-brush.png', '#1c1510', $x - 30, 262);
    $no = '#' . number_format((int)$rec['no']);
    $nz2 = fit_size(70, 40, $D, $no, 330);
    text($im, $nz2, $x + 14, 362, hexcol($im, '#fbf1dc'), $D, $no);
    text_spaced($im, 13, $x + 26 + text_w($nz2, $D, $no), 326, hexcol($im, '#f3c969'), $B, 'RECRUIT', 2);
    // their first game, and who brought them
    $res = $rec['res'] === 'win' ? 'Won ' . $rec['mode'] . ' with ' . (int)$rec['reg'] . ' Regions, first try.' : ($rec['res'] === 'tie' ? 'Tied ' . $rec['mode'] . ' in their first game.' : 'First game: ' . $rec['mode'] . ', ' . (int)$rec['reg'] . ' Regions held.');
    $ly = 432;
    foreach (hype_lines(21, $R, $res, 560) as $ln) { text($im, 21, $x, $ly, $ink, $R, $ln); $ly += 30; }
    if ($rec['by'] !== '') { text($im, 19, $x, $ly, $muted, $B, 'Brought in by ' . clean_label($rec['by'])); $ly += 28; }
    hype_stamp($im, $x, 512, 'WELCOME THEM', 'then duel them free at shyonsol.io');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 64 - spaced_w(12, $B, $site, 2), 590, $ink, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

// a Shadow holder: night falls, the moon behind, and their Shadow wakes in its own Aura. Rings ripple out from it like a
// stone in still water; the 覚 (awaken) seal sits on the frame.
function draw_holdr($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatefromjpeg(__DIR__ . '/share/wb-moon.jpg'); if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    imagealphablending($im, true);
    imagefilledrectangle($im, 0, 0, $W, $H, hexcol($im, '#06040f', 58));   // deeper night
    for ($xx = 560; $xx < $W; $xx += 4) imagefilledrectangle($im, $xx, 0, $xx + 3, $H, hexcol($im, '#06040f', (int)max(60, 110 - ($xx - 560) / 3)));   // the words sit in shadow, the moon still shows
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $auc = ['cyan' => '#4cc9f0', 'crimson' => '#ff3b5c', 'lightning' => '#ffe066', 'money' => '#f2c35b', 'btc' => '#f7931a'][$rec['aura'] ?? ''] ?? '#a78bfa';
    $cream = hexcol($im, '#f4eefc'); $muted = hexcol($im, '#b9b2d6'); $aura = hexcol($im, $auc);
    $cx = 300; $cy = 300;
    // the Aura glow, then the ripples
    for ($r = 330; $r > 0; $r -= 6) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, $auc, (int)(127 - 7 * (1 - $r / 330))));
    imagesetthickness($im, 2);
    foreach ([[205, 70], [240, 88], [280, 100], [325, 110], [375, 118]] as [$rr, $al]) imageellipse($im, $cx, $cy, $rr * 2, $rr * 2, hexcol($im, $auc, $al));
    imagesetthickness($im, 1);
    // tiny stars
    mt_srand(crc32($rec['sh'] . 'stars'));
    for ($i = 0; $i < 90; $i++) { $x = mt_rand(560, $W - 30); $y = mt_rand(30, $H - 30); imagefilledellipse($im, $x, $y, mt_rand(1, 3), mt_rand(1, 3), hexcol($im, '#ffffff', mt_rand(40, 100))); }
    mt_srand();
    // the Shadow, framed in its Aura with corner brackets
    $av = avatar_image(['avatar' => (string)$rec['sh'], 'mask' => 'unbound']);
    $ss = 300; $sx0 = $cx - $ss / 2; $sy0 = $cy - $ss / 2;
    imagefilledrectangle($im, $sx0 - 10, $sy0 - 10, $sx0 + $ss + 9, $sy0 + $ss + 9, hexcol($im, '#05030b'));
    imagefilledrectangle($im, $sx0 - 5, $sy0 - 5, $sx0 + $ss + 4, $sy0 + $ss + 4, $aura);
    rounded_copy($im, $av, (int)$sx0, (int)$sy0, $ss, 6);
    imagesetthickness($im, 4);
    $bl = 34; $o = 24;
    foreach ([[-1, -1], [1, -1], [-1, 1], [1, 1]] as [$dx, $dy]) {
        $px = $dx < 0 ? $sx0 - $o : $sx0 + $ss + $o; $py = $dy < 0 ? $sy0 - $o : $sy0 + $ss + $o;
        imageline($im, (int)$px, (int)$py, (int)($px - $dx * $bl), (int)$py, $aura); imageline($im, (int)$px, (int)$py, (int)$px, (int)($py - $dy * $bl), $aura);
    }
    imagesetthickness($im, 1);
    paste_png($im, __DIR__ . '/share/seal-wake.png', $sx0 + $ss - 70, $sy0 + $ss - 64, 112, 112);
    // more of their Shadows, small, under the big one
    $more = array_values(array_filter((array)($rec['all'] ?? []), fn($n) => (string)$n !== (string)$rec['sh']));
    if ($more) {
        $t = 46; $gx = (int)($cx - (min(4, count($more)) * ($t + 8) - 8) / 2); $gy = (int)($sy0 + $ss + 38);
        foreach (array_slice($more, 0, 4) as $i => $n) {
            $mi = avatar_image(['avatar' => (string)$n, 'mask' => 'unbound']);
            imagefilledrectangle($im, $gx - 2, $gy - 2, $gx + $t + 1, $gy + $t + 1, $aura);
            rounded_copy($im, $mi, $gx, $gy, $t, 3); $gx += $t + 8;
        }
    }

    // the words
    $x = 600;
    text_spaced($im, 13, $x, 84, $aura, $B, 'SHADOW AWAKENED  ·  SHYTOSHI SHADOWS', 3);
    text($im, 52, $x - 2, 160, $cream, $M, 'A Shadow');
    text($im, 58, $x - 4, 236, $aura, $M, 'has awakened.');
    $nm = clean_label($rec['n']);
    $who = $nm . ' brought Shadow #' . $rec['sh'] . ' to the table.';
    $ly = 290; foreach (hype_lines(22, $R, $who, 540) as $ln) { text($im, 22, $x, $ly, $cream, $R, $ln); $ly += 32; }
    // trait chips
    $chips = array_values(array_filter([
        $rec['auraName'] !== '' ? ['AURA', strtoupper($rec['auraName'])] : null,
        $rec['rank'] !== '' ? ['RARITY', strtoupper((string)$rec['rank'])] : null,
        $rec['tier'] !== '' ? ['$SHY RANK', strtoupper($rec['tier'])] : null,
        (int)$rec['cnt'] > 1 ? ['SHADOWS', (string)(int)$rec['cnt']] : null,
    ]));
    $chx = $x; $chy = $ly + 10;
    foreach ($chips as [$k, $v]) {
        $w = spaced_w(10, $B, $k, 1.5) + text_w(15, $B, $v) + 40;
        if ($chx + $w > $W - 50) { $chx = $x; $chy += 50; }
        imagefilledrectangle($im, $chx, $chy, $chx + $w, $chy + 38, hexcol($im, '#ffffff', 112));
        imagerectangle($im, $chx, $chy, $chx + $w, $chy + 38, hexcol($im, $auc, 60));
        text_spaced($im, 10, $chx + 14, $chy + 24, $muted, $B, $k, 1.5);
        text($im, 15, $chx + 26 + spaced_w(10, $B, $k, 1.5), $chy + 25, $cream, $B, $v);
        $chx += $w + 10;
    }
    hype_stamp($im, $x, 512, 'MINT YOUR SHADOW', 'launchmynft.io/mint/shyshadows', '#5b3bd6');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 60 - spaced_w(12, $B, $site, 2), 600, $muted, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-16 a newly minted Shadow: a gold and black lacquer vault. The Shadow's own art (read from its NFT, since a
//   brand new one isn't in the game's list yet) sits in a gold frame inside its Aura, gold dust rises off it like sparks
//   off fresh metal, and the 鋳 (cast, minted) seal is stamped on the frame. The right side has its number, Aura and
//   rarity, who collected it and a gold bar of how much of the collection is out.
function mintc_art($rec) {
    $n = preg_replace('/\D/', '', (string)$rec['sh']);
    $cache = SHARES . '/nft-' . $n . '.img';
    $url = (string)($rec['img'] ?? '');
    if ($n !== '' && !is_file($cache) && preg_match('#^https://#', $url)) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 10, CURLOPT_MAXFILESIZE => 8000000]);
        $data = curl_exec($ch); curl_close($ch);
        if ($data && @imagecreatefromstring($data)) { $t = $cache . '.tmp' . getmypid(); if (file_put_contents($t, $data) === strlen($data)) rename($t, $cache); else @unlink($t); }
    }
    if (is_file($cache)) { $im = @imagecreatefromstring(file_get_contents($cache)); if ($im) return $im; }
    return avatar_image(['avatar' => (string)$rec['sh'], 'mask' => 'unbound']);
}
function draw_mintc($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(16 - 10 * $k), (int)(11 - 7 * $k), (int)(10 - 6 * $k))); }
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $an = strtolower((string)($rec['auraName'] ?? ''));
    $ak = ''; foreach (['cyan', 'crimson', 'lightning', 'money', 'btc'] as $k) if (strpos($an, $k) !== false) $ak = $k;
    $auc = ['cyan' => '#4cc9f0', 'crimson' => '#ff3b5c', 'lightning' => '#ffe066', 'money' => '#f2c35b', 'btc' => '#f7931a'][$ak] ?? '#a78bfa';
    $goldHex = '#e8b23a';
    $gold = hexcol($im, $goldHex); $goldLt = hexcol($im, '#f7d98a'); $cream = hexcol($im, '#fbf3e2'); $muted = hexcol($im, '#c9bba0'); $aura = hexcol($im, $auc);
    // a soft gold sheen across the lacquer
    for ($i = 0; $i < 7; $i++) { $x0 = 520 + $i * 26; imagefilledpolygon($im, [$x0, 0, $x0 + 16, 0, $x0 - 330, $H, $x0 - 346, $H], hexcol($im, '#f7d98a', 121)); }
    $cx = 300; $cy = 300;
    // the Aura glow, then a ring of gold
    for ($r = 340; $r > 0; $r -= 6) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, $auc, (int)(127 - 7 * (1 - $r / 340))));
    imagesetthickness($im, 2);
    foreach ([[228, 76], [262, 96], [300, 110]] as [$rr, $al]) imageellipse($im, $cx, $cy, $rr * 2, $rr * 2, hexcol($im, $goldHex, $al));
    imagesetthickness($im, 1);
    // gold dust rising off it, thicker low down
    mt_srand(crc32($rec['sh'] . 'dust'));
    for ($i = 0; $i < 170; $i++) {
        $y = (int)(630 - pow(mt_rand(0, 1000) / 1000, 1.6) * 600); $x = (int)($cx + (mt_rand(-1000, 1000) / 1000) * (200 + (630 - $y) * 0.35));
        $z = mt_rand(1, 4); imagefilledellipse($im, $x, $y, $z, $z, hexcol($im, mt_rand(0, 4) ? '#f7d98a' : $auc, mt_rand(20, 90)));
    }
    for ($i = 0; $i < 60; $i++) { $x = mt_rand(600, $W - 40); $y = mt_rand(30, $H - 30); imagefilledellipse($im, $x, $y, 2, 2, hexcol($im, '#f7d98a', mt_rand(90, 118))); }
    mt_srand();
    // the Shadow in its gold frame
    $art = mintc_art($rec);
    $ss = 330; $sx0 = (int)($cx - $ss / 2); $sy0 = (int)($cy - $ss / 2);
    imagefilledrectangle($im, $sx0 - 4, $sy0 + 10, $sx0 + $ss + 22, $sy0 + $ss + 26, hexcol($im, '#000000', 40));
    imagefilledrectangle($im, $sx0 - 14, $sy0 - 14, $sx0 + $ss + 13, $sy0 + $ss + 13, $gold);
    imagefilledrectangle($im, $sx0 - 9, $sy0 - 9, $sx0 + $ss + 8, $sy0 + $ss + 8, hexcol($im, '#120c06'));
    imagerectangle($im, $sx0 - 12, $sy0 - 12, $sx0 + $ss + 11, $sy0 + $ss + 11, $goldLt);
    rounded_copy($im, $art, $sx0, $sy0, $ss, 4);
    imagesetthickness($im, 4);
    $bl = 36; $o = 30;
    foreach ([[-1, -1], [1, -1], [-1, 1], [1, 1]] as [$dx, $dy]) {
        $px = $dx < 0 ? $sx0 - $o : $sx0 + $ss + $o; $py = $dy < 0 ? $sy0 - $o : $sy0 + $ss + $o;
        imageline($im, (int)$px, (int)$py, (int)($px - $dx * $bl), (int)$py, $aura); imageline($im, (int)$px, (int)$py, (int)$px, (int)($py - $dy * $bl), $aura);
    }
    imagesetthickness($im, 1);
    paste_png($im, __DIR__ . '/share/seal-mint.png', $sx0 + $ss - 74, $sy0 + $ss - 66, 116, 116);

    // the words
    $x = 612;
    text_spaced($im, 13, $x, 82, $gold, $B, 'FRESHLY MINTED  ·  SHYTOSHI SHADOWS', 3);
    text($im, 46, $x - 2, 146, $cream, $M, 'Shadow');
    $no = '#' . (int)$rec['sh'];
    $nz = fit_size(104, 60, $D, $no, 520);
    text($im, $nz, $x - 6, 254, hexcol($im, '#2a1a06'), $D, $no);
    text($im, $nz, $x - 8, 250, $gold, $D, $no);
    text($im, 22, $x + text_w($nz, $D, $no) + 16, 250, $muted, $R, 'has been cast.');
    $who = 'Collected by ' . clean_label((string)$rec['who']);
    text($im, 21, $x, 298, $cream, $B, $who);
    // trait chips
    $chips = array_values(array_filter([
        ($rec['auraName'] ?? '') !== '' ? ['AURA', strtoupper((string)$rec['auraName'])] : null,
        ($rec['rank'] ?? '') !== '' ? ['RARITY', strtoupper((string)$rec['rank'])] : null,
    ]));
    $chx = $x; $chy = 318;
    foreach ($chips as [$k, $v]) {
        $w = spaced_w(10, $B, $k, 1.5) + text_w(15, $B, $v) + 40;
        imagefilledrectangle($im, $chx, $chy, $chx + $w, $chy + 38, hexcol($im, '#ffffff', 114));
        imagerectangle($im, $chx, $chy, $chx + $w, $chy + 38, hexcol($im, $k === 'AURA' ? $auc : $goldHex, 50));
        text_spaced($im, 10, $chx + 14, $chy + 24, $muted, $B, $k, 1.5);
        text($im, 15, $chx + 26 + spaced_w(10, $B, $k, 1.5), $chy + 25, $cream, $B, $v);
        $chx += $w + 10;
    }
    // how much of the collection is out
    $tot = max(1, (int)$rec['total']); $mn = max(0, min($tot, (int)$rec['minted'])); $bw = 520; $by = 416;
    text_spaced($im, 11, $x, $by - 12, $goldLt, $B, number_format($mn) . ' OF ' . number_format($tot) . ' MINTED', 2);
    $lt = number_format($tot - $mn) . ' LEFT';
    text_spaced($im, 11, $x + $bw - spaced_w(11, $B, $lt, 2), $by - 12, $muted, $B, $lt, 2);
    imagefilledrectangle($im, $x, $by, $x + $bw, $by + 14, hexcol($im, '#ffffff', 112));
    $fw = max(6, (int)round($bw * $mn / $tot));
    for ($i = 0; $i < $fw; $i++) { $k = $i / max(1, $bw); imageline($im, $x + $i, $by, $x + $i, $by + 14, imagecolorallocate($im, (int)(196 + 50 * $k), (int)(140 + 70 * $k), (int)(40 + 60 * $k))); }
    imagefilledrectangle($im, $x + $fw - 3, $by - 3, $x + $fw + 2, $by + 17, $cream);
    imagerectangle($im, $x, $by, $x + $bw, $by + 14, hexcol($im, $goldHex, 70));
    hype_stamp($im, $x, 470, 'MINT YOURS', 'launchmynft.io/mint/shyshadows', '#b8831c');
    // a thin gold double frame round the card
    imagerectangle($im, 16, 16, $W - 17, $H - 17, hexcol($im, $goldHex, 60));
    imagerectangle($im, 22, 22, $W - 23, $H - 23, hexcol($im, $goldHex, 100));
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 60 - spaced_w(12, $B, $site, 2), 598, $muted, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-16 ?ne=: an expedition came home with treasure or a relic (exp_tg_find in expedition.php). An explorer's map
//   on washi: a compass rose, the ink route the Shadow walked ending on a red X, the Shadow pinned to the map like a
//   field print with the 宝 (treasure) or 遺 (relic) seal, and the Koban it brought back on a brush stroke.
function draw_expfd($rec, $out) {
    $W = 1200; $H = 630;
    $relic = ($rec['find'] ?? '') === 'relic';
    $im = imagecreatefromjpeg(__DIR__ . '/share/wb-default.jpg'); if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    $half = imagecreatetruecolor(600, $H); imagecopy($half, $im, 0, 0, 0, 0, 600, $H); imageflip($half, IMG_FLIP_HORIZONTAL);
    imagecopy($im, $half, 600, 0, 0, 0, 600, $H); imagedestroy($half);
    imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $ink = hexcol($im, '#1c1510'); $muted = hexcol($im, '#6b5a48'); $red = hexcol($im, '#c42a1f');
    $accHex = $relic ? '#1f7a66' : '#b8831c'; $acc = hexcol($im, $accHex);
    // the map: faint ink grid, coast lines, the compass rose
    $grid = hexcol($im, '#1c1510', 116);
    for ($x = 640; $x < $W - 20; $x += 48) imageline($im, $x, 30, $x, $H - 30, $grid);
    for ($y = 54; $y < $H - 20; $y += 48) imageline($im, 620, $y, $W - 30, $y, $grid);
    mt_srand(crc32($rec['region'] . 'coast'));
    $coast = hexcol($im, '#1c1510', 96);
    imagesetthickness($im, 2);
    foreach ([[660, 140, 300], [700, 470, 260], [960, 520, 210]] as [$x0, $y0, $len]) {
        $px = $x0; $py = $y0;
        for ($i = 0; $i < $len; $i += 12) { $nx = $px + 12; $ny = $py + mt_rand(-9, 9); imageline($im, $px, $py, $nx, $ny, $coast); $px = $nx; $py = $ny; }
    }
    mt_srand();
    $rx = 1050; $ry = 130;
    imageellipse($im, $rx, $ry, 150, 150, hexcol($im, '#1c1510', 80)); imageellipse($im, $rx, $ry, 120, 120, hexcol($im, '#1c1510', 100));
    foreach ([[0, -1], [1, 0], [0, 1], [-1, 0]] as $i => [$dx, $dy]) {
        $tip = [$rx + $dx * 74, $ry + $dy * 74]; $l = [$rx - $dy * 12, $ry + $dx * 12]; $r2 = [$rx + $dy * 12, $ry - $dx * 12];
        imagefilledpolygon($im, [(int)$tip[0], (int)$tip[1], (int)$l[0], (int)$l[1], $rx, $ry], $i === 0 ? $red : $ink);
        imagefilledpolygon($im, [(int)$tip[0], (int)$tip[1], (int)$r2[0], (int)$r2[1], $rx, $ry], hexcol($im, '#1c1510', 60));
    }
    text($im, 15, $rx - 6, $ry - 82, $red, $B, 'N');
    // the route: dashed ink from the edge of the map to the red X under the print
    $sx = 900; $sy = 320;
    $pts = []; $ax = 640; $ay = 548; $bx = 1120; $by = 462;   // from the bottom left corner of the map, round under the print, to the X
    for ($t = 0; $t <= 1.0001; $t += 0.02) { $pts[] = [(int)($ax + ($bx - $ax) * $t), (int)($ay + ($by - $ay) * $t + sin($t * M_PI) * 22 - sin($t * M_PI * 2) * 18)]; }
    imagesetthickness($im, 4);
    for ($i = 0; $i < count($pts) - 1; $i += 2) imageline($im, $pts[$i][0], $pts[$i][1], $pts[$i + 1][0], $pts[$i + 1][1], hexcol($im, '#c42a1f', 10));
    $ex = end($pts);
    imagesetthickness($im, 7);
    imageline($im, $ex[0] - 18, $ex[1] - 18, $ex[0] + 18, $ex[1] + 18, $red); imageline($im, $ex[0] - 18, $ex[1] + 18, $ex[0] + 18, $ex[1] - 18, $red);
    imagesetthickness($im, 2); imageellipse($im, $ex[0], $ex[1], 62, 62, hexcol($im, '#c42a1f', 40));
    imagesetthickness($im, 1);
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#1c1510', 70)); imagesetthickness($im, 1);

    // the Shadow as a pinned field print
    $av = avatar_image(['avatar' => (string)($rec['sh'] ?? ''), 'mask' => 'unbound']);
    $ms = 240; $frame = imagecreatetruecolor($ms + 28, $ms + 28);
    imagefilledrectangle($frame, 0, 0, $ms + 27, $ms + 27, imagecolorallocate($frame, 28, 21, 16));
    imagefilledrectangle($frame, 5, 5, $ms + 22, $ms + 22, imagecolorallocate($frame, 248, 239, 219));
    imagecopyresampled($frame, $av, 14, 14, 0, 0, $ms, $ms, imagesx($av), imagesy($av));
    $rot = imagerotate($frame, 5, imagecolorallocatealpha($frame, 0, 0, 0, 127)); imagesavealpha($rot, true);
    $fx = (int)($sx - imagesx($rot) / 2); $fy = (int)($sy - imagesy($rot) / 2 - 20);
    imagefilledrectangle($im, $fx + 18, $fy + 22, $fx + imagesx($rot) - 6, $fy + imagesy($rot) + 2, hexcol($im, '#000000', 95));
    imagecopy($im, $rot, $fx, $fy, 0, 0, imagesx($rot), imagesy($rot));
    imagefilledellipse($im, $fx + (int)(imagesx($rot) / 2), $fy + 10, 18, 18, $red); imagefilledellipse($im, $fx + (int)(imagesx($rot) / 2) - 3, $fy + 7, 6, 6, hexcol($im, '#ffffff', 60));
    paste_png($im, __DIR__ . '/share/seal-' . ($relic ? 'relic' : 'treasure') . '.png', $fx + imagesx($rot) - 90, $fy + imagesy($rot) - 96, 116, 116);
    // the Shadow's name tab
    $tag = $rec['sh'] !== '' ? 'Shadow #' . $rec['sh'] : 'Unbound';
    $tw = text_w(17, $B, $tag) + 30; $tx = (int)($sx - $tw / 2); $ty = $fy + imagesy($rot) + 10;
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 34, $ink); imagefilledrectangle($im, $tx, $ty, $tx + 5, $ty + 34, $acc);
    text($im, 17, $tx + 17, $ty + 24, hexcol($im, '#fbf1dc'), $B, $tag);

    // the words
    $x = 64;
    text_spaced($im, 13, $x, 84, $red, $B, 'SHADOW EXPEDITION  ·  ' . ($relic ? 'RELIC FOUND' : 'TREASURE FOUND'), 3);
    text($im, 56, $x - 2, 160, $ink, $M, $relic ? 'A relic,' : 'Treasure,');
    $rg = 'found in ' . (string)$rec['region'];
    $rz = fit_size(40, 24, $M, $rg, 500);
    text($im, $rz, $x - 2, 222, $acc, $M, $rg);
    $who = clean_label((string)$rec['n']) . '\'s ' . ($rec['sh'] !== '' ? 'Shadow' : 'mask') . ' came home from a ' . (string)$rec['len'] . ' with';
    $ly = 268; foreach (hype_lines(20, $R, $who, 500) as $ln) { text($im, 20, $x, $ly, $ink, $R, $ln); $ly += 28; }
    // the haul on the brush stroke
    tinted_png($im, __DIR__ . '/share/wb-brush.png', '#1c1510', $x - 30, $ly - 12);
    $kb = '+' . number_format((int)$rec['koban']);
    $kz = fit_size(66, 40, $D, $kb, 300);
    text($im, $kz, $x + 14, $ly + 86, hexcol($im, '#fbf1dc'), $D, $kb);
    text_spaced($im, 13, $x + 26 + text_w($kz, $D, $kb), $ly + 52, hexcol($im, '#f3c969'), $B, 'KOBAN', 2);
    hype_stamp($im, $x, 512, 'SEND YOUR SHADOW', 'Expeditions at shyonsol.io/play', $relic ? '#1f7a66' : '#c42a1f');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 64 - spaced_w(12, $B, $site, 2), 590, $ink, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-16 ?nb=: a limited bundle going on sale (tg_offers in tg.php). A night storm over the dojo: rain in streaks,
//   forked lightning behind the 雷 (thunder) seal, the gear in the bundle listed like a merchant's ledger with what each
//   piece costs in Koban, and the price in a bright cyan plaque with when it ends.
function offr_bolt($im, $x, $y, $len, $col, $seed) {
    mt_srand($seed); $px = $x; $py = $y;
    imagesetthickness($im, 3);
    while ($py < $y + $len) { $nx = $px + mt_rand(-34, 34); $ny = $py + mt_rand(22, 46); imageline($im, $px, $py, $nx, $ny, $col);
        if (mt_rand(0, 4) === 0) { $bx = $nx + mt_rand(-60, 60); imageline($im, $nx, $ny, $bx, $ny + mt_rand(30, 70), $col); }
        $px = $nx; $py = $ny; }
    imagesetthickness($im, 1); mt_srand();
}
function draw_offr($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(20 - 10 * $k), (int)(14 - 6 * $k), (int)(52 - 30 * $k))); }
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $cyan = hexcol($im, '#7fdcff'); $cream = hexcol($im, '#f2f6ff'); $muted = hexcol($im, '#a9b2d8'); $vio = hexcol($im, '#8f7bff');
    // the storm glow and the rain
    $cx = 270; $cy = 300;
    for ($r = 330; $r > 0; $r -= 6) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, '#5b4bd6', (int)(127 - 7 * (1 - $r / 330))));
    mt_srand(crc32($rec['n'] . 'rain'));
    for ($i = 0; $i < 260; $i++) { $x = mt_rand(0, $W); $y = mt_rand(-40, $H); $l = mt_rand(14, 34); imageline($im, $x, $y, $x - (int)($l * .35), $y + $l, hexcol($im, '#b8c8ff', mt_rand(96, 118))); }
    mt_srand();
    offr_bolt($im, 120, 0, 330, hexcol($im, '#dff6ff', 20), 7); offr_bolt($im, 420, 0, 260, hexcol($im, '#dff6ff', 50), 11);
    offr_bolt($im, 120, 0, 330, hexcol($im, '#7fdcff', 90), 7);
    // the seal, big, glowing
    for ($r = 150; $r > 90; $r -= 6) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, '#7fdcff', 118));
    paste_png($im, __DIR__ . '/share/seal-storm.png', $cx - 130, $cy - 130, 260, 260);
    text_spaced($im, 13, $cx - (int)(spaced_w(13, $B, 'WEEKEND ONLY', 3) / 2), $cy + 175, $cyan, $B, 'WEEKEND ONLY', 3);

    // the words
    $x = 560;
    text_spaced($im, 13, $x, 74, $cyan, $B, ($rec['last'] ? 'LAST HOURS' : 'NEW IN THE DOJO SHOP') . '  ·  LIMITED BUNDLE', 3);
    text($im, 58, $x - 2, 146, $cream, $M, 'Raijin');
    text($im, 34, $x, 196, $vio, $M, 'Weekend Bundle');
    // the ledger
    $ly = 236; $lw = 580;
    foreach ($rec['items'] as [$nm, $kb, $slot]) {
        if ($kb <= 0) continue;
        text($im, 18, $x, $ly + 22, $cream, $B, clean_label($nm));
        $kv = number_format($kb) . ' KOBAN';
        text_spaced($im, 11, $x + $lw - spaced_w(11, $B, $kv, 1.5), $ly + 21, $muted, $B, $kv, 1.5);
        for ($dx = $x + text_w(18, $B, clean_label($nm)) + 12; $dx < $x + $lw - spaced_w(11, $B, $kv, 1.5) - 12; $dx += 7) imagefilledellipse($im, $dx, $ly + 17, 2, 2, hexcol($im, '#a9b2d8', 80));
        $ly += 34;
    }
    $extra = '+ ' . number_format((int)$rec['koban']) . ' Koban and the Stormcaller title, never sold again';
    foreach (hype_lines(17, $R, $extra, $lw) as $ln) { text($im, 17, $x, $ly + 22, $cyan, $R, $ln); $ly += 26; }
    // the price plaque
    $py = 476;
    imagefilledrectangle($im, $x + 6, $py + 7, $x + 306, $py + 87, hexcol($im, '#000000', 70));
    imagefilledrectangle($im, $x, $py, $x + 300, $py + 80, hexcol($im, '#7fdcff'));
    imagerectangle($im, $x + 5, $py + 5, $x + 295, $py + 75, hexcol($im, '#0d0a26', 80));
    $pr = '$' . number_format((float)$rec['usd'], 2);
    text($im, 36, $x + 20, $py + 50, hexcol($im, '#0d0a26'), $D, $pr);
    text($im, 14, $x + 28 + text_w(36, $D, $pr), $py + 48, hexcol($im, '#1d1650'), $B, 'IN $SHY');
    text($im, 13, $x + 20, $py + 70, hexcol($im, '#1d1650'), $B, 'One per player');
    $wk = number_format(floor((int)$rec['worth'] / 1000) * 1000) . '+';
    text($im, 30, $x + 330, $py + 40, $cream, $D, $wk);
    text_spaced($im, 11, $x + 332, $py + 62, $muted, $B, 'KOBAN OF GEAR INSIDE', 1.5);
    $site = 'ENDS SUNDAY, MIDNIGHT EASTERN  ·  SHYONSOL.IO';
    text_spaced($im, 12, $W - 50 - spaced_w(12, $B, $site, 2), 600, $muted, $B, $site, 2);
    imagerectangle($im, 16, 16, $W - 17, $H - 17, hexcol($im, '#7fdcff', 90));
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-16 ?nk=: the burn tracker as a card for the pinned Telegram post (tg_burn_update), drawn like the tracker on the
//   Treasury page: the total burned in big ember numbers, the bar of how much of all $SHY is gone, the burn that just
//   happened under the 燃 (burn) seal, and the latest burns down the right. Embers drift up from the bottom.
function burnc_flame($im, $x, $y, $s) {
    imagefilledellipse($im, $x, $y + (int)($s * .25), (int)($s * .8), (int)($s * .8), hexcol($im, '#ff7a2f'));
    imagefilledpolygon($im, [$x - (int)($s * .4), $y + (int)($s * .2), $x, $y - (int)($s * .6), $x + (int)($s * .4), $y + (int)($s * .2)], hexcol($im, '#ff7a2f'));
    imagefilledellipse($im, $x, $y + (int)($s * .32), (int)($s * .42), (int)($s * .42), hexcol($im, '#ffd36b'));
}
function burnc_lab($s) { return trim(mb_substr(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string)$s), 0, 60)); }   // the whole label (clean_label stops at 20 letters, for names)
function burnc_fit($size, $font, $s, $max) { if (text_w($size, $font, $s) <= $max) return $s; while ($s !== '' && text_w($size, $font, $s . '…') > $max) $s = mb_substr($s, 0, -1); return rtrim($s) . '…'; }
function burnc_ago($d) { return $d < 3600 ? max(1, (int)floor($d / 60)) . 'm ago' : ($d < 86400 ? (int)floor($d / 3600) . 'h ago' : (int)floor($d / 86400) . 'd ago'); }
function draw_burnc($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(34 - 18 * $k), (int)(14 - 4 * $k), (int)(22 - 4 * $k))); }
    for ($r = 520; $r > 0; $r -= 8) imagefilledellipse($im, 120, 60, $r * 2, (int)($r * 1.3), hexcol($im, '#c42a1f', (int)(127 - 5 * (1 - $r / 520))));
    $D = 'brico-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $ember = hexcol($im, '#ffb36b'); $cream = hexcol($im, '#f7ece4'); $muted = hexcol($im, '#c4b2b6'); $red = hexcol($im, '#ff5a3c');
    mt_srand(crc32((string)$rec['t'] . 'embers'));
    for ($i = 0; $i < 70; $i++) { $x = mt_rand(30, $W - 30); $y = (int)($H - pow(mt_rand(0, 1000) / 1000, 1.8) * 420); $z = mt_rand(2, 5); imagefilledellipse($im, $x, $y, $z, $z, hexcol($im, mt_rand(0, 2) ? '#ff8a3c' : '#ffd36b', mt_rand(30, 90))); }
    mt_srand();
    imagerectangle($im, 16, 16, $W - 17, $H - 17, hexcol($im, '#c42a1f', 60));
    // left: the total
    $x = 56;
    imagefilledellipse($im, $x + 7, 60, 12, 12, $red);
    text_spaced($im, 13, $x + 22, 66, hexcol($im, '#ff9a7a'), $B, 'LIVE BURN TRACKER', 2.5);
    text_spaced($im, 11, $x, 112, $muted, $B, 'TOTAL $SHY BURNED', 2);
    $tot = number_format((int)$rec['total']); $tz = fit_size(78, 50, $D, $tot, 560);
    text($im, $tz, $x - 3, 196, hexcol($im, '#5a1f0c'), $D, $tot);
    text($im, $tz, $x - 5, 192, $ember, $D, $tot);
    $bw = 560; $by = 222; $fw = (int)round($bw * max(0, min(100, (float)$rec['pct'])) / 100);
    imagefilledrectangle($im, $x, $by, $x + $bw, $by + 16, hexcol($im, '#000000', 60));
    for ($i = 0; $i < $fw; $i++) { $k = $i / max(1, $fw); imageline($im, $x + $i, $by, $x + $i, $by + 16, imagecolorallocate($im, (int)(255 - 60 * sin($k * M_PI)), (int)(120 - 80 * sin($k * M_PI)), (int)(60 - 30 * $k))); }
    text($im, 17, $x, 270, $ember, $B, number_format((float)$rec['pct'], 2) . '%');
    text($im, 17, $x + text_w(17, $B, number_format((float)$rec['pct'], 2) . '%') + 8, 270, $cream, $R, 'of all $SHY ever minted is gone.');
    // the burn that just happened
    $th = $rec['this'] ?? ['shy' => 0];
    $bx = $x; $by2 = 306; $bw2 = 560; $bh = 150;
    imagefilledrectangle($im, $bx, $by2, $bx + $bw2, $by2 + $bh, hexcol($im, '#2a0f0c', 30));
    imagerectangle($im, $bx, $by2, $bx + $bw2, $by2 + $bh, hexcol($im, '#ff8a3c', 70));
    paste_png($im, __DIR__ . '/share/seal-burn.png', $bx + 22, $by2 + 24, 100, 100);
    if ((int)$th['shy'] > 0) {
        text_spaced($im, 11, $bx + 142, $by2 + 40, hexcol($im, '#ffb36b'), $B, 'JUST BURNED', 2);
        $js = '+' . number_format((int)$th['shy']) . ' $SHY';
        text($im, fit_size(40, 26, $D, $js, 390), $bx + 140, $by2 + 88, $cream, $D, $js);
        $sub = trim(burnc_lab((string)$th['what']) . (($th['name'] ?? '') !== '' ? '  ·  ' . burnc_lab((string)$th['name']) : ''));
        text($im, 16, $bx + 142, $by2 + 118, $muted, $R, burnc_fit(16, $R, $sub, 400));
    } else {
        text_spaced($im, 11, $bx + 142, $by2 + 40, hexcol($im, '#ffb36b'), $B, 'THE FOUNDING BURN', 2);
        text($im, 30, $bx + 140, $by2 + 84, $cream, $D, '500,000,000 $SHY');
        text($im, 16, $bx + 142, $by2 + 114, $muted, $R, 'Jan 26, 2025, half of every $SHY that will ever exist.');
    }
    $pct = (int)($rec['bp'] ?? 0);
    $foot = $pct ? $pct . '% of every $SHY shop sale burns in the buyer\'s own transaction.' : 'Every burn is on the Treasury page.';
    foreach (hype_lines(16, $R, $foot, 560) as $i => $ln) text($im, 16, $x, 500 + $i * 22, $muted, $R, $ln);
    text_spaced($im, 12, $x, 586, hexcol($im, '#ff9a7a'), $B, 'SHYONSOL.IO/TREASURY', 2);
    // right: the latest burns
    $rx = 660; $rw = 488;
    text_spaced($im, 11, $rx, 66, $muted, $B, 'LATEST BURNS', 2);
    $ry = 86; $now = (int)$rec['t'];
    foreach (array_slice((array)$rec['list'], 0, 7) as $i => $b) {
        $hl = $i === 0 && (int)$th['shy'] > 0;
        imagefilledrectangle($im, $rx, $ry, $rx + $rw, $ry + 60, hexcol($im, $hl ? '#3a160c' : '#160a0c', $hl ? 20 : 30));
        imagerectangle($im, $rx, $ry, $rx + $rw, $ry + 60, hexcol($im, $hl ? '#ff8a3c' : '#ffffff', $hl ? 60 : 112));
        burnc_flame($im, $rx + 24, $ry + 28, 18);
        $amt = number_format((int)$b['shy']) . ' $SHY';
        text($im, 17, $rx + 46, $ry + 37, hexcol($im, '#ffd36b'), $D, $amt);
        $ago = burnc_ago(max(0, $now - (int)$b['t']));
        $aw = text_w(13, $R, $ago);
        text($im, 13, $rx + $rw - 16 - $aw, $ry + 36, $muted, $R, $ago);
        $lab = burnc_lab((string)$b['what']) . ((string)$b['name'] !== '' ? ' · ' . burnc_lab((string)$b['name']) : '');
        $lx = $rx + 58 + text_w(17, $D, $amt);
        $lab = burnc_fit(13, $R, $lab, $rx + $rw - 28 - $aw - $lx);
        text($im, 13, $lx, $ry + 36, $cream, $R, $lab);
        $ry += 70;
    }
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-17 a $SHY buy on Shy Swap: the night swap card. The 換 (exchange) seal, how much $SHY landed, what it cost,
//   and who bought it (their player name, or a shortened wallet, never both). Coins rise behind the amount.
function swapc_num($v) {
    $v = (float)$v;
    if ($v < 1e7 && $v >= 1) return number_format(round($v));   // a whole number reads better than 11.1K
    if ($v >= 1e9) return rtrim(rtrim(number_format($v / 1e9, 2), '0'), '.') . 'B';
    if ($v >= 1e6) return rtrim(rtrim(number_format($v / 1e6, 2), '0'), '.') . 'M';
    if ($v >= 1e3) return rtrim(rtrim(number_format($v / 1e3, 1), '0'), '.') . 'K';
    return rtrim(rtrim(number_format($v, 2), '0'), '.');
}
function swapc_px($p) { $p = (float)$p; if ($p <= 0) return ''; $d = max(2, min(10, (int)ceil(-log10($p)) + 3)); return '$' . rtrim(rtrim(number_format($p, $d, '.', ','), '0'), '.'); }
function swapc_lab($s) { return mb_substr(trim(preg_replace('/[^\p{L}\p{N} .,+_\-…$]/u', '', (string)$s)), 0, 40); }
function draw_swapc($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(30 - 16 * $k), (int)(20 - 12 * $k), (int)(66 - 36 * $k))); }
    for ($r = 560; $r > 0; $r -= 8) imagefilledellipse($im, 330, 300, $r * 2, (int)($r * 1.25), hexcol($im, '#ff5d73', (int)(127 - 4 * (1 - $r / 560))));
    for ($r = 420; $r > 0; $r -= 8) imagefilledellipse($im, 1080, 80, $r * 2, $r * 2, hexcol($im, '#ffb547', (int)(127 - 3 * (1 - $r / 420))));
    $D = 'brico-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $gold = hexcol($im, '#ffc95c'); $cream = hexcol($im, '#fff6e8'); $muted = hexcol($im, '#c9bfe6'); $coral = hexcol($im, '#ff8a7a'); $green = hexcol($im, '#3fe0a5');
    // gold coins drifting up
    mt_srand(crc32((string)($rec['sig'] ?? $rec['t'])));
    for ($i = 0; $i < 26; $i++) {
        $cx = mt_rand(40, 700); $cy = mt_rand(40, $H - 40); $z = mt_rand(10, 26); $sq = mt_rand(30, 100) / 100;
        $al = mt_rand(55, 98);
        imagefilledellipse($im, $cx, $cy, max(3, (int)($z * $sq)), $z, hexcol($im, '#e8a531', $al));
        imagefilledellipse($im, $cx, $cy, max(2, (int)($z * $sq * .62)), (int)($z * .62), hexcol($im, '#ffd978', $al));
        imagefilledellipse($im, (int)($cx - $z * $sq * .12), (int)($cy - $z * .18), max(1, (int)($z * $sq * .2)), max(1, (int)($z * .18)), hexcol($im, '#fff6d8', $al));
    }
    mt_srand();
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, '#ff5d73', 80)); imagesetthickness($im, 1);
    $x = 60;
    paste_png($im, __DIR__ . '/share/seal-swap.png', $x - 6, 46, 112, 112);
    imagefilledellipse($im, $x + 130, 84, 12, 12, $green);
    text_spaced($im, 13, $x + 146, 90, hexcol($im, '#7ff0c4'), $B, 'NEW $SHY BUY', 3);
    text_spaced($im, 12, $x + 130, 124, $muted, $B, 'ON SHY SWAP  ·  CONFIRMED ON SOLANA', 2);
    // the amount
    $amt = '+' . swapc_num($rec['shy']);
    $az = fit_size(118, 60, $D, $amt, 640);
    text($im, $az, $x - 2, 200 + $az, hexcol($im, '#5c2a10'), $D, $amt);
    text($im, $az, $x - 5, 196 + $az, $gold, $D, $amt);
    $ty = 196 + $az + 62;
    text($im, 40, $x, $ty, $cream, $D, '$SHY');
    if ((float)$rec['usd'] > 0) { $u = 'about $' . number_format((float)$rec['usd'], (float)$rec['usd'] >= 100 ? 0 : 2); text($im, 26, $x + text_w(40, $D, '$SHY') + 22, $ty - 4, $coral, $B, $u); }
    if ((string)$rec['paid'] !== '') { $pd = 'Paid ' . swapc_lab($rec['paid']); text($im, 22, $x, $ty + 50, $muted, $R, burnc_fit(22, $R, $pd, 640)); }
    // the side panel
    $px = 770; $pw = 370; $py = 70; $ph = 420;
    imagefilledrectangle($im, $px, $py, $px + $pw, $py + $ph, hexcol($im, '#0c0820', 40));
    imagerectangle($im, $px, $py, $px + $pw, $py + $ph, hexcol($im, '#ffffff', 108));
    $rows = [['BOUGHT BY', swapc_lab($rec['who']) ?: 'a new holder']];
    if (!empty($rec['price'])) $rows[] = ['$SHY PRICE', swapc_px($rec['price'])];
    if (!empty($rec['mcap'])) $rows[] = ['MARKET CAP', '$' . swapc_num($rec['mcap'])];
    if (!empty($rec['n'])) $rows[] = ['BUYS ON SHY SWAP THIS WEEK', number_format((int)$rec['n'])];
    $ry = $py + 52;
    foreach ($rows as $i => [$lab, $val]) {
        text_spaced($im, 11, $px + 28, $ry, $muted, $B, $lab, 2);
        $vz = fit_size(30, 16, $D, $val, $pw - 56);
        text($im, $vz, $px + 28, $ry + 14 + $vz, $i === 0 ? $cream : $gold, $D, $val);
        $ry += 96;
        if ($i < count($rows) - 1) imageline($im, $px + 28, $ry - 34, $px + $pw - 28, $ry - 34, hexcol($im, '#ffffff', 112));
    }
    hype_stamp($im, $x, 520, 'BUY $SHY', 'shyonsol.io/swap', '#d6304a');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 60 - spaced_w(12, $B, $site, 2), 590, $muted, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

// a trophy: a lit display case in black lacquer. The trophy's own art sits under a spotlight with gold rays behind it, the
// 賞 (prize) seal on the glass, and a plaque with the winner's name. Each trophy keeps its own colour.
function draw_trophy($rec, $out) {
    $W = 1200; $H = 630;
    $acc = ['champ' => '#f3c969', 'cup' => '#ff6b7f', 'club15' => '#3fe0a5', 'master' => '#b49bff', 'rkjade' => '#46d6a6', 'rkshogun' => '#ff8a4c', 'diamond' => '#7cc8ff', 'ancient' => '#e8c27a'][$rec['k']] ?? '#f3c969';
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(22 - 12 * $k), (int)(15 - 9 * $k), (int)(12 - 7 * $k))); }
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $gold = hexcol($im, $acc); $cream = hexcol($im, '#fbf1dc'); $muted = hexcol($im, '#cbbfa8');
    $cx = 300; $cy = 290;
    // the spotlight cone from above and the rays
    imagefilledpolygon($im, [$cx - 40, 0, $cx + 40, 0, $cx + 260, $H, $cx - 260, $H], hexcol($im, '#fff3d6', 118));
    for ($r = 340; $r > 0; $r -= 7) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, $acc, (int)(127 - 8 * (1 - $r / 340))));
    foreach ([[0, 230, 110], [230, 330, 118]] as [$r0, $r1, $al]) {
        $ray = hexcol($im, $acc, $al);
        for ($i = 0; $i < 28; $i++) { $a = $i * M_PI / 14; $b2 = $a + M_PI / 56;
            imagefilledpolygon($im, [(int)($cx + cos($a) * $r0), (int)($cy + sin($a) * $r0), (int)($cx + cos($a) * $r1), (int)($cy + sin($a) * $r1), (int)($cx + cos($b2) * $r1), (int)($cy + sin($b2) * $r1), (int)($cx + cos($b2) * $r0), (int)($cy + sin($b2) * $r0)], $ray); }
    }
    // the case: the trophy art behind glass, a plinth under it
    $ts = 320; $tx0 = $cx - $ts / 2; $ty0 = $cy - $ts / 2 - 10;
    imagefilledrectangle($im, $tx0 - 12 + 8, $ty0 - 12 + 12, $tx0 + $ts + 11 + 8, $ty0 + $ts + 11 + 12, hexcol($im, '#000000', 50));
    imagefilledrectangle($im, $tx0 - 12, $ty0 - 12, $tx0 + $ts + 11, $ty0 + $ts + 11, hexcol($im, '#0b0806'));
    imagefilledrectangle($im, $tx0 - 7, $ty0 - 7, $tx0 + $ts + 6, $ty0 + $ts + 6, $gold);
    $art = @imagecreatefrompng(dirname(__DIR__) . '/assets/art/trophy/' . (preg_match('/^[a-z0-9]+$/', $rec['k']) ? $rec['k'] : 'champ') . '.png');
    if ($art) { if (!imageistruecolor($art)) imagepalettetotruecolor($art); imagecopyresampled($im, $art, (int)$tx0, (int)$ty0, 0, 0, $ts, $ts, imagesx($art), imagesy($art)); }
    imagefilledpolygon($im, [(int)$tx0, (int)$ty0, (int)($tx0 + 120), (int)$ty0, (int)$tx0, (int)($ty0 + 120)], hexcol($im, '#ffffff', 112));   // a glint on the glass
    $py = (int)($ty0 + $ts + 26);
    imagefilledrectangle($im, (int)($cx - 190), $py, (int)($cx + 190), $py + 18, hexcol($im, '#2a1d14'));
    imagefilledrectangle($im, (int)($cx - 170), $py + 18, (int)($cx + 170), $py + 52, hexcol($im, '#1a120c'));
    imagerectangle($im, (int)($cx - 170), $py + 18, (int)($cx + 170), $py + 52, hexcol($im, $acc, 70));
    $nm = clean_label($rec['n']); $nz = fit_size(18, 12, $B, strtoupper($nm), 300);
    text_spaced($im, $nz, (int)($cx - spaced_w($nz, $B, strtoupper($nm), 2) / 2), $py + 42, $gold, $B, strtoupper($nm), 2);
    paste_png($im, __DIR__ . '/share/seal-prize.png', $tx0 + $ts - 58, $ty0 - 46, 104, 104);
    imagesetthickness($im, 2); imagerectangle($im, 18, 18, $W - 19, $H - 19, hexcol($im, $acc, 82)); imagesetthickness($im, 1);

    // the words
    $x = 610;
    [$tname, $tdesc] = TROPHY_KINDS[$rec['k']] ?? ['Trophy', ''];
    text_spaced($im, 13, $x, 84, $gold, $B, 'TROPHY UNLOCKED  ·  ON SOLANA', 3);
    text($im, 40, $x - 2, 146, $cream, $M, clean_label($nm) === '' ? 'A champion' : 'Won by');
    $nz3 = fit_size(52, 30, $D, $nm, 540);
    text($im, $nz3, $x - 2, 146 + 16 + $nz3, $cream, $D, $nm);
    $ly = 146 + 16 + $nz3 + 62;
    $tz = fit_size(46, 28, $M, $tname, 540);
    text($im, $tz, $x - 2, $ly, $gold, $M, $tname);
    $ly += 40;
    if ($rec['what'] !== '') { text($im, 22, $x, $ly, $cream, $B, 'for ' . clean_label($rec['what'])); $ly += 34; }
    if ($tdesc !== '') { foreach (hype_lines(19, $R, $tdesc . '.', 540) as $ln) { text($im, 19, $x, $ly, $muted, $R, $ln); $ly += 28; } }
    $chain = !empty($rec['w']) ? 'Minted to their wallet as an NFT.' : 'Mints to their wallet when they connect one.';
    text($im, 17, $x, $ly + 8, hexcol($im, $acc, 30), $B, $chain);
    hype_stamp($im, $x, 512, 'EARN YOURS', 'play free at shyonsol.io', '#b8322a');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 60 - spaced_w(12, $B, $site, 2), 600, $muted, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

// a match the server saw end (live, solo or Daily): the table on washi. The winner's mask (two for a shared world) with the
// 勝 (victory) or 和 (draw) seal, and every seat's Regions as a woodblock bar, humans in ink, bots in grey.
function draw_match($rec, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatefromjpeg(__DIR__ . '/share/wb-default.jpg'); if (!imageistruecolor($im)) imagepalettetotruecolor($im);
    $half = imagecreatetruecolor(600, $H); imagecopy($half, $im, 0, 0, 0, 0, 600, $H); imageflip($half, IMG_FLIP_HORIZONTAL);
    imagecopy($im, $half, 600, 0, 0, 0, 600, $H); imagedestroy($half);
    imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    $ink = hexcol($im, '#1c1510'); $muted = hexcol($im, '#6b5a48'); $red = hexcol($im, '#c42a1f');
    $rows = array_slice((array)($rec['rows'] ?? []), 0, 6); $win = array_values((array)($rec['win'] ?? [])); $tie = !empty($rec['tie']);
    $mode = (string)($rec['mode'] ?? 'live');
    // the sun behind the winner
    $cx = 260; $cy = 280;
    for ($r = 250; $r > 170; $r -= 4) imagefilledellipse($im, $cx, $cy, $r * 2, $r * 2, hexcol($im, $tie ? '#2b4f86' : '#e0453a', (int)(127 - 4 * (1 - ($r - 170) / 80))));
    imagefilledellipse($im, $cx, $cy, 340, 340, hexcol($im, $tie ? '#2b4f86' : '#d8382a', 10));
    // the winner's mask (or two, side by side and overlapping, for a shared world)
    $mk = function ($name, $human) { $k = !$human ? (BOT_MASKS[$name] ?? null) : null; return $k ?? ['ronin', 'monk', 'tiger', 'crane', 'kitsune', 'oni', 'unbound'][crc32((string)$name) % 7]; };
    $faces = [];
    foreach ($rows as $r) if (in_array($r['n'], $win, true)) $faces[] = $r;
    if (!$faces && $rows) $faces = [$rows[0]];
    $faces = array_slice($faces, 0, 2);
    $ms = count($faces) > 1 ? 190 : 240;
    foreach ($faces as $i => $f) {
        $fx = (int)($cx - $ms / 2 + (count($faces) > 1 ? ($i ? 70 : -70) : 0)); $fy = (int)($cy - $ms / 2 + (count($faces) > 1 ? ($i ? 26 : -26) : 0) - 8);
        $mi = mask_card_img($mk($f['n'], !empty($f['h'])));
        imagefilledrectangle($im, $fx + 8, $fy + 12, $fx + $ms + 16, $fy + $ms + 20, hexcol($im, '#000000', 90));
        imagefilledrectangle($im, $fx - 8, $fy - 8, $fx + $ms + 7, $fy + $ms + 7, $ink);
        imagefilledrectangle($im, $fx - 3, $fy - 3, $fx + $ms + 2, $fy + $ms + 2, hexcol($im, '#f8efdb'));
        if ($mi) rounded_copy($im, $mi, $fx, $fy, $ms, 4);
    }
    paste_png($im, __DIR__ . '/share/' . ($tie ? 'seal-tie.png' : 'seal-win.png'), $cx + ($ms / 2) + (count($faces) > 1 ? 40 : 0) - 70, $cy - $ms / 2 - 60, 110, 110);
    // the winner's name tab
    $label = $win ? implode(' & ', array_map('clean_label', array_slice($win, 0, 2))) : clean_label((string)($rows[0]['n'] ?? ''));
    $nz = fit_size(22, 14, $D, $label, 380); $tw = text_w($nz, $D, $label) + 40; $tx = (int)($cx - $tw / 2); $ty = $cy + 168;
    imagefilledrectangle($im, $tx + 4, $ty + 5, $tx + $tw + 4, $ty + 47, hexcol($im, '#000000', 90));
    imagefilledrectangle($im, $tx, $ty, $tx + $tw, $ty + 42, $ink);
    imagefilledrectangle($im, $tx, $ty, $tx + 5, $ty + 42, $tie ? hexcol($im, '#2b4f86') : $red);
    text($im, $nz, $tx + 22, $ty + 30, hexcol($im, '#fbf1dc'), $D, $label);

    // the words
    $x = 560;
    $eye = $mode === 'daily' ? 'DAILY CHALLENGE' . (!empty($rec['no']) ? ' #' . (int)$rec['no'] : '') : ($mode === 'solo' ? 'SOLO GAME' : 'LIVE MATCH');
    text_spaced($im, 13, $x, 84, $red, $B, $eye . '  ·  SHILLUMINATI ONLINE', 3);
    $humanWin = false; foreach ($faces as $f) if (!empty($f['h']) && in_array($f['n'], $win, true)) $humanWin = true;
    [$l1, $l2] = $tie ? ['A shared', 'world.'] : ($win ? ($humanWin ? ['The world', 'is theirs.'] : ['The bots', 'took it.']) : ['The world', 'fought back.']);
    text($im, 48, $x - 2, 152, $ink, $M, $l1);
    text($im, 58, $x - 4, 222, $tie ? hexcol($im, '#2b4f86') : $red, $M, $l2);
    $note = (string)($rec['note'] ?? '');
    if ($note !== '') text($im, fit_size(18, 14, $R, $note, 580), $x, 258, $muted, $R, $note);
    // the table as woodblock bars, scaled to the 15 Regions a world has
    $top = $note !== '' ? 286 : 268; $bw = 300; $rh = count($rows) > 4 ? 34 : 40;
    foreach ($rows as $i => $r) {
        $y = $top + $i * $rh; $isW = in_array($r['n'], $win, true); $h = !empty($r['h']);
        $nm = ($i + 1) . '. ' . clean_label($r['n']);
        text($im, fit_size(18, 13, $h ? $B : $R, $nm, 210), $x, $y + 22, $h ? $ink : $muted, $h ? $B : $R, $nm);
        if (!$h) text_spaced($im, 9, $x + min(210, text_w(fit_size(18, 13, $R, $nm, 210), $R, $nm)) + 10, $y + 21, $muted, $B, 'BOT', 1.5);
        $bx = $x + 250; $len = max(6, (int)round($bw * min(15, (int)$r['r']) / 15));
        imagefilledrectangle($im, $bx, $y + 6, $bx + $bw, $y + 26, hexcol($im, '#1c1510', 112));
        imagefilledrectangle($im, $bx, $y + 6, $bx + $len, $y + 26, $isW ? ($tie ? hexcol($im, '#2b4f86') : $red) : ($h ? $ink : hexcol($im, '#8a7a68')));
        $rs = (string)(int)$r['r'];
        text($im, 17, $bx + $bw + 12, $y + 24, $ink, $D, $rs);
    }
    $sy = 494;
    hype_stamp($im, $x, $sy, $mode === 'live' ? 'JOIN A LIVE MATCH' : ($mode === 'daily' ? 'TAKE YOUR SHOT' : 'PLAY FREE'), 'shyonsol.io, free in your browser', $tie ? '#2b4f86' : '#e0453a');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 64 - spaced_w(12, $B, $site, 2), 600, $ink, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}

//MC 2026-10-15 a release card: night lacquer in a gold frame, the 報 (news) seal, the date and version, the release
//   title big in Mincho, its one-line summary, and up to three of its changes with New / Better / Fixed tabs.
function draw_release($r, $out) {
    $W = 1200; $H = 630;
    $im = imagecreatetruecolor($W, $H); imagealphablending($im, true);
    $D = 'brico-800.ttf'; $M = 'mincho-800.ttf'; $B = 'inter-700.ttf'; $R = 'inter-500.ttf';
    // night lacquer, lighter toward the top right where the seal sits
    for ($y = 0; $y < $H; $y++) { $k = $y / $H; imageline($im, 0, $y, $W, $y, imagecolorallocate($im, (int)(30 - 12 * $k), (int)(20 - 8 * $k), (int)(54 - 20 * $k))); }
    for ($rr = 520; $rr > 0; $rr -= 8) imagefilledellipse($im, 980, 120, $rr * 2, $rr * 2, hexcol($im, '#8b5cf6', (int)(127 - 7 * (1 - $rr / 520))));
    for ($rr = 360; $rr > 0; $rr -= 8) imagefilledellipse($im, 120, 640, $rr * 2, $rr * 2, hexcol($im, '#e0453a', (int)(127 - 6 * (1 - $rr / 360))));
    // fine gold rays from the seal, and a scatter of embers
    $ray = hexcol($im, '#f2c35b', 118);
    for ($i = 0; $i < 22; $i++) { $a = M_PI * 0.5 + $i * M_PI / 21; imageline($im, 1030, 110, (int)(1030 + cos($a) * 1100), (int)(110 + sin($a) * 1100), $ray); }
    mt_srand(crc32($r['v']));
    for ($i = 0; $i < 70; $i++) { $ex = mt_rand(0, $W); $ey = mt_rand(0, $H); $es = mt_rand(1, 3); imagefilledellipse($im, $ex, $ey, $es, $es, hexcol($im, mt_rand(0, 2) ? '#f2c35b' : '#ff9f43', mt_rand(40, 100))); }
    mt_srand();
    // the gold frame, double ruled
    imagesetthickness($im, 3); imagerectangle($im, 22, 22, $W - 23, $H - 23, hexcol($im, '#f2c35b', 30));
    imagesetthickness($im, 1); imagerectangle($im, 32, 32, $W - 33, $H - 33, hexcol($im, '#f2c35b', 85));
    foreach ([[22, 22], [$W - 23, 22], [22, $H - 23], [$W - 23, $H - 23]] as [$cx, $cy]) imagefilledrectangle($im, $cx - 5, $cy - 5, $cx + 5, $cy + 5, hexcol($im, '#f2c35b'));
    paste_png($im, __DIR__ . '/share/seal-rel.png', $W - 228, 58, 160, 160);

    $gold = hexcol($im, '#f2c35b'); $white = hexcol($im, '#ffffff'); $muted = hexcol($im, '#cfc8ef');
    $x = 72;
    $ts = strtotime((string)$r['date']); $date = $ts ? strtoupper(date('M j, Y', $ts)) : strtoupper((string)$r['date']);
    text_spaced($im, 13, $x, 92, $gold, $B, 'UPDATE  ·  ' . $date . '  ·  SHILLUMINATI ONLINE', 3);
    // the title: Mincho, as big as fits in two lines beside the seal
    $title = (string)$r['title']; $tw = 840;
    // every line, nothing cut (hype_lines stops at two and cuts the rest), then smaller until it fits in two
    $wrap = function ($z, $f, $str, $mw) { $ls = []; $cur = ''; foreach (explode(' ', $str) as $wd) { $t = ltrim($cur . ' ' . $wd); if ($cur !== '' && text_w($z, $f, $t) > $mw) { $ls[] = $cur; $cur = $wd; } else $cur = $t; } if ($cur !== '') $ls[] = $cur; return $ls; };
    $tz = 60; $lines = $wrap($tz, $M, $title, $tw);
    while (count($lines) > 2 && $tz > 32) { $tz -= 4; $lines = $wrap($tz, $M, $title, $tw); }
    $ty = 104 + $tz + 8;
    foreach (array_slice($lines, 0, 2) as $ln) { text($im, $tz, $x - 2, $ty, $white, $M, $ln); $ty += (int)($tz * 1.22); }
    // the summary
    $sy = $ty + 10;
    $sum = $wrap(21, $R, (string)$r['summary'], 760);
    foreach (array_slice($sum, 0, 2) as $i => $ln) { if ($i === 1 && count($sum) > 2) $ln = rtrim($ln, ' .,') . '...'; text($im, 21, $x, $sy, $muted, $R, $ln); $sy += 31; }
    // a fan of three real cards from the deck on the right, picked by the version so each release keeps its own
    $arts = glob(dirname(__DIR__) . '/assets/cards/*.webp') ?: [];
    if (count($arts) >= 3) {
        sort($arts); $seed = crc32($r['v']);
        $pick = [$arts[$seed % count($arts)], $arts[($seed >> 7) % count($arts)], $arts[($seed >> 15) % count($arts)]];
        foreach ([[-10, 905, 300], [6, 1010, 290], [-2, 958, 270]] as $k => [$ang, $cx, $cy]) {
            $src = @imagecreatefromwebp($pick[$k]); if (!$src) continue;
            $cw = 150; $ch = 200; $card = imagecreatetruecolor($cw + 12, $ch + 12);
            imagefilledrectangle($card, 0, 0, $cw + 11, $ch + 11, imagecolorallocate($card, 242, 195, 91));
            imagefilledrectangle($card, 3, 3, $cw + 8, $ch + 8, imagecolorallocate($card, 20, 12, 30));
            $sw = imagesx($src); $sh = imagesy($src); $crop = min($sw, (int)($sh * $cw / $ch));
            imagecopyresampled($card, $src, 6, 6, (int)(($sw - $crop) / 2), 0, $cw, $ch, $crop, min($sh, (int)($crop * $ch / $cw)));
            imagedestroy($src);
            $rot = imagerotate($card, $ang, imagecolorallocatealpha($card, 0, 0, 0, 127)); imagesavealpha($rot, true); imagedestroy($card);
            $px = (int)($cx - imagesx($rot) / 2); $py = (int)$cy;
            imagecopy($im, $rot, $px, $py, 0, 0, imagesx($rot), imagesy($rot)); imagedestroy($rot);
        }
    }
    // up to three changes, one line each, with their tab
    $tabs = ['new' => ['NEW', '#2ef0b0', '#04110c'], 'better' => ['BETTER', '#4cc9f0', '#04111c'], 'fixed' => ['FIXED', '#ff5d73', '#1c0408']];
    $iy = max($sy + 22, 382);
    $items = (array)($r['items'] ?? []);
    $room = (int)floor((520 - $iy) / 44) + 1; $show = max(1, min(3, $room));
    foreach (array_slice($items, 0, $show) as $it) {
        [$t, $txt] = [(string)$it[0], (string)$it[1]];
        $tb = $tabs[$t] ?? ['NOTE', '#f2c35b', '#1c1408'];
        $first = preg_split('/(?<=[.!?])\s+/', trim($txt))[0];
        $first = rtrim($first, '.');
        $chw = 96;   // one width for every tab, so the changes line up in a column
        imagefilledrectangle($im, $x, $iy - 22, $x + $chw, $iy + 6, hexcol($im, $tb[1]));
        text_spaced($im, 12, $x + (int)(($chw - spaced_w(12, $B, $tb[0], 2)) / 2), $iy - 2, hexcol($im, $tb[2]), $B, $tb[0], 2);
        $line = $first; $maxw = 690;
        if (text_w(20, $B, $line) > $maxw) {   // cut at a whole word
            $words = explode(' ', $line); $line = '';
            foreach ($words as $wd) { $try = ltrim($line . ' ' . $wd); if (text_w(20, $B, $try . '...') > $maxw) break; $line = $try; }
            $line = rtrim($line, ' ,:;') . '...';
        }
        text($im, 20, $x + $chw + 16, $iy, $white, $B, $line);
        $iy += 44;
    }
    if (count($items) > $show) text($im, 16, $x, $iy - 6, $muted, $R, '+ ' . (count($items) - $show) . ' more in the release notes');
    // the foot: where to read it, and the name
    imageline($im, $x, 548, $W - 72, 548, hexcol($im, '#f2c35b', 95));
    text($im, 20, $x, 588, $gold, $D, 'shyonsol.io/updates');
    $site = 'SHILLUMINATI ONLINE  ·  $SHY';
    text_spaced($im, 12, $W - 72 - spaced_w(12, $B, $site, 2), 584, $muted, $B, $site, 2);
    imagejpeg($im, $out, 90); imagedestroy($im);
}
