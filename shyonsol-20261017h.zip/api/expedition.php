<?php
// Shadow Expeditions: send your Shadow (or your Unbound mask) on a timed mission to a Region of the world, come back when
// it returns, and claim what it brought home: Koban and Season Scroll XP, sometimes treasure. The idea is the timed
// expeditions successful Solana games run (RollerCoin's Hamster expeditions and the like): a reason to come back a few
// times a day. Holders can run one expedition per Shadow they hold, up to three at once, and each Shadow's Aura adds to
// the haul. Three Regions are open each day (the same for everyone), one of them a hot zone that pays more.
// POST {a: state | send | claim, pid, key, ...}
//   send: {len: scout | raid | campaign, region: one of today's, shadow: number or '' for Unbound}
//   claim: {id}
//MC 2026-10-16 first version
if (!defined('SHY_API')) define('SHY_API', 1);
require_once __DIR__ . '/common.php';
require_once __DIR__ . '/holders.php';
require_once __DIR__ . '/economy.php';
if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';   // the Region names

define('EXPEDITIONS', DATA_DIR . '/expeditions.php');   // pid => [act => [...], d => day, n => sent today, k => Koban today, log => [...]]
const EXP_LENS = [
    'scout'    => ['name' => 'Scout',    'h' => 1, 'koban' => 30,  'xp' => 10],
    'raid'     => ['name' => 'Raid',     'h' => 4, 'koban' => 100, 'xp' => 30],
    'campaign' => ['name' => 'Campaign', 'h' => 8, 'koban' => 180, 'xp' => 50],
];
const EXP_AURA = ['none' => 15, 'cyan' => 25, 'crimson' => 25, 'lightning' => 30, 'money' => 40, 'btc' => 40];   // % more Koban
const EXP_HOT = 25;          // % more Koban in today's hot zone
const EXP_DAY_SENDS = 4;     // expeditions a player can send a day
const EXP_DAY_KOBAN = 900;   // most Koban expeditions pay one player a day (treasure included)

//MC 2026-10-16 a treasure or relic find goes to the $SHY Telegram chat on its own card (share.php ?ne=, the explorer's
//   map). Relics are rare and always post; treasure is about 1 claim in 8, so at most EXP_TG_HOUR of those an hour.
//   Called holding the site lock. The switch is "Expedition finds" in Admin > Telegram.
define('EXP_TG', DATA_DIR . '/exp-tg.php');   // [ts of treasure posts in the last hour]
const EXP_TG_HOUR = 6;
function exp_tg_find($pid, $x, $find, $paid) {
    if ($find === '' || $paid <= 0 || !function_exists('tg_post')) return;
    $c = tg_cfg(); if (!tg_ready($c) || !tg_on($c, 'exp')) return;
    $name = (string)(load(PLAYERS)[$pid]['name'] ?? ''); if ($name === '') return;
    if ($find === 'treasure') {
        $t = array_values(array_filter((array)load(EXP_TG), fn($v) => $v > time() - 3600));
        if (count($t) >= EXP_TG_HOUR) return;
        $t[] = time(); save(EXP_TG, $t);
    }
    $sh = (string)$x['shadow'];
    $rec = ['n' => $name, 'sh' => $sh, 'region' => (string)$x['region'], 'len' => (string)$x['name'], 'find' => $find, 'koban' => (int)$paid];
    $img = function_exists('tg_card_rec') ? tg_card_rec('expfd', $rec, 'ne') : '';
    $what = $sh !== '' ? 'Shadow #' . tg_h($sh) : 'Unbound mask';
    $html = ($find === 'relic' ? '🏺 <b>A relic, found in ' . tg_h($x['region']) . '!</b>' : '💰 <b>Treasure, found in ' . tg_h($x['region']) . '!</b>')
        . "\n" . tg_link(tg_pslug($name), $name) . '\'s ' . $what . ' came home from a ' . tg_h($x['name']) . ' with <b>+' . number_format($paid) . ' Koban</b>' . ($find === 'relic' ? ', a relic among it.' : ', double the haul.')
        . "\nSend your Shadow out: " . tg_link('/play#g-exp', 'Shadow Expeditions');
    tg_post('exp', $html, 'exp:' . $pid . ':' . $x['id'], null, $img);
}
function exp_cfg() {
    $s = eco_settings();
    return ['on' => empty($s['exp_off']), 'mult' => max(0, min(5, (float)($s['exp_mult'] ?? 1))), 'sends' => (int)($s['exp_sends'] ?? EXP_DAY_SENDS), 'cap' => (int)($s['exp_cap'] ?? EXP_DAY_KOBAN)];
}
// three Regions open today, the same for everyone; the first is the hot zone
function exp_today($day = null) {
    $day = $day ?? gmdate('Y-m-d');
    $r = REGIONS; $out = [];
    $seed = crc32('exp|' . $day);
    for ($i = 0; count($out) < 3 && $i < 40; $i++) { $k = ($seed + $i * 7919) % count($r); if (!in_array($r[$k], $out, true)) $out[] = $r[$k]; $seed = crc32($seed . '|' . $i); }
    return array_map(fn($name, $i) => ['r' => $name, 'hot' => $i === 0], $out, array_keys($out));
}
function exp_rec(&$db, $pid) {
    $r = $db[$pid] ?? [];
    $r += ['act' => [], 'd' => '', 'n' => 0, 'k' => 0, 'log' => []];
    if ($r['d'] !== gmdate('Y-m-d')) { $r['d'] = gmdate('Y-m-d'); $r['n'] = 0; $r['k'] = 0; }
    return $r;
}
function exp_view($r, $pid) {
    $cfg = exp_cfg(); $h = load(HOLDERS)[$pid] ?? null; $mine = array_map('strval', (array)($h['shadows'] ?? []));
    $busy = array_map(fn($a) => (string)$a['shadow'], $r['act']);
    $slots = $mine ? min(3, count($mine)) : 1;
    $sh = [];
    foreach (array_slice($mine, 0, 30) as $n) $sh[] = ['n' => $n, 'img' => shadow_img($n), 'aura' => shadow_aura($n), 'bonus' => EXP_AURA[shadow_aura($n)] ?? EXP_AURA['none'], 'busy' => in_array($n, $busy, true)];
    $lens = [];
    foreach (EXP_LENS as $k => $l) $lens[] = ['id' => $k, 'name' => $l['name'], 'h' => $l['h'], 'koban' => (int)round($l['koban'] * $cfg['mult']), 'xp' => $l['xp']];
    return ['ok' => true, 'on' => $cfg['on'], 'now' => time(), 'sent' => (int)$r['n'], 'sends' => $cfg['sends'], 'kobanToday' => (int)$r['k'], 'cap' => $cfg['cap'],
        'slots' => $slots, 'holder' => (bool)$mine, 'dest' => exp_today(), 'hot' => EXP_HOT, 'lens' => $lens, 'shadows' => $sh,
        'active' => array_values(array_map(fn($a) => $a + ['img' => $a['shadow'] !== '' ? shadow_img($a['shadow']) : '', 'done' => time() >= $a['end']], $r['act'])),
        'log' => array_slice($r['log'], 0, 6)];
}

if (defined('EXP_LIB')) return;   //MC 2026-10-16 Admin > Expeditions loads this for the settings and numbers above
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$a = (string)($b['a'] ?? 'state');
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('Play a game first, then send your Shadow out.');
if (function_exists('player_banned') && player_banned($pid)) fail('This profile can\'t send expeditions.', 403);
if (!in_array($a, ['state', 'send', 'claim'], true)) fail('unknown action');
if ($a !== 'state') {
    $ok = with_lock(function () { $l = load(LIMITS); $ok = rate_ok($l, 'expedition:' . client_ip(), 60, 600); save(LIMITS, $l); return $ok; });
    if (!$ok) fail('Slow down a little and try again.', 429);
}

$res = with_lock(function () use ($a, $b, $pid, $key) {
    if (!key_ok($pid, hash('sha256', $key))) return ['err' => 'not your profile', 'code' => 403];
    $cfg = exp_cfg();
    $db = load(EXPEDITIONS); $r = exp_rec($db, $pid); $now = time();
    if ($a === 'send') {
        if (!$cfg['on']) return ['err' => 'Expeditions are resting right now. Check back soon.', 'code' => 409];
        $len = (string)($b['len'] ?? ''); $region = (string)($b['region'] ?? ''); $shadow = (string)($b['shadow'] ?? '');
        if (!isset(EXP_LENS[$len])) return ['err' => 'Pick how long the expedition goes for.', 'code' => 400];
        $dest = null; foreach (exp_today() as $d) if ($d['r'] === $region) $dest = $d;
        if (!$dest) return ['err' => 'That Region isn\'t open today. Pick one of today\'s three.', 'code' => 400];
        if ($r['n'] >= $cfg['sends']) return ['err' => 'That\'s ' . $cfg['sends'] . ' expeditions today. New ones open at midnight UTC.', 'code' => 429];
        $mine = array_map('strval', (array)(load(HOLDERS)[$pid]['shadows'] ?? []));
        $slots = $mine ? min(3, count($mine)) : 1;
        if (count($r['act']) >= $slots) return ['err' => $mine ? 'All your expedition slots are out. Claim one when it comes back.' : 'Your Shadow is already out. Holders can send one per Shadow, up to three.', 'code' => 409];
        if ($shadow !== '') {
            if (!in_array($shadow, $mine, true)) return ['err' => 'That Shadow isn\'t in your wallet.', 'code' => 403];
            foreach ($r['act'] as $x) if ((string)$x['shadow'] === $shadow) return ['err' => 'That Shadow is already out on an expedition.', 'code' => 409];
        } elseif ($mine) {
            // a holder sends a Shadow: the first one that isn't out
            foreach ($mine as $n) { $out = false; foreach ($r['act'] as $x) if ((string)$x['shadow'] === $n) $out = true; if (!$out) { $shadow = $n; break; } }
        }
        $aura = $shadow !== '' ? shadow_aura($shadow) : '';
        $bonus = ($shadow !== '' ? (EXP_AURA[$aura] ?? EXP_AURA['none']) : 0) + ($dest['hot'] ? EXP_HOT : 0);
        $L = EXP_LENS[$len];
        $id = bin2hex(random_bytes(5));
        $r['act'][] = ['id' => $id, 'len' => $len, 'name' => $L['name'], 'region' => $region, 'hot' => $dest['hot'], 'shadow' => $shadow, 'aura' => $aura, 'bonus' => $bonus,
            'start' => $now, 'end' => $now + $L['h'] * 3600, 'koban' => (int)round($L['koban'] * $cfg['mult'] * (100 + $bonus) / 100), 'xp' => $L['xp']];
        $r['n']++;
        $db[$pid] = $r; save(EXPEDITIONS, $db);
        if (function_exists('track')) track('expeditions');
        return exp_view($r, $pid) + ['sentId' => $id];
    }
    if ($a === 'claim') {
        $id = (string)($b['id'] ?? ''); $k = null;
        foreach ($r['act'] as $i => $x) if ($x['id'] === $id) $k = $i;
        if ($k === null) return ['err' => 'That expedition was already claimed.', 'code' => 409];
        $x = $r['act'][$k];
        if ($now < $x['end']) return ['err' => 'Not back yet.', 'code' => 409];
        // what it found: now and then treasure (double), rarely a relic (+300)
        $roll = random_int(1, 1000); $find = $roll <= 20 ? 'relic' : ($roll <= 140 ? 'treasure' : '');
        $kob = $x['koban'] * ($find === 'treasure' ? 2 : 1) + ($find === 'relic' ? 300 : 0);
        $room = max(0, $cfg['cap'] - (int)$r['k']); $paid = min($kob, $room);
        $eco = load(ECO); $acc = eco_get($eco, $pid);
        if ($paid > 0) eco_credit($acc, $paid, 'Expedition: ' . $x['region'] . ($find ? ' (' . $find . ')' : ''));
        $acc['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, (int)$acc['sc']['xp'] + (int)$x['xp']);
        $eco[$pid] = $acc; save(ECO, $eco);
        $r['k'] += $paid;
        array_splice($r['act'], $k, 1);
        array_unshift($r['log'], ['region' => $x['region'], 'name' => $x['name'], 'shadow' => $x['shadow'], 'koban' => $paid, 'xp' => (int)$x['xp'], 'find' => $find, 't' => $now]);
        $r['log'] = array_slice($r['log'], 0, 20);
        $db[$pid] = $r; save(EXPEDITIONS, $db);
        try { exp_tg_find($pid, $x, $find, $paid); } catch (Throwable $e) {}
        return exp_view($r, $pid) + ['claimed' => ['koban' => $paid, 'xp' => (int)$x['xp'], 'find' => $find, 'capped' => $paid < $kob, 'region' => $x['region'], 'balance' => (int)$acc['koban']]];
    }
    return exp_view($r, $pid);
});
if (isset($res['err'])) fail($res['err'], $res['code']);
out($res);
