<?php
// The live mint tracker on the NFTs page: how many of the 1,335 Shytoshi Shadows are minted, who's collecting, which
// Auras are out, and the newest mints with their art. Read straight from Solana (the DAS lookup the holder check uses),
// at most once a minute for everyone; while one visit refreshes it, every other visit gets the last answer.
// A Shadow's mint time is when this first saw it. The first look marks everything already out as "before tracking",
// and the newest few get their real mint time from their first transaction on Solana.
// GET ?a=stats
// GET ?a=one&n=145   one minted Shadow up close (art, Aura, rarity, holder shortened); not minted yet gives minted:false
//MC 2026-10-15 first version
if (!defined('SHY_API')) define('SHY_API', 1);
require_once __DIR__ . '/common.php';
require_once __DIR__ . '/holders.php';
require_once __DIR__ . '/economy.php';   //MC 2026-10-16 for the Telegram post when a Shadow is minted (economy.php loads tg.php)

const MINT_TOTAL = 1335;
const MINT_CACHE = DATA_DIR . '/cache-mints.php';
const MINT_SEEN = DATA_DIR . '/mints-seen.php';
const MINT_ALL = DATA_DIR . '/cache-mints-all.php';
const MINT_POSTED = DATA_DIR . '/mints-posted.php';   //MC 2026-10-16 ['p' => asset id => ts posted to Telegram]
const MINT_TG_MAX = 3;   // more new Shadows than this in one look go out as one post
const MINT_LINK = 'https://launchmynft.io/mint/shyshadows';
const MINT_META = DATA_DIR . '/mints-meta.php';   //MC 2026-10-15 art and traits read from a Shadow's own metadata file when the DAS lookup had none   //MC 2026-10-15 every minted Shadow by number, for ?a=one (the wall's close-up)   // asset id => ['n' => number, 't' => first seen ts (0 = before tracking), 'tx' => 1 once looked up]

function mt_rpc($method, $params, $timeout = 12) {
    $c = shy_config();
    $url = !empty($c['das_url']) ? $c['das_url'] : 'https://mainnet.helius-rpc.com/?api-key=' . rawurlencode($c['helius'] ?? '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(['jsonrpc' => '2.0', 'id' => 'mt', 'method' => $method, 'params' => $params]),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false || $code !== 200) return null;
    $j = json_decode($raw, true);
    return is_array($j) && array_key_exists('result', $j) ? $j['result'] : null;
}
function mt_short($w) { return strlen($w) > 10 ? substr($w, 0, 4) . '...' . substr($w, -4) : $w; }

// every Shadow minted so far, newest first
//MC 2026-10-15 a fresh mint can come back from the DAS lookup with no image and no traits until Helius has read its
//   metadata file (#145 showed as a blank Void Shade with "Aura"). Read that file ourselves: a few per refresh, kept
//   once found, tried again after 10 minutes if it wasn't there yet.
function mt_meta_fix(&$items, $raw) {
    $meta = load(MINT_META); $now = time(); $tries = 0; $changed = false;
    foreach ($items as $k => &$x) {
        if ($x['img'] !== '' && $x['aura'] !== '') continue;
        $m = $meta[$x['id']] ?? null;
        if ($m && !empty($m['img'])) { $x['img'] = $x['img'] ?: $m['img']; $x['aura'] = $x['aura'] ?: (string)($m['aura'] ?? ''); $x['rank'] = $x['rank'] ?: (string)($m['rank'] ?? ''); continue; }
        if ($m && $now - ($m['tried'] ?? 0) < 600) continue;
        if ($tries >= 6) continue;
        $tries++; $changed = true;
        $uri = (string)($raw[$x['id']] ?? '');
        $got = ['tried' => $now];
        if (preg_match('#^https://#', $uri)) {
            $ch = curl_init($uri);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4]);
            $j = json_decode((string)curl_exec($ch), true); curl_close($ch);
            if (is_array($j)) {
                $tr = nft_traits(['content' => ['metadata' => ['attributes' => $j['attributes'] ?? []]]]);
                $img = (string)($j['image'] ?? ($j['properties']['files'][0]['uri'] ?? ''));
                if (preg_match('#^https://#', $img)) $got = ['img' => $img, 'aura' => (string)($tr['aura'] ?? ''), 'rank' => (string)($tr['rarity rank'] ?? ($tr['rank'] ?? ''))];
            }
        }
        $meta[$x['id']] = $got;
        if (!empty($got['img'])) { $x['img'] = $x['img'] ?: $got['img']; $x['aura'] = $x['aura'] ?: $got['aura']; $x['rank'] = $x['rank'] ?: $got['rank']; }
    }
    unset($x);
    if ($changed) save(MINT_META, $meta);
}
function mt_fetch() {
    $items = []; $uris = [];
    for ($page = 1; $page <= 3; $page++) {
        $r = mt_rpc('getAssetsByGroup', ['groupKey' => 'collection', 'groupValue' => SHADOWS_COLLECTION, 'page' => $page, 'limit' => 1000, 'sortBy' => ['sortBy' => 'created', 'sortDirection' => 'desc']]);
        if (!is_array($r) || !isset($r['items'])) return null;
        foreach ($r['items'] as $it) {
            if (!empty($it['burnt'])) continue;
            if (!preg_match('/#\s*(\d{1,5})/', (string)($it['content']['metadata']['name'] ?? ''), $m)) continue;
            $img = $it['content']['links']['image'] ?? ($it['content']['files'][0]['uri'] ?? '');
            $tr = nft_traits($it);
            if (!empty($it['content']['json_uri'])) $uris[(string)($it['id'] ?? '')] = (string)$it['content']['json_uri'];
            $items[] = ['id' => (string)($it['id'] ?? ''), 'n' => (int)$m[1], 'img' => preg_match('#^https://#', $img) ? $img : '', 'owner' => (string)($it['ownership']['owner'] ?? ''),
                'aura' => (string)($tr['aura'] ?? ''), 'rank' => (string)($tr['rarity rank'] ?? ($tr['rank'] ?? ''))];
        }
        if (count($r['items']) < 1000) break;
    }
    mt_meta_fix($items, $uris);
    return $items;
}
// when a Shadow was minted: the time of the oldest transaction on its address
function mt_mint_time($id) {
    $r = mt_rpc('getSignaturesForAddress', [$id, ['limit' => 1000]], 8);
    if (!is_array($r) || !$r) return 0;
    $last = end($r);
    return (int)($last['blockTime'] ?? 0);
}
function mt_build($items) {
    $seen = load(MINT_SEEN); $first = !$seen; $now = time();
    foreach ($items as $x) if ($x['id'] !== '' && !isset($seen[$x['id']])) $seen[$x['id']] = ['n' => $x['n'], 't' => $first ? 0 : $now];
    // the newest few without a real time get one from Solana (a few per refresh, once each)
    $looked = 0;
    foreach (array_slice($items, 0, 12) as $x) {
        if ($looked >= 4) break;
        $s = &$seen[$x['id']];
        if (empty($s['tx'])) { $t = mt_mint_time($x['id']); $looked++; $s['tx'] = 1; if ($t > 0) $s['t'] = $t; }
        unset($s);
    }
    save(MINT_SEEN, $seen);
    try { mt_announce($items); } catch (Throwable $e) {}   //MC 2026-10-16 a Telegram hiccup never stops the tracker
    $owners = []; $auras = [];
    foreach ($items as $x) { if ($x['owner'] !== '') $owners[$x['owner']] = ($owners[$x['owner']] ?? 0) + 1; $a = $x['aura'] !== '' ? $x['aura'] : 'Unknown'; $auras[$a] = ($auras[$a] ?? 0) + 1; }
    arsort($owners); arsort($auras);
    // mints per day for the last 14 days (by first seen)
    $days = []; for ($i = 13; $i >= 0; $i--) $days[gmdate('Y-m-d', $now - $i * 86400)] = 0;
    $d24 = 0;
    foreach ($seen as $s) { if (empty($s['t'])) continue; $d = gmdate('Y-m-d', $s['t']); if (isset($days[$d])) $days[$d]++; if ($s['t'] > $now - 86400) $d24++; }
    $recent = array_map(fn($x) => ['n' => $x['n'], 'img' => $x['img'], 'aura' => $x['aura'], 'rank' => $x['rank'], 'asset' => $x['id'], 'owner' => mt_short($x['owner']), 't' => (int)($seen[$x['id']]['t'] ?? 0)], array_slice($items, 0, 16));
    //MC 2026-10-15 a collector who plays Shilluminati shows as their player (name, Shadow, link to their page) instead of
    //   the shortened wallet. Only players who verified that wallet themselves (holders.php), and the wallet is not sent.
    $byW = []; foreach ((array)load(HOLDERS) as $pid => $h) if (!empty($h['wallet'])) $byW[$h['wallet']] = $pid;
    $players = $byW ? load(PLAYERS) : [];
    $top = [];
    foreach (array_slice($owners, 0, 5, true) as $w => $n) {
        $pid = $byW[$w] ?? ''; $pl = $pid !== '' ? ($players[$pid] ?? null) : null;
        if ($pl && !empty($pl['name'])) $top[] = ['p' => (string)$pl['name'], 'url' => '/p/' . rawurlencode(str_replace(' ', '_', (string)$pl['name'])), 'img' => !empty($pl['avatar']) ? shadow_img($pl['avatar']) : '', 'n' => $n];
        else $top[] = ['w' => mt_short($w), 'n' => $n];
    }
    //MC 2026-10-15 the wall on the NFTs page: every minted number with its Aura (as an index into wa), newest first
    $wa = array_keys($auras); $wi = array_flip($wa); $wall = [];
    $all = [];
    foreach ($items as $x) {
        $wall[] = [$x['n'], $wi[$x['aura'] !== '' ? $x['aura'] : 'Unknown'] ?? 0];
        $all[$x['n']] = ['n' => $x['n'], 'img' => $x['img'], 'aura' => $x['aura'], 'rank' => $x['rank'], 'asset' => $x['id'], 'owner' => mt_short($x['owner']), 't' => (int)($seen[$x['id']]['t'] ?? 0)];
    }
    save(MINT_ALL, $all);
    $minted = min(MINT_TOTAL, count($items));
    $since = 0; foreach ($seen as $s) if (!empty($s['t']) && (!$since || $s['t'] < $since)) $since = $s['t'];
    return ['total' => MINT_TOTAL, 'minted' => $minted, 'left' => MINT_TOTAL - $minted, 'holders' => count($owners), 'last24' => $d24,
        'days' => array_map(fn($d, $n) => ['d' => $d, 'n' => $n], array_keys($days), $days), 'auras' => array_map(fn($a, $n) => ['a' => $a, 'n' => $n], array_keys($auras), $auras),
        'recent' => $recent, 'top' => $top, 'tracking' => $since, 'at' => $now, 'wa' => $wa, 'wall' => $wall];
}

//MC 2026-10-16 a new Shadow minted: a post in the $SHY Telegram chat with its art, Aura, rank and who collected it (a
//   player by name when they verified that wallet, otherwise the wallet shortened), and how many are left. Runs from
//   the tracker's refresh, so the NFTs page and the 5 minute cron job both catch it. The first run only remembers
//   what's already out, so turning it on never floods the chat with old mints. Several at once (a big mint) go out as
//   one post. The switch is "New Shadows minted" in Admin > Telegram.
function mt_art_jpeg($u) { return str_replace('format=auto', 'format=jpeg', (string)$u); }
// who collected it: [text for the post, plain name for the card]
function mt_who($owner, $byW, $players) {
    $pid = $byW[$owner] ?? ''; $pl = $pid !== '' ? ($players[$pid] ?? null) : null;
    if ($pl && !empty($pl['name'])) return [tg_link(tg_pslug($pl['name']), (string)$pl['name']), (string)$pl['name']];
    return $owner !== '' ? ['<code>' . tg_h(mt_short($owner)) . '</code>', mt_short($owner)] : ['a new collector', 'a new collector'];
}
//MC 2026-10-16 the post goes out on its own card (share.php ?nm=, the gold vault); the bare art if the card can't be made
function mt_card($x, $who, $minted) {
    $rec = ['n' => 'Shadow #' . $x['n'], 'sh' => (int)$x['n'], 'img' => mt_art_jpeg($x['img']), 'auraName' => trim((string)$x['aura']), 'rank' => trim((string)$x['rank']),
        'who' => $who, 'minted' => $minted, 'total' => MINT_TOTAL];
    $u = function_exists('tg_card_rec') ? tg_card_rec('mintc', $rec, 'nm') : '';
    return $u !== '' ? $u : mt_art_jpeg($x['img']);
}
function mt_announce($items) {
    if (!function_exists('tg_post')) return;
    $mk = function () use ($items) {
        $d = load(MINT_POSTED); $first = empty($d['p']); $new = [];
        foreach ($items as $x) {
            if ($x['id'] === '' || isset($d['p'][$x['id']])) continue;
            $d['p'][$x['id']] = time();
            if (!$first) $new[] = $x;
        }
        if ($new || $first) save(MINT_POSTED, $d + ['since' => time()]);
        return $new;
    };
    $new = (function_exists('lock_depth') && lock_depth() > 0) ? $mk() : with_lock($mk);
    if (!$new) return;
    $c = tg_cfg();
    if (!tg_ready($c) || !tg_on($c, 'mint')) return;
    $minted = min(MINT_TOTAL, count($items)); $left = MINT_TOTAL - $minted;
    $byW = []; foreach ((array)load(HOLDERS) as $pid => $h) if (!empty($h['wallet'])) $byW[$h['wallet']] = $pid;
    $players = $byW ? load(PLAYERS) : [];
    $count = '<b>' . number_format($minted) . '</b> of ' . number_format(MINT_TOTAL) . ' Shadows minted, <b>' . number_format($left) . '</b> left.';
    $foot = "\n" . '<a href="' . MINT_LINK . '">Mint a Shadow</a> · ' . tg_link('/nfts#mint-live', 'See the wall');
    usort($new, fn($a, $b) => $a['n'] <=> $b['n']);
    if (count($new) > MINT_TG_MAX) {
        $nums = implode(', ', array_map(fn($x) => '#' . $x['n'], array_slice($new, 0, 12))) . (count($new) > 12 ? ' and ' . (count($new) - 12) . ' more' : '');
        $html = '🌑 <b>' . count($new) . ' new Shadows just minted!</b>' . "\n" . tg_h($nums) . "\n" . $count . $foot;
        $top = $new[count($new) - 1];
        tg_post('mint', $html, 'mint:' . $new[0]['id'] . ':' . count($new), null, mt_card($top, mt_who($top['owner'], $byW, $players)[1], $minted));
        return;
    }
    foreach ($new as $x) {
        $aura = trim((string)$x['aura']); $rank = trim((string)$x['rank']);
        $html = tg_pick(['🌑 <b>Shadow #%n just minted!</b>', '👁 <b>A new Shadow steps out of the dark: #%n</b>', '🌘 <b>Shadow #%n has been summoned.</b>'], $x['id']);
        $html = str_replace('%n', (string)$x['n'], $html)
            . ($aura !== '' || $rank !== '' ? "\n" . ($aura !== '' ? 'Aura: <b>' . tg_h($aura) . '</b>' : '') . ($aura !== '' && $rank !== '' ? ' · ' : '') . ($rank !== '' ? 'Rarity rank <b>' . tg_h($rank) . '</b>' : '') : '')
            . "\nCollected by " . ($who = mt_who($x['owner'], $byW, $players))[0] . '.'
            . "\n" . $count . $foot;
        tg_post('mint', $html, 'mint:' . $x['id'], null, mt_card($x, $who[1], $minted));
    }
}

if (defined('MINTS_LIB')) return;   //MC 2026-10-16 cron.php loads this for the functions above
$a = $_GET['a'] ?? 'stats';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
if ($a === 'one') {
    $n = (int)($_GET['n'] ?? 0);
    if ($n < 1 || $n > MINT_TOTAL) fail('No Shadow with that number.');
    $all = is_file(MINT_ALL) ? load(MINT_ALL) : [];
    header('Cache-Control: public, max-age=30');
    out(isset($all[$n]) ? ['ok' => true, 'minted' => true] + $all[$n] : ['ok' => true, 'minted' => false, 'n' => $n]);
}
if ($a !== 'stats') fail('unknown action');
$c = is_file(MINT_CACHE) ? load(MINT_CACHE) : [];
$fresh = !empty($c['at']) && time() - $c['at'] < 60;
if (!$fresh) {
    // one refresh at a time; anyone else gets the last answer straight away
    $lf = @fopen(DATA_DIR . '/mints.lock', 'c');
    if ($lf && flock($lf, LOCK_EX | LOCK_NB)) {
        try {
            $c2 = is_file(MINT_CACHE) ? load(MINT_CACHE) : [];
            if (empty($c2['at']) || time() - $c2['at'] >= 60) {
                $items = mt_fetch();
                if ($items !== null) { $c = mt_build($items); save(MINT_CACHE, $c); }
                elseif ($c) { $c['at'] = time() - 30; save(MINT_CACHE, $c); }   // Solana didn't answer: keep the last numbers, try again in 30s
            } else $c = $c2;
        } finally { flock($lf, LOCK_UN); fclose($lf); }
    }
}
if (!$c) fail('The mint numbers are loading. Try again in a moment.', 503);
header('Cache-Control: public, max-age=20');
out(['ok' => true] + $c);
