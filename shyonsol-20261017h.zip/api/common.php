<?php
// Shared helpers for the leaderboard and live match scripts.
if (!defined('SHY_API')) { http_response_code(404); exit; }

// Scores live OUTSIDE public_html (next to it, in shy-data) so site updates and wipes never touch them.
// Falls back to api/data if the host won't allow that folder.
function shy_data_dir() {
    $docroot = $_SERVER['DOCUMENT_ROOT'] ?? '';
    $base = $docroot ? dirname(rtrim($docroot, '/')) : dirname(__DIR__, 2);
    $outside = $base . '/shy-data';
    if ((is_dir($outside) || @mkdir($outside, 0755, true)) && is_writable($outside)) {
        // one-time move of any scores saved before the switch
        $old = __DIR__ . '/data';
        if (!is_file($outside . '/players.php') && is_file($old . '/players.php')) {
            foreach (['players.php', 'daily.php'] as $f) if (is_file($old . '/' . $f)) @copy($old . '/' . $f, $outside . '/' . $f);
        }
        return $outside;
    }
    return __DIR__ . '/data';
}
define('DATA_DIR', shy_data_dir());
define('PLAYERS', DATA_DIR . '/players.php');
define('TOKENS', DATA_DIR . '/tokens.php');
define('LIMITS', DATA_DIR . '/limits.php');
const GUARD   = "<?php http_response_code(404); exit; ?>\n";

//MC 2026-10-11 PHP 8.1 has this built in; older hosts get the same thing
if (!function_exists('array_is_list')) { function array_is_list(array $a) { $i = 0; foreach ($a as $k => $_) if ($k !== $i++) return false; return true; } }
//MC 2026-10-11 no page reads a list from the address (?a=..&b=..), so b[]=1 style tricks are turned into empty values
//   instead of "Array to string conversion" warnings further down
foreach ($_GET as $gk => $gv) if (!is_scalar($gv)) $_GET[$gk] = '';
//MC 2026-10-16 a broken character anywhere in a reply (a pasted emoji cut in half) made json_encode give up and send an
//   empty body, so the live table could not read its update. Broken bytes now come out as a replacement mark.
function out($data, $code = 200) { http_response_code($code); echo json_encode($data, JSON_INVALID_UTF8_SUBSTITUTE); exit; }
function fail($msg, $code = 400) { out(['ok' => false, 'error' => $msg], $code); }

//MC 2026-10-09 one request often reads the same big file several times (the reward boards read economy.php three times,
//   about 16 ms each). Reads are kept for the rest of the request and reused while the file on disk is unchanged.
//   save() always writes a new file and renames it into place, so a changed file has a new inode, size or time and is
//   read again; inside with_lock nobody else can write, so a reused read is never stale there either.
function load_sig($file) { clearstatcache(true, $file); $st = @stat($file); return $st ? $st['ino'] . ':' . $st['size'] . ':' . $st['mtime'] . ':' . $st['ctime'] : ''; }
function &load_memo() { static $m = []; return $m; }
function load($file) {
    $memo = &load_memo();
    $sig = load_sig($file);
    if ($sig === '') { unset($memo[$file]); return []; }
    if (isset($memo[$file]) && $memo[$file][0] === $sig) return $memo[$file][1];
    $raw = file_get_contents($file);
    $nl = $raw === false ? false : strpos($raw, "\n");
    $d = $nl === false ? null : json_decode(substr($raw, $nl + 1), true);
    if (is_array($d)) { if (strlen($raw) > 20000) $memo[$file] = [$sig, $d]; return $d; }
    // A scores file we can't read must never be treated as empty, or the next save would write an empty board over it.
    if (in_array(basename($file), ['players.php', 'daily.php', 'holders.php', 'shadows.php', 'weeks.php', 'economy.php', 'orders.php', 'rewards.php', 'keys.php', 'push-keys.php', 'friends.php', 'duels.php', 'wallet-claims.php'], true)) {   //MC 2026-10-11 wallet-claims.php too: read as empty it would let a wallet collect its stipend twice
        @file_put_contents(DATA_DIR . '/storage-errors.log', gmdate('c') . ' unreadable ' . basename($file) . "\n", FILE_APPEND);
        storage_fail('The leaderboard is having a moment. Try again in a minute.');
    }
    return [];
}
//MC 2026-10-11 a storage failure inside with_lock used to echo the 503 and exit right there, so the lock was never let go
//   while the shutdown hooks ran (Telegram, push and mail flushes), and a hook that took the lock again waited on its own
//   process. Inside with_lock it now throws; with_lock lets go of the lock first and then answers 503.
class ShyStorageError extends Exception {}
function &lock_depth() { static $d = 0; return $d; }
function storage_fail($msg) {
    if (lock_depth() > 0) throw new ShyStorageError($msg);
    http_response_code(503);
    header('Content-Type: application/json');
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}
function save($file, $data) {
    // keep a daily copy of the scores for 14 days, just in case
    $base = basename($file, '.php');
    if (in_array($base, ['players', 'economy', 'orders', 'rewards'], true) && dirname($file) === DATA_DIR && is_file($file)) {
        $dir = DATA_DIR . '/backups';
        $bk = $dir . '/' . $base . '-' . gmdate('Y-m-d') . '.php';
        if (!is_file($bk)) {
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            //MC 2026-10-11 copied to a temp name and renamed, so a half-written copy never sits under the day's name. The prune
            //   only counts names that are exactly <file>-<date>.php: it used to count players-before-restore-* (and would
            //   have counted the new weekly copies, players-2026-W41.php) and deleted real daily copies early. The cron job
            //   (backup_run in opslib.php) backs up the other files and makes the weekly copies.
            $tmp = $bk . '.tmp.' . getmypid();
            if (@copy($file, $tmp) && @rename($tmp, $bk)) {
                $all = array_filter(glob($dir . '/' . $base . '-*.php') ?: [], fn($f) => preg_match('/^' . $base . '-\d{4}-\d{2}-\d{2}\.php$/', basename($f)));
                sort($all);
                foreach (array_slice($all, 0, max(0, count($all) - 14)) as $old) @unlink($old);
            } else @unlink($tmp);
        }
    }
    //MC 2026-10-11 every write gets its own temp file. With one shared "<file>.tmp", two requests saving the same file
    //   (caches, telegram.php) could rename a temp the other was still filling, and readers saw half a file. A torn
    //   telegram.php read as empty and the next flush saved the defaults over the bot token. Leftovers from a crash are
    //   swept by cron (storage_sweep).
    $tmp = $file . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(4));
    $body = GUARD . json_encode($data);
    // only swap the new file in if it was written in full (a full disk must not cost us the old one)
    if (file_put_contents($tmp, $body) !== strlen($body) || !rename($tmp, $file)) {
        @unlink($tmp);
        @file_put_contents(DATA_DIR . '/storage-errors.log', gmdate('c') . ' write failed ' . basename($file) . "\n", FILE_APPEND);
        storage_fail("Couldn't save right now. Try again in a minute.");
    }
    $memo = &load_memo(); unset($memo[$file]);   // the next read gets the new file
    //MC 2026-10-11 a change to the players or the Daily makes the cached leaderboards (lb.php top) stale
    if (($base === 'players' || $base === 'daily') && dirname($file) === DATA_DIR) foreach (glob(DATA_DIR . '/cache-board-*.php') ?: [] as $c) @unlink($c);
}
function with_lock($fn) {
    if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0755, true); }
    $lf = fopen(DATA_DIR . '/lock.php', 'c');
    if (!$lf) fail('storage unavailable', 500);
    return lock_run($lf, $fn, true);
}
// run $fn holding the open lock file $lf, and always let go of it (also used by the mail and tournament locks)
//MC 2026-10-11 $note: how long it waited for the lock is sampled for the health check (only the site lock does this)
function lock_run($lf, $fn, $note = false) {
    $t0 = $note ? hrtime(true) : 0;
    flock($lf, LOCK_EX);
    $w = $note ? intdiv(hrtime(true) - $t0, 1000) : -1;
    $d = &lock_depth(); $d++; $err = null;
    try { return $fn(); }
    catch (ShyStorageError $e) { $err = $e; }
    finally { $d--; flock($lf, LOCK_UN); fclose($lf); if ($w >= 0) lock_wait_note($w); }
    storage_fail($err->getMessage());   // the lock is free again: now answer 503 (or pass it up to an outer lock)
}
//MC 2026-10-11 one wait for the site lock, in microseconds, written after the lock is let go so it never adds to the hold.
//   With APCu: counters per minute in memory. Without: a line in lock-wait.dat for every wait of 2 ms or more and for one
//   in 20 of the short ones (that line counts 20 times), so a busy site appends a few bytes per request at most. Tried a
//   per-minute summary file first, but that is a read and a rewrite on every request. cron trims the file hourly; a
//   size check here keeps it small even when cron isn't set up.
function lock_wait_note($us) {
    try {
        if (function_exists('apcu_enabled') && @apcu_enabled()) {
            $p = 'shylw:' . substr(md5(DATA_DIR), 0, 8) . ':' . intdiv(time(), 60) . ':';
            apcu_inc($p . 'n', 1, $ok, 7200); apcu_inc($p . 's', $us, $ok, 7200);
            $x = apcu_fetch($p . 'x');
            if ($x === false) apcu_add($p . 'x', $us, 7200); elseif ($us > $x) apcu_cas($p . 'x', $x, $us);
            return;
        }
        if ($us < 2000 && mt_rand(1, 20) !== 1) return;
        $f = DATA_DIR . '/lock-wait.dat';
        if (mt_rand(1, 500) === 1 && @filesize($f) > 1000000) @rename($f, $f . '.1');
        @file_put_contents($f, time() . ' ' . $us . ' ' . ($us < 2000 ? 20 : 1) . "\n", FILE_APPEND);
    } catch (Throwable $e) {}
}
// temp files left by a request that died mid-write, older than an hour (called from cron)
function storage_sweep() { foreach (glob(DATA_DIR . '/*.tmp.*') ?: [] as $f) if (@filemtime($f) < time() - 3600) @unlink($f); }
function client_ip() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    //MC 2026-10-11 behind Cloudflare or another proxy every visitor arrives from the proxy's address and would share one
    //   limit. Set 'trust_proxy' => 'cloudflare' (or 'forwarded') in the private config only when the site really sits
    //   behind one; otherwise these headers are ignored, since anyone can send them.
    $tp = function_exists('shy_config') ? (shy_config()['trust_proxy'] ?? '') : '';
    if ($tp === 'cloudflare' && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    elseif ($tp === 'forwarded' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    return hash('sha256', 'shy-salt:' . $ip);
}
//MC 2026-10-11 a count per window instead of every hit's time: limits.php kept up to 600 timestamps per visitor and
//   action and grew with traffic. Each key is now [window start, count]. Old lists still read (their recent hits count).
function rate_ok(&$limits, $key, $max, $window) {
    $now = time();
    // now and then forget visitors who haven't been back for a day, so this file stays small
    if (random_int(1, 50) === 1) foreach ($limits as $k => $v) if (!is_array($v) || !$v || rate_last($v) < $now - 86400) unset($limits[$k]);
    $v = $limits[$key] ?? null;
    if (is_array($v) && isset($v['w'])) { $start = (int)$v['w']; $n = (int)$v['n']; }
    else { $hits = array_filter((array)$v, fn($t) => is_int($t) && $t > $now - $window); $start = $hits ? min($hits) : $now; $n = count($hits); }
    if ($now - $start >= $window) { $start = $now; $n = 0; }
    if ($n >= $max) { $limits[$key] = ['w' => $start, 'n' => $n]; return false; }
    $limits[$key] = ['w' => $start, 'n' => $n + 1];
    return true;
}
function rate_last($v) { return isset($v['w']) ? (int)$v['w'] : ($v ? max(array_map('intval', (array)$v)) : 0); }
// ---------- player names ----------
// Names are checked after undoing the usual disguises: l33t digits, symbols, spacing and stretched letters.
define('BLOCKED_NAMES', DATA_DIR . '/blocked-names.php');   // extra words the admin adds
const NAME_BAD = [
    // slurs and hate
    'nigg', 'nigga', 'niga', 'negro', 'fag', 'faggot', 'dyke', 'tranny', 'retard', 'spic', 'chink', 'gook', 'kike', 'wetback', 'coon', 'paki', 'raghead', 'towelhead', 'beaner', 'nazi', 'hitler', 'heil', 'kkk', 'jihad', 'isis', 'whitepower', 'siegheil', 'gaschamber', 'holocaust',
    // sexual
    'fuck', 'fuk', 'fck', 'shit', 'bitch', 'cunt', 'whore', 'slut', 'dick', 'cock', 'pussy', 'penis', 'vagina', 'porn', 'sex', 'anal', 'anus', 'boob', 'tits', 'titty', 'cum', 'jizz', 'blowjob', 'handjob', 'dildo', 'horny', 'milf', 'rape', 'rapist', 'pedo', 'pedophile', 'molest', 'incest', 'nude', 'naked', 'orgasm', 'erection', 'hentai', 'onlyfans',
    // abuse
    'asshole', 'arsehole', 'dumbass', 'jackass', 'bigass', 'asshat', 'asswipe', 'fatass', 'bastard', 'wanker', 'twat', 'prick', 'douche', 'motherf', 'killyourself', 'kys', 'suicide',
    // impersonation and scams
    'admin', 'moderator', 'official', 'support', 'shytoshi', 'kusama', 'shyonsol', 'airdrop', 'giveaway', 'freesol', 'claimnow', 'walletconnect', 'seedphrase',
];
// short words that only count as a whole word, so names like "Scunthorpe" or "Essex" still work
const NAME_BAD_WHOLE = ['ass', 'cum', 'sex', 'fag', 'kys', 'tit', 'nig'];
const NAME_OK_INSIDE = ['scunthorpe', 'essex', 'sussex', 'middlesex', 'cocktail', 'peacock', 'hancock', 'dickens', 'shitake', 'shiitake', 'assassin', 'classic', 'bass', 'grass', 'glass', 'pass', 'mass', 'sextant', 'cumulus', 'document', 'circumstance', 'title', 'constitution', 'analog', 'analyst', 'japan', 'skyscraper'];
function name_fold($n) {
    $n = strtolower($n);
    $n = strtr($n, ['0' => 'o', '1' => 'i', '!' => 'i', '|' => 'i', '3' => 'e', '4' => 'a', '@' => 'a', '5' => 's', '$' => 's', '7' => 't', '8' => 'b', '9' => 'g', '6' => 'g', '2' => 'z', '+' => 't', 'ph' => 'f']);
    return $n;
}
function name_blocked($n) {
    static $extra = null;
    if ($extra === null) { $extra = is_file(BLOCKED_NAMES) ? load(BLOCKED_NAMES) : []; if (!is_array($extra)) $extra = []; }
    $f = name_fold($n);
    $words = preg_split('/[^a-z]+/', $f, -1, PREG_SPLIT_NO_EMPTY);
    $joined = implode('', $words);
    $squeezed = preg_replace('/(.)\1+/', '$1', $joined);            // "fuuuuck" -> "fuck"
    $safe = $joined;
    foreach (NAME_OK_INSIDE as $ok) $safe = str_replace($ok, str_repeat('_', strlen($ok)), $safe);
    $safeSq = preg_replace('/(.)\1+/', '$1', $safe);
    foreach (array_merge(NAME_BAD, $extra) as $bad) {
        $bad = strtolower(preg_replace('/[^a-z0-9]/i', '', (string)$bad));
        if (strlen($bad) < 3) continue;
        $badSq = preg_replace('/(.)\1+/', '$1', $bad);
        if (strpos($safe, $bad) !== false || (strlen($badSq) >= 4 && strpos($safeSq, $badSq) !== false)) return true;
    }
    foreach ($words as $w) if (in_array($w, NAME_BAD_WHOLE, true) || in_array(preg_replace('/(.)\1+/', '$1', $w), NAME_BAD_WHOLE, true)) return true;
    // the whole name squeezed together, for spaced-out tricks like "f u c k"
    foreach (NAME_BAD_WHOLE as $w) if ($squeezed === $w) return true;
    return false;
}
// Why a name was turned down, in words a player understands.
function name_problem($n) {
    $n = trim(preg_replace('/\s+/', ' ', is_scalar($n) ? (string)$n : ''));   //MC 2026-10-11 a list or object sent as a name is just a bad name
    if (!preg_match('/^[A-Za-z0-9 _.\-]{3,20}$/', $n)) return 'Names use 3 to 20 letters, numbers, spaces, dots or dashes.';
    if (!preg_match('/[A-Za-z]/', $n)) return 'Names need at least one letter.';
    return "That name isn't allowed. Pick something else.";
}
function clean_name($n) {
    $n = trim(preg_replace('/\s+/', ' ', is_scalar($n) ? (string)$n : ''));
    if (!preg_match('/^[A-Za-z0-9 _.\-]{3,20}$/', $n) || !preg_match('/[A-Za-z]/', $n)) return null;
    if (name_blocked($n)) return null;
    return $n;
}
function week_key() { return gmdate('o-W'); }
function today() { return gmdate('Y-m-d'); }
// Weekly points reset as players start a new week, so the first save of a new week files last week's
// final standings first. Call inside with_lock with the players just loaded.
define('WEEKS', DATA_DIR . '/weeks.php');
function archive_weeks($players) {
    $now = week_key();
    $weeks = null; $changed = false;
    $seen = [];
    foreach ($players as $p) if (!empty($p['wk']) && $p['wk'] !== $now) $seen[$p['wk']] = 1;
    if (!$seen) return;
    $weeks = load(WEEKS);
    foreach (array_keys($seen) as $wk) {
        if (isset($weeks[$wk]) || $wk > $now || $wk < gmdate('o-W', time() - 26 * 7 * 86400)) continue;
        $rows = [];
        foreach ($players as $pid => $p) {
            if (($p['wk'] ?? '') !== $wk || empty($p['wpts'])) continue;
            $rows[] = ['pid' => $pid, 'name' => $p['name'] ?? '', 'pts' => $p['wpts'], 'holder' => !empty($p['holder']), 'avatar' => $p['avatar'] ?? ''];
        }
        usort($rows, fn($a, $b) => $b['pts'] <=> $a['pts']);
        $weeks[$wk] = ['at' => time(), 'rows' => array_slice($rows, 0, 100)];
        if (function_exists('house_freeze_week')) house_freeze_week($wk, $players);   // the House board closes at the same moment
        $changed = true;
    }
    if ($changed) { krsort($weeks); save(WEEKS, array_slice($weeks, 0, 26, true)); }
}
