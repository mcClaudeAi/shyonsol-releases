<?php
// Shy Exchange's swap, the server side. The swap on /exchange is our own (assets/swap.js); the route comes from
// Jupiter's Swap API (api.jup.ag/swap/v2), which finds the best price across every Solana DEX. This file only relays:
// it asks Jupiter for an order, adds our fee (Jupiter's Referral Program: the fee goes to a referral account owned by
// the marketing wallet), hands the unsigned transaction to the visitor's own wallet, and passes the signed one back to
// Jupiter to land. It never holds keys or funds; nothing can move without the visitor signing in their own wallet.
// The Jupiter API key and the fee live in shy-data/exchange.php, set in Admin > Shy Exchange.
// GET  ?a=cfg                                   the fee in bps (0 = none) and whether token search is on
// GET  ?a=order&inputMint&outputMint&amount[&taker][&slippageBps]   a quote, or with taker a transaction to sign
// POST {a: execute, signedTransaction, requestId}                   lands the signed swap
// GET  ?a=tokens                                the popular tokens with logos and prices
// GET  ?a=search&q=                             tokens by name, symbol or mint
// GET  ?a=balances&owner=                       a wallet's SOL and tokens
//MC 2026-10-17 first version
if (!defined('SHY_API')) define('SHY_API', 1);
require_once __DIR__ . '/common.php';
require_once __DIR__ . '/holders.php';   // shy_config: the Helius access

define('SWAP_CFG', DATA_DIR . '/exchange.php');   // ['key' => Jupiter API key, 'ref' => referral account, 'fee' => bps, 'on' => bool]
const SWAP_JUP = 'https://api.jup.ag';
const SWAP_SOL = 'So11111111111111111111111111111111111111112';
const SWAP_SHY = '7d1vpt5eri79nETcL74Punhp3mGkeBgUkMdPWep6pump';
// the tokens shown first in the picker, in this order
const SWAP_POPULAR = [SWAP_SOL, SWAP_SHY, 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
    'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN', 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', 'EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm',
    'J1toso1uCk3RLmjorhTtrVwY9HJ7X8V9yYac6Y7kGCPn', 'mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So', '4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R'];
const SWAP_SOL_ICON = 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png';

function swap_cfg() { $c = is_file(SWAP_CFG) ? load(SWAP_CFG) : []; return (is_array($c) ? $c : []) + ['key' => '', 'ref' => '', 'fee' => 50, 'on' => false]; }
function swap_fee($c = null) { $c = $c ?? swap_cfg(); return !empty($c['on']) && swap_addr($c['ref']) ? max(50, min(255, (int)$c['fee'])) : 0; }
function swap_addr($s) { return is_string($s) && preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $s); }
// one call to Jupiter: [http code, decoded body or null, raw body]
function swap_jup($method, $path, $query = [], $body = null, $timeout = 15) {
    $c = swap_cfg();
    $url = (shy_config()['jup_api'] ?? SWAP_JUP) . $path . ($query ? '?' . http_build_query($query) : '');   // jup_api only for local testing
    $h = ['Accept: application/json'];
    if ($c['key'] !== '') $h[] = 'x-api-key: ' . $c['key'];
    $ch = curl_init($url);
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_HTTPHEADER => $h];
    if ($method === 'POST') { $opt[CURLOPT_POST] = true; $opt[CURLOPT_POSTFIELDS] = json_encode($body); $opt[CURLOPT_HTTPHEADER][] = 'Content-Type: application/json'; }
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false) return [0, null, ''];
    $j = json_decode($raw, true);
    return [$code, is_array($j) ? $j : null, (string)$raw];
}
// Helius (the same access the holder check uses): token details and wallet balances, so the swap works before a
// Jupiter key is set
function swap_das($method, $params, $timeout = 10) {
    $c = shy_config();
    $url = !empty($c['das_url']) ? $c['das_url'] : 'https://mainnet.helius-rpc.com/?api-key=' . rawurlencode($c['helius'] ?? '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(['jsonrpc' => '2.0', 'id' => 'sx', 'method' => $method, 'params' => $params]),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false || $code !== 200) return null;
    $j = json_decode($raw, true);
    return is_array($j) && array_key_exists('result', $j) ? $j['result'] : null;
}
// a token as the page uses it
function swap_tok($id, $sym, $name, $icon, $dec, $usd = null, $verified = null) {
    if ($id === SWAP_SOL) { $sym = 'SOL'; $name = 'Solana'; if ($icon === '') $icon = SWAP_SOL_ICON; }
    $t = ['id' => $id, 'symbol' => mb_substr((string)$sym, 0, 16), 'name' => mb_substr((string)$name, 0, 40), 'icon' => preg_match('#^https://#', (string)$icon) ? (string)$icon : '', 'decimals' => (int)$dec];
    if ($usd !== null && $usd > 0) $t['usd'] = (float)$usd;
    if ($verified !== null) $t['verified'] = (bool)$verified;
    return $t;
}
function swap_from_jup($x) { return swap_tok((string)($x['id'] ?? ''), $x['symbol'] ?? '', $x['name'] ?? '', $x['icon'] ?? '', $x['decimals'] ?? 0, $x['usdPrice'] ?? null, $x['isVerified'] ?? null); }
function swap_from_das($a) {
    $ti = $a['token_info'] ?? []; $md = $a['content']['metadata'] ?? [];
    if (!isset($ti['decimals'])) return null;
    $icon = (string)($a['content']['links']['image'] ?? ($a['content']['files'][0]['cdn_uri'] ?? ($a['content']['files'][0]['uri'] ?? '')));
    return swap_tok((string)$a['id'], $ti['symbol'] ?? ($md['symbol'] ?? ''), $md['name'] ?? '', $icon, $ti['decimals'], $ti['price_info']['price_per_token'] ?? null);
}
function swap_tokens_by_mint($mints) {
    $c = swap_cfg(); $out = [];
    if ($c['key'] !== '') {
        [$code, $j] = swap_jup('GET', '/tokens/v2/search', ['query' => implode(',', $mints)]);
        if ($code === 200 && is_array($j)) foreach ($j as $x) if (!empty($x['id'])) $out[$x['id']] = swap_from_jup($x);
    }
    $miss = array_values(array_filter($mints, fn($m) => !isset($out[$m])));
    if ($miss) { $r = swap_das('getAssetBatch', ['ids' => $miss]); foreach ((array)$r as $a) if (is_array($a) && ($t = swap_from_das($a))) $out[$t['id']] = $t; }
    $list = []; foreach ($mints as $m) if (isset($out[$m])) $list[] = $out[$m];
    return $list;
}

function swap_ds_search($q) {
    $key = mb_strtolower($q); $cf = DATA_DIR . '/cache-swapsearch.json';
    $cache = is_file($cf) ? (json_decode((string)@file_get_contents($cf), true) ?: []) : [];
    if (isset($cache[$key]) && time() - $cache[$key]['t'] < 300) return $cache[$key]['l'];
    $base = shy_config()['ds_api'] ?? 'https://api.dexscreener.com';   // ds_api only for local testing
    $ch = curl_init($base . '/latest/dex/search?q=' . rawurlencode($q));
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = $raw !== false && $code === 200 ? json_decode($raw, true) : null;
    $liq = []; $img = []; $ql = mb_strtolower($q);
    foreach ((array)($j['pairs'] ?? []) as $p) {
        if (($p['chainId'] ?? '') !== 'solana') continue;
        foreach (['baseToken', 'quoteToken'] as $side) {
            $t = $p[$side] ?? []; $m = (string)($t['address'] ?? '');
            if (!swap_addr($m)) continue;
            // only the side that matches what was typed, so "troll" does not list SOL from every TROLL/SOL pair
            if (mb_strpos(mb_strtolower(($t['symbol'] ?? '') . ' ' . ($t['name'] ?? '')), $ql) === false) continue;
            $liq[$m] = ($liq[$m] ?? 0) + (float)($p['liquidity']['usd'] ?? 0);
            if ($side === 'baseToken' && !empty($p['info']['imageUrl']) && empty($img[$m])) $img[$m] = (string)$p['info']['imageUrl'];
        }
    }
    arsort($liq);
    $mints = array_slice(array_keys($liq), 0, 15);
    $list = $mints ? swap_tokens_by_mint($mints) : [];
    foreach ($list as &$t) if ($t['icon'] === '' && !empty($img[$t['id']]) && preg_match('#^https://#', $img[$t['id']])) $t['icon'] = $img[$t['id']];
    unset($t);
    if ($j !== null) {
        $cache[$key] = ['t' => time(), 'l' => $list];
        if (count($cache) > 300) { uasort($cache, fn($a, $b) => $b['t'] <=> $a['t']); $cache = array_slice($cache, 0, 200, true); }
        @file_put_contents($cf, json_encode($cache), LOCK_EX);
    }
    return $list;
}

if (defined('SWAP_LIB')) return;   //MC 2026-10-17 Admin > Shy Exchange loads this for the settings above
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
$a = (string)($_GET['a'] ?? '');
$body = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') { $body = json_decode((string)file_get_contents('php://input'), true) ?: []; $a = (string)($body['a'] ?? $a); }
// quotes come often while someone types, so the limit is generous; it only stops a script hammering Jupiter through us
$lim = ['ph_new' => [10, 60], 'ph_state' => [120, 60], 'ph_sign' => [20, 60], 'ph_back' => [30, 60], 'ph_end' => [10, 60], 'err' => [12, 60], 'order' => [90, 60], 'execute' => [20, 60], 'search' => [60, 60], 'balances' => [40, 60], 'tokens' => [30, 60], 'cfg' => [30, 60]][$a] ?? null;
if (!$lim) fail('unknown action');
$okRate = with_lock(function () use ($a, $lim) { $l = load(LIMITS); $ok = rate_ok($l, 'swap:' . $a . ':' . client_ip(), $lim[0], $lim[1]); save(LIMITS, $l); return $ok; });
if (!$okRate) fail('Slow down a little and try again.', 429);

if ($a === 'cfg') {
    $c = swap_cfg();
    header('Cache-Control: public, max-age=60');
    out(['ok' => true, 'fee' => swap_fee($c), 'search' => $c['key'] !== '', 'ph' => ph_ok()]);
}
// the order Jupiter is asked for: our fee goes on when it's set up. Returns [http code, answer, fee] or fails
function swap_order($in, $outM, $amt, $tk, $slip) {
    if (!swap_addr($in) || !swap_addr($outM) || $in === $outM) fail('Pick two different tokens.');
    if (!preg_match('/^[1-9]\d{0,24}$/', (string)$amt)) fail('Enter an amount.');
    $q = ['inputMint' => $in, 'outputMint' => $outM, 'amount' => (string)$amt, 'swapMode' => 'ExactIn', 'maxSupportedTransactionVersion' => '0'];
    if ($tk !== '') { if (!swap_addr($tk)) fail('That wallet address is not valid.'); $q['taker'] = $tk; }
    if ($slip !== '' && $slip !== null) { $sv = (int)$slip; if ($sv < 1 || $sv > 5000) fail('Slippage must be between 0.01% and 50%.'); $q['slippageBps'] = $sv; }
    $c = swap_cfg();
    if (($fee = swap_fee($c)) > 0) { $q['referralAccount'] = $c['ref']; $q['referralFee'] = $fee; }
    [$code, $j] = swap_jup('GET', '/swap/v2/order', $q);
    if ($code === 0) fail('Jupiter is not answering right now. Try again in a moment.', 502);
    if (!$j) fail('Jupiter sent back something unexpected. Try again.', 502);
    return [$code, $j, $fee];
}
if ($a === 'order') {
    [$code, $j, $fee] = swap_order((string)($_GET['inputMint'] ?? ''), (string)($_GET['outputMint'] ?? ''), (string)($_GET['amount'] ?? ''), (string)($_GET['taker'] ?? ''), $_GET['slippageBps'] ?? '');
    http_response_code($code >= 200 && $code < 500 ? $code : 502);
    echo json_encode(['ok' => $code === 200 && empty($j['error'])] + $j + ['shyFee' => $fee]);
    exit;
}

//MC 2026-10-17 approve in Phantom without leaving the app. Phones with no wallet in the browser (the Shilluminati
//   home-screen app, Safari, Telegram) used to be sent into Phantom's own browser and left there. Now Phantom opens
//   only to approve, through its deeplinks: connect, then signTransaction. Phantom answers by opening a link back to
//   us (/phantom/<handle>/<step>, a plain path so Phantom can add its answer as the query). The keys for that conversation live here on the server, so the answer can be read and the signed
//   swap sent to Jupiter straight away, whichever browser Phantom hands back to (on iPhone that's Safari, since a
//   home-screen app can't be reopened by another app). The page only holds a random handle and asks ph_state.
//   Nothing here can sign: every swap is approved by the player in Phantom.
const PH_FILE = DATA_DIR . '/phantom-sx.php';
const PH_B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
function ph_b58e($bin) {
    $bytes = array_values(unpack('C*', $bin) ?: []); $z = 0; $n = count($bytes);
    while ($z < $n && $bytes[$z] === 0) $z++;
    $d = [];
    foreach ($bytes as $b) { $c = $b; foreach ($d as $k => $v) { $c += $v << 8; $d[$k] = $c % 58; $c = intdiv($c, 58); } while ($c) { $d[] = $c % 58; $c = intdiv($c, 58); } }
    $o = str_repeat('1', $z); for ($k = count($d) - 1; $k >= 0; $k--) $o .= PH_B58[$d[$k]];
    return $o;
}
function ph_b58d($s) {
    $s = (string)$s; if ($s === '' || strspn($s, PH_B58) !== strlen($s)) return null;
    $z = strspn($s, '1'); $b = [];
    for ($i = 0, $L = strlen($s); $i < $L; $i++) { $c = strpos(PH_B58, $s[$i]); foreach ($b as $k => $v) { $c += $v * 58; $b[$k] = $c & 255; $c >>= 8; } while ($c) { $b[] = $c & 255; $c >>= 8; } }
    return str_repeat("\0", $z) . implode('', array_map('chr', array_reverse($b)));
}
function ph_all() { $d = load(PH_FILE); return is_array($d) ? $d : []; }
function ph_get($id) { return preg_match('/^[a-f0-9]{32}$/', (string)$id) ? (ph_all()[$id] ?? null) : null; }
function ph_put($id, $rec) {
    with_lock(function () use ($id, $rec) {
        $d = ph_all(); $now = time();
        foreach ($d as $k => $v) if (($v['seen'] ?? $v['t']) < $now - 30 * 86400) unset($d[$k]);
        if ($rec === null) unset($d[$id]); else $d[$id] = $rec;
        if (count($d) > 4000) { uasort($d, fn($a, $b) => ($b['seen'] ?? 0) <=> ($a['seen'] ?? 0)); $d = array_slice($d, 0, 3000, true); }
        save(PH_FILE, $d);
    });
}
//MC 2026-10-17 the live server's PHP has no sodium, so the same box (X25519 with XSalsa20-Poly1305, what Phantom uses)
//   comes from sodium_compat in api/lib when it's missing. 'ph_compat' in the config forces it, for testing.
function ph_native() { return function_exists('sodium_crypto_box_keypair_from_secretkey_and_publickey') && empty(shy_config()['ph_compat']); }
function ph_lib() {
    if (ph_native()) return true;
    if (!class_exists('ParagonIE_Sodium_Compat', false)) { $f = __DIR__ . '/lib/sodium_compat/autoload.php'; if (!is_file($f)) return false; require_once $f; }
    return class_exists('ParagonIE_Sodium_Compat');
}
function ph_keypair() { return ph_native() ? sodium_crypto_box_keypair() : ParagonIE_Sodium_Compat::crypto_box_keypair(); }
function ph_kp_sk($kp) { return ph_native() ? sodium_crypto_box_secretkey($kp) : ParagonIE_Sodium_Compat::crypto_box_secretkey($kp); }
function ph_kp_pk($kp) { return ph_native() ? sodium_crypto_box_publickey($kp) : ParagonIE_Sodium_Compat::crypto_box_publickey($kp); }
function ph_kp($sk, $pk) { return ph_native() ? sodium_crypto_box_keypair_from_secretkey_and_publickey($sk, $pk) : ParagonIE_Sodium_Compat::crypto_box_keypair_from_secretkey_and_publickey($sk, $pk); }
function ph_box($rec, $obj) {
    $nonce = random_bytes(24); $kp = ph_kp(base64_decode($rec['sk']), ph_b58d($rec['phpk']));
    $c = ph_native() ? sodium_crypto_box(json_encode($obj), $nonce, $kp) : ParagonIE_Sodium_Compat::crypto_box(json_encode($obj), $nonce, $kp);
    return [ph_b58e($nonce), ph_b58e($c)];
}
function ph_open($sk, $phpk58, $nonce58, $data58) {
    $pk = ph_b58d($phpk58); $n = ph_b58d($nonce58); $c = ph_b58d($data58);
    if (!$pk || strlen($pk) !== 32 || !$n || strlen($n) !== 24 || !$c) return null;
    $kp = ph_kp(base64_decode($sk), $pk);
    try { $m = ph_native() ? sodium_crypto_box_open($c, $n, $kp) : ParagonIE_Sodium_Compat::crypto_box_open($c, $n, $kp); } catch (Throwable $e) { $m = false; }
    return $m === false || $m === null ? null : json_decode($m, true);
}
const TG_SITE_SWAP = 'https://shyonsol.io';
function ph_site() { return shy_config()['site_url'] ?? TG_SITE_SWAP; }
function ph_ok() { return ph_lib(); }

if (strncmp($a, 'ph_', 3) === 0 && !ph_lib()) fail('Phantom approval is not available here yet.', 503);
if ($a === 'ph_new') {
    if (!ph_ok()) fail('Phantom approval is not available here yet.', 503);
    $kp = ph_keypair(); $id = bin2hex(random_bytes(16));
    ph_put($id, ['t' => time(), 'seen' => time(), 'sk' => base64_encode(ph_kp_sk($kp)), 'pk' => ph_b58e(ph_kp_pk($kp)), 'phpk' => '', 'sess' => '', 'wallet' => '', 'req' => null, 'last' => null]);
    $site = ph_site();
    $url = 'https://phantom.app/ul/v1/connect?' . http_build_query(['app_url' => $site, 'dapp_encryption_public_key' => ph_b58e(ph_kp_pk($kp)),
        'redirect_link' => $site . '/phantom/' . $id . '/connect', 'cluster' => 'mainnet-beta']);
    out(['ok' => true, 's' => $id, 'url' => $url]);
}
if ($a === 'ph_state') {
    $id = (string)($_GET['s'] ?? ''); $r = ph_get($id);
    if (!$r) out(['ok' => true, 'gone' => true]);
    if (($r['seen'] ?? 0) < time() - 3600) { $r['seen'] = time(); ph_put($id, $r); }
    out(['ok' => true, 'wallet' => $r['wallet'], 'last' => $r['last'], 'pending' => !empty($r['req']) && empty($r['req']['done'])]);
}
if ($a === 'ph_end') {
    $id = (string)($body['s'] ?? ''); if (ph_get($id)) ph_put($id, null);
    out(['ok' => true]);
}
if ($a === 'ph_sign') {
    $id = (string)($body['s'] ?? ''); $r = ph_get($id);
    if (!$r || $r['wallet'] === '' || $r['sess'] === '') fail('Connect Phantom again.', 409);
    [$code, $j, $fee] = swap_order((string)($body['inputMint'] ?? ''), (string)($body['outputMint'] ?? ''), (string)($body['amount'] ?? ''), $r['wallet'], $body['slippageBps'] ?? '');
    if ($code !== 200 || empty($j['transaction']) || empty($j['requestId'])) { http_response_code($code >= 400 && $code < 500 ? $code : 502); echo json_encode(['ok' => false] + $j); exit; }
    [$nonce, $payload] = ph_box($r, ['transaction' => ph_b58e(base64_decode($j['transaction'])), 'session' => $r['sess']]);
    $r['req'] = ['rid' => (string)$j['requestId'], 't' => time(), 'in' => (string)$body['inputMint'], 'out' => (string)$body['outputMint'], 'oa' => (string)($j['outAmount'] ?? ''), 'done' => 0];
    $r['seen'] = time(); ph_put($id, $r);
    $url = 'https://phantom.app/ul/v1/signTransaction?' . http_build_query(['dapp_encryption_public_key' => $r['pk'], 'nonce' => $nonce,
        'redirect_link' => ph_site() . '/phantom/' . $id . '/sign', 'payload' => $payload]);
    out(['ok' => true, 'url' => $url, 'outAmount' => $j['outAmount'] ?? '', 'shyFee' => $fee]);
}
if ($a === 'ph_back') {
    $id = (string)($_GET['s'] ?? ''); $stp = ($_GET['st'] ?? '') === 'sign' ? 'sign' : 'connect'; $r = ph_get($id);
    header('Cache-Control: no-store');
    $go = function ($extra = '') use ($id) { header('Content-Type: text/html; charset=utf-8'); header('Location: /swap?phs=' . $id . $extra, true, 302); exit; };
    if (!$r) $go('&ph=gone');
    $last = ['st' => $stp, 'ok' => 0, 't' => time()];
    if (isset($_GET['errorCode'])) {
        $last['err'] = (string)$_GET['errorCode'] === '4001' ? 'cancel' : mb_substr(preg_replace('/[^\p{L}\p{N} .,:\'_\-]/u', '', (string)($_GET['errorMessage'] ?? 'Phantom could not finish that.')), 0, 160);
        if ($stp === 'sign' && $r['req']) $r['req']['done'] = 1;
    } elseif ($stp === 'connect') {
        $phpk = (string)($_GET['phantom_encryption_public_key'] ?? '');
        $m = ph_open($r['sk'], $phpk, $_GET['nonce'] ?? '', $_GET['data'] ?? '');
        if ($m && swap_addr((string)($m['public_key'] ?? '')) && !empty($m['session'])) { $r['phpk'] = $phpk; $r['sess'] = (string)$m['session']; $r['wallet'] = (string)$m['public_key']; $last['ok'] = 1; }
        else $last['err'] = 'Phantom\'s answer could not be read. Try connecting again.';
    } else {
        $m = $r['req'] && empty($r['req']['done']) ? ph_open($r['sk'], $r['phpk'], $_GET['nonce'] ?? '', $_GET['data'] ?? '') : null;
        $tx = $m ? ph_b58d((string)($m['transaction'] ?? '')) : null;
        if (!$r['req'] || !empty($r['req']['done'])) $last['err'] = 'That swap was already handled. Get a new price and try again.';
        elseif (!$tx) $last['err'] = 'Phantom\'s answer could not be read. Nothing was spent. Try again.';
        else {
            $r['req']['done'] = 1; ph_put($id, $r);   // marked first, so a reload of this link can't send it twice
            [$code, $j] = swap_jup('POST', '/swap/v2/execute', [], ['signedTransaction' => base64_encode($tx), 'requestId' => $r['req']['rid']], 45);
            if ($code === 200 && ($j['status'] ?? '') === 'Success' && !empty($j['signature'])) {
                $last = array_merge($last, ['ok' => 1, 'sig' => (string)$j['signature'], 'in' => $r['req']['in'], 'out' => $r['req']['out'], 'got' => (string)($j['outputAmountResult'] ?? ($j['totalOutputAmount'] ?? $r['req']['oa']))]);
            } else $last['err'] = 'The swap didn\'t go through' . (isset($j['code']) ? ' (code ' . (int)$j['code'] . ')' : '') . '. Nothing was taken except possibly a tiny network fee. Get a new price and try again.';
        }
    }
    $r['last'] = $last; $r['seen'] = time(); ph_put($id, $r);
    $go('&ph=' . $stp);
}

//MC 2026-10-17 a wallet error before the swap was sent (Phantom showed "Unknown Error" on a first try). The page sends
//   what the wallet said so Admin > Shy Swap shows it; no wallet address or amount is kept
if ($a === 'err') {
    $m = mb_substr(preg_replace('/[^\p{L}\p{N} .,:;()\'"_\-\/]/u', '', (string)($body['m'] ?? '')), 0, 200);
    $rec = ['t' => time(), 'm' => $m, 'w' => mb_substr(preg_replace('/[^\p{L}\p{N} ]/u', '', (string)($body['w'] ?? '')), 0, 30), 'step' => in_array($body['step'] ?? '', ['connect', 'order', 'sign', 'send'], true) ? $body['step'] : '',
        'mob' => !empty($body['mob']) ? 1 : 0];
    $f = DATA_DIR . '/swap-errors.json';
    with_lock(function () use ($f, $rec) { $l = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : []; $l[] = $rec; @file_put_contents($f, json_encode(array_slice($l, -60)), LOCK_EX); });
    out(['ok' => true]);
}
if ($a === 'execute') {
    $tx = (string)($body['signedTransaction'] ?? ''); $rid = (string)($body['requestId'] ?? '');
    if ($tx === '' || strlen($tx) > 8000 || !preg_match('#^[A-Za-z0-9+/=]+$#', $tx)) fail('The signed swap is missing.');
    if ($rid === '' || strlen($rid) > 200) fail('The swap has expired. Get a new quote.');
    [$code, $j] = swap_jup('POST', '/swap/v2/execute', [], ['signedTransaction' => $tx, 'requestId' => $rid], 45);
    if ($code === 0 || !$j) fail('Jupiter did not answer while landing the swap. Check your wallet before trying again: it may have gone through.', 502);
    if (!empty($j['signature']) && ($j['status'] ?? '') === 'Success') { try { if (function_exists('track')) track('exchange_swaps'); } catch (Throwable $e) {} }
    http_response_code($code >= 200 && $code < 500 ? $code : 502);
    echo json_encode(['ok' => ($j['status'] ?? '') === 'Success'] + $j);
    exit;
}
if ($a === 'tokens') {
    $f = DATA_DIR . '/cache-swaptokens.php';
    $cc = is_file($f) ? load($f) : [];
    if (empty($cc['t']) || time() - $cc['t'] > 600 || empty($cc['list'])) {
        $list = swap_tokens_by_mint(SWAP_POPULAR);
        if ($list) { $cc = ['t' => time(), 'list' => $list]; with_lock(fn() => save($f, $cc)); }
    }
    header('Cache-Control: public, max-age=300');
    out(['ok' => true, 'tokens' => $cc['list'] ?? []]);
}
if ($a === 'search') {
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q === '' || mb_strlen($q) > 60) out(['ok' => true, 'tokens' => []]);
    if (swap_addr($q)) out(['ok' => true, 'tokens' => swap_tokens_by_mint([$q])]);   // a pasted mint
    $c = swap_cfg(); $list = [];
    if ($c['key'] !== '') {
        [$code, $j] = swap_jup('GET', '/tokens/v2/search', ['query' => $q]);
        if ($code === 200 && is_array($j)) foreach (array_slice($j, 0, 30) as $x) if (!empty($x['id'])) $list[] = swap_from_jup($x);
    }
    //MC 2026-10-17 searching by name needed a Jupiter key, so with no key "troll" found nothing. DexScreener search
    //   is keyless: take the Solana pairs, rank tokens by liquidity, then get decimals from Helius (DexScreener has none)
    if (!$list) $list = swap_ds_search($q);
    header('Cache-Control: public, max-age=120');
    out(['ok' => true, 'tokens' => $list]);
}
if ($a === 'balances') {
    $own = (string)($_GET['owner'] ?? '');
    if (!swap_addr($own)) fail('That wallet address is not valid.');
    $r = swap_das('getAssetsByOwner', ['ownerAddress' => $own, 'page' => 1, 'limit' => 1000, 'displayOptions' => ['showFungible' => true, 'showNativeBalance' => true, 'showZeroBalance' => false]], 12);
    if (!is_array($r)) fail('Could not read that wallet right now.', 502);
    $toks = [];
    $nb = $r['nativeBalance'] ?? [];
    $sol = (string)(int)($nb['lamports'] ?? 0);
    foreach ($r['items'] ?? [] as $x) {
        if (($x['interface'] ?? '') !== 'FungibleToken' && ($x['interface'] ?? '') !== 'FungibleAsset') continue;
        $raw = (string)($x['token_info']['balance'] ?? '0'); if ($raw === '0' || $raw === '') continue;
        $t = swap_from_das($x); if (!$t || $t['id'] === SWAP_SOL) continue;
        $t['raw'] = $raw;
        $t['value'] = (float)($x['token_info']['price_info']['total_price'] ?? 0);
        $toks[] = $t;
    }
    usort($toks, fn($p, $q) => $q['value'] <=> $p['value']);
    out(['ok' => true, 'sol' => $sol, 'solUsd' => (float)($nb['price_per_sol'] ?? 0), 'tokens' => array_slice($toks, 0, 200)]);
}
