<?php
//MC 2026-10-16 is this player on the team? The app shows an Admin center button in its menu for the profiles on the
//   team's dev list (eco setting dev_pids, Shilltoshi by default). It only shows the button: admin still asks for its
//   own sign-in.
// POST {pid, key} -> {ok, team}
define('SHY_API', 1);
require __DIR__ . '/common.php';
require_once __DIR__ . '/holders.php';
require_once __DIR__ . '/economy.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) out(['ok' => true, 'team' => false]);
$team = with_lock(function () use ($pid, $key) { return !empty(keys_known($pid)) && key_ok($pid, hash('sha256', $key)) && eco_dev($pid); });
out(['ok' => true, 'team' => (bool)$team]);
