<?php
if (!defined('SHY_API')) { http_response_code(404); exit; }
//MC 2026-10-15 room codes are random letters, and a player got PCUNT. Every new code is now checked against a list of
//   rude words (also read with the digits as the letters they look like: 3 E, 5 S, 7 T and so on) and redrawn if it
//   spells one. Used by new_code in livelib.php and tp_code in tourney.php.
const CODE_RUDE = ['CUNT', 'CVNT', 'KUNT', 'FUCK', 'FUK', 'FCK', 'FUC', 'FUQ', 'PHUC', 'PHUK', 'TWAT', 'CUM', 'JIZ', 'COCK', 'DICK', 'DIK', 'DCK',
    'PUSS', 'PUSY', 'PSSY', 'PENIS', 'PNS', 'TIT', 'TTS', 'ASS', 'ARSE', 'BUTT', 'ANAL', 'ANUS', 'SEX', 'SXY', 'XXX', 'PORN', 'PRN', 'NUDE', 'NUD',
    'SHIT', 'SHT', 'CRAP', 'PISS', 'PSS', 'DAMN', 'BTCH', 'BICH', 'BITCH', 'WHOR', 'HOE', 'SLUT', 'SLT', 'SKANK', 'SKNK', 'WANK', 'WNK', 'BJ',
    'NIG', 'NGG', 'NGR', 'NGA', 'NEGR', 'KKK', 'NAZI', 'NAZ', 'HTLR', 'HITLR', 'SS', 'JEW', 'KIKE', 'KYK', 'SPIC', 'SPK', 'CHNK', 'GOOK',
    'FAG', 'FGT', 'FAGT', 'DYKE', 'DYK', 'TRANNY', 'TRNY', 'RETARD', 'RTRD', 'RETRD', 'TARD', 'SPAZ', 'RAPE', 'RAPST', 'RPST', 'MOLEST', 'PEDO', 'PDO',
    'KYS', 'KMS', 'KILL', 'MURDR', 'STFU', 'GTFO', 'WTF', 'MILF', 'MLF', 'DILF', 'THOT', 'THT', 'BALLS', 'NUTS', 'NUTZ', 'HUMP', 'SUCK', 'SUK', 'SCK',
    'BOOB', 'BOOBS', 'BUB', 'BEWB', 'DUMBASS', 'JERK', 'JRK', 'POOP', 'PUKE', 'VAG', 'VGN', 'CLIT', 'CLT', 'TWT', 'GAY', 'HOMO', 'HMO', 'LSD', 'METH', 'MTH',
    'WEED', 'HEROIN', 'CRACK', 'CRCK', 'DRUG', 'ISIS', 'ISIL', 'TERR', 'BOMB', 'BMB', 'GUN', 'SHOOT', 'DEAD', 'DIE', 'HATE'];
function code_clean($c) {
    $c = strtoupper($c);
    $look = strtr($c, ['0' => 'O', '1' => 'I', '2' => 'Z', '3' => 'E', '4' => 'A', '5' => 'S', '6' => 'G', '7' => 'T', '8' => 'B', '9' => 'G']);
    foreach (CODE_RUDE as $w) {
        if (strlen($w) < 3 && $w !== 'BJ' && $w !== 'SS') continue;
        if (strpos($c, $w) !== false || strpos($look, $w) !== false) return false;
    }
    return true;
}

