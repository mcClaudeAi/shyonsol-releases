// A player's public page (shyonsol.io/p/name): their look, record, ranks, collection and the cards they play most.
//MC 2026-10-09 clean URLs (/play, /profile, /stats, /houses); the .html links cost a redirect on every tap
// The record comes in the page itself (api/player.php puts it there), or from ?n= when the page is opened directly.
(function () {
  "use strict";
  var root = document.getElementById("pp");
  if (!root) return;
  var AV = (document.querySelector('script[src*="player.js"]') || {}).src;
  AV = AV && AV.indexOf("?") > 0 ? AV.slice(AV.indexOf("?")) : "";
  var L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined;   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function date(ts) { return new Date(ts * 1000).toLocaleDateString(L, { month: "short", day: "numeric", year: "numeric" }); }
  function ago(ts) {
    var s = Math.max(0, Date.now() / 1000 - ts), f;
    try { f = new Intl.RelativeTimeFormat(L, { numeric: "auto", style: "short" }); } catch (e) { return date(ts); }
    if (s < 90) return f.format(0, "minute");
    if (s < 3600) return f.format(-Math.round(s / 60), "minute");
    if (s < 86400) return f.format(-Math.round(s / 3600), "hour");
    if (s < 86400 * 7) return f.format(-Math.round(s / 86400), "day");
    return date(ts);
  }
  function store(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }

  //MC 2026-10-10 the $SHY Army Ranks replace the Bronze to Kami tiers: each rank has its emblem from the community poster
  var RK = ["sapling", "cadet", "scout", "knight", "champion", "commander", "sovereign", "king", "supreme"];
  var RKN = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King / Queen", supreme: "Shytoshi Supreme" };
  var RKC = ["Recruits", "Recruits", "Recruits", "Officers", "Officers", "Officers", "High Command", "High Command", "High Command"];
  function rkImg(k, small) { return "/assets/ranks/" + k + (small ? "-64" : "") + ".webp"; }
  function tierChip(P) {
    if (RKN[P.tier]) return '<span class="pp-tier rk t-' + esc(P.tier) + '"><img src="' + rkImg(P.tier, 1) + '" alt="" width="22" height="22"><span data-i18n-skip>' + esc(RKN[P.tier]) + '</span></span>';
    return P.tier === "shadow" ? '<span class="pp-tier t-shadow">Shadow holder</span>' : "";
  }
  // the rank panel: emblem, name and the next rank. The $SHY gap isn't shown here, it would give away the balance
  function rankCard(P) {
    var k = RKN[P.tier] ? P.tier : ""; if (!k) return "";
    var i = RK.indexOf(k), nx = P.tierNext;
    var track = RK.map(function (r, j) { return '<i class="rk-step' + (j < i ? " done" : j === i ? " on" : "") + '" title="' + esc(RKN[r]) + '"><img src="' + rkImg(r, 1) + '" alt="" width="64" height="64" loading="lazy"></i>'; }).join("");
    return '<section class="rk-card rk pp-rk t-' + k + '"><div class="rk-em"><img src="' + rkImg(k) + '" alt="" width="256" height="256"></div>' +
      '<div class="rk-txt"><span class="rk-k">$SHY Army Rank &middot; ' + RKC[i] + '</span><h2 class="rk-name" data-i18n-skip>' + esc(RKN[k]) + '</h2>' +
      '<p class="rk-sub">Rank ' + (i + 1) + ' of 9</p></div>' +
      '<div class="rk-next">' + (nx ? '<p class="rk-need">Next rank: <b data-i18n-skip>' + esc(nx.name) + '</b> at ' + fmt(nx.at) + ' $SHY</p>' : '<p class="rk-need">The top of the ranks.</p>') +
      '<div class="rk-track">' + track + '</div><a class="rk-all" href="/token#holders">See every rank and its perks</a></div></section>';
  }
  var MODE = { normal: "Solo", easy: "Solo · Easy", daily: "Daily", live: "Live" };
  var RES = { win: "Win", tie: "Tie", loss: "Loss" };
  //MC 2026-10-10 the Animated finishes too, so a showcased one has its name
  var FIN_N = { gold: "Gold Leaf", crimson: "Blood Moon", neon: "Neon Shrine", holo: "Holo Foil", shadow: "Shadow Ink", ink: "Ink Bleed", seal: "Vermilion Seal", smoke: "Smoke Wisp", kintsugi: "Kintsugi", sakura: "Sakura Drift", ember: "Ember Rise", frost: "Frost Creep", koi: "Koi Pond", raijin: "Raijin Crackle", glitch: "Glitch Scan", aurora: "Aurora Veil", cosmos: "Night Sky" };
  var KIND_N = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", trick: "Trick", passive: "Reaction" };

  function face(P) {
    var cos = P.cos || {}, src, cls = "pp-av";
    if (P.img) { src = P.img; cls += " pp-holder" + (P.aura ? " av-aura au-" + P.aura : "") + (/^[a-z]+$/.test(cos.halo || "") ? " hl-" + cos.halo : ""); }
    else if (/^[a-z]+$/.test(cos.skin || "")) src = "assets/art/skins/skin_" + cos.skin + ".svg" + AV;
    else src = "assets/art/masks/unbound.svg" + AV;
    if (/^[a-z]+$/.test(cos.ring || "")) cls += " ring-" + cos.ring;
    //MC 2026-10-09 Living Portrait (Profile Studio unlock): the picture floats and turns like a Living Shadow (living.js),
    //in the Shadow's Aura colour for a holder. Without the unlock, or if living.js didn't load, it's the still picture.
    if ((P.page || {}).portrait && window.ShyLiving) {
      var sz = matchMedia("(max-width:720px)").matches ? "132px" : "168px";
      return '<div class="' + cls + ' pp-live">' + ShyLiving.html(src, { aura: P.img && /^[a-z]+$/.test(P.aura || "") ? P.aura : "none", size: sz, fb: "assets/art/masks/unbound.svg" + AV }) + (P.img ? '<i class="pp-ok" title="Verified holder" aria-hidden="true">✓</i>' : "") + '</div>';
    }
    return '<div class="' + cls + '"><img src="' + esc(src) + '" alt="" onerror="this.src=\'assets/art/masks/unbound.svg' + AV + '\'">' + (P.img ? '<i class="pp-ok" title="Verified holder" aria-hidden="true">✓</i>' : "") + '</div>';
  }
  function rank(r) { return r && r.rank ? '<span class="pp-rk">#' + fmt(r.rank) + '</span> <small>of ' + fmt(r.of) + '</small>' : '<small>Unranked</small>'; }

  //MC 2026-10-13 power tiers: one bar to 9,000 meant the top players sat on a full bar forever and the 9,000 label
  //   collided with the number. Now the bar is progress through the CURRENT tier, 9,000 is the gate into Limit Breaker
  //   (where the meter cracks for good), and Final Form at 35,000 is the show the top players earn. Tier names stay
  //   untranslated like brand words. assets/eggs.js animates it.
  var PW_TIERS = [["Initiate", 0, "\u521D"], ["Ronin", 3000, "\u6D6A"], ["Limit Breaker", 9000, "\u9650"], ["Warlord", 18000, "\u8987"], ["Final Form", 35000, "\u6975"]];
  function power(s) {
    var pw = s.points + 90 * s.wins + 45 * s.best + 9 * s.games;
    var ti = 0; for (var i = 0; i < PW_TIERS.length; i++) if (pw >= PW_TIERS[i][1]) ti = i;
    var tier = PW_TIERS[ti], next = PW_TIERS[ti + 1] || null;
    var pct = next ? Math.min(100, 100 * (pw - tier[1]) / (next[1] - tier[1])) : 100;
    var rows = [["Points", s.points, 1], ["Wins", s.wins, 90], ["Best boards", s.best, 45], ["Games", s.games, 9]];
    return '<section class="pw-strip t' + (ti + 1) + (ti >= 2 ? " broken" : "") + (next ? "" : " final") + '" data-pw="' + pw + '" data-pct="' + pct.toFixed(1) + '" role="button" tabindex="0" aria-expanded="false">' +
      '<i class="pw-kanji" aria-hidden="true" data-i18n-skip>' + tier[2] + '</i>' +
      '<div class="pw-top"><small>Power level</small><b class="pw-n" data-i18n-skip>' + fmt(pw) + '</b><span class="pw-tier" data-i18n-skip><i>' + tier[2] + '</i>' + tier[0] + '</span><span class="pw-hint">Tap for the breakdown</span></div>' +
      '<span class="pw-bar"><i class="pw-fill" style="width:' + pct.toFixed(1) + '%"></i></span>' +
      '<span class="pw-sub">' + (next ? '<span>Next tier:</span> <b data-i18n-skip>' + next[0] + '</b> <span>at</span> <b data-i18n-skip>' + fmt(next[1]) + '</b>' + (ti >= 2 ? ' <span>The meter was not built for this.</span>' : "") : '<span>The ladder ends here. The meter gave up long ago.</span>') + '</span>' +
      '<div class="pw-break" hidden>' + rows.map(function (r) {
        return '<div class="pw-row"><span>' + r[0] + '</span><em data-i18n-skip>' + fmt(r[1]) + (r[2] > 1 ? " \u00D7 " + r[2] : "") + '</em><b data-i18n-skip>+' + fmt(r[1] * r[2]) + '</b></div>';
      }).join("") + '</div></section>';
  }
  function tile(label, value, sub, cls) { return '<div class="pp-tile' + (cls ? " " + cls : "") + '"><small>' + label + '</small><b>' + value + '</b>' + (sub ? '<span>' + sub + '</span>' : "") + '</div>'; }

  function render(P) {
    document.getElementById("pp-crumb").textContent = P.name;
    if (P.hidden) {
      root.innerHTML = '<section class="pp-head pp-private"><div class="pp-av"><img src="assets/art/masks/unbound.svg' + AV + '" alt=""></div><div class="pp-id"><span class="pp-k">Player</span><h1 class="pp-name" data-i18n-skip>' + esc(P.name) + '</h1>' +
        '<p class="pp-lead">This player keeps their page private.</p><div class="pp-cta"><a class="btn btn-red" href="/play">Play Shilluminati free</a><a class="btn btn-line" href="/stats">See the leaderboards</a></div></div></section>';
      return;
    }
    var s = P.stats, wr = s.games ? Math.round(s.wins / s.games * 100) : 0, mine = store("shy-lb-pid").slice(0, 6) === P.tag;
    //MC 2026-10-15 the shared link carries the preview picture's own version (?s=), so every new post makes X and Telegram
    //   fetch the card as it is now. A plain /p/name link reused X's cached preview, broken one included, for days.
    var ogm = document.querySelector('meta[property="og:image"]'), ogv = ogm && /[?&]h=([a-f0-9]{8})/.exec(ogm.content);
    //MC 2026-10-15 sharing someone else's page tags their X account (@handle) when they've connected one, not just their name
    var url = location.origin + "/p/" + encodeURIComponent(P.slug) + (ogv ? "?s=" + ogv[1] : "");
    //   and the picture is drawn now, while you're on the page, so it's ready before anyone's app asks for it
    if (ogv && !P.hidden) try { fetch(ogm.content.replace(/^https?:\/\/[^/]+/, ""), { cache: "force-cache" }).catch(function () {}); } catch (e) {}
    var chips = (P.cos && P.cos.title ? '<em class="g-title">' + esc(P.cos.title) + '</em>' : "") +
      (P.house ? '<a class="pp-house" href="/houses?h=' + encodeURIComponent(P.house.tag) + '"><span class="hs-tag" data-i18n-skip>' + esc(P.house.tag) + '</span><span data-i18n-skip>' + esc(P.house.name) + '</span></a>' : "") +
      tierChip(P) +
      (P.seeker ? '<span class="pp-seeker" title="Owns a Solana Seeker phone"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M10.5 18.5h3"/></svg>Seeker</span>' : "") +   //MC 2026-10-15
      (P.x ? '<a class="pp-x" href="https://x.com/' + esc(P.x) + '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.8 7.8L23 22h-6.2l-4.8-6.3L6.4 22H3.3l7.3-8.3L1 2h6.3l4.4 5.8L18.9 2Z"/></svg><span data-i18n-skip>@' + esc(P.x) + '</span></a>' : "") +
      //MC 2026-10-13 flaunt chips: only holders who switched them on in their own profile show these
      (P.flaunt && P.flaunt.shy != null ? '<span class="pp-flaunt" data-i18n-skip>\u25C8 ' + fmt(P.flaunt.shy) + ' $SHY</span>' : "") +
      (P.flaunt && P.flaunt.koban != null ? '<span class="pp-flaunt kb" data-i18n-skip><i class="kb-coin"></i>' + fmt(P.flaunt.koban) + '</span>' : "");
    // Profile Studio: the banner, nameplate, page effect and accent the player picked
    var pg = P.page || {}, L = window.ShyLook, seed = parseInt(P.tag || "1", 16) || 7;
    root.className = root.className.replace(/\s*pga-[a-z]+/g, "") + (L ? L.page(pg) : "");
    //MC 2026-10-10 the banner's moving layer, and the picture in its Studio frame and seal
    var head = '<section class="pp-head ' + (L ? L.head(pg) : "") + '">' + (L ? (L.layers ? L.layers(pg, seed) : L.fx(pg, seed)) : "") + (L && L.avatar ? L.avatar(pg, face(P)) : face(P)) +
      '<div class="pp-id"><span class="pp-k">' + (P.holder ? "Verified $SHY holder" : "Shilluminati player") + '</span><h1 class="pp-name' + (L ? L.name(pg) : "") + '" data-i18n-skip>' + esc(P.name) + '</h1>' +
      (pg.motto ? '<p class="pp-motto" dir="auto" data-i18n-skip>' + esc(pg.motto) + '</p>' : "") +
      (chips ? '<div class="pp-chips">' + chips + '</div>' : "") +
      '<p class="pp-meta">' + (P.online ? '<span class="pp-on"><i class="fr-on"></i>Online now</span>' : "") + '<span>Playing since <span data-i18n-skip>' + date(P.since || P.last) + '</span></span>' + (P.last ? '<span>Last played <span data-i18n-skip>' + ago(P.last) + '</span></span>' : "") + (pg.visits != null ? '<span class="pp-visits">' + (pg.visits === 1 ? "1 visit" : fmt(pg.visits) + " visits") + '</span>' : "") + '</p>' +
      '<div class="pp-cta">' + (mine ? '<a class="btn btn-line" href="/profile">Edit your profile</a>' : (P.online ? '<a class="btn btn-mint" href="/play?challenge=' + esc(P.tag) + '" data-fr-invite="' + esc(P.tag) + '">Invite to a live match</a>' : "") + '<a class="btn btn-red" href="/play?friend=' + esc(P.tag) + '" data-pp-fr>Challenge <span data-i18n-skip>' + esc(P.name) + '</span></a>') +
      '<a class="btn btn-line" href="https://x.com/intent/tweet?text=' + encodeURIComponent((mine ? "My Shilluminati Online record: " : (P.x ? "@" + P.x : P.name) + " on Shilluminati Online: ") + fmt(s.points) + " pts, " + fmt(s.wins) + " wins. Think you can beat it? @ShyOnSol_ $SHY\n" + url) + '" target="_blank" rel="noopener">Share on X</a>' +
      '<button class="btn btn-line" data-pp-copy="' + esc(url) + '">Copy link</button></div></div>' +
      '<div class="pp-medal"><small>All-time rank</small><b>' + (P.ranks.all.rank ? "#" + fmt(P.ranks.all.rank) : "–") + '</b><span>' + fmt(s.points) + ' pts</span></div></section>' + stampsBar(P, mine);

    var tiles = '<section class="pp-tiles">' +
      tile("Win rate", wr + "%", fmt(s.wins) + " wins in " + fmt(s.games) + " games", "hot") +
      tile("Best game", s.best + ' <small>Regions</small>', "Most Regions held at the end") +
      tile("Live record", '<span class="pp-rec">' + fmt(s.live.w) + "–" + fmt(Math.max(0, s.live.g - s.live.w)) + '</span>', "Live board " + rank(P.ranks.live)) +
      tile("This week", fmt(s.week) + ' <small>pts</small>', "Weekly " + rank(P.ranks.week)) +
      (P.rank ? tile("Ranked · Season " + P.season, '<span class="rank-b r-' + esc(P.rank.tier) + ' pp-rank">' + esc(P.rank.name) + '</span> ' + fmt(P.rank.rp) + ' <small>RP</small>', fmt(P.rank.w) + " wins in " + fmt(P.rank.n) + " ranked matches") : tile("Badges", fmt(s.badges), "Earned in play")) +
      tile("Best streak", fmt(s.streak) + ' <small>days</small>', "Days in a row with a game") + '</section>';

    //MC 2026-10-11 alt is "Latest win" (a dictionary key) instead of "<name>'s latest win", which could never be translated
    var card = P.card ? '<section class="pp-card pp-win"><div class="pp-h"><h2>Latest win</h2><a href="s/' + esc(P.card) + '">Open →</a></div><a class="pp-shot" href="s/' + esc(P.card) + '"><img src="api/share.php?i=' + esc(P.card) + '" alt="Latest win" loading="lazy"></a></section>' : "";
    var mastered = P.mastered && P.mastered.length ? '<section class="pp-card pp-mast"><div class="pp-h"><h2>Signature cards</h2><span>Most played</span></div><div class="pp-cards">' +
      P.mastered.map(function (c) {
        return '<div class="pp-c"><span class="cf' + (c.fin ? " vf-" + esc(c.fin) : "") + '"><img src="assets/cards/' + esc(c.id) + '.webp' + AV + '" alt="" loading="lazy"></span><b>' + esc(c.name) + '</b><small><span>' + esc(c.lvName) + '</span> · <span>' + fmt(c.plays) + ' plays</span></small>' + (c.fin ? '<em class="pp-fin f-' + esc(c.fin) + '">' + FIN_N[c.fin] + '</em>' : "") + '</div>';
      }).join("") + '</div></section>' : "";

    var c = P.col, col = "";
    if (c) {
      var fins = ["gold", "crimson", "neon", "holo", "shadow"].map(function (f) { return '<div class="pf-fin f-' + f + (c.by[f] ? " on" : "") + '"><i class="fd fd-' + f + (c.by[f] ? " on" : "") + '" aria-hidden="true"></i><small>' + FIN_N[f] + '</small><b>' + fmt(c.by[f] || 0) + '</b></div>'; }).join("");
      var badges = c.sets.map(function (x) { return '<span class="pf-set f-' + x.fin + '">🏆 <span>' + KIND_N[x.kind] + ' set</span> · <span>' + FIN_N[x.fin] + '</span></span>'; });
      if (c.full) badges.push('<span class="pf-set f-all">✨ <span>' + (c.full === 1 ? "1 card with every finish" : fmt(c.full) + " cards with every finish") + '</span></span>');
      col = '<section class="pp-card pf-col"><div class="pp-h"><h2>Collection</h2><span>Level ' + c.lv + '</span></div><p class="pf-col-n"><b>' + fmt(c.n) + '</b> <span>finishes owned across ' + fmt(c.cards) + ' cards</span></p><div class="pf-fins">' + fins + '</div>' +
        (badges.length ? '<div class="pf-sets">' + badges.join("") + '</div>' : "") + '</section>';
    }
    var games = '<section class="pp-card"><div class="pp-h"><h2>Recent games</h2></div>' + (P.games.length ? '<ul class="pf-games">' + P.games.map(function (g) {
      return '<li class="r-' + esc(g.r) + '"><span class="pf-res">' + (RES[g.r] || "") + '</span><span class="pf-mode">' + (MODE[g.m] || esc(g.m)) + '</span><span class="pf-reg">' + g.g + ' Regions</span><b>+' + fmt(g.p) + '</b><small>' + ago(g.t) + '</small></li>';
    }).join("") + '</ul>' : '<p class="pf-empty">No recent games to show.</p>') + '</section>';

    var cta = '<section class="pp-join"><div><span class="pp-k">Shilluminati Online</span><h2>' + (mine ? "Climb higher." : "Think you can beat <span data-i18n-skip>" + esc(P.name) + "</span>?") + '</h2><p>The free world-domination card game of the $SHY community. Play in your browser, no sign-up.</p></div>' +
      '<a class="btn btn-red" href="/play">Play free</a></section>';

    var show = pg.show && pg.show.length ? '<section class="pp-card pp-show"><div class="pp-h"><h2>Showcase</h2><span>Picked by <span data-i18n-skip>' + esc(P.name) + '</span></span></div><div class="pp-showcards">' +
      pg.show.map(function (c) {
        return '<figure class="pp-sc k-' + esc(c.kind) + '"><span class="cf' + (c.fin ? " vf-" + esc(c.fin) : "") + '"><img src="assets/cards/' + esc(c.id) + '.webp' + AV + '" alt="" loading="lazy"></span><figcaption><b>' + esc(c.name) + '</b>' + (c.fin ? '<em class="pp-fin f-' + esc(c.fin) + '">' + FIN_N[c.fin] + '</em>' : "") + (c.plays ? '<small>' + fmt(c.plays) + ' plays</small>' : "") + '</figcaption></figure>';
      }).join("") + '</div></section>' : "";
    var pwHtml = power(s);
    //MC 2026-10-15 trophies on Solana: each one minted to the player's wallet links to it on Solscan
    var tro = P.trophies && P.trophies.length ? '<section class="pp-card pp-tro"><div class="pp-h"><h2>Trophies</h2><span>On Solana</span></div><div class="pp-tro-l">' + P.trophies.map(function (t) {
      var inner = '<img src="assets/art/trophy/' + esc(t.kind) + '.png' + AV + '" alt="" loading="lazy" width="96" height="96"><b>' + esc(t.name) + '</b>' + (t.what ? '<small>' + esc(t.what) + '</small>' : "") + '<em>' + (t.mint ? "Minted" : "Minting soon") + '</em>';
      return t.mint ? '<a class="pp-tro-i" href="https://solscan.io/token/' + esc(t.mint) + '" target="_blank" rel="noopener">' + inner + '</a>' : '<span class="pp-tro-i">' + inner + '</span>';
    }).join("") + '</div></section>' : "";
    root.innerHTML = head + vault(P, mine) + rankCard(P) + pwHtml + tiles + tro + show + '<div class="pp-two">' + (card || "") + (mastered || "") + '</div>' + col + games + cta;
    vaultMount(P, mine);
    if (!card && !mastered) { var two = root.querySelector(".pp-two"); if (two) two.remove(); }
    else if (!card || !mastered) root.querySelector(".pp-two").classList.add("one");
    if (!mine) friendBtn(P);
  }

  //MC 2026-10-11 signed-in visitors (a player name on this device) get the right button next to Share: "Challenge to a
  //   Duel" for a friend (friends.js starts it, the same as Duel in the Friends panel), "Add friend" or "Accept friend
  //   request" otherwise. It replaces the "Challenge <name>" link in place, so the row doesn't grow. Guests and anything
  //   that goes wrong keep that link, which still opens the add-friend sheet on the Play page.
  function signedIn() { var p = store("shy-lb-pid"), k = store("shy-lb-key"); return /^[a-f0-9]{16}$/.test(p) && /^[a-f0-9]{32}$/.test(k) && store("shy-lb-name") ? { pid: p, key: k } : null; }
  function frPost(body) {
    var m = signedIn(); if (!m) return Promise.reject();
    return fetch("/api/friends.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: m.pid, key: m.key }, body)) }).then(function (r) { return r.json(); });
  }
  function frDraw(tag, w) {
    var el = root.querySelector("[data-pp-fr]"); if (!el) return;
    var b = document.createElement("button"); b.type = "button"; b.setAttribute("data-pp-fr", w.friend ? "duel" : w.pending ? "sent" : "add");
    if (w.friend) { b.className = "btn btn-red pp-duel"; b.setAttribute("data-fr-duel", tag); b.innerHTML = '<span aria-hidden="true">⚔️</span> Challenge to a Duel'; b.title = "Same deal for both of you, one shot each"; }
    else if (w.pending) { b.className = "btn btn-line"; b.disabled = true; b.textContent = "Friend request sent"; }
    else { b.className = "btn btn-red"; b.setAttribute("data-pp-add", tag); b.textContent = w.asked ? "Accept friend request" : "Add friend"; }
    el.replaceWith(b);
  }
  function friendBtn(P) {
    if (!signedIn() || !/^[a-f0-9]{6}$/.test(P.tag || "")) return;
    frPost({ a: "who", id: P.tag }).then(function (w) { if (w && w.ok && !w.self) frDraw(P.tag, w); }).catch(function () {});
  }
  root.addEventListener("click", function (e) {
    var b = e.target.closest("[data-pp-add]"); if (!b || b.disabled) return;
    var tag = b.getAttribute("data-pp-add"); b.disabled = true;
    var say = function (t) { var p = root.querySelector(".pp-frmsg"); if (!p) { p = document.createElement("p"); p.className = "pp-frmsg"; p.setAttribute("role", "status"); var c = root.querySelector(".pp-cta"); if (c) c.after(p); } p.textContent = t; };   // the button may already be swapped out
    frPost({ a: "add", who: tag }).then(function (j) {
      if (j && j.ok) { frDraw(tag, { friend: !!j.friends, pending: !j.friends }); say(j.friends ? "You're friends now. Challenge them to a Duel any time." : "Friend request sent. You can Duel once they accept."); }
      else { b.disabled = false; say((j && j.error) || "Something went wrong. Try again."); }
    }).catch(function () { b.disabled = false; say("Couldn't reach the site. Check your connection."); });
  });

  // stamps visitors leave on a page: one a day each, and never on your own
  var STAMPS = [["respect", "🙇", "Respect"], ["gg", "⚔️", "GG"], ["fire", "🔥", "On fire"], ["legend", "👑", "Legend"]];
  function today() { return new Date().toISOString().slice(0, 10); }
  //MC 2026-10-15 the Shadow Vault: the Shytoshi Shadows in a holder's wallet, near the top of their page. One Shadow
  //   lives on the stage (Living Shadows, living.js: it floats, tilts under the pointer or finger, motes rise in its Aura),
  //   with its traits and its own record: every game anyone has played as it. The rest wait in a strip below; tap one,
  //   swipe the stage or use the arrow keys to bring the next one up. The page glows in the Aura of the Shadow on stage.
  var AURA_C = { cyan: "#4cc9f0", crimson: "#ff3b5c", lightning: "#ffe066", money: "#f2c35b", btc: "#f7931a", none: "#a78bfa" };
  var AURA_N = { cyan: "Electric Cyan", crimson: "Crimson Glow", lightning: "Lightning Aura", money: "Money Aura", btc: "BTC Aura", none: "No Aura" };
  function vault(P, mine) {
    var L = P.shadows || [];
    if (!L.length) return "";
    var first = 0; L.forEach(function (x, i) { if (String(x.n) === String(P.avatar)) first = i; });
    var strip = L.length > 1 ? '<div class="sv-strip" role="tablist" aria-label="Shadows">' + L.map(function (x, i) {
      return '<button type="button" class="sv-t" role="tab" data-pv-i="' + i + '" style="--sv-c:' + (AURA_C[x.aura] || AURA_C.none) + '" aria-label="Shadow #' + esc(x.n) + '">' +
        '<span class="sv-ti">' + (x.img ? '<img src="' + esc(x.img) + '" alt="" loading="lazy" onerror="this.remove()">' : "") + '</span><b data-i18n-skip>#' + esc(x.n) + '</b>' +
        (String(x.n) === String(P.avatar) ? '<i class="sv-eq" title="Plays as this Shadow">★</i>' : "") + '</button>';
    }).join("") + '</div>' : "";
    return '<section class="pp-card sv" data-pv data-first="' + first + '" tabindex="-1" aria-label="The Shadow Vault"><i class="sv-glow" aria-hidden="true"></i>' +
      '<div class="pp-h"><h2>The Shadow Vault</h2><span><span data-i18n-skip>' + fmt(L.length) + '</span> <span>' + (L.length === 1 ? "Shytoshi Shadow" : "Shytoshi Shadows") + '</span> · <span>on Solana</span></span></div>' +
      '<div class="sv-stage">' + (L.length > 1 ? '<button type="button" class="sv-nav sv-prev" data-pv-step="-1" aria-label="Previous Shadow">&lsaquo;</button>' : "") +
      '<div class="sv-hero" data-pv-hero></div><div class="sv-info" data-pv-info aria-live="polite"></div>' +
      (L.length > 1 ? '<button type="button" class="sv-nav sv-next" data-pv-step="1" aria-label="Next Shadow">&rsaquo;</button>' : "") + '</div>' + strip +
      (mine ? '<p class="sv-own"><span>Your Shadows, straight from your wallet.</span> <a href="/profile">Pick which one you play as</a></p>' : "") + '</section>';
  }
  function vaultMount(P, mine) {
    var box = root.querySelector("[data-pv]"); if (!box) return;
    var L = P.shadows, at = -1;
    function show(i, dir) {
      i = (i + L.length) % L.length; if (i === at) return; at = i;
      var x = L[i], c = AURA_C[x.aura] || AURA_C.none, wr = x.g ? Math.round(x.w / x.g * 100) : 0, eq = String(x.n) === String(P.avatar);
      box.style.setProperty("--sv-c", c);
      var hero = box.querySelector("[data-pv-hero]");
      hero.innerHTML = window.ShyLiving && x.img ? ShyLiving.html(x.img, { aura: x.aura, cls: "enter", size: matchMedia("(max-width:640px)").matches ? "min(62vw,230px)" : "250px", alt: "Shytoshi Shadow #" + x.n, fb: "assets/art/masks/unbound.svg" + AV })
        : '<img class="sv-flat" src="' + esc(x.img || "assets/art/masks/unbound.svg" + AV) + '" alt="Shytoshi Shadow #' + esc(x.n) + '">';
      hero.dataset.dir = dir || 0;
      var tiles = [[fmt(x.g), "Games"], [fmt(x.w), "Wins"], [x.g ? wr + "%" : "–", "Win rate"], [x.best ? x.best + "" : "–", "Best game"], [x.lg ? fmt(x.lw) + "–" + fmt(Math.max(0, x.lg - x.lw)) : "–", "Live"], [fmt(x.pts), "Points"]];
      box.querySelector("[data-pv-info]").innerHTML = '<span class="sv-k">Shytoshi Shadow</span><h3 data-i18n-skip>#' + esc(x.n) + '</h3>' +
        '<div class="sv-chips"><span class="sv-chip sv-au"><i></i><span>' + esc(x.auraName || AURA_N[x.aura] || "Aura") + '</span></span>' +
        (x.rank ? '<span class="sv-chip"><small>Rarity</small> <b data-i18n-skip>' + esc(String(x.rank).replace(/^#?/, "#")) + '</b></span>' : "") +
        (eq ? '<span class="sv-chip sv-on">★ <span>Plays as this Shadow</span></span>' : "") + '</div>' +
        '<div class="sv-stats">' + tiles.map(function (t) { return '<div><b>' + t[0] + '</b><small>' + t[1] + '</small></div>'; }).join("") + '</div>' +
        '<p class="sv-note">' + (x.g ? "Every game played as this Shadow, by anyone who has held it." : "No games played as this Shadow yet. Its record starts with the first one.") + '</p>' +
        (x.asset ? '<a class="sv-link" href="https://solscan.io/token/' + esc(x.asset) + '" target="_blank" rel="noopener">See it on Solana ↗</a>' : "");
      box.querySelectorAll(".sv-t").forEach(function (b) { var on = +b.dataset.pvI === i; b.classList.toggle("on", on); b.setAttribute("aria-selected", on ? "true" : "false"); if (on && b.scrollIntoView && box.dataset.ready) { var st = b.parentNode; st.scrollTo({ left: b.offsetLeft - st.clientWidth / 2 + b.clientWidth / 2, behavior: "smooth" }); } });
    }
    box.addEventListener("click", function (e) {
      var t = e.target.closest("[data-pv-i]"); if (t) { show(+t.dataset.pvI, +t.dataset.pvI > at ? 1 : -1); return; }
      var s = e.target.closest("[data-pv-step]"); if (s) show(at + +s.dataset.pvStep, +s.dataset.pvStep);
    });
    box.addEventListener("keydown", function (e) { if (L.length < 2) return; if (e.key === "ArrowRight") { e.preventDefault(); show(at + 1, 1); } else if (e.key === "ArrowLeft") { e.preventDefault(); show(at - 1, -1); } });
    var sx = null, hero = box.querySelector("[data-pv-hero]");
    hero.addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; }, { passive: true });
    hero.addEventListener("touchend", function (e) { if (sx == null || L.length < 2) return; var dx = e.changedTouches[0].clientX - sx; sx = null; if (Math.abs(dx) > 45) show(at + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1); }, { passive: true });
    show(+box.dataset.first || 0, 0);
    box.dataset.ready = "1";
  }
  function stampsBar(P, mine) {
    var c = P.stamps || {}, total = 0, done = store("shy-stamp-" + P.tag), doneKind = done.slice(0, 10) === today() ? done.slice(11) : "";
    STAMPS.forEach(function (x) { total += c[x[0]] || 0; });
    var me = store("shy-lb-pid");
    return '<section class="pp-stamps" data-pp-stamps="' + esc(P.tag) + '"><div class="pp-st-l"><b>' + (mine ? "Stamps on your page" : doneKind ? "Thanks for the stamp" : "Leave a stamp") + '</b><small>' + (mine ? fmt(total) + (total === 1 ? " stamp from visitors" : " stamps from visitors") : !me ? "Play a game first, then you can leave stamps." : doneKind ? "Come back tomorrow for another." : "One a day. They stay on the page.") + '</small></div><div class="pp-st-b">' +
      STAMPS.map(function (x) { return '<button type="button" class="pp-st' + (doneKind === x[0] ? " on" : "") + '" data-stamp="' + x[0] + '"' + (mine || doneKind || !me ? " disabled" : "") + ' title="' + x[2] + '" aria-label="' + x[2] + ': ' + fmt(c[x[0]] || 0) + '"><i aria-hidden="true">' + x[1] + '</i><span>' + x[2] + '</span><b>' + fmt(c[x[0]] || 0) + '</b></button>'; }).join("") + '</div></section>';
  }
  root.addEventListener("click", async function (e) {
    var st = e.target.closest("[data-stamp]"); if (!st || st.disabled) return;
    var box = st.closest("[data-pp-stamps]"), tag = box.dataset.ppStamps;
    box.querySelectorAll("[data-stamp]").forEach(function (b) { b.disabled = true; });
    try {
      var r = await fetch("api/player.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "stamp", pid: store("shy-lb-pid"), key: store("shy-lb-key"), to: tag, s: st.dataset.stamp }) });
      var j = await r.json();
      if (j.stamps) { try { localStorage.setItem("shy-stamp-" + tag, today() + ":" + (j.mine || st.dataset.stamp)); } catch (x) {} }
      if (window.SHY_PLAYER && j.stamps) window.SHY_PLAYER.stamps = j.stamps;
      var P = window.SHY_PLAYER || {}; P.stamps = j.stamps || P.stamps; P.tag = tag;
      box.outerHTML = stampsBar(P, false);
      if (!j.ok && j.error) { var m = document.querySelector("[data-pp-stamps] small"); if (m) m.textContent = j.error; }
    } catch (x) { box.querySelectorAll("[data-stamp]").forEach(function (b) { b.disabled = false; }); }
  });
  root.addEventListener("click", function (e) {
    var b = e.target.closest("[data-pp-copy]"); if (!b) return;
    var done = function () { var t = b.textContent; b.textContent = "Link copied"; setTimeout(function () { b.textContent = t; }, 1600); };
    if (navigator.clipboard) navigator.clipboard.writeText(b.dataset.ppCopy).then(done, done); else done();
  });

  //MC 2026-10-11 the space held for the player card (see .pp-wait in style.css) is let go once something is drawn
  new MutationObserver(function (m, o) { root.classList.remove("pp-wait"); o.disconnect(); }).observe(root, { childList: true });
  if (window.SHY_PLAYER) { render(window.SHY_PLAYER); return; }
  var n = new URLSearchParams(location.search).get("n");
  //MC 2026-10-11 /player with no name is only a pointer to the boards: kept out of search results, and the breadcrumb no longer ends on a bare "/"
  if (!n) { var nx = document.createElement("meta"); nx.name = "robots"; nx.content = "noindex"; document.head.appendChild(nx); var cr = document.getElementById("pp-crumb"); if (cr) { cr.removeAttribute("data-i18n-skip"); cr.textContent = "Find a player"; } }
  if (!n) { root.innerHTML = '<section class="pp-head pp-private"><div class="pp-id"><h1 class="pp-name">Find a player</h1><p class="pp-lead">Open any player from the leaderboards to see their page.</p><div class="pp-cta"><a class="btn btn-red" href="/stats">See the leaderboards</a></div></div></section>'; return; }
  fetch("api/player.php?a=get&n=" + encodeURIComponent(n)).then(function (r) { return r.json(); }).then(function (j) {
    if (j && j.ok) { window.SHY_PLAYER = j.player; render(j.player); } else root.innerHTML = '<section class="pp-head pp-private"><div class="pp-id"><h1 class="pp-name">Player not found</h1><p class="pp-lead">No player goes by that name.</p><div class="pp-cta"><a class="btn btn-red" href="/stats">See the leaderboards</a></div></div></section>';
  });
})();
