// Shy on Solana: shared behavior for every page
(() => {
  //MC 2026-10-09 no pinch zoom on iPhone. Safari ignores maximum-scale and user-scalable in the viewport tag, so its
  //   own gesture events are cancelled instead. Android honours the viewport tag; double-tap zoom is off in style.css.
  ["gesturestart", "gesturechange", "gestureend"].forEach((t) => document.addEventListener(t, (e) => e.preventDefault(), { passive: false }));
  const CA = "7d1vpt5eri79nETcL74Punhp3mGkeBgUkMdPWep6pump";
  const PAIR = "FkXXLYB169GkEMTx3r6zJ4MXFFu29AY9w9cyj77hHVhb";
  const BUY_URL = "https://dexscreener.com/solana/fkxxlyb169gkemtx3r6zj4mxffu29ay9w9cyj77hhvhb";
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const buzz = ms => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {} };

  document.querySelectorAll(".buy-link").forEach(a => { a.href = BUY_URL; a.target = "_blank"; a.rel = "noopener"; });
  //MC 2026-10-11 a small dot on Release notes (phone menu and footer) and on the menu buttons while there's a release this
  //   browser hasn't opened the notes for. The links carry the newest version (data-rel-new, from build.py); opening
  //   /updates marks it read. A first visit marks it read too, since nothing is "new" to someone who just arrived. Runs
  //   before the first-visit flag (shy-fv) is set below, which is how a first visit is told apart.
  (() => {
    try {
      const links = document.querySelectorAll("[data-rel-new]"), v = links.length ? links[0].getAttribute("data-rel-new") : "";
      if (!v) return;
      const seen = localStorage.getItem("shy-rel-seen");
      if (/^\/updates(\.html)?\/?$/.test(location.pathname) || (!seen && !localStorage.getItem("shy-fv"))) { localStorage.setItem("shy-rel-seen", v); return; }
      if (seen === v) return;
      // screen readers hear "New" from one hidden line (aria-describedby); text inside the link would change the
      // sentence the translations look up, and "Release notes" would stay English in every other language
      const d = document.createElement("span"); d.id = "rel-new-d"; d.hidden = true; d.textContent = "New"; document.body.appendChild(d);
      links.forEach(a => { a.classList.add("rel-new"); a.setAttribute("aria-describedby", "rel-new-d"); });
      document.querySelectorAll("[data-open-menu]").forEach(b => b.classList.add("rel-new"));
    } catch (e) {}
  })();
  // first visit of this browser, for the team's player funnel: just the game's random id and where the visit came from
  (() => {
    try {
      if (localStorage.getItem("shy-fv")) return;
      let pid = localStorage.getItem("shy-lb-pid");
      if (!pid) { const a = new Uint8Array(8); crypto.getRandomValues(a); pid = Array.from(a, b => b.toString(16).padStart(2, "0")).join(""); localStorage.setItem("shy-lb-pid", pid); }
      const q = new URLSearchParams(location.search), ref = (document.referrer && new URL(document.referrer).hostname) || "";
      const src = q.get("utm_source") || q.get("ref") || (q.get("friend") ? "invite" : q.get("tgapp") ? "telegram-app" : "") ||
        (/(^|\.)(x|twitter|t)\.(com|co)$/.test(ref) ? "x" : /t\.me|telegram/.test(ref) ? "telegram" : /google|bing|duckduckgo|yahoo/.test(ref) ? "search" :
         /dexscreener/.test(ref) ? "dexscreener" : /shyonsol/.test(ref) || !ref ? "direct" : ref.replace(/^www\./, ""));
      localStorage.setItem("shy-fv", "1");
      fetch("/api/funnel.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, src: src }), keepalive: true }).catch(() => {});
    } catch (e) {}
  })();
  //MC 2026-10-10 where players are, for When and where on the Stats page: the browser's time zone name and language
  //   (Europe/Berlin, de). Sent when they change or once a week, and only kept once this browser has finished a game, so
  //   a visitor who hasn't played yet is asked again at most every half hour. No location, no IP (see api/where.php).
  (() => {
    try {
      const pid = localStorage.getItem("shy-lb-pid") || "";
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
      if (!/^[a-f0-9]{16}$/.test(pid) || !tz) return;
      const lang = String(navigator.language || "").slice(0, 12), key = tz + "|" + lang;
      let last = {}; try { last = JSON.parse(localStorage.getItem("shy-where") || "{}") || {}; } catch (e) {}
      if (last.k === key && Date.now() - (last.t || 0) < 7 * 86400000) return;
      if (last.try && Date.now() - last.try < 30 * 60000) return;
      setTimeout(() => {
        fetch("/api/where.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, tz: tz, lang: lang }) })
          .then(r => r.json()).then(j => { try { localStorage.setItem("shy-where", JSON.stringify(j && j.saved ? { k: key, t: Date.now() } : { try: Date.now() })); } catch (e) {} }).catch(() => {});
      }, 2500);
    } catch (e) {}
  })();
  //MC 2026-10-09 one pager for every long list (Profile Studio, Dojo Shop grids and history, profile history, release
  //notes). slice() cuts a list to one page; html() draws the buttons, each carrying data-pg="key:page" for the list's own
  //click handler. Long runs of pages fold into "..." so the bar never gets wider than a phone.
  window.ShyPager = {
    slice: function (list, per, page) {
      var pages = Math.max(1, Math.ceil(list.length / per));
      page = Math.min(Math.max(1, page || 1), pages);
      return { items: list.slice((page - 1) * per, page * per), page: page, pages: pages, per: per, total: list.length };
    },
    html: function (p, key) {
      if (!p || p.pages < 2) return "";
      var h = '<nav class="pgr" aria-label="Pages"><button type="button" class="pgr-b" data-pg="' + key + ':' + (p.page - 1) + '"' + (p.page < 2 ? " disabled" : "") + ' aria-label="Previous page">&#8249;</button>';
      for (var i = 1; i <= p.pages; i++) {
        if (p.pages > 7 && i > 1 && i < p.pages && Math.abs(i - p.page) > 1) { if (i === 2 || i === p.pages - 1) h += '<span class="pgr-gap" aria-hidden="true">&#8230;</span>'; continue; }
        h += '<button type="button" class="pgr-n' + (i === p.page ? ' on" aria-current="page"' : '"') + ' data-pg="' + key + ':' + i + '">' + i + '</button>';
      }
      return h + '<button type="button" class="pgr-b" data-pg="' + key + ':' + (p.page + 1) + '"' + (p.page >= p.pages ? " disabled" : "") + ' aria-label="Next page">&#8250;</button></nav>';
    },
    // reads a click: {key, page} when it hit a pager button for this key prefix, else null
    hit: function (e, prefix) {
      var b = e.target.closest && e.target.closest("[data-pg]");
      if (!b || b.disabled) return null;
      var v = b.getAttribute("data-pg"), i = v.lastIndexOf(":");
      if (v.indexOf(prefix) !== 0) return null;
      return { key: v.slice(0, i), page: parseInt(v.slice(i + 1), 10) || 1 };
    }
  };
  const yr = document.getElementById("yr");
  if (yr) yr.textContent = new Date().getFullYear();

  // active page in menus and tab bar
  const here = location.pathname.split("/").pop().replace(/\.html$/, "") || "index";
  document.querySelectorAll("[data-page]").forEach(a => { if (a.dataset.page === here) a.classList.add("active"); });

  // drawer
  //MC 2026-10-09 drawer now takes focus when it opens, closes on Esc, keeps Tab inside, and hands focus back to
  //the button that opened it. Before this focus stayed on More and Tab walked through the header under the drawer.
  const drawer = document.getElementById("drawer");
  let drawerFrom = null;
  const menuBtns = document.querySelectorAll("[data-open-menu]");
  const openDrawer = (e) => {
    if (!drawer) return;
    drawerFrom = e && e.currentTarget;
    drawer.classList.add("open"); buzz(8);
    menuBtns.forEach(b => b.setAttribute("aria-expanded", "true"));
    //MC 2026-10-09 a single focus() at 60ms missed: the drawer is still visibility:hidden for the first frames of its slide-in.
    //Retry a few times until it takes
    let tries = 0;
    const grab = () => { const c = document.getElementById("close"); if (!c || !drawer.classList.contains("open")) return; c.focus({ preventScroll: true }); if (document.activeElement !== c && ++tries < 10) setTimeout(grab, 50); };
    setTimeout(grab, 30);
  };
  const closeDrawer = () => {
    if (!drawer || !drawer.classList.contains("open")) return;
    drawer.classList.remove("open");
    menuBtns.forEach(b => b.setAttribute("aria-expanded", "false"));
    if (drawerFrom && drawerFrom.focus && drawerFrom.offsetParent) drawerFrom.focus({ preventScroll: true });
    drawerFrom = null;
  };
  menuBtns.forEach(b => { b.setAttribute("aria-expanded", "false"); b.addEventListener("click", openDrawer); });
  const closeBtn = document.getElementById("close");
  if (closeBtn) closeBtn.onclick = closeDrawer;
  //MC 2026-10-09 capture phase on window so this runs before i18n.js's Esc; an open language list closes first
  addEventListener("keydown", e => {
    if (!drawer || !drawer.classList.contains("open")) return;
    if (e.key === "Escape") {
      if (drawer.querySelector(".lp-list:not([hidden])")) return;
      closeDrawer(); return;
    }
    if (e.key === "Tab") {
      const f = [...drawer.querySelectorAll("a[href],button:not([disabled]),input,select,textarea")].filter(x => x.offsetParent);
      if (!f.length) return;
      if (!drawer.contains(document.activeElement)) { e.preventDefault(); f[0].focus(); return; }
      if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
    }
  }, true);

  // tap feedback: a press and a ripple from where you touched, on every link and button
  var nav = document.createElement("div");
  nav.className = "navload"; document.body.appendChild(nav);
  document.addEventListener("pointerdown", function (e) {
    var el = e.target.closest("a, button, .tile, summary, [data-tap]");
    if (!el || el.disabled || el.closest(".g-map-svg, .g-hand")) return;
    //MC 2026-10-09 measure first, then change classes. The old order added "pressed" and then measured, which made the
    //   browser redo the whole page's styles and layout inside every tap (up to 160 ms on a phone on the Play page).
    var r = el.getBoundingClientRect(), stat = getComputedStyle(el).position === "static";
    el.classList.add("pressed");
    var up = function () { el.classList.remove("pressed"); removeEventListener("pointerup", up); removeEventListener("pointercancel", up); };
    addEventListener("pointerup", up); addEventListener("pointercancel", up);
    if (reduce || el.closest(".tabbar .buy")) return;
    var size = Math.max(r.width, r.height) * 2.2;
    if (stat) el.style.position = "relative";
    el.classList.add("has-ripple");
    var rip = document.createElement("span");
    rip.className = "fx-ripple";
    rip.style.width = rip.style.height = size + "px";
    rip.style.left = (e.clientX - r.left - size / 2) + "px";
    rip.style.top = (e.clientY - r.top - size / 2) + "px";
    el.appendChild(rip);
    setTimeout(function () { rip.remove(); }, 650);
  }, { passive: true });

  // page changes: the tapped tab lights up, a loading bar runs, and the page dims instead of vanishing
  document.querySelectorAll('a[href^="/"]:not([href^="//"]):not([href^="/api"]):not([href^="/admin"]):not([href^="/s/"]), a[href$=".html"], a[href*=".html#"]').forEach(function (a) {
    a.addEventListener("click", function (e) {
      if (e.metaKey || e.ctrlKey || a.target === "_blank") return;
      var url = new URL(a.href, location.href);
      if (url.pathname === location.pathname && url.hash) return;
      e.preventDefault();
      var bar = a.closest(".tabbar, .menu, .drawer nav");
      if (bar) {
        bar.querySelectorAll(".active").forEach(function (x) { x.classList.remove("active"); });
        a.classList.add("active", "tapped");
      }
      buzz(8);
      document.body.classList.add("leaving");
      setTimeout(function () { location.href = a.href; }, 160);
    });
  });
  addEventListener("pageshow", function () {
    document.body.classList.remove("leaving");
    document.querySelectorAll(".tapped").forEach(function (x) { x.classList.remove("tapped"); });
  });

  // copy contract address
  const toast = document.getElementById("toast");
  document.querySelectorAll("[data-copy]").forEach(btn => {
    btn.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(CA); }
      catch (e) {
        const t = document.createElement("textarea");
        t.value = CA; document.body.appendChild(t); t.select();
        document.execCommand("copy"); t.remove();
      }
      buzz(18);
      //MC 2026-10-09 skip the tap ripple span; "Copied" was going into the ripple and vanished with it
      const label = btn.querySelector("span:not(.fx-ripple)");
      const prev = label ? label.textContent : btn.textContent;
      label ? (label.textContent = "Copied") : (btn.textContent = "Copied");
      btn.classList.add("ok");
      if (toast) toast.classList.add("show");
      setTimeout(() => { label ? (label.textContent = prev) : (btn.textContent = prev); btn.classList.remove("ok"); if (toast) toast.classList.remove("show"); }, 1800);
    });
  });

  // live market data
  if (document.querySelector("[data-stat]")) {
    const usd = n => {
      n = Number(n); if (!isFinite(n)) return "--";
      if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
      if (n >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
      if (n >= 1e3) return "$" + (n / 1e3).toFixed(1) + "K";
      return "$" + n.toFixed(2);
    };
    const px = n => { n = Number(n); if (!isFinite(n)) return "--"; return n >= 1 ? "$" + n.toFixed(4) : "$" + n.toPrecision(4); };
    const set = (k, v, cls) => document.querySelectorAll('[data-stat="' + k + '"]').forEach(el => {
      el.textContent = v; el.classList.remove("up", "down"); if (cls) el.classList.add(cls);
    });
    const load = async () => {
      try {
        //MC 2026-10-11 from api/market.php (cached on the server, the same numbers the Token page shows), not DexScreener
        // straight from the browser: ad blockers and privacy browsers block that, and the ticker sat at "..." on every page
        const r = await fetch("/api/market.php?a=pair");
        const j = await r.json();
        const p = j && j.ok && j.pair;
        if (!p) return;
        const ch = Number(p.change) || 0;
        set("price", px(p.price));
        set("change", (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%", ch >= 0 ? "up" : "down");
        set("mcap", usd(p.mcap));
        set("liq", usd(p.liq));
        set("vol", usd(p.vol));
      } catch (e) { /* the chart embed still shows data */ }
    };
    load();
    setInterval(function () { if (!document.hidden) load(); }, 30000);
  }

  // hero: random minted Shadow every load
  const core = document.getElementById("hero-core");
  if (core) {
    const img = document.getElementById("hero-nft");
    const tag = document.getElementById("hero-tag");
    const list = (core.dataset.nfts || "").split("|").filter(Boolean).map(x => { const i = x.indexOf(":"); return { n: x.slice(0, i), src: x.slice(i + 1) }; });
    if (list.length && img) {
      const pick = list[Math.floor(Math.random() * list.length)];
      const probe = new Image();
      img.classList.add("loading");
      probe.onload = () => { img.src = pick.src; img.classList.remove("loading"); if (tag) tag.textContent = "Shadow #" + pick.n; };
      probe.onerror = () => { img.src = core.dataset.fallback; img.classList.remove("loading"); };
      probe.src = pick.src;
    }
  }


  // home: top players teaser
  const mini = document.getElementById("lb-mini");
  if (mini) {
    fetch("api/lb.php?a=top", { cache: "no-store" }).then(r => r.json()).then(j => {
      if (!j.ok || !j.top.length) { mini.innerHTML = "<li><span>1</span>Your name here<em>Be first</em></li>"; return; }
      const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
      mini.innerHTML = j.top.slice(0, 3).map((r, i) => "<li><span>" + (i + 1) + '</span><span class="hm-av">' + (r.img ? '<img src="' + esc(r.img) + '" alt="" loading="lazy">' : esc((r.name || "?").slice(0, 1).toUpperCase())) + '</span><span class="hm-nm">' + esc(r.name) + (r.x ? ' <i class="xb mini" title="Verified with X">\u{1D54F}</i>' : "") + "</span><em>" + r.points.toLocaleString("en-US") + " pts</em></li>").join("");
    }).catch(() => { mini.remove(); });
  }

  // home: how many games of each kind were played today
  const modes = document.querySelectorAll("[data-hs]");
  if (modes.length) {
    fetch("api/stats.php?a=all", { cache: "no-store" }).then(r => r.json()).then(j => {
      const d = j.ok && j.days && j.days[j.days.length - 1];
      if (!d) return;
      modes.forEach(el => { const n = d[el.dataset.hs] || 0; if (n) el.textContent = n.toLocaleString("en-US") + " today"; });
      const tot = document.querySelector("[data-hs-total]");
      if (tot && d.g) tot.textContent = d.g.toLocaleString("en-US") + " games played today";
    }).catch(() => {});
  }

  // home: Shytoshi's words, one at a time
  const q = document.getElementById("hm-q");
  if (q) {
    const all = q.querySelectorAll(".hm-qt"), n = document.getElementById("hm-q-n");
    let at = 0;
    document.addEventListener("click", e => {
      const b = e.target.closest("[data-q]"); if (!b) return;
      all[at].classList.remove("on");
      at = (at + Number(b.dataset.q) + all.length) % all.length;
      all[at].classList.add("on");
      if (n) n.textContent = (at + 1) + " / " + all.length;
    });
  }

  // NFT page: each Shadow's career record
  var recs = document.getElementById("shadow-records");
  if (recs) {
    var e2 = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
    fetch("api/holder.php?a=shadows", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.ok || !j.top.length) { recs.innerHTML = '<li class="lb-empty">No Shadow has a record yet. Be the first.</li>'; return; }
      recs.innerHTML = j.top.slice(0, 10).map(function (r, k) {
        return '<li class="holder ' + (k < 3 ? "podium p" + (k + 1) : "") + '"><span class="lb-rank">' + (k + 1) + '</span><span class="lb-av">' + (r.img ? '<img src="' + e2(r.img) + '" alt="" loading="lazy">' : "") + '</span>' +
          //MC 2026-10-10 each Shadow's rarity, labelled so it isn't read as its place on this list or a game rank
          '<span class="lb-name"><b>Shadow #' + e2(r.n) + '</b><small>' + r.wins + (r.wins === 1 ? " win" : " wins") + " &middot; " + r.games + (r.games === 1 ? " game" : " games") +
          (parseInt(String(r.rank || "").replace(/[^0-9]/g, ""), 10) > 0 ? ' &middot; <span class="sh-rar-in" title="Rarity rank among all 1,335 Shytoshi Shadows. 1 is the rarest.">Rarity #' + parseInt(String(r.rank).replace(/[^0-9]/g, ""), 10).toLocaleString("en-US") + ' of 1,335</span>' : "") + '</small></span><span class="lb-pts">' + r.points.toLocaleString() + '<small>pts</small></span></li>';
      }).join("");
    }).catch(function () { recs.innerHTML = '<li class="lb-empty">Records are offline right now.</li>'; });
  }

  //MC 2026-10-09 card art is a pre-drawn WebP now; if one ever fails to load, fall back to the SVG it was drawn from
  document.addEventListener("error", (e) => {
    const t = e.target;
    if (t && t.tagName === "IMG" && /\/assets\/cards\/[a-z0-9]+\.webp/.test(t.src) && !t.dataset.svgFallback) { t.dataset.svgFallback = "1"; t.src = t.src.replace(/\.webp(\?|$)/, ".svg$1"); }
  }, true);
  // scroll progress
  // moved with a transform once per frame, so scrolling never waits on layout
  const bar = document.querySelector(".progress");
  if (bar) {
    let queued = false;
    const paint = () => { queued = false; const h = document.documentElement.scrollHeight - innerHeight; bar.style.transform = "scaleX(" + (h > 0 ? Math.min(1, scrollY / h) : 0) + ")"; };
    addEventListener("scroll", () => { if (!queued) { queued = true; requestAnimationFrame(paint); } }, { passive: true });
    paint();
  }

  // swipe rows get dots on phones
  document.querySelectorAll(".swipe").forEach(track => {
    const dots = track.nextElementSibling;
    if (!dots || !dots.classList.contains("dots")) return;
    const items = [...track.children];
    dots.innerHTML = items.map(() => "<i></i>").join("");
    const marks = [...dots.children];
    const update = () => {
      const w = items[0] ? items[0].offsetWidth + 12 : 1;
      //MC 2026-10-09 abs() so the dots work in Persian too, where scrollLeft runs negative
      const i = Math.min(items.length - 1, Math.round(Math.abs(track.scrollLeft) / w));
      marks.forEach((d, k) => d.classList.toggle("on", k === i));
    };
    track.addEventListener("scroll", update, { passive: true });
    update();
  });

  // tap to flip cards
  document.querySelectorAll(".card3d").forEach(c => c.addEventListener("click", () => {
    const inner = c.querySelector(".inner");
    inner.style.transform = inner.style.transform ? "" : "rotateY(180deg)";
    buzz(8);
  }));

  // tilt NFT cards on desktop
  if (!reduce && matchMedia("(hover:hover)").matches) {
    document.querySelectorAll(".nft").forEach(c => {
      c.addEventListener("mousemove", e => {
        const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        c.style.transform = `perspective(700px) rotateY(${x * 10}deg) rotateX(${-y * 10}deg) translateY(-4px)`;
      });
      c.addEventListener("mouseleave", () => { c.style.transform = ""; });
    });
  }

  //MC 2026-10-09 sections out of view pause their animations. Spinning podium rings, halo glows and live dots kept
  //   running below the fold, and the ones that animate colours or glows cost the browser work on every frame even
  //   where nobody could see them (most noticeable on phones). They pick up again as they scroll back in.
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle("io-off", !e.isIntersecting)), { rootMargin: "200px 0px" });
    document.querySelectorAll("main section, body > section, footer").forEach((el) => { if (!el.querySelector("#game, .g-root, .game")) io.observe(el); });   // never the game itself (focus mode pins it to the screen)
  }
  // scroll reveal
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
  }), { threshold: .1 });
  document.querySelectorAll(".reveal").forEach((el, i) => { el.style.transitionDelay = (i % 4) * 70 + "ms"; io.observe(el); });

  // count up numbers
  const cio = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    const el = e.target, end = parseFloat(el.dataset.count);
    const pre = el.dataset.pre || "", suf = el.dataset.suf || "";
    let t0 = null;
    const step = ts => {
      t0 = t0 || ts;
      const k = Math.min((ts - t0) / 1400, 1), v = end * (1 - Math.pow(1 - k, 3));
      el.textContent = pre + Math.round(v).toLocaleString() + suf;
      if (k < 1) requestAnimationFrame(step);
    };
    reduce ? (el.textContent = pre + end.toLocaleString() + suf) : requestAnimationFrame(step);
    cio.unobserve(el);
  }), { threshold: .5 });
  document.querySelectorAll("[data-count]").forEach(el => cio.observe(el));

  // star field behind the hero
  const cv = document.getElementById("net");
  if (cv && !reduce) {
    const ctx = cv.getContext("2d");
    let w, h, pts = [];
    //MC 2026-10-15 the star field was the biggest cost on a phone in PageSpeed (5 s of script on a slow phone): every
    //   point is checked against every other point each frame. Phones get a third of the points, a lower resolution and
    //   20 frames a second, and it starts only after the page has drawn, so it never holds up the first paint.
    const PHONE = matchMedia("(max-width:760px), (pointer:coarse)").matches;
    const DPR = PHONE ? 1 : Math.min(devicePixelRatio || 1, 2);
    const colors = ["255,209,102", "46,240,176", "255,255,255", "255,111,216"];
    const size = () => {
      w = cv.offsetWidth; h = cv.offsetHeight;
      cv.width = w * DPR; cv.height = h * DPR; ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      const count = PHONE ? Math.min(26, Math.floor(w * h / 22000)) : Math.min(80, Math.floor(w * h / 16000));
      pts = Array.from({ length: count }, () => ({
        x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3,
        r: Math.random() * 1.8 + .6, c: colors[Math.floor(Math.random() * colors.length)]
      }));
    };
    // only animate while the hero is on screen
    let onScreen = true, running = false;
    const go = () => { if (!running && onScreen) { running = true; requestAnimationFrame(tick); } };
    new IntersectionObserver(es => { onScreen = es[0].isIntersecting; go(); }).observe(cv);
    // hold still while the page is being scrolled, and draw at 30fps otherwise (the drift is slow, so it looks the same)
    let scrolling = 0, frame = 0;
    addEventListener("scroll", () => { scrolling = performance.now(); }, { passive: true });
    const tick = () => {
      if (!onScreen) { running = false; return; }
      requestAnimationFrame(tick);
      if (performance.now() - scrolling < 180 || (PHONE ? frame++ % 3 : frame++ & 1)) return;
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        p.x += p.vx * 2; p.y += p.vy * 2;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
      }
      for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
        const a = pts[i], b = pts[j], d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 120) { ctx.strokeStyle = "rgba(" + a.c + "," + (1 - d / 120) * .22 + ")"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      }
      for (const p of pts) { ctx.fillStyle = "rgba(" + p.c + ",.9)"; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill(); }
    };
    // phones fire resize when the address bar slides during a scroll; only rebuild when the width really changes
    let lastW = 0;
    addEventListener("resize", () => { if (cv.offsetWidth !== lastW) { lastW = cv.offsetWidth; size(); } });
    const start = () => { size(); lastW = cv.offsetWidth; go(); };
    const idle = window.requestIdleCallback || (f => setTimeout(f, 300));
    if (document.readyState === "complete") idle(start, { timeout: 2000 }); else addEventListener("load", () => setTimeout(() => idle(start, { timeout: 2000 }), PHONE ? 1200 : 200), { once: true });
  }
})();

// home page: the two newest stories from the blog, read on this site
(function () {
  var box = document.getElementById("home-story");
  if (!box || !window.fetch) return;
  fetch("api/medium.php?a=list").then(function (r) { return r.json(); }).then(function (j) {
    if (!j.ok || !j.live || !j.posts || !j.posts.length) return;
    var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
    box.innerHTML = j.posts.slice(0, 2).map(function (p) {
      var d = new Date(p.date + "T12:00:00Z").toLocaleDateString(((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined, { month: "short", day: "numeric", year: "numeric" });   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
      return '<a class="tile reveal in" href="/story?p=' + encodeURIComponent(p.id) + '"><span class="status s-plan" style="margin:0 0 14px">' + d + '</span><h3>' + esc(p.title) + '</h3><p>' + esc(p.excerpt || "") + '</p><span class="more">Read the story</span></a>';
    }).join("");
  }).catch(function () {});
})();

// Header fit: longer languages (German, Russian…) can make the top menu wider than the screen.
// First drop the Mint button, then fold the menu into the ☰ button, only when it doesn't fit.
(function () {
  var root = document.documentElement, nav = document.querySelector("header .nav"), right = nav && nav.querySelector(".nav-right");
  if (!nav || !right) return;
  function over() { return nav.scrollWidth > nav.clientWidth + 1 || right.getBoundingClientRect().right > document.documentElement.clientWidth; }
  function fit() {
    root.classList.remove("nav-tight", "nav-collapse");
    if (over()) root.classList.add("nav-tight");
    if (over()) root.classList.add("nav-collapse");
  }
  var t = null;
  window.addEventListener("resize", function () { clearTimeout(t); t = setTimeout(fit, 100); });
  document.addEventListener("DOMContentLoaded", function () { setTimeout(fit, 0); });
  window.addEventListener("load", fit);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
  fit();
})();

// A link like /play#rewards: the sections above it fill in after the page loads (the game, the tournament,
// the League), which pushes the target down. Keep it in place a few times while that settles, and stop
// the moment the visitor scrolls on their own.
(function () {
  var id = location.hash.slice(1);
  if (!/^[a-z][\w-]*$/i.test(id)) return;
  var mine = false, stop = function () { mine = true; };
  ["wheel", "touchstart", "keydown", "mousedown"].forEach(function (e) { window.addEventListener(e, stop, { passive: true, once: true }); });
  [400, 1200, 2500, 4000].forEach(function (ms) {
    setTimeout(function () {
      var el = document.getElementById(id);
      if (mine || !el) return;
      if (Math.abs(el.getBoundingClientRect().top - 90) > 40) el.scrollIntoView({ block: "start" });
    }, ms);
  });
})();

//MC 2026-10-16 an Admin center button in the menu for the team (api/teamcheck.php: the profiles on the dev list), so the
//   admin is one tap away from the app on a phone's home screen too. Checked once a visit, then remembered for the tab.
(function () {
  "use strict";
  var pid = "", key = "";
  try { pid = localStorage.getItem("shy-lb-pid") || ""; key = localStorage.getItem("shy-lb-key") || ""; } catch (e) {}
  if (!/^[a-f0-9]{16}$/.test(pid) || !/^[a-f0-9]{32}$/.test(key)) return;
  function add() {
    var nav = document.querySelector("#drawer nav");
    if (!nav || nav.querySelector("[data-admin-link]")) return;
    var a = document.createElement("a");
    a.href = "/admin/"; a.setAttribute("data-admin-link", ""); a.className = "adm-link";
    a.innerHTML = '<img decoding="async" src="/assets/art/icon-admin.svg" alt="">Admin center';
    nav.insertBefore(a, nav.firstChild);   // first in the menu: only the team ever sees it
  }
  var cached = null; try { cached = JSON.parse(sessionStorage.getItem("shy-team") || "null"); } catch (e) {}
  if (cached && cached.pid === pid && Date.now() - cached.t < 3600e3) { if (cached.team) add(); return; }
  fetch("/api/teamcheck.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, key: key }) })
    .then(function (r) { return r.json(); }).then(function (j) {
      var team = !!(j && j.ok && j.team);
      try { sessionStorage.setItem("shy-team", JSON.stringify({ pid: pid, team: team, t: Date.now() })); } catch (e) {}
      if (team) add();
    }).catch(function () {});
})();
