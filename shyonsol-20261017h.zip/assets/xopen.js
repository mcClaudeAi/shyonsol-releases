// Every "Post on X" across the site and admin opens the X app on a phone. A link to x.com/intent opens the web page in
// the browser (or inside the home screen app) on iPhone, so the post sits in a browser tab instead of in X. On phones
// this catches those links and window.open calls and goes to the app (twitter://post) with the same words; if the app
// doesn't open within a moment (not installed), the X web compose opens as before and that's remembered for next time.
// Inside Telegram the post keeps going through Telegram's own link handling.
//MC 2026-10-16 first version
(function () {
  "use strict";
  if (window.ShyX) return;
  var phone = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  function isIntent(u) { return /^https?:\/\/(www\.)?(x|twitter)\.com\/intent\/(tweet|post)\b/i.test(String(u || "")); }
  function inTg() { return !!(window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData); }
  function noApp() { try { return localStorage.getItem("shy-x-noapp") === "1"; } catch (e) { return false; } }
  function appUrl(u) {
    var q; try { q = new URL(u).searchParams; } catch (e) { return ""; }
    var msg = [q.get("text") || "", q.get("url") || "", q.get("hashtags") ? q.get("hashtags").split(",").map(function (h) { return "#" + h; }).join(" ") : ""].filter(Boolean).join(" ");
    return "twitter://post?message=" + encodeURIComponent(msg);
  }
  var nativeOpen = window.open;
  // a new tab (asking for "noopener" always reports a blocked window, which would send this page away); this page goes
  // only when the tab really was blocked
  function web(u) { var w = null; try { w = nativeOpen.call(window, u, "_blank"); } catch (e) {} if (w) { try { w.opener = null; } catch (e) {} } else location.href = u; }
  function go(u) {
    if (!phone || inTg() || noApp()) return false;
    var a = appUrl(u); if (!a) return false;
    var left = false, t;
    var gone = function () { left = true; clearTimeout(t); };
    document.addEventListener("visibilitychange", function once() { if (document.hidden) { gone(); document.removeEventListener("visibilitychange", once); } });
    window.addEventListener("pagehide", gone, { once: true });
    window.addEventListener("blur", function () { setTimeout(function () { if (document.hidden) gone(); }, 300); }, { once: true });
    t = setTimeout(function () { if (!left && !document.hidden) { try { localStorage.setItem("shy-x-noapp", "1"); } catch (e) {} web(u); } }, 1600);
    window.__shyXLast = a;   // what was sent to the app (read by the tests)
    if (!window.__shyXTest) location.href = a;   // the tests' browser has no X app and drops the page on twitter://
    return true;
  }
  // links
  document.addEventListener("click", function (e) {
    var l = e.target.closest && e.target.closest("a[href]");
    if (!l || !isIntent(l.href) || e.defaultPrevented || e.metaKey || e.ctrlKey) return;
    if (go(l.href)) e.preventDefault();
  }, true);
  // window.open("https://x.com/intent/...") from the game, profile and shop code
  window.open = function (u) {
    if (isIntent(u) && go(String(u))) return { closed: false, close: function () {}, focus: function () {} };
    return nativeOpen.apply(window, arguments);
  };
  window.ShyX = { open: function (u) { if (!go(u)) web(u); }, isIntent: isIntent };
})();
