<?php
//MC 2026-10-14 Admin > Hype posts for X: ten ready-to-post hype options about the game, each built around real cards
//   from the deck with the card art previewed under it, leaning toward the newest cards. Every option tags
//   @ShytoshiKusama plus accounts from an editable Solana gaming list, and carries the site's usual cashtags. Refresh
//   deals ten new ones and the card previews follow the posts. Posting happens by hand through the X compose window
//   (the intent link), the same way the admin's other X buttons work: a person reads it, can edit it, and sends it
//   from the brand account they are signed into. Nothing here posts by itself, and nothing is billed to the X app.
if (!defined('SHY_API')) exit;

// the accounts every hype post tags: Shytoshi always, plus a rotating pick from this list the team can edit
const MKT_ALWAYS = '@ShytoshiKusama';
const MKT_DEFAULT_TAGS = "@solana\n@SolanaMobile\n@MagicEden\n@SuperteamDAO\n@StarAtlas\n@Backpack";

function mkt_tag_list() {
    $raw = (string)(eco_settings()['mkt_x_tags'] ?? MKT_DEFAULT_TAGS);
    $out = [];
    foreach (preg_split('/[\r\n,]+/', $raw) as $t) { $t = '@' . ltrim(trim($t), '@'); if (preg_match('/^@[A-Za-z0-9_]{1,15}$/', $t) && strcasecmp($t, MKT_ALWAYS) !== 0) $out[] = $t; }
    return array_slice(array_values(array_unique($out)), 0, 40);
}

// the deck in play order with each card's effect line, read from the game the way the Shilluminati page reads it.
// Later in the list is newer, so the picker can lean toward the newest art and season cards.
function mkt_cards() {
    static $cards = null;
    if ($cards !== null) return $cards;
    $cards = [];
    $src = (string)@file_get_contents(dirname(__DIR__) . '/assets/game.js');
    if ($src === '' || !preg_match('/var DECK = \[(.*?)\];/s', $src, $m)) return $cards;
    foreach (array_unique(preg_match_all('/"(\w+)"/', $m[1], $ids) ? $ids[1] : []) as $id) {
        if (!preg_match('/^\s*' . preg_quote($id, '/') . ':\s*\{ no: \d+, name: "((?:[^"\\\\]|\\\\.)*)", kind: "(\w+)", target: "\w+", text: "((?:[^"\\\\]|\\\\.)*)" \}/m', $src, $c)) continue;
        $cards[] = ['id' => $id, 'name' => stripcslashes($c[1]), 'kind' => $c[2], 'text' => stripcslashes($c[3])];
    }
    return $cards;
}

// one card, leaning toward the newest third of the deck ("newer cards reflect in the posts")
function mkt_pick($cards, &$used) {
    $n = count($cards);
    for ($try = 0; $try < 12; $try++) {
        $i = random_int(0, 99) < 55 ? random_int(max(0, $n - 20), $n - 1) : random_int(0, $n - 1);
        if (!isset($used[$cards[$i]['id']])) { $used[$cards[$i]['id']] = 1; return $cards[$i]; }
    }
    return $cards[random_int(0, $n - 1)];
}

// ten hype options. Each: ['text' => the whole post, 'cards' => card ids its previews show, 'len' => characters]
//MC 2026-10-14 premium pass: card-centric posts now link to /c/<card>, whose unfurl is that card's own promo image
//   (api/share.php?c=), so the card named in the post is the card X shows. Copy tightened to read like a person.
function mkt_hype($n = 10) {
    $cards = mkt_cards();
    if (count($cards) < 5) return [];
    $site = rtrim(TG_SITE, '/');
    $play = $site . '/play';
    $cl = fn($c) => $site . '/c/' . $c['id'];
    $st = load(STATS); $today = (int)($st['d'][gmdate('Y-m-d')]['g'] ?? 0);
    $pres = load(DATA_DIR . '/presence.php'); $on = 0; $now = time();
    foreach ($pres as $ts) if ($now - (int)$ts < 150) $on++;
    // every shape stays short so the tags always fit under 280
    $shapes = [
        fn($c, $c2) => $c['name'] . ' just ended a thirty minute alliance in one turn. 71 hand-inked Chaos cards, free in your browser. ' . $cl($c),
        fn($c, $c2) => 'The art alone is worth the tap. ' . $c['name'] . ', inked like an old woodblock print. ' . $cl($c),
        fn($c, $c2) => 'POV: the leader is two Regions from winning and you are holding ' . $c['name'] . '. ' . $cl($c),
        fn($c, $c2) => 'No wallet. No download. Just ' . $c['name'] . ' and 70 other ways to ruin a friendship. ' . $cl($c),
        fn($c, $c2) => $c['name'] . ': "' . $c['text'] . '" Imagine eating that on turn two. ' . $cl($c),
        fn($c, $c2) => 'Some cards win games. ' . $c['name'] . ' ends them. ' . $cl($c),
        fn($c, $c2) => 'A million simulated games went into balancing this deck, so you can lose fair and square to ' . $c['name'] . '. ' . $cl($c),
        fn($c, $c2) => 'Hold ' . $c['name'] . ' long enough and someone always walks into it. ' . $cl($c),
        fn($c, $c2) => 'The Shogun has taken Koban off better players than you. Bring ' . $c['name'] . ' and prove it wrong. ' . $cl($c),
        fn($c, $c2) => $c['name'] . ' and ' . $c2['name'] . ' in the same hand should be illegal. It is not. ' . $cl($c),
        fn($c, $c2) => 'We burned half the supply on day one and kept all the chaos. ' . $c['name'] . ' lives here: ' . $cl($c),
        fn($c, $c2) => 'Your first game is ninety seconds away. Draw ' . $c['name'] . ' and thank us later. ' . $cl($c),
        fn($c, $c2) => 'Tag someone who would main ' . $c['name'] . '. ' . $cl($c),
        fn($c, $c2) => 'Finishes are cosmetic and ' . $c['name'] . ' hits the same for everyone. No pay to win, ever. ' . $cl($c),
        fn($c, $c2) => 'Every season, $SHY holders vote one new card into the deck. The original 71 never change. Meet ' . $c['name'] . ': ' . $cl($c),
        fn($c, $c2) => '40 Regions. 71 Chaos cards. One winner. ' . $c['name'] . ' decides more games than it should. ' . $cl($c),
    ];
    if ($today >= 25) $shapes[] = fn($c, $c2) => number_format($today) . ' games played today and the tables are still hungry. ' . $c['name'] . ' is in someone\'s hand right now. ' . $play;
    if ($on >= 3) $shapes[] = fn($c, $c2) => $on . ' players on the site right now. Pull up a seat before ' . $c['name'] . ' finds you. ' . $play;
    $tags = mkt_tag_list();
    $casht = trim((string)(eco_settings()['x_tags'] ?? '')) ?: '$SHY #Solana #SolanaGaming';
    shuffle($shapes);
    $out = []; $used = [];
    for ($i = 0; $i < $n; $i++) {
        $c = mkt_pick($cards, $used); $c2 = mkt_pick($cards, $used);
        $shape = $shapes[$i % count($shapes)];
        $body = $shape($c, $c2);
        $withBoth = strpos($body, $c2['name']) !== false;
        // the tags: Shytoshi on every post, plus one or two from the gaming list
        $pick = $tags; shuffle($pick);
        $line = trim(MKT_ALWAYS . ' ' . implode(' ', array_slice($pick, 0, random_int(1, min(2, max(1, count($pick)))))));
        $text = $body . "\n\n" . $line . ' ' . $casht;
        if (mb_strlen($text) > 275) $text = $body . "\n\n" . MKT_ALWAYS . ' ' . $casht;   // a long card line: keep it legal, keep Shytoshi
        $out[] = ['text' => $text, 'cards' => $withBoth ? [$c['id'], $c2['id']] : [$c['id']], 'len' => mb_strlen($text)];
    }
    return $out;
}

function mkt_actions($do) {
    if ($do !== 'hype-tags') return;
    if (!can('players', 2)) go('players', 'Your access can see this page but not change it.');
    $out = [];
    //MC 2026-10-14 one handle per line (or comma), never split on spaces: "not a handle" must fail, not become @not and @a
    foreach (preg_split('/[\r\n,]+/', (string)($_POST['mkt_tags'] ?? '')) as $t) { $t = '@' . ltrim(trim($t), '@'); if (preg_match('/^@[A-Za-z0-9_]{1,15}$/', $t) && strcasecmp($t, MKT_ALWAYS) !== 0) $out[] = $t; }
    with_lock(function () use ($out) { $s = is_file(ECOSET) ? load(ECOSET) : []; $s['mkt_x_tags'] = implode("\n", array_slice(array_values(array_unique($out)), 0, 40)); save(ECOSET, $s); });
    audit('hype-tags', ['n' => count($out)]);
    go('players', 'Saved. New posts pick from ' . count($out) . ' accounts, and ' . MKT_ALWAYS . ' is on every one.');
}

function mkt_section() {
    $posts = mkt_hype(10);
    $tags = mkt_tag_list();
    echo '<h2>Hype posts for X <small>ten fresh options, posted by hand</small></h2>';
    echo '<p class="muted">Marketing on the fly: ten hype posts about the game, each built around real cards from the deck (the newest cards show up most), with the card art previewed under it so you see what the post is talking about. Every post tags <b>' . h(MKT_ALWAYS) . '</b> plus one or two accounts from your Solana gaming list. <b>Open in X</b> puts the post in the X compose window on whatever account you are signed into, so you read it, tweak it if you like, and send it yourself. X treats repeated automated @mentions as spam, so posting by hand is also the safe way to tag.</p>';
    echo '<div class="bar"><a class="btn" href="?p=hype&r=' . random_int(1000, 999999) . '#hype-list">&#8635; Refresh the ten</a><span class="muted">New posts, new cards, new tags every time.</span></div>';
    echo '<div class="mkt-grid" id="hype-list">';
    foreach ($posts as $i => $p) {
        $cid = 'hype' . $i;
        echo '<div class="mkt-c"><div class="mkt-cards">';
        //MC 2026-10-14 the preview is the exact image X will unfurl for the post's /c/ link (api/share.php?c=), so
        //   what you see here is pixel for pixel what the feed shows
        foreach ($p['cards'] as $card) echo '<a href="../c/' . h($card) . '" target="_blank" rel="noopener" title="Open the landing link"><img src="../api/share.php?c=' . h($card) . '" alt="" loading="lazy"></a>';
        echo '</div><pre class="mkt-t" id="' . $cid . '">' . h($p['text']) . '</pre>';
        echo '<div class="mkt-b"><a class="btn" href="' . h(x_intent($p['text'])) . '" target="_blank" rel="noopener">Open in X &#8599;</a>' .
            '<button type="button" class="ghost" data-copy="' . $cid . '">Copy</button><small class="muted">' . (int)$p['len'] . ' / 280</small></div></div>';
    }
    echo '</div>';
    echo '<h3>Solana gaming accounts to tag</h3><p class="muted">One per line. Each post picks one or two at random, and ' . h(MKT_ALWAYS) . ' rides on every post whatever this list says.</p>';
    echo '<form method="post" class="bar" style="align-items:flex-start"><input type="hidden" name="csrf" value="' . h(csrf()) . '">' .
        '<textarea name="mkt_tags" rows="4" style="min-width:min(420px,100%)" placeholder="@account">' . h(implode("\n", $tags)) . '</textarea>' .
        '<button name="do" value="hype-tags">Save the list</button></form>';
}

//MC 2026-10-15 Release posts for X: every release with its own share card (api/share.php?rl=) and a post ready to send.
//   The link in the post is /r/<version> (api/relpage.php), which X unfurls as that release's card and which takes
//   readers to the release in the notes. Mark each one posted to keep track of what is still to go out.
const REL_POSTED = DATA_DIR . '/x-rel-posted.php';   // version => [ts, by]
const REL_PER_PAGE = 24;
function rel_all() {
    $f = dirname(__DIR__) . '/api/lib/releases-all.php';
    return is_file($f) ? (array)(require $f) : [];
}
// X counts every link as 23 characters, whatever its length
function rel_xlen($text) { return mb_strlen(preg_replace('~https?://\S+~', str_repeat('x', 23), $text)); }
function rel_post_text($r) {
    $site = rtrim(TG_SITE, '/');
    $link = $site . '/r/' . rawurlencode($r['v']);
    $casht = trim((string)(eco_settings()['x_tags'] ?? '')) ?: '$SHY #Solana #SolanaGaming';
    $tail = "\n\n" . $link . "\n\n" . MKT_ALWAYS . ' ' . $casht;
    $head = 'New on Shilluminati Online: ' . $r['title'];
    $sum = trim((string)$r['summary']);
    $text = $head . "\n\n" . $sum . $tail;
    if (rel_xlen($text) > 280) {   // too long: the summary's first sentence, then shorter still
        $first = preg_split('/(?<=[.!?])\s+/', $sum)[0];
        $text = $head . "\n\n" . $first . $tail;
        while (rel_xlen($text) > 280 && mb_strlen($first) > 20) { $first = rtrim(mb_substr($first, 0, mb_strlen($first) - 10), ' ,.;:') . '...'; $text = $head . "\n\n" . $first . $tail; }
    }
    return $text;
}
function rel_actions($do) {
    if ($do !== 'rel-posted') return;
    if (!can('players', 2)) go('players', 'Your access can see this page but not change it.');
    $v = (string)($_POST['v'] ?? '');
    if (!preg_match('/^[a-z0-9]{2,24}$/', $v)) go('players', 'That release was not found.');
    $on = !empty($_POST['on']);
    $by = (string)(me()['name'] ?? '');
    with_lock(function () use ($v, $on, $by) { $p = is_file(REL_POSTED) ? load(REL_POSTED) : []; if ($on) $p[$v] = [time(), $by]; else unset($p[$v]); save(REL_POSTED, $p); });
    audit('rel-posted', ['v' => $v, 'on' => $on]);
    go('players', $on ? 'Marked as posted.' : 'Marked as not posted yet.', 'rel-' . $v);
}
function rel_section() {
    $all = rel_all();
    $posted = is_file(REL_POSTED) ? load(REL_POSTED) : [];
    $f = ($_GET['f'] ?? '') === 'todo' ? 'todo' : 'all';
    $list = $f === 'todo' ? array_values(array_filter($all, fn($r) => !isset($posted[$r['v']]))) : $all;
    $pages = max(1, (int)ceil(count($list) / REL_PER_PAGE));
    $pg = max(1, min($pages, (int)($_GET['pg'] ?? 1)));
    $todo = count(array_filter($all, fn($r) => !isset($posted[$r['v']])));
    $canEdit = can('players', 2);
    echo '<h2 id="rel-posts">Release posts for X <small>' . count($all) . ' releases, ' . $todo . ' not posted yet</small></h2>';
    echo '<p class="muted">Every release, newest first, with its own share card and a post ready to send. The link in each post opens as that card on X, and anyone who taps it lands on that release in the release notes. Edit the words if you like, then <b>Post on X</b> opens it in the X compose window on whatever account you are signed into. <b>Download card</b> saves the picture if you would rather attach it yourself. Tick <b>Posted</b> to keep track of what has gone out.</p>';
    $q = fn($ff, $p) => '?p=xrel' . ($ff === 'todo' ? '&f=todo' : '') . ($p > 1 ? '&pg=' . $p : '') . '#rel-posts';
    echo '<div class="bar rel-filter"><a class="btn' . ($f === 'all' ? '' : ' ghost') . '" href="' . h($q('all', 1)) . '">All releases</a><a class="btn' . ($f === 'todo' ? '' : ' ghost') . '" href="' . h($q('todo', 1)) . '">Not posted yet (' . $todo . ')</a></div>';
    if (!$list) { echo '<p class="muted">Every release has been posted.</p>'; return; }
    echo '<div class="mkt-grid rel-grid">';
    foreach (array_slice($list, ($pg - 1) * REL_PER_PAGE, REL_PER_PAGE) as $r) {
        $v = (string)$r['v']; $id = 'rel-' . $v; $text = rel_post_text($r); $done = $posted[$v] ?? null;
        $ts = strtotime((string)$r['date']);
        echo '<div class="mkt-c rel-c' . ($done ? ' is-posted' : '') . '" id="' . h($id) . '">';
        echo '<div class="mkt-cards"><a href="../r/' . h(rawurlencode($v)) . '" target="_blank" rel="noopener" title="Open the link X will show"><img src="../api/share.php?rl=' . h(rawurlencode($v)) . '" alt="" loading="lazy"></a></div>';
        echo '<div class="rel-meta"><b>' . h($r['title']) . '</b><small>' . h($ts ? date('M j, Y', $ts) : $r['date']) . ' &middot; ' . h($v) . ' &middot; ' . count((array)$r['items']) . (count((array)$r['items']) === 1 ? ' change' : ' changes') . '</small>' .
            ($done ? '<span class="rel-done">Posted ' . h(date('M j', (int)$done[0])) . ($done[1] !== '' ? ' by ' . h($done[1]) : '') . '</span>' : '') . '</div>';
        echo '<textarea class="mkt-t rel-t" id="' . h($id) . '-t" rows="7" spellcheck="true">' . h($text) . '</textarea>';
        echo '<div class="mkt-b rel-b"><a class="btn" data-rel-x="' . h($id) . '-t" href="' . h(x_intent($text)) . '" target="_blank" rel="noopener">Post on X &#8599;</a>' .
            '<button type="button" class="ghost" data-rel-copy="' . h($id) . '-t">Copy</button>' .
            '<a class="btn ghost" href="../api/share.php?rl=' . h(rawurlencode($v)) . '&amp;dl=1">Download card</a>' .
            '<small class="muted rel-n" data-rel-n="' . h($id) . '-t">' . rel_xlen($text) . ' / 280</small></div>';
        if ($canEdit) echo '<form method="post" class="rel-p"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="_p" value="xrel"><input type="hidden" name="v" value="' . h($v) . '">' .
            ($done ? '<input type="hidden" name="on" value=""><button name="do" value="rel-posted" class="ghost">&#10003; Posted (undo)</button>' : '<input type="hidden" name="on" value="1"><button name="do" value="rel-posted" class="ghost">Mark as posted</button>') . '</form>';
        echo '</div>';
    }
    echo '</div>';
    if ($pages > 1) {
        echo '<div class="bar rel-pager">';
        for ($i = 1; $i <= $pages; $i++) echo '<a class="btn' . ($i === $pg ? '' : ' ghost') . '" href="' . h($q($f, $i)) . '">' . $i . '</a>';
        echo '</div>';
    }
    // the words can be edited: keep the Post on X link and the count in step, and copy what is in the box
    echo '<script>(function(){function len(t){return t.replace(/https?:\/\/\S+/g,"xxxxxxxxxxxxxxxxxxxxxxx").length}' .
        'document.addEventListener("input",function(e){var t=e.target;if(!t.classList||!t.classList.contains("rel-t"))return;var a=document.querySelector("[data-rel-x=\""+t.id+"\"]"),n=document.querySelector("[data-rel-n=\""+t.id+"\"]");' .
        'if(a)a.href="https://x.com/intent/post?text="+encodeURIComponent(t.value);if(n){var l=len(t.value);n.textContent=l+" / 280";n.classList.toggle("over",l>280)}});' .
        'document.addEventListener("click",function(e){var c=e.target.closest("[data-rel-copy]");if(!c)return;var t=document.getElementById(c.dataset.relCopy);if(!t)return;' .
        'var done=function(){c.textContent="Copied";setTimeout(function(){c.textContent="Copy"},1600)};if(navigator.clipboard)navigator.clipboard.writeText(t.value).then(done,function(){t.select();document.execCommand("copy");done()});else{t.select();document.execCommand("copy");done()}});})();</script>';
}
