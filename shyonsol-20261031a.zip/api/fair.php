<?php
// Provably fair, the public side (see fairlib.php).
// GET ?a=daily            Daily seals: the week ahead sealed, past days opened (proof and seed)
// GET ?a=live&id=<id>     one finished live match: its seal, seed, salt, seats and season cards
// GET ?a=recent           the latest finished live matches, newest first (for the Fair page)
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/fairlib.php';

$a = (string)($_GET['a'] ?? 'daily');
if ($a === 'daily') {
    header('Cache-Control: public, max-age=300');
    out(['ok' => true] + fair_daily_list(14));
}
if ($a === 'live') {
    $id = strtolower((string)($_GET['id'] ?? ''));
    if (!preg_match('/^[a-z0-9]{3,8}-\d{9,11}$/', $id)) fail('bad match');
    $r = load(FAIR_LIVE)[$id] ?? null;
    if (!$r) fail('That match is not in the record. Matches are kept for 45 days.', 404);
    header('Cache-Control: public, max-age=3600');
    out(['ok' => true, 'id' => $id] + $r);
}
if ($a === 'recent') {
    header('Cache-Control: public, max-age=60');
    $all = load(FAIR_LIVE);
    uasort($all, fn($x, $y) => $y['end'] <=> $x['end']);
    $rows = [];
    foreach (array_slice($all, 0, 20, true) as $id => $r) $rows[] = ['id' => $id, 'end' => $r['end'], 'boss' => $r['boss'], 'elite' => !empty($r['elite']), 'seal' => $r['seal'],
        'names' => array_map(fn($n) => preg_replace('/ \(bot\)$/', '', $n), $r['names'])];
    out(['ok' => true, 'rows' => $rows]);
}
fail('unknown action');
