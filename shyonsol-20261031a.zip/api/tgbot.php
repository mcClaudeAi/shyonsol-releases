<?php
// The Telegram bot's ears: Telegram sends chat messages here (a webhook set from the admin).
// The bot answers a few commands (/start, /play, /daily, /leaderboard, /friends, /me, /notify, /stats), links players' Telegram
// accounts to their game profiles, and remembers which chats it's in so the admin can pick the chat.
// Everything else in the chat is ignored straight away.
header('Content-Type: application/json; charset=utf-8');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/tglb.php';
if (!defined('DAILY')) define('DAILY', DATA_DIR . '/daily.php');

$c = tg_cfg();
// only Telegram knows the secret set with the webhook
if (($c['hook_secret'] ?? '') === '' || !hash_equals($c['hook_secret'], (string)($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? ''))) { http_response_code(403); exit; }
$u = json_decode(file_get_contents('php://input'), true) ?: [];
$S = TG_SITE;

// ---------------------------------------------------------------- notification switches (buttons under /notify)
function notify_view($tgid) {
    $l = tgl(); $x = $l['u'][(string)$tgid] ?? null;
    if (!$x) return null;
    $n = tg_notes($x);
    $rows = [];
    foreach (TG_NOTES as $k => $label) $rows[] = [['text' => ($n[$k] ? '✅ ' : '▫️ ') . $label, 'callback_data' => 'n:' . $k]];
    $rows[] = [['text' => '🎴 Play now', 'web_app' => ['url' => TG_SITE . '/play?tgapp=1']]];
    return ['text' => "🔔 <b>What should I message you about?</b>\nTap to switch each one on or off.\n\n<b>Streak reminders</b>: an evening nudge when your daily streak is about to end.\n<b>New Daily Challenge</b>: a morning nudge with today's Daily, if you haven't played it yet.\n<b>Tournaments</b>: check-in, your table and the results.\n<b>Friends, challenges and Duels</b>: friend requests, a friend calling you into a live match, and Duels to play or results.", 'kb' => ['inline_keyboard' => $rows]];
}
$cb = $u['callback_query'] ?? null;
if ($cb) {
    if (tglb_callback($cb, $c['token'])) exit;   // leaderboard buttons
    $from = (string)($cb['from']['id'] ?? '');
    $data = (string)($cb['data'] ?? '');
    $note = '';
    if (preg_match('/^n:(\w+)$/', $data, $m) && isset(TG_NOTES[$m[1]])) {
        $note = with_lock(function () use ($from, $m) {
            $l = tgl();
            if (!isset($l['u'][$from])) return 'Link your game profile first: open the game from the button below.';
            $n = tg_notes($l['u'][$from]);
            $n[$m[1]] = !$n[$m[1]];
            $l['u'][$from]['n'] = $n; $l['u'][$from]['nset'] = true; $l['u'][$from]['dm'] = true;
            save(TGLINKS, $l);
            return TG_NOTES[$m[1]] . ($n[$m[1]] ? ' on' : ' off');
        });
    }
    tg_api($c['token'], 'answerCallbackQuery', ['callback_query_id' => $cb['id'], 'text' => $note]);
    $v = notify_view($from);
    if ($v && isset($cb['message']['message_id'])) {
        echo json_encode(['method' => 'editMessageText', 'chat_id' => $cb['message']['chat']['id'], 'message_id' => $cb['message']['message_id'], 'text' => $v['text'], 'parse_mode' => 'HTML', 'reply_markup' => $v['kb']]);
        exit;
    }
    echo '{}'; exit;
}

$msg = $u['message'] ?? $u['channel_post'] ?? null;
$chat = $msg['chat'] ?? ($u['my_chat_member']['chat'] ?? null);
$private = ($chat['type'] ?? '') === 'private';
$fromId = (string)($msg['from']['id'] ?? '');

// remember the chats the bot is in, for Find my chat
if ($chat && !$private) {
    $id = (string)$chat['id'];
    $title = mb_substr((string)($chat['title'] ?? ($chat['username'] ?? 'Chat')), 0, 80);
    if (($c['seen'][$id] ?? null) !== $title) {
        $lf = fopen(DATA_DIR . '/tg-lock.php', 'c'); flock($lf, LOCK_EX);
        $c2 = tg_cfg(); $c2['seen'][$id] = $title; $c2['seen'] = array_slice($c2['seen'], -20, null, true); save(TGCFG, $c2);
        flock($lf, LOCK_UN); fclose($lf);
    }
}
//MC 2026-10-09 the bot was removed from a partner group: stop posting joint events there
if ($chat && !$private && in_array(($u['my_chat_member']['new_chat_member']['status'] ?? ''), ['left', 'kicked'], true)) { tp_unlink_chat((string)$chat['id']); echo '{}'; exit; }
// someone who blocked the bot and came back can be messaged again
if ($private && ($u['my_chat_member']['new_chat_member']['status'] ?? '') !== '') {
    $st = $u['my_chat_member']['new_chat_member']['status'];
    $who = (string)($u['my_chat_member']['from']['id'] ?? '');
    with_lock(function () use ($who, $st) { $l = tgl(); if (isset($l['u'][$who])) { $l['u'][$who]['dm'] = $st === 'member'; save(TGLINKS, $l); } });
    echo '{}'; exit;
}
$text = trim((string)($msg['text'] ?? ''));
if (!$msg || $text === '' || $text[0] !== '/') { echo '{}'; exit; }
$parts = preg_split('/\s+/', $text, 2);
$cmd = strtolower(preg_replace('/@\w+$/', '', $parts[0]));
$arg = trim((string)($parts[1] ?? ''));
if ($cmd === '/lb') $cmd = '/leaderboard';
if ($cmd === '/friends') { $cmd = '/leaderboard'; $arg = 'friends ' . $arg; }
if ($cmd === '/boss') $cmd = '/shilluminatiboss';   //MC 2026-10-12 the Shogun; Telegram passes /shilluminatiBoss as typed, lowercased above
if ($cmd === '/elite') $cmd = '/shilluminatielite';   //MC 2026-10-30 Shogun Elite
if (!in_array($cmd, ['/start', '/help', '/play', '/shilluminatiboss', '/shilluminatielite', '/daily', '/top', '/league', '/leaderboard', '/stats', '/me', '/notify', '/partner'], true)) { echo '{}'; exit; }

// one answer per command per chat every 20 seconds (5 in a private chat), so nobody can make the bot spam
$key = 'cmd:' . ($chat['id'] ?? 0) . ':' . $cmd;
$ok = with_lock(function () use ($key, $private) { $l = load(LIMITS); $ok = rate_ok($l, $key, 1, $private ? 5 : 20); save(LIMITS, $l); return $ok; });
if (!$ok) { echo '{}'; exit; }

$medal = ['🥇', '🥈', '🥉', '4.', '5.'];
$kb = null;
$out = '';
// private chats get a button that opens the game inside Telegram; groups get a link button
$playKb = $private ? tg_kb_private() : tg_kb('🎴 Play now');

if ($cmd === '/start' && $private && preg_match('/^link_([A-Z0-9]{10})$/', $arg, $m)) {
    // the code from "Link Telegram" on the website
    $pid = with_lock(fn() => tg_take_code($m[1]));
    if (!$pid) $out = "That link has expired. On the website, open your profile and press <b>Link Telegram</b> again.";
    else {
        $name = with_lock(function () use ($pid, $msg) { tg_link_set((string)$msg['from']['id'], $pid, $msg['from'], true); return load(PLAYERS)[$pid]['name'] ?? ''; });
        $out = "✅ <b>Linked</b>" . ($name !== '' ? " to <b>" . tg_h($name) . "</b>" : '') . ".\nOpening the game from Telegram now signs you in as you, and I can remind you before your daily streak runs out.\n\nSend /notify to choose what I message you about, or /me for your numbers.";
        $kb = tg_kb_private();
    }
} elseif ($cmd === '/start' || $cmd === '/help') {
    $out = "👋 <b>Shilluminati Online</b>\nI post live matches, the Daily and Weekly League results and big Dojo Shop pickups to the \$SHY chat.\n\n"
        . "/play  play free" . ($private ? ' right here in Telegram' : '') . "\n/shilluminatiboss  take on the Shogun for Koban\n/shilluminatielite  Shogun Elite, the one that sees your hand\n/daily  today's Daily Challenge so far\n/leaderboard  every board, with prizes and your place\n/friends  you and your friends this week\n/me  your streak, Koban and League rank\n/notify  reminders I can send you\n/stats  games played today";
    if ($private && !tg_pid_of($fromId)) $out .= "\n\nOpen the game with the button below and your profile links to this Telegram account by itself.";
    $kb = $playKb;
    if ($private && $fromId !== '') with_lock(function () use ($fromId) { $l = tgl(); if (isset($l['u'][$fromId]) && empty($l['u'][$fromId]['dm'])) { $l['u'][$fromId]['dm'] = true; save(TGLINKS, $l); } });
} elseif ($cmd === '/partner') {
    //MC 2026-10-09 a partner community links its group to our joint events: /partner CODE, or /partner off to stop.
    //Only that group's admins can do it, checked with Telegram, so a random member can't sign a group up.
    if ($private) $out = "🤝 This is for partner communities. Add me to your group, then a group admin types <b>/partner CODE</b> there, with the code from the \$SHY team. I'll post your joint tournament there: the announcement, reminders and the winners.";
    else {
        $st = (string)(tg_api($c['token'], 'getChatMember', ['chat_id' => $chat['id'], 'user_id' => $fromId])['result']['status'] ?? '');
        $admin = in_array($st, ['creator', 'administrator'], true) || ($chat['type'] ?? '') === 'channel';
        if (!$admin) $out = 'Only an admin of this group can do that.';
        elseif (strtolower($arg) === 'off') $out = tp_unlink_chat((string)$chat['id']) ? "Done. I won't post joint events here anymore." : 'This group isn\'t linked to any joint event.';
        elseif (!preg_match('/^[A-Za-z0-9]{6}$/', $arg)) $out = 'Type <b>/partner</b> followed by the 6 letter code from the $SHY team, like <b>/partner K7QM2X</b>.';
        else {
            $t = tp_link_chat($arg, (string)$chat['id'], (string)($chat['title'] ?? ''));
            if (!$t) $out = "That code doesn't match an upcoming joint event. Check it with the \$SHY team.";
            else {
                $out = '✅ <b>Linked.</b> I\'ll post ' . tg_h($t['name']) . ' here: a reminder the day before and an hour before, the start and the winners. A group admin can type <b>/partner off</b> any time to stop.';
                tp_post($t, tp_intro($t), 'intro:' . $t['id']);
            }
        }
    }
} elseif ($cmd === '/shilluminatiboss') {
    //MC 2026-10-12 the Shogun: what it pays, how many have beaten it, and a button straight into a match
    require_once __DIR__ . '/bosslib.php';
    $bi = boss_info($fromId !== '' ? (string)tg_pid_of($fromId) : '');
    if (!$bi['on']) $out = '⚔️ The Shogun is resting right now. Try again later.';
    else {
        $out = "⚔️ <b>The Shogun</b>\nThe hardest bot in Shilluminati. A 1v1, you against it. It plays every move out to the end before it chooses, and it starts with " . ($bi['edge'] ? $bi['edge'] . ' extra ' . ($bi['edge'] === 1 ? 'card' : 'cards') : 'no extra cards') . ".\n\n"
            . ($bi['koban'] ? 'Beat it for <b>' . number_format($bi['koban']) . ' Koban</b>, once a ' . $bi['per'] . ".\n" : '')
            . ($bi['beaten'] ? number_format($bi['beaten']) . ($bi['beaten'] === 1 ? ' player has' : ' players have') . ' beaten it so far, ' . number_format($bi['all'][0]) . ' wins in ' . number_format($bi['all'][1]) . ' matches.' : 'Nobody has beaten it yet.');
        $kb = $private ? ['inline_keyboard' => [[['text' => '⚔️ Challenge the Shogun', 'web_app' => ['url' => $S . '/play?tgapp=1&boss=1']]]]] : tg_kb('⚔️ Challenge the Shogun', 'boss');
    }
} elseif ($cmd === '/shilluminatielite') {
    //MC 2026-10-30 Shogun Elite: the Shogun's twin that sees your hand; locked until a first win over the Shogun when the gate is on
    require_once __DIR__ . '/bosslib.php';
    $epid = $fromId !== '' ? (string)tg_pid_of($fromId) : '';
    $ei = boss_info($epid, true);
    if (!$ei['on']) $out = '👁 Shogun Elite is resting right now. Try again later.';
    else {
        $out = "👁 <b>Shogun Elite</b>\nThe Shogun's harder twin. Same brain, one difference: it sees every card in your hand, so a bluff or a held Blocker means nothing to it. The decks stay hidden from it, so it can be beaten." . ($ei['edge'] ? ' It also starts with ' . $ei['edge'] . ' extra ' . ($ei['edge'] === 1 ? 'card' : 'cards') . '.' : '') . "\n\n"
            . ($ei['koban'] ? 'Beat it for <b>' . number_format($ei['koban']) . ' Koban</b>, once a ' . $ei['per'] . ".\n" : '')
            . ($ei['gate'] ? "It only sits down with players who have beaten the Shogun once.\n" : '')
            . ($ei['beaten'] ? number_format($ei['beaten']) . ($ei['beaten'] === 1 ? ' player has' : ' players have') . ' beaten it so far, ' . number_format($ei['all'][0]) . ' wins in ' . number_format($ei['all'][1]) . ' matches.' : 'Nobody has beaten it yet.');
        $kb = $private ? ['inline_keyboard' => [[['text' => '👁 Challenge Shogun Elite', 'web_app' => ['url' => $S . '/play?tgapp=1&elite=1']]]]] : tg_kb('👁 Challenge Shogun Elite', 'elite');
    }
} elseif ($cmd === '/play') {
    $out = "🎴 <b>Shilluminati Online</b> is free, no download. Live matches, a Daily Challenge and \$SHY prizes every week.";
    $kb = $playKb;
} elseif ($cmd === '/me') {
    $pid = $fromId !== '' ? tg_pid_of($fromId) : null;
    if (!$pid) {
        $out = $private ? "Your Telegram isn't linked to a game profile yet. Open the game with the button below and it links by itself." : "Your Telegram isn't linked to a game profile yet. Message me privately and send /start to link it.";
        $kb = $private ? tg_kb_private() : (!empty($c['bot']) ? ['inline_keyboard' => [[['text' => 'Link my profile', 'url' => 'https://t.me/' . $c['bot'] . '?start=me']]]] : null);
    } else {
        [$p, $a, $rank, $total] = with_lock(function () use ($pid) {
            $players = load(PLAYERS); $eco = load(ECO);
            $rows = league_rows($players, load(HOLDERS), 'league');
            $r = 0; foreach ($rows as $i => $x) if ($x['pid'] === $pid) { $r = $i + 1; break; }
            return [$players[$pid] ?? [], eco_get($eco, $pid), $r, count($rows)];
        });
        $st = $a['st'];
        $alive = in_array($st['d'] ?? '', [today(), gmdate('Y-m-d', time() - 86400)], true);
        $out = "👤 <b>" . tg_h($p['name'] ?? 'You') . "</b>\n"
            . "🔥 Streak: " . ($alive ? (int)$st['n'] : 0) . " " . (($alive ? (int)$st['n'] : 0) === 1 ? 'day' : 'days') . ($st['d'] === today() ? ', played today' : ($alive ? ', play today to keep it' : '')) . " (best " . (int)($st['best'] ?? 0) . ")\n"
            . "🪙 Koban: " . number_format((int)$a['koban']) . "\n"
            . "🏆 League this week: " . (int)(($p['lg']['wk'] ?? '') === week_key() ? $p['lg']['pts'] : 0) . " pts" . ($rank ? ", #$rank of $total" : '') . "\n"
            . "🎴 Games: " . number_format((int)($p['games'] ?? 0)) . ", wins: " . number_format((int)($p['wins'] ?? 0));
        $kb = $playKb;
    }
} elseif ($cmd === '/notify') {
    if (!$private) { $out = "Message me privately and send /notify to pick your reminders."; $kb = !empty($c['bot']) ? ['inline_keyboard' => [[['text' => 'Open a private chat', 'url' => 'https://t.me/' . $c['bot'] . '?start=notify']]]] : null; }
    else {
        $v = notify_view($fromId);
        if (!$v) { $out = "Link your game profile first: open the game with the button below and it links by itself. Then send /notify again."; $kb = tg_kb_private(); }
        else { with_lock(function () use ($fromId) { $l = tgl(); $l['u'][$fromId]['dm'] = true; save(TGLINKS, $l); }); $out = $v['text']; $kb = $v['kb']; }
    }
} elseif ($cmd === '/daily') {
    $day = today(); $daily = load(DAILY); $players = load(PLAYERS);
    $no = (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1;
    $rows = [];
    foreach ($daily[$day] ?? [] as $pid => $d) $rows[] = ['n' => $players[$pid]['name'] ?? 'Player', 'p' => (int)$d['points'], 'g' => (int)$d['regions'], 't' => (int)$d['ts']];
    usort($rows, fn($a, $b) => [$b['p'], $a['t']] <=> [$a['p'], $b['t']]);
    $list = $rows ? implode("\n", array_map(fn($r, $i) => $medal[$i] . ' ' . tg_h($r['n']) . ': ' . $r['p'] . ' pts, ' . $r['g'] . ' Regions', array_slice($rows, 0, 5), array_keys(array_slice($rows, 0, 5)))) : 'Nobody has played it yet. Be first.';
    $out = "🗓 <b>Daily #$no</b>, " . count($rows) . ' ' . (count($rows) === 1 ? 'player' : 'players') . " so far\n\n$list\n\nSame deal for everyone, one shot a day.";
    $kb = $private ? tg_kb_private('🗓 Play the Daily') : tg_kb('🗓 Play the Daily', 'daily');
} elseif ($cmd === '/top' || $cmd === '/league' || $cmd === '/leaderboard') {
    // every board with buttons: /leaderboard daily, /leaderboard live 2 and so on pick a board and page straight away
    $w = 'league'; $pg = 1;
    foreach (preg_split('/\s+/', strtolower($arg)) as $a) {
        if (ctype_digit($a)) $pg = (int)$a;
        elseif ($a !== '') foreach (['league' => ['league', 'week', 'weekly'], 'cup' => ['cup', 'holder', 'holders'], 'season' => ['season'], 'daily' => ['daily', 'today'], 'live' => ['live'], 'all' => ['all', 'alltime', 'all-time'], 'friends' => ['friends', 'friend']] as $k => $al) if (in_array($a, $al, true)) $w = $k;
    }
    $v = tglb_view($w, $pg, $private, $fromId);
    $out = $v['text']; $kb = $v['kb'];
} else {
    $st = load(DATA_DIR . '/stats.php');
    $d = $st['d'][today()] ?? null;
    $g = $d['g'] ?? 0; $p = $d ? count($d['p']) : 0;
    $out = "📊 <b>Today so far</b>: $g " . ($g === 1 ? 'game' : 'games') . " by $p " . ($p === 1 ? 'player' : 'players') . ($d ? ' (' . $d['m']['live'] . ' live, ' . $d['m']['daily'] . ' Daily, ' . $d['m']['solo'] . ' solo)' : '') . ".\n" . tg_link('/stats', 'All the stats');
}
// answer straight in the webhook reply: no extra call to Telegram
$reply = ['method' => 'sendMessage', 'chat_id' => $chat['id'], 'text' => $out, 'parse_mode' => 'HTML', 'link_preview_options' => ['is_disabled' => true]];
if ($kb) $reply['reply_markup'] = $kb;
echo json_encode($reply);
