<?php
// Card art: swap the drawing on any card without a site update. Upload an image, set where the card should focus,
// preview it the way players see it, then publish. The live list is served to every page by api/art.php.
// Images are served from /card-art, with a safe copy in shy-data/card-art-keep that a site update can't touch.

// files, the safe copies and rebuilding: api/artlib.php (shared with the site, which heals missing images on its own)
require_once dirname(__DIR__) . '/api/artlib.php';

function art_cards() {
    static $list = null;
    if ($list !== null) return $list;
    if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
    require_once dirname(__DIR__) . '/api/engine.php';
    $list = [];
    // only cards that are in the game and have a drawing (retired or unfinished ids would show as blank tiles)
    $dir = dirname(__DIR__) . '/assets/cards/';
    // numbered like the community card list (the Card # column), and listed in that order so a number is easy to find
    // numbered in deck order, the same numbers as the Card Prompts PDF (the order of card-prompts.json)
    $nos = array_flip(array_keys(art_prompts()));
    foreach ($nos as &$v) $v++;
    unset($v);
    // season cards: the ones in play and the candidates on the ballot (a candidate that failed the balance test needs no art)
    require_once dirname(__DIR__) . '/api/cardsetlib.php';
    $season = []; foreach (cs_active() as $a) $season[$a['id']] = $a['season'];
    $next = cs_next_set(); if ($next) foreach ($next['cards'] as $sid) $season[$sid] = $next['season'];
    foreach (CARDS as $id => $c) {
        if (!is_file($dir . $id . '.svg')) continue;
        if (!empty($c['season'])) { if (isset($season[$id])) $list[$id] = ['name' => $c['name'], 'kind' => $c['kind'], 'n' => 0, 'no' => 0, 'season' => $season[$id]]; continue; }
        $list[$id] = ['name' => $c['name'], 'kind' => $c['kind'], 'n' => $c['n'], 'no' => (int)($nos[$id] ?? 0)];
    }
    // the original deck in its numbered order, then the season cards by season
    uasort($list, fn($a, $b) => [$a['season'] ?? 0, $a['no'] ?: 999, $a['name']] <=> [$b['season'] ?? 0, $b['no'] ?: 999, $b['name']]);
    $list['back'] = ['name' => 'Card back', 'kind' => 'back', 'n' => 0, 'no' => 0];
    return $list;
}
function art_prompts() { static $p = null; if ($p === null) $p = json_decode((string)@file_get_contents(__DIR__ . '/card-prompts.json'), true) ?: []; return $p; }
function art_db() { return load(ART_DB); }
function art_url($f) { return '/card-art/' . rawurlencode($f); }

// the original upload, for picking the focus (kept outside the website)
function art_serve_src() {
    if (!can('art')) { http_response_code(403); exit; }
    $f = basename((string)$_GET['art_src']);
    $path = ART_SRC . '/' . $f;
    if (!preg_match('/^[a-z0-9]+-[a-f0-9]{8}\.(png|jpg|webp)$/', $f) || !is_file($path)) { http_response_code(404); exit; }
    header('Content-Type: ' . ['png' => 'image/png', 'jpg' => 'image/jpeg', 'webp' => 'image/webp'][pathinfo($f, PATHINFO_EXTENSION)]);
    header('Cache-Control: private, max-age=86400');
    header('X-Content-Type-Options: nosniff');
    readfile($path); exit;
}

// what the Game Design channel is told about a card, e.g. "#03 Plasma Storm (Attack)"
function art_label($id) {
    $c = art_cards()[$id] ?? ['name' => $id, 'kind' => '', 'no' => 0];
    $kinds = ['attack' => 'Attack', 'gain' => 'Gain', 'defense' => 'Defense', 'global' => 'Global', 'trick' => 'Trick', 'passive' => 'Reaction'];
    return ($c['no'] ? '#' . sprintf('%02d', $c['no']) . ' ' : '') . $c['name'] . (isset($kinds[$c['kind']]) ? ' (' . $kinds[$c['kind']] . ')' : '');
}
function art_who() { $m = me(); $n = trim((string)($m['name'] ?? '')); $u = (string)($m['username'] ?? ''); return $n !== '' && strcasecmp($n, $u) !== 0 ? $n . ' (' . $u . ')' : ($u ?: 'Someone'); }
function art_kb($id) { return ['inline_keyboard' => [[['text' => '🖼 Open in Card art', 'url' => TG_SITE . '/admin/?tab=art&card=' . rawurlencode($id)]]]]; }
// tell the Game Design channel (if one is set in the Telegram tab) about new art, with the picture itself
function art_tell($kind, $id, $html, $img, $reply = 0, $done = null) {
    if (!function_exists('tg_design')) return;
    $c = tg_cfg();
    if ($c['token'] === '' || $c['design_chat'] === '' || empty($c['design_on'][$kind])) return;
    tg_design($kind, $html, $img ? tg_jpeg_copy($img) : '', art_kb($id), $reply, $done);
}
// published or waiting art whose image is gone from /card-art (the folder lives outside the update zip, so it goes missing
// if the website folder is emptied before a new version is unpacked). The original uploads in shy-data can rebuild them.
function art_missing($db = null) {
    $db = $db ?? art_db(); $out = [];
    foreach ($db as $id => $e) {
        if ($id === '_v' || !is_array($e)) continue;
        foreach (['live', 'draft'] as $k) if (!empty($e[$k]['f']) && !is_file(ART_PUB . '/' . $e[$k]['f'])) $out[] = [$id, $k];
    }
    return $out;
}
// rebuilds every missing image from its original upload, at the same focus. Returns [rebuilt, without an original]
// works in batches of about 20 seconds so a host's time limit can't cut it off; the page carries on with the rest by itself
function art_restore($budget = 20) {
    $done = 0; $lost = []; $t0 = microtime(true); $more = 0;
    $skip = $_SESSION['art_lost'] ?? [];     // ones already found without an original, so a later batch doesn't retry them
    foreach (art_missing() as [$id, $k]) {
        if (in_array($id . ':' . $k, $skip, true)) continue;
        if (($done || $lost) && microtime(true) - $t0 > $budget) { $more++; continue; }   // always at least one per batch
        $e = art_db()[$id][$k] ?? null; if (!$e) continue;
        if (!art_heal($e['f'])) { $lost[] = $id; $skip[] = $id . ':' . $k; continue; }   // same file name, so nothing else changes
        $done++;
    }
    $_SESSION['art_lost'] = $skip;
    return [$done, array_values(array_unique($lost)), $more];
}
// how many published and waiting images have their safe copy in shy-data/card-art-keep
function art_backup_status($db = null) {
    $db = $db ?? art_db(); $n = 0; $kept = 0;
    foreach ($db as $id => $e) {
        if ($id === '_v' || !is_array($e)) continue;
        foreach (['live', 'draft'] as $k) if (!empty($e[$k]['f'])) { $n++; if (is_file(ART_KEEP . '/' . $e[$k]['f'])) $kept++; }
    }
    return [$kept, $n];
}
function art_go($b, $msg) { $_SESSION['flash'] = $msg; header('Location: ./?tab=art&card=' . rawurlencode($b[1])); exit; }

//MC 2026-10-13 ---------------------------------------------------------------- bot masks
//   Each mask with who wears it and the Midjourney prompt that makes a matching one, shown next to its image so new
//   art can be ordered straight from this page. The shared style block keeps the set in one family.
const MASK_STYLE = 'japanese woodblock print style, ukiyo-e game avatar icon, bold flat shapes, thick sumi ink outlines, centered front-facing mask on dark indigo background, vermilion red cream and gold palette, minimal, iconic, reads at small size, square emblem --ar 1:1 --style raw --no text, watermark, photorealism, 3d render';
const MASK_INFO = [
    'ronin'   => ['Ronin', 'Neon Ronin, Velvet Shogun, Hollow Ronin, Cobalt Samurai, Frost Ninja, Rust Shogun, Smoke Daimyo, Koi Ronin', 'menacing ronin warrior mask, straw hat shadow over glowing eyes, torn cloak collar'],
    'monk'    => ['Monk', 'Iron Monk, Static Monk, Lantern Monk, Red Daruma, Ghost Lantern, Willow Sage', 'serene warrior monk mask, closed eyes, prayer beads, single flame above the brow'],
    'tiger'   => ['Tiger', 'Paper Tiger, Rain Tiger, Ivory Tiger, Silk Viper, Dusk Tiger', 'snarling tiger mask, folded paper angles, bared fangs, striped cheeks'],
    'crane'   => ['Crane', 'Night Crane, Copper Crane, Midnight Heron, Obsidian Crane, Paper Crane', 'elegant crane spirit mask, long beak, red crown dot, folded origami wings framing the face'],
    'kitsune' => ['Kitsune', 'Jade Fox, Ash Kitsune, Glass Fox, Golden Tanuki, Moon Kitsune', 'sly kitsune fox mask, narrow smiling eyes, split ears, shrine rope knot at the chin'],
    'oni'     => ['Oni', 'Silent Oni, Ember Oni, Thunder Kappa, Shadow Tengu, Storm Oni', 'roaring oni demon mask, two horns, wide grin of square teeth, storm clouds behind'],
    'shogun'  => ['The Shogun', 'The boss. Its mask is on boss matches, the Shogun victory card and the promo card', 'imposing shogun war mask, gold kabuto helmet with crest, furious burning eyes, the final boss'],
    'elite'   => ['Shogun Elite', 'The Shogun\'s harder twin that sees your hand. Its mask is on Elite matches and its victory card', 'the Shogun\'s dark twin, black lacquer shogun war mask, taller gold kabuto helmet with a split crest, deep crimson face, two wide open all-seeing eyes glowing pale white with red pupils, calm and knowing, the true final boss'],   //MC 2026-10-30
];
function mask_actions($do) {
    $key = (string)($_POST['key'] ?? '');
    if (!in_array($key, MASK_KEYS, true)) go('art', 'Pick a mask.');
    if ($do === 'mask-upload') {
        $up = $_FILES['img'] ?? null;
        if (!$up || ($up['error'] ?? 1) !== UPLOAD_ERR_OK) go('art', ($up['error'] ?? 0) === UPLOAD_ERR_INI_SIZE || ($up['error'] ?? 0) === UPLOAD_ERR_FORM_SIZE ? 'That image is too big for the server. Keep it under 8 MB.' : 'Pick an image to upload.');
        $src = @imagecreatefromstring((string)@file_get_contents($up['tmp_name']));
        if (!$src) go('art', 'That file is not an image this server can read. PNG or JPG works.');
        if (!imageistruecolor($src)) imagepalettetotruecolor($src);
        $dir = mask_dir();
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        // the original stock file, saved once, so Back to stock always has something to go back to
        $stock = $dir . '/stock-' . $key . '.svg';
        if (!is_file($stock) && is_file(mask_site($key)) && !mask_custom($key)) @copy(mask_site($key), $stock);
        // square center crop, then the two sizes: 512 wrapped in SVG for the game, 300 PNG for the Telegram cards
        $sw = imagesx($src); $sh = imagesy($src); $side = min($sw, $sh);
        $crop = function ($size) use ($src, $sw, $sh, $side) {
            $im = imagecreatetruecolor($size, $size);
            imagecopyresampled($im, $src, 0, 0, (int)(($sw - $side) / 2), (int)(($sh - $side) / 2), $size, $size, $side, $side);
            return $im;
        };
        $big = $crop(512);
        //MC 2026-10-13 JPEG, not PNG: the first uploads wrapped 512px PNGs and came out 230 to 400 KB each, which put
        //   about 2 MB of masks on a phone at a full table. The tiles are opaque squares, so JPEG at 85 loses nothing
        //   anyone can see and lands around 40 to 70 KB.
        ob_start(); imagejpeg($big, null, 85); $jpg = ob_get_clean(); imagedestroy($big);
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><image width="512" height="512" href="data:image/jpeg;base64,' . base64_encode($jpg) . '"/></svg>';
        $small = $crop(300);
        $tmp2 = $dir . '/av-' . $key . '.tmp.png'; imagepng($small, $tmp2, 6); imagedestroy($small); imagedestroy($src);
        if (@file_put_contents($dir . '/' . $key . '.svg', $svg) === false || !@rename($tmp2, $dir . '/av-' . $key . '.png')) { @unlink($tmp2); go('art', 'Could not save the mask. Check the server has space.'); }
        @copy($dir . '/' . $key . '.svg', mask_site($key));
        audit('mask-upload', ['key' => $key, 'kb' => (int)round($up['size'] / 1024)]);
        go('art', MASK_INFO[$key][0] . ' mask replaced. New visits see it right away, and every cached game picks it up within about 10 minutes.');
    }
    if ($do === 'mask-revert') {
        $dir = mask_dir();
        $stock = $dir . '/stock-' . $key . '.svg';
        if (is_file($stock)) @copy($stock, mask_site($key));
        @unlink($dir . '/' . $key . '.svg'); @unlink($dir . '/av-' . $key . '.png');
        audit('mask-revert', ['key' => $key]);
        go('art', MASK_INFO[$key][0] . ' mask is back to the stock drawing.');
    }
}
//MC 2026-10-13 the Bot masks section on the Card art page: each mask with its image, who wears it, the Midjourney
//   prompt to make a new one (click to select, ready to paste), an upload box and Back to stock
function page_masks($edit) {
    masks_heal();
    masks_slim();   //MC 2026-10-13 early uploads were heavy PNGs; opening this page slims them
    echo '<details class="addbox" id="masks"><summary class="btnish">Bot masks <small class="muted">the 6 bot faces, the Shogun and Shogun Elite, with their Midjourney prompts</small></summary>';
    echo '<p class="muted">Every bot in the game wears one of these masks, and the Shogun and Shogun Elite each have their own. Replace one here and it changes everywhere at once: in matches, on the Play page panels, on the bot victory cards in Telegram and on the Shogun cards. Square images work best, PNG or JPG, 1024px or bigger. The prompt next to each makes a matching one in Midjourney; run the Shogun first, then add <code>--sref</code> with its image link to the others so the set stays in one style.</p>';
    echo '<p class="muted small">Shared style block, already on the end of every prompt below:<br><code style="user-select:all">' . h(MASK_STYLE) . '</code></p>';
    echo '<div class="maskgrid">';
    foreach (MASK_INFO as $key => [$label, $wearers, $prompt]) {
        $custom = mask_custom($key);
        echo '<section class="maskcard"><div class="mask-im"><img src="../assets/art/masks/' . h($key) . '.svg?t=' . (int)@filemtime(mask_site($key)) . '" alt="" width="96" height="96" loading="lazy"></div>' .
            '<div class="mask-t"><b>' . h($label) . '</b> ' . ($custom ? '<span class="pill on">Custom</span>' : '<span class="pill off">Stock</span>') .
            '<p class="muted small">' . h($wearers) . '</p>' .
            '<code class="mask-prompt" style="user-select:all">' . h($prompt . ', ' . MASK_STYLE) . '</code>';
        if ($edit) {
            echo '<form method="post" enctype="multipart/form-data" class="bar"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="key" value="' . h($key) . '">' .
                '<input type="file" name="img" accept="image/png,image/jpeg,image/webp" required><button name="do" value="mask-upload">Replace</button>' .
                ($custom ? '<button name="do" value="mask-revert" class="ghost" data-confirm="Put the stock ' . h($label) . ' mask back everywhere?">Back to stock</button>' : '') . '</form>';
        }
        echo '</div></section>';
    }
    echo '</div></details>';
}
function art_actions($do) {
    if ($do === 'art-backup') {
        $db = art_db(); $made = 0; $sizes = 0;
        @set_time_limit(120);
        foreach ($db as $id => $e) { if ($id === '_v' || !is_array($e)) continue; foreach (['live', 'draft'] as $k) if (!empty($e[$k]['f'])) {
            //MC 2026-10-11 also makes the smaller sizes the site shows in lists and thumbnails, for images published before they existed
            if (is_file(ART_PUB . '/' . $e[$k]['f'])) $sizes += art_make_sizes($e[$k]['f']);
            if (!is_file(ART_KEEP . '/' . $e[$k]['f'])) { art_keep($e[$k]['f']); if (is_file(ART_KEEP . '/' . $e[$k]['f'])) $made++; }
        } }
        [$kept, $n] = art_backup_status();
        go('art', ($made ? 'Backed up ' . $made . ($made === 1 ? ' image' : ' images') . '. ' : '') . ($sizes ? 'Made ' . $sizes . ' smaller ' . ($sizes === 1 ? 'copy' : 'copies') . ' for thumbnails. ' : '') . $kept . ' of ' . $n . ' images are safely backed up in shy-data.' . ($kept < $n ? ' The rest are missing from the website: rebuild them first.' : ''));
    }
    if ($do === 'art-restore') {
        @set_time_limit(120);
        if (empty($_POST['more'])) $_SESSION['art_lost'] = [];
        [$n, $lost, $more] = art_restore((float)(shy_config()['art_budget'] ?? 20));
        $_SESSION['art_rb'] = ($_SESSION['art_rb'] ?? 0) * (empty($_POST['more']) ? 0 : 1) + $n;
        $_SESSION['art_rl'] = array_values(array_unique(array_merge(empty($_POST['more']) ? [] : ($_SESSION['art_rl'] ?? []), $lost)));
        if ($more) { $_SESSION['art_more'] = 1; go('art', 'Rebuilt ' . $_SESSION['art_rb'] . ' so far. ' . $more . ' to go, carrying on...'); }
        $total = $_SESSION['art_rb']; $gone = $_SESSION['art_rl']; unset($_SESSION['art_more'], $_SESSION['art_rb'], $_SESSION['art_rl'], $_SESSION['art_lost']);
        go('art', ($total ? 'Rebuilt ' . $total . ($total === 1 ? ' image' : ' images') . ' from the original uploads.' : 'Nothing to rebuild.') . ($gone ? ' No original upload was found for ' . count($gone) . ' (' . implode(', ', array_map(fn($x) => art_cards()[$x]['name'] ?? $x, $gone)) . '): upload those again.' : ''));
    }
    $id = (string)($_POST['card'] ?? '');
    if (!isset(art_cards()[$id])) go('art', 'Pick a card.');
    $back = ['art', $id];
    $fx = max(0, min(100, (float)($_POST['fx'] ?? 50))); $fy = max(0, min(100, (float)($_POST['fy'] ?? 50)));
    if ($do === 'art-upload') {
        $up = $_FILES['img'] ?? null;
        if (!$up || ($up['error'] ?? 1) !== UPLOAD_ERR_OK) art_go($back, ($up['error'] ?? 0) === UPLOAD_ERR_INI_SIZE || ($up['error'] ?? 0) === UPLOAD_ERR_FORM_SIZE ? 'That image is too big for the server. Keep it under 8 MB.' : 'Pick an image to upload.');
        if ($up['size'] > 8 * 1024 * 1024) art_go($back, 'That image is too big. Keep it under 8 MB.');
        $info = @getimagesize($up['tmp_name']);
        $ext = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_WEBP => 'webp'][$info[2] ?? 0] ?? null;
        if (!$ext) art_go($back, 'Use a PNG, JPG or WebP image.');
        if (!is_dir(ART_SRC)) @mkdir(ART_SRC, 0755, true);
        $src = $id . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!@move_uploaded_file($up['tmp_name'], ART_SRC . '/' . $src) && !@copy($up['tmp_name'], ART_SRC . '/' . $src)) art_go($back, 'Couldn\'t store the upload.');
        $r = art_render(ART_SRC . '/' . $src, $id, $fx, $fy);
        if (isset($r['err'])) { @unlink(ART_SRC . '/' . $src); art_go($back, $r['err']); }
        with_lock(function () use ($id, $src, $r, $fx, $fy) {
            $db = art_db();
            $old = $db[$id]['draft'] ?? null;
            if ($old) { art_drop_file($old['f']); if (($db[$id]['live']['src'] ?? '') !== $old['src']) @unlink(ART_SRC . '/' . basename($old['src'])); }
            $db[$id]['draft'] = ['f' => $r['f'], 'src' => $src, 'fx' => $fx, 'fy' => $fy, 'w' => getimagesize(ART_SRC . '/' . $src)[0] ?? 0, 'h' => getimagesize(ART_SRC . '/' . $src)[1] ?? 0, 'by' => me()['username'], 'at' => time()];
            save(ART_DB, $db);
        });
        $info2 = @getimagesize(ART_SRC . '/' . $src);
        $live = !empty(art_db()[$id]['live']);
        $fname = trim(preg_replace('/[^\w .()-]+/u', '', mb_substr((string)($up['name'] ?? ''), 0, 80)));
        art_tell('art_up', $id, "🎨 <b>New card art uploaded</b>\n" . tg_h(art_label($id)) . "\nBy <b>" . tg_h(art_who()) . '</b>' .
            "\nImage: " . ($fname !== '' ? tg_h($fname) . ', ' : '') . (int)($info2[0] ?? 0) . ' x ' . (int)($info2[1] ?? 0) . ', ' . strtoupper($ext) .
            "\n" . ($live ? 'Waiting to be published. The current new art stays live until then.' : 'Waiting to be published. Players still see the original drawing.'), ART_SRC . '/' . $src);
        art_go($back, 'Uploaded. Check the preview, move the focus if needed, then publish.' . ($r['small'] ? ' Heads up: the image is small, so it may look soft on big screens. Aim for at least 1040 x 640.' : ''));
    }
    if ($do === 'art-focus') {
        $db = art_db();
        $d = $db[$id]['draft'] ?? null;
        $from = $d ?: ($db[$id]['live'] ?? null);
        if (!$from || !is_file(ART_SRC . '/' . $from['src'])) art_go($back, 'Upload an image first.');
        $r = art_render(ART_SRC . '/' . $from['src'], $id, $fx, $fy);
        if (isset($r['err'])) art_go($back, $r['err']);
        with_lock(function () use ($id, $from, $r, $fx, $fy) {
            $db = art_db();
            if (!empty($db[$id]['draft'])) art_drop_file($db[$id]['draft']['f']);
            $db[$id]['draft'] = ['f' => $r['f'], 'src' => $from['src'], 'fx' => $fx, 'fy' => $fy, 'w' => $from['w'] ?? 0, 'h' => $from['h'] ?? 0, 'by' => $from['by'] ?? me()['username'], 'at' => time()];
            save(ART_DB, $db);
        });
        art_go($back, 'Focus moved. The preview shows the new crop.');
    }
    if ($do === 'art-publish') {
        $msg = with_lock(function () use ($id) {
            $db = art_db();
            $d = $db[$id]['draft'] ?? null;
            if (!$d) return 'Nothing waiting to publish.';
            $old = $db[$id]['live'] ?? null;
            if ($old) { art_drop_file($old['f']); if ($old['src'] !== $d['src']) @unlink(ART_SRC . '/' . basename($old['src'])); }
            $db[$id]['live'] = $d + ['pub' => time(), 'pubBy' => me()['username']];
            unset($db[$id]['draft']);
            $db['_v'] = time();
            save(ART_DB, $db);
            return '';
        });
        if (!$msg) {
            $l = art_db()[$id]['live'] ?? [];
            $up = (string)($l['by'] ?? '');
            $by = "Published by <b>" . tg_h(art_who()) . '</b>' . ($up !== '' && strcasecmp($up, (string)(me()['username'] ?? '')) !== 0 ? ', uploaded by ' . tg_h($up) : '');
            // the picture goes up again, cropped the way players see it
            art_tell('art_pub', $id, "✅ <b>New card art is live</b>\n" . tg_h(art_label($id)) . "\n" . $by . "\nPlayers see it within 5 minutes. This is how the card shows in the game.", !empty($l['f']) ? ART_PUB . '/' . $l['f'] : '');
        }
        art_go($back, $msg ?: 'Published. Players see the new art within 5 minutes.');
    }
    if ($do === 'art-discard') {
        with_lock(function () use ($id) {
            $db = art_db(); $d = $db[$id]['draft'] ?? null;
            if ($d) { art_drop_file($d['f']); if (($db[$id]['live']['src'] ?? '') !== $d['src']) @unlink(ART_SRC . '/' . basename($d['src'])); unset($db[$id]['draft']); save(ART_DB, $db); }
        });
        art_go($back, 'Draft thrown away.');
    }
    if ($do === 'art-revert') {
        with_lock(function () use ($id) {
            $db = art_db(); $l = $db[$id]['live'] ?? null;
            if ($l) { art_drop_file($l['f']); if (($db[$id]['draft']['src'] ?? '') !== $l['src']) @unlink(ART_SRC . '/' . basename($l['src'])); unset($db[$id]['live']); $db['_v'] = time(); save(ART_DB, $db); }
        });
        art_go($back, 'Back to the original drawing.');
    }
}

function art_img($id, $entry) { return $entry ? art_url($entry['f']) : '../assets/cards/' . $id . '.webp'; }
function art_pos($e) { return $e ? h(round($e['fx'])) . '% ' . h(round($e['fy'])) . '%' : '50% 50%'; }

function page_art() {
    $cards = art_cards(); $db = art_db(); $edit = can('art', 2);
    $id = (string)($_GET['card'] ?? '');
    if (isset($cards[$id])) { art_detail($id, $cards[$id], $db[$id] ?? [], $edit); return; }
    $live = 0; $drafts = 0;
    foreach ($cards as $k => $c) { if (!empty($db[$k]['live'])) $live++; if (!empty($db[$k]['draft'])) $drafts++; }
    $miss = art_missing($db);
    if ($miss) echo '<div class="viewonly artmiss"><div><b>' . count($miss) . ' card art ' . (count($miss) === 1 ? 'image is' : 'images are') . ' missing from the website.</b> This happens when the website folder is emptied before a new version is unpacked. Nothing is lost: the site puts each one back by itself the first time it\'s shown, from a safe copy or your original upload. Rebuild does them all now.' .
        ($edit ? '<form method="post" class="bar" id="art-rb"><input type="hidden" name="csrf" value="' . h(csrf()) . '">' . (!empty($_SESSION['art_more']) ? '<input type="hidden" name="more" value="1">' : '') . '<button name="do" value="art-restore">' . (!empty($_SESSION['art_more']) ? 'Rebuilding...' : 'Rebuild missing images') . '</button></form>' .
            (!empty($_SESSION['art_more']) ? '<script>setTimeout(function(){var f=document.getElementById("art-rb");var i=document.createElement("input");i.type="hidden";i.name="do";i.value="art-restore";f.appendChild(i);f.submit();},400);</script>' : '') : '') . '</div></div>';
    [$kept, $nImg] = art_backup_status($db);
    if ($nImg) echo '<div class="bar artbk"><span class="pill ' . ($kept === $nImg ? 'on' : 'warn') . '">' . ($kept === $nImg ? 'Backed up' : 'Backup incomplete') . '</span><span class="muted">' . $kept . ' of ' . $nImg . ' card art images have a safe copy in shy-data, outside the website. New uploads are backed up as they\'re made, along with your original files.</span>' .
        ($edit ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><button name="do" value="art-backup" class="ghost">Back up now</button></form>' : '') . '</div>';
    page_masks($edit);   //MC 2026-10-13 the Bot masks section, above the card grid
    echo '<p class="muted">Pick a card to give it new art. Each card shows the original drawing until you publish a replacement. ' . $live . ' of ' . count($cards) . ' cards have new art' . ($drafts ? ', ' . $drafts . ' waiting to be published' : '') . '.</p>';
    $kinds = ['attack' => 'Attacks', 'gain' => 'Gains', 'defense' => 'Defenses', 'global' => 'Global', 'trick' => 'Tricks', 'passive' => 'Passives', 'back' => 'Card back'];
    echo '<div class="bar artfilter"><button type="button" class="ghost on" data-k="">All</button>';
    foreach ($kinds as $k => $l) echo '<button type="button" class="ghost" data-k="' . $k . '">' . h($l) . '</button>';
    echo '<button type="button" class="ghost" data-k="season">Season cards</button><button type="button" class="ghost" data-k="new">New art</button><button type="button" class="ghost" data-k="draft">Waiting</button>' . ($miss ? '<button type="button" class="ghost" data-k="gone">Image missing</button>' : '') . '' .
        '<input type="search" class="artfind" placeholder="Find by # or name" autocomplete="off"></div><div class="artgrid">';
    foreach ($cards as $k => $c) {
        $e = $db[$k] ?? [];
        $gone = !empty($e['live']['f']) && !is_file(ART_PUB . '/' . $e['live']['f']);   // published, but the image file is missing on the server
        $st = $gone ? '<span class="pill warn">Image missing</span>' : (!empty($e['draft']) ? '<span class="pill warn">Waiting</span>' : (!empty($e['live']) ? '<span class="pill on">New art</span>' : '<span class="pill off">Original</span>'));
        $no = !empty($c['season']) ? 'S' . (int)$c['season'] : (!empty($c['no']) ? sprintf('%02d', $c['no']) : '');
        echo '<a class="artcard k-' . h($c['kind']) . (!empty($c['season']) ? ' season' : '') . '" href="?tab=art&amp;card=' . h($k) . '" data-kind="' . h($c['kind']) . '"' . (!empty($c['season']) ? ' data-season="' . (int)$c['season'] . '"' : '') . ' data-no="' . (int)$c['no'] . '" data-name="' . h(strtolower($c['name'])) . '" data-st="' . ($gone ? 'gone' : (!empty($e['draft']) ? 'draft' : (!empty($e['live']) ? 'new' : ''))) . '"><span class="artimg">' . ($no ? '<span class="artno">' . $no . '</span>' : '') . '<img src="' . h(art_img($k, $e['live'] ?? null)) . '" alt="" loading="lazy" style="object-position:' . art_pos($e['live'] ?? null) . '" onerror="this.onerror=null;this.src=\'../assets/cards/' . h($k) . '.svg\'"></span><span class="artmeta"><b>' . h($c['name']) . '</b>' . $st . '</span></a>';
    }
    echo '</div>';
    //MC 2026-10-09 the filter and Find box left a blank space when nothing matched
    echo '<p class="muted" id="art-none" hidden>No cards match.</p>';
}

function art_detail($id, $c, $e, $edit) {
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="card" value="' . h($id) . '"><input type="hidden" name="back" value="art">';
    $live = $e['live'] ?? null; $draft = $e['draft'] ?? null;
    $show = $draft ?: $live;
    $img = art_img($id, $show); $pos = art_pos($show);
    echo '<p><a href="?tab=art">&larr; All cards</a></p>';
    echo '<div class="artdetail"><div class="artcol">';
    echo '<h2>' . (!empty($c['season']) ? '<span class="artno inl">S' . (int)$c['season'] . '</span> ' : (!empty($c['no']) ? '<span class="artno inl">' . sprintf('%02d', $c['no']) . '</span> ' : '')) . h($c['name']) . ' <small>' . ($draft ? 'Draft preview' : ($live ? 'New art, live' : 'Original drawing')) . '</small></h2>';
    if (!empty($c['season'])) {
        $inPlay = in_array($id, season_deck_at(), true);
        echo '<p class="muted">' . ($inPlay ? 'A Season ' . (int)$c['season'] . ' card, in the game now on top of the original deck.' : 'A candidate for Season ' . (int)$c['season'] . '. If it wins the holders\' vote it joins the game on ' . gmdate('M j', cs_season_start((int)$c['season'])) . '. Art you publish now shows on the cards page vote and, if it wins, in the game.') . '</p>';
    }
    // the card the way the Cards page and the end screen draw it
    echo '<div class="pv-big k-' . h($c['kind']) . '"><img src="' . h($img) . '" alt="" style="object-position:' . $pos . '"><span class="pv-name">' . h($c['name']) . '</span></div>';
    echo '<div class="pv-row"><figure><div class="pv-hand"><span class="pv-art"><img src="' . h($img) . '" alt="" style="object-position:' . $pos . '"></span><b>' . h($c['name']) . '</b></div><figcaption>In your hand</figcaption></figure>' .
        '<figure><div class="pv-hand pv-phone"><span class="pv-art"><img src="' . h($img) . '" alt="" style="object-position:' . $pos . '"></span><b>' . h($c['name']) . '</b></div><figcaption>Phone hand</figcaption></figure>' .
        '<figure><div class="pv-thumb"><img src="' . h($img) . '" alt="" style="object-position:' . $pos . '"></div><figcaption>Stats and lists</figcaption></figure></div>';
    if ($draft) echo '<p class="muted small">Uploaded by ' . h($draft['by']) . ' ' . h(ago($draft['at'])) . ($draft['w'] ? ', ' . (int)$draft['w'] . ' x ' . (int)$draft['h'] . ' original' : '') . '.' . ($live ? ' The live art stays until you publish.' : '') . '</p>';
    elseif ($live) echo '<p class="muted small">Published by ' . h($live['pubBy'] ?? $live['by']) . ' ' . h(ago($live['pub'] ?? $live['at'])) . '.</p>';
    if ($edit && ($draft || $live)) {
        echo '<div class="bar">';
        if ($draft) echo '<form method="post">' . $csrf . '<button name="do" value="art-publish">Publish this art</button></form><form method="post">' . $csrf . '<button name="do" value="art-discard" class="ghost">Throw away draft</button></form>';
        if ($live) echo '<form method="post">' . $csrf . '<button name="do" value="art-revert" class="ghost danger" data-confirm="Go back to the original drawing for ' . h($c['name']) . '?">Back to the original</button></form>';
        echo '</div>';
    }
    echo '</div><div class="artcol">';
    if ($edit) {
        $srcEntry = $draft ?: $live;
        if ($srcEntry) {
            echo '<h2>Focus <small>click where the card should center</small></h2><form method="post" class="focusbox">' . $csrf .
                '<div class="focus" data-focus><img src="?art_src=' . h(rawurlencode($srcEntry['src'])) . '" alt=""><i class="frame"></i><i class="dot" style="left:' . round($srcEntry['fx']) . '%;top:' . round($srcEntry['fy']) . '%"></i></div>' .
                '<input type="hidden" name="fx" value="' . h($srcEntry['fx']) . '"><input type="hidden" name="fy" value="' . h($srcEntry['fy']) . '">' .
                '<p class="muted small">Narrow spots like the phone hand show only the middle strip of the art, so put the focus on the part that tells the story. The crop is redone from your original upload.</p><div class="bar"><button name="do" value="art-focus">Apply focus</button></div></form>';
        }
        echo '<h2>Upload new art</h2><form method="post" enctype="multipart/form-data" class="tform upbox">' . $csrf . '<input type="hidden" name="MAX_FILE_SIZE" value="8388608">' .
            '<label>Image <small>PNG, JPG or WebP, up to 8 MB. Best at 13:8, like 1456 x 896.</small><input type="file" name="img" accept="image/png,image/jpeg,image/webp" required></label>' .
            '<input type="hidden" name="fx" value="50"><input type="hidden" name="fy" value="50">' .
            '<div class="bar"><button name="do" value="art-upload">Upload and preview</button><span class="muted small">Nothing changes for players until you publish.</span></div></form>';
    }
    $p = art_prompts()[$id] ?? '';
    if ($p) echo '<h2>Midjourney prompt</h2><div class="hashline"><code id="mj-' . h($id) . '">' . h($p) . '</code><button type="button" class="ghost" data-copy="mj-' . h($id) . '">Copy</button></div>';
    echo '</div></div>';
}
