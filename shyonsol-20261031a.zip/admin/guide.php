<?php
// The admin How-to guide: everything the admin can do, page by page. Shown on the admin's How-to guide page.
if (!defined('SHY_API')) { http_response_code(404); exit; }

function guide_sections() {
    $mw = function_exists('mw_address') ? mw_address() : 'the marketing wallet';
    return [
    //MC 2026-10-13 the new layout, first, since the team asked where everything went
    'nav' => ['Finding your way', 'How the admin is laid out, search, Needs you, and where each old tab went.', [
        ['The sidebar', [
            'Every job has its own page, grouped by what you came to do: <b>Daily work</b> (payouts, Fair Play, orders, ideas, live rooms and chat), <b>Players</b>, <b>Economy</b> (sales, prices, prizes, events), <b>Channels</b> (Telegram, X, email, card art), <b>Reports</b> and <b>Team and system</b>.',
            'Tap a group\'s name to fold it away. The admin remembers what you folded, and the group you are in always stays open.',
            'A red number next to a page is how many things wait there. A yellow dot means something there needs a look.',
            'On a phone, the menu button at the top left slides the sidebar in. Tap outside it or press Escape to close it.']],
        ['Search', [
            'Press <b>Ctrl K</b> (<b>Cmd K</b> on a Mac) or <b>/</b> anywhere, or tap the magnifier at the top. Type any part of what you want: a page (<b>payouts</b>), a section (<b>bounty</b>) or a setting (<b>pin</b>, <b>burn</b>, <b>KOL</b>, <b>floor</b>).',
            'Use the arrow keys and Enter, or tap a result. A setting opens its page with the setting highlighted.',
            'Type a player\'s name and the last result finds them on All players.']],
        ['Needs you', [
            'The bell at the top shows everything waiting on the team: prizes to pay, lists waiting for a second admin, the 15 Club bounty, payments players say did not arrive, matches the farming check flagged, names to review, new ideas, a low prize budget and any health check that is not green.',
            'Each line opens the page that fixes it. Home shows the whole list at the top.',
            'You only see what your access lets you act on.']],
        ['Pages with tabs', [
            'Bigger pages (Telegram, Email, Logs, All players) have tabs under the title. The admin remembers the last tab you used on each page.',
            'After you save or press a button, you come back to the same page and tab.',
            'Change anything in a long settings form and a bar at the bottom offers <b>Save</b> and <b>Undo</b>, so you never have to scroll for the button. Leaving the page with changes not saved asks first.',
            'Old links and bookmarks (<code>?tab=rewards</code>) still work: they open the page that now holds that part.']],
        ['Where each old tab went', [
            '<b>Overview</b>: Home, plus <b>Player analytics</b> under Reports for when and where players play and where they drop off.',
            '<b>Rewards</b>: <b>Payouts</b> (with the 15 Club bounty) and <b>Fix a final week</b> under Daily work; <b>Prize budget</b>, <b>Events</b> and <b>Treasury page</b> under Economy; <b>Houses</b> and <b>Recover lost points</b> under Players.',
            '<b>Shop</b>: <b>Sales</b>, <b>Today\'s shop</b>, <b>Limited drops</b>, <b>Shop prices</b> and <b>Give Koban or items</b>. <b>Rewards</b>: <b>Prize budget</b>, <b>Invites and tasks</b>, <b>The Shogun</b> and <b>Events</b>. <b>Solana</b>: <b>Email wallets</b>, <b>Trophies on Solana</b> and the <b>Treasury page</b>. <b>Orders and payments</b> (Payment help, the nightly check, every order) sits under Daily work.',
            '<b>Players</b>: <b>All players</b> (names to review, Award Koban, combine), <b>Live chat</b> under Daily work and <b>X posting</b> under Channels.',
            '<b>Weekly</b> and <b>Daily</b> are under Reports. <b>Holders</b> and <b>Tournaments</b> are under Players. <b>Live rooms</b> is under Daily work.']],
    ]],
    'start' => ['Getting started', 'Signing in, who can get in, and keeping the admin safe.', [
        ['Signing in', [
            'Go to <b>shyonsol.io/admin</b> and sign in with your username or email and your own password. You stay signed in for up to 8 hours of inactivity.',
            'Owners and anyone who can send prize payouts also type a 6-digit code from an authenticator app (two-step sign-in). Set it up once in <b>My account</b>.',
            'Too many wrong tries from one connection pauses sign-in there for 15 minutes. Five wrong passwords or codes in a row lock that account for 15 minutes.',
            'Always <b>Log out</b> on a shared or borrowed computer.']],
        ['The setup key', [
            'The old shared password in <code>shy-data/config.php</code> still works as the <b>setup key</b>: on the sign-in screen, leave the name empty and use it. It skips two-step sign-in, so it is your way back in if every owner is locked out.',
            'Use it only for that. Give everyone their own account in <b>Team</b>, and change the setup key (below) if it was ever shared.']],
        ['Changing the setup key', [
            'Use <b>Make a new password line</b> at the bottom of this tab. Type the new password twice and press the button. You get one line that starts with <code>\'admin_hash\' =&gt;</code>.',
            'In Hostinger\'s File Manager open <code>shy-data/config.php</code>, replace the old <code>admin_hash</code> line with the new one, and save. The new setup key works straight away.',
            'The file only stores a scrambled version of the password, so nobody can read it from the file. Keep the setup key itself in a password manager.']],
        ['Keeping it safe', [
            'Turn on two-step login for Hostinger and for the X account. Whoever controls Hostinger controls the whole site.',
            'The marketing wallet (' . h(short_w($mw)) . ') is where shop money lands and prizes come from. The site never holds its keys; you approve every payout yourself in Phantom. Keep it on a hardware wallet if you can, and never sign anything you didn\'t start.',
            'Never paste a password, the Helius key, the X secret or the Telegram bot token into a chat, a screenshot or a public place. If one leaks, change it (for the bot: <code>/revoke</code> in @BotFather, then paste the new token in the Telegram tab).']],
    ]],
    'routine' => ['Daily routine', 'A five-minute check that keeps everything running.', [
        ['Every day', [
            '<b>Ideas</b>: read new suggestions (the tab shows a count). Put the good ones on the board, reply to bug reports.',
            '<b>Shop</b>: glance at the latest orders. Anything that isn\'t Paid after a few minutes can be checked on Solana from its row.',
            '<b>Players</b>: look at <b>Names to review</b> at the top. Rename or remove anything offensive.',
            '<b>Logs</b>: everything there should be empty or quiet. Shop or X errors are worth a look.']],
        ['Every Monday', [
            'At Monday 00:00 UTC the week freezes. Open <b>Rewards</b>, check last week\'s Weekly League and Holder Cup winners, then pay them (see the Rewards section of this guide).',
            'Every fourth Monday a season ends and the Season Championship appears in Rewards too.']],
        ['After each site update', [
            'Open <b>Overview</b> and check the Setup list is all green.',
            'Open shyonsol.io/updates and make sure the newest release note is at the top.']],
    ]],
    'overview' => ['Overview', 'The numbers at a glance and a health check.', [
        ['The tiles', [
            '<b>Players</b>: everyone with a record. <b>Games played</b> and <b>Live games</b>: totals since launch. <b>Played this week</b>: players with points this week.',
            '<b>Today\'s Daily</b>: how many finished today\'s Daily Challenge. <b>Verified holders</b>: connected wallets holding a Shadow. <b>Live matches now</b>: rooms mid-game. <b>Shared results</b>: result cards made for sharing.']],
        ['This week so far', ['The top five of the Weekly board right now. The full list is in the Weekly tab.']],
        ['Setup', [
            '<b>Wallet checks</b> must say On. If it says Off, the Helius key is missing from config.php, and holders, prices and crypto payments won\'t work.',
            '<b>Image cards</b> must say Ready, or shared results have no picture.',
            '<b>Data folder</b> must say safe from site updates. If it ever says inside the website folder, stop and fix it before uploading anything.']],
        ['Health (owners)', [
            'The card at the top is green when all is well, amber when something needs a look and red when something needs attention. It lists what isn\'t green; <b>Details</b> shows every check.',
            'It checks the size of the data files, when the cron job last ran, how long requests waited for each other in the last hour, the last Telegram and email errors, the age of the newest backup, disk use, payments found but not delivered, and the PHP setup.',
            'The same check is at /api/health.php with the cron key (from the Telegram tab) added as ?k=, for an uptime monitor. It answers 503 when something is red. The daily report email has it in one line too.']],
    ]],
    'ideas' => ['Ideas', 'Player suggestions, the public Ideas board, and the email that tells you about them.', [
        ['Where suggestions come from', [
            'Every page has a <b>Suggest an idea</b> button (bottom right on computers, in the menu and footer on phones). Players pick a topic, write it, and can add a screenshot and a way to reach them.',
            'Each new suggestion lands here marked <b>New</b> and is emailed to the address at the top of the Ideas tab.']],
        ['Email', [
            'Change the address in <b>Email new ones to</b> and press <b>Save</b>. <b>Save and send a test</b> sends a test email. Check spam the first time.',
            'Leave the box empty to stop emails. If an email fails, the suggestion is still saved here and the failure shows in Logs.']],
        ['Ideas in other languages', [
            'The site works out what language each suggestion is in. If it isn\'t English, the email shows the player\'s own words first and an English translation under them, and the subject line uses the English. The translation also shows under the original here.',
            'Translations come from the free MyMemory service, which allows about 5,000 characters a day. For more, add <code>\'mymemory_email\' => \'you@example.com\',</code> to <code>shy-data/config.php</code> (50,000 a day), or a free DeepL key as <code>\'deepl_key\' => \'...\',</code> for better translations.',
            'If the service doesn\'t answer, the email says so and the suggestion shows a <b>Translate to English</b> button here to try again. Older suggestions in other languages have the same button.']],
        ['Putting an idea on the public board', [
            'Press <b>Put on the board</b> on its top line. It shows on shyonsol.io/updates under Ideas board within about a minute, where players vote for it. <b>Take off the board</b> removes it.',
            'Setting a status on its own does <b>not</b> publish it. Only Put on the board, or ticking Show on the Ideas board, does.',
            'Under <b>Respond and publish</b> you can set a cleaner <b>Board title</b> and <b>Board text</b> (the player\'s original words stay here), write a <b>Public reply from the team</b>, tick <b>Credit the player by name</b>, and keep a <b>Private note</b> only admins see.',
            'Contact details, wallets and screenshots are never shown publicly.']],
        ['Statuses', [
            '<b>New</b>: not looked at yet. <b>Reviewing</b>: being considered. <b>Planned</b>: we\'ll build it. <b>Building</b>: in progress. <b>Shipped</b>: it\'s live. <b>Not for now</b>: declined, politely.',
            'The filter buttons along the top show Open (everything not Shipped or Not for now), each status, or All.',
            'When you ship something from the board, set it to Shipped and mention it in the release notes.']],
        ['Deleting', ['<b>Delete</b> removes a suggestion and its screenshot for good. Use it for spam.']],
    ]],
    'friends' => ['Friends and Duels', 'How players add friends, challenge them, and Duel on the same deal.', [
        ['What players can do', [
            'Every page has a <b>Friends</b> button in the header (and on the Dojo bar). Players add friends by name, by their 6-letter player id, with their invite link (<code>shyonsol.io/play?friend=ID</code>), or with the buttons under the result of a live match. A request has to be accepted. Players can remove or block anyone.',
            '<b>Live</b> opens a private room and calls the friend in. <b>Duel</b> gives both players the same deal: the challenger plays first, then the friend has 24 hours to beat their Regions. Normal rules, no hints, one shot each. Duel games count for points and Scroll XP like a normal game, never for the Weekly League.',
            'From the second week of the release, "Win 2 Duels against friends" joins the weekly mission rotation.']],
        ['How challenges reach players', [
            'On the site: a card pops up on any page they have open, and a red count shows on the Friends button.',
            'In Telegram: players who linked Telegram get a message with a Join or Play button. They can switch this off with /notify (Friends, challenges and Duels). /friends shows them and their friends this week, and so does the Friends button under /leaderboard.',
            'In the browser: players can turn on notifications in Friends. They work on Android and computers, and on iPhone once the site is on the Home Screen. The site makes its own notification key the first time; it lives in <code>shy-data/push-keys.php</code>. If notifications ever fail, the reason is in <code>shy-data/push-errors.log</code>.']],
        ['Limits that stop spam', [
            'Only friends can challenge each other. A player can send a few live challenges an hour, and each friend gets at most 4 an hour from them. A player can have 10 Duels waiting at once and one Duel at a time with each friend. 200 friends at most.']]]],
    'shop' => ['Shop', 'Sales, orders, giving Koban or items, and fixing a payment by hand.', [
        ['How payments work', [
            'Players buy Koban packs and bundles with $SHY (they get 20% more Koban), SOL, USDC, or card once Stripe is set up.',
            'Crypto goes straight to the marketing wallet. The site delivers an order only after it finds the payment on Solana. One payment can only ever pay for one order.',
            'Purchases paid from the marketing wallet itself are delivered too, but are left out of shop revenue so they don\'t grow the prize pool.']],
        ['What players can buy', [
            '<b>With money</b>: Koban packs (the first buy of each pack size is double), the Starter Pack, the Founder\'s Bundle while it lasts, the Season Scroll, Scroll+ and the Scroll+ upgrade, and the Koban Moon (300 Koban now, then 60 a day for 30 days with the daily gift).',
            '<b>With Koban</b>: card finishes (Gold Leaf, Blood Moon and Neon Shrine any day; Holo Foil only for the three cards in the daily shop; Shadow Ink only from the Season Scroll), card backs, share card themes, frames, tables, victory effects, titles, name rings, reactions, boosts (XP Boost, Tier Skip, Mission Reroll, Bounty Board, Streak Saver) and the weekly bundle.',
            'Nothing sold changes the cards, the deal, scores, League points or who wins. Boosts only speed up the Season Scroll, missions and streaks.',
            'Holders pay less Koban on everything except boosts, by $SHY Army Rank: from 3% for a Kusama Cadet up to 22% for Shytoshi Supreme. Daily gifts are 2x to 5x by rank.']],
        ['Daily X tasks', [
            'Three X tasks every day: share a game result, plus two of these in turn: share the Daily, post about $SHY, challenge a friend (tag @ShyOnSol_ and someone else), or use #Shilluminati. They change at 00:00 UTC.',
            'Players post on X, then paste the post\'s link in the Dojo. The site checks it with X\'s free embed service, so it costs no X credits. The post has to be public, made today (UTC), from the player\'s X account, and say what the task asks. Each post counts once, and each X account belongs to one player (the one they connected on their profile, or else the one their first counted post came from).',
            'Each task pays Koban and 20 Scroll XP, and doing all three pays a bonus. Holders get double Koban. Set the amounts or switch tasks off under <b>Daily X tasks</b> on this tab. Results posted with the site\'s own Post to X count on their own.',
            'The list on this tab shows the latest posts that earned Koban, with links. If a post was deleted or is spam, press <b>Take back</b> to remove the Koban. If a player changes X accounts, use <b>Free this X account</b> so their next post ties the new one.']],
        ['Shadow skins', [
            'Nine Shades in the Style tab, from 300 to 1,800 Koban: the Unbound hood in a Shadow trait\'s colours (Void, Cyan, Crimson, Storm, Gold, Bitcoin), two masks (Oni, Kitsune) and an animated one (Kami). They show on the player\'s seat, to rivals in live matches, on the boards, the profile, the friends list and the share card.',
            'They are looks, not NFTs, and each carries its name on its plate so it never passes for a numbered Shadow. A holder always plays as their own Shadow instead. The terms of sale say this in plain words.',
            '<b>Holders</b> get more than any skin: a verified Shadow glows in its own Aura trait colour with a ✓ seal everywhere it shows, free. On top of that they can buy <b>Shadow halos</b> (600 to 1,500 Koban), frames around their own Shadow. Only a wallet that holds a Shadow can buy or wear one, and halos never appear in the daily shop. If a holder sells their Shadow, their halo stops showing until they hold one again.',
            'The artwork is made by <code>scripts/skins.py</code>, and the share card pictures by <code>scripts/skins_png.py</code>. To add a Shade, add it to both scripts and to the items list in <code>api/economy.php</code>.']],
        ['The daily shop and the weekly bundle', [
            'Every day at 00:00 UTC the shop picks a deal of the day (40% off), three Holo Foil cards and four picks (15% off). Every Monday it picks a themed bundle; its price counts only what a player doesn\'t own yet, 30% off. Both are the same for every player. See them, and roll new ones for today, on <b>Today\'s shop</b>.',
            'It all runs on its own. There is nothing to set.']],
        ['Collection and mastery', [
            'Every card finish a player owns adds to their Collection level, which pays Koban, a card back, titles, a frame and a share card theme along the way.',
            'Every card a player chooses to play counts toward that card\'s mastery. Levels pay a little Koban, and Master (100 plays) gives that card\'s Gold Leaf finish for free.']],
        ['The tiles', ['Revenue this week and all time (in USD at the price when bought), paid orders, buyers, Koban currently held by players, and shop accounts. Below them on <b>Sales</b>: sales by product, and Koban flow (Koban earned free, bought and spent, and what players spend it on).']],
        ['Give Koban or an item', [
            'Type a player\'s name or 6-letter id, an amount of Koban and/or pick an item, add a reason, press <b>Give</b>. The reason shows in their Koban history.',
            'Use it to make up for a problem, reward a contest winner or test a cosmetic.']],
        ['Orders', [
            'The latest 150, newest first. Paid orders link to the payment on Solscan (or the Stripe id for cards).',
            '<b>Check on Solana</b>: looks for the order\'s payment again. If a player sends you their transaction link from Phantom, paste it in the box first. You get a plain answer: delivered, failed on Solana, sent nothing to the marketing wallet, underpaid, or no payment found.',
            '<b>Deliver by hand</b>: delivers without any check on Solana. Only use it after you have seen the payment yourself on Solscan, landing in the marketing wallet for the right amount.',
            'Unpaid orders simply expire after a day. Nothing needs doing.']],
        ['Payment help (paid, but nothing arrived)', [
            'In the shop\'s History, players can paste the payment from their wallet. The site looks it up on Solana and delivers straight away when it came from their own wallet, after the order, for at least the price. That covers wallets and exchanges that drop the order\'s reference.',
            'Anything it can\'t match (paid from a wallet that isn\'t theirs, paid too little, no open order) lands under <b>Payment help</b> on <b>Orders and payments</b>, and the Shop tab shows a count. Open the transaction, then press <b>Check with this payment</b> on the right order, or <b>Deliver by hand</b> once you\'re sure. <b>Mark sorted</b> clears a request.',
            'A payment can only ever deliver one order, however many times it\'s pasted.']],
        ['Card payments', ['Cards stay off until a Stripe secret key (<code>stripe_secret</code>) and webhook secret (<code>stripe_webhook</code>) are added to config.php. Ask for help setting Stripe up when you want it.']],
        ['Nightly payment check', [
            'Every night after 03:00 UTC the cron job looks up open orders that have a wallet signature or a Payment help request on Solana again. If a payment carries the order\'s reference, covers the price and came within a day, it delivers the order, exactly as the shop would have when the buyer checked.',
            'Anything else that found money (a payment pasted in Payment help that covers an order, a late or short payment, one more than a day after the order) is listed under <b>Nightly payment check</b> in the Shop tab and in the daily report email, with the same <b>Check with this payment</b> and <b>Deliver at the quoted price</b> buttons. Nothing there is delivered until you press one.',
            '<b>Run the check now</b> does it straight away.']],
    ]],
    'rewards' => ['Rewards', 'Paying prizes, setting prize pools and holder perks, and running events.', [
        ['How prizes work', [
            '<b>Weekly League</b>: League points come from each player\'s first Daily Challenge run and from live matches with at least two real players (up to 10 a day). The top 10 win.',
            '<b>Holder Cup</b>: the same points, holders only. The top 5 win.',
            '<b>Season Championship</b>: four-week seasons, top 3.',
            'To win, a player needs a connected wallet and the minimum number of League games that week (twice that for a season). Anyone who doesn\'t qualify is skipped and the next player moves up.',
            'The Weekly League pool is the base amount plus a share of the previous week\'s shop revenue.']],
        ['Paying the winners (every Monday)', [
            '1. Open <b>Rewards</b>. Last week\'s League and Holder Cup appear under Payouts, opened if anyone is unpaid.',
            '2. Check the winners. Use <b>Leave out</b> for anyone who shouldn\'t be paid (for example, a team account). Press it again to include them.',
            '3. Press <b>Set amounts at today\'s price</b>. Each prize in USD is turned into $SHY at the current price.',
            '4. On a computer with Phantom, unlock the <b>marketing wallet</b> in Phantom and press <b>Send with Phantom</b>. Phantom asks you to approve each batch of up to 5 winners.',
            '5. The site checks every batch on Solana and marks those winners Paid with a link to the transaction. If you stop halfway, press Send again later; already paid winners are never paid twice.',
            'Make sure the marketing wallet has enough $SHY for the prizes and a little SOL for network fees before you start.']],
        ['A second admin approves big payouts', [
            'A prize list worth at least the approval amount (USD, set by owners under Prize pools and rules, 0 turns it off) needs a second admin before <b>Send with Phantom</b> works.',
            'The admin who pressed <b>Set amounts</b> can\'t approve their own list. Anyone else with payout access sees <b>Approve this payout</b>. Any change after that (new amounts, leaving someone out, a different wallet) needs approving again. The setup key can\'t approve.']],
        ['Daily runs from before the League', [
            'Daily Challenge runs played before the Weekly League existed earned no League points. Under <b>Daily runs not in the League</b>, each such run this week has a <b>Count it</b> button that adds its points once. Runs played since then are already counted.']],
        ['Prize pools and rules', [
            'Change any pool, split or rule and press <b>Save</b>. Splits are percentages separated by commas and must add up to 100, or that split is left as it was.',
            //MC 2026-10-10 guide copy follows the $SHY Army Ranks (was Bronze, Silver, Gold and Shogun)
            '<b>$SHY Army Ranks</b> are the $SHY a wallet must hold for each of the nine ranks, Shy Sapling to Shytoshi Supreme. <b>Stipends</b> are the Koban each rank can collect every week.',
            '<b>Shop open</b>: untick it to pause all purchases (for example during a problem). <b>Founder\'s Bundle on sale until</b>: the last day that bundle is offered.']],
        ['Events', [
            'An event multiplies League points for a set time, like a Double Points Weekend. Give it a name, a start time (in UTC), how many hours, and the multiplier, then <b>Add event</b>.',
            'Players see a countdown before and during it. <b>Remove</b> cancels it.']],
        ['The Shogun (boss bot)', [
            'A 1v1 against the hardest bot in the game. Players start it with <b>Challenge</b> on the Play page, or with <b>/shilluminatiboss</b> (or /boss) in Telegram, which answers with a button straight into a match.',
            'The Shogun tries every card it could play, plays each one out to the end of the game many times with the cards it can\'t see dealt at random, and picks what won most. It never sees the player\'s hand. In testing it beat the normal bots about 9 times in 10.',
            'Set it under <b>Economy > The Shogun</b>: on or off, the Koban a win pays, once a day or once a week, extra cards it starts with (players are told), how long it thinks per card, and how many boss matches a player can start a day.',
            'A win only pays when the player played every turn themselves. If a bot covered a turn (they timed out or left), the win still counts on their record but pays nothing. Boss matches only go on the Shogun record: no leaderboard points, games or wins, and nothing toward the League or Ranked.',
            'Every win against it is posted to the chat if <b>Wins against the Shogun</b> is on under Telegram > What gets posted.']],
        ['Shogun Elite', [
            'The Shogun\'s harder twin, beside it on the Play page. Same brain, one difference: when it plays its moves out it uses the challenger\'s <b>real hand</b> instead of a random one, so bluffs and held Blockers mean nothing to it. The decks stay hidden from it, so it can be beaten with luck and a plan. Players are told on its card and on the Fair play page.',
            'Set it under <b>Rewards > Shogun Elite</b>: on or off, the Koban a win pays, once a day or once a week, extra cards, thinking time (1200 ms by default, more than the Shogun), matches a day, paid bounties a week, and the gate: by default only players who have beaten the Shogun once can challenge it. Turn the gate off and everyone can.',
            'It has its own record, its own mask (<b>Art > Bot masks</b>, with a Midjourney prompt) and its own Telegram command, <b>/shilluminatielite</b>. Its wins and losses post under the same Telegram switches as the Shogun\'s, in its own name. It never drops into quick matches.']],
    ]],
    'players' => ['Players', 'Names, Koban awards, mottos, duplicates, removals, blocked words and posting to X.', [
        ['Names to review', ['Names on the boards that fail the name filter appear at the top. <b>Rename</b> them or <b>Remove</b> them.']],
        ['Renaming', [
            'Open <b>Rename, remove, combine</b> on a player\'s row, type the new name and press <b>Rename</b>.',
            'A name set by an admin is locked: the player can no longer change it themselves. Only rename when you need to.']],
        ['Combining two players', [
            'For someone who ended up with two profiles (for example, they played as a guest, then connected a wallet on another device).',
            'Type the profile to move in the first box and the one to keep in the second, then <b>Combine</b>. Use names, 6-letter ids or a wallet address. Ids are safest when names look alike.',
            'Everything moves into the second profile: points, wins, Daily runs, weekly history, Koban, items, purchases, devices, a connected X account and recent games. The first profile disappears. If the kept profile had no name yet, it takes the other one\'s name.',
            'It can\'t be undone, but a daily backup exists (see Backups).']],
        ['Players who haven\'t played yet', ['Connected profiles that haven\'t finished a game show as <b>Connected, no games</b>. You can rename them or combine into them. They stay off the public boards until they play.']],
        ['Awarding Koban', [
            'Use <b>Award Koban</b> on <b>All players</b>: type the player\'s name (or paste their page link, 6-letter id or wallet), pick an amount or tap a preset, add a reason and press <b>Award</b>. The Koban lands right away and the reason shows in their Koban history.',
            'For one player you\'re already looking at, open <b>Rename, give Koban, remove, combine</b> on their row and use <b>Give Koban</b>.',
            'A minus amount takes Koban back, never below 0. Up to 100,000 at a time. <b>Recent awards</b> lists the last 15 with who gave them, and everything is in the activity log.',
            'To give an item instead of Koban, use <b>Give Koban or items</b> under Economy.']],
        ['Mottos', ['Players who unlock the Motto in the Profile Studio can put one line on their public page. Links, handles and blocked words are refused automatically. If one still needs to go, open <b>Rename, remove, combine</b> on the row and press <b>Clear motto</b>. The player can write a new one.']],
        ['Removing', ['<b>Remove</b> deletes a player from every board, including their points and Daily runs. Use it for cheaters or offensive accounts. Only a backup restore brings them back.']],
        ['Blocked words', [
            'The name filter already blocks slurs, sexual words, insults and names pretending to be the team, including look-alike spellings. Add your own words in the box (spaces or commas between) and <b>Save words</b>. New names are checked right away.']],
        ['Posting to X', [
            'Shows how many players connected X and how many posts the site sent this month.',
            'Posts are billed to the X developer account. X charges much more for a post that contains a link, so <b>Include the result link</b> is off by default.',
            'The <b>Monthly limit</b> caps posts across all players. When it\'s reached, players share with the normal X button until the month turns over. Credits are added at console.x.com under Billing.']],
        ['Download CSV', ['<b>Download CSV</b> gives every player with points, wins, games, holder status, wallet and id.']],
    ]],
    'team' => ['Team and access', 'Personal sign-ins for every admin, what each one can see and change, and the activity log.', [
        ['Your own sign-in first', [
            'Until the team is set up, everyone shares the setup password from config.php. On the sign-in screen, leave the name empty and use that password.',
            'Open <b>Team</b>, press <b>Add an admin</b>, add yourself with the role <b>Owner</b>, and copy the temporary password it shows. Sign out, sign in with your username, and pick your own password.',
            'From then on, give everyone their own account. Keep the setup password somewhere safe: it is the way back in if every owner is ever locked out.']],
        ['Adding an admin', [
            'Pick a username (and an email if you like; either signs them in), then a role. The admin gets a temporary password, shown to you once. Send it privately, never in a group chat.',
            'At their first sign-in they must choose their own password of 12 characters or more before they can do anything else.',
            'Tick <b>Email them the sign-in link</b> to send their username and the admin address. The password is never emailed.']],
        ['Roles and access', [
            'Every part of the admin has three levels: <b>No access</b> (the page is hidden), <b>View</b> (they can see it, every button is switched off) and <b>Edit</b>.',
            '<b>Owner</b>: everything. <b>Admin</b>: everything, including the team, but can\'t touch owners. <b>Moderator</b>: players, names, ideas and boards. <b>Support</b>: checks payments and delivers orders. <b>Treasurer</b>: prize pools and payouts. <b>Viewer</b>: sees everything but the team, changes nothing. <b>Custom</b>: set each area yourself.',
            'Giving away free Koban or items and sending prize payouts are separate areas, so you can let someone run the shop without letting them hand out freebies or move money.',
            'Nobody can give access they don\'t have, and only owners can add, change or remove owners. The last active owner can\'t be removed or demoted.']],
        ['Changing or removing someone', [
            'Press <b>Edit</b> beside them to change their role, areas, name, email or switch off <b>Can sign in</b>. Changes apply on their next click; switching someone off signs them out straight away.',
            '<b>New temporary password</b> signs them out everywhere and makes them pick a new password. <b>Remove</b> deletes the account for good.',
            'Five wrong passwords in a row lock an account for 15 minutes. A new temporary password unlocks it.']],
        ['Two-step sign-in', [
            'Owners and anyone who can send payouts must use it; everyone else can switch it on in <b>My account</b>. Scan the QR code with an authenticator app (Google Authenticator, Authy, 1Password, Microsoft Authenticator), type the code, and save the 8 recovery codes it shows once.',
            'Lost phone: sign in with a recovery code (each works once), then make new ones. If the codes are gone too, another owner presses <b>Reset two-step</b> in their Edit panel and they set it up again at their next sign-in.']],
        ['The activity log', [
            'Every sign-in, wrong password, download and change lands in the log at the bottom of Team, with who did it and what it touched. Passwords and tokens are never written to it.',
            'Pick a name in the list to see just that admin. Anything someone tried without the access for it shows as <b>Tried something without access</b>.']],
    ]],
    'telegram' => ['Telegram', 'Posting games, wrap-ups and big purchases to the $SHY chat.', [
        ['Setting it up', [
            'Everything goes through a Telegram bot you own. Bots are free and posting costs nothing.',
            '1. In Telegram, open <b>@BotFather</b>, send <code>/newbot</code>, pick a name and a username ending in <code>bot</code>. Copy the token it gives you.',
            '2. Add the bot to the $SHY group. If the group only lets admins post, make the bot an admin with just the post messages permission. In the group, send <code>/start</code> once.',
            '3. In the Telegram tab, paste the token and press <b>Save</b>, then <b>Find my chat</b>, pick the group, and press <b>Save and send a test</b>.']],
        ['What gets posted', [
            '<b>Live matches</b> with 2 or more real players: the winner and the final table.',
            '<b>Daily Challenge runs</b> and <b>Solo wins</b> as they happen. These are off at first because they can get busy. A per-hour limit keeps game posts in check.',
            '<b>Daily wrap-up</b>: the first visit to the site after midnight UTC posts yesterday\'s top 5. <b>Weekly League results</b>: the top 10 and their prizes when the week ends.',
            '<b>Daily Challenge morning call</b>: once a day at the Daily call hour (UTC), today\'s Daily is up, who leads and how many have played, with a Play button.',
            '<b>Shop purchases</b> at or above the amount you set (USD): the player name and what they bought. Amounts and wallets are never posted.',
            '<b>New releases</b>: after you upload a new site zip, the first visit (or the cron job) posts that version\'s release notes to the chat, once. They come from <code>scripts/releases.py</code>, the same notes as the Release notes page. To send them again, press <b>Post the latest release notes</b> in the Telegram tab.']],
        ['Commands anyone can use in the chat', [
            '<code>/start</code> the menu, <code>/play</code> a link to the game, <code>/daily</code> today\'s Daily so far, <code>/leaderboard</code> (or <code>/lb</code>, <code>/top</code>) every board ten players a page, with buttons to switch between the Weekly League, Holder Cup, Season, Daily, Live and All time boards, what each paid place is worth, and a <b>Me</b> button that shows whoever taps it their own place. <code>/leaderboard daily</code> or <code>/leaderboard live 2</code> opens a board and page straight away, <code>/me</code> your own numbers, <code>/notify</code> reminders, <code>/stats</code> games played today.',
            'The bot answers each command at most once every 20 seconds per chat, so it can\'t be used to spam. Saving the token in the Telegram tab is what switches the answers on.']],
        ['Playing inside Telegram (Mini App)', [
            'Press <b>Turn on the Play button</b> in the Telegram tab. In a private chat with the bot, a Play button next to the message box opens the game inside Telegram, signed in as that player.',
            'For a link that also works in the group, make a Mini App in @BotFather (<code>/newapp</code>, web address <code>https://shyonsol.io/play?tgapp=1</code>) and paste its short name in the Telegram tab. Posts then carry a <b>Play in Telegram</b> button and room invites open straight into the room.',
            'Buying in the shop still needs a wallet, so it opens in Phantom or Solflare from there.']],
        ['Linking and reminders', [
            'Players link Telegram from their profile (<b>Link Telegram</b>) or just by opening the game inside Telegram. <code>/me</code> shows their streak, Koban and League rank; <code>/notify</code> picks what the bot may message them about.',
            'Reminders: an evening nudge before a daily streak ends (from the hour you set, UTC), a morning nudge with today\'s Daily at the Daily call hour, only for players who haven\'t played it yet (on unless they switch it off), and tournament check-in, tables and results. Each goes out once a day at most. Untick <b>Send reminders</b> to stop them all.',
            'Reminders and tournament rounds run whenever people are on the site. For exact timing, add the cron job shown at the bottom of the Telegram tab in hPanel (Advanced, Cron Jobs, every 5 minutes).']],
        ['If nothing shows up', [
            'Check Logs for <b>Telegram messages that failed</b>. Most problems are the bot not being in the group, or not being allowed to post there. Remove and re-add it, then send a test.',
            'When the last 3 posts to the chat all failed, a red line at the top of the Telegram tab says so, with Telegram\'s reason. Failed posts are tried again on their own for about 8 hours. Once the bot is back, <b>Resend the last weekly results</b> and <b>Resend the last payout post</b> (under Send again) post them once more; a payout post is pinned again.',
            'To stop everything, tick <b>Disconnect the bot</b> and save, or untick each kind of post.']],
    ]],
    'tourneys' => ['Tournaments', 'Scheduling knockout tournaments and what players see.', [
        ['How a tournament runs', [
            'Players sign up on the Play page any time before the start, then <b>check in</b> during the last 30 minutes. Anyone who doesn\'t check in loses their spot.',
            'At the start, everyone checked in is seated at tables of up to 4 (bots fill empty seats). A table starts when all its players arrive, or after about 2 minutes with a bot for anyone missing. If every player at a table leaves, it plays out with bots.',
            'The best real player at each table moves on. When 4 or fewer are left they play the final table, which decides 1st to 4th. Koban prizes land straight away and the winner gets the <b>Cup Champion</b> title.',
            'Tournament games are live matches, so they also count toward the Weekly League like any live match.']],
        ['Scheduling one', [
            'Press <b>Schedule a tournament</b>, give it a name, a start time in UTC, the most players, and Koban prizes for 1st to 4th. An extra prize note (for example a $SHY prize you send by hand) is shown to players.',
            '<b>Repeat every week</b> books the next one at the same time when this one ends. <b>Announce it</b> posts it to the Telegram chat, which also gets an hour-before reminder, the start, each round and the champion.',
            '<b>Start now</b> starts early with everyone signed up. <b>Call off</b> stops it without prizes. Fewer than 2 checked-in players calls it off on its own.']],
    ]],
    'art' => ['Card art', 'Giving any card new art without a site update.', [
        ['Changing a card\'s art', [
            'Open <b>Card art</b> and pick a card. Each card page has its Midjourney prompt to copy, already sized at 13:8.',
            'Upload a PNG, JPG or WebP (up to 8 MB, ideally 1456 x 896 or bigger). The preview shows it the way players see it: the big card, the hand, the phone hand and the small lists.',
            'Click on the picture where the card should focus and press <b>Apply focus</b>: narrow spots like the phone hand only show the middle strip, so put the focus on the part that tells the story.',
            'Press <b>Publish this art</b>. Players see it within 5 minutes, everywhere a card appears. <b>Back to the original</b> undoes it.']],
        ['Game Design channel', ['Every upload is posted to the team\'s Game Design chat in Telegram with the picture, the card, who uploaded it and the file name and size, and again when it is published. Set the chat in <b>Telegram</b>, under Game Design channel: press <b>Find my chat</b> and <b>Use for Game Design</b>, or paste a link to any message in that chat (a message inside a topic sets the topic too). Add the bot to the chat first, then press <b>Save and send a test</b>.']],
        ['Where the files live', ['Published art is kept in the <code>card-art</code> folder of the website, outside the update zip, so uploading a new site version never removes it. The original uploads are kept in shy-data.']],
    ]],
    'houses' => ['Houses and ranked', 'Teams that compete every week, and the ranked live ladder.', [
        ['Houses', [
            'Players found a House (it costs Koban and needs a few games first) or join one, up to 20 members. Members\' weekly points add up on the House board at <code>/houses</code>.',
            'When the week ends, every member of the top 3 Houses who played that week gets Koban. Set the amounts in <b>Rewards</b>, under Houses, where you can also close a House with an offensive name.',
            'A player can join a new House once a week, so nobody hops to the leading House on Sunday night.']],
        ['Ranked', [
            'Live matches with at least two real players move Rank Points: +30 for a win, +5 for 2nd, less for 3rd and 4th. Bronze, Silver, Gold, Jade, then Shogun. Matches against bots only, and tournament tables, don\'t count.',
            'Each Season Scroll season is a ranked season. Points start again at 0, and the tier a player finished on pays Koban the next time they play, with a title for Jade and Shogun.']],
    ]],
    'growth' => ['Growth tools', 'Public pages, invites, the funnel, the Treasury and buying on the site.', [
        ['Public player pages', ['Every player has a page at <code>shyonsol.io/p/their_name</code> with their look, record, ranks, collection and latest win, which also shows as the link preview on X and Telegram. Players can make theirs private on their profile.']],
        ['Invite rewards', ['A new player who opens a friend\'s invite link and plays a few games earns the inviter Koban and gets a welcome gift, plus a bonus for the inviter if the new player holds $SHY. Settings and the latest invites are in <b>Shop</b>, under Invite rewards.']],
        //MC 2026-10-09 guide entries for the new ambassador count and tracked links
        ['Ambassadors', ['<b>Shop</b>, Ambassadors by month counts each inviter\'s invites that finished their games that month, plus holder bonuses, with their tier (Scout at 5, Recruiter at 15, Top ambassador) and wallet, so the monthly $SHY bonus can be paid straight from the table. Check the Same network column before paying: several invites from one internet connection can mean fake profiles.']],
        ['Partner groups', ['A joint event gets a 6 letter code. Send the partner\'s admin the two steps shown on the tournament: add our bot to their Telegram group, then type <code>/partner CODE</code> there. Their group then gets the announcement, a reminder the day before and an hour before, the start and the winners, all by itself, with sign-up links tracked as <code>partner-theirname</code>. Their admin can type <code>/partner off</code> to stop, and removing the bot stops it too. Weekly repeats keep the link. The switch is under <b>Telegram</b>, Joint events in partner groups.']],
        ['Tracked links', ['Add <code>?ref=tg-groupname</code> to any site link, or <code>?startapp=src_tg-groupname</code> to the Telegram mini app link, and new visitors from it show under that name in <b>Overview</b>, Where players drop off. Letters, numbers and hyphens only.']],
        ['Where players drop off', ['<b>Overview</b> shows new visitors and how many started a game, finished one, came back, connected a wallet and bought something, and where they came from (X, Telegram, invites, search). Only the game\'s random player id is used, nothing personal.']],
        ['Treasury page', ['Prize payouts show on <code>/treasury</code> by themselves, each with its transaction. Add other moves (a $SHY buy for the prize pool, a burn, liquidity) in <b>Rewards</b>, under Treasury page.']],
        ['Buy on the site', ['The token page has Jupiter\'s own swap box, so people buy $SHY without leaving the site. Swaps go straight between their wallet and Jupiter; the site never touches the funds. Every Buy $SHY button on the site leads there.']],
        ['Holder events', ['When you schedule a tournament you can make it $SHY holders only, a rank and up (Shy Scout to Shytoshi Supreme), or a joint event with a partner community: add their name, logo, link and token, and their holders can sign up with the wallet they connect.']],
        ['Watching and replays', ['Anyone can watch a live match or a tournament table from the Play page, and players see how many are watching. Every Daily run from now on can be replayed move by move from the Daily board or from its share link.']],
    ]],
    'listings' => ['Listings checklist', 'Getting $SHY shown right on the sites people check before they buy.', [
        ['Before you start', [
            'Have these ready: the contract <code>7d1vpt5eri79nETcL74Punhp3mGkeBgUkMdPWep6pump</code>, the website <code>https://shyonsol.io</code>, X <code>https://x.com/ShyOnSol_</code>, Telegram <code>https://t.me/shytoshisol</code>, the logo (800 x 800 PNG) and the Treasury page <code>https://shyonsol.io/treasury</code>, which shows every prize paid on chain.',
            '<b>Short description</b> (most forms cap it near 160 characters): <i>Shy on Solana ($SHY) is a community-run Solana token with a free card game, Shilluminati Online, and the Shytoshi Shadows NFTs.</i>',
            '<b>Longer description:</b> <i>$SHY is a community takeover on Solana. Holders play Shilluminati Online free in the browser or in Telegram, win weekly prizes paid in $SHY from the community wallet, and unlock holder perks. Every prize payout is public on the Treasury page.</i>']],
        ['DexScreener', [
            'Open the $SHY pair on DexScreener and choose <b>Update token info</b>. It is a paid service on DexScreener. Add the logo, a header image, the description and every link above.',
            'Check afterwards that the website and socials show under the chart, and that the logo shows in search.']],
        ['CoinGecko and CoinMarketCap', [
            'Open the $SHY page on each site (the token page links to both) and check it shows the Solana contract above, the website, X and Telegram.',
            'If anything is missing or wrong, use the update request on each site (CoinGecko: the request form, choose updating an existing listing; CoinMarketCap: Request update on the coin page). Include the Treasury page as proof of a working product.']],
        ['Jupiter', [
            'Search $SHY on jup.ag. If it doesn\'t show as verified, apply through Jupiter\'s token verification. Real holders, steady volume, a working website and active socials all count in your favour.']],
        ['Solscan', [
            'On the token\'s Solscan page, use <b>Update token info</b> to add the logo, website and socials, so wallets and explorers show them.']],
        ['After each listing', [
            'Post it in the Telegram chat and on X, and add it to the Official Links on the token page so people can check they\'re on the right one.']],
    ]],
    'boards' => ['Boards and holders', 'The Weekly, Daily, Holders and Live rooms tabs.', [
        ['Weekly', [
            'Pick a week to see its final board. Weekly points reset every Monday 00:00 UTC and each finished week is filed automatically.',
            'The CSV buttons download all players, or holders only, with wallet addresses for verified holders.']],
        ['Daily', ['Pick a day to see who played that Daily Challenge, their points, Regions and result. Only each player\'s first run counts.']],
        ['Holders', ['Everyone who connected a wallet, with the Shadows it holds and when it was last checked. Ownership is checked again every 6 hours, so a sold Shadow drops off on its own.']],
        ['Live rooms', ['Rooms tidy themselves up when they go quiet. Use <b>Close</b> only on a room that looks stuck; anyone in it goes back to the menu.']],
    ]],
    'system' => ['Logs and backups', 'Where problems show up, and how to roll back.', [
        ['Logs', [
            '<b>Emails that could not be sent</b>: suggestion emails the server couldn\'t send.',
            '<b>X connections and posts that failed</b>: what X said when a connect or a post didn\'t work.',
            '<b>Storage problems</b>: should always be empty. If not, tell the developer straight away.',
            '<b>Wallet verification errors</b> and <b>Rejected solo scores</b>: occasional entries are normal (a slow wallet, a cheat attempt). Lots at once means something is wrong.',
            '<b>Shop payments that could not be matched</b>: payments the shop couldn\'t tie to an order, with the reason.',
            '<b>Clear</b> empties a log once you have read it.']],
        ['Backups', [
            'After midnight UTC the cron job copies every important data file (scores, shop accounts, orders, rewards, wallets, devices, Telegram and X links, Houses, friends, the bounty, the Telegram settings, card art, the Daily secret, stipend claims, Fair Play rules and more) into the backups folder inside shy-data. Daily copies are kept for 14 days, weekly copies for 8 weeks. The tab lists every file, what it holds and its newest copy.',
            'The score copies have <b>Download</b> and <b>Restore</b>. Restore replaces all current scores with that copy; the current scores are saved first, so a restore can be undone. Everything else goes back by hand: the tab explains how.',
            'Owners also get <b>Download all data (zip)</b>: everything in shy-data in one file, including config.php with the private keys, so keep it private. A second button adds the card art pictures.',
            'Restore is for emergencies only, like a mistaken Remove or Combine. League points lost to the Oct 11, 2026 bug come back with <b>Recover lost League points</b> in Rewards, which only ever adds.']],
    ]],
    'site' => ['Site and files', 'Where everything lives, how updates go up, and the private settings file.', [
        ['The two folders', [
            '<b>public_html</b> is the website. Every update replaces it. Nothing private belongs here.',
            '<b>shy-data</b> sits next to public_html, not inside it, so it can\'t be opened from the web. It holds all scores, players, orders, suggestions, backups and config.php. Never delete it.']],
        ['Uploading an update', [
            '1. In Hostinger, open File Manager and choose <b>Access all files of Premium Web Hosting</b>.',
            '2. Open public_html, upload the zip, and extract it there, replacing existing files.',
            '3. Make sure <code>.htaccess</code> is still in public_html (the file manager can hide files starting with a dot). It gives the site its clean addresses like shyonsol.io/cards.',
            '4. Delete the uploaded zip, then open the site and this admin to check everything loads.',
            'Every update comes with an entry on the release notes page (shyonsol.io/updates).']],
        ['Languages and the Stats page', [
            'The site speaks 11 languages: English, Türkçe, Español, Português, Français, Deutsch, Русский, Tiếng Việt, Bahasa Indonesia, 中文 and 한국어. Visitors get their browser\'s language the first time and can switch with the globe button in the menu or the footer. Release notes and Medium posts stay in English. This admin is English only.',
            'Anything new that has no translation yet shows in English until the next update adds it, so nothing ever shows up blank.',
            '<b>shyonsol.io/stats</b> is public: games per day, results, busy hours, card win rates, top players and Shadows. It counts every scored game and saves a running tally in <code>shy-data/stats.php</code> (refreshed every minute). Deleting that file only resets the charts; it rebuilds from players\' recent games.']],
        ['config.php', [
            'In shy-data. It holds the private keys:',
            '<code>helius</code>: Solana data (holders, prices, payment checks). <code>admin_hash</code>: the admin password, scrambled. <code>x_client_id</code> and <code>x_client_secret</code>: Connect X (console.x.com). <code>stripe_secret</code> and <code>stripe_webhook</code>: card payments, once set up. <code>mw</code>: only if the marketing wallet ever changes.',
            'Edit it carefully: every line ends with a comma, and the file must start with <code>&lt;?php</code>. A broken config.php stops the site, so keep a copy before editing.']],
        ['Accounts the site depends on', [
            '<b>Hostinger</b>: hosting and the domain. <b>Helius</b>: Solana data. <b>X developer console</b> (console.x.com): Connect X and the credits posts are billed to. <b>Medium</b> (@SHY_Community): stories shown on shyonsol.io/story, refreshed every half hour. <b>Phantom</b>: the marketing wallet.']],
    ]],
    'help' => ['Troubleshooting', 'Common questions and what to do.', [
        ['"I paid but didn\'t get my Koban"', [
            'Ask the player to open the shop\'s <b>History</b> tab, which checks again on its own and explains any problem.',
            'If it still isn\'t delivered, ask for the transaction link from Phantom, find the order in Shop, paste the link into Check on Solana and press it.',
            'If Solana shows the payment arrived but the check still fails, confirm the amount on Solscan and use Deliver by hand.']],
        ['"It says my name is taken"', ['Someone, possibly an older guest profile of theirs, already has it. If it\'s their own old profile, Combine the old one into their current one, then they can set the name on their profile page.']],
        ['"My X post failed"', [
            'Check Logs for X errors. A balance of $0 on console.x.com, or the monthly limit in Players, stops posts.',
            'Expired connections fix themselves when the player reconnects X from their profile.']],
        ['"The Ideas board is empty"', ['Suggestions only show after you press Put on the board. Allow a minute for the board to update.']],
        ['"I can\'t sign in to the admin"', ['After 8 wrong tries, wait 15 minutes. If the password is lost, make a new password line (on another device that\'s signed in, or ask the developer) and put it in config.php.']],
        ['Something looks broken after an update', ['Check that .htaccess and every folder extracted into public_html, then hard-refresh the browser (Ctrl+Shift+R, or Cmd+Shift+R on a Mac). If it\'s still wrong, upload the previous zip again; shy-data is untouched by updates.']],
    ]],
    ];
}

function admin_guide($csrf) {
    $secs = guide_sections();
    $first = array_key_first($secs);
    echo '<div class="guide"><nav class="g-tabs" role="tablist" aria-label="Guide sections">';
    foreach ($secs as $k => $s) echo '<button type="button" role="tab" data-g="' . $k . '"' . ($k === $first ? ' class="on" aria-selected="true"' : ' aria-selected="false"') . '>' . h($s[0]) . '</button>';
    echo '</nav>';
    foreach ($secs as $k => $s) {
        echo '<section class="g-panel" id="g-' . $k . '" role="tabpanel"' . ($k === $first ? '' : ' hidden') . '><header class="g-head"><h2>' . h($s[0]) . '</h2><p>' . h($s[1]) . '</p></header><div class="g-cards">';
        foreach ($s[2] as [$title, $paras]) {
            $ol = preg_match('/^\d\. /', strip_tags($paras[0]));
            echo '<article class="g-card"><h3>' . h($title) . '</h3>';
            foreach ($paras as $p) echo '<p' . (preg_match('/^\d\. /', strip_tags($p)) ? ' class="g-step"' : '') . '>' . $p . '</p>';
            echo '</article>';
        }
        if ($k === 'start') {
            echo '<article class="g-card g-tool" id="g-hash"><h3>Make a new password line</h3><p>Type a new admin password twice. Use at least 12 characters; a few random words joined together works well. Nothing is saved here: you copy the line into config.php yourself.</p>' .
                '<form method="post" class="bar"><input type="hidden" name="csrf" value="' . h($csrf) . '"><input type="password" name="pw1" placeholder="New password" minlength="12" autocomplete="new-password" required><input type="password" name="pw2" placeholder="Same again" minlength="12" autocomplete="new-password" required><button name="do" value="hash-tool">Make the line</button></form></article>';
        }
        echo '</div></section>';
    }
    echo '</div>';
}
