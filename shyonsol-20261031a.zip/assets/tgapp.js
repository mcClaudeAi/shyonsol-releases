// The game opened inside Telegram (a Mini App). Loaded before the game so a room invite from Telegram opens that room.
// Signs the player in as the profile linked to their Telegram account, or links this profile the first time.
(function () {
  "use strict";
  var q = location.search;
  // opened in a wallet app from Telegram (?claim=CODE): sign in as the Telegram profile, then connect the wallet
  var cl = /[?&]claim=([A-Za-z0-9]{10})/.exec(q);
  if (cl) {
    var ls = function (k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } };
    var rnd = function (n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); };
    var pid0 = ls("shy-lb-pid") || rnd(8), key0 = ls("shy-lb-key") || rnd(16);
    document.documentElement.classList.add("ho-claim");
    fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "claim", code: cl[1], pid: pid0, key: key0 }) })
      .then(function (r) { return r.json(); }).catch(function () { return { ok: false }; })
      .then(function (j) {
        if (j && j.ok) {
          ls("shy-lb-pid", j.pid); ls("shy-lb-key", j.key);
          if (j.name) ls("shy-lb-name", j.name);
          ls("shy-holder", ""); ls("shy-avatar", "");
          ls("shy-ho", JSON.stringify({ c: cl[1], pid: j.pid, t: Date.now(), app: /[?&]app=1/.test(q) ? 1 : 0, pf: /[?&]pf=1/.test(q) ? 1 : 0 }));   //MC 2026-10-15 app: from the home screen app; 2026-10-18 pf: from the Profile page in a plain browser
          location.replace(location.pathname + "?connect=1#game");
        } else {
          try { sessionStorage.setItem("shy-ho-err", (j && j.error) || (/[?&]pf=1/.test(q) ? "That link didn't work. Go back to your browser and tap the wallet button again." : /[?&]app=1/.test(q) ? "That link didn't work. Go back to the app and tap Open in Phantom again." : "That link didn't work. Go back to Telegram and tap Connect again.")); } catch (e) {}
          location.replace(location.pathname + "#game");
        }
      });
    return;
  }
  var inApp = /[?&]tgapp=1/.test(q) || /tgWebAppData=/.test(location.hash);
  try { if (inApp) sessionStorage.setItem("shy-tgapp", "1"); else inApp = sessionStorage.getItem("shy-tgapp") === "1"; } catch (e) {}
  if (!inApp) return;
  document.documentElement.classList.add("tgapp");
  // a room invite shared in Telegram (t.me/bot/app?startapp=room_ABCDE) opens that room
  var m = /[?&]tgWebAppStartParam=(?:room|join)_([A-Za-z0-9]{5})/.exec(q);   //MC 2026-10-10 join_ is a challenge: play.js joins at once
  if (m && !/[?&]room=/.test(q)) try { history.replaceState(null, "", location.pathname + q + "&room=" + m[1] + location.hash); } catch (e) {}
  // Duels, rematches and friend links from the bot's messages (startapp=duel_ID, duelvs_ID, friend_ID, friends)
  var f = /[?&]tgWebAppStartParam=(duel|duelvs|friend)_([a-f0-9]{6,10})/.exec(q), fs = /[?&]tgWebAppStartParam=friends(?:&|$)/.test(q);
  if (f && !new RegExp("[?&]" + f[1] + "=").test(q)) try { history.replaceState(null, "", location.pathname + q + "&" + f[1] + "=" + f[2] + location.hash); } catch (e) {}
  else if (fs && !/[?&]friends=/.test(q)) try { history.replaceState(null, "", location.pathname + q + "&friends=1" + location.hash); } catch (e) {}
  else if (/[?&]tgWebAppStartParam=boss(?:&|$)/.test(q) && !/[?&]boss=/.test(q)) try { history.replaceState(null, "", location.pathname + q + "&boss=1" + location.hash); } catch (e) {}   //MC 2026-10-12 the Shogun
  else if (/[?&]tgWebAppStartParam=elite(?:&|$)/.test(q) && !/[?&]elite=/.test(q)) try { history.replaceState(null, "", location.pathname + q + "&elite=1" + location.hash); } catch (e) {}   //MC 2026-10-30 Shogun Elite
  //MC 2026-10-09 marketing links into the mini app (startapp=src_tg-groupname) now count under that name in the admin
  //funnel. Telegram only passes letters, numbers, _ and - in startapp, so ?ref= on the mini app link never got through
  //and every one of those visits showed as telegram-app. Runs before app.js, which reads ?ref= on the first visit.
  var sp = /[?&]tgWebAppStartParam=src_([A-Za-z0-9-]{1,40})(?:&|$)/.exec(location.search);
  if (sp && !/[?&](ref|utm_source)=/.test(location.search)) try { history.replaceState(null, "", location.pathname + location.search + "&ref=" + sp[1].toLowerCase() + location.hash); } catch (e) {}

  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  function call(body) {
    return fetch("/api/tglink.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); }).catch(function () { return { ok: false }; });
  }
  function signIn(W) {
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid) { pid = hex(8); store("shy-lb-pid", pid); }
    if (!key) { key = hex(16); store("shy-lb-key", key); }
    call({ a: "webapp", initData: W.initData, pid: pid, key: key }).then(function (j) {
      if (!j || !j.ok) return;
      window.SHY_TG = { invite: j.invite || "" };
      if (j["switch"] && j["switch"] !== pid) {
        // this Telegram account already has a profile: use it here
        store("shy-lb-pid", j["switch"]); store("shy-lb-key", j.key);
        if (j.name) store("shy-lb-name", j.name);
        var once = false; try { once = sessionStorage.getItem("shy-tg-sw") === "1"; sessionStorage.setItem("shy-tg-sw", "1"); } catch (e) {}
        if (!once) location.reload();
        return;
      }
      // a first-time player starts with their Telegram first name, if it's a name the game accepts
      if (!store("shy-lb-name") && !j.name && j.tg && j.tg.fn) {
        var n = String(j.tg.fn).replace(/[^A-Za-z0-9 _.\-]/g, "").trim().slice(0, 16);
        if (n.length >= 2) { store("shy-lb-name", n); var inp = document.getElementById("g-name"); if (inp && !inp.value) inp.value = n; }
      }
      // ask once whether the bot may send streak reminders
      if (W.requestWriteAccess && !store("shy-tg-wa")) {
        store("shy-tg-wa", "1");
        try { W.requestWriteAccess(function (ok) { if (ok) call({ a: "webapp", initData: W.initData, pid: store("shy-lb-pid"), key: store("shy-lb-key"), dm: 1 }); }); } catch (e) {}
      }
    });
  }
  var s = document.createElement("script");
  s.src = "https://telegram.org/js/telegram-web-app.js";
  s.async = true;
  s.onload = function () {
    var W = window.Telegram && window.Telegram.WebApp;
    if (!W) return;
    try {
      W.ready(); W.expand();
      if (W.setHeaderColor) W.setHeaderColor("#0d0920");
      if (W.setBackgroundColor) W.setBackgroundColor("#0d0920");
      if (W.disableVerticalSwipes) W.disableVerticalSwipes();   // dragging cards must never close the app
    } catch (e) {}
    if (W.initData) signIn(W);
    //MC 2026-10-09 Telegram's own Back button (top left, and Android's back gesture) now closes whatever is open in
    //the game: checkout, the shop, Friends, the end screen, a room, or offers to leave a game in progress. Before, the
    //only thing at the top was Telegram's X, which closes the whole app, and Android's back did the same. Players on
    //the end screen or in the shop had no way out but closing and reopening the game.
    //The list runs top layer first; the first one showing on screen wins.
    var BACK = ["#checkout:not([hidden]) [data-co-close]", ".xc-panel [data-xc-close]", ".idea-panel [data-idea-close]",
      "#shop:not([hidden]) .cd-pop [data-cd-close]", "#shop:not([hidden]) .sh-x", "#fr:not([hidden]) .fr-x",
      "#g-quit:not([hidden]) #g-quit-no", "#g-end:not([hidden]) [data-game-menu]", "#g-wend:not([hidden]) [data-watch-stop]", ".g-intro", "#g-room:not([hidden]) #g-room-leave", "#g-quit-btn"];
    function backTarget() {
      for (var i = 0; i < BACK.length; i++) {
        var el = document.querySelector(BACK[i]);
        if (el && el.getClientRects().length && getComputedStyle(el).visibility !== "hidden") return el;
      }
      return null;
    }
    if (W.BackButton && W.BackButton.onClick) {
      var shown = false, queued = false;
      var sync = function () {
        queued = false;
        var on = !!backTarget();
        if (on === shown) return;
        shown = on;
        try { on ? W.BackButton.show() : W.BackButton.hide(); } catch (e) {}
      };
      W.BackButton.onClick(function () { var el = backTarget(); if (el) el.click(); setTimeout(sync, 260); });
      new MutationObserver(function () { if (!queued) { queued = true; requestAnimationFrame(sync); } })
        .observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["hidden", "class"] });
      sync();
    }
    // back from connecting a wallet: if that wallet already had a profile, Telegram now plays as it
    document.addEventListener("visibilitychange", function () {
      var t = +(store("shy-ho-wait") || 0);
      if (document.hidden || !W.initData || !t || Date.now() - t > 1800000) return;
      try { sessionStorage.removeItem("shy-tg-sw"); } catch (e) {}
      signIn(W);
    });
  };
  document.head.appendChild(s);
})();
