// Sign in with Google or Apple for a free Phantom wallet, for players with no wallet app (Telegram, phones, desktops
// without an extension). The wallet is Phantom's own embedded wallet: non-custodial, the player can open it later in the
// Phantom app with the same Google or Apple account, and nothing about it is held here.
// It acts like any wallet the site already knows: play.js and profile.js ask it for connect() and signMessage(), so
// linking it is the same signed message as Phantom or Solflare and nothing on the server changes.
// Sign-in leaves the page and comes back (OAuth). shy-ew in localStorage remembers that a sign-in is under way.
//MC 2026-10-15 first version. The SDK comes from jsDelivr (pinned) and only loads when someone taps the button or
//   comes back from signing in, so no page pays for it otherwise. The App ID comes from the holder status reply.
(function () {
  "use strict";
  var SDK_URL = "https://cdn.jsdelivr.net/npm/@phantom/browser-sdk@2.0.4/+esm";
  var app = "", mod = null, sdk = null;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function pend() { var p = null; try { p = JSON.parse(ls("shy-ew") || "null"); } catch (e) {} return p && Date.now() - p.t < 20 * 60000 ? p : null; }
  function back() { return location.origin + location.pathname + "?ew=back" + (location.hash || ""); }
  async function load() {
    if (sdk) return sdk;
    if (!app) throw new Error("Wallet sign-in isn't set up yet.");
    mod = mod || await import(SDK_URL);
    sdk = new mod.BrowserSDK({ providers: ["google", "apple"], addressTypes: [mod.AddressType.solana], appId: app, authOptions: { redirectUrl: back() }, autoConnect: false });
    return sdk;
  }
  function b64url(s) { s = String(s).replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  function addrOf(s) {
    var pk = s.solana && s.solana.publicKey;
    if (pk) return String(pk);
    return "";
  }
  // a provider object shaped like window.phantom.solana, for the existing connect code
  function provider(s) {
    return {
      isEmbedded: true,
      get publicKey() { var a = addrOf(s); return a ? { toString: function () { return a; } } : null; },
      connect: async function () { var a = addrOf(s); if (!a) throw new Error("The sign-in didn't finish. Try again."); return { publicKey: { toString: function () { return a; } } }; },
      signMessage: async function (bytes) {
        var r = await s.solana.signMessage(new TextDecoder().decode(bytes));
        return { signature: b64url(r.rawSignature || r.signature) };
      }
    };
  }
  window.ShyEW = {
    // the holder status reply carries ew: {app} when the team turned it on
    set: function (cfg) { app = cfg && cfg.app ? String(cfg.app) : ""; },
    ready: function () { return !!app; },
    pending: function () { return !!pend() || /[?&]ew=back/.test(location.search); },
    // start a sign-in: leaves the page for Google or Apple and comes back to this page
    start: async function (which) {
      var s = await load();
      ls("shy-ew", JSON.stringify({ p: which, t: Date.now() }));
      await s.connect({ provider: which === "apple" ? "apple" : "google" });   // resolves when it didn't need to leave (an existing session)
      return provider(s);
    },
    // back from signing in: finish the session and hand back a wallet, or null
    resume: async function () {
      if (!this.pending()) return null;
      var p = pend();
      try {
        // the SDK reads its own sign-in result from this address, so the address is only tidied once it's done
        var s = await load();
        try { await s.autoConnect(); } catch (e) {}
        for (var i = 0; i < 40 && !addrOf(s); i++) await new Promise(function (r) { setTimeout(r, 150); });
        if (!addrOf(s) && p) { try { await s.connect({ provider: p.p === "apple" ? "apple" : "google" }); } catch (e) {} }
        ls("shy-ew", null);
        try { history.replaceState(null, "", location.pathname + (location.hash || "")); } catch (e) {}
        return addrOf(s) ? provider(s) : null;
      } catch (e) { ls("shy-ew", null); return null; }
    },
    // buttons for a wallet box; data-ew is handled by the page
    buttons: function (cls) {
      if (!app) return "";
      return '<button class="btn ' + (cls || "btn-line btn-sm") + ' ew-btn" data-ew="google"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M22.6 12.2c0-.8-.1-1.5-.2-2.2H12v4.2h6a5.1 5.1 0 0 1-2.2 3.4v2.8h3.6c2.1-1.9 3.2-4.8 3.2-8.2z"/><path fill="#34A853" d="M12 23c3 0 5.5-1 7.3-2.7l-3.6-2.8c-1 .7-2.2 1.1-3.7 1.1-2.9 0-5.3-1.9-6.2-4.6H2.1v2.9A11 11 0 0 0 12 23z"/><path fill="#FBBC05" d="M5.8 14c-.2-.7-.4-1.3-.4-2s.1-1.3.4-2V7.1H2.1A11 11 0 0 0 1 12c0 1.8.4 3.4 1.1 4.9L5.8 14z"/><path fill="#EA4335" d="M12 5.4c1.6 0 3.1.6 4.2 1.7l3.2-3.2A11 11 0 0 0 2.1 7.1L5.8 10c.9-2.7 3.3-4.6 6.2-4.6z"/></svg>Google</button>' +
        '<button class="btn ' + (cls || "btn-line btn-sm") + ' ew-btn" data-ew="apple"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9a4.8 4.8 0 0 0-3.8-2c-1.6-.2-3.1.9-3.9.9-.8 0-2-.9-3.4-.9a5 5 0 0 0-4.2 2.6c-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6 1.3-.1 1.8-.8 3.3-.8s2 .8 3.4.8 2.2-1.3 3.1-2.5c1-1.4 1.4-2.8 1.4-2.9-.1 0-2.6-1-2.6-4.1zM13.9 5c.7-.9 1.2-2 1.1-3.2-1 0-2.3.7-3 1.6-.7.8-1.2 2-1.1 3.1 1.1.1 2.3-.6 3-1.5z"/></svg>Apple</button>';
    }
  };
})();
