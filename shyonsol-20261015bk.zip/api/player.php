<?php
// Public player pages: shyonsol.io/p/<name>.
// GET ?page=<name>  -> the page itself, with the player's name and their profile card as the link preview (see .htaccess)
// GET ?a=get&n=<name or 6-letter id> -> the public record as JSON
// POST {a: stamp, pid, key, to: <6-letter id>, s: respect|gg|fire|legend} -> leave a stamp on someone's page (one a day each)
// Never shown here: wallets, Koban, purchases, or anything a player didn't already show on a leaderboard.

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/friendslib.php';   //MC 2026-10-09 for the Online now dot
const PP_SITE = 'https://shyonsol.io';
define('STAMPS', DATA_DIR . '/stamps.php');    // [pid => ['c' => [kind => count], 'by' => [visitor pid => [day, kind]]]]
const STAMP_KINDS = ['respect', 'gg', 'fire', 'legend'];
//MC 2026-10-09 the Visit Counter (a Profile Studio unlock): page opens per player, each visitor once a day. Visitors are
//kept only as a short hash of their connection for the day, then forgotten. Counted for everyone from now on, shown
//only on pages that bought the unlock.
define('VISITS', DATA_DIR . '/visits.php');    // [pid => ['n' => total, 'd' => day, 'v' => [visitor hash => 1]]]
function pp_visit($pid) {
    $who = substr(hash('sha256', client_ip() . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|visit'), 0, 12);
    with_lock(function () use ($pid, $who) {
        $all = load(VISITS); $x = $all[$pid] ?? ['n' => 0, 'd' => '', 'v' => []];
        if ($x['d'] !== today()) { $x['d'] = today(); $x['v'] = []; }
        if (isset($x['v'][$who]) || count($x['v']) >= 2000) return;
        $x['v'][$who] = 1; $x['n']++;
        $all[$pid] = $x; save(VISITS, $all);
    });
}
function pp_visits($pid) { return (int)(load(VISITS)[$pid]['n'] ?? 0); }
function pp_stamps($pid, $all = null) { $x = ($all ?? load(STAMPS))[$pid]['c'] ?? []; $o = []; foreach (STAMP_KINDS as $k) $o[$k] = (int)($x[$k] ?? 0); return $o; }

// a name from the address: /p/Night_Crane and /p/night%20crane both find "Night Crane"; a 6-letter player id works too
function pp_find($players, $q) {
    $q = trim(rawurldecode((string)$q));
    if ($q === '' || strlen($q) > 40) return null;
    $want = strtolower($q); $alt = strtolower(str_replace('_', ' ', $q));
    $best = null; $bestPts = -1;
    foreach ($players as $pid => $p) {
        $n = strtolower((string)($p['name'] ?? ''));
        if ($n === '' || empty($p['games'])) continue;
        if ($n === $want || $n === $alt) { $pts = (int)($p['points'] ?? 0); if ($pts > $bestPts) { $best = $pid; $bestPts = $pts; } }
    }
    if ($best === null && preg_match('/^[a-f0-9]{6}$/', $want)) foreach ($players as $pid => $p) if (strpos($pid, $want) === 0 && !empty($p['games'])) return $pid;
    return $best;
}
//MC 2026-10-09 ties all got the same rank here (only strictly higher scores counted), so a page could say #1 while
// /profile and the boards said #4. Now it sorts exactly like lb.php board() and profile.php place_in(): score, then wins,
// then fewer games, and takes the position
function pp_place($players, $pid, $keep, $score) {
    $rows = [];
    foreach ($players as $id => $p) if ($keep($p)) $rows[] = [$id, $score($p)];
    if (!$keep($players[$pid] ?? [])) return ['rank' => 0, 'of' => 0];
    usort($rows, fn($x, $y) => $y[1] <=> $x[1]);
    foreach ($rows as $i => $r) if ($r[0] === $pid) return ['rank' => $i + 1, 'of' => count($rows)];
    return ['rank' => 0, 'of' => count($rows)];
}
function pp_slug($name) { return str_replace(' ', '_', $name); }

// the public record
function pp_record($players, $pid) {
    $p = $players[$pid];
    $hol = load(HOLDERS); $h = $hol[$pid] ?? null;
    $tier = holder_tier($h);
    $eco = load(ECO);
    $acc = isset($eco[$pid]) ? eco_get($eco, $pid) : null;
    $cos = $acc ? eco_public($acc, $tier) : [];
    $wk = week_key();
    $holder = !empty($p['holder']) && !empty($p['avatar']);
    $mastered = [];
    if ($acc) {
        $deck = deck_cards();
        arsort($acc['cm']);
        foreach (array_slice($acc['cm'], 0, 3, true) as $c => $n) if (isset($deck[$c]) && mastery_level($n) >= 1) $mastered[] = ['id' => $c, 'name' => $deck[$c]['name'], 'plays' => (int)$n, 'lv' => mastery_level($n), 'lvName' => MASTERY_NAMES[mastery_level($n)], 'fin' => $acc['veq'][$c] ?? ''];
    }
    $hist = array_map(fn($g) => ['r' => $g['r'] ?? '', 'm' => $g['m'] ?? '', 'g' => (int)($g['g'] ?? 0), 'p' => (int)($g['p'] ?? 0), 't' => (int)($g['t'] ?? 0)], array_slice($p['hist'] ?? [], 0, 8));
    $live = ['w' => (int)($p['pvp_w'] ?? 0), 'g' => (int)($p['pvp_g'] ?? 0)];
    return [
        'name' => $p['name'], 'slug' => pp_slug($p['name']), 'tag' => substr($pid, 0, 6), 'since' => (int)($p['since'] ?? 0), 'last' => (int)($p['last'] ?? 0),
        'online' => isset(fr_online_list(load(PRESENCE), $players)[$pid]),
        'img' => $holder ? shadow_img($p['avatar']) : '', 'avatar' => $holder ? (string)$p['avatar'] : '', 'aura' => $holder ? shadow_aura($p['avatar']) : '',
        'holder' => !empty($p['holder']), 'tier' => $tier, 'cos' => $cos, 'x' => $p['xu'] ?? '',
        'trophies' => array_slice(trophies_of($pid), 0, 12),   //MC 2026-10-15 trophies minted to their wallet (trophylib.php)
        //MC 2026-10-10 the rank above theirs and what it takes, without the gap: the gap would give away the player's $SHY balance
        'tierNext' => ($nx = holder_next($h)) && $tier !== '' ? ['tier' => $nx['tier'], 'name' => HOLDER_NAMES[$nx['tier']], 'at' => $nx['at']] : null,
        'stats' => ['points' => (int)($p['points'] ?? 0), 'wins' => (int)($p['wins'] ?? 0), 'games' => (int)($p['games'] ?? 0), 'best' => (int)($p['best'] ?? 0),
            'week' => ($p['wk'] ?? '') === $wk ? (int)($p['wpts'] ?? 0) : 0, 'badges' => (int)($p['badges'] ?? 0), 'live' => $live, 'streak' => $acc ? (int)($acc['st']['best'] ?? ($acc['st']['n'] ?? 0)) : 0],
        'ranks' => [
            'all' => pp_place($players, $pid, fn($x) => !empty($x['games']), fn($x) => [$x['points'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]),
            'week' => pp_place($players, $pid, fn($x) => ($x['wk'] ?? '') === $wk && !empty($x['wpts']), fn($x) => [$x['wpts'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]),
            'live' => pp_place($players, $pid, fn($x) => !empty($x['pvp_g']), fn($x) => [$x['lpts'] ?? 0, $x['pvp_w'] ?? 0, -($x['pvp_g'] ?? 0)])],
        'rank' => rank_show($p), 'season' => season_no(),
        //MC 2026-10-13 flaunt: only what the holder switched on themselves (profile.php a=flaunt), rounded, never the wallet
        'flaunt' => (function () use ($p, $h, $acc) {
            $fl = $p['fl'] ?? null; if (!$fl || empty($h['wallet'])) return null;
            $out = [];
            if (!empty($fl['shy']) && isset($h['shy_bal'])) $out['shy'] = (int)round($h['shy_bal']);
            if (!empty($fl['koban']) && $acc) $out['koban'] = (int)$acc['koban'];
            return $out ?: null;
        })(),
        'house' => (function () use ($pid) { $H = houses(); $id = house_of($pid, $H); return $id ? ['tag' => $H['h'][$id]['tag'], 'name' => $H['h'][$id]['name'], 'crest' => $H['h'][$id]['crest'], 'color' => $H['h'][$id]['color']] : null; })(),
        'col' => $acc ? collection_show($acc) : null,
        'mastered' => $mastered, 'games' => $hist,
        'card' => !empty($p['lsh']) && is_file(DATA_DIR . '/shares/' . $p['lsh'] . '.json') ? $p['lsh'] : '',
        'page' => $acc ? (function ($pg) use ($pid) { if (isset($pg['visits'])) $pg['visits'] = pp_visits($pid); return $pg; })(page_public($acc, $tier)) : [], 'stamps' => pp_stamps($pid),
    ];
}

$players = load(PLAYERS);

if (isset($_GET['page'])) {
    $pid = pp_find($players, $_GET['page']);
    $tpl = @file_get_contents(dirname(__DIR__) . '/player.html');
    if (!$pid || $tpl === false) {
        http_response_code(404); header('Content-Type: text/html; charset=utf-8'); header('X-Robots-Tag: noindex');
        @readfile(dirname(__DIR__) . '/404.html'); exit;
    }
    $hidden = !empty($players[$pid]['hide']);
    if (!$hidden) pp_visit($pid);
    $rec = $hidden ? ['hidden' => true, 'name' => $players[$pid]['name'], 'slug' => pp_slug($players[$pid]['name'])] : pp_record($players, $pid);
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $name = $players[$pid]['name'];
    $url = PP_SITE . '/p/' . rawurlencode(pp_slug($name));
    $title = $name . ' on Shilluminati Online | Shy on Solana';
    $desc = $hidden ? $name . ' plays Shilluminati Online, the free $SHY card game.'
        : $name . ': ' . number_format($rec['stats']['points']) . ' points, ' . number_format($rec['stats']['wins']) . ' wins in ' . number_format($rec['stats']['games']) . ' games'
          . ($rec['ranks']['all']['rank'] ? ', #' . $rec['ranks']['all']['rank'] . ' all time' : '') . '. Play Shilluminati Online free and take them on.';
    //MC 2026-10-10 &v= follows SHARE_LOOK in share.php, so X fetches the woodblock card instead of its cached old one
    //MC 2026-10-12 the preview is now the player's profile card (share.php ?p=), not their last shared game. &h= changes
    //   when anything on the card does, so X and Telegram fetch the new picture instead of their cached one.
    $img = !$hidden ? PP_SITE . '/api/share.php?p=' . $rec['tag'] . '&h=' . substr(sha1(json_encode([$rec['stats'], $rec['ranks']['all'], $rec['cos'], $rec['page']['motto'] ?? '', $rec['page']['show'][0]['id'] ?? '', $rec['house'], $rec['avatar'], $rec['rank'], $rec['x']])), 0, 8) : null;
    // the page from the build, with this player's title, description, preview and address
    $tpl = preg_replace('#<title>.*?</title>#s', '<title>' . $e($title) . '</title>', $tpl, 1);
    $tpl = preg_replace('#(<meta (?:name="description"|property="og:description"|name="twitter:description") content=")[^"]*#', '${1}' . $e($desc), $tpl);
    $tpl = preg_replace('#(<meta (?:property="og:title"|name="twitter:title") content=")[^"]*#', '${1}' . $e($title), $tpl);
    $tpl = preg_replace('#(<link rel="canonical" href=")[^"]*#', '${1}' . $e($url), $tpl);
    $tpl = preg_replace('#(<meta property="og:url" content=")[^"]*#', '${1}' . $e($url), $tpl);
    if ($img) $tpl = preg_replace('#(<meta (?:property="og:image"|name="twitter:image") content=")[^"]*#', '${1}' . $e($img), $tpl);
    $tpl = str_replace('<!--PP-DATA-->', '<script>window.SHY_PLAYER=' . json_encode($rec, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) . ';</script>', $tpl);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-cache');
    if ($hidden) header('X-Robots-Tag: noindex');
    echo $tpl;
    exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_GET['a'] ?? '') === 'get') {
    $pid = pp_find($players, $_GET['n'] ?? '');
    if (!$pid) fail('No player by that name.', 404);
    if (!empty($players[$pid]['hide'])) out(['ok' => true, 'player' => ['hidden' => true, 'name' => $players[$pid]['name']]]);
    out(['ok' => true, 'player' => pp_record($players, $pid)]);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $b = json_decode((string)file_get_contents('php://input'), true) ?: [];
    if (($b['a'] ?? '') !== 'stamp') fail('unknown action');
    $me = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? ''); $to = strtolower((string)($b['to'] ?? '')); $kind = (string)($b['s'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/', $me) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('Play a game first, then you can leave stamps.', 403);
    if (!preg_match('/^[a-f0-9]{6}$/', $to) || !in_array($kind, STAMP_KINDS, true)) fail('bad stamp');
    $r = with_lock(function () use ($me, $key, $to, $kind) {
        $l = load(LIMITS); $ok = rate_ok($l, 'stamp:' . client_ip(), 60, 3600); save(LIMITS, $l);
        if (!$ok) return ['err' => 'Slow down a little.'];
        $players = load(PLAYERS);
        if (empty($players[$me]['games']) || !key_ok($me, hash('sha256', $key), $players)) return ['err' => 'Play a game first, then you can leave stamps.'];
        $pid = null; foreach ($players as $id => $p) if (strpos($id, $to) === 0 && !empty($p['games'])) { $pid = $id; break; }
        if (!$pid || !empty($players[$pid]['hide'])) return ['err' => 'No player there.'];
        if ($pid === $me) return ['err' => 'Stamps are for other players\' pages.'];
        $all = load(STAMPS); $x = $all[$pid] ?? ['c' => [], 'by' => []];
        $day = today();
        if (($x['by'][$me][0] ?? '') === $day) return ['err' => 'You already stamped this page today. Come back tomorrow.', 'stamps' => pp_stamps($pid, $all), 'mine' => $x['by'][$me][1]];
        $x['c'][$kind] = (int)($x['c'][$kind] ?? 0) + 1;
        $x['by'][$me] = [$day, $kind];
        $x['by'] = array_filter($x['by'], fn($v) => $v[0] >= gmdate('Y-m-d', time() - 2 * 86400));
        $all[$pid] = $x; save(STAMPS, $all);
        return ['stamps' => pp_stamps($pid, $all), 'mine' => $kind];
    });
    if (isset($r['err'])) out(['ok' => false, 'error' => $r['err']] + array_diff_key($r, ['err' => 1]), 400);
    out(['ok' => true] + $r);
}
fail('unknown action');
