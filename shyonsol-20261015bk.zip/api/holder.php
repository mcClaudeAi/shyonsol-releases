<?php
// Verify a wallet and link its Shytoshi Shadows to a player profile.
// POST {a: status|nonce|verify|refresh|unlink, pid, key, ...}   GET ?a=shadows -> Shadow career records

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

$a = $_GET['a'] ?? '';
if ($a === 'shadows') {
    $reg = with_lock(fn() => load(SHADOWREG));
    $rows = [];
    foreach ($reg as $n => $r) {
        if (empty($r['games'])) continue;
        $rows[] = ['n' => (string)$n, 'img' => $r['img'] ?? '', 'wins' => $r['wins'], 'games' => $r['games'], 'points' => $r['points'],
            'pvp_w' => $r['pvp_w'] ?? 0, 'pvp_g' => $r['pvp_g'] ?? 0, 'best' => $r['best'] ?? 0, 'aura' => $r['aura'] ?? '', 'rank' => $r['rank'] ?? ''];
    }
    usort($rows, fn($x, $y) => [$y['points'], $y['wins']] <=> [$x['points'], $x['wins']]);
    $pages = max(1, (int)ceil(count($rows) / 10));
    $pg = max(1, min($pages, (int)($_GET['pg'] ?? 1)));
    out(['ok' => true, 'enabled' => holders_enabled(), 'total' => count($rows), 'page' => $pg, 'pages' => $pages, 'per' => 10,
        'top' => isset($_GET['pg']) ? array_slice($rows, ($pg - 1) * 10, 10) : array_slice($rows, 0, 50)]);
}

//MC 2026-10-13 the browsable gallery on the NFTs page: every Shadow the site has met, with its aura, rarity rank and
//   career, so visitors can filter by aura, sort by rarity and send any of them into a free trial game
if ($a === 'gallery') {
    header('Cache-Control: public, max-age=60');
    $reg = with_lock(fn() => load(SHADOWREG));
    $rows = []; $auras = [];
    foreach ($reg as $n => $r) {
        if (($r['img'] ?? '') === '') continue;
        $aura = trim((string)($r['aura'] ?? ''));
        if ($aura !== '') $auras[$aura] = ($auras[$aura] ?? 0) + 1;
        $rows[] = ['n' => (string)$n, 'img' => $r['img'], 'aura' => $aura, 'rank' => (int)ltrim((string)($r['rank'] ?? ''), '#'),
            'wins' => (int)($r['wins'] ?? 0), 'games' => (int)($r['games'] ?? 0)];
        if (count($rows) >= 400) break;
    }
    usort($rows, fn($x, $y) => [$x['rank'] ?: 9999, -$x['wins']] <=> [$y['rank'] ?: 9999, -$y['wins']]);
    out(['ok' => true, 'total' => count($rows), 'auras' => $auras, 'rows' => $rows]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 4000) fail('too large');
$body = json_decode($raw, true) ?: [];
$a = (string)($body['a'] ?? '');
$pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);

// the key proves this browser owns the profile (same key the leaderboard uses)
function owns_profile($pid, $kh) { return key_ok($pid, $kh); }
function public_view($h, $reg) {
    if (!$h || empty($h['wallet'])) return ['linked' => false, 'holder' => false, 'shadows' => []];
    $list = array_map(fn($n) => ['n' => (string)$n, 'img' => $reg[$n]['img'] ?? '', 'wins' => $reg[$n]['wins'] ?? 0, 'games' => $reg[$n]['games'] ?? 0, 'aura' => $reg[$n]['aura'] ?? '', 'rank' => $reg[$n]['rank'] ?? ''], $h['shadows'] ?? []);
    return ['linked' => true, 'holder' => count($list) > 0, 'wallet' => $h['wallet'], 'shadows' => $list, 'checked' => $h['chk'] ?? 0,
        'tier' => holder_tier($h), 'shy' => isset($h['shy_bal']) ? ['bal' => $h['shy_bal'], 'usd' => $h['shy_usd'] ?? 0] : null];
}

if (!holders_enabled() && $a !== 'status') fail('Holder verification is being set up. Check back soon.', 503);

if ($a === 'nonce') {
    $wallet = (string)($body['wallet'] ?? '');
    if (!valid_wallet($wallet)) fail('That wallet address does not look right.');
    $res = with_lock(function () use ($pid, $kh, $wallet) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'nonce:' . client_ip(), 30, 600)) { save(LIMITS, $limits); return null; }
        save(LIMITS, $limits);
        if (!owns_profile($pid, $kh)) return ['err' => 'not your profile'];
        $nonces = load(NONCES);
        $now = time();
        $nonces = array_filter($nonces, fn($x) => $x['ts'] > $now - NONCE_TTL);
        $n = bin2hex(random_bytes(10));
        $nonces[$n] = ['pid' => $pid, 'wallet' => $wallet, 'ts' => $now];
        save(NONCES, $nonces);
        return ['nonce' => $n, 'message' => sign_text($wallet, $pid, $n, $now)];
    });
    if (!$res) fail('Slow down a little and try again.', 429);
    if (isset($res['err'])) fail($res['err'], 403);
    out(['ok' => true] + $res);
}

if ($a === 'verify') {
    $nonce = (string)($body['nonce'] ?? ''); $sig = (string)($body['signature'] ?? '');
    if (!preg_match('/^[a-f0-9]{20}$/', $nonce)) fail('bad request');
    //MC 2026-10-11 a good signature for a live nonce gets its wallet looked up before the lock is taken (holder_prefetch);
    //   everything is checked again inside, and the nonce is still used up there
    $rec0 = load(NONCES)[$nonce] ?? null;
    if ($rec0 && ($rec0['pid'] ?? '') === $pid && time() - $rec0['ts'] <= NONCE_TTL && key_ok($pid, $kh) && sig_check($rec0['wallet'], sign_text($rec0['wallet'], $pid, $nonce, $rec0['ts']), $sig) === '')
        holder_prefetch($pid, true, null, ['wallet' => $rec0['wallet'], 'shadows' => [], 'chk' => 0]);
    $res = with_lock(function () use ($pid, $kh, $nonce, $sig) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'verify:' . client_ip(), 30, 600)) { save(LIMITS, $limits); return ['err' => 'Slow down a little and try again.', 'code' => 429]; }
        save(LIMITS, $limits);
        if (!owns_profile($pid, $kh)) return ['err' => 'not your profile', 'code' => 403];
        $nonces = load(NONCES);
        $rec = $nonces[$nonce] ?? null;
        unset($nonces[$nonce]);        // one use only, even if it fails
        save(NONCES, $nonces);
        if (!$rec || $rec['pid'] !== $pid || time() - $rec['ts'] > NONCE_TTL) return ['err' => 'That request expired. Try connecting again.', 'code' => 400];
        $msg = sign_text($rec['wallet'], $pid, $nonce, $rec['ts']);
        $why = sig_check($rec['wallet'], $msg, $sig);
        if ($why !== '') {
            @file_put_contents(DATA_DIR . '/holder-errors.log', gmdate('c') . " $why wallet=" . $rec['wallet'] . ' siglen=' . strlen((string)$sig) . ' php=' . PHP_VERSION . ' sodium=' . (function_exists('sodium_crypto_sign_verify_detached') ? 'yes' : 'no') . "\n", FILE_APPEND);
            return ['err' => "The signature didn't check out. Try again. (code: $why)", 'code' => 400];
        }
        $holders = load(HOLDERS); $reg = load(SHADOWREG);
        // A wallet already tied to a profile signs this device in to THAT profile: purchases and records live on the wallet.
        // Anything this device earned as a guest (Koban, items) moves across with it.
        foreach ($holders as $id => $h) if ($id !== $pid && ($h['wallet'] ?? '') === $rec['wallet']) {
            key_add($id, $kh);
            $eco = load(ECO);
            $from = $eco[$pid] ?? null;
            //MC 2026-10-11 only a true guest profile moves across. One that ever had a wallet linked, or collected a holder
            //   stipend, keeps its own Koban: the audit linked a wallet to spare profiles, collected the stipend on each,
            //   unlinked, then signed them in to the wallet's profile so all of it landed there.
            $guest = !isset($holders[$pid]) && empty($from['stip']);
            if ($from && $guest && empty($holders[$pid]['wallet'])) {
                $to = eco_get($eco, $id);
                if ($from['koban'] > 0) eco_credit($to, $from['koban'], 'Moved from guest profile');
                foreach ($from['items'] ?? [] as $it => $ts) if (!isset($to['items'][$it])) $to['items'][$it] = $ts;
                $eco[$id] = $to; unset($eco[$pid]);
                save(ECO, $eco);
            }
            $players = load(PLAYERS);
            $h2 = holder_refresh($holders, $reg, $id, true);
            save(HOLDERS, $holders); save(SHADOWREG, $reg);
            if (holder_sync_player($players, $id, $h2)) save(PLAYERS, $players);   //MC 2026-10-09 signing in on a new device shows their Shadow straight away
            funnel_mark($pid, 'w');
            return public_view($h2, $reg) + ['switch' => $id, 'name' => $players[$id]['name'] ?? ''];
        }
        $moved = [];
        $holders[$pid] = ['wallet' => $rec['wallet'], 'kh' => $kh, 'shadows' => [], 'chk' => 0, 'since' => time()];
        key_add($pid, $kh);
        $h = holder_refresh($holders, $reg, $pid, true);
        if (($h['chk'] ?? 0) === 0) return ['err' => "Couldn't reach Solana to check your Shadows. Try again in a minute.", 'code' => 502];
        save(HOLDERS, $holders); save(SHADOWREG, $reg);
        $players = load(PLAYERS);
        foreach ($moved as $id) if (isset($players[$id])) { $players[$id]['holder'] = false; $players[$id]['avatar'] = ''; }
        holder_sync_player($players, $pid, $h);   //MC 2026-10-09 flag and Shadow together
        save(PLAYERS, $players);
        //MC 2026-10-09 counted for the reports, and a new holder gets an email to the team
        track('wallets');
        if (!empty($h['shadows']) || holder_tier($h)) { track('holders_new'); alert_holder($pid, $h); }
        return public_view($h, $reg);
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

if ($a === 'status' || $a === 'refresh') {
    //MC 2026-10-11 the key and the refresh limit are checked first, then any lookup that's due runs with no lock held
    //   (holder_prefetch), then the lock is taken to save. Same answers as before, the rest of the site keeps moving.
    $pre = with_lock(function () use ($pid, $kh, $a) {
        if (!owns_profile($pid, $kh)) return 'not your profile';
        if ($a === 'refresh' && !empty(load(HOLDERS)[$pid]['wallet'])) {
            $limits = load(LIMITS);
            if (!rate_ok($limits, 'refresh:' . client_ip(), 12, 600)) { save(LIMITS, $limits); return 'Slow down a little and try again.'; }
            save(LIMITS, $limits);
        }
        return '';
    });
    if ($pre !== '') fail($pre, 403);
    holder_prefetch($pid, $a === 'refresh');
    $res = with_lock(function () use ($pid, $kh, $a) {
        if (!owns_profile($pid, $kh)) return ['err' => 'not your profile'];
        $holders = load(HOLDERS); $reg = load(SHADOWREG);
        if (empty($holders[$pid]['wallet'])) return public_view(null, $reg);
        $h = holder_refresh($holders, $reg, $pid, $a === 'refresh');
        save(HOLDERS, $holders); save(SHADOWREG, $reg);
        $players = load(PLAYERS);
        if (holder_sync_player($players, $pid, $h)) save(PLAYERS, $players);   //MC 2026-10-09 flag and Shadow together, not just the flag
        holders_repair_once();
        return public_view($h, $reg);
    });
    if (isset($res['err'])) fail($res['err'], 403);
    //MC 2026-10-15 sign in with Google or Apple for a free Phantom wallet (assets/ewallet.js), when the team set an app id
    $es = eco_settings();
    $ew = !empty($es['ew_on']) && preg_match('/^[a-f0-9-]{36}$/i', (string)($es['ew_app'] ?? '')) ? ['app' => (string)$es['ew_app']] : null;
    out(['ok' => true, 'enabled' => holders_enabled(), 'ew' => $ew] + $res);
}

if ($a === 'unlink') {
    with_lock(function () use ($pid, $kh) {
        if (!owns_profile($pid, $kh)) return;
        $holders = load(HOLDERS);
        if (isset($holders[$pid])) { $holders[$pid]['wallet'] = ''; $holders[$pid]['shadows'] = []; save(HOLDERS, $holders); }
        $players = load(PLAYERS);
        if (isset($players[$pid])) { $players[$pid]['holder'] = false; $players[$pid]['avatar'] = ''; save(PLAYERS, $players); }
    });
    out(['ok' => true, 'linked' => false, 'holder' => false, 'shadows' => []]);
}

fail('unknown action');
