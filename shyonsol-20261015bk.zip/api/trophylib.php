<?php
// Trophies on Solana: the big wins are minted as compressed NFTs to the winner's own wallet.
//
// What earns one: winning the Weekly League, winning a tournament, joining the 15 Club, a Grandmaster card, finishing a
// ranked season in Jade or Shogun, and holding for 90 and 180 days (Diamond Hands, Ancient Holder). Each trophy has a
// fixed id (for example champ-2026-W42-<player>), so the same win can never mint twice, here or at the minting service.
//
// Minting goes through Crossmint's minting API (compressed NFTs on Solana; they pay the network fee and hold no key of
// ours). The team sets the API key and collection in Admin > Shop > Trophies; until then trophies are recorded and wait.
// A winner with no wallet connected keeps theirs waiting too, and it mints the first time a pass finds a wallet.
// Passes run from the site's background tick (a few mints at a time, never inside the site lock) and from cron.
//MC 2026-10-15 first version
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('TROPHIES', DATA_DIR . '/trophies.php');     // id => ['pid', 'kind', 'name', 'desc', 't', 'st' => wait|mint|done|fail, ...]
define('TROPHY_CFG', DATA_DIR . '/trophy-cfg.php'); // ['on', 'key', 'col', 'env' => prod|staging]
const TROPHY_KINDS = [
    'champ'   => ['League Champion', 'Won the Shilluminati Online Weekly League'],
    'cup'     => ['Tournament Champion', 'Won a Shilluminati Online tournament'],
    'club15'  => ['15 Club', 'Won a game holding 15 Regions'],
    'master'  => ['Grandmaster', 'Mastered a Chaos card to Grandmaster'],
    'rkjade'  => ['Jade Ranked', 'Finished a ranked season in Jade'],
    'rkshogun'=> ['Ranked Shogun', 'Finished a ranked season in Shogun'],
    'diamond' => ['Diamond Hands', 'Held a $SHY rank for 90 days'],
    'ancient' => ['Ancient Holder', 'Held a $SHY rank for 180 days'],
];

function trophy_cfg() {
    $c = is_file(TROPHY_CFG) ? load(TROPHY_CFG) : [];
    return ['on' => !empty($c['on']), 'key' => (string)($c['key'] ?? ''), 'col' => (string)($c['col'] ?? 'default-solana'), 'env' => ($c['env'] ?? 'prod') === 'staging' ? 'staging' : 'prod'];
}
function trophy_ready() { $c = trophy_cfg(); return $c['on'] && strlen($c['key']) > 20; }

// a win happened: record its trophy (once). $tag makes it unique (the week, the tournament, the card...). Call anywhere;
// it takes the site lock itself unless the caller already holds it.
function trophy_award($pid, $kind, $tag, $what = '') {
    if (!isset(TROPHY_KINDS[$kind]) || !preg_match('/^[a-f0-9]{16}$/', (string)$pid)) return;
    $id = $kind . '-' . preg_replace('/[^a-z0-9-]/', '', strtolower((string)$tag)) . '-' . substr($pid, 0, 10);
    $fn = function () use ($id, $pid, $kind, $what) {
        $all = load(TROPHIES);
        if (isset($all[$id])) return;
        $all[$id] = ['pid' => $pid, 'kind' => $kind, 'what' => mb_substr((string)$what, 0, 40), 't' => time(), 'st' => 'wait', 'tries' => 0];
        save(TROPHIES, $all);
    };
    (function_exists('lock_depth') && lock_depth() > 0) ? $fn() : with_lock($fn);
}
// the NFT's name (32 characters at most) and description (64)
function trophy_meta($id, $r) {
    [$name, $desc] = TROPHY_KINDS[$r['kind']];
    $n = $name . ($r['what'] !== '' ? ' · ' . $r['what'] : '');
    if (mb_strlen($n) > 32) $n = mb_substr($n, 0, 31) . '…';
    $pl = load(PLAYERS)[$r['pid']]['name'] ?? '';
    $d = $desc . ($pl !== '' ? ' as ' . $pl : '') . '.';
    if (mb_strlen($d) > 64) $d = $desc . '.';
    return ['name' => $n, 'symbol' => 'SHYT', 'description' => $d,
        'image' => 'https://shyonsol.io/assets/art/trophy/' . $r['kind'] . '.png',
        'attributes' => array_values(array_filter([
            ['trait_type' => 'Trophy', 'value' => $name],
            $r['what'] !== '' ? ['trait_type' => 'For', 'value' => $r['what']] : null,
            $pl !== '' ? ['trait_type' => 'Player', 'value' => $pl] : null,
            ['trait_type' => 'Won', 'value' => gmdate('Y-m-d', $r['t'])],
            ['trait_type' => 'Game', 'value' => 'Shilluminati Online'],
        ]))];
}
// one call to the minting API. PUT is idempotent by our trophy id: asking again only reports how it went.
function trophy_call($id, $wallet, $meta) {
    $c = trophy_cfg();
    $host = $c['env'] === 'staging' ? 'https://staging.crossmint.com' : 'https://www.crossmint.com';
    $cfgBase = function_exists('shy_config') ? (string)(shy_config()['trophy_api'] ?? '') : '';   // a test server, set only in a test config
    $url = ($cfgBase !== '' ? $cfgBase : $host) . '/api/2022-06-09/collections/' . rawurlencode($c['col']) . '/nfts/' . rawurlencode('shy-' . $id);
    $body = json_encode(['recipient' => 'solana:' . $wallet, 'metadata' => $meta, 'compressed' => true, 'reuploadLinkedFiles' => true, 'sendNotification' => false], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => 'PUT', CURLOPT_POSTFIELDS => $body, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-API-KEY: ' . $c['key']]]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    return ['code' => $code, 'j' => is_array($j) ? $j : []];
}
// a pass: up to $n trophies sent or checked. Network outside the lock, results saved inside it.
function trophy_tick($n = 3, $force = false) {
    if (!trophy_ready()) return 0;
    $sf = DATA_DIR . '/trophy-tick.php';
    if (!$force && time() - (int)(load($sf)['t'] ?? 0) < 90) return 0;
    save($sf, ['t' => time()]);
    $all = load(TROPHIES); $holders = load(HOLDERS);
    $todo = [];
    foreach ($all as $id => $r) {
        if ($r['st'] === 'done' || $r['st'] === 'fail') continue;
        if (time() - (int)($r['next'] ?? 0) < 0) continue;
        $w = $holders[$r['pid']]['wallet'] ?? '';
        if (!$w || !valid_wallet($w)) continue;   // waits for a connected wallet
        $todo[$id] = $w;
        if (count($todo) >= $n) break;
    }
    $res = [];
    foreach ($todo as $id => $w) {
        $r = $all[$id];
        $x = trophy_call($id, $r['wallet'] ?? $w, trophy_meta($id, $r));   // a trophy keeps the wallet it was first sent to
        $res[$id] = $x + ['w' => $r['wallet'] ?? $w];
    }
    if (!$res) return 0;
    with_lock(function () use ($res) {
        $all = load(TROPHIES);
        foreach ($res as $id => $x) {
            if (!isset($all[$id])) continue;
            $r = &$all[$id];
            $r['tries'] = (int)$r['tries'] + 1; $r['wallet'] = $x['w']; $r['last'] = time();
            $on = $x['j']['onChain'] ?? [];
            if ($x['code'] >= 200 && $x['code'] < 300) {
                if (($on['status'] ?? '') === 'success' && !empty($on['mintHash'])) { $r['st'] = 'done'; $r['mint'] = $on['mintHash']; $r['tx'] = $on['txId'] ?? ''; }
                else { $r['st'] = 'mint'; $r['next'] = time() + 120; }   // accepted, still minting: ask again in a bit
            } elseif ($x['code'] === 400 || $x['code'] === 403) {
                $r['err'] = mb_substr((string)($x['j']['message'] ?? ('HTTP ' . $x['code'])), 0, 200);
                $r['next'] = time() + 6 * 3600;   // a settings problem: the team sees it in the admin; try again later
                if ($r['tries'] >= 8) $r['st'] = 'fail';
            } else { $r['err'] = 'HTTP ' . $x['code']; $r['next'] = time() + min(3600, 60 * (1 << min(6, $r['tries']))); }
            unset($r);
        }
        save(TROPHIES, $all);
    });
    return count($res);
}
// a player's trophies, newest first, for their profile and player page
function trophies_of($pid) {
    $out = [];
    foreach (load(TROPHIES) as $id => $r) if ($r['pid'] === $pid) $out[] = ['kind' => $r['kind'], 'name' => TROPHY_KINDS[$r['kind']][0], 'what' => $r['what'], 't' => $r['t'], 'st' => $r['st'], 'mint' => $r['mint'] ?? ''];
    usort($out, fn($a, $b) => $b['t'] <=> $a['t']);
    return $out;
}
