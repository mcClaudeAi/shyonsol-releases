<?php
// Shilluminati Online rules engine: the server's exact copy of assets/game.js (71-card deck, 40 Regions).
// Every random draw happens in the same order as the browser so solo games replay identically.
if (!defined('SHY_ENGINE')) { http_response_code(404); exit; }

const REGIONS = ["Eastern North America", "Western North America", "Western Canada", "Eastern Canada", "Central America",
    "Caribbean", "Andes", "Amazonia", "Brazilian Highlands", "Southern Cone", "British Isles", "Scandinavia", "Western Europe",
    "Central Europe", "Eastern Europe", "Iberia", "Mediterranean", "Balkans", "North Africa", "West Africa", "Central Africa",
    "East Africa", "Southern Africa", "Southeast Africa", "Middle East", "Persia", "Arabian Peninsula", "Central Asia",
    "Western Siberia", "Far East", "South Asia", "Northern China", "Southern China", "Korean Peninsula", "Japan", "Indochina",
    "Indonesia", "Western Australia", "Eastern Australia", "Pacific Islands"];

const CARDS = [
    'meteor' => ['name' => 'Meteor Strike', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'superweapon' => ['name' => 'Secret Superweapon', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'plasma' => ['name' => 'Plasma Storm', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'drone' => ['name' => 'Drone Strike', 'kind' => 'attack', 'target' => 'pick', 'n' => 0],
    'sub' => ['name' => 'Hidden Nuclear Submarine', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'drones' => ['name' => 'Unstoppable Drones', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'dictator' => ['name' => 'Rise of a Dictator', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'border' => ['name' => 'Border Conflict Escalates', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'coup' => ['name' => 'Coup d\'État', 'kind' => 'attack', 'target' => 'leader', 'n' => 1],
    'empire' => ['name' => 'Shadow Empire', 'kind' => 'attack', 'target' => 'leader', 'n' => 1],
    'endera' => ['name' => 'End of an Era', 'kind' => 'attack', 'target' => 'leader', 'n' => 1],
    'pact' => ['name' => 'Mutual Destruction Pact', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'censor' => ['name' => 'Mass Media Censorship', 'kind' => 'attack', 'target' => 'pick', 'n' => 0],
    'epidemic' => ['name' => 'Epidemic Containment', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'newleader' => ['name' => 'New Global Leader', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'prophecy' => ['name' => 'False Prophecy', 'kind' => 'attack', 'target' => 'pick', 'n' => 1],
    'unicoup' => ['name' => 'Universal Coup', 'kind' => 'attack', 'target' => 'none', 'n' => 1],
    'machines' => ['name' => 'Rise of the Machines', 'kind' => 'attack', 'target' => 'none', 'n' => 1],
    'popcontrol' => ['name' => 'Population Control Agenda', 'kind' => 'attack', 'target' => 'none', 'n' => 1],
    'atlantis' => ['name' => 'Discovery of Atlantis', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'surge' => ['name' => 'Power Surge', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'resource' => ['name' => 'Resource Surge', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'space' => ['name' => 'Space Race Victory', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'solar' => ['name' => 'Solar Harvesting', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'era' => ['name' => 'Era of Expansion', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'reinforce' => ['name' => 'Reinforcements Arrive', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'prophecyful' => ['name' => 'Prophecy Fulfilled', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'galactic' => ['name' => 'Galactic Expansion', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'galconsp' => ['name' => 'Galactic Conspiracy', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'tunnels' => ['name' => 'Underground Tunnels', 'kind' => 'gain', 'target' => 'none', 'n' => 0],
    'summit' => ['name' => 'Secret Society Summit', 'kind' => 'gain', 'target' => 'none', 'n' => 0],
    'underworld' => ['name' => 'Rise of the Underworld', 'kind' => 'global', 'target' => 'none', 'n' => 0],
    'rekindled' => ['name' => 'Rekindled Hope', 'kind' => 'global', 'target' => 'none', 'n' => 0],
    'secretgov' => ['name' => 'Secret Government Project', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'awakening' => ['name' => 'The Great Awakening', 'kind' => 'gain', 'target' => 'none', 'n' => 1],
    'bunker' => ['name' => 'Underground Bunker', 'kind' => 'defense', 'target' => 'none', 'n' => 1],
    'irondome' => ['name' => 'Iron Dome', 'kind' => 'defense', 'target' => 'none', 'n' => 1],
    'stronghold' => ['name' => 'The Last Stronghold', 'kind' => 'defense', 'target' => 'none', 'n' => 1],
    'lone' => ['name' => 'Lone Survivor', 'kind' => 'defense', 'target' => 'none', 'n' => 1],
    'coop' => ['name' => 'Cooperative Defense', 'kind' => 'defense', 'target' => 'none', 'n' => 1],
    'failedcoup' => ['name' => 'Failed Coup', 'kind' => 'passive', 'target' => 'none', 'n' => 1],
    'assassin' => ['name' => 'Failed Assassination Attempt', 'kind' => 'passive', 'target' => 'none', 'n' => 1],
    'decoy' => ['name' => 'Holographic Decoy', 'kind' => 'passive', 'target' => 'none', 'n' => 1],
    'boom' => ['name' => 'Population Boom', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'forgotten' => ['name' => 'Rise of the Forgotten', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'overthrow' => ['name' => 'Global Overthrow', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'resistance' => ['name' => 'Rise of the Resistance', 'kind' => 'global', 'target' => 'none', 'n' => 0],
    'taxation' => ['name' => 'Universal Taxation', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'audit' => ['name' => 'Global Audit', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'rebellion' => ['name' => 'Unexpected Rebellion', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'zombie' => ['name' => 'Zombie Apocalypse', 'kind' => 'global', 'target' => 'none', 'n' => 0],
    'negotiations' => ['name' => 'Failed Negotiations', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'locusts' => ['name' => 'Locusts Eat Everything', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'plague' => ['name' => 'Plague Outbreak', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'flood' => ['name' => 'The Great Flood', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'ww3' => ['name' => 'World War III', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'mutiny' => ['name' => 'Global Mutiny', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'alien' => ['name' => 'Alien Abduction Frenzy', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'nuclear' => ['name' => 'Nuclear Chain Reaction', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'famine' => ['name' => 'The Great Famine', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'extinction' => ['name' => 'Extinction Level Event', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'winter' => ['name' => 'Eternal Winter', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'renaissance' => ['name' => 'Cultural Renaissance', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'blackhole' => ['name' => 'Black Hole Event', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'anarchy' => ['name' => 'Global Anarchy', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'cern' => ['name' => 'CERN Goes Haywire', 'kind' => 'global', 'target' => 'none', 'n' => 1],
    'double' => ['name' => 'Double Disaster', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'blitz' => ['name' => 'Blitz Tactics', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'gravity' => ['name' => 'Gravity Collapse', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'madsci' => ['name' => 'Mad Scientist\'s Experiment', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'superai' => ['name' => 'Superintelligent A.I.', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'neural' => ['name' => 'Neural Network Hack', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'pandora' => ['name' => 'Pandora\'s Box', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'conspiracy' => ['name' => 'Global Conspiracy Unveiled', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'currency' => ['name' => 'Currency Collapse', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'netcrash' => ['name' => 'Global Internet Crash', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'tides' => ['name' => 'Tides of Power', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    'quantum' => ['name' => 'Quantum Rift', 'kind' => 'trick', 'target' => 'pick', 'n' => 1],
    'falsememory' => ['name' => 'False Memory Implant', 'kind' => 'trick', 'target' => 'none', 'n' => 1],
    // season cards: never in the original deck; a season's winning card joins play through eng_season(), after every card above
    'kamikaze' => ['name' => 'Divine Wind', 'kind' => 'global', 'target' => 'none', 'n' => 0, 'season' => 2],
    'decree' => ['name' => 'Shogun\'s Decree', 'kind' => 'attack', 'target' => 'leader', 'n' => 0, 'season' => 2],
    'ninja' => ['name' => 'Ninja Infiltration', 'kind' => 'attack', 'target' => 'pick', 'n' => 0, 'season' => 2],
    'paper' => ['name' => 'Paper Fortress', 'kind' => 'defense', 'target' => 'none', 'n' => 0, 'season' => 2],
    'harvest' => ['name' => 'Rice Harvest', 'kind' => 'gain', 'target' => 'none', 'n' => 0, 'season' => 2],
    'ronin' => ['name' => 'Ronin for Hire', 'kind' => 'trick', 'target' => 'pick', 'n' => 0, 'season' => 2],
    'truce' => ['name' => 'Tea Ceremony Truce', 'kind' => 'global', 'target' => 'none', 'n' => 0, 'season' => 2],
    'eclipse' => ['name' => 'Eclipse', 'kind' => 'passive', 'target' => 'none', 'n' => 0, 'season' => 2],
];
// the season cards in play on top of the original deck; set before eng_new / eng_replay (see cardsetlib.php season_deck_at())
$GLOBALS['SHY_SEASON'] = [];
function eng_season(array $ids) {
    $GLOBALS['SHY_SEASON'] = array_values(array_filter($ids, fn($id) => isset(CARDS[$id]) && !empty(CARDS[$id]['season'])));
    return $GLOBALS['SHY_SEASON'];
}
const WORTH = ['reinforce' => 6, 'prophecyful' => 4, 'galactic' => 5, 'galconsp' => 5.5, 'tunnels' => 3.5, 'summit' => 3, 'underworld' => 3, 'rekindled' => 3, 'meteor' => 6, 'superweapon' => 6, 'plasma' => 7, 'drone' => 4, 'sub' => 4.5, 'drones' => 4.5, 'dictator' => 5, 'border' => 5, 'coup' => 5, 'empire' => 7, 'endera' => 6, 'pact' => 3, 'censor' => 3, 'epidemic' => 3, 'newleader' => 3, 'prophecy' => 4, 'unicoup' => 7, 'machines' => 5, 'popcontrol' => 5, 'atlantis' => 6, 'surge' => 4, 'resource' => 5, 'space' => 3.5, 'solar' => 4.5, 'era' => 5, 'secretgov' => 4.5, 'awakening' => 7, 'bunker' => 4, 'irondome' => 5, 'stronghold' => 5, 'lone' => 3, 'coop' => 4, 'failedcoup' => 5, 'assassin' => 5.5, 'decoy' => 4.5, 'boom' => 3, 'forgotten' => 4, 'overthrow' => 3, 'resistance' => 3, 'taxation' => 3, 'audit' => 3.5, 'rebellion' => 3.5, 'zombie' => 2.5, 'negotiations' => 2.5, 'locusts' => 2.5, 'plague' => 2.5, 'flood' => 2.5, 'ww3' => 3, 'mutiny' => 2.5, 'alien' => 2.5, 'nuclear' => 3, 'famine' => 2.5, 'extinction' => 3, 'winter' => 6, 'renaissance' => 2, 'blackhole' => 2, 'anarchy' => 2, 'cern' => 2, 'double' => 4, 'blitz' => 5, 'gravity' => 5, 'madsci' => 3.5, 'superai' => 5, 'neural' => 4, 'pandora' => 4, 'conspiracy' => 4, 'currency' => 4, 'netcrash' => 2.5, 'tides' => 2, 'quantum' => 2.5, 'falsememory' => 3, 'kamikaze' => 5, 'decree' => 5.5, 'ninja' => 5.5, 'paper' => 4.5, 'harvest' => 4.5, 'ronin' => 3.5, 'truce' => 3.5, 'eclipse' => 5];

const MAX_ROUNDS = 30;
const WIN_AT = 15;
const PASS_WORTH = 5;
const STYLE = ['hawkAttack' => 0.4, 'hawkGain' => -0.1, 'buildGain' => 0.25, 'buildDefense' => 0.25, 'buildAttack' => 0.05, 'wild' => 1.8, 'attackScale' => 1, 'leaderBonus' => 0];

// ---------- random numbers ----------
$GLOBALS['SHY_SEED'] = null;
function rnd_seed($seed) { $GLOBALS['SHY_SEED'] = $seed === null ? null : ((int)$seed & 0xffffffff); }
function imul32($a, $b) {   // 32-bit multiply like JavaScript's Math.imul, without 64-bit overflow
    $a &= 0xffffffff; $b &= 0xffffffff;
    $lo = (($a & 0xffff) * $b) & 0xffffffff;
    $hi = ((($a >> 16) & 0xffff) * $b) & 0xffff;
    return ($lo + ($hi << 16)) & 0xffffffff;
}
function rnd() {
    if ($GLOBALS['SHY_SEED'] === null) return random_int(0, PHP_INT_MAX - 1) / PHP_INT_MAX;
    $a = ($GLOBALS['SHY_SEED'] + 0x6D2B79F5) & 0xffffffff;
    $GLOBALS['SHY_SEED'] = $a;
    $t = imul32($a ^ ($a >> 15), 1 | $a);
    $t = (($t + imul32($t ^ ($t >> 7), 61 | $t)) & 0xffffffff) ^ $t;
    return (($t ^ ($t >> 14)) & 0xffffffff) / 4294967296;
}
function rint($n) { return (int)floor(rnd() * $n); }
function shuf(array $a) {
    for ($i = count($a) - 1; $i > 0; $i--) { $j = rint($i + 1); [$a[$i], $a[$j]] = [$a[$j], $a[$i]]; }
    return $a;
}
const BOT_NAMES = ["Neon Ronin", "Iron Monk", "Paper Tiger", "Night Crane", "Jade Fox", "Silent Oni"];
function setup_rivals() { $names = array_slice(shuf(BOT_NAMES), 0, 3); $styles = shuf(['hawk', 'builder', 'wild']); return [$names, $styles]; }
function plural($n, $w) { return $n . ' ' . $w . ($n === 1 ? '' : 's'); }

// ---------- setup ----------
function eng_new(array $names, array $styles, $easy = false, $human = -1) {
    $chaos = [];
    $extra = array_count_values($GLOBALS['SHY_SEASON']);
    foreach (CARDS as $id => $c) for ($k = 0; $k < $c['n'] + ($extra[$id] ?? 0); $k++) $chaos[] = $id;
    $g = ['round' => 1, 'turn' => 0, 'over' => false, 'log' => [], 'seq' => 0, 'easy' => (bool)$easy, 'plays' => 0, 'played' => false,
        'extraTurn' => false, 'noDraw' => -1, 'truce' => -1, 'snap' => null, 'blocks' => 0, 'deck' => $GLOBALS['SHY_SEASON'],
        'regionDeck' => shuf(REGIONS), 'regionDiscard' => [], 'chaosDeck' => shuf($chaos), 'chaosDiscard' => [], 'players' => []];
    foreach ($names as $i => $n) $g['players'][] = ['name' => $n, 'style' => $styles[$i] ?? '', 'regions' => [], 'hand' => [], 'shield' => 0, 'skip' => 0, 'lone' => false, 'paper' => false, 'harvest' => 0];
    $g['start'] = $g['turn'] = rint(count($names));
    foreach (array_keys($g['players']) as $i) {
        $easyMe = $easy && $i === $human;
        for ($k = 0; $k < ($easyMe ? 3 : 2); $k++) $g['players'][$i]['regions'][] = array_pop($g['regionDeck']);
        for ($k = 0; $k < ($easyMe ? 6 : 5); $k++) { $c = draw_chaos($g); if ($c) $g['players'][$i]['hand'][] = $c; }
    }
    return $g;
}
function say(&$g, $who, $text, $kind = 'info', $card = null) {
    $e = ['id' => ++$g['seq'], 'who' => $who, 'text' => $text, 'kind' => $kind];
    if ($card) $e['card'] = $card;
    $g['log'][] = $e;
    if (count($g['log']) > 80) $g['log'] = array_slice($g['log'], -80);
}

// ---------- decks ----------
function draw_chaos(&$g) {
    if (!$g['chaosDeck']) {
        if (!$g['chaosDiscard']) return null;
        $g['chaosDeck'] = shuf($g['chaosDiscard']); $g['chaosDiscard'] = [];
    }
    return array_pop($g['chaosDeck']);
}
function give_chaos(&$g, $pi, $k) { $got = 0; for ($i = 0; $i < $k; $i++) { $c = draw_chaos($g); if ($c) { $g['players'][$pi]['hand'][] = $c; $got++; } } return $got; }
function discard_random(&$g, $pi, $k) {
    $n = 0;
    for ($i = 0; $i < $k && $g['players'][$pi]['hand']; $i++) { $g['chaosDiscard'][] = array_splice($g['players'][$pi]['hand'], rint(count($g['players'][$pi]['hand'])), 1)[0]; $n++; }
    return $n;
}
function discard_hand(&$g, $pi) { while ($g['players'][$pi]['hand']) $g['chaosDiscard'][] = array_pop($g['players'][$pi]['hand']); }
function best_index($list, $weakest = false) {
    $bi = -1; $bv = 0;
    foreach (array_values($list) as $i => $id) { $v = WORTH[$id] ?? 0; if ($bi < 0 || ($weakest ? $v < $bv : $v > $bv)) { $bi = $i; $bv = $v; } }
    return $bi;
}
function gain_deck(&$g, $pi, $k) { $got = 0; for ($i = 0; $i < $k && $g['regionDeck']; $i++) { $g['players'][$pi]['regions'][] = array_pop($g['regionDeck']); $got++; } return $got; }
function gain_discard(&$g, $pi, $k) {
    $got = 0;
    for ($i = 0; $i < $k && $g['regionDiscard']; $i++) { $g['players'][$pi]['regions'][] = array_splice($g['regionDiscard'], rint(count($g['regionDiscard'])), 1)[0]; $got++; }
    return $got;
}
function lose_regions(&$g, $pi, $k) {
    $lost = 0;
    for ($i = 0; $i < $k && $g['players'][$pi]['regions']; $i++) { $g['regionDiscard'][] = array_splice($g['players'][$pi]['regions'], rint(count($g['players'][$pi]['regions'])), 1)[0]; $lost++; }
    return $lost;
}
function steal_regions(&$g, $from, $to, $k) {
    $got = 0;
    for ($i = 0; $i < $k && $g['players'][$from]['regions']; $i++) { $g['players'][$to]['regions'][] = array_splice($g['players'][$from]['regions'], rint(count($g['players'][$from]['regions'])), 1)[0]; $got++; }
    return $got;
}

// ---------- who ----------
function rival_leader($g, $pi) {
    $best = -1; $bi = -1;
    foreach ($g['players'] as $i => $p) {
        if ($i === $pi) continue;
        $c = count($p['regions']);
        if ($c > $best || ($c === $best && rnd() < 0.5)) { $best = $c; $bi = $i; }
    }
    return $bi;
}
function pick_by($g, $seats, $fewest) {
    $best = null; $ids = [];
    foreach ($seats as $i) {
        $c = count($g['players'][$i]['regions']);
        if ($best === null || ($fewest ? $c < $best : $c > $best)) { $best = $c; $ids = [$i]; } elseif ($c === $best) $ids[] = $i;
    }
    return $ids ? $ids[rint(count($ids))] : -1;
}
function all_seats($g) { return array_keys($g['players']); }
function rivals_of($g, $pi) { return array_values(array_filter(array_keys($g['players']), fn($i) => $i !== $pi)); }
function next_seat($g, $pi) { return ($pi + 1) % count($g['players']); }

// ---------- defense ----------
function walled($p) { return $p['shield'] > 0 || ($p['lone'] && count($p['regions']) < 3); }
function add_skip(&$g, $pi, $k) { $g['players'][$pi]['skip'] = min(3, $g['players'][$pi]['skip'] + $k); }
// $steal: the attack takes Regions (an Eclipse in hand answers it). $pierce: walls don't stop it (Ninja Infiltration).
function defend(&$g, $attacker, $target, $steal = false, $pierce = false) {
    $t = $g['players'][$target]; $tn = $t['name'];
    if (!$pierce && $t['shield'] > 0) { $g['blocks']++; say($g, $target, $tn . "'s defenses hold. Attack blocked.", 'block'); return false; }
    if (!$pierce && $t['lone'] && count($t['regions']) < 3) { $g['blocks']++; say($g, $target, $tn . ' is a Lone Survivor. Attack blocked.', 'block'); return false; }
    if (!empty($t['paper'])) { $g['players'][$target]['paper'] = false; $g['blocks']++; give_chaos($g, $target, 1); say($g, $target, $tn . "'s Paper Fortress takes the hit and breaks. Attack blocked.", 'block'); return false; }
    if ($steal) {
        $ec = array_search('eclipse', $g['players'][$target]['hand'], true);
        if ($ec !== false) {
            array_splice($g['players'][$target]['hand'], $ec, 1); $g['chaosDiscard'][] = 'eclipse'; $g['blocks']++; lose_regions($g, $attacker, 1);
            $g['pcx'][] = [$target, 'eclipse'];   //MC 2026-10-13 a reaction fired from hand counts as a play for its holder
            say($g, $target, $tn . ' reveals an Eclipse. ' . $g['players'][$attacker]['name'] . ' loses a Region instead.', 'block'); return false;
        }
    }
    foreach (['assassin', 'failedcoup', 'decoy'] as $r) {
        $at = array_search($r, $g['players'][$target]['hand'], true);
        if ($at === false) continue;
        array_splice($g['players'][$target]['hand'], $at, 1); $g['chaosDiscard'][] = $r; $g['blocks']++;
        //MC 2026-10-13 reaction cards can never be played by hand (can_play says no), so they never reached the mastery
        //   count and their stars were stuck at 0 forever, Gold Leaf at Master included. The trigger is the play.
        $g['pcx'][] = [$target, $r];
        if ($r === 'failedcoup') { give_chaos($g, $target, 1); say($g, $target, $tn . ' reveals a Failed Coup. Attack cancelled.', 'block'); }
        elseif ($r === 'assassin') { add_skip($g, $attacker, 1); say($g, $target, $tn . ' survives a Failed Assassination Attempt. ' . $g['players'][$attacker]['name'] . ' skips their next turn.', 'block'); }
        else say($g, $target, $tn . "'s Holographic Decoy takes the hit. Attack cancelled.", 'block');
        return false;
    }
    return true;
}
function sweep(&$g, $target) {
    if (walled($g['players'][$target])) { $g['blocks']++; say($g, $target, $g['players'][$target]['name'] . "'s defenses hold.", 'block'); return false; }
    return true;
}

// ---------- turns ----------
// returns true when the turn is skipped
function eng_start_turn(&$g) {
    $pi = $g['turn'];
    $g['plays'] = 0;
    if ($g['players'][$pi]['shield'] > 0) $g['players'][$pi]['shield']--;
    if ($g['players'][$pi]['lone'] && count($g['players'][$pi]['regions']) >= 3) $g['players'][$pi]['lone'] = false;
    if ($g['noDraw'] === $pi) $g['noDraw'] = -1;
    if (($g['truce'] ?? -1) === $pi) { $g['truce'] = -1; say($g, $pi, 'The truce ends.', 'info'); }
    if (($g['players'][$pi]['harvest'] ?? 0) > 0) { $hv = gain_deck($g, $pi, $g['players'][$pi]['harvest']); $g['players'][$pi]['harvest'] = 0; if ($hv) say($g, $pi, $g['players'][$pi]['name'] . ' brings in the harvest: ' . plural($hv, 'Region') . '.', 'gain'); }
    if ($g['players'][$pi]['skip'] > 0) {
        $g['players'][$pi]['skip']--;
        say($g, $pi, $g['players'][$pi]['name'] . ' skips this turn.', 'skip');
        return true;
    }
    $g['played'] = false;
    if ($g['noDraw'] < 0) give_chaos($g, $pi, 1);
    $g['plays'] = 1;
    return false;
}
function can_play($id) { return isset(CARDS[$id]) && CARDS[$id]['kind'] !== 'passive'; }
function has_playable($p) { foreach ($p['hand'] as $id) if (can_play($id)) return true; return false; }
function eng_more_plays($g, $pi) { return $g['plays'] > 0 && !$g['over'] && has_playable($g['players'][$pi]); }
//MC 2026-10-12 False Memory undid far more than the last card. The snapshot from before the last card play stayed in the game
//   for as long as nobody played another card, so a player who claimed a Region every turn while saving their hand (eight
//   turns, eight Regions) lost all eight when the Shogun played False Memory: the map went back to how it was before the
//   last card, turns ago. Reported twice in boss matches. Now the snapshot also keeps how the map looked right after that
//   card, and False Memory only works while the map is still exactly that. A claim, a harvest or any other change since
//   means there's nothing to undo. The same change is in assets/game.js so solo replays still match.
function map_key($g) { return implode('|', array_map(fn($p) => implode(',', $p['regions']), $g['players'])) . '#' . count($g['regionDeck']) . '#' . count($g['regionDiscard']); }
function snap_ok($g) { return !empty($g['snap']) && ($g['snap']['after'] ?? null) === map_key($g); }
function snapshot($g) { return ['r' => array_map(fn($p) => $p['regions'], $g['players']), 'deck' => $g['regionDeck'], 'disc' => $g['regionDiscard']]; }

function eng_play(&$g, $pi, $h, $target) {
    $id = $g['players'][$pi]['hand'][$h] ?? null;
    if (!$id || !can_play($id) || $g['plays'] <= 0) return false;
    $c = CARDS[$id];
    if ($c['target'] === 'pick' && ($target === null || $target === $pi || !isset($g['players'][$target]))) return false;
    $before = snapshot($g);
    $g['plays']--; $g['played'] = true;
    array_splice($g['players'][$pi]['hand'], $h, 1); $g['chaosDiscard'][] = $id;
    if ($c['target'] === 'leader') $target = rival_leader($g, $pi);
    $pn = $g['players'][$pi]['name'];
    $tn = ($target !== null && $target >= 0) ? $g['players'][$target]['name'] : '';
    say($g, $pi, $pn . ' plays ' . $c['name'] . ($c['target'] === 'pick' && $tn !== '' ? ' on ' . $tn : '') . '.', 'play', $id);
    if ($c['kind'] === 'attack' && ($g['truce'] ?? -1) >= 0) { say($g, $pi, 'The truce holds. The attack does nothing.', 'block'); $g['snap'] = $before; $g['snap']['after'] = map_key($g); return true; }
    switch ($id) {
        // -- attacks --
        case 'meteor': case 'superweapon':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 2); say($g, $target, $tn . ' loses ' . plural($n, 'Region') . '.', 'hit'); } break;
        case 'plasma':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 3); say($g, $target, $tn . ' loses ' . plural($n, 'Region') . '.', 'hit'); }
            give_chaos($g, $pi, 2); break;
        case 'drone':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 1); say($g, $target, $tn . ' loses ' . plural($n, 'Region') . '.', 'hit'); } break;
        case 'sub':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 1); discard_random($g, $target, 1); say($g, $target, $tn . ' loses ' . plural($n, 'Region') . ' and a card.', 'hit'); } break;
        case 'drones':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 1); say($g, $target, $tn . ' loses ' . plural($n, 'Region') . '.', 'hit'); }
            $q = next_seat($g, $pi); if (discard_random($g, $q, 1)) say($g, $q, $g['players'][$q]['name'] . ' discards a card.', 'hit'); break;
        case 'dictator': case 'border': case 'coup':
            if (defend($g, $pi, $target, true)) { $n = steal_regions($g, $target, $pi, 1); say($g, $pi, $pn . ' steals ' . plural($n, 'Region') . ' from ' . $tn . '.', 'hit'); } break;
        case 'empire':
            if (defend($g, $pi, $target, true)) { $n = steal_regions($g, $target, $pi, 2); give_chaos($g, $target, 2); say($g, $pi, $pn . ' steals ' . plural($n, 'Region') . ' from ' . $tn . '.', 'hit'); } break;
        case 'endera':
            if (defend($g, $pi, $target)) { $n = lose_regions($g, $target, 2); say($g, $target, $tn . ' has the most and loses ' . plural($n, 'Region') . '.', 'hit'); } break;
        case 'pact':
            if (defend($g, $pi, $target)) { lose_regions($g, $pi, 2); lose_regions($g, $target, 2); give_chaos($g, $pi, 3); give_chaos($g, $target, 3); say($g, $pi, $pn . ' and ' . $tn . ' each lose 2 Regions and draw 3 cards.', 'hit'); } break;
        case 'censor': case 'epidemic': case 'newleader':
            if (defend($g, $pi, $target)) { add_skip($g, $target, 1); say($g, $target, $tn . ' will skip their next turn.', 'hit'); } break;
        case 'prophecy':
            if (defend($g, $pi, $target)) { add_skip($g, $target, 1); say($g, $target, $tn . ' will skip their next turn.', 'hit'); }
            give_chaos($g, $pi, 2); break;
        case 'unicoup':
            foreach (rivals_of($g, $pi) as $r) if (sweep($g, $r)) steal_regions($g, $r, $pi, 1);
            say($g, $pi, $pn . ' takes a Region from every rival they can reach.', 'hit'); break;
        case 'machines': case 'popcontrol':
            foreach (rivals_of($g, $pi) as $r) if (sweep($g, $r)) lose_regions($g, $r, 1);
            say($g, $pi, 'Every rival in reach loses a Region.', 'hit'); break;
        // -- gains --
        case 'atlantis': $n = gain_deck($g, $pi, 2); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . '.', 'gain'); break;
        case 'surge': $n = gain_deck($g, $pi, 1); give_chaos($g, $pi, 1); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and a card.', 'gain'); break;
        case 'resource': $n = gain_deck($g, $pi, 1); give_chaos($g, $pi, 3); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and 3 cards.', 'gain'); break;
        case 'space': $n = gain_discard($g, $pi, 1) ?: gain_deck($g, $pi, 1); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . '.', 'gain'); break;
        case 'solar': $n = gain_deck($g, $pi, 2); add_skip($g, $pi, 1); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and rests a turn.', 'gain'); break;
        case 'era': $n = gain_deck($g, $pi, 3); add_skip($g, $pi, 1); say($g, $pi, $pn . ' begins an Era of Expansion and gains ' . plural($n, 'Region') . '.', 'gain'); break;
        case 'reinforce': $n = gain_deck($g, $pi, 2); give_chaos($g, $pi, 2); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and 2 cards.', 'gain'); break;
        case 'prophecyful': $n = gain_deck($g, $pi, 1); give_chaos($g, $pi, 1); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and a card.', 'gain'); break;
        case 'galactic':
            $n = gain_deck($g, $pi, 2); $i = pick_by($g, all_seats($g), true); gain_deck($g, $i, 1);
            say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ', and ' . $g['players'][$i]['name'] . ' gains 1.', 'gain'); break;
        case 'galconsp':
            $n = gain_deck($g, $pi, 2); $i = pick_by($g, rivals_of($g, $pi), false); if (sweep($g, $i)) lose_regions($g, $i, 1);
            say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and the leader loses one.', 'gain'); break;
        case 'tunnels': $n = gain_discard($g, $pi, 1) ?: gain_deck($g, $pi, 1); say($g, $pi, $pn . ' tunnels into ' . plural($n, 'Region') . '.', 'gain'); break;
        case 'summit': $n = gain_deck($g, $pi, 1); add_skip($g, $pi, 1); say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and rests a turn.', 'gain'); break;
        case 'underworld':
            for ($i = 0; $i < 3 && $g['regionDiscard']; $i++) { $n = pick_by($g, all_seats($g), true); gain_discard($g, $n, 1); }
            say($g, $pi, 'The underworld rises. The players with the fewest Regions take back the lost land.', 'gain'); break;
        case 'rekindled':
            $lows = all_seats($g); usort($lows, fn($a, $b) => (count($g['players'][$a]['regions']) - count($g['players'][$b]['regions'])) ?: ($a - $b));
            foreach (array_slice($lows, 0, 2) as $k) gain_discard($g, $k, 1);
            say($g, $pi, 'Hope returns to the two smallest nations.', 'gain'); break;
        case 'secretgov':
            $n = gain_deck($g, $pi, 1);
            $top = []; for ($i = 0; $i < 5 && $g['chaosDeck']; $i++) $top[] = array_pop($g['chaosDeck']);
            if ($top) { $i = best_index($top); $g['players'][$pi]['hand'][] = array_splice($top, $i, 1)[0]; while ($top) $g['chaosDeck'][] = array_pop($top); }
            say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . ' and a hand-picked card.', 'gain'); break;
        case 'awakening':
            $n = gain_deck($g, $pi, 1); foreach (rivals_of($g, $pi) as $r) add_skip($g, $r, 1);
            say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . '. Everyone else skips their next turn.', 'gain'); break;
        // -- defense --
        case 'bunker': $g['players'][$pi]['shield'] = max($g['players'][$pi]['shield'], 2); say($g, $pi, $pn . ' is safe in a bunker for 2 rounds.', 'gain'); break;
        case 'irondome': case 'stronghold': $g['players'][$pi]['shield'] = max($g['players'][$pi]['shield'], 3); say($g, $pi, $pn . ' is protected for 3 rounds.', 'gain'); break;
        case 'lone': $g['players'][$pi]['lone'] = true; say($g, $pi, $pn . " can't be attacked until they hold 3 Regions.", 'gain'); break;
        case 'coop':
            $n = pick_by($g, rivals_of($g, $pi), true);
            $g['players'][$pi]['shield'] = max($g['players'][$pi]['shield'], 2); $g['players'][$n]['shield'] = max($g['players'][$n]['shield'], 2);
            say($g, $pi, $pn . ' and ' . $g['players'][$n]['name'] . ' are protected for 2 rounds.', 'gain'); break;
        // -- everyone --
        case 'boom': foreach (all_seats($g) as $x) gain_deck($g, $x, 1); say($g, $pi, 'Everyone draws a Region.', 'gain'); break;
        case 'forgotten': $n = pick_by($g, all_seats($g), true); $i = gain_deck($g, $n, 4); say($g, $n, $g['players'][$n]['name'] . ' has the fewest and draws ' . plural($i, 'Region') . '.', 'gain'); break;
        case 'overthrow':
            $n = pick_by($g, all_seats($g), true); $i = gain_discard($g, $n, 2);
            say($g, $n, $g['players'][$n]['name'] . ($i ? ' rises up and gains ' . plural($i, 'Region') . '.' : " rises up, but there's nothing left to take back."), 'gain'); break;
        case 'resistance': foreach (all_seats($g) as $x) if (count($g['players'][$x]['regions']) < 3) gain_deck($g, $x, 1); say($g, $pi, 'Anyone under 3 Regions gains one.', 'gain'); break;
        case 'taxation':
            foreach (all_seats($g) as $x) { if (count($g['players'][$x]['regions']) >= 3) lose_regions($g, $x, 1); else gain_deck($g, $x, 1); }
            say($g, $pi, 'Taxes: the rich pay a Region, the poor get one.', 'hit'); break;
        case 'audit':
            foreach (all_seats($g) as $k) if (count($g['players'][$k]['regions']) >= 7 && sweep($g, $k)) { lose_regions($g, $k, 3); say($g, $k, $g['players'][$k]['name'] . ' is audited and loses 3 Regions.', 'hit'); }
            say($g, $pi, 'The audit is done.', 'info'); break;
        case 'rebellion': $n = pick_by($g, all_seats($g), false); lose_regions($g, $n, 2); say($g, $n, $g['players'][$n]['name'] . ' has the most and loses 2 Regions.', 'hit'); break;
        case 'zombie': case 'negotiations': case 'locusts':
            foreach (all_seats($g) as $x) lose_regions($g, $x, 1); say($g, $pi, 'Everyone loses a Region.', 'hit'); break;
        case 'plague': case 'flood':
            foreach (all_seats($g) as $x) if (count($g['players'][$x]['regions']) >= 2) lose_regions($g, $x, 1); say($g, $pi, 'Everyone with 2 or more loses a Region.', 'hit'); break;
        case 'ww3': foreach (all_seats($g) as $x) if (count($g['players'][$x]['regions']) >= 3) lose_regions($g, $x, 2); say($g, $pi, 'Everyone with 3 or more loses 2 Regions.', 'hit'); break;
        case 'mutiny': case 'alien':
            foreach (all_seats($g) as $x) { lose_regions($g, $x, 1); discard_random($g, $x, 1); }
            say($g, $pi, 'Everyone loses a Region and a Chaos card.', 'hit'); break;
        case 'nuclear':
            $at = $pi;
            for ($k = 0; $k < count($g['players']); $k++) {
                $at = next_seat($g, $at);
                if (!$g['players'][$at]['regions']) { say($g, $at, $g['players'][$at]['name'] . ' has nothing left to lose. The chain reaction stops.', 'info'); break; }
                lose_regions($g, $at, 1);
                say($g, $at, $g['players'][$at]['name'] . ' loses a Region in the blast.', 'hit');
            }
            break;
        case 'famine':
            foreach (all_seats($g) as $x) { if ($g['players'][$x]['regions']) lose_regions($g, $x, 1); else add_skip($g, $x, 1); }
            say($g, $pi, 'Famine spreads. Everyone loses a Region, and anyone with none skips their next turn.', 'hit'); break;
        case 'extinction':
            for ($i = 0; $i < 5; $i++) {
                $owners = []; foreach ($g['players'] as $k => $x) for ($r = 0; $r < count($x['regions']); $r++) $owners[] = $k;
                if (!$owners) break;
                lose_regions($g, $owners[rint(count($owners))], 1);
            }
            say($g, $pi, 'Extinction: 5 Regions are wiped off the map.', 'hit'); break;
        case 'winter': foreach (rivals_of($g, $pi) as $r) add_skip($g, $r, 1); say($g, $pi, 'Eternal Winter. Everyone else skips their next turn.', 'skip'); break;
        case 'renaissance': foreach (all_seats($g) as $x) give_chaos($g, $x, 1); say($g, $pi, 'Everyone draws a Chaos card.', 'gain'); break;
        case 'blackhole': case 'anarchy':
            foreach (all_seats($g) as $x) discard_hand($g, $x);
            foreach (all_seats($g) as $x) give_chaos($g, $x, $id === 'blackhole' ? 5 : 4);
            say($g, $pi, 'Every hand is thrown away and redrawn.', 'info'); break;
        case 'cern':
            $hands = array_map(fn($x) => $x['hand'], $g['players']); $np = count($hands);
            foreach (all_seats($g) as $k) $g['players'][$k]['hand'] = $hands[($k - 1 + $np) % $np];
            say($g, $pi, 'Every hand moves one seat to the left.', 'info'); break;
        // -- tricks --
        case 'double': $g['plays'] += 1; say($g, $pi, $pn . ' may play another card.', 'info'); break;
        case 'blitz': $g['plays'] += 2; say($g, $pi, $pn . ' may play 2 more cards.', 'info'); break;
        case 'gravity':
            for ($i = 0; $i < 5 && $g['chaosDeck']; $i++) $g['chaosDiscard'][] = array_pop($g['chaosDeck']);
            $g['extraTurn'] = true; say($g, $pi, $pn . ' will take another turn.', 'info'); break;
        case 'madsci':
            $n = 0; for ($i = 0; $i < 2 && count($g['chaosDiscard']) > 1; $i++) { $g['players'][$pi]['hand'][] = array_splice($g['chaosDiscard'], rint(count($g['chaosDiscard']) - 1), 1)[0]; $n++; }
            if ($n < 2) give_chaos($g, $pi, 2 - $n);
            say($g, $pi, $pn . ' pulls 2 cards from the discard pile.', 'gain'); break;
        case 'superai': case 'neural':
            $look = []; for ($i = 0; $i < 10 && $g['chaosDeck']; $i++) $look[] = array_pop($g['chaosDeck']);
            for ($i = 0; $i < ($id === 'superai' ? 3 : 2) && $look; $i++) $g['players'][$pi]['hand'][] = array_splice($look, best_index($look), 1)[0];
            $g['chaosDeck'] = array_merge($g['chaosDeck'], shuf($look));
            say($g, $pi, $pn . ' studies the deck and keeps the best cards.', 'gain'); break;
        case 'pandora':
            give_chaos($g, $pi, 5);
            for ($i = 0; $i < 3 && $g['players'][$pi]['hand']; $i++) $g['chaosDiscard'][] = array_splice($g['players'][$pi]['hand'], best_index($g['players'][$pi]['hand'], true), 1)[0];
            say($g, $pi, $pn . " opens Pandora's Box.", 'gain'); break;
        case 'conspiracy':
            foreach (rivals_of($g, $pi) as $r) if ($g['players'][$r]['hand']) $g['chaosDiscard'][] = array_splice($g['players'][$r]['hand'], best_index($g['players'][$r]['hand']), 1)[0];
            say($g, $pi, 'Every rival loses their best card.', 'hit'); break;
        case 'currency':
            foreach (rivals_of($g, $pi) as $r) discard_random($g, $r, 2); give_chaos($g, $pi, 2);
            say($g, $pi, 'Every rival discards 2 cards and ' . $pn . ' draws 2.', 'hit'); break;
        case 'netcrash': $g['noDraw'] = $pi; say($g, $pi, 'The internet is down. No one draws on their turn until ' . $pn . ' plays again.', 'info'); break;
        case 'tides':
            $q = next_seat($g, $pi); $tmp = $g['players'][$pi]['hand']; $g['players'][$pi]['hand'] = $g['players'][$q]['hand']; $g['players'][$q]['hand'] = $tmp;
            say($g, $pi, $pn . ' trades hands with ' . $g['players'][$q]['name'] . '.', 'info'); break;
        case 'quantum':
            $tmp = $g['players'][$pi]['hand']; $g['players'][$pi]['hand'] = $g['players'][$target]['hand']; $g['players'][$target]['hand'] = $tmp;
            say($g, $pi, $pn . ' swaps hands with ' . $tn . '.', 'info'); break;
        // -- season cards --
        case 'kamikaze':
            foreach (all_seats($g) as $x) discard_random($g, $x, 1);
            $n = gain_deck($g, $pi, 2); say($g, $pi, $pn . ' calls a divine wind that scatters every hand, and gains ' . plural($n, 'Region') . '.', 'gain'); break;
        case 'decree':
            $fewest = true; foreach ($g['players'] as $k => $x) if ($k !== $pi && count($g['players'][$pi]['regions']) > count($x['regions'])) $fewest = false;
            if (defend($g, $pi, $target, true)) { $n = steal_regions($g, $target, $pi, $fewest ? 2 : 1); say($g, $pi, $pn . ' decrees it and takes ' . plural($n, 'Region') . ' from ' . $tn . '.', 'hit'); } break;
        case 'ninja':
            if (defend($g, $pi, $target, true, true)) { $n = steal_regions($g, $target, $pi, 1); say($g, $pi, $pn . ' slips past the walls and steals ' . plural($n, 'Region') . ' from ' . $tn . '.', 'hit'); } break;
        case 'paper': $g['players'][$pi]['paper'] = true; say($g, $pi, $pn . ' raises a Paper Fortress. It blocks the next attack.', 'gain'); break;
        case 'harvest':
            $n = gain_deck($g, $pi, 1); $g['players'][$pi]['harvest'] = ($g['players'][$pi]['harvest'] ?? 0) + 1; say($g, $pi, $pn . ' gains ' . plural($n, 'Region') . '. More comes in next turn.', 'gain'); break;
        case 'ronin':
            if ($g['players'][$target]['hand']) { $g['players'][$pi]['hand'][] = array_splice($g['players'][$target]['hand'], rint(count($g['players'][$target]['hand'])), 1)[0]; say($g, $pi, $pn . ' hires a ronin and takes a card from ' . $tn . '.', 'hit'); }
            else say($g, $pi, $tn . ' has no cards to take.', 'info');
            break;
        case 'truce': $g['truce'] = $pi; give_chaos($g, $pi, 1); say($g, $pi, 'A truce is called. No one can attack until ' . $pn . "'s next turn.", 'info'); break;
        case 'falsememory':
            if (snap_ok($g)) {
                $s = $g['snap'];
                foreach (all_seats($g) as $k) $g['players'][$k]['regions'] = $s['r'][$k];
                $g['regionDeck'] = $s['deck']; $g['regionDiscard'] = $s['disc'];
                say($g, $pi, "Memories rewritten. The last card's effect on the map is undone.", 'info');
            } else say($g, $pi, "There's nothing to undo yet.", 'info');
            break;
    }
    $g['snap'] = $before; $g['snap']['after'] = map_key($g);
    return true;
}
// ends the current turn; a turn spent building instead of playing claims a Region
function eng_end_turn(&$g) {
    if ($g['plays'] > 0 && !$g['played'] && gain_deck($g, $g['turn'], 1)) say($g, $g['turn'], $g['players'][$g['turn']]['name'] . ' claims a Region.', 'claim');
    $g['plays'] = 0;
    $top = 0; foreach ($g['players'] as $p) $top = max($top, count($p['regions']));
    if (!$g['regionDeck'] || $top >= WIN_AT) { $g['over'] = true; return true; }
    if ($g['extraTurn']) { $g['extraTurn'] = false; return false; }
    $g['turn'] = next_seat($g, $g['turn']);
    if ($g['turn'] === $g['start']) {
        if ($g['round'] >= MAX_ROUNDS) { $g['over'] = true; return true; }
        $g['round']++;
    }
    return false;
}
function eng_standings($g) {
    $s = [];
    foreach ($g['players'] as $i => $p) $s[] = ['i' => $i, 'name' => $p['name'], 'regions' => count($p['regions']), 'hand' => count($p['hand'])];
    usort($s, fn($a, $b) => [$b['regions'], $b['hand'], $a['i']] <=> [$a['regions'], $a['hand'], $b['i']]);
    return $s;
}
function eng_winners($g) {
    $s = eng_standings($g); $top = $s[0];
    return array_values(array_map(fn($x) => $x['i'], array_filter($s, fn($x) => $x['regions'] === $top['regions'] && $x['hand'] === $top['hand'])));
}

// ---------- bots ----------
// $noise null = the browser's solo bots (Easy is looser); a number = live matches. Personalities apply either way.
function eng_bot(&$g, $pi, $noise = null) {
    $solo = $noise === null;
    if ($solo) $noise = !empty($g['easy']) ? 3.5 : 0.6;
    $easyPick = $solo && !empty($g['easy']);
    $p = $g['players'][$pi]; $best = null;
    $bestScore = !$g['played'] && $g['regionDeck'] ? PASS_WORTH : 0.5;
    $mine = count($p['regions']); $others = rivals_of($g, $pi);
    $counts = array_map(fn($x) => count($x['regions']), $g['players']);
    $top = max(array_map(fn($i) => $counts[$i], $others));
    $low = min($counts);
    $sum = 0; foreach ($others as $i) $sum += $counts[$i];
    $avg = $sum / count($others);
    $lead = $mine - $avg;
    $leader = rival_leader($g, $pi);
    $deckLeft = count($g['regionDeck']);
    $openRival = function () use ($g, $others, $counts, $noise, $easyPick) {
        $bi = -1; $bv = -1;
        foreach ($others as $i) {
            if (walled($g['players'][$i])) continue;
            $v = $easyPick ? rnd() * 10 : $counts[$i] + ($noise ? rnd() * 0.5 : 0);
            if ($v > $bv) { $bv = $v; $bi = $i; }
        }
        return $bi;
    };
    $reachRegions = 0; foreach ($others as $i) if (!walled($g['players'][$i])) $reachRegions += min(1, $counts[$i]);
    $HIT = ['meteor' => 2, 'superweapon' => 2, 'plasma' => 3, 'drone' => 1, 'sub' => 1.3, 'drones' => 1.3, 'dictator' => 2, 'border' => 2, 'coup' => 2, 'empire' => 4.5, 'endera' => 2];
    $AMT = ['atlantis' => 2, 'surge' => 1.3, 'resource' => 1.8, 'space' => 1, 'solar' => 2, 'era' => 3, 'secretgov' => 1.5, 'awakening' => 2.6, 'reinforce' => 2.6, 'prophecyful' => 1.3, 'galactic' => 1.8, 'galconsp' => 2.4, 'tunnels' => 1, 'summit' => 1, 'harvest' => 1.8];
    foreach ($p['hand'] as $h => $id) {
        if (!can_play($id)) continue;
        $c = CARDS[$id]; $s = 0; $t = null;
        if ($c['kind'] === 'attack' && ($g['truce'] ?? -1) >= 0) continue;   // a truce makes every attack a wasted card
        if ($id === 'ninja' || $id === 'ronin') {
            // Ninja ignores walls, so aim at the biggest rival; Ronin takes from the fullest hand
            $bi2 = -1; $bv2 = -1;
            foreach ($others as $i) { $v = ($id === 'ninja' ? $counts[$i] : count($g['players'][$i]['hand'])) + ($noise ? rnd() * 0.5 : 0); if ($v > $bv2) { $bv2 = $v; $bi2 = $i; } }
            $t = $bi2;
            if ($t < 0) continue;
            $s = $id === 'ninja' ? ($counts[$t] ? 1.5 + 2 * 1.1 + $counts[$t] * 0.35 + (walled($g['players'][$t]) ? 0.8 : 0) : 0.1) : (count($g['players'][$t]['hand']) ? 1.6 + min(4, count($g['players'][$t]['hand'])) * 0.15 : 0);
        } elseif ($c['target'] === 'pick' || $c['target'] === 'leader') {
            $t = $c['target'] === 'pick' ? $openRival() : $leader;
            if ($t === null || $t < 0) continue;
            $tc = $counts[$t]; $open = !walled($g['players'][$t]);
            if (in_array($id, ['censor', 'epidemic', 'newleader', 'prophecy'], true)) $s = $open ? 1.4 + $tc * 0.3 + ($id === 'prophecy' ? 1.6 : 0) : ($id === 'prophecy' ? 1.6 : 0.1);
            elseif ($id === 'pact') $s = $open && $tc >= $mine ? 1 + ($tc - $mine) * 0.5 : 0;
            elseif ($id === 'quantum') $s = count($g['players'][$t]['hand']) - count($p['hand']) > 1 ? 1.5 : 0;
            else {
                $hit = $id === 'decree' ? ($mine <= $low ? 4 : 2) : ($HIT[$id] ?? 1);
                $s = $open && $tc ? (1.5 + $hit * 1.1 + $tc * 0.35) * STYLE['attackScale'] + ($t === $leader && $counts[$t] >= $top ? STYLE['leaderBonus'] : 0) : ($id === 'plasma' ? 1.2 : 0.1);
            }
        } elseif ($id === 'unicoup') $s = $reachRegions * 1.6;
        elseif ($id === 'machines' || $id === 'popcontrol') $s = $reachRegions * 0.9 + ($lead < 0 ? 0.8 : 0);
        elseif ($c['kind'] === 'gain') {
            $amt = $AMT[$id];
            $s = ($deckLeft || $id === 'space') ? 1.8 + $amt * 1.3 : 0.3;
            if ($id === 'solar' || $id === 'summit') $s -= 1.4;
            if (($id === 'space' || $id === 'tunnels') && !$g['regionDiscard'] && !$deckLeft) $s = 0.3;
            if ($id === 'era') $s -= 1.4;
        } elseif ($c['kind'] === 'defense') {
            $exposed = $mine + ($lead > 0 ? 3 : 0);
            if ($id === 'lone') $s = $mine < 3 && !$p['lone'] ? 2.5 : 0;
            elseif ($id === 'paper') $s = !empty($p['paper']) || $p['shield'] > 0 ? 0 : 0.8 + $exposed * 0.35;
            else $s = $p['shield'] > 0 ? 0 : 0.6 + $exposed * 0.35 + ($id === 'coop' ? 0.3 : 0) + ($id === 'bunker' ? 0 : 0.4);
        } elseif ($c['kind'] === 'global') {
            $behind = -$lead;
            switch ($id) {
                case 'boom': $s = 1.6; break;
                case 'underworld': case 'rekindled': $s = $g['regionDiscard'] ? ($mine === $low ? 3.2 : 0.8) : 0.2; break;
                case 'forgotten': $s = $mine === $low ? 5 : 0.2; break;
                case 'overthrow': $s = $mine === $low && $g['regionDiscard'] ? 3.5 : 0.2; break;
                case 'resistance': $s = $mine < 3 ? 3 : 0.3; break;
                case 'taxation': $s = $mine < 3 ? 2 + $behind * 0.4 : 0.6 + $behind * 0.4; break;
                case 'audit': $s = $mine < 7 && $top >= 7 ? 2 + ($top - 7) * 0.5 : ($top >= 7 ? -3 : 0); break;
                case 'rebellion': $s = $mine < $top ? 3 : -4; break;
                case 'zombie': case 'negotiations': case 'locusts': case 'mutiny': case 'alien': case 'famine': $s = 1 + $behind * 0.6; break;
                case 'plague': case 'flood': $s = $mine < 2 ? 3 : 1 + $behind * 0.5; break;
                case 'ww3': $s = $mine < 3 ? 3 + ($top >= 3 ? 1 : 0) : 0.6 + $behind * 0.5; break;
                case 'nuclear': $s = $counts[next_seat($g, $pi)] ? 1.2 + $behind * 0.5 : 0.2; break;
                case 'extinction': $s = 0.8 + $behind * 0.5; break;
                case 'winter': $s = 4.5; break;
                case 'renaissance': $s = 1; break;
                case 'blackhole': case 'anarchy': $s = count($p['hand']) <= 3 ? 1.8 : 0.4; break;
                case 'cern': $s = count($g['players'][($pi - 1 + count($counts)) % count($counts)]['hand']) - count($p['hand']) >= 2 ? 1.5 : 0.2; break;
                case 'kamikaze': $s = $deckLeft ? 4 - (count($p['hand']) <= 2 ? 0.8 : 0) : 0.3; break;
                case 'truce':
                    $atk = false; foreach ($p['hand'] as $x) if ((CARDS[$x]['kind'] ?? '') === 'attack') $atk = true;
                    $s = 1 + max(0, $lead) * 0.5 - ($atk ? 0.8 : 0); break;
            }
        } elseif ($c['kind'] === 'trick') {
            $playable = 0; foreach ($p['hand'] as $k => $x) if ($k !== $h && can_play($x)) $playable++;
            switch ($id) {
                case 'double': $s = $playable >= 1 ? 2.6 : 0; break;
                case 'blitz': $s = $playable >= 2 ? 3.6 : ($playable ? 1.5 : 0); break;
                case 'gravity': $s = 3; break;
                case 'madsci': $s = 1.8; break;
                case 'superai': $s = 3.2; break;
                case 'neural': $s = 2.6; break;
                case 'pandora': $s = 2.2; break;
                case 'conspiracy': $s = 2.4; break;
                case 'currency': $s = 2.4; break;
                case 'netcrash': $s = 1; break;
                case 'tides': $s = count($g['players'][next_seat($g, $pi)]['hand']) - count($p['hand']) >= 2 ? 1.5 : 0.2; break;
                case 'falsememory':
                    if (!snap_ok($g)) { $s = 0; break; }
                    $nowGap = count($g['snap']['r'][$pi]) - $mine; $rivalGain = 0;
                    foreach ($others as $i) $rivalGain += $counts[$i] - count($g['snap']['r'][$i]);
                    $s = 0.5 + $nowGap * 1.5 + $rivalGain * 0.8; break;
            }
        }
        $style = $p['style'] ?? '';
        if ($style === 'hawk') { if ($c['kind'] === 'attack' && $s > 0.5) $s += STYLE['hawkAttack']; if ($c['kind'] === 'gain') $s -= STYLE['hawkGain']; }
        elseif ($style === 'builder') { if ($c['kind'] === 'gain') $s += STYLE['buildGain']; if ($c['kind'] === 'defense' && $p['shield'] <= 0) $s += STYLE['buildDefense']; if ($c['kind'] === 'attack') $s -= STYLE['buildAttack']; }
        elseif ($style === 'wild') $s += rnd() * STYLE['wild'];
        $s += $noise ? rnd() * $noise : 0;
        if ($s > $bestScore) { $bestScore = $s; $best = ['hand' => $h, 'target' => $t]; }
    }
    return $best;
}
// a whole bot turn after the turn has started: keep playing while the turn allows it
function eng_bot_turn(&$g, $pi, $noise = null) {
    $guard = 0;
    while ($g['plays'] > 0 && !$g['over'] && $guard++ < 8) {
        $ch = eng_bot($g, $pi, $noise);
        if (!$ch) break;
        eng_play($g, $pi, $ch['hand'], $ch['target']);
    }
}

// Replays a solo or Daily game from its seed and the human's moves, exactly as the browser played it.
// $moves: one entry per human decision: ['h' => handIndex or -1 to pass, 't' => target or null].
// After a play the turn continues only if the card allowed another play and the human still has a playable card.
function eng_replay($seed, $easy, $moves) {
    rnd_seed($seed);
    [$names, $styles] = setup_rivals();
    $g = eng_new(array_merge(['You'], $names), array_merge([''], $styles), $easy, 0);
    $mi = 0; $guard = 0; $err = null; $played = [];
    while (!$g['over'] && $guard++ < 400) {
        $pi = $g['turn'];
        if (!eng_start_turn($g)) {
            if ($pi === 0) {
                while (true) {
                    $m = $moves[$mi++] ?? null;
                    if (!is_array($m)) { $err = 'moves ended early'; break 2; }
                    $h = (int)($m['h'] ?? -1);
                    if ($h < 0) break;
                    $t = isset($m['t']) && $m['t'] !== null ? (int)$m['t'] : null;
                    $cid = $g['players'][0]['hand'][$h] ?? null;
                    if (!eng_play($g, 0, $h, $t)) { $err = 'illegal move'; break 2; }
                    $played[] = $cid;
                    if (!eng_more_plays($g, 0)) break;
                }
            } else eng_bot_turn($g, $pi, null);
        }
        eng_end_turn($g);
    }
    rnd_seed(null);
    if ($err) return ['err' => $err];
    if ($mi !== count($moves)) return ['err' => 'extra moves'];
    //MC 2026-10-13 reactions the player's hand fired on its own count as plays too, or their mastery could never move
    foreach ($g['pcx'] ?? [] as [$si, $cid]) if ($si === 0) $played[] = $cid;
    $w = eng_winners($g);
    $regions = array_map(fn($p) => count($p['regions']), $g['players']);
    return ['regions' => $regions[0], 'all' => $regions, 'result' => in_array(0, $w, true) ? (count($w) > 1 ? 'tie' : 'win') : 'loss', 'winners' => $w, 'cards' => $played];
}

//MC 2026-10-11 the Daily's deal. It was crc32('shy-daily-' . day), so anyone could work out any day's deal in advance,
//   search the move tree offline with the public engine (assets/game.js) and play the best line on the run that counts
//   for the Daily League. Now it's an HMAC of the day with a secret kept in shy-data (made once, on first use), so a
//   Daily's deal is only known once someone starts it. Still the same deal for everyone that day, and the server replays
//   from it exactly as before (eng_replay, lb.php submit, replay.php). Days before the secret existed keep their old
//   seed so their replays still play back; if no Daily was finished yet today the new seed starts today, otherwise
//   tomorrow, so nobody's run today is replayed on a different deal.
//   Tried deriving it from a constant in the code first: the code is in every site zip, so that's no secret at all.
function daily_seed($day) {
    $old = (int)sprintf('%u', crc32('shy-daily-' . $day));
    $f = DATA_DIR . '/daily-secret.php';
    $s = is_file($f) ? load($f) : [];
    //MC 2026-10-14 the key has to be a real string: a torn or restored secret once left 'k' as something else (an array),
    //   and hash_hmac below threw a TypeError that fataled every Daily start (empty 500, board stuck at nobody today). A
    //   bad key now regenerates exactly like a missing one instead of crashing, so one mangled file can't close the Daily.
    $kok = fn($x) => isset($x['k']) && is_string($x['k']) && $x['k'] !== '';
    if (!$kok($s)) {
        $daily = load(DATA_DIR . '/daily.php');
        $new = ['k' => bin2hex(random_bytes(32)), 'since' => empty($daily[today()]) ? today() : gmdate('Y-m-d', time() + 86400), 'made' => time()];
        $tmp = $f . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (@file_put_contents($tmp, GUARD . json_encode($new)) !== false) {
            //MC 2026-10-14 link() creates the secret when none exists and loses the race to the first writer (so two first
            //   requests can't end up with two secrets). If that fails it is one of two cases: the secret already exists and
            //   is fine (another request wrote it), or the file is there but corrupt and has to be replaced. Only the corrupt
            //   case renames over it; the old code never did, so a mangled secret stayed mangled and every Daily fell back to
            //   the guessable crc32 deal. Re-read deciding this, so a good secret a racer just wrote is never stomped.
            if (!@link($tmp, $f)) { clearstatcache(); if (!$kok(is_file($f) ? load($f) : [])) @rename($tmp, $f); }
            @unlink($tmp);
        }
        clearstatcache();
        $s = load($f);
        if (!$kok($s)) return $old;   // storage trouble: the old deal rather than no Daily at all
    }
    $since = is_string($s['since'] ?? null) ? $s['since'] : '';
    if ($since !== '' && strcmp($day, $since) < 0) return $old;
    return (int)hexdec(substr(hash_hmac('sha256', 'shy-daily-' . $day, $s['k']), 0, 8));
}
//MC 2026-10-11 who has started today's Daily, so a run left after its first move can't be dealt again as a fresh run
//   (the audit's "Daily can be scouted"). day => pid => ['t' => game ticket, 'b' => 1 once the first move was made].
//   Kept for 3 days. Called inside lb.php's lock.
if (!defined('DAILY_RUNS') && defined('DATA_DIR')) define('DAILY_RUNS', DATA_DIR . '/daily-runs.php');
function daily_runs_tidy($runs) { krsort($runs); return array_slice($runs, 0, 3, true); }
