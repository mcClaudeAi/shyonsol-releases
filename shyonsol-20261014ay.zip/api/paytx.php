<?php
//MC 2026-10-10 Solana Pay transaction request for $SHY shop orders that burn part of the price.
//   A plain Solana Pay link can only ask for one transfer, so a phone that scans the checkout QR (or taps "Other wallet
//   app") gets this URL instead. The wallet asks it for the whole transaction: the price minus the burn to the marketing
//   wallet, the burn itself, the order's reference key and memo. The wallet shows it, the buyer signs, and the shop finds
//   it on Solana by the reference like any other payment. Nothing here signs anything or holds a key.
//   GET  ?o=ORDER          -> {label, icon}
//   POST ?o=ORDER {account} -> {transaction: base64, message}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept, Accept-Encoding');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') exit;
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

const MEMO_PROGRAM = 'MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    echo json_encode(['label' => 'Shilluminati Online', 'icon' => (defined('TG_SITE') ? TG_SITE : 'https://shyonsol.io') . '/assets/art/icon-192.png']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$id = (string)($_GET['o'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $id)) fail('bad order');
$body = json_decode((string)file_get_contents('php://input'), true) ?: [];
$acct = (string)($body['account'] ?? '');
if (!valid_wallet($acct)) fail('bad account');
$ok = with_lock(function () { $l = load(LIMITS); $r = rate_ok($l, 'paytx:' . client_ip(), 30, 600); save(LIMITS, $l); return $r; });
if (!$ok) fail('Slow down a little and try again.', 429);
$o = load(ORDERS)[$id] ?? null;
if (!$o || ($o['cur'] ?? '') !== 'SHY' || empty($o['burn'])) fail('That order isn\'t a $SHY payment.', 404);
if ($o['status'] === 'paid') fail('That order is already paid.', 409);
if (time() > $o['exp']) fail('The price on this order ran out. Start a new purchase in the shop.', 410);

$built = paytx_build($o, $acct);
if (isset($built['err'])) fail($built['err'], 400);
$tx = $built['tx'];
with_lock(function () use ($id, $acct) { $orders = load(ORDERS); if (isset($orders[$id])) { $orders[$id]['txreq'] = time(); $orders[$id]['txreq_by'] = $acct; save(ORDERS, $orders); } });
$fmt = fn($u) => rtrim(rtrim(number_format($u / pow(10, $o['dec']), min(6, $o['dec']), '.', ','), '0'), '.');
out(['transaction' => base64_encode($tx),
    'message' => $o['name'] . ': ' . $fmt($o['units'] - $o['burn']) . ' $SHY to the community wallet, ' . $fmt($o['burn']) . ' $SHY burned (' . (int)($o['bpct'] ?? 0) . '%).']);

// ---------------------------------------------------------------- building the transaction
// Solana's compact length ("shortvec")
function sv($n) { $o = ''; do { $b = $n & 0x7f; $n >>= 7; if ($n) $b |= 0x80; $o .= chr($b); } while ($n); return $o; }
// the payer's token account for the mint with the most in it, or null
function paytx_token_account($owner, $mint, $need = 0) {
    $r = rpc('getTokenAccountsByOwner', [$owner, ['mint' => $mint], ['encoding' => 'jsonParsed', 'commitment' => 'confirmed']]);
    $best = null; $bal = -1;
    foreach ($r['value'] ?? [] as $a) {
        $u = (int)($a['account']['data']['parsed']['info']['tokenAmount']['amount'] ?? 0);
        if ($u > $bal) { $bal = $u; $best = ['addr' => $a['pubkey'], 'units' => $u, 'prog' => $a['account']['owner'] ?? '']; }
    }
    return $best;
}
// the unsigned transaction as bytes, or why it can't be built
function paytx_build($o, $payer) {
    $src = paytx_token_account($payer, $o['mint']);
    if (!$src) return ['err' => 'This wallet holds no $SHY. Buy some on the Token page first.'];
    if ($src['units'] < $o['units']) return ['err' => 'This wallet has ' . number_format($src['units'] / pow(10, $o['dec'])) . ' $SHY. This purchase needs ' . number_format($o['units'] / pow(10, $o['dec'])) . '.'];
    $dst = paytx_token_account($o['to'], $o['mint']);
    if (!$dst) return ['err' => 'The community wallet has no $SHY account yet. Tell the team.'];
    $prog = $src['prog'] ?: (rpc('getAccountInfo', [$o['mint'], ['encoding' => 'base64']])['value']['owner'] ?? '');
    if (!valid_wallet($prog)) return ['err' => 'Couldn\'t read the token from Solana. Try again.'];
    $bh = rpc('getLatestBlockhash', [['commitment' => 'confirmed']])['value']['blockhash'] ?? '';
    if (!$bh) return ['err' => 'Couldn\'t reach Solana. Try again.'];
    $b = paytx_bytes($payer, $src['addr'], $dst['addr'], $o['mint'], $prog, $o['ref'], MEMO_PROGRAM, $bh, (int)$o['units'] - (int)$o['burn'], (int)$o['burn'], (int)$o['dec'], 'shy:' . $o['id']);
    return strlen($b) > 64 ? ['tx' => $b] : ['err' => 'Couldn\'t build the payment. Try again.'];
}
// A legacy transaction with one signature slot (the payer's, left empty for the wallet to fill):
// TransferChecked to the marketing wallet with the reference key attached, BurnChecked, and the memo.
function paytx_bytes($payer, $src, $dst, $mint, $prog, $ref, $memoProg, $blockhash, $send, $burn, $dec, $memo) {
    // accounts: the signer first, then writable, then read-only
    $keys = [$payer, $src, $dst, $mint, $prog, $ref, $memoProg];
    $bin = array_map('b58_decode', $keys);
    foreach ($bin as $b) if ($b === null || strlen($b) !== 32) return 'bad key';
    $bh = b58_decode($blockhash); if ($bh === null || strlen($bh) !== 32) return 'bad blockhash';
    $ix = function ($prog, $accts, $data) { return chr($prog) . sv(count($accts)) . implode('', array_map('chr', $accts)) . sv(strlen($data)) . $data; };
    $ixs = [
        $ix(4, [1, 3, 2, 0, 5], chr(12) . pack('P', $send) . chr($dec)),   // TransferChecked: source, mint, destination, owner (+ reference)
        $ix(6, [], $memo),
    ];
    if ($burn > 0) array_splice($ixs, 1, 0, [$ix(4, [1, 3, 0], chr(15) . pack('P', $burn) . chr($dec))]);   // BurnChecked: account, mint, owner
    // header: 1 signature, 0 read-only signers, 3 read-only accounts (token program, reference, memo program)
    $msg = chr(1) . chr(0) . chr(3) . sv(count($bin)) . implode('', $bin) . $bh . sv(count($ixs)) . implode('', $ixs);
    return sv(1) . str_repeat("\0", 64) . $msg;
}
