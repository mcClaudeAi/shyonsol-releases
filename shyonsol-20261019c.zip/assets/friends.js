// Friends on every page: the Friends panel (requests, friends online, Duels, this week's board), notices for
// friend requests, live challenges and Duels, invite links, and browser notifications for players who want them.
// The game page adds the playing part: ShyPlay.duel() runs a Duel, ShyPlay.liveChallenge() opens a room for a friend.
(function () {
  "use strict";
  var API = "/api/friends.php";
  var $ = function (id) { return document.getElementById(id); };
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); try { crypto.getRandomValues(a); } catch (e) { for (var i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256); } return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  function me() {
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid) { pid = hex(8); store("shy-lb-pid", pid); }
    if (!key) { key = hex(16); store("shy-lb-key", key); }
    return { pid: pid, key: key };
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function play() { return window.ShyPlay || null; }
  async function api(body) {
    var m = me();
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: m.pid, key: m.key }, body)) });
      var j = await r.json(); if (j && !j.ok) j.status = r.status; return j || { ok: false, error: "Something went wrong." };
    } catch (e) { return { ok: false, error: "Couldn't reach the site. Check your connection." }; }
  }
  function toast(t) {
    var P = play(); if (P && P.toast) return P.toast(esc(t));
    var el = $("fr-toast");
    if (!el) { el = document.createElement("div"); el.id = "fr-toast"; el.className = "fr-toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = t; el.classList.add("in"); clearTimeout(toast.tm); toast.tm = setTimeout(function () { el.classList.remove("in"); }, 3600);
  }
  function ago(ts) {
    var s = Math.max(0, Date.now() / 1000 - ts);
    if (!ts) return "";
    if (s < 3600) return Math.max(1, Math.round(s / 60)) + " min ago";
    if (s < 86400) return Math.round(s / 3600) + "h ago";
    return Math.round(s / 86400) + (Math.round(s / 86400) === 1 ? " day ago" : " days ago");
  }
  function left(ts) { var s = Math.max(0, ts - Date.now() / 1000); return s >= 3600 ? Math.floor(s / 3600) + "h " + Math.floor(s % 3600 / 60) + "m" : Math.max(1, Math.floor(s / 60)) + "m"; }
  function regions(n) { return n + (n === 1 ? " Region" : " Regions"); }
  function face(x) {
    var src = x.img || (/^[a-z]+$/.test(x.skin || "") ? "/assets/art/skins/skin_" + x.skin + ".svg" : "");
    var lk = x.img && /^[a-z]+$/.test(x.aura || "") ? " av-aura au-" + x.aura + (/^[a-z]+$/.test(x.halo || "") ? " hl-" + x.halo : "") : "";
    return src ? '<img class="fr-av' + lk + '" src="' + esc(src) + '" alt="" loading="lazy">' : '<span class="fr-av fr-ini" aria-hidden="true">' + esc((x.name || "?").charAt(0).toUpperCase()) + '</span>';
  }
  function link(id) { return location.origin + "/play?friend=" + id; }

  var S = { list: null, counts: { requests: 0, duels: 0, online: 0, friends: 0, all: 0 }, faces: [], tab: "friends", pick: false, timer: null, shown: {}, fq: "", ff: "all", fpage: 1, fd: { f: "all", q: "", page: 1, data: null }, fdTimer: null, fdType: null };

  // ---------- the badge on the Friends buttons ----------
  function badge() {
    var c = S.counts, n = c.requests + c.duels;
    document.querySelectorAll(".fr-dot").forEach(function (d) { d.hidden = !n; d.textContent = n > 9 ? "9+" : n || ""; });
    document.querySelectorAll("[data-fr-count]").forEach(function (el) {
      el.innerHTML = c.friends ? (c.online ? '<i class="fr-on"></i>' + c.online + " online" : c.friends + (c.friends === 1 ? " friend" : " friends")) : "Add friends";
    });
    document.querySelectorAll("[data-fr-badge]").forEach(function (el) { el.hidden = !n; el.textContent = n; });
    //MC 2026-10-09 the lobby's "players online now" strip: a few faces and the count, opens the Online tab
    document.querySelectorAll("[data-fr-online]").forEach(function (el) {
      el.hidden = !c.all;
      if (!c.all) return;
      el.innerHTML = '<span class="g-on-faces" aria-hidden="true">' + S.faces.map(function (f) { return face(f); }).join("") + '</span><span class="g-on-t"><b><i class="fr-on"></i>' + (c.all === 1 ? "1 player online now" : c.all + " players online now") + '</b><small>See who\'s on and invite them to a match</small></span><span class="g-on-go" aria-hidden="true">&rsaquo;</span>';
    });
  }

  // ---------- polling: online status, and anything new ----------
  async function poll() {
    if (document.hidden) return;
    var j = await api({ a: "poll" });
    if (!j.ok) return;
    S.counts = { requests: j.requests, duels: j.duels, online: j.online, friends: j.friends, all: j.all || 0 };
    S.faces = j.faces || []; S.hidden = !!j.hidden;
    badge();
    //MC 2026-10-10 a challenge to the room you're already sitting in (you came in by the link) still popped "Join the match"
    var P1 = play(), here = P1 && P1.liveCode && P1.liveCode();
    var fresh = (j.notices || []).filter(function (n) { if (here && n.k === "live" && n.d && n.d.code === here) { S.shown[n.id] = 1; api({ a: "seen", ids: [n.id] }); return false; } return !S.shown[n.id]; });
    if (fresh.length) {
      // the most urgent first; a phone shows one card and points to the rest
      var rank = { live: 0, duel: 1, req: 2, duelres: 3, acc: 4 };
      fresh.sort(function (x, y) { return (rank[x.k] == null ? 9 : rank[x.k]) - (rank[y.k] == null ? 9 : rank[y.k]); });
      var max = matchMedia("(max-width:640px)").matches ? 1 : 3;
      fresh.slice(0, max).reverse().forEach(function (n, i, arr) { note(n, i === arr.length - 1 ? fresh.length - max : 0); });
      fresh.forEach(function (n) { S.shown[n.id] = 1; });
      api({ a: "seen", ids: fresh.map(function (n) { return n.id; }) });
      if (panel() && !panel().hidden) load();
    }
  }
  //MC 2026-10-11 every 3 minutes instead of every minute while a game is on (html.g-playing): fewer calls under the table
  function schedule() { clearTimeout(S.timer); S.timer = setTimeout(function () { poll().then(schedule, schedule); }, document.documentElement.classList.contains("g-playing") ? 180000 : 60000); }
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { poll(); schedule(); } });

  // ---------- notice cards ----------
  function notesBox() {
    var b = $("fr-notes");
    if (!b) { b = document.createElement("div"); b.id = "fr-notes"; b.className = "fr-notes"; b.setAttribute("aria-live", "polite"); document.body.appendChild(b); }
    return b;
  }
  function note(n, more) {
    S.shown[n.id] = 1;
    var btns = "";
    //MC 2026-10-09 a challenge that lands mid-game can be lined up for when the game ends (an idea from the board)
    var P0 = play(), mid = n.k === "live" && P0 && P0.playing && P0.playing();
    if (mid) btns = '<button class="btn btn-red btn-sm" data-fr-next="' + esc(n.d.code) + '|' + esc(n.from) + '|' + esc(n.name) + '">Join after this game</button><a class="btn btn-line btn-sm" href="/play?room=' + esc(n.d.code) + '&go=1" data-fr-join="' + esc(n.d.code) + '">Leave and join now</a><button class="btn btn-line btn-sm" data-fr-close>Not now</button>';
    else if (n.k === "live") btns = '<a class="btn btn-red btn-sm" href="/play?room=' + esc(n.d.code) + '&go=1" data-fr-join="' + esc(n.d.code) + '">Join the match</a><button class="btn btn-line btn-sm" data-fr-close>Not now</button>';
    else if (n.k === "duel") btns = '<button class="btn btn-red btn-sm" data-fr-play="' + esc(n.d.id) + '">Play the Duel</button><button class="btn btn-line btn-sm" data-fr-close>Later</button>';
    else if (n.k === "req") btns = '<button class="btn btn-mint btn-sm" data-fr-act="accept:' + esc(n.from) + '">Accept</button><button class="btn btn-line btn-sm" data-fr-act="decline:' + esc(n.from) + '">Decline</button>';
    else if (n.k === "acc") btns = '<button class="btn btn-mint btn-sm" data-fr-duel="' + esc(n.from) + '">Duel them</button><button class="btn btn-line btn-sm" data-fr-close>OK</button>';
    else if (n.k === "duelres") btns = '<button class="btn btn-mint btn-sm" data-fr-duel="' + esc(n.from) + '">Rematch</button><button class="btn btn-line btn-sm" data-fr-close>OK</button>';
    else btns = '<button class="btn btn-line btn-sm" data-fr-close>OK</button>';
    var el = document.createElement("div");
    el.className = "fr-note k-" + n.k;
    el.innerHTML = '<span class="fr-note-ic" aria-hidden="true">' + ({ live: "⚔️", duel: "🎴", req: "👋", acc: "🤝", duelres: "🏁", duelno: "🎴", ref: "🎁", house: "🏯", later: "⏳", liveno: "🎴" }[n.k] || "🔔") + '</span><div><b>' + esc(n.title) + '</b><p>' + esc(n.body) + '</p><div class="fr-note-b">' + btns + '</div>' + (more > 0 ? '<button class="fr-note-more" data-friends>+' + more + ' more in Friends</button>' : "") + '</div><button class="fr-note-x" data-fr-close aria-label="Close">&times;</button>';
    notesBox().appendChild(el);
    requestAnimationFrame(function () { el.classList.add("in"); });
    if (["live", "duel", "req"].indexOf(n.k) < 0) setTimeout(function () { closeNote(el); }, 15000);
    var P = play(); if (P && P.sfx && (n.k === "live" || n.k === "duel")) P.sfx("badge");
  }
  function closeNote(el) { if (!el) return; el.classList.remove("in"); setTimeout(function () { el.remove(); }, 250); }

  // ---------- the panel ----------
  function panel() { return $("fr"); }
  // pick: true or "live" to pick a friend for your room, "online" to open on the Online now tab
  function openPanel(pick) {
    var p = panel();
    if (!p) { p = document.createElement("div"); p.id = "fr"; p.className = "fr"; p.hidden = true; document.body.appendChild(p); p.addEventListener("keydown", trap); }
    //MC 2026-10-09 remember who opened the panel so focus goes back there on close (keyboard users were left on <body>)
    if (p.hidden) S.opener = document.activeElement;
    S.pick = pick === true || pick === "live"; if (S.pick) S.tab = "friends";
    if (pick === "online") { S.tab = "find"; S.fd.f = "online"; S.fd.page = 1; }
    if (pick === "find") S.tab = "find";
    p.hidden = false; document.documentElement.classList.add("fr-open");
    requestAnimationFrame(function () { p.classList.add("in"); });
    render(); load();
    if (S.tab === "find") loadFind();
  }
  function closePanel() {
    var p = panel(); if (!p || p.hidden) return; p.classList.remove("in"); document.documentElement.classList.remove("fr-open"); setTimeout(function () { p.hidden = true; }, 200);
    clearTimeout(S.fdTimer);
    var o = S.opener; S.opener = null; if (o && o.focus && document.contains(o)) try { o.focus({ preventScroll: true }); } catch (e) {}
  }
  //MC 2026-10-09 the panel says aria-modal but Tab walked straight out to the page behind it. Keep Tab and Shift+Tab inside the panel
  function trap(e) {
    if (e.key !== "Tab") return;
    var pn = panel().querySelector(".fr-panel"); if (!pn) return;
    var f = [].filter.call(pn.querySelectorAll("a[href],button:not([disabled]),input,select,textarea,summary,[tabindex='0']"), function (x) { return x.offsetParent; });
    if (!f.length) return;
    var a = document.activeElement;
    if (!pn.contains(a)) { e.preventDefault(); f[0].focus(); }
    else if (e.shiftKey && a === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
    else if (!e.shiftKey && a === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
  }
  // a selector that finds the same control again after render() swaps the panel's HTML
  function focusKey(el) {
    if (!el || !el.attributes) return "";
    if (el.id) return "#" + el.id;
    for (var i = 0; i < el.attributes.length; i++) { var at = el.attributes[i]; if (at.name.indexOf("data-fr") === 0) return el.tagName.toLowerCase() + "[" + at.name + '="' + String(at.value).replace(/["\\]/g, "\\$&") + '"]'; }
    return "";
  }
  async function load() {
    var j = await api({ a: "list" });
    if (!j.ok) { S.err = j.error; render(); return; }
    S.err = ""; S.list = j;
    S.counts.friends = j.friends.length; S.counts.requests = j.in.length;
    S.counts.online = j.friends.filter(function (f) { return f.online; }).length;
    S.counts.duels = j.duels.filter(function (d) { return d.turn && !d.challenger; }).length;
    badge(); render();
  }
  function render() {
    var p = panel(); if (!p || p.hidden) return;
    var L = S.list, keep = p.querySelector(".fr-body"), top = keep ? keep.scrollTop : 0, typed = (p.querySelector("#fr-add") || {}).value || "";
    var fk = p.contains(document.activeElement) ? focusKey(document.activeElement) : "";
    var h = '<div class="fr-back" data-fr-x></div><div class="fr-panel" role="dialog" aria-modal="true" aria-label="Friends">' +
      '<header class="fr-head"><div><b>Friends</b><small>' + (S.pick ? "Pick a friend to challenge to your room" : "Challenge friends live, or Duel them on the same deal") + '</small></div><button class="fr-x" data-fr-x aria-label="Close">&times;</button></header>';
    if (!L) { p.innerHTML = h + '<div class="fr-body"><p class="fr-empty">' + esc(S.err || "Loading…") + '</p></div></div>'; refocus(p, fk); return; }
    var turn = L.duels.filter(function (d) { return d.turn; }).length;
    //MC 2026-10-09 the hub: your friends, requests, finding new players, Duels and the weekly board, like a game's friends list
    h += '<nav class="fr-tabs" role="tablist">' + [["friends", "Friends", 0], ["requests", "Requests", L.in.length], ["find", "Find players", 0], ["duels", "Duels", turn], ["board", "This week", 0]].map(function (t) {
      return '<button role="tab" aria-selected="' + (S.tab === t[0]) + '" data-fr-tab="' + t[0] + '"' + (S.tab === t[0] ? ' class="on"' : "") + '>' + (t[0] === "find" ? '<svg class="fr-tic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>' : "") + t[1] + (t[2] ? ' <i class="sh-dot">' + (t[2] > 99 ? "99+" : t[2]) + '</i>' : "") + '</button>';
    }).join("") + '</nav><div class="fr-body">';
    if (S.tab === "friends") h += viewFriends(L);
    else if (S.tab === "requests") h += viewRequests(L);
    else if (S.tab === "find") h += viewFind(L);
    else if (S.tab === "duels") h += viewDuels(L);
    else h += viewBoard(L);
    h += '</div></div>';
    p.innerHTML = h;
    var nb = p.querySelector(".fr-body"); if (nb) nb.scrollTop = top;
    var inp = p.querySelector("#fr-add"); if (inp && typed) inp.value = typed;
    refocus(p, fk);
  }
  //MC 2026-10-09 every render rebuilds the panel, which dropped focus to <body>. Put it back on the same control, else on the open tab (or the close button while loading)
  function refocus(p, fk) {
    var el = null;
    if (fk) try { el = p.querySelector(fk); if (el) { el.focus({ preventScroll: true }); if (el.setSelectionRange && el.type === "search") el.setSelectionRange(el.value.length, el.value.length); } } catch (e) {}
    if (el && document.activeElement === el) return;
    if (p.contains(document.activeElement)) return;
    el = p.querySelector(".fr-tabs .on") || p.querySelector(".fr-x");
    if (el) try { el.focus({ preventScroll: true }); } catch (e) {}
  }
  //MC 2026-10-10 a friend's $SHY Army Rank as its emblem, the name on hover
  //MC 2026-10-11 "Kusama King / Queen" with spaces, as the server, the Token page and the profile spell it
  var RKN = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King / Queen", supreme: "Shytoshi Supreme" };
  function tierTag(f) { return f.tier && RKN[f.tier] ? ' <em class="tier-b rk ico t-' + f.tier + '" title="' + RKN[f.tier] + '" data-i18n-skip><img src="/assets/ranks/' + f.tier + '-64.webp" alt="' + RKN[f.tier] + '" width="20" height="20"></em>' : ""; }
  function nameLink(f) { return '<a class="fr-pp" href="/p/' + encodeURIComponent(String(f.name || "").replace(/ /g, "_")) + '" data-i18n-skip>' + esc(f.name) + '</a>' + (f.holder ? ' <span class="fr-h1" title="Holder">💎</span>' : "") + tierTag(f); }
  //MC 2026-10-10 a player's Profile Studio portrait frame, still in the list and playing when the row is hovered
  function avatar(f) { return '<span class="fr-avw">' + (/^[a-z]+$/.test(f.pfr || "") && window.ShyLook && ShyLook.frame ? ShyLook.frame(f.pfr, face(f)) : face(f)) + (f.online ? '<i class="on-dot" aria-hidden="true"></i>' : "") + '</span>'; }
  function seenLine(f) { return f.online ? '<span class="fr-onl"><i class="fr-on"></i>Online now</span>' : '<span>' + (f.seen ? "Seen " + ago(f.seen) : "Not on yet") + '</span>'; }
  function search(attr, val, ph) { return '<label class="fr-search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg><input type="search" ' + attr + ' value="' + esc(val) + '" placeholder="' + ph + '" autocomplete="off" maxlength="40" aria-label="' + ph + '"></label>'; }
  function chips(attr, list, on) { return '<div class="fr-chips2" role="group">' + list.map(function (c) { return '<button type="button" ' + attr + '="' + c[0] + '"' + (c[0] === on ? ' class="on" aria-pressed="true"' : ' aria-pressed="false"') + '>' + (c[0] === "online" ? '<i class="fr-on" aria-hidden="true"></i>' : "") + c[1] + (c[2] != null ? ' <small>' + c[2] + '</small>' : "") + '</button>'; }).join("") + '</div>'; }

  // ---------- Friends: everyone you've added, online first, with a search and pages of 8 ----------
  function friendRows() {
    var L = S.list, q = S.fq.trim().toLowerCase();
    var list = L.friends.filter(function (f) { return (S.ff !== "online" || f.online) && (!q || String(f.name).toLowerCase().indexOf(q) >= 0 || f.id === q); });
    if (!list.length) return '<p class="fr-empty">' + (q ? "None of your friends match that." : "None of your friends are online right now.") + '</p>';
    var P = window.ShyPager ? ShyPager.slice(list, 8, S.fpage) : { items: list, page: 1, pages: 1 };
    S.fpage = P.page;
    return '<ul class="fr-list">' + P.items.map(function (f) {
      var rec = f.rec[0] + f.rec[1] + f.rec[2] ? " &middot; <span>Duels " + f.rec[0] + "&ndash;" + f.rec[1] + (f.rec[2] ? "&ndash;" + f.rec[2] : "") + "</span>" : "";
      return '<li class="' + (f.online ? "on" : "") + '">' + avatar(f) + '<div class="fr-t"><b>' + nameLink(f) + '</b><small>' + seenLine(f) + (f.wpts ? ' &middot; <span>' + f.wpts.toLocaleString() + ' pts this week</span>' : "") + rec + '</small></div>' +
        '<div class="fr-b"><button class="btn btn-red btn-sm" data-fr-live="' + f.id + '" title="Open a private room and call them in">Invite to play</button><button class="btn btn-mint btn-sm" data-fr-duel="' + f.id + '" title="Same deal for both of you, one shot each">Duel</button>' +
        '<details class="fr-more"><summary aria-label="More">&middot;&middot;&middot;</summary><div><a href="/p/' + encodeURIComponent(String(f.name || "").replace(/ /g, "_")) + '">See their page</a><button data-fr-act="remove:' + f.id + '">Remove friend</button><button data-fr-act="block:' + f.id + '">Block</button></div></details></div></li>';
    }).join("") + '</ul>' + (window.ShyPager ? ShyPager.html(P, "frf") : "");
  }
  function viewFriends(L) {
    var h = "";
    if (!L.me.name) h += '<p class="fr-warn">Pick a player name first: play a game and save your score, or set it on <a href="/profile">your profile</a>. Friends find you by it.</p>';
    var on = L.friends.filter(function (f) { return f.online; }).length;
    if (!L.friends.length) {
      h += '<div class="fr-zero"><span class="fr-zero-ic" aria-hidden="true">👥</span><b>No friends yet</b><p>Find players you\'ve met in live matches, or send your invite link to the people you play with. Friends can call each other into live matches and Duel on the same deal.</p>' +
        '<div class="fr-zero-b"><button class="btn btn-red" data-fr-tab="find">Find players</button><button class="btn btn-line" data-fr-copy="' + esc(link(L.me.id)) + '">Copy invite link</button></div></div>';
    } else {
      h += '<div class="fr-sum"><div><b>' + (L.friends.length === 1 ? "1 friend" : L.friends.length + " friends") + '</b>' + (on ? '<span class="fr-onl"><i class="fr-on"></i>' + on + " online</span>" : "") + '</div><button class="btn btn-line btn-sm" data-fr-tab="find">+ Add friends</button></div>';
      h += '<div class="fr-tools">' + search('data-fr-fq', S.fq, "Search your friends") + chips("data-fr-ff", [["all", "All", L.friends.length], ["online", "Online", on]], S.ff) + '</div>';
      h += '<div id="fr-flist">' + friendRows() + '</div>';
    }
    h += notifyBox(L);
    return h;
  }

  // ---------- Requests: people who asked you, people you asked, and anyone blocked ----------
  function viewRequests(L) {
    var h = "";
    if (!L.in.length && !L.out.length && !L.blocked.length) return '<div class="fr-zero"><span class="fr-zero-ic" aria-hidden="true">📭</span><b>No requests</b><p>When someone adds you, it shows up here. Find players to send your own.</p><div class="fr-zero-b"><button class="btn btn-red" data-fr-tab="find">Find players</button></div></div>';
    h += '<h4 class="fr-h">Want to be friends <small>' + L.in.length + '</small></h4>';
    h += L.in.length ? '<ul class="fr-list">' + L.in.map(function (f) {
      return '<li>' + avatar(f) + '<div class="fr-t"><b>' + nameLink(f) + '</b><small>' + seenLine(f) + (f.wpts ? ' &middot; <span>' + f.wpts.toLocaleString() + ' pts this week</span>' : "") + '</small></div><div class="fr-b"><button class="btn btn-mint btn-sm" data-fr-act="accept:' + f.id + '">Accept</button><button class="btn btn-line btn-sm" data-fr-act="decline:' + f.id + '">Decline</button></div></li>';
    }).join("") + '</ul>' : '<p class="fr-empty">Nobody is waiting on you.</p>';
    if (L.out.length) h += '<h4 class="fr-h">You asked <small>' + L.out.length + '</small></h4><ul class="fr-list dim">' + L.out.map(function (f) {
      return '<li>' + avatar(f) + '<div class="fr-t"><b>' + nameLink(f) + '</b><small>Waiting for them to accept</small></div><div class="fr-b"><button class="btn btn-line btn-sm" data-fr-act="cancel:' + f.id + '">Cancel</button></div></li>';
    }).join("") + '</ul>';
    if (L.blocked.length) h += '<details class="fr-blocked"><summary>Blocked (' + L.blocked.length + ')</summary><ul class="fr-list dim">' + L.blocked.map(function (f) {
      return '<li><span class="fr-av fr-ini">' + esc(f.name.charAt(0)) + '</span><div class="fr-t"><b data-i18n-skip>' + esc(f.name) + '</b></div><div class="fr-b"><button class="btn btn-line btn-sm" data-fr-act="unblock:' + f.id + '">Unblock</button></div></li>';
    }).join("") + '</ul></details>';
    return h;
  }

  // ---------- Find players: everyone with a player name, searched and sorted on the server, 10 to a page ----------
  var FIND_F = [["all", "Everyone"], ["online", "Online now"], ["week", "This week"], ["top", "Top players"], ["holders", "Holders"]];
  async function loadFind(quiet) {
    clearTimeout(S.fdTimer);
    var F = S.fd, ask = { f: F.f, q: F.q, page: F.page }, key = JSON.stringify(ask);
    S.fdKey = key;
    var j = await api(Object.assign({ a: "find" }, ask));
    if (S.fdKey !== key) return;   // a newer search went out meanwhile
    if (j.ok) { F.data = j; F.page = j.page; S.hidden = j.hidden; S.counts.all = j.online; badge(); }
    else if (!quiet) F.err = j.error;
    var p = panel();
    if (p && !p.hidden && S.tab === "find") { drawFind(); S.fdTimer = setTimeout(function () { loadFind(true); }, 30000); }
  }
  function findRows() {
    var D = S.fd.data;
    if (!D) return '<p class="fr-empty">' + esc(S.fd.err || "Loading…") + '</p>';
    if (!D.players.length) return '<p class="fr-empty">' + (D.q ? "No player goes by that. Check the spelling, or try their 6-letter player id." : D.f === "online" ? "Nobody else is on right now. Start a match and bots fill the seats, or send your invite link." : "Nobody here yet.") + '</p>';
    return '<ul class="fr-list fr-find">' + D.players.map(function (f) {
      var acts = "";
      if (f.friend) acts = '<span class="fr-isf">✓ Friend</span>' + '<button class="btn btn-red btn-sm" data-fr-live="' + f.id + '" title="Open a private room and call them in">Invite to play</button>';
      else {
        if (f.online) acts += '<button class="btn btn-red btn-sm" data-fr-live="' + f.id + '" title="Open a private room and call them in">Invite to play</button>';
        acts += f.asked ? '<button class="btn btn-mint btn-sm" data-fr-act="accept:' + f.id + '">Accept</button>' : f.pending ? '<button class="btn btn-line btn-sm" disabled>Requested</button>' : '<button class="btn btn-mint btn-sm" data-fr-addtag="' + f.id + '">+ Add</button>';
      }
      var stat = D.f === "top" || D.f === "holders" ? f.points.toLocaleString() + " pts" : f.wpts ? f.wpts.toLocaleString() + " pts this week" : (f.games === 1 ? "1 game played" : f.games.toLocaleString() + " games played");
      return '<li class="' + (f.online ? "on" : "") + '">' + avatar(f) + '<div class="fr-t"><b>' + (f.house ? '<em class="lb-house" data-i18n-skip>' + esc(f.house) + '</em>' : "") + nameLink(f) + '</b><small>' + seenLine(f) + ' &middot; <span>' + stat + '</span></small></div><div class="fr-b">' + acts + '</div></li>';
    }).join("") + '</ul>' + (window.ShyPager ? ShyPager.html({ page: D.page, pages: D.pages }, "frd") : "");
  }
  function findCount() {
    var D = S.fd.data; if (!D) return "";
    return D.q ? (D.total === 1 ? "1 player found" : D.total.toLocaleString() + " players found") : D.f === "online" ? (D.total === 1 ? "1 player online now" : D.total.toLocaleString() + " players online now") : (D.total === 1 ? "1 player" : D.total.toLocaleString() + " players");
  }
  function drawFind() {
    var p = panel(); if (!p) return;
    var res = p.querySelector("#fr-find-res"), cnt = p.querySelector("#fr-find-n");
    if (!res) { render(); return; }
    res.innerHTML = findRows(); if (cnt) cnt.textContent = findCount();
    p.querySelectorAll("[data-fr-fd]").forEach(function (b) { var on = b.dataset.frFd === S.fd.f; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  }
  function viewFind(L) {
    var R = L.ref, F = S.fd, D = F.data;
    var h = '<div class="fr-tools">' + search('data-fr-find', F.q, "Search by player name or id") + chips("data-fr-fd", FIND_F.map(function (c) { return [c[0], c[1], c[0] === "online" && D ? D.online : null]; }), F.f) + '</div>';
    h += '<p class="fr-count" id="fr-find-n" aria-live="polite">' + findCount() + '</p><div id="fr-find-res">' + findRows() + '</div>';
    h += '<section class="fr-invite"><div><span class="of-k">Can\'t find them? Send your invite link</span><code data-i18n-skip>' + esc(link(L.me.id).replace(/^https?:\/\//, "")) + '</code><small>Your player id is <b data-i18n-skip>' + esc(L.me.id) + '</b>. Anyone who opens the link can add you.</small></div>' +
      '<div class="fr-invite-b"><button class="btn btn-mint btn-sm" data-fr-copy="' + esc(link(L.me.id)) + '">Copy link</button><button class="btn btn-line btn-sm" data-fr-share="x">X</button><button class="btn btn-line btn-sm" data-fr-share="tg">Telegram</button></div></section>';
    //MC 2026-10-19 the invite program grew its own page: the panel now gives the short version and points there
    if (R && R.on) h += '<section class="fr-ref"><span class="fr-ref-ic" aria-hidden="true">🎁</span><div><b>Invite friends, get paid</b><p>When a friend joins with your link and plays, you get <span class="kbi">' + R.k + '</span> Koban' + (R.usd > 0 && R.usdOn ? " plus $" + R.usd + " in $SHY" : "") + ', more when they mint a Shadow, and a ' + R.cut + '% cut of every Koban they buy. <a href="/invite">See the whole deal &rsaquo;</a></p>' +
      (R.n || R.wait ? '<small>' + (R.n ? '<span>' + R.n + (R.n === 1 ? " friend joined" : " friends joined") + '</span>' : "") + (R.n && R.wait ? " · " : "") + (R.wait ? '<span>' + R.wait + " still playing their first games</span>" : "") + '</small>' : "") + '</div></section>';
    h += '<label class="fr-switch fr-vis"><input type="checkbox" data-fr-hide' + (S.hidden ? "" : " checked") + (L.me.name ? "" : " disabled") + '><span></span>Show me as online</label><p class="fr-note-s">Turn this off and nobody sees your green dot or can invite you unless you\'re friends.</p>';
    return h;
  }
  function viewDuels(L) {
    var h = '<p class="fr-lead">A Duel deals the same cards to both of you. You play first, then your friend gets 24 hours to beat your Regions. Normal rules, no hints, one shot each.</p>';
    if (!L.duels.length) return h + '<p class="fr-empty">No Duels yet. Pick a friend and press <b>Duel</b>.</p>';
    return h + '<ul class="fr-list fr-duels">' + L.duels.map(function (d) {
      var line, act = "";
      if (d.st === "new") { line = "You haven't played your run yet."; act = '<button class="btn btn-red btn-sm" data-fr-play="' + d.id + '">Play it</button>'; }
      else if (d.st === "open" && d.turn) { line = "<span>Beat " + regions(d.target) + "</span> &middot; <span>" + left(d.exp) + " left</span>"; act = '<button class="btn btn-red btn-sm" data-fr-play="' + d.id + '">Play</button><button class="btn btn-line btn-sm" data-fr-pass="' + d.id + '">Pass</button>'; }
      else if (d.st === "open") { line = "<span>You held " + regions(d.mine.g) + ".</span> <span>Waiting for them</span> &middot; <span>" + left(d.exp) + " left</span>"; }
      else if (d.st === "done") { line = (d.won === "me" ? "You won, " : d.won === "tie" ? "Tie, " : "They won, ") + (d.won === "them" ? d.theirs.g + " to " + d.mine.g : d.mine.g + " to " + d.theirs.g); act = '<button class="btn btn-mint btn-sm" data-fr-duel="' + d.vs + '">Rematch</button>'; }
      else if (d.st === "expired") { line = d.turn || !d.challenger ? "Ran out of time" : "They didn't play it in time"; }
      else { line = d.off ? "Called off" : d.challenger ? "They passed" : "You passed"; }   //MC 2026-10-10 an unfriend isn't a pass
      return '<li class="st-' + d.st + (d.turn ? " turn" : "") + (d.won ? " w-" + d.won : "") + '"><span class="fr-av fr-ini" aria-hidden="true">' + (d.won === "me" ? "🏆" : d.turn ? "🎴" : "⚔️") + '</span><div class="fr-t"><b>' + (d.challenger ? "<span>You vs</span> " : "") + '<span data-i18n-skip>' + esc(d.vsName) + '</span>' + (d.challenger ? "" : " <span>challenged you</span>") + '</b><small>' + line + '</small></div><div class="fr-b">' + act + '</div></li>';
    }).join("") + '</ul>';
  }
  function viewBoard(L) {
    var h = '<p class="fr-lead">You and your friends, by points from every verified game since Monday. It resets with the Weekly League. In Telegram, send <b>/friends</b> to the bot.</p>';
    if (L.board.length < 2) return h + '<p class="fr-empty">Add friends to see how you stack up.</p>';
    return h + '<ol class="fr-board">' + L.board.map(function (r, i) {
      return '<li class="' + (r.me ? "me" : "") + '"><span>' + (["🥇", "🥈", "🥉"][i] || i + 1) + '</span><b><span data-i18n-skip>' + esc(r.name) + '</span>' + (r.me ? ' <span>(you)</span>' : "") + (r.holder ? " 💎" : "") + '</b><em>' + r.pts.toLocaleString() + ' pts</em></li>';
    }).join("") + '</ol>';
  }
  // where challenges reach you when you're not on the site
  function notifyBox(L) {
    var h = '<section class="fr-notify"><h4 class="fr-h">Get challenges when you\'re away</h4>';
    if (L.me.tgdm) h += '<p class="ok">✓ Telegram: the bot messages you about requests, challenges and Duels.</p>';
    else if (L.me.tg) h += '<p>Telegram is linked, but Friends alerts are off. Send <b>/notify</b> to ' + (L.tgBot ? "@" + esc(L.tgBot) : "the bot") + ' and turn on <b>Friends, challenges and Duels</b>.</p>';
    else h += '<p><b>Telegram</b> is the surest way: <a href="/profile#pf-tg">link it on your profile</a> and the bot messages you with a Join button.</p>';
    var ps = pushState();
    if (ps === "unsupported") h += '<p class="dim">This browser can\'t show notifications.</p>';
    else if (ps === "ios") h += '<p class="dim">On iPhone and iPad, notifications work once you add this site to your Home Screen (Share, then Add to Home Screen) and open it from there.</p>';
    else if (ps === "denied") h += '<p class="dim">Notifications are blocked for this site in your browser settings.</p>';
    else h += '<label class="fr-switch"><input type="checkbox" data-fr-push' + (S.pushOn ? " checked" : "") + '><span></span>Browser notifications on this device</label>' +
      '<p class="dim">Only the ones worth a knock: friend requests, challenges and Duels, your Shadow back from an expedition, the Daily going live, the weekly reset, and big Dojo arrivals. A couple a day at most.' +
      ' <a href="#" data-fr-ping>Send a test</a></p>';
    return h + '</section>';
  }

  // ---------- browser notifications ----------
  function pushState() {
    var ios = /iP(hone|ad|od)/.test(navigator.userAgent) && !(window.navigator.standalone || matchMedia("(display-mode: standalone)").matches);
    if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) return ios ? "ios" : "unsupported";
    if (Notification.permission === "denied") return "denied";
    return "ok";
  }
  function b64key(s) { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; var r = atob(s), a = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) a[i] = r.charCodeAt(i); return a; }
  function uaName() { var u = navigator.userAgent; return /Android/.test(u) ? "Android" : /iPhone|iPad/.test(u) ? "iPhone" : /Mac/.test(u) ? "Mac" : /Windows/.test(u) ? "Windows" : "Browser"; }
  async function pushCheck() {
    if (pushState() !== "ok") return;
    try { var reg = await navigator.serviceWorker.getRegistration("/"); var sub = reg && await reg.pushManager.getSubscription(); S.pushOn = !!sub && Notification.permission === "granted"; } catch (e) { S.pushOn = false; }
  }
  async function pushOn() {
    try {
      var perm = await Notification.requestPermission();
      if (perm !== "granted") { toast("Notifications weren't allowed."); return false; }
      var reg = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
      await navigator.serviceWorker.ready;
      var k = await api({ a: "push-key" });
      if (!k.ok) { toast(k.error); return false; }
      var sub = await reg.pushManager.getSubscription() || await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64key(k.key) });
      var j = await api({ a: "push-on", endpoint: sub.endpoint, ua: uaName() });
      if (!j.ok) { toast(j.error); return false; }
      toast("Notifications on. You'll hear about requests, challenges and Duels here.");
      return true;
    } catch (e) { toast("This browser wouldn't turn notifications on."); return false; }
  }
  async function pushOff() {
    try { var reg = await navigator.serviceWorker.getRegistration("/"); var sub = reg && await reg.pushManager.getSubscription(); if (sub) { await api({ a: "push-off", endpoint: sub.endpoint }); await sub.unsubscribe(); } } catch (e) {}
    toast("Notifications off on this device.");
  }

  // ---------- actions ----------
  async function act(what, id) {
    var j = await api({ a: what, id: id });
    if (!j.ok) { toast(j.error); return; }
    var n = j.name || "them";
    toast({ accept: "You and " + n + " are friends now.", decline: "Request declined.", cancel: "Request cancelled.", remove: n + " is off your list.", block: n + " is blocked. They can't add or challenge you.", unblock: n + " is unblocked." }[what] || "Done.");
    load(); poll();
  }
  async function add(who) {
    if (!who) return;
    var j = await api({ a: "add", who: who });
    if (!j.ok) { toast(j.error); return; }
    toast(j.friends ? "You and " + j.name + " are friends now." : j.again ? "Your request to " + j.name + " is still waiting." : "Request sent to " + j.name + ".");
    load();
  }
  async function duelVs(tag) {
    var j = await api({ a: "duel", to: tag });
    if (!j.ok) {
      if (j.duel && j.mine) return playDuel(j.duel);
      toast(j.error); return;
    }
    playDuel(j.id, j.name);
  }
  //MC 2026-10-10 a solo or Duel run on this page: its turns run on timers, so moving to another game needs a page load
  function soloOn() { var P = play(); return !!(P && P.playing && P.playing() && !(P.liveCode && P.liveCode())); }
  function playDuel(id) {
    var P = play();
    closePanel();
    document.querySelectorAll(".fr-note").forEach(closeNote);
    //MC 2026-10-10 off the game page "Play the Duel" loaded /play?duel=ID, which asked "Play now" a second time. go=1 skips that.
    //   Mid solo game the bots' moves are still in flight and landed in the new Duel deal, so that goes by a fresh page too.
    if (P && P.duel && !soloOn()) P.duel(id); else location.href = "/play?duel=" + id + "&go=1";
  }
  async function liveVs(tag) {
    var P = play();
    closePanel();
    if (!P || !P.liveChallenge || soloOn()) { location.href = "/play?challenge=" + tag; return; }   //MC 2026-10-10 soloOn: see playDuel
    var g = document.getElementById("game"); if (g) g.scrollIntoView({ behavior: "smooth", block: "start" });
    P.liveChallenge(tag);
  }
  async function sendLive(code, tag) {
    var j = await api({ a: "live", to: tag, code: code });
    if (!j.ok) { toast(j.error); return; }
    toast(j.online ? j.name + " is online and has your challenge. Start with bots any time." : "Challenge sent to " + j.name + ". They have 10 minutes to join. Start with bots any time.");
  }
  //MC 2026-10-15 the invite button on a friend said Live, which players read as a status, not an action: now Invite to play
  function share(how) {
    var L = S.list; if (!L) return;
    var url = link(L.me.id), text = "Add me in Shilluminati Online and let's Duel: same deal, one shot each.";
    var to = how === "x" ? "https://x.com/intent/tweet?text=" + encodeURIComponent(text + " $SHY\n" + url) : "https://t.me/share/url?url=" + encodeURIComponent(url) + "&text=" + encodeURIComponent(text);
    var W = window.Telegram && window.Telegram.WebApp;
    if (W && W.openLink && W.initData) W.openLink(to); else open(to, "_blank", "noopener");
  }
  // "Add friend" buttons for the real players at a finished live match (the game page asks for these)
  function addChips(list) {
    if (!list.length) return "";
    return '<span class="fr-chips-k">Played with real people? Add them:</span>' + list.map(function (x) { return '<button class="fr-chip" data-fr-addtag="' + esc(x.tag) + '">+ ' + esc(x.name) + '</button>'; }).join("");
  }

  // a sheet for invite links, Duel links and rematches from outside
  function sheet(html) {
    var s = $("fr-sheet");
    if (!s) { s = document.createElement("div"); s.id = "fr-sheet"; s.className = "fr-sheet"; document.body.appendChild(s); }
    s.innerHTML = '<div class="fr-back" data-fr-sheetx></div><div class="fr-sheet-in" role="dialog" aria-modal="true">' + html + '</div>';
    s.hidden = false; requestAnimationFrame(function () { s.classList.add("in"); });
  }
  function sheetClose() { var s = $("fr-sheet"); if (s) { s.classList.remove("in"); setTimeout(function () { s.hidden = true; }, 200); } }
  async function fromLink() {
    var q = new URLSearchParams(location.search), clean = function (k) { q.delete(k); try { history.replaceState(null, "", location.pathname + (q.toString() ? "?" + q : "") + location.hash); } catch (e) {} };
    var friend = q.get("friend"), duel = q.get("duel"), duelvs = q.get("duelvs"), ch = q.get("challenge");
    if (q.get("friends")) { clean("friends"); openPanel(); return; }
    if (q.get("online")) { clean("online"); openPanel("online"); return; }
    if (friend && /^[a-f0-9]{6}$/i.test(friend)) {
      clean("friend");
      api({ a: "ref", id: friend });   // remembered for the invite reward, if this is a new player
      var w = await api({ a: "who", id: friend });
      if (!w.ok || w.self) return;
      sheet('<span class="fr-sheet-ic">👋</span><h3>' + (w.friend ? "You and " + esc(w.name) + " are friends" : "Add " + esc(w.name) + " as a friend?") + '</h3><p>Friends see each other online, challenge each other to live matches, and Duel on the same deal.</p><div class="fr-sheet-b">' +
        (w.friend ? '<button class="btn btn-mint" data-fr-duel="' + esc(w.id) + '">Duel them</button>' : '<button class="btn btn-red" data-fr-addtag="' + esc(w.id) + '">' + (w.asked ? "Accept" : "Add friend") + '</button>') + '<button class="btn btn-line" data-fr-sheetx>Not now</button></div>');
      return;
    }
    if (!play()) return;
    if (duel && /^[a-f0-9]{10}$/.test(duel)) {
      //MC 2026-10-10 go=1 (our own Play button) or Telegram's "Play the Duel" button: the player already said yes
      var goNow = q.get("go") === "1" || /^duel_/.test(q.get("tgWebAppStartParam") || "");
      if (q.get("go")) q.delete("go");
      clean("duel");
      var L = await api({ a: "list" }), d = L.ok ? L.duels.filter(function (x) { return x.id === duel; })[0] : null;
      if (!d) { toast("That Duel isn't yours, or it's gone."); return; }
      //MC 2026-10-10 tapping a Duel that's over just opened the Duels tab with no word why
      if (!d.turn) { if (goNow) toast(d.st === "expired" ? "This Duel ran out of time." : d.st === "declined" ? (d.off || d.challenger ? "This Duel was called off." : "You passed on this Duel.") : "You've played this Duel."); S.tab = "duels"; openPanel(); return; }
      if (goNow) { playDuel(d.id); return; }
      sheet('<span class="fr-sheet-ic">🎴</span><h3>' + (d.challenger ? "Your Duel with " + esc(d.vsName) : esc(d.vsName) + " challenged you to a Duel") + '</h3><p>' + (d.target != null ? "Beat <b>" + regions(d.target) + "</b>. " : "You play first, then " + esc(d.vsName) + " gets the same deal. ") +
        'Same cards for both of you, Normal rules, no hints, one shot.' + (d.exp ? " " + left(d.exp) + " left." : "") + '</p><div class="fr-sheet-b"><button class="btn btn-red" data-fr-play="' + d.id + '">Play now</button><button class="btn btn-line" data-fr-sheetx>Later</button></div>');
      return;
    }
    if (duelvs && /^[a-f0-9]{6}$/.test(duelvs)) { clean("duelvs"); sheet('<span class="fr-sheet-ic">⚔️</span><h3>Start a Duel?</h3><p>You play first. Your friend then gets the same deal and 24 hours to beat your Regions.</p><div class="fr-sheet-b"><button class="btn btn-red" data-fr-duel="' + duelvs + '">Start the Duel</button><button class="btn btn-line" data-fr-sheetx>Not now</button></div>'); return; }
    if (ch && /^[a-f0-9]{6}$/.test(ch)) { clean("challenge"); liveVs(ch); }
  }

  // ---------- next match: a challenge lined up while a game is on ----------
  //MC 2026-10-09 the pill under the notices shows what's lined up. When the game ends, a 10 second countdown joins the
  //   room (with Join now and Cancel), so the player sees their result first and doesn't have to quit to take it.
  function nextPill() {
    var el = $("fr-next");
    if (!S.next) { if (el) el.remove(); return; }
    if (!el) { el = document.createElement("div"); el.id = "fr-next"; el.className = "fr-next"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    var N = S.next;
    el.innerHTML = N.count != null
      ? '<span class="fr-next-ic" aria-hidden="true">⚔️</span><span class="fr-next-t"><b>Joining <span data-i18n-skip>' + esc(N.name) + '</span>\'s room in <span class="fr-next-n">' + N.count + '</span></b><small>Room <span data-i18n-skip>' + esc(N.code) + '</span></small></span><button class="btn btn-red btn-sm" data-fr-nextgo>Join now</button><button class="fr-next-x" data-fr-nextx aria-label="Cancel">&times;</button>'
      : '<button class="fr-next-ic" data-fr-nextpeek aria-label="Next match">⏳</button><span class="fr-next-t"><b>Next: <span data-i18n-skip>' + esc(N.name) + '</span>\'s room</b><small>You join when this game ends</small></span><button class="fr-next-x" data-fr-nextx aria-label="Cancel">&times;</button>';
    // on a phone the waiting pill folds down to a small hourglass after a few seconds, so it never sits on your cards
    el.classList.toggle("mini", N.count == null && !!N.mini);
    clearTimeout(S.nextFold);
    if (N.count == null && !N.mini) S.nextFold = setTimeout(function () { if (S.next && S.next.count == null && matchMedia("(max-width:760px)").matches) { S.next.mini = true; nextPill(); } }, 4000);
  }
  function nextSet(code, from, name) {
    S.next = { code: code, from: from, name: name, ts: Date.now(), count: null };
    nextPill();
    api({ a: "live-later", code: code, to: from }).then(function (j) { if (!j.ok && S.next && S.next.code === code) { toast(j.error); S.next = null; nextPill(); } });
    clearInterval(S.nextTimer);
    S.nextTimer = setInterval(nextTick, 1000);
  }
  function nextTick() {
    var N = S.next, P = play();
    if (!N) { clearInterval(S.nextTimer); return; }
    if (Date.now() - N.ts > 25 * 60000) { S.next = null; nextPill(); toast("The challenge you lined up ran out."); return; }   // private rooms close after 30 minutes
    if (P && P.playing && P.playing()) { if (N.count != null) { N.count = null; nextPill(); } return; }
    if (N.count == null) { N.count = 10; nextPill(); return; }
    N.count--;
    if (N.count <= 0) return nextGo();
    var c = document.querySelector("#fr-next .fr-next-n"); if (c) c.textContent = N.count;
  }
  function nextGo() {
    var N = S.next; if (!N) return;
    S.next = null; clearInterval(S.nextTimer); nextPill();
    var P = play();
    if (P && P.joinCode) P.joinCode(N.code); else location.href = "/play?room=" + N.code;
  }
  function nextCancel() {
    var N = S.next; if (!N) return;
    S.next = null; clearInterval(S.nextTimer); nextPill();
    api({ a: "live-no", code: N.code, to: N.from });
    toast("Called off. They've been told.");
  }

  // ---------- clicks ----------
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-friends]");
    if (b) { e.preventDefault(); if (b.classList.contains("fr-note-more")) document.querySelectorAll(".fr-note").forEach(closeNote); var d = $("drawer"); if (d && d.classList.contains("open")) { var c = $("close"); if (c) c.click(); } openPanel(b.getAttribute("data-friends") || false); return; }
    if ((b = e.target.closest("[data-fr-close]"))) { closeNote(b.closest(".fr-note")); return; }
    //MC 2026-10-10 "Join the match" used to load /play?room=CODE, which only showed a second "Join now" card. On a phone that
    //   card sat below the fold, so players tapped Join, saw nothing happen and the host started without them (reported
    //   from /updates). On the play page it now joins the room straight away; from any other page the link auto-joins.
    //MC 2026-10-10 "Leave and join now" mid solo game follows the link instead (a fresh page), see soloOn
    if ((b = e.target.closest("[data-fr-join]"))) { var JP = play(); closeNote(b.closest(".fr-note")); if (JP && JP.joinCode && !soloOn()) { e.preventDefault(); JP.joinCode(b.dataset.frJoin); } return; }
    if ((b = e.target.closest("[data-fr-next]"))) { var nx = b.dataset.frNext.split("|"); closeNote(b.closest(".fr-note")); nextSet(nx[0], nx[1], nx.slice(2).join("|")); toast("Lined up. You join their room when this game ends."); return; }
    if (e.target.closest("[data-fr-nextgo]")) { nextGo(); return; }
    if (e.target.closest("[data-fr-nextpeek]")) { if (S.next) { S.next.mini = !S.next.mini; nextPill(); } return; }
    if (e.target.closest("[data-fr-nextx]")) { nextCancel(); return; }
    if ((b = e.target.closest("[data-duelvs]")) && b.dataset.duelvs) { duelVs(b.dataset.duelvs); return; }
    if ((b = e.target.closest("[data-fr-sheetx]"))) { sheetClose(); return; }
    if ((b = e.target.closest("[data-fr-addtag]"))) { b.disabled = true; sheetClose(); var at = b.dataset.frAddtag; add(at).then(function () { b.textContent = "Request sent"; if (S.fd.data) S.fd.data.players.forEach(function (x) { if (x.id === at) x.pending = true; }); }); return; }
    //MC 2026-10-09 Invite from a leaderboard row or a player page: open a private room and call them in
    if ((b = e.target.closest("[data-fr-invite]"))) { e.preventDefault(); var hc = play() && play().hosting && play().hosting(); if (hc) sendLive(hc, b.dataset.frInvite); else liveVs(b.dataset.frInvite); return; }
    if ((b = e.target.closest("[data-fr-play]"))) { sheetClose(); closeNote(b.closest(".fr-note")); playDuel(b.dataset.frPlay); return; }
    if ((b = e.target.closest("[data-fr-duel]"))) { sheetClose(); closeNote(b.closest(".fr-note")); duelVs(b.dataset.frDuel); return; }
    if ((b = e.target.closest("[data-fr-act]"))) { var p = b.dataset.frAct.split(":"); closeNote(b.closest(".fr-note")); act(p[0], p[1]); return; }
    if (!e.target.closest("#fr")) return;
    if (e.target.closest("[data-fr-x]")) { closePanel(); return; }
    if ((b = e.target.closest("[data-fr-tab]"))) { S.tab = b.dataset.frTab; render(); if (S.tab === "find") loadFind(); else clearTimeout(S.fdTimer); var bt = panel().querySelector(".fr-tabs .on"); if (bt && bt.scrollIntoView) try { bt.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (x) {} return; }
    var pg = window.ShyPager && (ShyPager.hit(e, "frf") || ShyPager.hit(e, "frd"));
    var bd = panel().querySelector(".fr-body");
    if (pg && pg.key === "frf") { S.fpage = pg.page; var fl = $("fr-flist"); if (fl) fl.innerHTML = friendRows(); if (bd) bd.scrollTop = 0; return; }
    if (pg && pg.key === "frd") { S.fd.page = pg.page; loadFind(); if (bd) bd.scrollTop = 0; return; }
    if ((b = e.target.closest("[data-fr-ff]"))) { S.ff = b.dataset.frFf; S.fpage = 1; render(); return; }
    if ((b = e.target.closest("[data-fr-fd]"))) { S.fd.f = b.dataset.frFd; S.fd.page = 1; S.fd.data = S.fd.data ? Object.assign(S.fd.data, { f: S.fd.f }) : null; drawFind(); loadFind(); return; }
    if ((b = e.target.closest("[data-fr-live]"))) { var P = play(), code = P && P.hosting && P.hosting(); if (code) { closePanel(); sendLive(code, b.dataset.frLive); } else liveVs(b.dataset.frLive); return; }
    if ((b = e.target.closest("[data-fr-pass]"))) { api({ a: "duel-decline", id: b.dataset.frPass }).then(function (j) { toast(j.ok ? "Duel passed." : j.error); load(); }); return; }
    if ((b = e.target.closest("[data-fr-copy]"))) {
      var t = b.dataset.frCopy, done = function () { b.textContent = "Copied"; setTimeout(function () { b.textContent = "Copy link"; }, 1600); };
      try { navigator.clipboard.writeText(t).then(done, function () { prompt("Copy your link", t); }); } catch (x) { done(); }
      return;
    }
    if ((b = e.target.closest("[data-fr-share]"))) { share(b.dataset.frShare); return; }
  });
  document.addEventListener("change", async function (e) {
    if (e.target.matches && e.target.matches("[data-fr-hide]")) {
      var hb = e.target; hb.disabled = true;
      var hj = await api({ a: "hide", hide: !hb.checked });
      if (hj.ok) { S.hidden = hj.hidden; toast(hj.hidden ? "You're hidden. Nobody sees your green dot now." : "You show as online again."); }
      else { hb.checked = !hb.checked; toast(hj.error); }
      hb.disabled = false; return;
    }
    //MC 2026-10-18 the test knock: proves the whole chain on this very device, iPhone Home Screen setups above all
    if (e.target.matches && e.target.matches("[data-fr-ping]")) {
      e.preventDefault();
      var j2 = await api({ a: "push-ping" });
      toast(j2.ok ? "Sent. It lands in a few seconds, even with this app closed." : j2.error);
      return;
    }
    if (!e.target.matches || !e.target.matches("[data-fr-push]")) return;
    var box = e.target; box.disabled = true;
    S.pushOn = box.checked ? await pushOn() : (await pushOff(), false);
    box.checked = S.pushOn; box.disabled = false;
    if (S.list) S.list.me.push = S.pushOn ? 1 : 0;
  });
  //MC 2026-10-09 typing in a search redraws only the list, so the box keeps focus and the caret
  document.addEventListener("input", function (e) {
    var t = e.target; if (!t.matches) return;
    if (t.matches("[data-fr-fq]")) { S.fq = t.value; S.fpage = 1; var fl = $("fr-flist"); if (fl) fl.innerHTML = friendRows(); return; }
    if (t.matches("[data-fr-find]")) { S.fd.q = t.value.trim(); S.fd.page = 1; clearTimeout(S.fdType); S.fdType = setTimeout(function () { loadFind(); }, 280); }
  });
  document.addEventListener("submit", function (e) {
    if (!e.target.matches || !e.target.matches("[data-fr-addf]")) return;
    e.preventDefault(); var i = e.target.querySelector("input"); add(i.value.trim()); i.value = "";
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") { if ($("fr-sheet") && !$("fr-sheet").hidden) sheetClose(); else closePanel(); } });

  window.ShyFriends = { open: openPanel, refresh: function () { poll(); if (panel() && !panel().hidden) load(); }, sendLive: sendLive, addChips: addChips, duelVs: duelVs, counts: function () { return S.counts; }, invite: function (tag) { var hc = play() && play().hosting && play().hosting(); if (hc) sendLive(hc, tag); else liveVs(tag); } };
  pushCheck();
  poll().then(schedule, schedule);
  //MC 2026-10-09 closing the site drops the green dot right away. Another open tab puts it back on its next check.
  window.addEventListener("pagehide", function () {
    var m = me();
    var body = JSON.stringify({ a: "bye", pid: m.pid, key: m.key });
    try { fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: body, keepalive: true }).catch(function () {}); }
    catch (x) { try { navigator.sendBeacon(API, new Blob([body], { type: "application/json" })); } catch (y) {} }
  });
  // back from the browser's page cache: show as online again
  window.addEventListener("pageshow", function (e) { if (e.persisted) poll(); });
  // links from Telegram, invites and notifications: wait for the game to be ready on the play page
  setTimeout(fromLink, play() ? 300 : 0);
})();
