//MC 2026-10-19 the Invite and earn page: pulls the player's link, deal numbers and invite list from
//   api/referrals.php and draws them. Signed-out or unnamed visitors get the play-first card instead.
(function () {
  "use strict";
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  var pid = "", key = "";
  try { pid = localStorage.getItem("shy-lb-pid") || ""; key = localStorage.getItem("shy-lb-key") || ""; } catch (e) {}
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t));
    if (s < 3600) return Math.max(1, Math.floor(s / 60)) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    return Math.floor(s / 86400) + "d ago";
  }
  function badges(r) {
    var b = '<span class="iv-b on">Joined</span>';
    b += '<span class="iv-b' + (r.played ? " on" : "") + '">' + (r.played ? "Played" : "Not played yet") + '</span>';
    b += '<span class="iv-b' + (r.minted ? " on" : "") + '">' + (r.minted ? "Minted" : "No mint yet") + "</span>";
    b += '<span class="iv-b' + (r.bought ? " on" : "") + '">' + (r.bought ? "Buys in the Dojo" : "No buys yet") + "</span>";
    return b;
  }
  async function load() {
    var j = null;
    if (pid && key) {
      try { j = await (await fetch("/api/referrals.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, key: key }) })).json(); } catch (e) {}
    }
    if (j && j.ok && j.deal) {
      $("iv-d-k").textContent = fmt(j.deal.k) + " Koban";
      $("iv-d-mint").textContent = fmt(j.deal.mint) + " Koban";
      $("iv-d-cut").textContent = j.deal.cut + "% cut";
      //MC 2026-10-19 the $SHY per invite waits behind the community goal: locked shows the goal bar, open shows the $
      var usd = "$" + fmt(j.deal.usd) + " in $SHY";
      $("iv-d-usd").textContent = usd; $("iv-d-usd2").textContent = usd;
      if (j.deal.usd > 0 && j.deal.usdOn) {
        $("iv-d-usd-x").hidden = false;
        $("iv-d-usd-note").textContent = "The $SHY is sent by the team to your connected wallet.";
        if (j.deal.gate > 0) {
          $("iv-goal").hidden = false;
          $("iv-goal-h").textContent = "The community goal is done";
          $("iv-goal-n").textContent = fmt(j.deal.total) + " invites and counting";
          $("iv-goal-fill").style.width = "100%";
          $("iv-goal-p").innerHTML = "You did it together: every invite now also pays <b>" + esc(usd) + "</b>, sent by the team to the inviter's connected wallet.";
        }
      } else if (j.deal.usd > 0 && j.deal.gate > 0) {
        $("iv-goal").hidden = false;
        $("iv-goal-n").textContent = fmt(j.deal.total) + " of " + fmt(j.deal.gate) + " invites";
        $("iv-goal-fill").style.width = Math.min(100, Math.round(j.deal.total / j.deal.gate * 1000) / 10) + "%";
      }
    }
    if (!j || !j.ok || !j.named || !j.link) { $("iv-nolink").hidden = false; return; }
    $("iv-link-card").hidden = false;
    $("iv-link").textContent = j.link;
    $("iv-tg").href = "https://t.me/share/url?url=" + encodeURIComponent(j.link) + "&text=" + encodeURIComponent("Come play Shilluminati with me. Free, in your browser.");
    $("iv-copy").addEventListener("click", function () {
      var done = function () { $("iv-copy").textContent = "Copied"; setTimeout(function () { $("iv-copy").textContent = "Copy"; }, 1500); };
      try { navigator.clipboard.writeText(j.link).then(done, function () { window.prompt("Copy your link", j.link); }); } catch (e) { window.prompt("Copy your link", j.link); }
    });
    var tot = [];
    tot.push("<span><small>Invites</small><b>" + fmt(j.rows.length) + "</b></span>");
    tot.push("<span><small>Koban earned</small><b>" + fmt(j.koban) + "</b></span>");
    if (j.usdPend > 0 || (j.deal && j.deal.usdOn)) tot.push('<span><small>$SHY pending</small><b>$' + fmt(j.usdPend) + "</b></span>");
    if (j.usdPaid > 0) tot.push('<span><small>$SHY paid out</small><b>$' + fmt(j.usdPaid) + "</b></span>");
    if (j.deal && j.deal.cap) tot.push("<span><small>This week</small><b>" + fmt(j.week) + " of " + fmt(j.deal.cap) + "</b></span>");
    $("iv-tot").innerHTML = tot.join("");
    if (j.rows.length) {
      $("iv-list-wrap").hidden = false;
      $("iv-list").innerHTML = j.rows.map(function (r) {
        return '<div class="iv-row"><div class="iv-who"><b data-i18n-skip>' + esc(r.name) + "</b><small>joined " + ago(r.t) + " &middot; " + fmt(r.g) + (r.g === 1 ? " game" : " games") + "</small></div>" +
          '<div class="iv-badges">' + badges(r) + "</div>" +
          '<div class="iv-earn">' + (r.k > 0 ? "+" + fmt(r.k) + " Koban" + (r.cutK > 0 ? '<small>' + fmt(r.cutK) + " from their buys</small>" : "") : '<small>nothing yet</small>') + "</div></div>";
      }).join("");
    }
  }
  load();
})();
