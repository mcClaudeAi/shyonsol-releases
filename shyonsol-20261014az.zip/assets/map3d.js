// The 3D war table: the same 40 Regions as the flat map, raised as plates on a command table you can orbit and zoom.
// Built from assets/map.json (the flat map's own outlines), so both maps always agree on what a Region is and where.
// play.js owns the game: it tells this module who holds what (paint), whose turn it is (setTurn), who is highlighted
// (setHl) and whether a target is being picked (setPicking), and it gets taps and hovers back. Nothing here touches
// the rules, the server or the flat map; if WebGL is missing or anything fails, play.js keeps the flat map.
//MC 2026-10-14 three.js (assets/vendor/three-map.js, r170 with SVGLoader and OrbitControls) is fetched only when a
//   player has the 3D table on, so the flat map never pays for it. Touch: one finger orbits, two zoom. A tap that
//   does not move picks or shows the Region, same as tapping the flat map.
(function () {
  "use strict";
  var S = 0.012, W = 1000, H = 475;              // map units to table units; the flat map's own size
  var LAND_H = 0.13;                             // how far a plate rises off the table
  var OPEN = "#7a8a46", OPEN_SIDE = "#46522a", GONE = "#2a1f2f", GONE_SIDE = "#191219", EDGE = "#0c1710";
  var vendor = null;                             // the script tag, once asked for

  function supported() {
    try {
      var c = document.createElement("canvas");
      var gl = c.getContext("webgl2") || c.getContext("webgl");
      if (!gl) return false;
      var ext = gl.getExtension("WEBGL_lose_context"); if (ext) ext.loseContext();
      return true;
    } catch (e) { return false; }
  }
  // fetch three.js once; resolves when window.THREE is there
  function load(src) {
    if (window.THREE && window.ShyThreeAddons) return Promise.resolve();
    if (!vendor) {
      vendor = new Promise(function (res, rej) {
        var s = document.createElement("script"); s.src = src; s.async = true;
        s.onload = function () { window.THREE && window.ShyThreeAddons ? res() : rej(new Error("three missing")); };
        s.onerror = function () { rej(new Error("three failed to load")); };
        document.head.appendChild(s);
      });
    }
    return vendor;
  }
  function hex(c) { return new window.THREE.Color(c); }
  function mix(a, b, t) { return hex(a).lerp(hex(b), t); }
  // the table's grid, drawn once to a canvas: dark felt, fine lines, a soft vignette
  function gridTexture(T) {
    var c = document.createElement("canvas"); c.width = 1024; c.height = 512;
    var x = c.getContext("2d");
    x.fillStyle = "#10261c"; x.fillRect(0, 0, 1024, 512);
    x.strokeStyle = "rgba(150,220,180,.13)"; x.lineWidth = 1;
    for (var i = 0; i <= 1024; i += 32) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, 512); x.stroke(); }
    for (var j = 0; j <= 512; j += 32) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(1024, j + .5); x.stroke(); }
    x.strokeStyle = "rgba(150,220,180,.22)";
    for (i = 0; i <= 1024; i += 128) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, 512); x.stroke(); }
    for (j = 0; j <= 512; j += 128) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(1024, j + .5); x.stroke(); }
    var v = x.createRadialGradient(512, 256, 120, 512, 256, 620);
    v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.55)");
    x.fillStyle = v; x.fillRect(0, 0, 1024, 512);
    var t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.anisotropy = 4;
    return t;
  }
  // a Region's outline, from the flat map's path, as table shapes: x across, y toward the far edge, flipped from screen
  function shapesFor(T, A, d) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg"><path d="' + d + '"/></svg>';
    var paths = new A.SVGLoader().parse(svg).paths;
    var out = [];
    paths.forEach(function (p) {
      A.SVGLoader.createShapes(p).forEach(function (sh) {
        var fix = function (path) { path.curves.forEach(function (cv) { ["v0", "v1", "v2", "v3"].forEach(function (k) { var pt = cv[k]; if (pt && pt.isVector2) pt.set((pt.x - W / 2) * S, (H / 2 - pt.y) * S); }); }); };
        fix(sh); (sh.holes || []).forEach(fix);
        out.push(sh);
      });
    });
    return out;
  }

  function mount(opts) {
    var T = window.THREE, A = window.ShyThreeAddons;
    var el = opts.el, MAP = opts.map, names = opts.regions, COLORS = opts.colors, hooks = opts.hooks || {};
    var reduce = !!opts.reduce;
    var canvas = document.createElement("canvas"); canvas.className = "g-map3d-canvas";
    el.appendChild(canvas);
    var renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
    var coarse = matchMedia("(pointer: coarse)").matches;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2));
    renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
    var scene = new T.Scene();
    scene.background = hex("#0b1510");
    scene.fog = new T.Fog(0x0b1510, 10, 19);
    var camera = new T.PerspectiveCamera(40, 2, 0.1, 60);
    var VIEWS = { overview: { p: [0, 7.6, 6.2], t: [0, 0, -0.2] }, cinematic: { p: [0.9, 2.5, 6.6], t: [0, 0.1, -0.5] } };
    camera.position.set(0, 12, 7);

    // light: a warm key from the upper left, a cool sky fill, a touch of ambient
    scene.add(new T.HemisphereLight(0xd8f0dc, 0x0d1a12, 1.0));
    var key = new T.DirectionalLight(0xfff1d6, 1.25); key.position.set(-6, 9, 4); scene.add(key);
    scene.add(new T.AmbientLight(0xffffff, 0.22));

    // the table: felt with a grid, a lighter rim under it
    var felt = new T.Mesh(new T.PlaneGeometry(W * S + 0.9, H * S + 0.9), new T.MeshStandardMaterial({ map: gridTexture(T), roughness: .95, metalness: 0 }));
    felt.rotation.x = -Math.PI / 2; felt.position.y = 0; scene.add(felt);
    var rim = new T.Mesh(new T.BoxGeometry(W * S + 1.3, 0.16, H * S + 1.3), new T.MeshStandardMaterial({ color: hex("#5e4e33"), roughness: .8 }));
    rim.position.y = -0.09; scene.add(rim);

    // the Regions as plates, with their outlines, a marker each and the lookups to paint them
    var sideOpen = new T.MeshStandardMaterial({ color: hex(OPEN_SIDE), roughness: .9 });
    var sideGone = new T.MeshStandardMaterial({ color: hex(GONE_SIDE), roughness: .9 });
    var edgeMat = new T.LineBasicMaterial({ color: hex(EDGE), transparent: true, opacity: .6 });
    var R = {}, pick = [], land = new T.Group(); land.rotation.x = -Math.PI / 2; scene.add(land);
    var markers = new T.Group(); scene.add(markers);
    var hexGeo = new T.CylinderGeometry(0.11, 0.135, 0.13, 6), outGeo = new T.CylinderGeometry(0.05, 0.06, 0.06, 6);
    var domeGeo = new T.IcosahedronGeometry(0.34, 1);
    names.forEach(function (n) {
      var r = MAP.regions[n]; if (!r) return;
      var shapes;
      try { shapes = shapesFor(T, A, r.d); } catch (e) { return; }   //MC 2026-10-14 one odd outline never takes the table down
      if (!shapes.length) return;
      var geo = new T.ExtrudeGeometry(shapes, { depth: LAND_H, bevelEnabled: false, curveSegments: 4 });
      var top = new T.MeshStandardMaterial({ color: hex(OPEN), roughness: .85, metalness: 0, emissive: hex(COLORS[0]), emissiveIntensity: 0 });
      var mesh = new T.Mesh(geo, [top, sideOpen]);
      mesh.userData.region = n; land.add(mesh); pick.push(mesh);
      var edges = new T.LineSegments(new T.EdgesGeometry(geo, 20), edgeMat); land.add(edges);
      // the marker sits on the plate at the Region's centre
      var mk = new T.Group(); mk.position.set((r.c[0] - W / 2) * S, LAND_H, (r.c[1] - H / 2) * S); markers.add(mk);
      var post = new T.Mesh(outGeo, new T.MeshStandardMaterial({ color: hex("#d8d4c0"), roughness: .7, emissive: hex("#d8d4c0"), emissiveIntensity: .12 }));
      post.position.y = 0.03; post.userData.region = n; mk.add(post); pick.push(post);
      var own = new T.Mesh(hexGeo, new T.MeshStandardMaterial({ color: hex(COLORS[0]), roughness: .55, emissive: hex(COLORS[0]), emissiveIntensity: .45 }));
      own.position.y = 0.065; own.visible = false; own.userData.region = n; mk.add(own); pick.push(own);
      var dome = new T.Mesh(domeGeo, new T.MeshBasicMaterial({ color: hex("#bfe9ff"), wireframe: true, transparent: true, opacity: .4 }));
      dome.position.y = 0.1; dome.visible = false; mk.add(dome);
      R[n] = { mesh: mesh, top: top, post: post, own: own, dome: dome, mk: mk, state: "open", color: "", flags: {}, base: hex(OPEN), flash: 0, drop: 0 };
    });

    // ---- camera and controls
    var controls = new A.OrbitControls(camera, canvas);
    controls.enablePan = false; controls.enableDamping = true; controls.dampingFactor = .08;
    controls.rotateSpeed = .55; controls.zoomSpeed = .9;
    controls.minDistance = 3.8; controls.maxDistance = 13; controls.minPolarAngle = .18; controls.maxPolarAngle = 1.32;
    controls.touches = { ONE: T.TOUCH.ROTATE, TWO: T.TOUCH.DOLLY_PAN };
    var dirty = true, tween = null, raf = 0, dead = false;
    controls.addEventListener("change", function () { dirty = true; });
    function view(name, ms) {
      var v = VIEWS[name] || VIEWS.overview;
      var from = camera.position.clone(), to = new T.Vector3().fromArray(v.p), t0 = new T.Vector3().copy(controls.target), t1 = new T.Vector3().fromArray(v.t);
      if (reduce || !ms) { camera.position.copy(to); controls.target.copy(t1); controls.update(); dirty = true; tween = null; return; }
      var start = performance.now();
      tween = function (now) {
        var k = Math.min(1, (now - start) / ms); k = 1 - Math.pow(1 - k, 3);
        camera.position.lerpVectors(from, to, k); controls.target.lerpVectors(t0, t1, k);
        dirty = true; if (k >= 1) tween = null;
      };
    }
    controls.addEventListener("start", function () { tween = null; });

    // ---- painting
    var turn = null, hl = null, picking = false, anim = 0;
    function look(n, now) {
      var x = R[n]; if (!x) return;
      var ownIdx = typeof x.state === "number", gone = x.state === "gone";
      var base = gone ? hex(GONE) : ownIdx ? mix(x.color, OPEN, .22) : hex(OPEN);
      var dim = hl != null && (!ownIdx || x.state !== hl) ? .38 : 1;
      x.top.color.copy(base).multiplyScalar(dim);
      x.mesh.material[1] = gone ? sideGone : sideOpen;
      var e = 0;
      if (ownIdx) {
        x.top.emissive.set(x.color);
        if (turn === x.state) e = .16 + .16 * (.5 + .5 * Math.sin(now / 290));
        if (hl === x.state) e = Math.max(e, .3);
        if (x.flags.pickable) e = Math.max(e, .3 + .3 * (.5 + .5 * Math.sin(now / 160)));
      }
      if (x.flash > now) { var f = (x.flash - now) / 650; x.top.emissive.set("#ffffff").lerp(hex(ownIdx ? x.color : OPEN), 1 - f); e = Math.max(e, .9 * f); }
      x.top.emissiveIntensity = e;
      x.own.visible = ownIdx; x.post.visible = !ownIdx && !gone;
      if (ownIdx) {
        x.own.material.color.set(x.color); x.own.material.emissive.set(x.color);
        x.own.material.emissiveIntensity = x.flags.pickable ? .9 : (turn === x.state ? .6 : .4);
        var d = x.drop > now ? (x.drop - now) / 480 : 0; x.own.position.y = 0.065 + d * d * 0.9;   // a new marker drops in
        x.own.scale.setScalar(picking && !x.flags.pickable ? .8 : 1);
      }
      x.dome.visible = ownIdx && !!x.flags.shield;
      if (x.dome.visible) { x.dome.material.color.set(x.color).lerp(hex("#ffffff"), .55); x.dome.rotation.y = now / 2600; }
      x.mesh.visible = true;
    }
    function paint(n, state, color, flags) {
      var x = R[n]; if (!x) return;
      var was = x.state, now = performance.now();
      x.state = state; x.color = color || ""; x.flags = flags || {};
      if (was !== state && was !== undefined) { x.flash = now + 650; if (typeof state === "number") x.drop = now + 480; }
      look(n, now); dirty = true;
    }
    function setTurn(i) { turn = i; dirty = true; }
    function setHl(i) { hl = i; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }
    function setPicking(on) { picking = !!on; canvas.style.cursor = on ? "crosshair" : ""; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }

    // ---- size
    function size() {
      var w = el.clientWidth, h = el.clientHeight; if (!w || !h) return;
      renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); dirty = true;
    }
    var ro = new ResizeObserver(size); ro.observe(el); size();

    // ---- pointer: hover tells, a still tap picks
    var ray = new T.Raycaster(), ndc = new T.Vector2(), down = null;
    function hit(e) {
      var b = canvas.getBoundingClientRect();
      ndc.set(((e.clientX - b.left) / b.width) * 2 - 1, -((e.clientY - b.top) / b.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      var hits = ray.intersectObjects(pick, false);
      for (var i = 0; i < hits.length; i++) { var o = hits[i].object; if (o.visible && o.userData.region) return o.userData.region; }
      return null;
    }
    canvas.addEventListener("pointermove", function (e) {
      if (e.pointerType !== "mouse" || down) return;
      var n = hit(e); if (n) { if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType); } else if (hooks.leave) hooks.leave();
    });
    canvas.addEventListener("pointerdown", function (e) { down = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId }; });
    canvas.addEventListener("pointerup", function (e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), dt = performance.now() - down.t; down = null;
      if (moved > 9 || dt > 600) return;
      var n = hit(e); if (!n) { if (hooks.leave) hooks.leave(); return; }
      if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType);
      if (hooks.tap) hooks.tap(n);
    });
    canvas.addEventListener("pointercancel", function () { down = null; });
    canvas.addEventListener("pointerleave", function () { down = null; if (hooks.leave) hooks.leave(); });
    //MC 2026-10-14 our own dispose forces a context loss too, so only a loss on a live table counts as a failure
    canvas.addEventListener("webglcontextlost", function (e) { e.preventDefault(); if (dead) return; dead = true; if (hooks.fail) hooks.fail("context"); });

    // ---- frames: only drawn when something moved or glows; paused while the tab is hidden
    var last = 0, hidden = false;
    document.addEventListener("visibilitychange", function () { hidden = document.hidden; if (!hidden) dirty = true; });
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      if (hidden) return;
      if (tween) tween(now);
      var moved = controls.update();
      var glow = turn != null || picking || hl != null;
      var live = false;
      names.forEach(function (n) { var x = R[n]; if (x && (x.flash > now || x.drop > now || x.flags.shield)) live = true; });
      if (glow || live) {
        if (now - last < (coarse ? 33 : 16)) { if (!moved && !dirty) return; }
        names.forEach(function (n) { look(n, now); });
        dirty = true;
      }
      if (!dirty && !moved) return;
      dirty = false; last = now;
      renderer.render(scene, camera);
    }
    raf = requestAnimationFrame(frame);
    view("overview", 0); camera.position.set(0, 12.5, 8.5); view("overview", 1100);

    function dispose() {
      dead = true; cancelAnimationFrame(raf); ro.disconnect();
      try { controls.dispose(); } catch (e) {}
      scene.traverse(function (o) { if (o.geometry) o.geometry.dispose(); var m = o.material; if (m) (Array.isArray(m) ? m : [m]).forEach(function (q) { if (q.map) q.map.dispose(); q.dispose(); }); });
      try { renderer.dispose(); renderer.forceContextLoss(); } catch (e) {}
      if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
    }
    return { paint: paint, setTurn: setTurn, setHl: setHl, setPicking: setPicking, view: function (v) { view(v, 750); }, resize: size, dispose: dispose, canvas: canvas };
  }

  window.ShyMap3D = { supported: supported, load: load, mount: mount };
})();
