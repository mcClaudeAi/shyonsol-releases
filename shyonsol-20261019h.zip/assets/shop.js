// Shilluminati Online: the Dojo Shop, Koban, card finishes and the Collection, card mastery, boosts, the Season Scroll,
// holder perks and the Weekly League. Payments go straight from the player's wallet to the community marketing wallet;
// the server checks each one on Solana. Nothing sold here changes the cards, the deal or who wins.
(function () {
  "use strict";
  var P = window.ShyPlay;
  if (!P) return;
  var API = "api/shop.php";
  var $ = function (id) { return document.getElementById(id); };
  var esc = P.esc, me = P.me;
  //MC 2026-10-09 ledger note in its own element, item name and kind split, so each piece hits its own dictionary key
  var LED_KIND = /^(.+) (card frame|table|victory effect|title|name ring|reactions|card back|share card|page banner|nameplate|page effect|page accent|for your page|portrait frame|page seal)$/;
  function ledNote(w) { var m = LED_KIND.exec(w || ""); return '<em class="hi-w">' + (m ? '<i>' + esc(m[1]) + '</i> <i>' + esc(m[2]) + '</i>' : esc(w)) + '</em>'; }
  var cat = null, acc = null, rw = null, clockSkew = 0;
  var E = window.ShyEco = { eq: {}, pub: {}, veq: {}, cm: {}, reacts: [0, 1, 2, 3, 4, 5], onGame: onGame, refresh: refreshMe, open: openShop, mastery: masteryOf,
    need: function (n) { needK = Math.max(0, Math.ceil(+n || 0)); } };   //MC 2026-10-19 the Forge and friends hand their shortfall in, so The Mint opens naming the pack that covers it
  var AV = (function () { var sc = document.currentScript || document.querySelector('script[src*="shop.js"]'); var m = sc && /[?&]v=([\w.-]+)/.exec(sc.src); return m ? "?v=" + m[1] : ""; })();

  // ---------- helpers ----------
  function now() { return Date.now() / 1000 + clockSkew; }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function usd(n) { n = Number(n || 0); return "$" + (n % 1 ? n.toFixed(2) : n.toLocaleString("en-US")); }
  //MC 2026-10-10 prices and pools read in $SHY first (at today's price, to the nearest 10), the dollar figure small beside it.
  //   The checkout still quotes the exact amount and holds it for 20 minutes.
  function shyAmt(u) { var px = cat && cat.shyPx; return px ? Math.max(10, Math.round(u / px / 10) * 10) : 0; }
  function shyTag(u) { var a = shyAmt(u); return a ? fmt(a) + ' $SHY <small class="usd">' + usd(u) + '</small>' : usd(u); }
  function shyPool(u) { var a = shyAmt(u); return a ? fmt(a) + ' $SHY' : usd(u) + ' in $SHY'; }
  // extra Koban for paying in $SHY: everyone's 20%, plus the holder tier's
  function myShyBonus() { return (acc && acc.shyb) || cat.shyBonus; }
  function left(ts) {
    var s = Math.max(0, Math.floor(ts - now())), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    if (d) return d + "d " + h + "h";
    if (h) return h + "h " + m + "m";
    return m + "m " + (x < 10 ? "0" : "") + x + "s";
  }
  function short(a) { return a ? a.slice(0, 4) + "…" + a.slice(-4) : ""; }
  async function api(body) {
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) });
      var j = await r.json();
      if (j && !j.ok && !j.status) j.status = r.status;
      return j;
    } catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  async function getj(q) { try { return await (await fetch(API + "?" + q, { cache: "no-store" })).json(); } catch (e) { return { ok: false }; } }
  function koban(n, cls) { return '<span class="kb' + (cls ? " " + cls : "") + '"><i class="kb-coin" aria-hidden="true"></i>' + fmt(n) + '</span>'; }
  function itemById(id) { return cat ? cat.items.filter(function (x) { return x.id === id; })[0] : null; }
  function goodById(id) { return cat ? cat.goods.filter(function (x) { return x.id === id; })[0] : null; }
  function owned(id) { return !!(acc && acc.owned.indexOf(id) >= 0); }
  function linked() { return !!(acc && acc.wallet); }
  // holders pay less Koban (the server works it out the same way); boosts are the same price for everyone
  function disc() { return (acc && acc.disc) || 0; }
  function kp(base, flat) { var d = flat ? 0 : disc(); return Math.max(5, Math.round(base * (100 - d) / 100 / 5) * 5); }
  function priceTag(was, now2, cls) {
    return (was > now2 ? '<s class="was">' + fmt(was) + '</s>' : "") + koban(now2, cls);
  }
  function loadScript(src) {
    return new Promise(function (res, rej) {
      if (document.querySelector('script[data-src="' + src + '"]')) return res();
      var s = document.createElement("script"); s.src = src + AV; s.dataset.src = src; s.onload = res; s.onerror = function () { rej(new Error("Couldn't load " + src)); };
      document.head.appendChild(s);
    });
  }
  //MC 2026-10-09 pages for the long lists: style items (6), cards (12), purchases and Koban activity (8)
  var PG = {}, PER = { "sh-style": 6, "sh-cards": 12, "sh-ord": 8, "sh-led": 8 };
  function pageOf(key, list) { return window.ShyPager ? ShyPager.slice(list, PER[key], PG[key]) : { items: list }; }
  function pager(key, p) { return window.ShyPager ? ShyPager.html(p, key) : ""; }
  //MC 2026-10-10 two new Style tabs for the Animated set: Region claims (cap) and Turn auras (turn)
  //MC 2026-10-14 four war table tabs for the 3D command table: felt, land, pieces and air
  var SLOTS = { skin: "Shadow skins", halo: "Shadow halos", back: "Card backs", share: "Share cards", frame: "Card frames", table: "Tables", felt: "Table felt", land: "Land finish", piece: "Command pieces", air: "Table air", fx: "Victory", cap: "Region claims", turn: "Turn auras", title: "Titles", ring: "Name rings", emote: "Reactions" };
  var MAP_DEF = { felt: "Dojo Green", land: "Olive Plates", piece: "Faceted Gems", air: "Table Dust" };
  var RAR_N = { rare: "Rare", epic: "Epic", legendary: "Legendary", mythic: "Mythic" };
  function rarChip(r) { return r && RAR_N[r] ? '<span class="rar r-' + r + '">' + RAR_N[r] + '</span>' : ""; }
  function fx2() { return window.ShyFx2 || { tableHTML: function () { return ""; }, capHTML: function () { return ""; }, turnHTML: function () { return ""; }, cap: function () {} }; }
  // Profile Studio items are sold on the profile page, but can still turn up in your history here
  var PAGE_SLOT_N = { banner: "Page banners", plate: "Nameplates", pfx: "Page effects", accent: "Page accents", unlock: "Page extras", pframe: "Portrait frames", seal: "Page seals" };   //MC 2026-10-10 the two new Studio slots
  function slotName(k) { return SLOTS[k] || PAGE_SLOT_N[k] || ""; }
  var SLOT_LEAD = {
    skin: "Your look at the table, on every leaderboard, to your friends and on your share card. Each Shade takes its colours from a Shytoshi Shadow trait.",
    halo: "A frame around your own Shytoshi Shadow: at the table, on rivals' screens, on every leaderboard and on your share card. For holders only.",
    back: "The back of your Chaos cards: on every card you draw, and on rivals' screens in live matches and tournaments.",
    share: "The picture on every result you share to X, and on your wins posted in the Telegram chat.",
    frame: "Your hand wears it, and opponents see it on every card you play in live matches.",
    table: "Repaint the war table.", fx: "Plays when you win. Tap ▶ to preview.",
    title: "Shows under your name on the leaderboards and at the live table.", ring: "A coloured ring on your name everywhere it appears.",
    emote: "Four more reactions to throw in live matches.",
    cap: "Plays every time you claim or take a Region, on your screen and on every rival's in live matches.",
    turn: "Wraps your hand while it's your turn. In live matches, rivals see it on your seat.",
    felt: "The cloth, frame and room light of the 3D command table. Animated felts move while you play.",
    land: "The finish on every Region plate of the 3D table, yours and everyone's.",
    piece: "The shape of your command pieces on the 3D table. In live matches, rivals see your pieces on your Regions.",
    air: "What drifts in the air over the 3D table. Every one moves, and none of them cost a frame."
  };
  var REACT_SETS = { emote_oni: "\u{1F479} \u{1F5E1}️ \u{1F3EF} \u{1F409}", emote_sakura: "\u{1F338} \u{1F375} \u{1F390} \u{1F647}", emote_riches: "\u{1F4B0} \u{1F451} \u{1F48E} \u{1F680}", emote_moon: "\u{1F315} \u{1F98A} \u{1F319} ⛩️" };
  var KINDS = [["attack", "Attack"], ["gain", "Gain"], ["defense", "Defense"], ["global", "Global"], ["trick", "Trick"], ["passive", "Reaction"]];
  var KIND_L = {}; KINDS.forEach(function (k) { KIND_L[k[0]] = k[1]; });
  var FIN_ORDER = ["gold", "crimson", "neon", "holo", "shadow"];
  //MC 2026-10-10 the Animated finishes (cat.prem), shown in their own group under the classic five
  function premFins() { return (cat && cat.prem) || []; }
  function hasPrem(id) { return premFins().some(function (f) { return hasFin(id, f); }); }

  // ---------- cards, finishes and mastery ----------
  function cardName(id) { return cat && cat.deck[id] ? cat.deck[id].name : id; }
  function cardImg(id) { return "assets/cards/" + id + ".webp" + AV; }
  // the art of one card in a finish ("" = the original ink)
  function finArt(id, fin, extra) { return '<span class="cf' + (fin ? " vf-" + fin : "") + (extra ? " " + extra : "") + '"><img src="' + cardImg(id) + '" alt="" loading="lazy"></span>'; }
  function hasFin(id, fin) { return !!(acc && acc.vf && acc.vf[id] && acc.vf[id][fin]); }
  function finCount(id) { return acc && acc.vf && acc.vf[id] ? Object.keys(acc.vf[id]).length : 0; }
  function wornFin(id) { return acc && acc.veq && acc.veq[id] && hasFin(id, acc.veq[id]) ? acc.veq[id] : ""; }
  function plays(id) { return acc && acc.cm ? +acc.cm[id] || 0 : 0; }
  function mLevel(n) { var lv = 0; if (!cat) return 0; Object.keys(cat.mastery).forEach(function (l) { if (n >= cat.mastery[l][0]) lv = +l; }); return lv; }
  function masteryOf(id) { return mLevel(plays(id)); }
  function masteryPending() {
    if (!acc || !cat) return 0;
    var n = 0;
    Object.keys(acc.cm || {}).forEach(function (c) { var lv = mLevel(acc.cm[c]), had = +(acc.cml || {})[c] || 0; if (lv > had) n += lv - had; });
    return n;
  }
  function colLevel() { var lv = 0, pts = acc ? acc.colPts : 0; Object.keys(cat.collection).forEach(function (l) { if (pts >= cat.collection[l].at) lv = +l; }); return lv; }
  function colPending() { if (!acc) return 0; var n = 0, pts = acc.colPts; Object.keys(cat.collection).forEach(function (l) { if (pts >= cat.collection[l].at && acc.cl.indexOf(+l) < 0) n++; }); return n; }
  function pips(lv) { var h = ""; for (var i = 1; i <= 5; i++) h += '<i' + (i <= lv ? ' class="on"' : "") + '></i>'; return '<span class="mpips l' + lv + '" title="' + (lv ? esc(cat.masteryNames[lv]) : "Not mastered yet") + '">' + h + '</span>'; }
  function cardBack(k, cls) { return '<span class="cb cb-' + (k || "ink") + (cls ? " " + cls : "") + '" aria-hidden="true"></span>'; }

  // ---------- state ----------
  async function loadCatalog() {
    var j = await getj("a=catalog");
    if (j.ok) { cat = j; clockSkew = j.now - Date.now() / 1000; }
    return j.ok;
  }
  async function refreshMe() {
    var j = await api({ a: "me" });
    if (j.ok) setAcc(j.me);
    return j.ok;
  }
  var accKey = "", lookKey = "";
  function setAcc(m) {
    // nothing to do when the server sends back exactly what we already show (the common case on every refresh)
    var k = JSON.stringify(m);
    if (k === accKey) return;
    accKey = k; acc = m;
    E.eq = m.eq || {}; E.pub = m.public || {}; E.reacts = m.reacts || [0, 1, 2, 3, 4, 5];
    E.veq = {}; Object.keys(m.veq || {}).forEach(function (c) { if (m.vf && m.vf[c] && m.vf[c][m.veq[c]]) E.veq[c] = m.veq[c]; });
    E.cm = m.cm || {};
    // the game table only needs drawing again when the player's look changed
    var look = JSON.stringify([E.eq, E.pub, E.reacts, E.veq]);
    if (look !== lookKey) { lookKey = look; P.redraw(); }
    renderBar();
    if (shopEl && !shopEl.hidden) renderShop(true);
  }
  async function loadRewards() {
    var j = await getj("a=rewards&me=" + me.pid.slice(0, 6));
    if (j.ok) { rw = j; clockSkew = j.now - Date.now() / 1000; renderRewards(); renderBar(); }
  }
  // a new day or week while the page is open: the daily shop and the bundle change, so fetch the catalog again
  setInterval(function () { if (cat && cat.today && now() >= cat.today.ends) loadCatalog().then(function () { renderBar(); if (shopEl && !shopEl.hidden) renderShop(true); refreshMe(); }); }, 30000);

  // ---------- the dojo bar above the table ----------
  function renderBar() {
    var el = $("dojo"); if (!el || !cat) return;
    var a = acc || { koban: 0, streak: { n: 0, d: "" }, scroll: { xp: 0, prem: false } };
    var tier = Math.floor(a.scroll.xp / cat.tierXp), into = a.scroll.xp % cat.tierXp, maxed = tier >= cat.tiers;
    var today = new Date((now()) * 1000).toISOString().slice(0, 10), playedToday = a.streak.d === today;
    var claimable = acc ? scrollClaimable() : 0;
    var ev = cat.event, gift = acc && acc.gift && !acc.gift.claimed && acc.gift.ok;
    var boosted = acc && acc.boostXp > now();
    var html = '<button class="dj kbtn" data-shop="koban" title="Koban, the game\'s gold coin: earn them by playing, spend them in the Dojo Shop">' + koban(a.koban) + '<span class="dj-plus">+</span></button>';
    var xs = xtState();
    if (xs) { var xd = xs.tasks.filter(function (k) { return k.done; }).length, xl = xs.tasks.filter(function (k) { return !k.done; }).reduce(function (t, k) { return t + k.koban; }, 0) + (xs.bonusPaid ? 0 : xs.bonus);
      html += '<button class="dj xtb' + (xd === xs.tasks.length ? " lit" : "") + '" data-shop="x" title="Daily X tasks: post on X, earn Koban"><span class="dj-k"><span class="xt-ic sm" aria-hidden="true">' + xIcon() + '</span> X Tasks</span><b>' + xd + ' / ' + xs.tasks.length + '</b><small>' + (xd === xs.tasks.length ? "Done today" : "+" + fmt(xl) + " Koban left") + '</small>' + (xd < xs.tasks.length ? '<span class="dj-dot">' + (xs.tasks.length - xd) + '</span>' : "") + '</button>'; }
    var fc = window.ShyFriends ? ShyFriends.counts() : { friends: 0, online: 0, requests: 0, duels: 0 }, fn = fc.requests + fc.duels;
    html += '<button class="dj frb" data-friends title="Friends: challenge them live or to a Duel"><span class="dj-k">Friends</span><b data-fr-count>' + (fc.friends ? (fc.online ? '<i class="fr-on"></i>' + fc.online + " online" : fc.friends + (fc.friends === 1 ? " friend" : " friends")) : "Add friends") + '</b><span class="dj-dot" data-fr-badge' + (fn ? "" : " hidden") + '>' + fn + '</span></button>';
    //MC 2026-10-10 a waiting gift opens Free Koban, where the gift lives now
    html += '<button class="dj shopbtn' + (gift ? " gift" : "") + '" data-shop="' + (gift ? "free" : "today") + '" title="Dojo Shop"><span class="dj-k">Shop</span><b>' + (gift ? "Free gift" : "Today's deals") + '</b>' + (gift ? '<span class="dj-dot" title="A free gift is waiting">1</span>' : "") + '</button>';
    html += '<button class="dj" data-shop="scroll" title="Season Scroll"><span class="dj-k">Scroll' + (boosted ? ' <em class="dj-boost">+' + cat.xpBoost + '% XP</em>' : "") + '</span><b>' + (maxed ? "Max" : "Tier " + tier) + '</b><span class="dj-bar"><i style="width:' + (maxed ? 100 : into / cat.tierXp * 100) + '%"></i></span>' + (claimable ? '<span class="dj-dot" title="Rewards to collect">' + claimable + '</span>' : "") + '</button>';
    html += '<button class="dj ' + (playedToday ? "lit" : "") + '" data-shop="missions" title="Finish a game every day to grow your streak and its Koban"><span class="dj-flame" aria-hidden="true"></span><b>' + (streakAlive(a) ? a.streak.n + "-day streak" : "Start a streak") + '</b><small>' + (playedToday ? "Done today" : "Play today" + (a.streak.n && isYesterday(a.streak.d) ? " to keep it" : "")) + (a.saver ? ' &middot; <span class="dj-saver" title="Streak Savers">' + a.saver + '</span>' : "") + '</small></button>';
    var ms = missionsState(), msDone = ms.filter(function (m) { return m.done; }).length;
    if (ms.length) html += '<button class="dj ms' + (msDone === ms.length ? " lit" : "") + '" data-shop="missions" title="This week\'s missions"><span class="dj-k">Missions</span><b>' + msDone + ' / ' + ms.length + '</b><span class="dj-bar"><i style="width:' + Math.round(ms.reduce(function (t, m) { return t + Math.min(1, m.n / m.goal); }, 0) / ms.length * 100) + '%"></i></span></button>';
    if (rw) html += '<a class="dj gold" href="#rewards" title="Weekly League prize pool"><span class="dj-k">League</span><b>' + shyPool(rw.league.pool.total) + '</b><small data-count="' + rw.weekEnd + '">' + left(rw.weekEnd) + '</small></a>';
    //MC 2026-10-16 the limited bundle on now, with its clock, right in the bar on the Play page: the Raijin Weekend Bundle
    //   while it's on, then the Founder's Bundle until it goes for good (it had a clock only inside the shop)
    var lim = cat.offers.filter(function (o) { return (o.id === "raijin" || o.id === "founder") && o.ends && !(acc && acc.once.indexOf(o.id) >= 0); }).sort(function (x, y) { return (x.id === "raijin" ? 0 : 1) - (y.id === "raijin" ? 0 : 1); })[0];
    if (lim) html += '<button class="dj lim ' + (lim.id === "raijin" ? "storm" : "gold") + '" data-shop="' + (lim.id === "raijin" ? "today" : "koban") + '" title="' + esc(lim.name) + '"><span class="dj-k">' + (lim.id === "raijin" ? "Weekend only" : "Founder's Bundle") + '</b></span><b>' + (lim.id === "raijin" ? "Raijin Bundle" : "Never again") + '</b><small><span data-count="' + lim.ends + '">' + left(lim.ends) + '</span> left</small></button>';
    if (ev) html += '<span class="dj event" title="' + esc(ev.name) + '"><b>' + esc(ev.name) + '</b><small>' + (ev.upcoming ? "starts in " : "ends in ") + '<span data-count="' + (ev.upcoming ? ev.from : ev.to) + '">' + left(ev.upcoming ? ev.from : ev.to) + '</span></small></span>';   //MC 2026-10-09 countdown in its own element so "ends in" keeps one dictionary key
    el.innerHTML = html;
  }
  // still alive: played today or yesterday, or the days missed since are covered by Streak Savers
  function streakAlive(a) {
    if (!a || !a.streak || !a.streak.n || !a.streak.d) return false;
    var today = Date.parse(new Date(now() * 1000).toISOString().slice(0, 10) + "T00:00:00Z"), last = Date.parse(a.streak.d + "T00:00:00Z");
    var missed = Math.round((today - last) / 864e5) - 1;
    return missed <= (a.saver || 0);
  }
  function isYesterday(d) { return d === new Date((now() - 86400) * 1000).toISOString().slice(0, 10); }
  // this week's missions with the player's progress (bounties only once the board is open)
  function missionsState() {
    if (!cat) return [];
    if (acc && acc.missions && acc.missions.length && acc.missions[0].text) return acc.missions.filter(function (m) { return !m.bounty || !m.locked; }).map(function (m) { return Object.assign({}, m, { n: Math.min(m.n, m.goal) }); });
    return (cat.missions || []).map(function (m) { return { id: m.id, text: m.text, goal: m.goal, koban: m.koban, n: 0, done: false }; });
  }
  function scrollClaimable() {
    if (!acc || !cat) return 0;
    var t = Math.floor(acc.scroll.xp / cat.tierXp), n = 0;
    for (var i = 1; i <= t && i <= cat.tiers; i++) {
      var r = cat.scroll[i];
      if (r[0] && acc.scroll.cf.indexOf(i) < 0) n++;
      if (acc.scroll.prem && r[1] && acc.scroll.cp.indexOf(i) < 0) n++;
    }
    return n;
  }
  // live countdowns
  // a background tab skips the tick, and only text that actually changed is written (each write also wakes the translator)
  //MC 2026-10-11 the countdowns and clocks rest while a game is on (html.g-playing) and the shop is shut: every tick
  // rewrote text and the clock forced a reflow, once a second, under the game (GAME audit #21)
  function resting() { return document.documentElement.classList.contains("g-playing") && (!shopEl || shopEl.hidden); }
  setInterval(function () {
    if (document.hidden || resting()) return;
    document.querySelectorAll("[data-count]").forEach(function (x) { var t = (x.dataset.pre || "") + left(+x.dataset.count); if (window.SHYI18N && SHYI18N.T) t = SHYI18N.T(t); if (x.textContent !== t) x.textContent = t; });   //MC 2026-10-09 compare the translated text, or it rewrote every second in other languages
  }, 1000);

  // ---------- shop sheet ----------
  var shopEl = null, tab = "today", sub = "skin", busy = false;
  var cf = { kind: "", q: "", own: false, pv: "" }, cardOpen = "", setKind = "attack", setFin = "gold";
  //MC 2026-10-10 the shop is two halls now. Spend Koban (the Forge): today's deals, finishes, style, boosts, all paid in
  //   Koban. Get Koban (the Mint): packs and offers paid in $SHY, SOL, USDC or card, plus every free way to earn it.
  //   History sits in the header, it covers both. Old tab names still work, so every existing link lands where it did.
  var SIDES = {
    spend: { seal: "鍛", name: "Spend Koban", hall: "The Forge", blurb: "Deals, finishes, style and boosts", tabs: [["today", "Today's deals"], ["cards", "Finishes"], ["style", "Style"], ["boosts", "Boosts"]] },
    get: { seal: "金", name: "Get Koban", hall: "The Mint", blurb: "Packs, offers and free Koban", tabs: [["koban", "Buy Koban"], ["free", "Free Koban"], ["scroll", "Season Scroll"], ["missions", "Missions"], ["x", "X Tasks"]] }
  };
  var lastTab = { spend: "today", get: "koban" }, needK = 0, pendingOpen = null;
  function sideOf(t) { return t === "history" ? "" : SIDES.get.tabs.some(function (x) { return x[0] === t; }) ? "get" : "spend"; }
  var TAB_ALIAS = { featured: "today", items: "style", collection: "style", spend: "today", forge: "today", deals: "today", finishes: "cards", get: "koban", mint: "koban", buy: "koban", packs: "koban", earn: "free", gift: "free" };
  function openShop(where) {
    //MC 2026-10-10 a tap before the catalog arrived used to do nothing. Remember it and open once it's in
    if (!cat) { pendingOpen = where || "today"; return; }
    shopEl = shopEl || $("shop");
    if (!shopEl) return;
    if (where) {
      var w = String(where).split(":");
      tab = TAB_ALIAS[w[0]] || w[0];
      if (w[1]) { if (tab === "cards") cardOpen = w[1]; else sub = w[1]; }
    }
    if (shopEl.hidden || !opener) { var ae = document.activeElement; opener = ae && ae !== document.body && !shopEl.contains(ae) ? ae : null; }
    shopEl.hidden = false;
    document.documentElement.classList.add("shop-open");
    renderShop();
    requestAnimationFrame(function () { shopEl.classList.add("in"); });
    refreshMe();
  }
  //MC 2026-10-09 play.js drops the effect canvas into #game, which sits under the shop (z 900), so the Victory preview
  // and the buy effects played behind the panel and nobody saw them. Lift the canvas to <body> while the shop is open
  // (style.css gives body > .g-confetti a z-index above the shop). Didn't touch play.js, it's not mine
  function fx(k) {
    P.fxRun(k);
    if (!document.documentElement.classList.contains("shop-open")) return;
    var cs = document.querySelectorAll("#game > canvas.g-confetti"), cv = cs[cs.length - 1];
    if (cv) document.body.appendChild(cv);
  }
  //MC 2026-10-09 focus handling for the shop dialog: remember who opened it, keep Tab inside the panel, put focus back on close
  var opener = null;
  function shopFocusKey() {
    var f = document.activeElement;
    if (!f || !shopEl || !shopEl.contains(f)) return "";
    for (var i = 0; i < f.attributes.length; i++) { var a = f.attributes[i]; if (/^data-/.test(a.name)) return (f.closest(".sh-tabs") ? ".sh-tabs " : f.closest(".sh-sub") ? ".sh-sub " : f.closest(".sh-head") ? ".sh-head " : "") + "[" + a.name + '="' + String(a.value).replace(/["\\]/g, "\\$&") + '"]'; }
    return "";
  }
  function shopFocusables() {
    var box = shopEl.querySelector(".cd-pop") || shopEl.querySelector(".sh-panel");
    if (!box) return [];
    return [].filter.call(box.querySelectorAll("a[href],button:not([disabled]),input:not([disabled]),select,textarea,[tabindex='0']"), function (x) { return x.offsetParent || x.getClientRects().length; });
  }
  function closeShop() {
    if (!shopEl) return;
    shopEl.classList.remove("in");
    document.documentElement.classList.remove("shop-open");
    setTimeout(function () { shopEl.hidden = true; }, 220);
    needK = 0;
    if (opener && document.contains(opener) && opener.focus) opener.focus({ preventScroll: true });
    opener = null;
    //MC 2026-10-10 also drop the ?shop that /shop links arrive with, so a reload doesn't open it again
    var qs = location.search.replace(/([?&])shop(=[^&]*)?(&|$)/, function (m, a, b, c) { return c ? a : ""; });
    if (/^#(shop|spend|get)/.test(location.hash) || qs !== location.search) try { history.replaceState(null, "", location.pathname + qs); } catch (e) {}
  }
  function tabDot(t) {
    if (!acc) return 0;
    if (t === "x") { var xs = xtState(); return xs ? xs.tasks.filter(function (k) { return !k.done; }).length : 0; }
    if (t === "free") return (giftReady() ? 1 : 0) + (acc.tier && acc.stipend && !acc.stipend.claimed ? 1 : 0);   //MC 2026-10-10 the gift and the holders' weekly Koban live under Free Koban now
    if (t === "scroll") return scrollClaimable();
    if (t === "cards") return colPending() + (masteryPending() ? 1 : 0);
    return 0;
  }
  function giftReady() { return !!(acc && acc.gift && !acc.gift.claimed && acc.gift.ok); }
  function sideTabs(s) { return SIDES[s].tabs.filter(function (t) { return t[0] !== "x" || xtState(); }); }
  //MC 2026-10-10 can the player pay this many Koban right now? Buttons they can't afford turn quiet, and a tap on one
  //   still asks the server, which answers with how many are missing and sends them to the Mint
  function shortCls(n) { return acc && acc.koban < n ? " kb-short" : ""; }
  function renderShop(keep) {
    if (!shopEl || !cat) return;
    var prevBody = shopEl.querySelector(".sh-body"), prevTop = keep && prevBody ? prevBody.scrollTop : 0;
    var a = acc || { koban: 0 };
    var views = { today: viewToday, cards: viewCards, style: viewStyle, boosts: viewBoosts, scroll: viewScroll, missions: viewMissions, x: viewX, koban: viewKoban, free: viewFree, history: viewHistory };
    if (tab === "x" && !xtState()) tab = "free";
    if (!views[tab]) tab = "today";
    var side = sideOf(tab);
    if (side) lastTab[side] = tab;
    if (tab !== "koban") needK = 0;
    var body = views[tab]();
    var fKey = shopFocusKey();
    var sideBtn = function (s) {
      var S = SIDES[s], d = acc ? sideTabs(s).reduce(function (n, t) { return n + tabDot(t[0]); }, 0) : 0;
      return '<button class="sh-side ss-' + s + (s === side ? " on" : "") + '" data-side="' + s + '" aria-pressed="' + (s === side) + '"><span class="ss-seal" aria-hidden="true">' + S.seal + '</span>' +
        '<span class="ss-t"><b>' + S.name + '</b><small><em>' + S.hall + '</em> <span>' + S.blurb + '</span></small></span>' + (d && s !== side ? '<i class="sh-dot">' + d + '</i>' : "") + '</button>';
    };
    var foot = side !== "spend" ?
      'Payments go straight to the community marketing wallet <a href="https://solscan.io/account/' + cat.mw + '" target="_blank" rel="noopener">' + short(cat.mw) + '</a> and are checked on Solana before anything is delivered. <span class="sf-x">' + cat.pool.pct + '% of every week\'s sales go into the next Weekly League prize pool. Pay in $SHY for +' + myShyBonus() + '% Koban.</span> <a href="/terms">Terms of sale</a>' :
      '<span>Everything in the Forge is paid in Koban. Koban stay in the game and can\'t be cashed out.</span> <span class="sf-x">Finishes, style and boosts never change the cards, the deal or who wins.</span> <a href="/terms">Terms of sale</a>';
    shopEl.innerHTML = '<div class="sh-back" data-close></div><div class="sh-panel side-' + (side || "none") + '" role="dialog" aria-modal="true" aria-label="Shop">' +
      '<header class="sh-head"><div class="sh-brand"><span class="sh-seal">道</span><div><b>Dojo Shop</b><small>Make the game yours. Nothing here changes who wins.</small></div></div>' +
      '<div class="sh-bal">' + (disc() ? '<span class="sh-disc" title="Holders pay less Koban">Holder price &minus;' + disc() + '%</span>' : "") +
      '<button class="sh-hist' + (tab === "history" ? " on" : "") + '" data-tab="history" title="Purchases and Koban activity" aria-label="History"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1M3.5 4v4h4M12 7.5V12l3 2" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg></button>' +
      '<button class="sh-balb" data-tab="koban" title="Get more Koban">' + koban(a.koban, "big") + '<i>+</i></button></div><button class="sh-x" data-close aria-label="Close">✕</button></header>' +
      '<nav class="sh-sides" aria-label="Shop sections">' + sideBtn("spend") + sideBtn("get") + '</nav>' +
      (side ? '<nav class="sh-tabs">' + sideTabs(side).map(function (t) { var d = tabDot(t[0]); return '<button data-tab="' + t[0] + '"' + (t[0] === tab ? ' class="on" aria-current="page"' : "") + '>' + t[1] + (d ? ' <i class="sh-dot">' + d + '</i>' : "") + '</button>'; }).join("") + '</nav>' :
        '<div class="sh-tabs sh-tabs-hist"><span class="sh-hist-t">History</span><small>Purchases and Koban activity</small></div>') +
      '<div class="sh-body">' + body + '</div>' +
      '<footer class="sh-foot">' + foot + '</footer>' +
      '</div>';
    if (prevTop) { var nb = shopEl.querySelector(".sh-body"); if (nb) nb.scrollTop = prevTop; }
    //MC 2026-10-09 the panel only ever scrolls inside .sh-body. A Telegram player on Android ended up with the panel
    //itself scrolled down (focus or the browser nudging it), which pushed the header with the X out of sight and left
    //no way to close the shop. overflow:hidden doesn't stop that, so snap it back if it ever moves.
    var pnl = shopEl.querySelector(".sh-panel");
    if (pnl) pnl.addEventListener("scroll", function () { if (pnl.scrollTop) pnl.scrollTop = 0; });
    //MC 2026-10-09 offsetLeft is measured from the panel, not the tab row, so with the longer German tabs the active one
    // ended up half off screen. Use rects instead, which also works in RTL
    // Run it again on the next frame too: the translation pass swaps the labels after this, and German makes them wider
    function onTabInView() { if (shopEl) shopEl.querySelectorAll(".sh-tabs button.on, .sh-sub .on").forEach(function (b) { var row = b.parentNode, rr = row.getBoundingClientRect(), br = b.getBoundingClientRect(); if (br.right > rr.right - 28 || br.left < rr.left + 28) row.scrollLeft += (br.left + br.width / 2) - (rr.left + rr.width / 2); }); }
    onTabInView(); requestAnimationFrame(onTabInView);
    if (tab === "cards" && cardOpen) { var cd = shopEl.querySelector(".cd-pop"); if (cd) cd.focus(); }
    //MC 2026-10-09 the innerHTML swap above throws focus back to <body>. Put it back on the same control (or the active tab)
    else if (!co || co.hidden) {
      var back = fKey && shopEl.querySelector(fKey);
      if (!back && !shopEl.contains(document.activeElement)) back = shopEl.querySelector(".sh-tabs .on") || shopEl.querySelector(".sh-side.on") || shopEl.querySelector(".sh-hist");
      if (back) back.focus({ preventScroll: true });
    }
  }

  // ---------- Today: gift, deal of the day, Holo Foil, daily picks, the weekly bundle, offers ----------
  function offerPreview(x, big) {
    if (x.kind === "fin") return '<div class="dl-art">' + finArt(x.card, x.fin, big ? "big" : "") + '</div>';
    var it = itemById(x.id); return '<div class="dl-art item">' + (it ? itemPreview(it) : "") + '</div>';
  }
  function offerName(x) {
    if (x.kind === "fin") return '<b>' + esc(cardName(x.card)) + '</b><small>' + esc(cat.finishes[x.fin].name) + '</small>';
    var it = itemById(x.id); return '<b>' + esc(it ? it.name : x.id) + '</b><small>' + esc(it ? slotName(it.slot).replace(/s$/, "") : "") + '</small>';
  }
  function offerBuy(x) {
    var own = x.kind === "fin" ? hasFin(x.card, x.fin) : owned(x.id);
    if (own) return '<span class="owned">Owned</span>';
    var at = x.kind === "fin" ? 'data-fin="' + esc(x.card) + ':' + esc(x.fin) + '"' : 'data-buy="' + esc(x.id) + '"';
    return '<button class="btn btn-red btn-sm' + shortCls(kp(x.price)) + '" ' + at + '>' + priceTag(kp(x.was), kp(x.price)) + '</button>';
  }
  function giftCard() {
    if (!acc) return "";
    var g = acc.gift, moonLeft = acc.moon > now() ? Math.ceil((acc.moon - now()) / 86400) : 0;
    var amt = g.koban + g.moon;
    return '<section class="gift' + (g.claimed ? " done" : "") + '"><div class="gift-box" aria-hidden="true"><i></i></div><div class="gift-t"><span class="of-k">Daily gift</span>' +
      '<h3>' + (g.claimed ? "Collected. Back in <span data-count=\"" + cat.today.ends + "\">" + left(cat.today.ends) + "</span>" : koban(amt) + " waiting for you") + '</h3>' +
      //MC 2026-10-09 two spans so each sentence gets translated; as one line it showed in English in Turkish
      '<p><span>' + fmt(cat.gift.day) + ' Koban a day, ' + fmt(cat.gift.sunday) + ' on Sundays, 2x to 5x for holders.</span>' + (moonLeft ? ' <span>Your Koban Moon adds ' + fmt(cat.gift.moon) + ' more for ' + moonLeft + (moonLeft === 1 ? " day." : " days.") + '</span>' : "") + '</p></div>' +
      (g.claimed ? "" : g.ok ? '<button class="btn btn-mint" data-claim="gift">Collect</button>' : '<button class="btn btn-line" data-close data-play="quick">Play a game to unlock</button>') + '</section>';
  }
  //MC 2026-10-10 the Forge's Today tab is only things paid in Koban now. The gift, the X strip, the prize pool note and
  //   the money offers moved to the Mint; a waiting gift still gets one line up top that walks over to it
  function giftNudge() {
    if (!giftReady()) return "";
    var g = acc.gift;
    return '<button class="sh-nudge" data-tab="free"><span class="gift-box sm" aria-hidden="true"><i></i></span><span class="sn-t"><span class="of-k">Daily gift</span><b>' + fmt(g.koban + g.moon) + ' free Koban waiting for you</b></span><span class="sn-go">Collect &rsaquo;</span></button>';
  }
  function hallHead(kick, title, txt) { return '<div class="hall-hd"><span class="of-k">' + kick + '</span><h3>' + title + '</h3>' + (txt ? '<p>' + txt + '</p>' : "") + '</div>'; }
  function viewToday() {
    var t = cat.today, h = giftNudge();
    //MC 2026-10-13 a new player's first week: the Starter Pack leads the shop with a personal countdown (their own seventh
    //   day, not a global clock). Gone once bought or once the week is over. The offer itself stays buyable in the Mint.
    //MC 2026-10-16 the Raijin Weekend Bundle leads the shop while it's on and not yet bought
    var rj = cat.offers.filter(function (o) { return o.id === "raijin"; })[0];
    if (rj && !(acc && acc.once.indexOf("raijin") >= 0)) h += '<div class="sh-hd"><h4 class="sh-h">This weekend only</h4><small>Gone Sunday at midnight Eastern. Paid in $SHY.</small></div>' + offerCard(rj, true);
    var starter = cat.offers.filter(function (o) { return o.id === "starter"; })[0];
    if (starter && acc && acc.since && now() - acc.since < 604800 && acc.once.indexOf("starter") < 0) {
      var so = { id: starter.id, usd: starter.usd, name: starter.name, desc: starter.desc, ends: acc.since + 604800 };
      h += '<div class="sh-hd"><h4 class="sh-h">Your first week</h4><small>A one-time welcome price, only shown while you\'re new.</small></div>' + offerCard(so, true);
    }
    //MC 2026-10-13 limited finish drops lead the Forge while one is live or counting down: numbered copies, a hard end,
    //   paid in $SHY. Owned shows the copy number; sold out and ended say so instead of a buy button.
    (cat.drops || []).forEach(function (d) {
      var mine = acc && acc.dropn && acc.dropn[d.id];
      var state, cta = "";
      if (mine) state = '<span class="dr-own">Yours: copy ' + mine + " of " + d.n + '</span>';
      else if (d.soldout) state = '<span class="dr-out">Sold out. All ' + d.n + ' copies are gone.</span>';
      else if (now() < d.start) { state = '<span class="dr-when">Starts in <span data-count="' + d.start + '">' + left(d.start) + '</span></span>'; }
      else if (now() >= d.end) state = '<span class="dr-out">This drop has ended.</span>';
      else {
        state = '<span class="dr-left">' + fmt(d.left) + ' of ' + fmt(d.n) + ' left</span><span class="dr-when">Ends in <span data-count="' + d.end + '">' + left(d.end) + '</span></span>';
        cta = '<button class="btn btn-red" data-drop="' + esc(d.id) + '" data-i18n-skip>' + fmt(d.shy) + ' $SHY</button>';
      }
      h += '<section class="dropcard' + (mine ? " own" : d.soldout ? " out" : "") + '"><div class="dr-art">' + finArt(d.card, d.fin) + '</div>' +
        '<div class="dr-t"><span class="of-k">Limited drop &middot; ' + fmt(d.n) + ' copies, ever</span><h3><span data-i18n-skip>' + esc(d.cardName) + '</span> &middot; <span>' + esc(d.finName) + '</span></h3>' +
        '<p>Each copy is numbered as it sells and never sold again. Paid in $SHY; the usual burn share burns in your own payment.</p>' +
        '<div class="dr-row">' + state + cta + '</div></div></section>';
    });
    //MC 2026-10-13 a free player past tier 3 gets one quiet line to the Scroll, where the full personal pitch lives
    if (acc && !acc.scroll.prem && Math.floor(acc.scroll.xp / cat.tierXp) >= 3)
      h += '<button class="sh-cross" data-tab="scroll"><span><b>Your Scroll rewards are piling up.</b><small>You\'re past tier 3. The premium track pays out everything you\'ve already reached, instantly.</small></span><span class="sn-go">Season Scroll &rsaquo;</span></button>';
    h += hallHead("The Forge &middot; today", "Today's deals", '<span>A new deal, three Holo Foils and four picks every day at 00:00 UTC, all paid in Koban.</span> <span>Ends in <span data-count="' + t.ends + '">' + left(t.ends) + '</span>.</span>');
    // deal of the day
    var d = t.deal;
    h += '<section class="deal"><span class="deal-off">&minus;' + d.off + '%</span>' + offerPreview(d, true) +
      '<div class="deal-t"><span class="of-k">Deal of the day &middot; <span data-count="' + t.ends + '">' + left(t.ends) + '</span> left</span><h3>' + offerName(d) + '</h3>' +
      '<p>' + (d.kind === "fin" ? '<span>' + esc(cat.finishes[d.fin].desc) + '</span> <span>Shows in your hand, when you play it, and on every rival\'s screen in live matches.</span>' + (cat.finishes[d.fin].why ? ' <span>' + esc(cat.finishes[d.fin].why) + '</span>' : "") : esc(SLOT_LEAD[(itemById(d.id) || {}).slot] || "")) + '</p>' + offerBuy(d) + '</div></section>';
    // Holo Foil, today only
    h += '<div class="sh-hd"><h4 class="sh-h">Holo Foil, today only</h4><small>Three cards a day, the only way to get Holo. A card\'s Holo can take weeks to come back.</small></div><div class="sh-grid holo">' +
      t.holo.map(function (x) { return '<article class="tile holo">' + offerPreview(x) + '<div class="tile-t">' + offerName(x) + '</div>' + offerBuy(x) + '</article>'; }).join("") + '</div>';
    // daily picks
    h += '<div class="sh-hd"><h4 class="sh-h">Daily picks</h4><small>15% off until the day ends</small></div><div class="sh-grid picks">' +
      t.picks.map(function (x) { return '<article class="tile">' + '<span class="tile-off">&minus;' + x.off + '%</span>' + offerPreview(x) + '<div class="tile-t">' + offerName(x) + '</div>' + offerBuy(x) + '</article>'; }).join("") + '</div>';
    h += bundleCard();
    h += '<button class="sh-cross" data-side="get"><span><b>Running low on Koban?</b><small>Packs, the Koban Moon and free daily Koban are in the Mint.</small></span><span class="sn-go">Get Koban &rsaquo;</span></button>';
    return h;
  }
  //MC 2026-10-10 Free Koban: the daily gift, then every other free way in, each one a tap from its own tab, then the
  //   holder ladder (weekly Koban for holding $SHY). holderCard itself is untouched, it only renders here now
  function viewFree() {
    var a = acc || { streak: { n: 0, d: "" }, scroll: { xp: 0 }, missions: [] }, xs = xtState();
    var ms = missionsState().filter(function (m) { return !m.bounty; }), msDone = ms.filter(function (m) { return m.done; }).length;
    var msLeft = ms.filter(function (m) { return !m.done; }).reduce(function (t, m) { return t + (+m.koban || 0); }, 0);
    var alive = streakAlive(a), n = alive ? a.streak.n : 0, played = a.streak.d === new Date(now() * 1000).toISOString().slice(0, 10);
    var sc = scrollClaimable(), tier = Math.min(Math.floor(a.scroll.xp / cat.tierXp), cat.tiers), cm = colPending() + masteryPending();
    var tile = function (go, seal, cls, title, st, val) {
      var tg = /^href/.test(go) ? "a" : "button";
      return '<' + tg + ' class="earn ' + cls + '" ' + go + '><span class="earn-ic" aria-hidden="true">' + seal + '</span><span class="earn-t"><b>' + title + '</b><small>' + st + '</small></span>' + (val ? '<span class="earn-v">' + val + '</span>' : "") + '<span class="earn-go" aria-hidden="true">&rsaquo;</span></' + tg + '>';
    };
    var pays = [10, 15, 20, 25, 30, 40, 60];
    var h = hallHead("The Mint &middot; free", "Free Koban", "Play, post and come back each day. None of it costs a thing.");
    h += '<div class="free-gift">' + giftCard() + '</div>';
    h += '<div class="earn-grid">';
    if (xs) { var xd = xs.tasks.filter(function (k) { return k.done; }).length, xl = xs.tasks.filter(function (k) { return !k.done; }).reduce(function (t, k) { return t + k.koban; }, 0) + (xs.bonusPaid ? 0 : xs.bonus);
      h += tile('data-tab="x"', '<span class="xt-ic" aria-hidden="true">' + xIcon() + '</span>', "e-x" + (xd === xs.tasks.length ? " done" : ""), "Daily X tasks", xd === xs.tasks.length ? "All done today" : xd + " of " + xs.tasks.length + " done today", xl ? koban(xl) : ""); }
    h += tile('data-tab="missions"', "炎", "e-streak" + (played ? " done" : ""), n ? n + "-day streak" : "Daily streak", played ? "Done today" : "Finish one game today", played ? "" : koban(pays[n % 7]));
    h += tile('data-tab="missions"', "任", "e-ms" + (ms.length && msDone === ms.length ? " done" : ""), "Weekly missions", msDone + " of " + ms.length + " done this week", msLeft ? koban(msLeft) : "");
    h += tile('data-tab="scroll"', "巻", "e-scroll" + (sc ? " ready" : ""), "Season Scroll", sc ? (sc === 1 ? "1 reward to collect" : sc + " rewards to collect") : "Tier " + tier + " of " + cat.tiers, "");
    h += tile('data-tab="cards"', "極", "e-col" + (cm ? " ready" : ""), "Collection and mastery", cm ? "Rewards ready to collect" : "Master cards and collect finishes", "");
    if (rw) h += tile('href="#rewards" data-close', "杯", "e-league", "Weekly League", "The top 10 win $SHY and Koban", "");
    h += '</div>';
    h += holderCard();
    return h;
  }
  function bundleCard() {
    var b = cat.bundle, q = acc ? acc.bundle : { left: 0, full: 0, price: 0, parts: 1 };
    var chips = b.items.map(function (id) { var it = itemById(id); return it ? '<span class="bd-chip' + (owned(id) ? " own" : "") + '"><i class="sc-ic s-' + it.slot + '"></i>' + esc(it.name) + ' <small>' + esc(slotName(it.slot).replace(/s$/, "").toLowerCase()) + '</small></span>' : ""; }).join("");
    var cardsOwned = b.cards.filter(function (c) { return hasFin(c, b.fin); }).length;
    return '<section class="bundle bd-' + esc(b.id) + '"><div class="bd-fan">' + b.cards.slice(0, 5).map(function (c, i) { return '<span class="bd-c" style="--i:' + i + '">' + finArt(c, b.fin) + '</span>'; }).join("") + '</div>' +
      '<div class="bd-t"><span class="of-k">This week\'s bundle &middot; <span data-count="' + b.ends + '">' + left(b.ends) + '</span> left</span><h3>' + esc(b.name) + '</h3><p>' + esc(b.desc) + ' ' + b.cards.length + ' cards in ' + esc(cat.finishes[b.fin].name) + ', plus:</p>' +
      '<div class="bd-chips">' + chips + '<span class="bd-chip' + (cardsOwned === b.cards.length ? " own" : "") + '"><i class="sc-ic s-fin"></i>' + b.cards.length + ' cards in ' + esc(cat.finishes[b.fin].name) + (cardsOwned ? ' (' + cardsOwned + ' owned)' : "") + '</span></div>' +
      (!acc ? "" : !q.parts ? '<span class="owned">You own the whole set</span>' :
        '<div class="bd-buy"><button class="btn btn-red' + shortCls(q.price) + '" data-bundle="' + q.price + '">' + priceTag(kp(q.full), q.price) + '</button><small>' + (q.left < q.full ? "Priced for the parts you don't own yet, 30% off." : "30% off buying each part.") + '</small></div>') +
      '</div></section>';
  }
  function offerCard(o, big) {
    var done = acc && acc.once.indexOf(o.id) >= 0, scrollDone = o.scroll && acc && acc.scroll.prem && o.id === "scroll";
    var seal = { founder: "創", starter: "始", moon: "月", scroll: "巻", scrollplus: "巻", plusup: "巻", raijin: "雷" }[o.id] || "巻";
    //MC 2026-10-16 the Raijin Weekend Bundle: a storm card (lightning over the seal) and "Weekend only, $SHY only"
    var art = '<div class="of-art ' + (o.id === "founder" ? "founder" : o.id === "starter" ? "starter" : o.id === "moon" ? "moon" : o.id === "raijin" ? "raijin" : "scroll") + '">' + (o.id === "raijin" ? '<i class="of-bolt" aria-hidden="true"></i>' : "") + '<span class="of-seal">' + seal + '</span></div>';
    var kick = o.ends && o.id === "raijin" ? 'Weekend only &middot; <span data-count="' + o.ends + '">' + left(o.ends) + '</span> left &middot; $SHY only' : o.ends ? 'Limited &middot; <span data-count="' + o.ends + '">' + left(o.ends) + '</span> left' : o.once ? "One per player" : o.id === "moon" ? (acc && acc.moon > now() ? "Active &middot; " + Math.ceil((acc.moon - now()) / 86400) + " days left, buy to add 30" : "Best value") : "This season";
    return '<article class="offer' + (big ? " big" : "") + (o.id === "founder" ? " gold" : "") + (o.id === "raijin" ? " storm" : "") + (o.id === "moon" ? " moon" : "") + '">' + art +
      '<div class="of-txt"><span class="of-k">' + kick + '</span>' +
      '<h3>' + esc(o.name) + '</h3><p>' + esc(o.desc) + '</p>' +
      '<div class="of-buy">' + (done || scrollDone ? '<span class="owned">Owned</span>' :
        '<button class="btn btn-red" data-pay="' + o.id + '">' + shyTag(o.usd) + '</button>' + (o.koban_price ? '<button class="btn btn-line' + shortCls(o.koban_price) + '" data-buy="scroll">' + koban(o.koban_price) + '</button>' : "")) +
      '</div></div></article>';
  }
  //MC 2026-10-10 the holder ladder: the nine $SHY Army Ranks in three circles, each with its poster emblem, what it
  //   gets and how far the player is from the next. Replaced the seven Bronze to Kami tiers.
  function shyShort(n) { n = +n || 0; return n >= 1e6 ? (n / 1e6).toLocaleString("en-US", { maximumFractionDigits: 1 }) + "M" : n >= 1e3 ? Math.round(n / 1e3).toLocaleString("en-US") + "K" : fmt(n); }
  function holderCard() {
    var t = acc && acc.tier, st = acc && acc.stipend, L = cat.ladder || [], T = cat.holderTiers, S = cat.stipend, PK = cat.holderPerks, N = cat.holderNames;
    var bal = acc && acc.shy ? Math.floor(acc.shy.bal) : null, nx = acc && acc.next;
    var FREE = { bounty: "Bounty Board every week", scroll: "Season Scroll free", plus: "Scroll+ free" };
    var circles = [["Recruits", ["sapling", "cadet", "scout"]], ["Officers", ["knight", "champion", "commander"]], ["High Command", ["sovereign", "king", "supreme"]]];
    var rkImg = function (k) { return "/assets/ranks/" + k + "-64.webp"; };
    var rkChip = function (k) { return '<em class="tier-b rk t-' + k + '" data-i18n-skip><img src="' + rkImg(k) + '" alt="" width="17" height="17">' + esc(N[k]) + '</em>'; };
    var row = function (k) {
      var p = PK[k], fr = (p.free || []).filter(function (f) { return !(f === "scroll" && p.free.indexOf("plus") >= 0); });
      return '<li class="hl-row rk t-' + k + (t === k ? " on" : "") + '"><div class="hl-top"><img class="hl-em" src="' + rkImg(k) + '" alt="" width="44" height="44" loading="lazy"><span class="hl-nm"><em class="rk-nm" data-i18n-skip>' + esc(N[k]) + '</em><b>' + shyShort(T[k]) + '+ <small>$SHY</small></b></span>' + (t === k ? '<span class="hl-you">You</span>' : "") + '</div>' +
        '<div class="hl-perks"><span class="hl-p">' + koban(S[k]) + '<small>a week</small></span>' +
        (p.disc ? '<span class="hl-p"><b>&minus;' + p.disc + '%</b><small>Koban prices</small></span>' : "") +
        '<span class="hl-p"><b>' + p.gift + 'x</b><small>daily gift</small></span>' +
        '<span class="hl-p"><b>+' + (cat.shyBonus + p.shyb) + '%</b><small>Koban paying in $SHY</small></span></div>' +
        (fr.length ? '<div class="hl-free">' + fr.map(function (f) { return '<span>' + FREE[f] + '</span>'; }).join("") + '</div>' : "") + '</li>';
    };
    var status = "";
    if (linked()) {
      if (bal !== null) status = '<div class="hl-me"><span>You hold <b>' + fmt(bal) + ' $SHY</b>' + (t && t !== "shadow" ? ': ' + rkChip(t) : t === "shadow" ? ': Shadow holder' : "") + '.</span>' +
        (nx ? '<span>' + fmt(Math.ceil(nx.need)) + ' more to reach <b data-i18n-skip>' + esc(N[nx.tier]) + '</b>.</span><span class="hl-bar"><i style="width:' + Math.max(3, Math.min(100, Math.round(bal / nx.at * 100))) + '%"></i></span>' : '<span>The top of the ranks.</span>') + '</div>';
      else status = '<div class="hl-me"><span>Checking <span data-i18n-skip>' + short(acc.wallet) + '</span> on Solana&hellip;</span></div>';
    }
    //MC 2026-10-15 time held at your rank (api/loyaltylib.php): the step you're on, what it adds, and the next one
    var ly = acc && acc.loyal, loyal = "";
    if (ly && t && t !== "shadow") {
      var steps = [[30, "Steady Hands", 10], [90, "Diamond Hands", 25], [180, "Ancient Holder", 50]];
      loyal = '<div class="hl-loyal"><div class="hl-ly-top"><span class="hl-ly-k">Diamond hands</span><b>' + (ly.days === 1 ? "1 day" : ly.days + " days") + '</b><small>held at <span data-i18n-skip>' + esc(N[t]) + '</span></small></div>' +
        '<div class="hl-ly-steps">' + steps.map(function (x) { var on = ly.days >= x[0]; return '<span class="' + (on ? "on" : "") + '"><i style="width:' + Math.max(0, Math.min(100, Math.round(ly.days / x[0] * 100))) + '%"></i><b>' + x[1] + '</b><small>' + x[0] + ' days · +' + x[2] + '% weekly Koban' + (x[0] >= 90 ? ' · title' : '') + '</small></span>'; }).join("") + '</div>' +
        '<p class="hl-ly-note">' + (ly.bonus ? '+' + fmt(ly.bonus) + ' Koban a week from ' + (ly.from ? ly.from.days + ' days at <span data-i18n-skip>' + esc(ly.from.name) + '</span>' : "time held") + '. ' : "") +
        (ly.next ? ly.next.name + ' in ' + ly.next.in + (ly.next.in === 1 ? ' day' : ' days') + '. ' : 'Every step reached. ') +
        'The clock counts days in a row at your rank and belongs to your wallet. Dropping below a rank restarts that rank\'s clock; moving up keeps the bonus you built below.</p></div>';
    }
    var act = t ? (st && !st.claimed ? '<button class="btn btn-mint" data-claim="stipend">Collect ' + fmt(st.koban) + ' Koban' + (st.free && st.free.length ? " and your perks" : "") + '</button>' : '<span class="owned">Collected this week. Back Monday.</span>')
      : (linked() ? '<a class="btn btn-line" href="/swap">Get $SHY</a>' : '<button class="btn btn-mint" data-wallet>Connect wallet</button>');
    return '<section class="holder-card hl"><div class="hl-head"><div><span class="of-k">$SHY Army Ranks</span><h3>The more $SHY you hold, the more you get</h3>' +
      '<p><span>Nine ranks by the $SHY in your connected wallet. Every rank gets weekly Koban, bigger daily gifts, extra Koban when you pay in $SHY, the Holder title, ring and card back, and a seat in the Holder Cup every week.</span> <span>A Shytoshi Shadow counts too: ' + fmt(S.shadow) + ' Koban a week and double gifts.</span></p></div>' +
      '<div class="hl-act">' + status + act + '</div>' + loyal + '</div>' +
      '<div class="hl-circles">' + circles.map(function (c) { return '<div class="hl-circle rk t-' + c[1][0] + '"><h4>' + c[0] + '</h4><ul>' + c[1].filter(function (k) { return L.indexOf(k) >= 0; }).map(row).join("") + '</ul></div>'; }).join("") + '</div></section>';
  }

  // ---------- Cards: every Chaos card, its finishes and its mastery ----------
  function cardList() {
    var ids = Object.keys(cat.deck), q = cf.q.toLowerCase();
    return ids.filter(function (id) {
      var c = cat.deck[id];
      if (cf.kind && c.kind !== cf.kind) return false;
      if (q && c.name.toLowerCase().indexOf(q) < 0) return false;
      if (cf.own && !finCount(id)) return false;
      return true;
    });
  }
  function viewCards() {
    var lv = colLevel(), pts = acc ? acc.colPts : 0, levels = Object.keys(cat.collection).map(Number);
    var next = levels.filter(function (l) { return pts < cat.collection[l].at; })[0], nextAt = next ? cat.collection[next].at : pts, prevAt = lv ? cat.collection[lv].at : 0;
    var pend = colPending(), mpend = masteryPending();
    var h = hallHead("The Forge &middot; finishes", "Card finishes", "A finish repaints one Chaos card, in your hand and on every rival's screen. Buy one at a time, every finish for a card, or a whole kind at once.");
    h += '<section class="col-head"><div class="col-ring" style="--p:' + (next ? Math.round((pts - prevAt) / Math.max(1, nextAt - prevAt) * 100) : 100) + '"><b>' + lv + '</b><small>Level</small></div>' +
      '<div class="col-t"><span class="of-k">Your Collection</span><h3>' + fmt(pts) + ' finishes owned</h3><p>' + (next ? fmt(nextAt - pts) + ' more to level ' + next + ': ' + rewardText(cat.collection[next].reward) + '.' : 'Every level reached. You own the archive.') + ' Every finish you own counts. Play cards to master them: Master (100 plays) gives that card\'s Gold Leaf for free.</p>' +
      '<div class="col-acts">' + (pend ? '<button class="btn btn-mint btn-sm" data-claim="collection">Collect ' + pend + (pend === 1 ? " level reward" : " level rewards") + '</button>' : "") + (mpend ? '<button class="btn btn-mint btn-sm" data-claim="mastery">Collect mastery rewards</button>' : "") + '</div></div>' +
      '<ol class="col-steps">' + levels.map(function (l) { var c = cat.collection[l], got = acc && acc.cl.indexOf(l) >= 0, reach = pts >= c.at; return '<li class="' + (got ? "got" : reach ? "ready" : "") + '" title="' + esc(rewardText(c.reward)) + '"><b>' + l + '</b><small>' + c.at + '</small></li>'; }).join("") + '</ol></section>';
    h += afinShow();
    h += whyCollect();
    h += '<div class="cf-bar"><div class="cf-kinds"><button data-ck=""' + (cf.kind ? "" : ' class="on"') + '>All</button>' + KINDS.map(function (k) { return '<button data-ck="' + k[0] + '"' + (cf.kind === k[0] ? ' class="on"' : "") + '>' + k[1] + '</button>'; }).join("") + '</div>' +
      '<label class="cf-q"><input type="search" placeholder="Find a card" value="' + esc(cf.q) + '" data-cq autocomplete="off" spellcheck="false"></label><label class="cf-own"><input type="checkbox" data-cown' + (cf.own ? " checked" : "") + '> With a finish</label></div>';
    h += '<div class="cc-wrap">' + ccGrid() + '</div>';
    h += kindSetCard();
    if (cardOpen) h += cardDetail(cardOpen);
    return h;
  }
  //MC 2026-10-10 the Animated finishes, each shown moving on one card. Tap one to see every card in it, then open a card to buy.
  function afinShow() {
    var P2 = premFins(); if (!P2.length) return "";
    var sample = cat.deck.meteor ? "meteor" : Object.keys(cat.deck)[0];
    return '<section class="afin"><div class="afin-hd"><h4 class="sh-h">Animated finishes</h4><p>Priced per card. Tap one to see your whole deck in it.</p></div><div class="afin-grid">' +
      P2.map(function (f) { var F = cat.finishes[f]; return '<button class="afin-t' + (cf.pv === f ? " on" : "") + '" data-afin="' + f + '">' + finArt(sample, f) + '<b>' + esc(F.name) + '</b><span class="afin-p">' + rarChip(F.rar) + '<small>' + koban(kp(F.koban)) + ' a card</small></span></button>'; }).join("") + '</div>' +
      (cf.pv && cat.finishes[cf.pv] ? '<div class="afin-pv"><span>Showing every card in <b>' + esc(cat.finishes[cf.pv].name) + '</b>. Open a card to buy it.</span><button class="btn btn-line btn-sm" data-afin="">Stop preview</button></div>' : "") + '</section>';
  }
  // what finishes are for, said plainly: they show, some are rare, they add up. They never change play.
  function whyCollect() {
    var pts = [
      ["👁", "Seen at every table", "Your finish shows in your hand, on the big card when you play it, and on every rival's screen in live matches and tournaments."],
      ["💠", "Rare ones stay rare", "Only three cards get a Holo each day. Shadow Ink is never sold. Gold Leaf comes free with cards you master."],
      ["🏯", "Your collection adds up", "Every finish raises your Collection level, with Koban, card backs, titles and frames on the way. Full sets show on your profile."]
    ];
    return '<section class="why-col"><h4 class="sh-h">Why collect finishes?</h4><div class="why-pts">' + pts.map(function (p) { return '<div><span class="why-ic" aria-hidden="true">' + p[0] + '</span><b>' + p[1] + '</b><p>' + p[2] + '</p></div>'; }).join("") + '</div>' +
      '<p class="why-note">Finishes are for show. They never change how a card plays, the odds, or who wins.</p></section>';
  }
  function ccGrid() {
    var list = cardList(), p = pageOf("sh-cards", list);
    return '<div class="cc-grid">' + (list.length ? p.items.map(cardTile).join("") : '<p class="hi-empty">No cards match.</p>') + '</div>' + pager("sh-cards", p);
  }
  function cardTile(id) {
    var c = cat.deck[id], n = finCount(id), lv = mLevel(plays(id)), w = cf.pv || wornFin(id);
    var dots = FIN_ORDER.map(function (f) { return '<i class="fd fd-' + f + (hasFin(id, f) ? " on" : "") + '" title="' + esc(cat.finishes[f].name) + '"></i>'; }).join("") +
      (premFins().length ? '<i class="fd fd-anim' + (hasPrem(id) ? " on" : "") + '" title="Animated finishes"></i>' : "");
    return '<button class="cc k-' + c.kind + '" data-card="' + id + '">' + finArt(id, w) + '<span class="cc-t"><b>' + esc(c.name) + '</b><small>' + KIND_L[c.kind] + ' &middot; ' + fmt(plays(id)) + (plays(id) === 1 ? " play" : " plays") + '</small></span>' +
      '<span class="cc-f">' + dots + '</span>' + pips(lv) + '</button>';
  }
  function finState(id, f) {
    var F = cat.finishes[f], own = hasFin(id, f), worn = wornFin(id) === f;
    if (own) return worn ? '<span class="owned">Wearing</span>' : '<button class="btn btn-mint btn-sm" data-wear="' + id + ':' + f + '">Wear</button>';
    var deal = todayFor(id, f);
    if (deal) return '<button class="btn btn-red btn-sm' + shortCls(kp(deal.price)) + '" data-fin="' + id + ':' + f + '">' + priceTag(kp(deal.was), kp(deal.price)) + '</button>';
    if (cat.shelf.indexOf(f) >= 0) return '<button class="btn btn-red btn-sm' + shortCls(kp(F.koban)) + '" data-fin="' + id + ':' + f + '">' + koban(kp(F.koban)) + '</button>';
    if (premFins().indexOf(f) >= 0) return '<button class="btn btn-red btn-sm' + shortCls(kp(F.koban)) + '" data-fin="' + id + ':' + f + '" data-big="1">' + koban(kp(F.koban)) + '</button>';
    if (f === "holo") return '<span class="locked">In the daily shop</span>';
    var sc = cat.seasonCards.indexOf(id);
    return '<span class="locked">' + (sc >= 0 && sc < 6 ? "Season Scroll, this season" : "Season Scroll, another season") + '</span>';
  }
  function todayFor(id, f) {
    var t = cat.today; return [t.deal].concat(t.holo, t.picks).filter(function (x) { return x.kind === "fin" && x.card === id && x.fin === f; })[0];
  }
  function cardDetail(id) {
    var c = cat.deck[id]; if (!c) return "";
    var w = wornFin(id), n = plays(id), lv = mLevel(n), nextL = lv < 5 ? lv + 1 : 0;
    var setLeft = cat.shelf.filter(function (f) { return !hasFin(id, f); });
    var setFull = setLeft.reduce(function (t, f) { return t + cat.finishes[f].koban; }, 0), setPrice = Math.round(setFull * 0.8 / 10) * 10;
    var rows = '<li class="' + (!w ? "on" : "") + '"><span class="fr-sw">' + finArt(id, "", "sw") + '</span><div><b>Ink</b><small>The original drawing</small></div>' + (!w ? '<span class="owned">Wearing</span>' : '<button class="btn btn-line btn-sm" data-wear="' + id + ':">Wear</button>') + '</li>' +
      FIN_ORDER.map(function (f) { return '<li class="' + (w === f ? "on" : "") + '"><span class="fr-sw">' + finArt(id, f, "sw") + '</span><div><b>' + esc(cat.finishes[f].name) + '</b><small>' + esc(cat.finishes[f].desc) + '</small>' + (cat.finishes[f].why ? '<small class="fr-why">' + esc(cat.finishes[f].why) + '</small>' : "") + '</div>' + finState(id, f) + '</li>'; }).join("");
    return '<div class="cd-pop" tabindex="-1" role="dialog" aria-label="' + esc(c.name) + '"><div class="cd-back" data-cd-close></div><div class="cd-panel"><button class="sh-x" data-cd-close aria-label="Close">✕</button>' +
      '<div class="cd-l"><div class="cd-card k-' + c.kind + '">' + finArt(id, w, "big") + '<span class="gc-body"><span class="gc-k">' + KIND_L[c.kind] + '</span><b>' + esc(c.name) + '</b></span></div>' +
      '<div class="cd-m"><span class="of-k">Mastery</span><b>' + (lv ? esc(cat.masteryNames[lv]) : "Not mastered yet") + '</b>' + pips(lv) + '<small>' + fmt(n) + (n === 1 ? " play" : " plays") + (nextL ? ' &middot; ' + esc(cat.masteryNames[nextL]) + ' at ' + cat.mastery[nextL][0] + ', pays ' + cat.mastery[nextL][1] + ' Koban' + (nextL === 4 ? ' and this card\'s Gold Leaf' : "") : " &middot; fully mastered") + '</small></div></div>' +
      //MC 2026-10-09 was class fr-list, which collided with the Friends panel list (its flex + wrap rules broke these rows). Renamed to fin-list
      '<div class="cd-r"><h3>' + esc(c.name) + '</h3><ul class="fin-list">' + rows + '</ul>' +
      (premFins().length ? '<h4 class="fin-h">Animated finishes</h4><ul class="fin-list">' + premFins().map(function (f) { var F = cat.finishes[f]; return '<li class="' + (w === f ? "on" : "") + '"><span class="fr-sw">' + finArt(id, f, "sw") + '</span><div><b>' + esc(F.name) + '</b>' + rarChip(F.rar) + '<small>' + esc(F.desc) + '</small>' + (F.why ? '<small class="fr-why">' + esc(F.why) + '</small>' : "") + '</div>' + finState(id, f) + '</li>'; }).join("") + '</ul>' : "") +
      (setLeft.length > 1 ? '<div class="cd-set"><div><b>Every finish for this card</b><small>' + setLeft.map(function (f) { return esc(cat.finishes[f].name); }).join(", ") + ', 20% off</small></div><button class="btn btn-red btn-sm' + shortCls(kp(setPrice)) + '" data-set="card:' + id + '" data-price="' + kp(setPrice) + '">' + priceTag(kp(setFull), kp(setPrice)) + '</button></div>' : "") +
      '</div></div></div>';
  }
  function kindSetCard() {
    var ids = Object.keys(cat.deck).filter(function (id) { return cat.deck[id].kind === setKind; });
    var miss = ids.filter(function (id) { return !hasFin(id, setFin); });
    var full = miss.length * cat.finishes[setFin].koban, price = Math.round(full * 0.75 / 10) * 10;
    return '<section class="kset"><div class="kset-fan">' + ids.slice(0, 5).map(function (id, i) { return '<span class="bd-c" style="--i:' + i + '">' + finArt(id, setFin) + '</span>'; }).join("") + '</div>' +
      '<div class="kset-t"><span class="of-k">Finish a whole kind, 25% off</span><h3>Every ' + esc(KIND_L[setKind]) + ' card in ' + esc(cat.finishes[setFin].name) + '</h3>' +
      '<div class="kset-pick"><select data-skind aria-label="Kind">' + KINDS.map(function (k) { return '<option value="' + k[0] + '"' + (k[0] === setKind ? " selected" : "") + '>' + k[1] + ' (' + Object.keys(cat.deck).filter(function (id) { return cat.deck[id].kind === k[0]; }).length + ')</option>'; }).join("") + '</select>' +
      '<select data-sfin aria-label="Finish">' + cat.shelf.concat(premFins()).map(function (f) { return '<option value="' + f + '"' + (f === setFin ? " selected" : "") + '>' + esc(cat.finishes[f].name) + '</option>'; }).join("") + '</select></div>' +
      '<p>' + (miss.length ? miss.length + ' of ' + ids.length + ' cards still to get.' : 'You own all ' + ids.length + '.') + '</p>' +
      (miss.length ? '<button class="btn btn-red' + shortCls(kp(price)) + '" data-set="kind:' + setKind + ':' + setFin + '" data-price="' + kp(price) + '"' + (premFins().indexOf(setFin) >= 0 ? ' data-big="1"' : "") + '>' + priceTag(kp(full), kp(price)) + '</button>' : '<span class="owned">Complete</span>') + '</div></section>';
  }
  function rewardText(r) {
    if (!r) return "";
    if (r.koban) return fmt(r.koban) + " Koban";
    if (r.item) { var it = itemById(r.item); return it ? it.name + " (" + slotName(it.slot).replace(/s$/, "").toLowerCase() + ")" : r.item; }
    if (r.fin) return cardName(r.fin[0]) + " in " + cat.finishes[r.fin[1]].name;
    if (r.boost) { var g = goodById(r.boost); return g ? g.name : r.boost; }
    if (r.perk) return r.perk;   //MC 2026-10-10 holder perks that come with the weekly stipend
    return "";
  }

  // ---------- Style: card backs, share cards, frames, tables, victory, titles, rings, reactions ----------
  function itemPreview(it) {
    var s = it.slot, k = it.id.replace(/^[a-z]+_/, "");
    if (s === "frame") return '<div class="pv pv-frame"><span class="gc mini fr-' + k + '"><img src="assets/art/frame-preview.jpg' + AV + '" alt="" loading="lazy"><b>Coup d’État</b></span></div>';
    if (s === "table") return '<div class="pv pv-table tb-' + k + '">' + fx2().tableHTML(k) + '<i></i><i></i><i></i></div>';
    if (MAP_DEF[s]) return '<div class="pv pv-map"><img src="assets/art/map/' + esc(it.id) + '.jpg' + AV + '" alt="" loading="lazy"></div>';
    if (s === "cap") return '<div class="pv pv-cap"><span class="pv-n">+1<small>Region</small>' + fx2().capHTML(k) + '</span></div>';
    if (s === "turn") return '<div class="pv pv-turn"><div class="pv-hand">' + fx2().turnHTML(k) + '<span></span><span></span><span></span><span></span></div></div>';
    if (s === "fx") return '<div class="pv pv-fx fx-' + k + '"><button class="pv-play" data-fx="' + k + '" aria-label="Preview">▶</button></div>';
    if (s === "title") return '<div class="pv pv-title"><span class="g-title big">' + esc(it.name) + '</span></div>';
    if (s === "ring") return '<div class="pv pv-ring"><span class="ring-dot ring-' + k + '"></span></div>';
    if (s === "emote") return '<div class="pv pv-emote">' + (REACT_SETS[it.id] || "") + '</div>';
    if (s === "back") return '<div class="pv pv-back">' + cardBack(k, "a") + cardBack(k, "b") + cardBack(k, "c") + '</div>';
    if (s === "halo") { var sh = myShadowLook(); return '<div class="pv pv-halo' + (sh ? "" : " locked") + '"><span class="av-aura au-' + (sh ? sh.aura : "none") + ' hl-' + esc(k) + '"><img src="' + esc(sh ? sh.img : "assets/art/masks/unbound.svg" + AV) + '" alt="" loading="lazy"></span></div>'; }
    if (s === "skin") return '<div class="pv pv-skin"><img src="assets/art/skins/' + esc(it.id) + '.svg' + AV + '" alt="" loading="lazy"></div>';
    if (s === "share") return '<div class="pv pv-share"><img src="assets/art/share/' + k + '.jpg' + AV + '" alt="" loading="lazy"></div>';
    return "";
  }
  function itemSource(it) {
    if (it.offer) return it.offer === "founder" ? "Founder's Bundle" : it.offer === "raijin" ? "Raijin Weekend Bundle" : "Starter Pack";
    if (it.scroll) return "Season Scroll reward";
    if (it.holder) return "Holder perk";
    if (it.earned === "collection") { var l = Object.keys(cat.collection).filter(function (x) { return cat.collection[x].reward.item === it.id; })[0]; return l ? "Collection level " + l : "Collection reward"; }
    if (it.earned === "mastery") return "Grandmaster a card";
    if (it.earned === "ranked") return it.id === "title_rk_shogun" ? "Finish a ranked season in Shogun" : "Finish a ranked season in Jade";
    if (it.earned === "bounty") return "Win a game holding 15 Regions";   //MC 2026-10-09 the 15 Club title
    if (it.earned === "loyal") return it.id === "title_ancient" ? "Hold Kusama Cadet or higher for 180 days" : "Hold Kusama Cadet or higher for 90 days";   //MC 2026-10-15
    if (it.earned) return it.id === "title_cup" ? "Win a tournament" : "Win the Weekly League";
    return "";
  }
  function itemCard(it) {
    var own = owned(it.id), on = acc && acc.eq[it.slot] === it.id;
    var deal = cat.today.picks.concat([cat.today.deal]).filter(function (x) { return x.kind === "item" && x.id === it.id; })[0];
    var act = "";
    if (it.shadow && !own && !myShadowLook()) act = '<a class="btn btn-line btn-sm" href="/nfts" data-close title="Hold a Shytoshi Shadow to unlock Halos">Holders only</a>';
    //MC 2026-10-09 the "Equipped" button silently took the item off. Now it says Equipped as plain text like the default cards, with a real "Take off" button next to it
    else if (own) act = it.slot === "emote" ? '<span class="owned">Unlocked</span>' : on ? '<span class="owned">Equipped</span><button class="btn btn-line btn-sm" data-equip="' + it.slot + ':">Take off</button>' : '<button class="btn btn-mint btn-sm" data-equip="' + it.slot + ':' + it.id + '">Equip</button>';
    else if (it.koban) act = '<button class="btn btn-red btn-sm' + shortCls(deal ? kp(deal.price) : kp(it.koban)) + '" data-buy="' + it.id + '"' + (it.rar ? ' data-big="1"' : "") + '>' + (deal ? priceTag(kp(it.koban), kp(deal.price)) : priceTag(it.koban, kp(it.koban))) + '</button>';
    else act = '<span class="locked">' + esc(itemSource(it)) + '</span>';
    return '<article class="item' + (own ? " own" : "") + (on ? " on" : "") + (it.rar ? " rr-" + it.rar : "") + '">' + (deal && !own ? '<span class="tile-off">Today &minus;' + deal.off + '%</span>' : "") + itemPreview(it) + '<div class="it-txt"><b>' + esc(it.name) + '</b>' + (it.tag ? '<em>' + esc(it.tag) + '</em>' : "") + rarChip(it.rar) + (it.trait ? '<small class="it-trait">' + esc(it.trait) + ' trait</small>' : "") + '</div><div class="it-act">' + act + '</div></article>';
  }
  // the real thing stays a holder's: a Shade is a look, a Shadow is the NFT you play as
  // the holder's own Shadow and its aura, for Halo previews (null without one)
  function myShadowLook() {
    var h = P.holder && P.holder(), list = h && h.shadows || [];
    if (!list.length) return null;
    var cur = P.avatar && P.avatar(), x = list.filter(function (y) { return String(y.n) === String(cur); })[0] || list[0];
    var a = { "electric cyan": "cyan", "crimson glow": "crimson", "lightning aura": "lightning", "money aura": "money", "btc aura": "btc" }[String(x.aura || "").toLowerCase()] || "none";
    return { img: x.img || "assets/art/masks/unbound.svg" + AV, aura: a, n: x.n };
  }
  function haloNote() {
    var sh = myShadowLook();
    return '<section class="skin-real' + (sh ? " held" : "") + '"><div><span class="of-k">' + (sh ? "Shadow #" + esc(sh.n) + ", verified" : "For Shadow holders") + '</span><p>' +
      (sh ? "Your Shadow already glows in its own aura colour everywhere it shows, with a ✓ seal. A Halo adds a frame around it." :
        "Halos frame a holder's own Shytoshi Shadow, next to the aura glow every verified Shadow gets. Hold a Shadow and connect your wallet to unlock them.") + '</p></div>' +
      (sh ? "" : '<a class="btn btn-red btn-sm" href="/nfts" data-close>Mint a Shadow</a>') + '</section>';
  }
  function skinNote() {
    var h = P.holder && P.holder(), mine = h && h.shadows && h.shadows.length;
    return '<section class="skin-real' + (mine ? " held" : "") + '"><div><span class="of-k">' + (mine ? "You hold a Shadow" : "Want the real one?") + '</span><p>' +
      (mine ? "You play as your own verified Shadow, with its aura as your victory effect. Shades are for players without one, so you don't need a skin." :
        "A Shade is a look. A <b>Shytoshi Shadow</b> is the NFT on Solana: hold one and you play as it, verified, with its number, its record and its aura as your victory effect.") + '</p></div>' +
      (mine ? "" : '<a class="btn btn-red btn-sm" href="/nfts" data-close>Mint a Shadow</a>') + '</section>';
  }
  function viewStyle() {
    var list = cat.items.filter(function (x) { return x.slot === sub && (!x.dev || owned(x.id)); });   //MC 2026-10-12 the Dev collection only shows to its owner
    list.sort(function (x, y) { return (owned(y.id) - owned(x.id)) || ((x.koban || 1e9) - (y.koban || 1e9)); });
    var def = sub === "back" ? '<article class="item' + (!acc || !acc.eq.back ? " on own" : " own") + '"><div class="pv pv-back">' + cardBack("ink", "a") + cardBack("ink", "b") + cardBack("ink", "c") + '</div><div class="it-txt"><b>Ink Seal</b></div><div class="it-act">' + (!acc || !acc.eq.back ? '<span class="owned">Equipped</span>' : '<button class="btn btn-mint btn-sm" data-equip="back:">Equip</button>') + '</div></article>' :
      sub === "halo" && myShadowLook() ? '<article class="item' + (!acc || !acc.eq.halo ? " on own" : " own") + '"><div class="pv pv-halo"><span class="av-aura au-' + myShadowLook().aura + '"><img src="' + esc(myShadowLook().img) + '" alt="" loading="lazy"></span></div><div class="it-txt"><b>Aura glow only</b></div><div class="it-act">' + (!acc || !acc.eq.halo ? '<span class="owned">Equipped</span>' : '<button class="btn btn-mint btn-sm" data-equip="halo:">Equip</button>') + '</div></article>' :
      sub === "skin" ? '<article class="item' + (!acc || !acc.eq.skin ? " on own" : " own") + '"><div class="pv pv-skin"><img src="assets/art/masks/unbound.svg' + AV + '" alt="" loading="lazy"></div><div class="it-txt"><b>Unbound</b></div><div class="it-act">' + (!acc || !acc.eq.skin ? '<span class="owned">Equipped</span>' : '<button class="btn btn-mint btn-sm" data-equip="skin:">Equip</button>') + '</div></article>' :
      MAP_DEF[sub] ? '<article class="item' + (!acc || !acc.eq[sub] ? " on own" : " own") + '"><div class="pv pv-map"><img src="assets/art/map/' + sub + '_default.jpg' + AV + '" alt="" loading="lazy"></div><div class="it-txt"><b>' + MAP_DEF[sub] + '</b></div><div class="it-act">' + (!acc || !acc.eq[sub] ? '<span class="owned">Equipped</span>' : '<button class="btn btn-mint btn-sm" data-equip="' + sub + ':">Equip</button>') + '</div></article>' :
      sub === "share" ? '<article class="item' + (!acc || !acc.eq.share ? " on own" : " own") + '"><div class="pv pv-share"><img src="assets/art/share/default.jpg' + AV + '" alt="" loading="lazy"></div><div class="it-txt"><b>Dojo Dusk</b></div><div class="it-act">' + (!acc || !acc.eq.share ? '<span class="owned">Equipped</span>' : '<button class="btn btn-mint btn-sm" data-equip="share:">Equip</button>') + '</div></article>' : "";
    return hallHead("The Forge &middot; style", "Style", "Change how you look at the table, on the leaderboards and on everything you share. Equip anything you own, any time.") +
      '<nav class="sh-sub">' + Object.keys(SLOTS).map(function (k) { return '<button data-sub="' + k + '"' + (k === sub ? ' class="on"' : "") + '>' + SLOTS[k] + '</button>'; }).join("") + '</nav>' +
      '<p class="sh-lead small">' + SLOT_LEAD[sub] + '</p>' + (sub === "skin" ? skinNote() : sub === "halo" ? haloNote() : "") +
      (function () {
        // the free default look (Ink Seal, Unbound...) stays first, then the items, six to a page
        var all = (def ? [def] : []).concat(list.map(itemCard)), k = "sh-style";
        if (PG.styleSub !== sub) { PG.styleSub = sub; PG[k] = 1; }
        var p = pageOf(k, all);
        return '<div class="sh-grid items' + (sub === "share" || MAP_DEF[sub] ? " wide" : "") + '">' + p.items.join("") + '</div>' + pager(k, p);
      })();
  }

  // ---------- Boosts ----------
  function viewBoosts() {
    var a = acc || { boostXp: 0, saver: 0, scroll: { xp: 0, prem: false, plus: false }, rr: { banked: 0, free: false }, missions: [] };
    var xpOn = a.boostXp > now(), tier = Math.floor(a.scroll.xp / cat.tierXp);
    var bOpen = (a.missions || []).some(function (m) { return m.bounty && !m.locked; });
    var card = function (id, art, status, act) {
      var g = goodById(id); if (!g) return "";
      return '<article class="boost b-' + id + '"><div class="bo-art" aria-hidden="true">' + art + '</div><div class="bo-t"><b>' + esc(g.name) + '</b>' + (g.tag ? '<em>' + esc(g.tag) + '</em>' : "") + '<p>' + esc(g.desc) + '</p>' + (status ? '<small class="bo-st">' + status + '</small>' : "") + '</div><div class="bo-act">' + act + '</div></article>';
    };
    var buy = function (id, block) { var g = goodById(id); return block ? '<span class="owned">' + block + '</span>' : '<button class="btn btn-red btn-sm' + shortCls(g.koban) + '" data-buy="' + id + '">' + koban(g.koban) + '</button>'; };
    //MC 2026-10-10 boosts in two groups, by what they speed up
    var h = hallHead("The Forge &middot; boosts", "Boosts", "Boosts speed up your Season Scroll, your missions and your streak. They never touch a game's cards or score.");
    h += '<h4 class="sh-h">For the Season Scroll</h4><div class="bo-grid">';
    h += card("xp7", '<i>+' + cat.xpBoost + '%</i><small>XP</small>', xpOn ? 'Running: <span data-count="' + a.boostXp + '">' + left(a.boostXp) + '</span> left. Buying adds 7 days.' : "", buy("xp7"));
    h += card("xp3", '<i>+' + cat.xpBoost + '%</i><small>XP</small>', xpOn ? 'Running: <span data-count="' + a.boostXp + '">' + left(a.boostXp) + '</span> left. Buying adds 3 days.' : "", buy("xp3"));
    h += card("skip", '<i>+1</i><small>Tier</small>', 'You\'re on tier ' + Math.min(tier, cat.tiers) + ' of ' + cat.tiers + '.', buy("skip", tier >= cat.tiers ? "Scroll complete" : ""));
    h += '</div><h4 class="sh-h">For missions and your streak</h4><div class="bo-grid">';
    h += card("bounty", '<i>2x</i><small>Bounty</small>', bOpen ? "Open this week. Your bounties are in Missions." : a.scroll.plus ? "Free with your Scroll+, opens every Monday." : "Pays back up to " + fmt(cat.bountyKoban * 2) + " Koban.", bOpen ? '<button class="btn btn-line btn-sm" data-tab="missions">See bounties</button>' : buy("bounty"));
    h += card("reroll", '<i>⟳</i><small>Mission</small>', a.rr.free ? "Your free weekly reroll is ready." : a.rr.banked ? a.rr.banked + " banked " + (a.rr.banked === 1 ? "reroll" : "rerolls") + " ready." : "", '<button class="btn btn-line btn-sm" data-tab="missions">Pick a mission</button>');
    h += card("saver", '<i>' + (a.saver || 0) + '</i><small>Held</small>', a.saver ? "You hold " + a.saver + " of 2." : "", buy("saver", a.saver >= 2 ? "2 of 2 held" : ""));
    return h + '</div>';
  }

  // ---------- Daily X tasks ----------
  var XT_TEXT = {
    shill: "Playing Shilluminati Online, the free card game from Shy on Solana. Come take the world off me. $SHY https://shyonsol.io/play?v=w3", //MC 2026-10-13 ?v=w3: the bare /play link made every X task post unfurl with a preview X cached weeks ago
    tag: "@ShyOnSol_ who's taking me on in Shilluminati Online? Looking at you, @",
    hash: "Ruling the world one Chaos card at a time. #Shilluminati $SHY https://shyonsol.io/play?v=w3"
  };
  function xIcon() { return window.ShyX && window.ShyX.icon ? window.ShyX.icon : "X"; }
  function xtState() { return acc && acc.xt && acc.xt.on ? acc.xt : null; }
  function openOut(url) { var W = window.Telegram && window.Telegram.WebApp; if (W && W.openLink && W.initData) W.openLink(url); else open(url, "_blank", "noopener"); }
  // the strip on the Today tab
  function xtStrip() {
    var x = xtState();
    if (!x) return "";
    var n = x.tasks.filter(function (t) { return t.done; }).length, max = x.tasks.reduce(function (s, t) { return s + t.koban; }, 0) + x.bonus;
    return '<button class="xt-strip' + (n === x.tasks.length ? " done" : "") + '" data-tab="x"><span class="xt-ic" aria-hidden="true">' + xIcon() + '</span><span class="xt-st"><span class="of-k">Daily X tasks</span><b>' +
      (n === x.tasks.length ? "All done today. New ones in <span data-count=\"" + x.ends + "\">" + left(x.ends) + "</span>" : n + " of " + x.tasks.length + " done &middot; up to " + koban(max) + " a day") + '</b></span><span class="xt-go" aria-hidden="true">&rsaquo;</span></button>';
  }
  function xtSection() {
    var x = xtState();
    if (!x) return "";
    var n = x.tasks.filter(function (t) { return t.done; }).length;
    var h = '<section class="xt"><div class="xt-hd"><span class="xt-ic big" aria-hidden="true">' + xIcon() + '</span><div><span class="of-k">Daily X tasks &middot; ' + n + ' / ' + x.tasks.length + '</span>' +
      '<h3>Post on X, paste the link, get Koban</h3><p>Each task pays ' + koban(x.tasks[0].koban) + ' and ' + x.tasks[0].xp + ' Scroll XP. Do all three for ' + (x.bonusPaid ? "a bonus, paid today." : koban(x.bonus) + " more.") +
      ' New tasks in <span data-count="' + x.ends + '">' + left(x.ends) + '</span>.</p></div></div><ul class="ms-list xt-list">';
    h += x.tasks.map(function (t) {
      var act = t.done ? '<a class="xt-seen" href="' + esc(t.url) + '" target="_blank" rel="noopener">See post</a>'
        : t.id === "result" ? '<button class="btn btn-line btn-sm" data-close data-play="quick">Play a game</button>'
        : t.id === "daily" ? '<button class="btn btn-line btn-sm" data-close data-play="daily">Play the Daily</button>'
        : '<button class="btn btn-line btn-sm" data-xt-post="' + esc(t.id) + '">Write the post</button>';
      return '<li class="' + (t.done ? "done" : "") + '"><span class="ms-ck" aria-hidden="true"></span><div class="ms-t"><b>' + esc(t.text) + '</b><small>' + (t.done ? "Done, Koban paid" : esc(t.how)) + '</small>' +
        '</div><div class="xt-r">' + koban(t.koban, t.done ? "paid" : "") + act + '</div>' +
        (t.done ? "" : '<div class="xt-in"><input type="url" inputmode="url" autocomplete="off" placeholder="Then paste the link to your post" aria-label="Link to your post for ' + esc(t.text) + '" data-xt-url="' + esc(t.id) + '"><button class="btn btn-mint btn-sm" data-xt-check="' + esc(t.id) + '">Check</button></div>') + '</li>';
    }).join("");
    // with X connected, posting from the end screen counts the result task without pasting anything
    var xs = P.xState ? P.xState() : null, auto = x.tasks.some(function (t) { return !t.done && (t.id === "result" || t.id === "daily"); });
    h += '</ul>';
    if (auto && xs && xs.on) h += '<p class="xt-auto">' + (xs.user ? '<span>Tip: press <b>Post to X</b> on the end screen and the result task counts by itself, no link needed.</span>' : '<span>Skip the pasting: connect X on your profile, then <b>Post to X</b> from the end screen counts the result task by itself.</span> <a href="/profile#pf-x">Connect X</a>') + '</p>';
    h += '<p class="xt-note">' + (x.handle ? "Counts posts from <b>@" + esc(x.handle) + "</b>, made today (UTC), each post once." : "Posts must be public and made today (UTC), and each counts once. Your first counted post ties your X account to this profile.") + '</p></section>';
    return h;
  }
  function viewX() {
    var x = xtState();
    return xtSection() + '<div class="xt-how"><h4 class="sh-h">How it works</h4><ol><li>Pick a task and post it on X from your own account. <b>Write the post</b> fills in a draft you can change.</li>' +
      '<li>Copy the link to your post: tap Share on the post, then Copy link.</li><li>Paste it under the task and tap <b>Check</b>. Koban and Scroll XP land straight away.</li></ol>' +
      //MC 2026-10-11 the handle in its own element: inside the sentence it made a new dictionary key per player, so the rules stayed English
      '<p>Posts have to be public, made today (UTC) and from ' + (x && x.handle ? '<span data-i18n-skip>@' + esc(x.handle) + '</span>' : "the same X account every day") + '. Holders earn double. Koban for a deleted post can be taken back.</p></div>';
  }
  // the nudge under Share on X on the end screen
  function xtNudge(daily) {
    var x = xtState();
    if (!x) return "";
    var open_ = x.tasks.filter(function (k) { return !k.done && (k.id === "result" || (daily && k.id === "daily")); });
    var t = open_.filter(function (k) { return k.id === "daily"; })[0] || open_[0];
    if (!t) return "";
    return '<span class="xt-ic" aria-hidden="true">' + xIcon() + '</span><span>Share this on X, then paste the link in the Dojo for ' + koban(t.koban) + (x.bonusPaid ? "" : " toward today's bonus") + '.</span><button class="btn btn-mint btn-sm" data-shop="x">X Tasks</button>';
  }
  E.xtNudge = xtNudge;
  async function xtCheck(id) {
    var inp = shopEl.querySelector('[data-xt-url="' + id + '"]'), btn = shopEl.querySelector('[data-xt-check="' + id + '"]');
    var url = inp ? inp.value.trim() : "";
    if (!url) { P.toast("Paste the link to your post first."); if (inp) inp.focus(); return; }
    // the answer is also written under the box, so it's seen even if a toast is missed
    var li = btn && btn.closest("li"), say = function (txt, ok) {
      if (!li) return;
      var m = li.querySelector(".xt-msg"); if (!m) { m = document.createElement("p"); m.className = "xt-msg"; m.setAttribute("role", "status"); li.appendChild(m); }
      m.textContent = txt; m.classList.toggle("ok", !!ok);
    };
    say("Checking your post on X…", true);
    busy = true; if (btn) { btn.disabled = true; btn.textContent = "Checking…"; }
    var j = await api({ a: "xtask", task: id, url: url });
    busy = false;
    if (!j.ok) say(j.error || "Couldn't check that post. Try again.");
    if (j.ok) {
      P.sfx("badge"); fx("money");
      P.toast("Counted. +" + fmt(j.koban) + " Koban and " + j.xp + " Scroll XP" + (j.bonus ? ", including the all-three bonus." : "."));
      setAcc(j.me);
    } else {
      if (btn) { btn.disabled = false; btn.textContent = "Check"; }
      P.toast(esc(j.error || "Couldn't check that post. Try again."));
    }
  }

  // ---------- Missions ----------
  function viewMissions() {
    var a = acc || { streak: { n: 0, d: "" }, saver: 0, rr: { banked: 0, free: false } }, g = goodById("saver");
    var today = new Date(now() * 1000).toISOString().slice(0, 10), alive = streakAlive(a), played = a.streak.d === today;
    var pays = [10, 15, 20, 25, 30, 40, 60], n = alive ? a.streak.n : 0;
    var cyc = n ? ((n - 1) % 7) + 1 : 0, gotN = played ? cyc : (cyc === 7 ? 0 : cyc), nextD = played ? 0 : gotN + 1;
    var h = xtStrip() + '<section class="ms-streak"><div class="ms-flame" aria-hidden="true"></div><div class="ms-st"><span class="of-k">Daily streak</span><h3>' + (n ? n + (n === 1 ? " day" : " days") : "No streak yet") + '</h3>' +
      '<p>Finish one game a day, any mode, to keep it going. Each day pays more Koban, up to ' + koban(60) + ' on day 7, then the week starts over. It ends at midnight UTC.</p>' +
      '<ol class="ms-days">' + pays.map(function (p, i) { var d = i + 1; return '<li class="' + (d <= gotN ? "got" : d === nextD ? "nx" : "") + '"><small>Day ' + d + '</small>' + koban(p) + '</li>'; }).join("") + '</ol></div>';
    if (g) {
      var full = a.saver >= g.max;
      h += '<div class="ms-saver"><span class="ms-shield" aria-hidden="true">' + (a.saver || 0) + '</span><div><b>' + esc(g.name) + '</b><small>' + esc(g.desc) + '</small></div>' +
        (full ? '<span class="owned">' + g.max + ' of ' + g.max + ' held</span>' : '<button class="btn btn-red btn-sm' + shortCls(g.koban) + '" data-buy="saver">' + koban(g.koban) + '</button>') + '</div>';
    }
    h += '</section>';
    var all = acc && acc.missions ? acc.missions : missionsState(), ms = all.filter(function (m) { return !m.bounty; }), bs = all.filter(function (m) { return m.bounty; });
    var rrLabel = a.rr.free ? "Free" : a.rr.banked ? "Banked" : fmt((goodById("reroll") || {}).koban || 80);
    h += '<div class="ms-head"><h4 class="sh-h">This week\'s missions</h4><small>New ones in <span data-count="' + cat.weekEnd + '">' + left(cat.weekEnd) + '</span></small></div><ul class="ms-list">' + ms.map(function (m, i) {
      return '<li class="' + (m.done ? "done" : "") + '"><span class="ms-ck" aria-hidden="true"></span><div class="ms-t"><b>' + esc(m.text) + '</b><span class="dj-bar big"><i style="width:' + Math.round(Math.min(m.n, m.goal) / m.goal * 100) + '%"></i></span><small>' + (m.done ? "Done, Koban paid" : fmt(Math.min(m.n, m.goal)) + " / " + fmt(m.goal)) + '</small></div>' + koban(m.koban, m.done ? "paid" : "") +
        (m.done || !acc ? "" : '<button class="ms-rr" data-reroll="' + i + '" title="Swap this mission for another">⟳ <small>' + (a.rr.free || a.rr.banked ? rrLabel : koban(+rrLabel.replace(/,/g, ""))) + '</small></button>') + '</li>';
    }).join("") + '</ul>';
    var bOpen = bs.length && !bs[0].locked;
    h += '<section class="bounty' + (bOpen ? " open" : "") + '"><div class="bo-hd"><span class="of-k">Bounty Board</span><h3>' + (bOpen ? "Two hard bounties this week" : "Two hard bounties, " + fmt(cat.bountyKoban) + " Koban each") + '</h3><p>Each pays ' + koban(cat.bountyKoban) + ' and a Scroll tier. They reset with the week.' + (acc && acc.scroll.plus ? " Free every week with your Scroll+." : " Free every week with Scroll+.") + '</p>' +
      (bOpen || !acc ? "" : '<button class="btn btn-red btn-sm' + shortCls((goodById("bounty") || {}).koban || 200) + '" data-buy="bounty">Open the board ' + koban((goodById("bounty") || {}).koban || 200) + '</button>') + '</div>' +
      '<ul class="ms-list">' + bs.map(function (m) {
        return '<li class="' + (m.done ? "done" : "") + (bOpen ? "" : " lockd") + '"><span class="ms-ck" aria-hidden="true"></span><div class="ms-t"><b>' + esc(m.text) + '</b><span class="dj-bar big"><i style="width:' + Math.round(Math.min(m.n, m.goal) / m.goal * 100) + '%"></i></span><small>' + (m.done ? "Done, paid" : bOpen ? fmt(Math.min(m.n, m.goal)) + " / " + fmt(m.goal) : "Locked") + '</small></div>' + koban(m.koban, m.done ? "paid" : "") + '</li>';
      }).join("") + '</ul></section>';
    h += '<p class="sh-lead small">Every finished, verified game counts: solo, the Daily and live matches. Koban lands the moment a mission is done.</p>';
    return h;
  }

  // ---------- Koban ----------
  function coinArt(n) {
    var c = Math.min(6, n), out = "";
    for (var i = 0; i < c; i++) out += '<i style="--i:' + i + '"></i>';
    return '<div class="pk-art c' + c + '">' + out + '</div>';
  }
  function viewKoban() {
    var moon = cat.offers.filter(function (o) { return o.id === "moon"; })[0];
    var base = cat.packs[0].koban / cat.packs[0].usd;
    //MC 2026-10-10 Buy Koban is the Mint's front room: the packs first, then every offer paid in money (they used to sit
    //   at the bottom of Today), then the prize pool note and what Koban are
    //MC 2026-10-13 the top-up nudge names the smallest pack that covers the shortfall (first-buy doubling counted), with
    //   its own buy button right in the banner, and that pack is ringed in the grid below. Free Koban stays one tap away.
    var cover = null;
    if (needK) for (var ci = 0; ci < cat.packs.length; ci++) {
      var cp = cat.packs[ci], cTot = (cp.koban + cp.bonus) * (acc && acc.fp.indexOf(cp.id) < 0 ? 2 : 1);
      if (cTot >= needK) { cover = { id: cp.id, name: cp.name, usd: cp.usd, total: cTot }; break; }
    }
    var h = needK ? '<div class="sh-need" role="status"><span class="sh-need-ic" aria-hidden="true">!</span><div><b>You need ' + fmt(needK) + ' more Koban for that.</b><small>' +
      (cover ? 'The ' + esc(cover.name) + ' covers it: ' + fmt(cover.total) + ' Koban.' : 'Pick a pack below, or collect some for free.') + '</small></div>' +
      (cover ? '<button class="btn btn-red btn-sm" data-pay="' + cover.id + '">' + usd(cover.usd) + '</button>' : "") +   //MC 2026-10-13 the short price; the pack card below carries the full $SHY tag
      '<button class="btn btn-line btn-sm" data-tab="free">Free Koban</button></div>' : "";
    h += hallHead("The Mint", "Buy Koban", "");
    h += '<p class="sh-lead">Koban buy card finishes, cosmetics, boosts and the Season Scroll. <b>The first time you buy each pack, it\'s double.</b> Pay with <b>$SHY for +' + myShyBonus() + '% more</b>, or with SOL, USDC or card.</p>';
    h += '<div class="sh-grid packs">' + cat.packs.map(function (p, i) {
      var total = p.koban + p.bonus, first = acc && acc.fp.indexOf(p.id) < 0, more = Math.round((total / p.usd / base - 1) * 100);
      var isCover = cover && cover.id === p.id;   //MC 2026-10-13 the badge outranks the pack's usual tag while the nudge is up
      return '<article class="pack' + (p.tag ? " tagged" : "") + (first ? " first" : "") + (isCover ? " covers" : "") + '">' + (isCover ? '<span class="pk-cover">Covers it</span>' : first ? '<span class="pk-first">First buy: double</span>' : p.tag ? '<span class="pk-tag">' + esc(p.tag) + '</span>' : "") + coinArt(i + 1) +
        '<b class="pk-n">' + (first ? '<s class="was">' + fmt(total) + '</s>' + koban(total * 2) : koban(total)) + '</b>' + (more > 0 ? '<small class="pk-bonus">+' + more + '% Koban per $</small>' : '<small class="pk-bonus">&nbsp;</small>') +
        '<span class="pk-name">' + esc(p.name) + '</span><small class="pk-shy">' + fmt(Math.round(total * (first ? 2 : 1) * (100 + myShyBonus()) / 100)) + ' with $SHY</small>' +
        '<button class="btn btn-red" data-pay="' + p.id + '">' + shyTag(p.usd) + '</button></article>';
    }).join("") + '</div>';
    // offers that cost money
    var offs = cat.offers.filter(function (o) { return o.id !== "scrollplus" && o.id !== "plusup" && o.id !== "moon" && !(o.id === "scroll" && acc && acc.scroll.prem) && !(o.once && acc && acc.once.indexOf(o.id) >= 0); });
    var founder = offs.filter(function (o) { return o.id === "founder"; })[0];
    h += '<div class="sh-hd"><h4 class="sh-h">Offers</h4><small>More than Koban: items, the Season Scroll and daily Koban for a month.</small></div>';
    var rjo = offs.filter(function (o) { return o.id === "raijin"; })[0];   //MC 2026-10-16
    if (rjo) h += offerCard(rjo, true);
    if (moon) h += offerCard(moon, true);
    if (founder) h += offerCard(founder, true);
    var rest = offs.filter(function (o) { return o.id !== "founder" && o.id !== "raijin"; });
    if (rest.length) h += '<div class="sh-grid two">' + rest.map(function (o) { return offerCard(o); }).join("") + '</div>';
    h += '<div class="mint-foot"><section class="pool-note"><span class="of-k">Every purchase grows the prize pool</span><h3>' + shyPool(cat.pool.usd) + ' <small>so far this week</small></h3><p>' + cat.pool.pct + '% of this week\'s shop sales go into next week\'s Weekly League prize pool, paid in $SHY.</p><a href="#rewards" data-close>See the League</a></section>' +
      '<div class="kb-about"><p class="kb-why"><b>Koban</b> were the oval gold coins of old Japan, the money of the shoguns. In the Dojo they\'re the game\'s own coin: earned by playing, or bought here. They stay in the game and can\'t be cashed out.</p>' +
      '<p class="sh-lead small"><a class="sh-buyshy" href="/swap">Need $SHY? Buy it here →</a></p></div></div>';   //MC 2026-10-09 link in its own <p> so the intro keeps its dictionary key
    return h;
  }

  // ---------- Scroll ----------
  function rewardChip(r) {
    if (!r) return '<span class="sc-r empty"></span>';
    if (r.koban) return '<span class="sc-r">' + koban(r.koban) + '</span>';
    if (r.fin) return '<span class="sc-r fin" title="' + esc(rewardText(r)) + '">' + finArt(r.fin[0], r.fin[1], "chip") + '<em>' + esc(cat.finishes[r.fin[1]].name) + '</em></span>';
    if (r.boost) return '<span class="sc-r it" title="' + esc(rewardText(r)) + '"><i class="sc-ic s-boost"></i>' + esc(rewardText(r)) + '</span>';
    var it = itemById(r.item);
    return '<span class="sc-r it" title="' + esc(it ? it.name : "") + '"><i class="sc-ic s-' + (it ? it.slot : "") + '"></i>' + esc(it ? it.name : "") + '</span>';
  }
  function viewScroll() {
    var a = acc || { scroll: { xp: 0, prem: false, plus: false, cf: [], cp: [] }, boostXp: 0 };
    var tier = Math.floor(a.scroll.xp / cat.tierXp), into = a.scroll.xp % cat.tierXp;
    var plus = cat.offers.filter(function (o) { return o.id === "scrollplus"; })[0], base = cat.offers.filter(function (o) { return o.id === "scroll"; })[0], up = cat.offers.filter(function (o) { return o.id === "plusup"; })[0];
    var sc = cat.seasonCards.slice(0, 6);
    var h = '<div class="sc-head"><div><span class="of-k">Season ' + cat.season.n + ' &middot; ends in <span data-count="' + cat.season.end + '">' + left(cat.season.end) + '</span></span>' +
      '<h3>Season Scroll</h3><p>Every verified game earns XP: solo 10, Daily 40, live 50, more for a win, plus a bonus for your first game each day.' + (a.boostXp > now() ? ' <b>Your XP Boost adds ' + cat.xpBoost + '% for another <span data-count="' + a.boostXp + '">' + left(a.boostXp) + '</span>.</b>' : "") + ' The premium track pays out every tier.</p></div>' +
      '<div class="sc-prog"><b>Tier ' + Math.min(tier, cat.tiers) + '<small> / ' + cat.tiers + '</small></b><span class="dj-bar big"><i style="width:' + (tier >= cat.tiers ? 100 : into / cat.tierXp * 100) + '%"></i></span><small>' + (tier >= cat.tiers ? "Complete" : (cat.tierXp - into) + " XP to tier " + (tier + 1)) + '</small>' +
      (scrollClaimable() ? '<button class="btn btn-mint" data-claim="scroll">Collect ' + scrollClaimable() + (scrollClaimable() === 1 ? " reward" : " rewards") + '</button>' : "") + '</div></div>';
    h += '<div class="sc-show"><span class="of-k">This season in Shadow Ink, premium track only</span><div class="sc-fan">' + sc.map(function (c, i) { return '<span class="bd-c" style="--i:' + i + '" title="' + esc(cardName(c)) + '">' + finArt(c, "shadow") + '</span>'; }).join("") + '</div></div>';
    //MC 2026-10-13 from tier 3 the pitch turns personal: it counts the premium rewards the player has already passed,
    //   which all pay out the moment the Scroll is theirs. Before tier 3 the quiet generic line stays.
    if (!a.scroll.prem && base) {
      var missed = 0, missedK = 0;
      for (var mt = 1; mt <= Math.min(tier, cat.tiers); mt++) { var mr = cat.scroll[mt] && cat.scroll[mt][1]; if (mr) { missed++; if (mr.koban) missedK += mr.koban; } }
      var push = tier >= 3 && missed >= 2;   // the personal pitch needs a count worth the plural it speaks in
      var pitch = push
        ? '<b>' + missed + ' premium rewards are already waiting for you</b><small>You reached tier ' + Math.min(tier, cat.tiers) + ' on the free track. Unlock the Scroll and all ' + missed + ' pay out instantly' + (missedK ? ', ' + fmt(missedK) + ' Koban among them' : '') + ', plus a free Mission Reroll every week.</small>'
        : '<b>Unlock the premium track</b><small>Retroactive: everything you already reached pays out. Scroll owners also get a free Mission Reroll every week.</small>';
      h += '<div class="sc-up' + (push ? " push" : "") + '"><div>' + pitch + '</div><div class="sc-up-btns"><button class="btn btn-red" data-pay="scroll">' + shyTag(base.usd) + '</button><button class="btn btn-line' + shortCls(base.koban_price) + '" data-buy="scroll">' + koban(base.koban_price) + '</button>' + (plus ? '<button class="btn btn-gold" data-pay="scrollplus">Scroll+ ' + usd(plus.usd) + '</button>' : "") + '</div></div>';
    }
    else if (a.scroll.prem && !a.scroll.plus && up) h += '<div class="sc-up"><div><b>Upgrade to Scroll+</b><small>' + esc(up.desc) + '</small></div><div class="sc-up-btns"><button class="btn btn-gold" data-pay="plusup">' + shyTag(up.usd) + '</button></div></div>';
    h += '<div class="sc-track" id="sc-track"><div class="sc-rows"><span class="sc-lab">Free</span><span class="sc-lab prem">Premium' + (a.scroll.prem ? "" : " \u{1F512}") + '</span></div>';
    for (var t = 1; t <= cat.tiers; t++) {
      var r = cat.scroll[t], reached = tier >= t;
      var gotF = a.scroll.cf.indexOf(t) >= 0, gotP = a.scroll.cp.indexOf(t) >= 0;
      h += '<div class="sc-col' + (reached ? " reached" : "") + (t === tier + 1 ? " sc-next" : "") + '"><span class="sc-t">' + t + '</span>' +
        '<div class="sc-cell' + (gotF ? " got" : "") + '">' + rewardChip(r[0]) + '</div><div class="sc-cell prem' + (gotP ? " got" : "") + (a.scroll.prem ? "" : " locked") + '">' + rewardChip(r[1]) + '</div></div>';
    }
    return h + '</div>';
  }

  // ---------- purchase history and Koban activity ----------
  var ORDER_ST = {
    paid: ["ok", "Delivered", ""],
    open: ["wait", "Confirming", "Waiting for Solana to confirm the payment."],
    unpaid: ["mute", "Not paid", "No payment was sent for this order."],
    expired: ["mute", "Expired", "This price hold ran out before a payment arrived."],
    self: ["wait", "Checking", "Paid from the marketing wallet. Checking the transfer on Solana."],
    nopay: ["bad", "Not delivered", "That transaction went through but sent nothing to the marketing wallet. Contact us with the order number."],
    failed: ["bad", "Failed on Solana", "The payment failed on Solana, so nothing was taken except the network fee."],
    dropped: ["mute", "Didn't go through", "Solana never confirmed this payment, so nothing left your wallet. Buy again to try once more."],
    short: ["bad", "Underpaid", "The payment was less than the price. Contact us with the order number."]
  };
  function when(ts) { var d = new Date(ts * 1000), L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined; return d.toLocaleDateString(L, { month: "short", day: "numeric" }) + ", " + d.toLocaleTimeString(L, { hour: "numeric", minute: "2-digit" }); }
  //MC 2026-10-11 amounts read like money: whole $SHY (243,821.138 showed three decimals), USDC to the cent, SOL to 4 places
  function orderAmt(o) {
    var n = +o.amount, d = o.cur === "SOL" ? 4 : o.cur === "USDC" ? 2 : n >= 100 ? 0 : 2;
    return n.toLocaleString("en-US", { maximumFractionDigits: d }) + " " + (o.cur === "SHY" ? "$SHY" : esc(o.cur));
  }
  //MC 2026-10-11 a checkout you pressed Continue on but never paid: once its 20 minute price hold is over it's left out
  // of Purchases (it was one NOT PAID card per quote) and counted in one line. A late payment still turns it into Delivered.
  function abandoned(o) { return o.status === "open" && !o.sig && now() - o.ts > 20 * 60; }
  function orderRow(o) {
    var st = o.status === "open" && !o.sig ? "unpaid" : o.status;
    if (st === "expired" && !o.sig) st = "unpaid";
    var m = ORDER_ST[st] || ORDER_ST.open, tx = o.proof && !/^(cs_|manual)/.test(o.proof) ? o.proof : o.sig;
    var price = o.cur === "CARD" ? usd(o.usd) + " by card" : (o.amount ? orderAmt(o) : "") + ' <small>' + usd(o.usd) + '</small>';
    return '<li class="hi-o st-' + m[0] + '"><div class="hi-top"><b>' + esc(o.name) + '</b><span class="hi-pill">' + m[1] + '</span></div>' +
      '<div class="hi-meta"><span>' + price + '</span><span>' + when(o.paid || o.ts) + '</span><span class="hi-id">#' + esc(o.id) + '</span></div>' +
      (o.status === "paid" && o.got && o.got.length ? '<p class="hi-got">' + esc(o.got.join(", ")) + '</p>' : m[2] ? '<p class="hi-note">' + m[2] + '</p>' : "") +
      '<div class="hi-act">' + (tx ? '<a href="https://solscan.io/tx/' + esc(tx) + '" target="_blank" rel="noopener">View on Solscan</a>' : "") +
      (o.status !== "paid" && o.sig && ["expired", "nopay", "dropped"].indexOf(st) < 0 ? '<button class="btn btn-line btn-sm" data-recheck="' + esc(o.id) + '" data-sig="' + esc(o.sig) + '">Check again</button>' : "") + '</div></li>';
  }
  // payments still "confirming" after a few minutes get one fresh look on Solana when the history opens
  //MC 2026-10-11 it checked five, refreshed, and the redraw started the next five: one redraw per five stale orders.
  // Now all of them are checked once (five at a time) and the account is refreshed once at the end.
  var rechecked = {};
  async function autoRecheck() {
    if (!acc) return;
    var stale = (acc.orders || []).filter(function (o) { return ["open", "self", "dropped"].indexOf(o.status) >= 0 && !rechecked[o.id] && now() - o.ts > 240; });
    if (!stale.length) return;
    stale.forEach(function (o) { rechecked[o.id] = 1; });
    var paidNow = [];
    for (var i = 0; i < stale.length; i += 5) {
      var rs = await Promise.all(stale.slice(i, i + 5).map(function (o) { return api({ a: "check", order: o.id, sig: o.sig || "" }); }));
      rs.forEach(function (r) { if (r.ok && r.status === "paid") paidNow.push(r); });
    }
    if (paidNow.length) { P.sfx("badge"); P.toast("Payment found: " + esc((paidNow[0].got || []).join(", "))); }
    refreshMe();
  }
  // "I paid but nothing arrived": paste the payment and the server matches it to the order
  var phMsg = "";
  function payHelp(orders) {
    var open = (acc.orders || []).filter(function (o) { return o.status !== "paid" && o.cur !== "CARD" && now() - o.ts < 7 * 86400; });
    return '<details class="ph"' + (phMsg ? " open" : "") + '><summary><b>Paid, but nothing arrived?</b><small>Paste the payment from your wallet and we\'ll find it.</small></summary>' +
      '<form class="ph-form" id="ph-form"><label><span>Which order</span><select name="order"><option value="">Not sure</option>' + open.map(function (o) { return '<option value="' + esc(o.id) + '">' + esc(o.name) + ', ' + usd(o.usd) + ' #' + esc(o.id.slice(0, 6)) + '</option>'; }).join("") + '</select></label>' +
      '<label><span>The payment</span><input name="tx" required placeholder="Solscan link or transaction signature" autocomplete="off" spellcheck="false"></label>' +
      '<small class="ph-how">In Phantom: tap the payment in Recent Activity, then View on Solscan, and copy the link. In Solflare: tap the payment, then the explorer link.</small>' +
      '<label><span>Anything we should know <em>(optional)</em></span><input name="note" maxlength="300" placeholder="Paid from my other wallet, for example"></label>' +
      '<div class="ph-bar"><button class="btn btn-red btn-sm">Find my payment</button></div>' + (phMsg ? '<p class="ph-msg">' + phMsg + '</p>' : "") + '</form></details>';
  }
  async function payHelpSubmit(f) {
    var b = f.querySelector("button"); b.disabled = true; b.textContent = "Looking on Solana…";
    var j = await api({ a: "claim-tx", order: f.order.value, tx: f.tx.value, note: f.note.value });
    if (j.ok && j.status === "paid") { phMsg = ""; P.sfx("badge"); fx("money"); P.toast("Found your payment. " + esc((j.got || []).join(", "))); if (j.me) setAcc(j.me); renderShop(true); return; }
    phMsg = esc(j.ok ? j.msg : (j.error || "Couldn't check right now. Try again in a minute."));
    if (j.me) setAcc(j.me);
    renderShop(true);
  }
  function viewHistory() {
    if (!acc) return '<p class="sh-lead">Loading your history…</p>';
    setTimeout(autoRecheck, 50);
    var all = (acc.orders || []).filter(function (o) { return o.status === "paid" || o.sig || o.status === "open"; });
    var orders = all.filter(function (o) { return !abandoned(o); }), quiet = all.length - orders.length;
    var skipped = quiet ? '<p class="hi-empty hi-skip">' + (quiet === 1 ? "1 checkout you started but didn't pay is hidden. Nothing was taken from your wallet." : fmt(quiet) + " checkouts you started but didn't pay are hidden. Nothing was taken from your wallet.") + '</p>' : "";
    var h = linked() ? payHelp(orders) : "";
    var po = pageOf("sh-ord", orders);
    h += '<div class="hi-grid"><section data-hist-ord><h4 class="sh-h">Purchases</h4>' +
      (orders.length ? '<ul class="hi-list">' + po.items.map(orderRow).join("") + '</ul>' + pager("sh-ord", po) : '<p class="hi-empty">No purchases yet. Packs and bundles you buy show up here with a link to the payment on Solana.</p>') + skipped + '</section>';
    var led = acc.ledger || [], pl = pageOf("sh-led", led);
    h += '<section data-hist-led><h4 class="sh-h">Koban activity</h4>' + (led.length ? '<ul class="hi-led">' + pl.items.map(function (l) {
      return '<li><span>' + ledNote(l.w) + '<small data-i18n-skip>' + when(l.t) + '</small></span><b class="' + (l.n < 0 ? "neg" : "pos") + '">' + (l.n > 0 ? "+" : "") + fmt(l.n) + '</b></li>';
    }).join("") + '</ul>' + pager("sh-led", pl) : '<p class="hi-empty">Koban you earn and spend shows up here.</p>') + '</section></div>';
    if (linked()) h += '<p class="sh-lead small center"><a href="/profile">See your full profile, stats and every game →</a></p>';
    return h;
  }

  document.addEventListener("submit", function (e) {
    if (e.target.id !== "ph-form") return;
    e.preventDefault(); payHelpSubmit(e.target);
  });
  // paste a post link and it's checked straight away
  document.addEventListener("paste", function (e) {
    var el = e.target && e.target.matches && e.target.matches("[data-xt-url]") ? e.target : null;
    if (!el) return;
    setTimeout(function () { if (!busy && /(?:x|twitter)\.com\/\w+\/status(?:es)?\/\d+/i.test(el.value)) xtCheck(el.dataset.xtUrl); }, 0);
  });
  document.addEventListener("input", function (e) {
    if (!e.target.closest || !e.target.closest("#shop")) return;
    if (e.target.matches("[data-cq]")) { cf.q = e.target.value; PG["sh-cards"] = 1; var g = shopEl.querySelector(".cc-wrap"); if (g) g.innerHTML = ccGrid(); }
  });
  document.addEventListener("change", function (e) {
    if (!e.target.closest || !e.target.closest("#shop")) return;
    if (e.target.matches("[data-cown]")) { cf.own = e.target.checked; PG["sh-cards"] = 1; renderShop(true); }
    if (e.target.matches("[data-skind]")) { setKind = e.target.value; renderShop(true); }
    if (e.target.matches("[data-sfin]")) { setFin = e.target.value; renderShop(true); }
  });
  // ---------- shop clicks ----------
  function bought(j, msg) {
    P.sfx("badge"); P.buzz([12, 40, 12]); setAcc(j.me); P.toast(msg);
  }
  function failed(j, what) {
    //MC 2026-10-10 short on Koban: over to the Mint, which says how many are missing at the top
    if (j.need) { P.toast("You need " + fmt(j.need) + " more Koban."); tab = "koban"; cardOpen = ""; needK = j.need; renderShop(); var bd = shopEl.querySelector(".sh-body"); if (bd) bd.scrollTop = 0; }
    else { P.toast(esc(j.error || "Couldn't " + what + ".")); if (j.me) setAcc(j.me); else refreshMe().then(function () { renderShop(true); }); }
  }
  document.addEventListener("click", async function (e) {
    var t = e.target.closest("[data-shop]");
    if (t) { e.preventDefault(); openShop(t.dataset.shop); return; }
    if (!shopEl || shopEl.hidden || !e.target.closest("#shop")) return;
    if (e.target.closest("[data-cd-close]")) { cardOpen = ""; renderShop(true); return; }
    if (e.target.closest("[data-close]")) { closeShop(); return; }
    var b;
    if ((b = e.target.closest("[data-side]"))) { b = { dataset: { tab: lastTab[b.dataset.side] || "today" } }; }   //MC 2026-10-10 a hall opens on the tab you last had in it
    else b = e.target.closest("[data-tab]");
    if (b) { tab = b.dataset.tab; cardOpen = ""; renderShop(); shopEl.querySelector(".sh-body").scrollTop = 0; if (tab === "scroll") scrollToTier(); return; }
    if ((b = e.target.closest("[data-sub]"))) { sub = b.dataset.sub; renderShop(); return; }
    if ((b = e.target.closest("[data-ck]"))) { cf.kind = b.dataset.ck; PG["sh-cards"] = 1; renderShop(true); return; }
    if ((b = e.target.closest("[data-afin]"))) { cf.pv = cf.pv === b.dataset.afin ? "" : b.dataset.afin; PG["sh-cards"] = 1; renderShop(true); return; }
    var pg = window.ShyPager && ShyPager.hit(e, "sh-");
    if (pg) {
      PG[pg.key] = pg.page; renderShop(true);
      // bring the top of the list back into view inside the shop panel
      var top = shopEl.querySelector(pg.key === "sh-cards" ? ".cf-bar" : pg.key === "sh-style" ? ".sh-sub" : "[data-hist-" + pg.key.slice(3) + "]"), bd = shopEl.querySelector(".sh-body");
      if (top && bd) { var r = top.getBoundingClientRect(), br = bd.getBoundingClientRect(); if (r.top < br.top || r.top > br.top + br.height * .6) bd.scrollTop += r.top - br.top - 8; }
      return;
    }
    if ((b = e.target.closest("[data-card]"))) { cardOpen = b.dataset.card; renderShop(true); return; }
    if ((b = e.target.closest("[data-fx]"))) { fx(b.dataset.fx); return; }
    if ((b = e.target.closest("[data-recheck]"))) {
      b.disabled = true; b.textContent = "Checking…";
      var rc = await api({ a: "check", order: b.dataset.recheck, sig: b.dataset.sig });
      if (rc.ok && rc.status === "paid") { P.sfx("badge"); fx("money"); P.toast("Payment found: " + esc((rc.got || []).join(", "))); if (rc.me) setAcc(rc.me); }
      else { P.toast(rc.ok ? (rc.msg ? esc(rc.msg) : "Not confirmed yet. Give it a minute.") : esc(rc.error || "Couldn't check right now.")); await refreshMe(); }
      return;
    }
    if ((b = e.target.closest("[data-wallet]"))) { await P.connectWallet(); refreshMe(); return; }
    if ((b = e.target.closest("[data-wear]"))) {
      var wp = b.dataset.wear.split(":");
      var jw = await api({ a: "wear", card: wp[0], fin: wp[1] || "" });
      if (jw.ok) { P.sfx("select"); setAcc(jw.me); } else P.toast(esc(jw.error));
      return;
    }
    if ((b = e.target.closest("[data-xt-post]"))) { openOut("https://x.com/intent/tweet?text=" + encodeURIComponent(XT_TEXT[b.dataset.xtPost] || "")); return; }
    if (busy) return;
    //MC 2026-10-10 the Animated set costs thousands, so its buy buttons take two taps: the first one asks
    if ((b = e.target.closest("[data-big]")) && (b.matches("[data-buy],[data-fin],[data-set]")) && !b.classList.contains("armed")) {
      shopEl.querySelectorAll(".btn.armed").forEach(function (x) { x.classList.remove("armed"); if (x.__was) x.innerHTML = x.__was; });
      b.__was = b.innerHTML; b.classList.add("armed"); b.textContent = "Tap again to buy";
      clearTimeout(b.__tm); b.__tm = setTimeout(function () { if (b.classList.contains("armed")) { b.classList.remove("armed"); b.innerHTML = b.__was; } }, 4000);
      return;
    }
    if ((b = e.target.closest("[data-xt-check]"))) { await xtCheck(b.dataset.xtCheck); return; }
    if ((b = e.target.closest("[data-buy]"))) {
      busy = true; b.disabled = true;
      var id = b.dataset.buy, j = await api({ a: "buy", item: id });
      busy = false;
      if (j.ok) {
        var g = goodById(id), bi = itemById(id);
        if (bi && bi.slot === "fx") setTimeout(function () { fx(id.slice(3)); }, 250);   //MC 2026-10-10 a new victory effect plays once when you buy it
        bought(j, id === "saver" ? "Streak Saver ready. It covers a missed day on its own." : id === "scroll" ? "Yours. The premium track is open." : /^xp/.test(id) ? "XP Boost on. Every game earns " + cat.xpBoost + "% more Scroll XP." :
          id === "skip" ? "Up one tier. Collect your rewards on the Scroll." : id === "bounty" ? "The Bounty Board is open. Your bounties are in Missions." : g ? g.name + " ready." : "Yours. It's on now, or swap it in Style.");
      } else failed(j, "buy that");
      return;
    }
    if ((b = e.target.closest("[data-fin]"))) {
      busy = true; b.disabled = true;
      var fp = b.dataset.fin.split(":"), jf = await api({ a: "finish", card: fp[0], fin: fp[1] });
      busy = false;
      if (jf.ok) { fx(fp[1] === "holo" || fp[1] === "neon" || fp[1] === "glitch" || fp[1] === "aurora" || fp[1] === "frost" ? "cyan" : "money"); bought(jf, "New finish unlocked. It's on your card now."); }
      else failed(jf, "buy that");
      return;
    }
    if ((b = e.target.closest("[data-set]")) || (b = e.target.closest("[data-bundle]"))) {
      busy = true; b.disabled = true;
      var isB = b.hasAttribute("data-bundle");
      var js = await api(isB ? { a: "bundle", price: +b.dataset.bundle } : { a: "set", set: b.dataset.set, price: +b.dataset.price });
      busy = false;
      if (js.ok) { fx("money"); bought(js, js.n === 1 ? "Unlocked: 1 new piece." : "Unlocked: " + js.n + " new pieces."); }
      else failed(js, "buy that");
      return;
    }
    if ((b = e.target.closest("[data-reroll]"))) {
      busy = true; b.disabled = true;
      var jr = await api({ a: "reroll", slot: +b.dataset.reroll });
      busy = false;
      if (jr.ok) bought(jr, jr.how === "free" ? "Mission swapped with your free weekly reroll." : "Mission swapped.");
      else failed(jr, "swap it");
      return;
    }
    if ((b = e.target.closest("[data-equip]"))) {
      var parts = b.dataset.equip.split(":");
      var j2 = await api({ a: "equip", slot: parts[0], item: parts[1] || "" });
      if (j2.ok) { P.sfx("select"); setAcc(j2.me); } else P.toast(esc(j2.error));
      return;
    }
    if ((b = e.target.closest("[data-claim]"))) {
      busy = true; b.disabled = true;
      var j3 = await api({ a: "claim", kind: b.dataset.claim });
      busy = false;
      if (j3.ok) {
        P.sfx("badge"); fx("money");
        var got = j3.claimed;
        var k = typeof got === "number" ? got : got.reduce(function (s, x) { return s + (x.koban || 0); }, 0);
        var its = typeof got === "number" ? [] : got.filter(function (x) { return !x.koban; }).map(function (x) { return rewardText(x); });
        P.toast("Collected " + (k ? fmt(k) + " Koban" : "") + (its.length ? (k ? " and " : "") + esc(its.join(", ")) : "") + ".");
        setAcc(j3.me);
      } else { P.toast(esc(j3.error)); renderShop(); }
      return;
    }
    if ((b = e.target.closest("[data-pay]"))) { checkout(b.dataset.pay); return; }
    //MC 2026-10-13 a limited drop opens the checkout as a $SHY-only product with its exact price
    if ((b = e.target.closest("[data-drop]"))) {
      var dd = (cat.drops || []).filter(function (x) { return x.id === b.dataset.drop; })[0];
      if (dd) checkout({ id: "drop:" + dd.id, name: dd.cardName + " in " + dd.finName, shy: dd.shy, shyOnly: true });
      return;
    }
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && e.target.matches && e.target.matches("[data-xt-url]") && !busy) { e.preventDefault(); xtCheck(e.target.dataset.xtUrl); return; }
    //MC 2026-10-09 keep Tab inside the shop (or the open card popup) while it's up; checkout handles its own window
    //MC 2026-10-11 and Tab stays inside the checkout while it's open (it used to skip the trap, but nothing ever moved
    // focus into the checkout, so keyboard and screen reader users were stuck on the pack button behind it)
    if (e.key === "Tab" && co && !co.hidden) {
      var cf = coFocusables(); if (!cf.length) return;
      var ci = cf.indexOf(document.activeElement);
      if (ci < 0) { e.preventDefault(); cf[e.shiftKey ? cf.length - 1 : 0].focus(); }
      else if (e.shiftKey && ci === 0) { e.preventDefault(); cf[cf.length - 1].focus(); }
      else if (!e.shiftKey && ci === cf.length - 1) { e.preventDefault(); cf[0].focus(); }
      return;
    }
    if (e.key === "Escape" && co && !co.hidden) { closeCheckout(); return; }
    if (e.key === "Tab" && shopEl && !shopEl.hidden && (!co || co.hidden)) {
      var f = shopFocusables(); if (!f.length) return;
      var i = f.indexOf(document.activeElement);
      if (i < 0) { e.preventDefault(); f[0].focus(); }
      else if (e.shiftKey && i === 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
      return;
    }
    if (e.key !== "Escape" || !shopEl || shopEl.hidden) return;
    if (co && !co.hidden) closeCheckout(); else if (cardOpen) { cardOpen = ""; renderShop(true); } else closeShop();
  });
  function scrollToTier() {
    setTimeout(function () {
      var tr = $("sc-track"), nx = tr && (tr.querySelector(".sc-col.sc-next") || tr.querySelector(".sc-col.reached:last-child"));
      if (tr && nx) tr.scrollLeft = nx.offsetLeft - tr.clientWidth / 2;
    }, 30);
  }

  // ---------- checkout ----------
  var co = null, order = null, poll = null, pickCur = "SHY";
  //MC 2026-10-13 a product from outside the catalog (a tournament entry ticket): the page that opened the checkout
  //   hands the whole product in, and productById finds it again on redraws
  var extProd = null;
  function productById(id) { if (extProd && extProd.id === id) return extProd; return cat.packs.concat(cat.offers).filter(function (p) { return p.id === id; })[0]; }
  //MC 2026-10-11 focus goes into the checkout when it opens and back to the button that opened it when it closes
  var coFrom = null, coFromPay = "";
  function coFocusables() {
    if (!co) return [];
    return [].filter.call(co.querySelectorAll("a[href],button:not([disabled]),input:not([disabled]),select,textarea,summary,[tabindex='0']"), function (x) { return x.offsetParent || x.getClientRects().length; });
  }
  function coFocus(keep) {
    if (!co || co.hidden) return;
    var el = keep && co.querySelector(keep);
    if (!el || el.disabled) el = co.querySelector(".co-cur button.on") || co.querySelector(".co-go:not([disabled])") || co.querySelector(".co-panel");
    if (el) try { el.focus({ preventScroll: true }); } catch (x) { el.focus(); }
  }
  function closeCheckout() {
    if (co) { co.hidden = true; co.innerHTML = ""; }
    // the shop may have redrawn behind the checkout, so look the pack button up again if the old one is gone
    var back = coFrom && coFrom.isConnected ? coFrom : coFromPay && document.querySelector('#shop [data-pay="' + coFromPay + '"]');
    coFrom = null;
    if (back && back.focus) try { back.focus({ preventScroll: true }); } catch (x) {}
    clearTimeout(poll); poll = null;
    // a payment already sent keeps being checked in the background, without the window
    if (order && sentSig) { quiet(order.id, sentSig); } else forget();
    order = null; sentSig = "";
  }
  function checkout(pid) {
    var p;
    if (typeof pid === "object" && pid && pid.id) { extProd = pid; p = pid; pid = p.id; } else p = productById(pid);   //MC 2026-10-13 external products
    if (!p) return;
    if (p.shy && !p.usd) p.usd = Math.round(p.shy * (cat && cat.shyPx || 0) * 100) / 100;   // a rough USD line; the server quotes the exact fee
    if (p.shyOnly) pickCur = "SHY";
    co = co || $("checkout");
    if (co.hidden) { coFrom = document.activeElement && document.activeElement !== document.body ? document.activeElement : null; coFromPay = pid; }
    co.hidden = false;
    order = null;
    drawCheckout(p, "pick");
  }
  E.checkout = checkout;   //MC 2026-10-13 the tournament hall opens the checkout for entry tickets
  function payTotal(p) {
    var k = (p.koban || 0) + (p.bonus || 0);
    // the first buy of each Koban pack is doubled
    if (cat.packs.some(function (x) { return x.id === p.id; }) && acc && acc.fp && acc.fp.indexOf(p.id) < 0) k *= 2;
    return k;
  }
  function drawCheckout(p, step, info) {
    info = info || {};
    var k = payTotal(p);
    var gets = k ? koban(pickCur === "SHY" ? Math.round(k * (100 + myShyBonus()) / 100) : k) + (p.items ? " + " + p.items.length + " items" : "") : esc(p.name);
    // which control had focus, so the same one has it again after the redraw (picking a coin redraws the window)
    var ae = document.activeElement, keep = ae && co.contains(ae) ? (ae.dataset.cur ? '[data-cur="' + ae.dataset.cur + '"]' : ae.hasAttribute("data-co-close") ? ".sh-x" : null) : null;
    var h = '<div class="co-back" data-co-close></div><div class="co-panel" role="dialog" aria-modal="true" aria-label="Checkout" tabindex="-1">' +
      '<button class="sh-x" data-co-close aria-label="Close">✕</button><span class="of-k">Checkout</span><h3>' + esc(p.name) + '</h3>' +
      '<div class="co-sum"><span>You get</span><b>' + gets + '</b><span>Price</span><b>' + (p.shy ? fmt(p.shy) + ' $SHY <small class="usd">' + usd(p.usd) + '</small>' : pickCur === "SHY" ? shyTag(p.usd) : usd(p.usd)) + '</b></div>';   //MC 2026-10-13 a $SHY-priced product (a tournament entry) shows its exact fee
    if (step === "pick") {
      //MC 2026-10-09 only show the +% Koban tag when the product actually pays Koban, the Scroll was advertising a bonus it never gives
      //MC 2026-10-11 the Card option only shows once card payments are on (a disabled "Card / Soon" sat in every checkout)
      var curs = p.shyOnly ? [["SHY", "$SHY", ""]] : [["SHY", "$SHY", k > 0 ? "+" + myShyBonus() + "% Koban" : ""], ["SOL", "SOL", ""], ["USDC", "USDC", ""]].concat(cat.card ? [["CARD", "Card", ""]] : []);   //MC 2026-10-13 tournament entries are $SHY only
      h += '<div class="co-cur">' + curs.map(function (c) { return '<button data-cur="' + c[0] + '"' + (c[0] === pickCur ? ' class="on"' : "") + (c[0] === "CARD" && !cat.card ? " disabled" : "") + '><b>' + c[1] + '</b>' + (c[2] ? "<small>" + c[2] + "</small>" : "") + '</button>'; }).join("") + '</div>';
      if (!linked()) h += '<p class="co-note">Your purchases are kept on your wallet, so you can sign in on any device. Connect it to continue. Free, no transaction.</p><button class="btn btn-mint co-go" data-co-wallet>Connect wallet</button>';
      //MC 2026-10-11 the wallet address was inside the sentence, so the whole line missed the dictionary and stayed English in every language. Two pieces now, the address left as it is
      else h += '<p class="co-note"><span>Paying from <span data-i18n-skip>' + esc(short(acc.wallet)) + '</span>.</span> <span>' + (pickCur === "CARD" ? "You'll finish on a secure Stripe page." : "You'll approve one transfer in your wallet. The price is held for 20 minutes.") + '</span></p>' + (pickCur === "SHY" && cat.burnPct ? '<p class="co-note co-burnnote">' + cat.burnPct + '% of every $SHY payment is burned on Solana in the same transaction.</p>' : "") + '<button class="btn btn-red co-go" data-co-quote>Continue</button>';
    } else if (step === "pay" && info.order.cur === "CARD") {
      h += '<p class="co-status" id="co-status">' + (info.msg || "Waiting for the card payment\u2026") + '</p>';
    } else if (step === "pay") {
      var o = info.order, prov = P.provider();
      //MC 2026-10-10 a $SHY order says how much of it is burned: one transaction does both, the wallet shows the two lines
      var burnLine = +o.burn > 0 ? '<small class="co-burn"><i class="chip-fire" aria-hidden="true"></i>' + fmt(Math.round(+o.amount - +o.burnAmount)) + ' $SHY to the community wallet, <b>' + fmt(Math.round(+o.burnAmount)) + ' $SHY burned forever</b> (' + o.bpct + '%)</small>' : "";
      h += '<div class="co-amt"><small>' + (+o.burn > 0 ? "You pay" : "Send exactly") + '</small><b>' + Number(o.amount).toLocaleString("en-US", { maximumFractionDigits: 6 }) + ' ' + (o.cur === "SHY" ? "$SHY" : o.cur) + '</b>' + burnLine + '<small><span>' + (+o.burn > 0 ? "in one transaction from your wallet" : 'to the marketing wallet <span data-i18n-skip>' + esc(short(o.to)) + '</span>') + '</span> &middot; <span>price held for <span data-count="' + o.exp + '">' + left(o.exp) + '</span></span></small></div>';   //MC 2026-10-11 in pieces, the wallet address left out of the dictionary key
      //MC 2026-10-11 the wallet name on its own, so "Pay with <0/>" is one dictionary key for every wallet
      if (prov) h += '<button class="btn btn-red co-go" data-co-send>' + (prov.isPhantom || prov.isSolflare ? '<span>Pay with <span data-i18n-skip>' + (prov.isPhantom ? "Phantom" : "Solflare") + '</span></span>' : "Pay with your wallet") + '</button>';
      else if (/iPhone|iPad|Android/i.test(navigator.userAgent)) {
        var here = location.origin + location.pathname + "?order=" + o.id + "#shop";
        // no wallet in this browser: open this same checkout inside the wallet's own browser, where paying is one tap
        h += '<a class="btn btn-red co-go" href="https://phantom.app/ul/browse/' + encodeURIComponent(here) + '?ref=' + encodeURIComponent(location.origin) + '">Open in Phantom to pay</a>' +
          '<a class="btn btn-line co-go" href="https://solflare.com/ul/v1/browse/' + encodeURIComponent(here) + '?ref=' + encodeURIComponent(location.origin) + '">Open in Solflare to pay</a>' +
          '<a class="btn btn-line co-go" href="' + esc(o.url) + '">Other wallet app</a>';
      }
      h += '<details class="co-qr"' + (prov ? "" : " open") + '><summary>Pay from your phone</summary><div class="co-qr-in"><div id="co-qr"></div><small>Scan with Phantom or Solflare. This page updates on its own when the payment lands.</small></div></details>';
      //MC 2026-10-11 no "Waiting for your payment" before Pay has been pressed; it stays when paying from a phone or the QR code
      h += '<p class="co-status" id="co-status">' + (info.msg || (prov ? "" : "Waiting for your payment…")) + '</p>';
    } else if (step === "done") {
      h += '<div class="co-done"><div class="co-burst"></div><b>Paid. It\'s yours.</b><p>' + esc((info.got || []).join(", ")) + '</p>' +
        (info.proof && !/^cs_/.test(info.proof) ? '<a href="https://solscan.io/tx/' + esc(info.proof) + '" target="_blank" rel="noopener">View the payment on Solscan</a>' : "") + '</div><button class="btn btn-mint co-go" data-co-close>Back to the shop</button>';
    } else if (step === "err") {
      h += '<p class="co-status err">' + esc(info.msg) + '</p><button class="btn btn-line co-go" data-co-retry>Try again</button>';
    }
    co.innerHTML = h + '</div>';
    co.dataset.product = p.id;
    coFocus(keep);
    if (step === "pay" && info.order.url) drawQR(info.order.url);
  }
  async function drawQR(url) {
    try {
      await loadScript("assets/vendor/qrcode.js");
      var q = window.qrcode(0, "M"); q.addData(url); q.make();
      var el = $("co-qr"); if (el) el.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
    } catch (e) {}
  }
  function setStatus(msg, err) { var el = $("co-status"); if (el) { el.textContent = msg; el.classList.toggle("err", !!err); } }
  async function quote() {
    var p = productById(co.dataset.product);
    if (pickCur === "CARD") {
      setStatus("Opening the card page…");
      var c = await api({ a: "card", product: p.id });
      if (c.ok && c.url) { try { sessionStorage.setItem("shy-order", c.order); } catch (e) {} location.href = c.url; }
      else drawCheckout(p, "err", { msg: c.error || "Couldn't start a card payment." });
      return;
    }
    var j = await api({ a: "quote", product: p.id, cur: pickCur });
    if (!j.ok) return drawCheckout(p, "err", { msg: j.error || "Couldn't get a price." });
    order = j.order; sentSig = "";
    remember(order.id, "");
    drawCheckout(p, "pay", { order: order });
    watch(order.id, p);
  }
  // keep asking the server until the payment shows up on Solana
  var sentSig = "";
  function remember(id, sig, bg) { try { localStorage.setItem("shy-order", JSON.stringify({ id: id, sig: sig || "", ts: Date.now(), bg: !!bg })); } catch (e) {} }
  function forget() { try { localStorage.removeItem("shy-order"); sessionStorage.removeItem("shy-order"); } catch (e) {} }
  // check a sent payment in the background and say so when it lands
  var quietPoll = null;
  function quiet(id, sig) {
    remember(id, sig, true);
    clearTimeout(quietPoll);
    var started = Date.now();
    var tick = async function () {
      var j = await api({ a: "check", order: id, sig: sig });
      if (j.ok && j.status === "paid") { forget(); if (j.me) setAcc(j.me); P.sfx("badge"); fx("money"); P.toast("Payment received: " + esc((j.got || []).join(", "))); return; }
      if ((j.ok && (j.status === "failed" || j.status === "expired" || j.status === "short")) || (!j.ok && j.status === 404)) {
        forget(); if (j.msg) P.toast(esc(j.msg)); return;
      }
      if (Date.now() - started < 20 * 60 * 1000) quietPoll = setTimeout(tick, 8000);
    };
    quietPoll = setTimeout(tick, 4000);
  }
  function txLink(sig) { return sig ? ' <a href="https://solscan.io/tx/' + esc(sig) + '" target="_blank" rel="noopener">View it on Solscan</a>' : ""; }
  function setStatusHtml(html, err) { var el = $("co-status"); if (el) { el.innerHTML = html; el.classList.toggle("err", !!err); } }
  function watch(id, p, fast) {
    clearTimeout(poll);
    var started = Date.now(), misses = 0;
    var tick = async function () {
      if (!order || order.id !== id) return;
      var j = await api({ a: "check", order: id, sig: sentSig });
      if (!order || order.id !== id) return;
      var waited = Date.now() - started;
      if (j.ok) misses = 0; else misses++;
      if (j.ok && j.status === "paid") return paid(p, j);
      if (j.ok && j.status === "failed") {
        forget(); sentSig = "";
        co.querySelector("[data-co-send]") && (co.querySelector("[data-co-send]").disabled = false);
        setStatusHtml(esc(j.msg) + txLink(j.sig), true);
        return;
      }
      if (j.ok && j.status === "short") { setStatusHtml(esc(j.msg) + txLink(sentSig), true); return; }
      if (j.ok && j.status === "expired") { setStatus("This order expired. Start a new one.", true); forget(); return; }
      if (j.ok && j.status === "late") setStatusHtml("The price hold ran out, but if you already paid it will still go through." + txLink(sentSig));
      else if (!j.ok && misses >= 3) setStatusHtml("Having trouble reaching the server. Still checking…" + txLink(sentSig));
      else if (sentSig && waited > 90000) setStatusHtml("Solana is taking longer than usual. You can close this: your purchase is added the moment the payment confirms, even if you come back later. Order " + esc(id) + "." + txLink(sentSig));
      else if (sentSig) setStatusHtml("Sent. Confirming on Solana…" + txLink(sentSig));
      if (waited < 25 * 60 * 1000) poll = setTimeout(tick, misses ? 6000 : fast && waited < 120000 ? 2500 : 5000);
    };
    poll = setTimeout(tick, fast ? 1500 : 3000);
  }
  function paid(p, j) {
    forget(); sentSig = "";
    order = null;
    P.sfx("badge"); P.buzz([20, 60, 20, 60, 30]); fx("money");
    if (j.me) setAcc(j.me);
    if (co && !co.hidden) drawCheckout(p, "done", { got: j.got, proof: j.proof });
    else P.toast("Payment received: " + esc((j.got || []).join(", ")));
    try { document.dispatchEvent(new CustomEvent("shy:paid", { detail: { product: p.id, got: j.got || [] } })); } catch (e) {}   //MC 2026-10-13 the tournament hall signs the buyer up the moment the entry lands
  }
  async function sendWithWallet() {
    var prov = P.provider();
    if (!prov || !order) return;
    var btn = co.querySelector("[data-co-send]"); if (btn) btn.disabled = true;
    try {
      setStatus("Getting the transaction ready…");
      await Promise.all([loadScript("assets/vendor/solana-web3.min.js"), loadScript("assets/paytx.js")]);
      var W = window.solanaWeb3;
      var conn = await prov.connect();
      var payer = ((conn && conn.publicKey) || prov.publicKey).toString();
      var tokProg = null;
      if (order.cur !== "SOL") {
        var info = await api({ a: "rpc", method: "getAccountInfo", params: [order.mint] });
        tokProg = info.ok && info.result && info.result.value ? info.result.value.owner : null;
        if (!tokProg) throw new Error("Couldn't read the token from Solana. Try again.");
      }
      // check the wallet can cover it before asking it to sign, so a short wallet never sends a payment that fails
      var f = await api({ a: "rpc", method: "funds", params: [payer, order.cur === "SOL" ? "" : order.mint] });
      if (f.ok && f.result) {
        var FEE = 50000, lam = f.result.lamports, have = f.result.units, need = Number(order.units);
        var amt = function (u) { return (u / Math.pow(10, order.dec)).toLocaleString("en-US", { maximumFractionDigits: Math.min(6, order.dec) }); };
        // say which wallet was checked: wallet apps can hold several accounts, and show coins from other networks too
        var from = ' <span>Paying from <span data-i18n-skip>' + esc(payer.slice(0, 4) + "…" + payer.slice(-4)) + '</span>.</span>';
        var short = function (msg, extra) { var er = new Error(msg); er.html = '<span>' + esc(msg) + '</span>' + from + (extra || ""); throw er; };
        if (order.cur === "SOL" && lam != null && lam < need + FEE) short("This wallet has " + amt(lam) + " SOL. This purchase needs " + amt(need) + " SOL plus a tiny network fee. Top it up, or pay with a different coin.");
        if (order.cur !== "SOL" && have != null && have < need) short("This wallet has " + amt(have) + " " + order.cur + ". This purchase needs " + amt(need) + " " + order.cur + ". Top it up, or pay with a different coin.",
          order.cur === "USDC" ? ' <span>Only USDC on Solana works here. If your wallet app shows more, it may be on another network like Base or Ethereum, or in a different account in your wallet.</span>' : "");
        if (order.cur !== "SOL" && lam != null && lam < FEE) short("This wallet needs a little SOL for the Solana network fee, even when paying with " + order.cur + ". About 0.001 SOL is plenty.");
      }
      var bh = await api({ a: "rpc", method: "getLatestBlockhash" });
      if (!bh.ok || !bh.result) throw new Error("Couldn't reach Solana. Try again.");
      var tx = window.ShyPayTx.build(W, order, payer, tokProg, bh.result.value.blockhash);
      setStatus("Approve the payment in your wallet…");
      var res = await prov.signAndSendTransaction(tx);
      sentSig = typeof res === "string" ? res : (res && res.signature) || "";
      remember(order.id, sentSig);
      setStatusHtml("Sent. Confirming on Solana…" + txLink(sentSig));
      watch(order.id, productById(co.dataset.product), true);
    } catch (e) {
      if (e && e.html) { setStatusHtml(e.html, true); if (btn) btn.disabled = false; return; }
      var m = (e && e.message) || "";
      setStatus(/reject|denied|cancel|User rejected/i.test(m) ? "Cancelled in your wallet. Nothing was sent." : /insufficient|0x1\b|debit/i.test(m) ? "Not enough funds in this wallet for the payment and its network fee." : m || "Something went wrong. Try again.", true);
      if (btn) btn.disabled = false;
    }
  }
  document.addEventListener("click", async function (e) {
    if (!co || co.hidden || !e.target.closest("#checkout")) return;
    var b;
    if (e.target.closest("[data-co-close]")) return closeCheckout();
    var p = productById(co.dataset.product);
    if ((b = e.target.closest("[data-cur]")) && !b.disabled) { pickCur = b.dataset.cur; drawCheckout(p, "pick"); return; }
    if (e.target.closest("[data-co-wallet]")) { await P.connectWallet(); await refreshMe(); drawCheckout(p, "pick"); return; }
    if ((b = e.target.closest("[data-co-quote]"))) { b.disabled = true; b.textContent = "Getting a live price…"; quote(); return; }
    if (e.target.closest("[data-co-send]")) { sendWithWallet(); return; }
    if (e.target.closest("[data-co-retry]")) { drawCheckout(p, "pick"); return; }
  });

  // ---------- after each game ----------
  function onGame(eco, league) {
    var el = $("g-eco"); if (!el || !eco) { refreshMe(); return; }
    var bits = [];
    if (eco.xp) bits.push('<span class="ge xp">+' + eco.xp + ' XP' + (eco.boosted ? ' <em>boosted</em>' : "") + (eco.tierUp ? ' &middot; <b>Scroll tier ' + eco.tier + '!</b>' : "") + '</span>');
    (eco.mastery || []).forEach(function (m) { bits.push('<button class="ge mastery" data-shop="cards:' + esc(m.card) + '"><span>' + esc(cat.masteryNames[m.level]) + '</span><span>' + esc(cardName(m.card)) + '</span>' + koban(cat.mastery[m.level][1]) + '</button>'); });
    if (eco.streakPay) bits.push('<span class="ge streak">Day ' + eco.streak + ' streak ' + koban(eco.streakPay) + '</span>');
    if (eco.saverUsed) bits.push('<span class="ge saver">Streak Saver kept your streak</span>');
    (eco.missions || []).forEach(function (m) {
      if (m.new) bits.push('<button class="ge mission" data-shop="missions"><span>Mission done</span><span>' + esc(m.text) + '</span>' + koban(m.koban) + '</button>');
      else if (m.moved && !m.done) bits.push('<button class="ge mission dim" data-shop="missions"><span>' + esc(m.text) + '</span><small>' + fmt(m.n) + ' / ' + fmt(m.goal) + '</small></button>');
    });
    if (league && league.gain) bits.push('<a class="ge league" href="#rewards">+' + fmt(league.gain) + ' League points</a>');
    // a live match that didn't count for the League says why, so the League games count never looks stuck
    if (league && league.miss === "bots") bits.push('<a class="ge league-miss" href="#rewards"><b>Not a League game</b><span>Everyone else at the table was a bot. League games are your first Daily each day and live matches with at least one other real player.</span></a>');
    //MC 2026-10-10 the admin can switch private rooms out of the League (Fair Play)
    if (league && league.miss === "private") bits.push('<a class="ge league-miss" href="#rewards"><b>Not a League game</b><span>Private rooms don\'t count for the League right now. Quick matches with other players do. This match still counts for everything else.</span></a>');
    //MC 2026-10-10 Fair Play rules: why a match with another real player still wasn't a League game
    var FPW = { left: "Your rival left early, so the game played their seat. League games need a real rival who stays for most of the match; one who bails in the last rounds counts now. This match still counts for everything else.",
      quit: "You left this match before the end, so it went down as a loss, finished last for Ranked, and sat out the League. Stay to the end and the result is yours.",
      same: "Everyone else at the table played from your network and browser. League games need a rival on their own device. This match still counts for everything else.",
      "new": "Your rivals are brand new accounts. They start counting for your League after a few more games. This match still counts for everything else.",
      pair: "You've already played your League matches against this player today. Play someone else for League points. This match still counts for everything else." };
    if (league && FPW[league.miss]) bits.push('<a class="ge league-miss" href="#rewards"><b>Not a League game</b><span>' + FPW[league.miss] + '</span></a>');
    if (league && league.miss === "cap") bits.push('<a class="ge league-miss" href="#rewards"><b>Not a League game</b><span>You\'ve played 10 League matches today, the most that count in one day. This match still counts for everything else.</span></a>');
    el.innerHTML = bits.join("") + (eco.tierUp ? '<button class="btn btn-mint btn-sm" data-shop="scroll">Collect rewards</button>' : "") + ((eco.mastery || []).length ? '<button class="btn btn-mint btn-sm" data-shop="cards">Collect mastery</button>' : "");
    el.hidden = !bits.length;
    if (eco.tierUp || (eco.mastery || []).length || (eco.missions || []).some(function (m) { return m.new; })) P.sfx("badge");
    refreshMe(); loadRewards();
  }

  // ---------- Weekly League section ----------
  // ---------- Weekly League ----------
  var wl = { key: "", sim: "daily-win", reg: 9, open: false, shown: false };
  function wlStatus(r, need) {
    if (r.ok) return ["ok", "Qualified"];
    var more = Math.max(0, need - r.n);
    if (more === 1) return ["need", "1 more game to qualify"];
    if (more > 1) return ["need", more + " more games to qualify"];
    if (!r.w) return ["wallet", "Needs a wallet to win"];
    return ["need", "Not qualified yet"];
  }
  function wlAv(r) { return '<span class="wl-av">' + (r.img ? '<img src="' + esc(r.img) + '" alt="" loading="lazy">' : '<i>' + esc(String(r.name || "?").charAt(0).toUpperCase()) + '</i>') + '</span>'; }
  // prize places go to qualified players in order, like the payout itself
  function wlPlaces(rows) { var k = 0; return rows.map(function (r) { return r.ok ? k++ : -1; }); }
  function wlSimPts(kind, reg) {
    var p = reg * 5, mult = rw && rw.event && !rw.event.upcoming ? +rw.event.mult || 1 : 1;
    if (kind === "daily-win") p += 100;
    else if (kind === "live-2") p += 100 + 20;
    else if (kind === "live-4") p += 100 + 60;
    return Math.round(p * mult);
  }
  function wlSimText() {
    var L = rw.league, mine = L.me, base = mine ? mine.pts : 0, gain = wlSimPts(wl.sim, wl.reg), total = base + gain;
    var rank = 1; L.rows.forEach(function (r) { if (r.tag !== me.pid.slice(0, 6) && r.pts >= total) rank++; });
    return { gain: gain, rank: rank, total: total };
  }
  function drawSim() {
    var o = wlSimText(), g = $("wl-sim-pts"), rk = $("wl-sim-rank"), v = $("wl-reg-v");
    if (g) g.textContent = "+" + fmt(o.gain);
    if (v) v.textContent = wl.reg;
    if (rk) rk.innerHTML = 'That puts you on <b>' + fmt(o.total) + ' points</b>, about <b>#' + o.rank + '</b> this week.';
  }
  function renderRewards() {
    var el = $("rewards-body"); if (!el || !rw) return;
    // the same numbers as last time: nothing to redraw (keeps the page still and the simulator as it was)
    var k = JSON.stringify([rw.league, rw.cup, rw.seasonBoard, rw.event, rw.past, rw.shyPx, linked()]);
    if (k === wl.key && el.firstChild && el.querySelector(".wl-hero")) return;
    wl.key = k;
    var px = rw.shyPx, min = rw.minGames, myTag = me.pid.slice(0, 6);
    var shyOf = function (u) { return px ? fmt(Math.round(u / px)) + " $SHY" : usd(u) + " in $SHY"; };
    //MC 2026-10-10 a rank shows as its emblem (name on hover), a Shadow as before
    var RKN = cat.holderNames || {}, tierTag = function (t) { return t && t !== "shadow" && RKN[t] ? '<em class="tier-b rk ico t-' + t + '" title="' + esc(RKN[t]) + '" data-i18n-skip><img src="/assets/ranks/' + t + '-64.webp" alt="' + esc(RKN[t]) + '" width="22" height="22"></em>' : t ? '<em class="lb-holder">' + (t === "shadow" ? "Shadow holder" : "Holder") + '</em>' : ""; };
    var L = rw.league, C = rw.cup, S = rw.seasonBoard, pool = L.pool.total;
    var chip = function (r, need) { var st = wlStatus(r, need); return '<span class="wl-chip ' + st[0] + '">' + st[1] + '</span>'; };
    //MC 2026-10-12 cash: places paid in $SHY; the places below it win Koban (already in kob)
    var prizeOf = function (split, total, place, cash) { return place >= 0 && place < (cash || 99) && split[place] ? total * split[place] / 100 : 0; };
    var row = function (r, i, split, total, place, need, kob, cash) {
      var prize = prizeOf(split, total, place, cash), mine = r.tag === myTag;
      return '<li class="' + (mine ? "me " : "") + (r.ok ? "" : "ineligible") + '" style="--d:' + Math.min(i, 12) * 35 + 'ms"><span class="lg-r">' + (i + 1) + '</span>' + wlAv(r) +
        '<span class="lg-n"><b' + (r.cos && r.cos.ring ? ' class="ring-' + esc(r.cos.ring) + '"' : "") + ' data-i18n-skip>' + esc(r.name) + '</b>' + (r.cos && r.cos.title ? '<em class="lb-title">' + esc(r.cos.title) + '</em>' : "") +
        tierTag(r.tier) + (mine ? '<em class="wl-you-tag">You</em>' : "") + '<small>' + r.n + (r.n === 1 ? " game" : " games") + '</small>' + chip(r, need) + '</span>' +
        '<span class="lg-p">' + fmt(r.pts) + '<small>pts</small></span>' + (prize ? '<span class="lg-w">' + shyOf(prize) + '</span>' : '<span class="lg-w dim">' + (kob && place >= 0 && kob[place] ? koban(kob[place]) : "") + '</span>') + '</li>';
    };
    // ---- the pool, the clock and every prize
    var maxPct = Math.max.apply(null, L.split);
    var cashN = Math.min(L.cash || L.split.length, L.split.length);
    var bars = L.split.map(function (pct, i) {
      var u = pool * pct / 100;
      if (i >= cashN) return '<button type="button" class="wl-bar k" style="--h:' + Math.round(pct / maxPct * 100) + '%;--d:' + i * 45 + 'ms" data-tip="' + esc('#' + (i + 1) + ': ' + fmt((L.koban && L.koban[i]) || 0) + ' Koban') + '"><i></i><span>' + (i + 1) + '</span></button>';
      return '<button type="button" class="wl-bar" style="--h:' + Math.round(pct / maxPct * 100) + '%;--d:' + i * 45 + 'ms" data-tip="' + esc('#' + (i + 1) + ': ' + usd(u) + (px ? ', about ' + shyOf(u) : '') + (L.koban && L.koban[i] ? ', plus ' + fmt(L.koban[i]) + ' Koban' : '')) + '"><i></i><span>' + (i + 1) + '</span></button>';
    }).join("");
    var h = '<div class="wl-hero"><div class="wl-pool"><span class="of-k">This week\'s prize pool</span>' +
      '<b class="lg-big"><span data-countup="' + pool + '">' + usd(pool) + '</span><small> in $SHY</small></b>' +
      (px ? '<small class="lg-sub">about ' + shyOf(pool) + ' at today\'s price' + (L.pool.share ? ', including ' + usd(L.pool.share) + ' from last week\'s shop' : "") + '</small>' : "") +
      '<div class="wl-clock" data-clock="' + rw.weekEnd + '" aria-label="Time left this week">' + clockHTML(rw.weekEnd) + '</div>' +
      '<div class="wl-split"><div class="wl-bars">' + bars + '</div><p class="wl-tip" id="wl-tip">' + (cashN < L.split.length ? 'Tap a bar to see that prize. The top ' + cashN + ' win $SHY, places ' + (cashN + 1) + ' to ' + L.split.length + ' win Koban.' : 'Tap a bar to see that prize. Top ' + L.split.length + ' qualified players get paid.') + '</p></div></div>';
    // ---- your week
    var m = L.me, need = min;
    var ring = function (n, of) { var f = Math.min(1, n / Math.max(1, of)), c = 2 * Math.PI * 52; return '<svg viewBox="0 0 120 120" aria-hidden="true"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg' + (f >= 1 ? " done" : "") + '" cx="60" cy="60" r="52" stroke-dasharray="' + c.toFixed(1) + '" style="--off:' + (c * (1 - f)).toFixed(1) + '"/></svg>'; };
    var you;
    if (!m) {
      you = '<div class="wl-ring">' + ring(0, need) + '<b>0<small>/' + need + '</small></b><span>League games</span></div><div class="wl-you-txt"><span class="of-k">Your week</span><h3>You\'re not on the board yet</h3>' +
        '<p class="wl-state need">Play today\'s Daily or a live match with real players to get on it. ' + need + ' League games this week and a connected wallet qualify you for prizes.</p>';
    } else {
      var st = wlStatus(m, need), placeIdx = -1, k2 = 0, myPrize = 0;
      L.rows.forEach(function (r) { if (r.ok) { if (r.tag === myTag) placeIdx = k2; k2++; } });
      if (placeIdx >= 0) myPrize = prizeOf(L.split, pool, placeIdx, cashN);
      var myKob = placeIdx >= cashN && L.koban ? L.koban[placeIdx] || 0 : 0;
      var ahead = L.rows[m.rank - 2], gap = ahead ? ahead.pts - m.pts : 0;
      you = '<div class="wl-ring">' + ring(m.n, need) + '<b>' + m.n + '<small>/' + need + '</small></b><span>League games</span></div><div class="wl-you-txt"><span class="of-k">Your week</span>' +
        '<h3>#' + m.rank + ' <small>of ' + L.total + '</small> &middot; ' + fmt(m.pts) + ' <small>pts</small></h3>' +
        '<p class="wl-state ' + st[0] + '">' + (m.ok ? "You qualify for prizes this week." : st[0] === "wallet" ? "Connect a wallet to collect prizes. Your points already count." : '<span>' + (Math.max(0, need - m.n) === 1 ? "1 more League game to qualify for prizes." : Math.max(0, need - m.n) + " more League games to qualify for prizes.") + '</span>' + (m.w || st[0] === "wallet" ? "" : " <span>You'll also need a connected wallet.</span>")) + '</p>' +   //MC 2026-10-09 each sentence in its own span so both find their dictionary keys
        (m.ok ? "" : '<p class="wl-counts">League games are your first Daily each day and live matches with at least one other real player. Live matches against bots only don\'t count.</p>') +
        (myPrize ? '<p class="wl-gap">You\'re in the prizes right now: about <b>' + shyOf(myPrize) + '</b>.</p>' : myKob ? '<p class="wl-gap">You\'re in the prizes right now: <b>' + fmt(myKob) + ' Koban</b>.</p>' : "") +
        (ahead && gap >= 0 ? '<p class="wl-gap">' + fmt(gap + 1) + ' points to pass #' + (m.rank - 1) + '.</p>' : (m.rank === 1 ? '<p class="wl-gap">You\'re leading the League.</p>' : ""));
    }
    you += '<div class="btns"><button class="btn btn-red btn-sm" data-play="daily">Play today\'s Daily</button><button class="btn btn-mint btn-sm" data-play="live-quick">Find a live match</button>' + (linked() ? "" : '<button class="btn btn-line btn-sm" data-rw-wallet>Connect wallet</button>') + '</div></div>';
    h += '<div class="wl-you">' + you + '</div></div>';
    if (rw.event) h += '<div class="lg-event' + (rw.event.upcoming ? " soon" : "") + '"><b>' + esc(rw.event.name) + '</b> ' + (rw.event.upcoming ? "starts in " : "x" + rw.event.mult + " League points, ends in ") + '<span data-count="' + (rw.event.upcoming ? rw.event.from : rw.event.to) + '">' + left(rw.event.upcoming ? rw.event.from : rw.event.to) + '</span></div>';
    // ---- what a game is worth
    var sims = [["daily-win", "Daily, win"], ["daily-loss", "Daily, no win"], ["live-2", "Live win vs 1 real player"], ["live-4", "Live win vs 3 real players"]];
    h += '<section class="wl-sim"><div class="wl-sim-hd"><h4>What\'s your next game worth?</h4><small>Pick a game and how many Regions you end with.</small></div>' +
      '<div class="wl-seg" role="tablist">' + sims.map(function (x) { return '<button type="button" data-sim="' + x[0] + '"' + (wl.sim === x[0] ? ' class="on"' : "") + '>' + x[1] + '</button>'; }).join("") + '</div>' +
      '<div class="wl-sim-row"><label class="wl-range"><span>Regions at the end</span><input type="range" min="0" max="15" step="1" value="' + wl.reg + '" id="wl-reg" aria-label="Regions at the end"><b id="wl-reg-v">' + wl.reg + '</b></label>' +
      '<div class="wl-sim-out"><b id="wl-sim-pts">+0</b><span id="wl-sim-rank"></span></div></div>' +
      '<p class="wl-note">5 points per Region, +100 for a win, +50 for a tie, and +20 for each other real player when you win a live match.' + (rw.event && !rw.event.upcoming ? ' ' + esc(rw.event.name) + ' multiplies every League point right now.' : "") + '</p></section>';
    // ---- the rules, in plain words
    var rules = [
      ["What counts", "Your first Daily Challenge run each day, and live matches with at least 2 real players, up to " + rw.liveCap + " a day. Solo games and Daily replays don't count."],
      ["Points", "5 per Region you hold at the end, +100 for a win, +50 for a tie. Winning or tying a live match adds +20 for each other real player at the table."],
      ["To win prizes", "Connect a Solana wallet and play at least " + min + " League games in the week. The Season Championship needs " + min * 2 + "."],
      ["Who gets paid", (cashN < L.split.length ? "The top " + cashN + " qualified players win $SHY and places " + (cashN + 1) + " to " + L.split.length + " win Koban." : "The top " + L.split.length + " qualified players.") + " Anyone who isn't qualified is skipped and the next player moves up."],
      ["The week", "Monday 00:00 UTC to Monday 00:00 UTC. Results freeze the moment the week ends."],
      ["Prizes", (rw.sales ? "The pool grows with the shop: a share of last week's shop sales goes into it. " : "") + "Paid in $SHY from the community marketing wallet at that day's price, each with a public transaction link. The top " + L.split.length + " also get Koban straight away."],
      ["Ties", "Same points? The player with fewer games ranks higher."],
      ["Holder Cup and Season", "The Holder Cup uses the same points, for $SHY and Shadow holders. The Season Championship adds up four weeks."]];
    h += '<details class="wl-rules"' + (wl.open ? " open" : "") + '><summary><span>How the Weekly League works</span><i>' + rules.length + ' rules</i></summary><div class="wl-rules-grid">' +
      rules.map(function (r, i) { return '<div><b><span>' + (i + 1) + '</span>' + r[0] + '</b><p>' + esc(r[1]) + '</p></div>'; }).join("") + '</div><a class="wl-more" href="/rules">Read the official rules</a></details>';
    // ---- the boards
    var pl = wlPlaces(L.rows), top3 = L.rows.slice(0, 3);
    var pod = function (r, i) {
      if (!r) return '<div class="pd p' + (i + 1) + ' empty"><span class="wl-av"><i>?</i></span><b>Open spot</b><small>Play to take it</small></div>';
      var prize = prizeOf(L.split, pool, pl[i], cashN);
      return '<div class="pd p' + (i + 1) + (r.tag === myTag ? " me" : "") + '">' + (i === 0 ? '<span class="pd-crown" aria-hidden="true"></span>' : "") + wlAv(r) + '<b data-i18n-skip>' + esc(r.name) + '</b><span class="pd-pts">' + fmt(r.pts) + ' <small>pts</small></span>' +
        (prize ? '<span class="pd-prize">' + shyOf(prize) + '</span>' : "") + chip(r, min) + '<span class="pd-step">' + (i + 1) + '</span></div>';
    };
    h += '<div class="lg-grid"><section class="lg-board"><div class="lg-hd"><h3>Weekly League</h3><small>' + L.total + (L.total === 1 ? " player" : " players") + ' this week</small></div>' +
      (L.rows.length ? '<div class="wl-podium">' + [1, 0, 2].map(function (i) { return pod(top3[i], i); }).join("") + '</div>' : "") +
      '<ol class="lg-list" start="4">' + (L.rows.length > 3 ? L.rows.slice(3, 15).map(function (r, i) { return row(r, i + 3, L.split, pool, pl[i + 3], min, L.koban, cashN); }).join("") : (L.rows.length ? "" : '<li class="lb-empty">Nobody on the board yet this week. The pool is wide open.</li>')) + '</ol></section>' +
      '<div class="lg-side"><section class="lg-board cup"><div class="lg-hd"><h3>Holder Cup</h3><small>' + shyPool(C.pool) + ', top ' + C.split.length + '</small></div>' +
      '<ol class="lg-list">' + (C.rows.length ? (function () { var p2 = wlPlaces(C.rows); return C.rows.slice(0, 5).map(function (r, i) { return row(r, i, C.split, C.pool, p2[i], min, C.koban, C.cash); }); })().join("") : '<li class="lb-empty">No holders on it yet. Hold $SHY or a Shadow and play.</li>') + '</ol></section>' +
      '<section class="lg-board season"><div class="lg-hd"><h3>Season ' + rw.season + ' Championship</h3><small>' + shyPool(S.pool) + ' &middot; ends in <span data-count="' + rw.seasonEnd + '">' + left(rw.seasonEnd) + '</span></small></div>' +
      '<ol class="lg-list">' + (S.rows.length ? (function () { var p3 = wlPlaces(S.rows); return S.rows.slice(0, 5).map(function (r, i) { return row(r, i, S.split, S.pool, p3[i], min * 2, S.koban, S.cash); }); })().join("") : '<li class="lb-empty">The season race is open.</li>') + '</ol></section></div></div>';
    if (rw.past.length) h += '<section class="lg-past"><h4>Past winners</h4>' + rw.past.map(function (w) {
      return '<div class="lg-week"><b>Week ' + esc(w.wk.split("-")[1]) + '</b><span class="lg-st ' + esc(w.status) + '">' + (w.status === "paid" ? "Paid" : "Payout pending") + '</span>' +
        w.winners.slice(0, 3).map(function (x) { return '<span>' + x.place + '. <span data-i18n-skip>' + esc(x.name) + '</span> ' + (x.shy ? fmt(x.shy) + " $SHY" : usd(x.usd)) + (x.sig ? ' <a href="https://solscan.io/tx/' + esc(x.sig) + '" target="_blank" rel="noopener">tx</a>' : "") + '</span>'; }).join("") + '</div>';
    }).join("") + '</section>';
    h += '<p class="fine center">No purchase necessary. Prizes are paid in $SHY from the community marketing wallet and depend on verified play only. <a href="/rules">Official rules</a></p>';
    el.innerHTML = h;
    drawSim();
    // the pool counts up once, when it first comes into view
    var cu = el.querySelector("[data-countup]");
    if (cu && !wl.shown) {
      var go = function () {
        if (wl.shown) return; wl.shown = true;
        var end = +cu.dataset.countup, t0 = performance.now(), dur = reduceMotion ? 1 : 1100;
        (function step(t) { var f = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - f, 3); cu.textContent = usd(Math.round(end * e * 100) / 100); if (f < 1) requestAnimationFrame(step); else cu.textContent = usd(end); })(t0);
      };
      if ("IntersectionObserver" in window) { var io = new IntersectionObserver(function (es) { if (es.some(function (x) { return x.isIntersecting; })) { io.disconnect(); go(); } }, { threshold: .3 }); io.observe(cu); } else go();
    }
  }
  var reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  // big clock: days, hours, minutes, seconds
  function clockHTML(ts) {
    var s = Math.max(0, Math.floor(ts - now())), parts = [[Math.floor(s / 86400), "days"], [Math.floor(s % 86400 / 3600), "hrs"], [Math.floor(s % 3600 / 60), "min"], [s % 60, "sec"]];
    return parts.map(function (p) { return '<div><b>' + (p[0] < 10 ? "0" : "") + p[0] + '</b><small>' + p[1] + '</small></div>'; }).join("");
  }
  setInterval(function () {
    if (document.hidden || resting()) return;
    document.querySelectorAll("[data-clock]").forEach(function (c) {
      var s = Math.max(0, Math.floor(+c.dataset.clock - now())), v = [Math.floor(s / 86400), Math.floor(s % 86400 / 3600), Math.floor(s % 3600 / 60), s % 60], bs = c.querySelectorAll("b");
      for (var i = 0; i < 4 && i < bs.length; i++) { var t = (v[i] < 10 ? "0" : "") + v[i]; if (bs[i].textContent !== t) { bs[i].textContent = t; if (i === 3 && !reduceMotion) { bs[i].classList.remove("tick"); void bs[i].offsetWidth; bs[i].classList.add("tick"); } } }
    });
  }, 1000);
  // the League's controls: prize bars, the simulator and the rules
  document.addEventListener("click", function (e) {
    var b = e.target.closest(".wl-bar");
    if (b) { var tip = $("wl-tip"); document.querySelectorAll(".wl-bar.on").forEach(function (x) { x.classList.remove("on"); }); b.classList.add("on"); if (tip) tip.textContent = b.dataset.tip; return; }
    var sb = e.target.closest("[data-sim]");
    if (sb) { wl.sim = sb.dataset.sim; document.querySelectorAll("[data-sim]").forEach(function (x) { x.classList.toggle("on", x === sb); }); drawSim(); }
  });
  document.addEventListener("mouseover", function (e) { var b = e.target.closest && e.target.closest(".wl-bar"); if (b) { var tip = $("wl-tip"); if (tip) tip.textContent = b.dataset.tip; } });
  document.addEventListener("input", function (e) { if (e.target.id === "wl-reg") { wl.reg = +e.target.value; drawSim(); } });
  document.addEventListener("toggle", function (e) { if (e.target.classList && e.target.classList.contains("wl-rules")) wl.open = e.target.open; }, true);

  document.addEventListener("click", async function (e) {
    var b = e.target.closest("[data-play]");
    if (b) { e.preventDefault(); var g = $("game"); if (g) g.scrollIntoView({ behavior: "smooth", block: "start" }); P.start(b.dataset.play); return; }
    if (e.target.closest("[data-rw-wallet]")) { await P.connectWallet(); await refreshMe(); renderRewards(); }
  });

  // ---------- boot ----------
  // the sheets live at the top of the page so nothing (like the phone tab bar) can sit above them
  ["shop", "checkout"].forEach(function (id) { var el = $(id); if (el) document.body.appendChild(el); });
  (async function () {
    if (!(await loadCatalog())) return;
    renderBar();
    await refreshMe();
    loadRewards();
    setInterval(function () { if (!resting()) loadRewards(); }, 60000);   //MC 2026-10-11 not during a game
    var hm = shopHash();
    if (hm) openShop(hm[1]);
    else if (pendingOpen) openShop(pendingOpen);
    pendingOpen = null;
    // back from a card payment, a wallet app, or a reload while a payment was confirming: pick the order up again
    var m = /[?&]order=([a-f0-9]{16})/.exec(location.search), pend = m ? m[1] : null, psig = "";
    try {
      var saved = JSON.parse(localStorage.getItem("shy-order") || "null");
      if (!saved) { var old = sessionStorage.getItem("shy-order"); if (old) saved = { id: old, sig: "", ts: Date.now() }; }
      if (saved && Date.now() - (saved.ts || 0) > 2 * 86400000) { forget(); saved = null; }
      var bg = false;
      if (saved && (!pend || pend === saved.id)) { pend = saved.id; psig = saved.sig || ""; bg = !m; }
    } catch (e) {}
    if (pend && bg && psig) quiet(pend, psig);
    else if (pend && bg) forget();   // never paid: nothing to pick up
    else if (pend) {
      var j = await api({ a: "check", order: pend, sig: psig });
      // opened inside a wallet app: this browser needs the wallet's profile before it can see the order
      if (m && !j.ok && P.provider()) { await P.connectWallet(); await refreshMe(); j = await api({ a: "check", order: pend, sig: psig }); }
      if (j.ok && j.status === "paid") { openShop(); paid({ name: "" }, j); }
      else if (j.ok && (j.status === "failed" || j.status === "expired")) forget();
      else if (!j.ok && j.status === 404) forget();
      else if (j.ok && (j.status === "open" || j.status === "late") && j.order && (m || psig)) {
        openShop();
        var p = productById(j.order.product) || { id: j.order.product, name: j.order.name || "", usd: j.order.usd };
        co = co || $("checkout"); co.hidden = false; order = j.order; sentSig = psig;
        drawCheckout(p, "pay", j.order.cur === "CARD" ? { order: j.order, msg: "Waiting for the card payment to confirm…" } : { order: j.order, msg: psig ? "Sent. Confirming on Solana…" : "" });
        if (psig) setStatusHtml("Sent. Confirming on Solana…" + txLink(psig));
        watch(pend, p, !!psig);
      }
    }
  })();
  //MC 2026-10-10 links into the shop: /play#shop, /play#shop-<tab> (or tab:item, like #shop-style:skin), and the short
  //   /shop#spend or /shop#get, which the server turns into /play?shop with the # part kept
  function shopHash() {
    var h = decodeURIComponent(location.hash || "");
    var m = /^#shop(?:-([\w:]+))?$/.exec(h);
    if (m) return m;
    if (/[?&]shop\b/.test(location.search)) { m = /^#([\w:]+)$/.exec(h); return [h, m ? m[1] : ""]; }
    return null;
  }
  window.addEventListener("hashchange", function () { var m = shopHash(); if (m) openShop(m[1]); });
})();
