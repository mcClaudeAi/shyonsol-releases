// The live mint tracker under the NFTs hero (api/mints.php): a ring that fills as the 1,335 Shadows mint, the numbers
// around it, the newest mints sliding in as they happen (with a flash and a toast when one lands while you watch), the
// Auras minted so far, mints per day for two weeks, and the biggest collectors. Tap a mint to see it up close.
// Asks again every 20 seconds while the tracker is on screen and the tab is open.
//MC 2026-10-15 first version
(function () {
  "use strict";
  var box = document.getElementById("mint-live");
  if (!box) return;
  var API = "/api/mints.php?a=stats", AV = (document.querySelector('script[src*="minttrack.js"]') || {}).src || "";
  AV = /\?v=([^&]+)/.exec(AV); AV = AV ? "?v=" + AV[1] : "";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var AURA = { "crimson glow": ["crimson", "#ff3b5c"], "electric cyan": ["cyan", "#4cc9f0"], "lightning aura": ["lightning", "#ffe066"], "money aura": ["money", "#f2c35b"], "btc aura": ["btc", "#f7931a"] };
  var SKIN = { crimson: "skin_crimson", cyan: "skin_cyan", lightning: "skin_storm", money: "skin_gold", btc: "skin_btc", none: "skin_void" };
  function au(name) { return AURA[String(name || "").toLowerCase()] || ["none", "#a78bfa"]; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function ago(t) {
    if (!t) return "before tracking";
    var s = Math.max(1, Math.round(Date.now() / 1000 - t));
    return s < 60 ? "just now" : s < 3600 ? Math.round(s / 60) + "m ago" : s < 86400 ? Math.round(s / 3600) + "h ago" : Math.round(s / 86400) + "d ago";
  }
  function fallback(x) { return "/assets/art/skins/" + SKIN[au(x.aura)[0]] + ".svg" + AV; }
  var D = null, seenTop = null, timer = 0, lastOk = 0;

  // ---------- the ring ----------
  function ring(pct) {
    var c = box.querySelector(".mt-ring-fg"); if (!c) return;
    c.style.strokeDashoffset = String(Math.round(565 * (1 - Math.min(1, pct))));
    box.querySelectorAll(".mt-ms").forEach(function (m) { m.classList.toggle("hit", pct >= +m.dataset.at); });
  }
  function countTo(el, to) {
    var from = +(el.dataset.v || 0); el.dataset.v = to;
    if (reduce || from === to) { el.textContent = fmt(to); return; }
    var t0 = performance.now(), dur = from ? 700 : 1400;
    (function step(now) { var k = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(from + (to - from) * e)); if (k < 1) requestAnimationFrame(step); })(t0);
  }

  // ---------- drawing ----------
  function draw(first) {
    var pct = D.minted / D.total;
    countTo(box.querySelector("[data-mt=minted]"), D.minted);
    countTo(box.querySelector("[data-mt=left]"), D.left);
    countTo(box.querySelector("[data-mt=holders]"), D.holders);
    countTo(box.querySelector("[data-mt=last24]"), D.last24);
    box.querySelector("[data-mt=pct]").textContent = (Math.floor(pct * 1000) / 10) + "%";
    box.querySelector("[data-mt=leftline]").textContent = D.left > 0 ? "Only " + fmt(D.left) + " Shadows left" : "Sold out";
    setTimeout(function () { ring(pct); }, first ? 120 : 0);
    // the newest mints
    var feed = box.querySelector("[data-mt=feed]");
    var fresh = seenTop === null ? [] : D.recent.filter(function (x) { return seenTop.indexOf(x.n) < 0; });
    feed.innerHTML = D.recent.slice(0, 8).map(function (x, i) {
      var a = au(x.aura), isNew = fresh.some(function (f) { return f.n === x.n; });
      return '<button type="button" class="mt-m' + (isNew ? " new" : "") + '" data-mt-i="' + i + '" style="--mt-c:' + a[1] + '">' +
        '<span class="mt-mi"><img src="' + esc(x.img || fallback(x)) + '" alt="" loading="lazy" onerror="this.onerror=null;this.src=\'' + fallback(x) + '\'"></span>' +
        '<span class="mt-mt"><b data-i18n-skip>#' + esc(x.n) + '</b><small><i></i>' + esc(x.aura || "Aura") + '</small></span>' +
        '<span class="mt-mw"><small>' + ago(x.t) + '</small><small class="mt-own" data-i18n-skip>' + esc(x.owner) + '</small></span></button>';
    }).join("");
    if (fresh.length && seenTop !== null) toast(fresh[0]);
    seenTop = D.recent.map(function (x) { return x.n; });
    // Auras minted so far
    var max = Math.max.apply(null, D.auras.map(function (x) { return x.n; }).concat([1]));
    box.querySelector("[data-mt=auras]").innerHTML = D.auras.slice(0, 6).map(function (x) {
      var a = au(x.a), p = D.minted ? Math.round(x.n / D.minted * 1000) / 10 : 0;
      return '<li style="--mt-c:' + a[1] + '" tabindex="0"><span class="mt-an"><i></i>' + esc(x.a) + '</span><span class="mt-ab"><i style="width:' + Math.max(3, Math.round(x.n / max * 100)) + '%"></i></span><b>' + fmt(x.n) + '</b><small>' + p + '%</small></li>';
    }).join("");
    // mints per day
    var dm = Math.max.apply(null, D.days.map(function (x) { return x.n; }).concat([1]));
    var any = D.days.some(function (x) { return x.n > 0; });
    box.querySelector("[data-mt=days]").innerHTML = any ? D.days.map(function (x) {
      var d = new Date(x.d + "T12:00:00Z"), lbl = d.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" });
      return '<span class="mt-d" title="' + esc(lbl + ": " + x.n + (x.n === 1 ? " mint" : " mints")) + '"><i style="height:' + Math.max(4, Math.round(x.n / dm * 100)) + '%"></i><small>' + x.n + '</small></span>';
    }).join("") : '<p class="mt-empty">Mints per day show here from the first day of tracking.</p>';
    // collectors
    box.querySelector("[data-mt=top]").innerHTML = D.top.map(function (x, i) { return '<li><span>' + (i + 1) + '</span><b data-i18n-skip>' + esc(x.w) + '</b><em>' + fmt(x.n) + '</em></li>'; }).join("");
    lastOk = Date.now(); stamp();
  }
  function stamp() { var s = box.querySelector("[data-mt=at]"); if (s && lastOk) { var k = Math.round((Date.now() - lastOk) / 1000); s.textContent = k < 5 ? "Updated just now" : "Updated " + k + "s ago"; } }
  function toast(x) {
    var t = document.createElement("div"); var a = au(x.aura);
    t.className = "mt-toast"; t.style.setProperty("--mt-c", a[1]);
    t.innerHTML = '<img src="' + esc(x.img || fallback(x)) + '" alt="" onerror="this.onerror=null;this.src=\'' + fallback(x) + '\'"><span><b>Just minted</b><small data-i18n-skip>#' + esc(x.n) + (x.aura ? " · " + esc(x.aura) : "") + '</small></span>';
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add("in"); });
    setTimeout(function () { t.classList.remove("in"); setTimeout(function () { t.remove(); }, 500); }, 4200);
  }

  // ---------- a mint up close ----------
  function open(i) {
    var x = D.recent[i]; if (!x) return;
    var a = au(x.aura), src = x.img || fallback(x);
    var o = document.createElement("div"); o.className = "mt-ov"; o.setAttribute("role", "dialog"); o.setAttribute("aria-modal", "true"); o.style.setProperty("--mt-c", a[1]);
    o.innerHTML = '<div class="mt-ov-in"><button type="button" class="mt-x" aria-label="Close">&times;</button><div class="mt-ov-art">' +
      (window.ShyLiving ? ShyLiving.html(src, { aura: a[0], cls: "enter", size: "min(64vw,260px)", alt: "Shytoshi Shadow #" + x.n, fb: fallback(x) }) : '<img src="' + esc(src) + '" alt="">') +
      '</div><span class="mt-k">Shytoshi Shadow</span><h3 data-i18n-skip>#' + esc(x.n) + '</h3><div class="mt-chips"><span><i></i>' + esc(x.aura || "Aura") + '</span>' + (x.rank ? '<span><small>Rarity</small> <b data-i18n-skip>' + esc(String(x.rank).replace(/^#?/, "#")) + '</b></span>' : "") + '</div>' +
      '<p class="mt-ov-l"><span>Minted ' + ago(x.t) + '</span> · <span data-i18n-skip>' + esc(x.owner) + '</span></p>' +
      '<div class="mt-ov-b">' + (x.asset ? '<a class="btn btn-line btn-sm" href="https://solscan.io/token/' + esc(x.asset) + '" target="_blank" rel="noopener">See it on Solana</a>' : "") + '<a class="btn btn-red btn-sm" href="https://launchmynft.io/mint/shyshadows" target="_blank" rel="noopener">Mint yours</a></div></div>';
    document.body.appendChild(o);
    var close = function () { o.remove(); document.removeEventListener("keydown", key); };
    var key = function (e) { if (e.key === "Escape") close(); };
    o.addEventListener("click", function (e) { if (e.target === o || e.target.closest(".mt-x")) close(); });
    document.addEventListener("keydown", key);
    o.querySelector(".mt-x").focus();
  }
  box.addEventListener("click", function (e) { var b = e.target.closest("[data-mt-i]"); if (b) open(+b.dataset.mtI); });

  // ---------- asking for news ----------
  var onScreen = true;
  function load(first) {
    fetch(API, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok) { if (first) box.classList.add("mt-off"); return; }
      box.classList.remove("mt-off", "mt-wait"); D = j; draw(first);
    }).catch(function () { if (first) box.classList.add("mt-off"); });
  }
  function loop() { clearTimeout(timer); timer = setTimeout(function () { if (!document.hidden && onScreen) load(false); loop(); }, 20000); }
  if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { onScreen = es[0].isIntersecting; }).observe(box);
  setInterval(stamp, 5000);
  load(true); loop();
})();
