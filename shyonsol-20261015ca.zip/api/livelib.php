<?php
// Live match rooms: seats, turns, bots covering for players who drop, and recording results.
// Shared by api/live.php (the players) and the tournament runner (api/tourney.php). Include after economy.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }
if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/statslib.php';
require_once __DIR__ . '/fairplay.php';   //MC 2026-10-10 Fair Play records
require_once __DIR__ . '/bosslib.php';   //MC 2026-10-12 the Shogun boss bot
require_once __DIR__ . '/fairlib.php';   //MC 2026-10-15 sealed deals (provably fair)

if (!defined('ROOMS')) define('ROOMS', DATA_DIR . '/rooms');
if (!defined('LOBBY')) define('LOBBY', DATA_DIR . '/lobby.php');
const SEATS = 4;
const TURN_SECONDS = 30;
const FIRST_TURN_BONUS = 10;
const QUICK_WAIT = 30;         // public rooms start this long after opening, bots fill empty seats
const QUICK_HOLD = 60;         //MC 2026-10-15 Wait for real players adds this much to a quick match's countdown
const QUICK_HOLD_MAX = 180;    //   up to this long after the room opened, then bots fill the empty seats as before
function quick_starts($room) { return max($room['created'] + QUICK_WAIT, (float)($room['hold'] ?? 0)); }
const PRIVATE_TTL = 1800;      // unused private rooms expire
const GONE_AFTER = 20;         // seconds without a poll before a bot covers for you
const BOT_THINK = 1.1;
const AFTER_PLAY = 2.1;
const AFTER_CLAIM = 0.5;
const AFTER_SKIP = 1.3;
const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const REACTIONS = 6;

function now() { return microtime(true); }
function room_file($code) { return ROOMS . '/' . $code . '.php'; }
function valid_code($c) { return is_string($c) && preg_match('/^[' . CODE_CHARS . ']{5}$/', $c); }
require_once __DIR__ . '/codeclean.php';   //MC 2026-10-15 rude-word check for room codes
function new_code() {
    for ($t = 0; $t < 50; $t++) { $s = ''; for ($i = 0; $i < 5; $i++) $s .= CODE_CHARS[random_int(0, strlen(CODE_CHARS) - 1)]; if (code_clean($s)) return $s; }
    return $s;
}

// Lock one room file for the whole request so ticks and moves never collide.
function with_room($code, $fn, $create = false) {
    if (!is_dir(ROOMS)) @mkdir(ROOMS, 0755, true);
    $f = room_file($code);
    if (!$create && !is_file($f)) return ['err' => 'Room not found. It may have ended.', 'code' => 404];
    $lf = fopen($f . '.lock', 'c');
    if (!$lf) return ['err' => 'storage unavailable', 'code' => 500];
    flock($lf, LOCK_EX);
    try {
        $room = load($f);
        if (!$room && !$create) return ['err' => 'Room not found. It may have ended.', 'code' => 404];
        $before = json_encode($room);
        $res = $fn($room);
        if ($room && json_encode($room) !== $before) save($f, $room);
        return $res;
    } finally { flock($lf, LOCK_UN); fclose($lf); }
}

function player_profile($body) {
    $pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
    $name = clean_name($body['name'] ?? '');
    if ($name === null) fail(name_problem($body['name'] ?? ''));
    $avatar = preg_match('/^\d{1,4}$/', (string)($body['avatar'] ?? '')) ? (string)$body['avatar'] : '';
    $kh = hash('sha256', $key);
    if (player_banned($pid)) fail(BANNED_MSG, 403);   //MC 2026-10-11 no live tables for a banned profile
    //MC 2026-10-11 any Shadow / $SHY lookup that's due happens here, before the lock (see holder_prefetch)
    holder_prefetch($pid, false, $kh);
    $check = with_lock(function () use ($pid, $kh, $name, $avatar) {
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return 'not your profile';
        if (!empty($players[$pid]['nlock'])) $name = $players[$pid]['name'];   // a name the admin set
        foreach ($players as $id => $p) if ($id !== $pid && strcasecmp($p['name'] ?? '', $name) === 0) return 'That name is taken. Try another.';
        $va = verified_avatar($pid, $avatar);
        // cosmetics everyone at the table sees, and the reactions this player has unlocked
        $eco = load(ECO); $holders = load(HOLDERS);
        $acc = eco_get($eco, $pid); $tier = holder_tier($holders[$pid] ?? null);
        funnel_mark($pid, 's');
        $cos = eco_public($acc, $tier, true);
        if ($rs = rank_show($players[$pid] ?? [])) $cos['rank'] = $rs['tier'];   // everyone at the table sees their ranked tier
        if (is_seeker($holders[$pid] ?? null)) $cos['sk'] = 1;   //MC 2026-10-15 the Seeker badge at the table
        return array_merge($va, [$name, $cos, eco_reacts($acc, $tier)]);
    });
    if (is_string($check)) fail($check, 409);
    return ['pid' => $pid, 'kh' => $kh, 'name' => $check[2], 'avatar' => $check[0], 'holder' => $check[1], 'cos' => $check[3], 'reacts' => $check[4]];
}

function limit($what, $max, $window) {
    $ok = with_lock(function () use ($what, $max, $window) {
        $limits = load(LIMITS);
        $ok = rate_ok($limits, $what . ':' . client_ip(), $max, $window);
        save(LIMITS, $limits);
        return $ok;
    });
    if (!$ok) fail('Slow down a little and try again.', 429);
}

function seat_add(&$room, $prof) {
    // same player coming back (refresh, new tab) gets their seat back
    foreach ($room['seats'] as $i => &$s) {
        if (!empty($s['pid']) && $s['pid'] === $prof['pid']) {
            $secret = bin2hex(random_bytes(16));
            fp_seen($s);   //MC 2026-10-10 Fair Play
            $s['sh'] = hash('sha256', $secret); $s['seen'] = now(); $s['gone'] = false; $s['name'] = $prof['name']; $s['avatar'] = $prof['avatar']; $s['holder'] = $prof['holder']; $s['cos'] = $prof['cos'] ?? []; $s['reacts'] = $prof['reacts'] ?? [];
            //MC 2026-10-15 a player who left (or was moved out by another room) and came back got their seat but stayed a bot:
            //   leaving set human off and nothing turned it back on, so the bot kept playing while they watched. Coming back
            //   now takes the seat back as a person, waiting or mid-match. A tournament walkout stays a forfeit.
            if (empty($s['tleft'])) { if (empty($s['human'])) $room['ver']++; $s['human'] = true; $s['away'] = false; unset($s['style']); }
            return [$i, $secret];
        }
    }
    unset($s);
    //MC 2026-10-15 late join (an idea from Tommy Shiby and ZATO in the chat): someone who gets the room code or link in
    //   the first two minutes of a match takes over a bot's seat instead of having to wait for a new room. They play on
    //   from where the bot was (its hand and Regions) and the match counts for them. Never a tournament table or a
    //   Shogun match, never a seat a player left, and never the bot whose turn it is right now.
    if ($room['status'] === 'playing') {
        $i = late_seat($room);
        if ($i < 0) return null;
        $bot = str_replace(' (bot)', '', (string)$room['seats'][$i]['name']);
        $secret = bin2hex(random_bytes(16));
        $room['seats'][$i] = ['name' => $prof['name'], 'avatar' => $prof['avatar'], 'holder' => $prof['holder'] ?? false, 'pid' => $prof['pid'], 'kh' => $prof['kh'], 'human' => true, 'cos' => $prof['cos'] ?? [], 'reacts' => $prof['reacts'] ?? [],
            'sh' => hash('sha256', $secret), 'seen' => now(), 'gone' => false, 'away' => false, 'strikes' => 0, 'late' => $bot];
        fp_seen($room['seats'][$i]);
        if (isset($room['g']['players'][$i])) $room['g']['players'][$i]['name'] = $prof['name'];
        say($room['g'], $i, $prof['name'] . ' jumped in and took over from ' . $bot . '.', 'info');
        $room['ver']++;
        return [$i, $secret, $bot];
    }
    if ($room['status'] !== 'waiting' || count($room['seats']) >= SEATS) return null;
    $secret = bin2hex(random_bytes(16));
    $room['seats'][] = ['name' => $prof['name'], 'avatar' => $prof['avatar'], 'holder' => $prof['holder'] ?? false, 'pid' => $prof['pid'], 'kh' => $prof['kh'], 'human' => true, 'cos' => $prof['cos'] ?? [], 'reacts' => $prof['reacts'] ?? [],
        'sh' => hash('sha256', $secret), 'seen' => now(), 'gone' => false, 'away' => false, 'strikes' => 0];
    fp_seen($room['seats'][count($room['seats']) - 1]);   //MC 2026-10-10 Fair Play
    $room['ver']++;
    return [count($room['seats']) - 1, $secret];
}
//MC 2026-10-15 late join: the bot seat someone joining now would take, or -1 (see seat_add)
const LATE_JOIN = 120;   // seconds after the match starts
function late_seat($room) {
    if (($room['status'] ?? '') !== 'playing' || !empty($room['tourney']) || !empty($room['boss']) || empty($room['g'])) return -1;
    if (now() - (float)($room['started'] ?? 0) > LATE_JOIN) return -1;
    foreach ($room['seats'] as $i => $s) {
        if (!empty($s['human']) || !empty($s['pid']) || !empty($s['boss'])) continue;   // only seats a bot had from the start
        if ((int)($room['g']['turn'] ?? -1) === $i) continue;
        return $i;
    }
    return -1;
}
function new_room($public) {
    return ['public' => $public, 'status' => 'waiting', 'created' => now(), 'seats' => [], 'g' => null, 'phase' => 'start',
        'next' => 0, 'turnStart' => 0, 'deadline' => 0, 'ver' => 1, 'reacts' => [], 'result' => null];
}
function auth(&$room, $body) {
    $seat = (int)($body['seat'] ?? -1); $secret = (string)($body['secret'] ?? '');
    if (!isset($room['seats'][$seat]) || empty($room['seats'][$seat]['sh']) || !hash_equals($room['seats'][$seat]['sh'], hash('sha256', $secret))) return -1;
    return $seat;
}
function humans($room) { return count(array_filter($room['seats'], fn($s) => !empty($s['human']))); }

function start_game(&$room) {
    if (function_exists('track')) track('live_rooms');   //MC 2026-10-09 live matches started, for the reports
    //MC 2026-10-09 the bots that fill empty seats come from the full cast of rivals (game.js PERSONAS), not the
    //same six every match. Live games run here on the server, so there's no seed to keep in step with.
    $bots = ['Neon Ronin', 'Iron Monk', 'Paper Tiger', 'Night Crane', 'Jade Fox', 'Silent Oni', 'Ash Kitsune', 'Velvet Shogun', 'Static Monk',
        'Copper Crane', 'Hollow Ronin', 'Rain Tiger', 'Ember Oni', 'Glass Fox', 'Midnight Heron', 'Cobalt Samurai', 'Lantern Monk', 'Golden Tanuki',
        'Thunder Kappa', 'Frost Ninja', 'Red Daruma', 'Shadow Tengu', 'Ivory Tiger', 'Obsidian Crane', 'Moon Kitsune', 'Storm Oni', 'Rust Shogun',
        'Smoke Daimyo', 'Silk Viper', 'Ghost Lantern', 'Willow Sage', 'Koi Ronin', 'Dusk Tiger', 'Paper Crane'];
    shuffle($bots);
    $styles = ['hawk', 'builder', 'wild']; shuffle($styles);
    $k = 0;
    while (count($room['seats']) < (!empty($room['boss']) ? 2 : SEATS)) {   //MC 2026-10-12 a boss match is just you and the Shogun
        $room['seats'][] = ['name' => $bots[$k] . ' (bot)', 'avatar' => '', 'human' => false, 'style' => $styles[$k % 3], 'away' => false, 'gone' => false];
        $k++;
    }
    $names = array_map(fn($s) => $s['name'], $room['seats']);
    $sty = array_map(fn($s) => $s['style'] ?? '', $room['seats']);
    $season = function_exists('season_deck_at') ? season_deck_at() : [];
    eng_season($season);
    //MC 2026-10-15 the deal comes from a sealed seed (fairlib.php): every seat sees its hash from the first turn, and the
    //   seed itself when the match ends, so anyone can rebuild the opening deal and check nothing was changed after it.
    //   Only the deal is seeded; what happens during the match goes back to random_int right after.
    $fair = fair_live_begin();
    $room['g'] = eng_new($names, $sty);
    rnd_seed(null);
    eng_season([]);
    $room['fair'] = $fair + ['names' => $names, 'styles' => $sty, 'season' => $season, 'edge' => 0];
    //MC 2026-10-12 the Shogun's edge: extra cards in its opening hand (Admin, The Shogun), shown to the player
    if (!empty($room['boss'])) foreach ($room['seats'] as $i => $s) if (!empty($s['boss']) && ($room['boss']['edge'] ?? 0) > 0) { give_chaos($room['g'], $i, (int)$room['boss']['edge']); $room['fair']['edge'] = [$i, (int)$room['boss']['edge']]; }
    $room['status'] = 'playing';
    $room['phase'] = 'start';
    $room['next'] = now() + 1.8;
    $room['started'] = now();
    say($room['g'], $room['g']['start'], $room['g']['players'][$room['g']['start']]['name'] . ' goes first.', 'info');
    $room['ver']++;
    lobby_drop($room['code']);
}

function finish_turn(&$room, $after) {
    $room['botPlays'] = 0;
    $over = eng_end_turn($room['g']);
    $room['phase'] = 'start';
    $room['deadline'] = 0;
    $room['next'] = now() + $after;
    $room['ver']++;
    if ($over) end_game($room);
}

function tick(&$room) {
    $t = now();
    // anyone who stopped polling gets a bot until they come back
    foreach ($room['seats'] as &$s) {
        if (!empty($s['human']) && !$s['gone'] && $t - ($s['seen'] ?? $t) > GONE_AFTER) { $s['gone'] = true; $room['ver']++; }
    }
    unset($s);
    if ($room['status'] === 'waiting') {
        if ($room['public'] && (humans($room) >= SEATS || $t >= quick_starts($room)) && humans($room) > 0) start_game($room);
        // a tournament table starts when everyone seated there has arrived, or after the wait, with bots for no-shows
        if (!empty($room['tourney'])) {
            $all = true;
            foreach ($room['seats'] as $s) if (!empty($s['tseat']) && !empty($s['human']) && empty($s['seen'])) $all = false;
            if ($all || $t >= ($room['tstart'] ?? 0)) {
                // a bot plays the seat of anyone not here yet; they can still take it over until the table ends
                foreach ($room['seats'] as &$s) if (!empty($s['tseat']) && !empty($s['human']) && empty($s['seen'])) { $s['away'] = true; $s['gone'] = true; $s['ns'] = 1; $s['style'] = 'wild'; }
                unset($s);
                start_game($room);
            }
        }
        return;
    }
    if ($room['status'] !== 'playing') return;
    for ($guard = 0; $guard < 12 && $room['status'] === 'playing'; $guard++) {
        if ($t < $room['next']) return;
        $g = &$room['g'];
        $pi = $g['turn'];
        $seat = $room['seats'][$pi];
        if ($room['phase'] === 'start') {
            $skipped = eng_start_turn($g);
            $room['ver']++;
            if ($skipped) { finish_turn($room, AFTER_SKIP); $t = now(); continue; }
            $room['phase'] = 'act';
            $room['turnStart'] = $t;
            $auto = empty($seat['human']) || $seat['away'] || $seat['gone'];
            $first = empty($room['firstTurnDone'][$pi]);
            $room['deadline'] = $auto ? 0 : $t + TURN_SECONDS + ($first ? FIRST_TURN_BONUS : 0);
            $room['next'] = $t + ($auto ? BOT_THINK : AFTER_CLAIM);
            continue;
        }
        // phase act
        $auto = empty($seat['human']) || $seat['away'] || $seat['gone'];
        if (!$auto && $t < $room['deadline']) return;
        if (!empty($seat['human']) && $auto) $room['covered'][$pi] = 1;   //MC 2026-10-12 a bot played this player's turn (no boss reward then)
        if (!$auto) {
            $room['covered'][$pi] = 1;
            $room['seats'][$pi]['strikes'] = ($room['seats'][$pi]['strikes'] ?? 0) + 1;
            say($g, $pi, $seat['name'] . ' ran out of time.', 'info');
            if ($room['seats'][$pi]['strikes'] >= 2) { $room['seats'][$pi]['away'] = true; say($g, $pi, 'A bot is covering for ' . $seat['name'] . ' until they come back.', 'info'); }
        }
        // one card per tick so everyone sees each play; Double Disaster and Blitz keep the turn going
        $can = $g['plays'] > 0 && !$g['over'] && ($room['botPlays'] ?? 0) < 8;
        if (!empty($seat['boss'])) $ch = $can ? boss_pick($g, $pi, (int)($room['boss']['think'] ?? 700)) : null;   //MC 2026-10-12 the Shogun thinks for itself
        else $ch = $can ? eng_bot($g, $pi, empty($seat['human']) ? 0.6 : 0.3) : null;
        $played = $ch ? eng_play($g, $pi, $ch['hand'], $ch['target']) : false;
        $room['firstTurnDone'][$pi] = 1;
        if ($played && $g['plays'] > 0 && !$g['over']) {
            $room['botPlays'] = ($room['botPlays'] ?? 0) + 1;
            $room['deadline'] = 0;
            $room['next'] = now() + AFTER_PLAY;
            $room['ver']++;
            $t = now();
            unset($g);
            continue;
        }
        if (!$played && $g['played']) say($g, $pi, $seat['name'] . ' ends the turn.', 'info');
        finish_turn($room, $played ? AFTER_PLAY : AFTER_CLAIM);
        $t = now();
        unset($g);
    }
}

function end_game(&$room) {
    // a tournament player who never took their seat gets nothing from the bot's game and can't move on
    foreach ($room['seats'] as &$s) if (!empty($s['ns'])) { $s['human'] = false; $s['name'] .= ' (no show)'; $s['sh'] = ''; }
    unset($s);
    $g = $room['g'];
    $room['status'] = 'over';
    $room['ended'] = now();
    try { fair_live_keep($room); } catch (\Throwable $e) {}   //MC 2026-10-15 the sealed deal outlives the room
    $w = eng_winners($g);
    //MC 2026-10-13 reactions fired from a hand during the match count as plays for mastery, like cards chosen in act
    foreach ($g['pcx'] ?? [] as [$si, $cid]) $room['pc'][$si][] = $cid;
    $hum = humans($room);
    $res = [];
    foreach ($room['seats'] as $i => $s) {
        $regions = count($g['players'][$i]['regions']);
        $result = in_array($i, $w, true) ? (count($w) > 1 ? 'tie' : 'win') : 'loss';
        // beating real people is worth more: +20 per other human in the match
        $pts = $regions * 5 + ($result === 'win' ? 100 : ($result === 'tie' ? 50 : 0));
        if ($result !== 'loss') $pts += 20 * max(0, $hum - 1);
        $res[$i] = ['regions' => $regions, 'result' => $result, 'points' => !empty($s['human']) ? $pts : 0];
    }
    $room['result'] = ['winners' => $w, 'seats' => $res, 'standings' => eng_standings($g)];
    // record every human's result on the leaderboard (the server watched the whole game, so these are trusted)
    with_lock(function () use (&$room, &$res, $hum) {
        $players = load(PLAYERS);
        archive_weeks($players);
        rewards_freeze($players);
        //MC 2026-10-10 Fair Play rules: only real rivals make a match count for the League and Ranked, and only they add
        //   the +20. A rival who left, shares this player's network and browser, is a brand new account, or has already
        //   given this player 3 League matches today doesn't count. Worked out on the board as it was before this match.
        $riv = fp_rivals($room, $players);
        foreach ($riv as $i => $rv) {
            if ($res[$i]['result'] === 'loss') continue;
            $res[$i]['points'] = $res[$i]['regions'] * 5 + ($res[$i]['result'] === 'win' ? 100 : 50) + 20 * count($rv['ok']);
            $room['result']['seats'][$i]['points'] = $res[$i]['points'];
        }
        $awards = [];
        $wk = week_key();
        foreach ($room['seats'] as $i => $s) {
            if (empty($s['human']) || empty($s['pid'])) continue;
            $pid = $s['pid'];
            $p = $players[$pid] ?? ['kh' => $s['kh'], 'points' => 0, 'wins' => 0, 'games' => 0, 'best' => 0, 'since' => time()];
            if (!key_ok($pid, $s['kh'], $players)) continue;
            if (($p['wk'] ?? '') !== $wk) { $p['wk'] = $wk; $p['wpts'] = 0; }
            $r = $res[$i];
            //MC 2026-10-12 a boss match only goes on the Shogun record (and pays boss Koban): no points, games, wins, live stats,
            //   League, Ranked or 15 Club, so nobody climbs the boards by grinding the boss
            if (!empty($room['boss'])) {
                //MC 2026-10-13 the match still goes on the player's own record: the continue below used to skip game_log
                //   entirely, so boss matches never showed in All matches and share.php returned 409 for them. The row
                //   carries the Shogun's Regions too (v), so losses show the full score on the profile.
                game_log($p, 'live', $r['result'], $r['regions'], 0);
                $p['hist'][0]['b'] = 1;
                foreach ($room['seats'] as $bj => $bs) if (!empty($bs['boss'])) $p['hist'][0]['v'] = count($room['g']['players'][$bj]['regions']);
                $p['last'] = time(); $players[$pid] = $p;
                $awards[$i] = ['pid' => $pid, 'result' => $r['result'], 'league' => 0, 'lwhy' => '', 'regions' => $r['regions'], 'cards' => [], 'rk' => null, 'bounty' => null, 'boss' => boss_result($room, $i, $pid, $p['name'] ?? $s['name'], $r)];
                $res[$i]['points'] = 0; $room['result']['seats'][$i]['points'] = 0;
                continue;
            }
            // keep a name the admin set; never take a name someone else claimed while this match was running
            $clash = false;
            foreach ($players as $id => $o) if ($id !== $pid && strcasecmp($o['name'] ?? '', $s['name']) === 0) $clash = true;
            if (empty($p['nlock']) && empty($p['nprof']) && !$clash) $p['name'] = $s['name'];
            elseif (empty($p['name'])) $p['name'] = substr($s['name'], 0, 12) . ' ' . random_int(100, 999);
            $p['avatar'] = $s['avatar'];
            $p['points'] += $r['points']; $p['wpts'] = ($p['wpts'] ?? 0) + $r['points'];
            $p['lpts'] = ($p['lpts'] ?? 0) + $r['points'];
            $p['games']++; $p['pvp_g'] = ($p['pvp_g'] ?? 0) + 1;
            //MC 2026-10-15 a first-ever game is a new player: welcome them in the Telegram chat (tg_join)
            if ((int)$p['games'] === 1 && function_exists('tg_join')) tg_join($pid, $p['name'] ?? $s['name'], ['mode' => 'live', 'result' => $r['result'], 'regions' => $r['regions']], count(array_filter($players, fn($x) => !empty($x['games']))) + (empty($players[$pid]['games']) ? 1 : 0));
            if ($r['result'] === 'win') { $p['wins']++; $p['pvp_w'] = ($p['pvp_w'] ?? 0) + 1; }
            $p['best'] = max($p['best'], $r['regions']);
            $p['last'] = time();
            $p['holder'] = !empty($s['holder']);
            // prize league: matches with at least two real players, up to 10 a day (stops farming against bots)
            // lwhy tells the player why a match didn't count: 'bots' (no other real player at the table) or 'cap' (10 already today)
            $lgain = 0; $lwhy = '';
            //MC 2026-10-10 the admin can stop private invite rooms counting for the League (Fair Play page); public, tournament and
            //   quick matches always count
            $privOk = !empty($room['public']) || !empty($room['tourney']) || fp_priv_league();
            $real = count($riv[$i]['ok'] ?? []);
            if ($hum >= 2 && !$privOk) $lwhy = 'private';
            elseif ($hum >= 2 && !$real) $lwhy = $riv[$i]['why'] ?: 'bots';
            elseif ($hum >= 2) {
                fp_pair_count($p, $room, $riv[$i]['ok']);
                if (($p['lgd']['d'] ?? '') !== today()) $p['lgd'] = ['d' => today(), 'n' => 0];
                if ($p['lgd']['n'] < 10) { $p['lgd']['n']++; $lgain = league_add($p, $r['points']); } else $lwhy = 'cap';
            } else $lwhy = 'bots';
            // ranked: where this seat finished among everyone at the table (bots too), for matches with real rivals
            //MC 2026-10-10 placed by the game's own standings (Regions, then cards in hand), so losing a Regions tie on cards
            //   is 2nd, not 1st. Counting Regions alone put that player 1st, which isn't a ranked step (-15 RP, the worst).
            //   Only an exact tie on both shares a place.
            $place = 1; foreach ($res as $j => $o) if ($j !== $i && [$o['regions'], count($room['g']['players'][$j]['hand'])] > [$r['regions'], count($room['g']['players'][$i]['hand'])]) $place++;
            //MC 2026-10-10 Ranked needs a real rival too
            //MC 2026-10-11 and follows the League's Fair Play switch for private invite rooms ($privOk above): with it
            //   off, two friends could trade wins in a private room for +30 RP each time, the farming the League's gate stops
            $rk = empty($room['tourney']) && empty($room['boss']) && $privOk ? rank_apply($p, $place, $r['result'], 1 + $real) : null;   //MC 2026-10-12 not for boss matches
            game_log($p, 'live', $r['result'], $r['regions'], $r['points']);
            stats_add($pid, 'live', $r['result'], $r['regions']);
            $players[$pid] = $p;
            if (!empty($s['avatar'])) shadow_record($s['avatar'], $r['points'], $r['result'], $r['regions'], true);
            //MC 2026-10-09 the 15 Club bounty: any live match, as long as the player was still at the table (not a bot covering for them)
            $bty = empty($s['away']) && empty($s['gone']) ? bounty_claim($pid, $p['name'], 'live', $r['regions'], $r['result']) : null;
            $awards[$i] = ['pid' => $pid, 'result' => $r['result'], 'league' => $lgain, 'lwhy' => $lwhy, 'regions' => $r['regions'], 'cards' => $room['pc'][$i] ?? [], 'rk' => $rk, 'bounty' => $bty];
        }
        save(PLAYERS, $players);
        try { fp_record($room, $res, $awards); } catch (Throwable $e) {}   //MC 2026-10-10 Fair Play: keep the match after the room is gone
        if ($hum >= 2 && empty($room['tourney'])) tg_live($room['seats'], $res, $room['result']['standings']);   //MC 2026-10-10 in the game's own order   // matches with real rivals go to the Telegram chat
        foreach ($awards as $i => $aw) {
            $room['result']['seats'][$i]['eco'] = eco_award_game($aw['pid'], empty($room['boss']) ? 'live' : 'solo', $aw['result'], 0, ['regions' => $aw['regions'], 'cards' => $aw['cards']]);   //MC 2026-10-12 a boss match earns like a solo game (no live missions)
            $room['result']['seats'][$i]['league'] = $aw['league'];
            if ($aw['lwhy'] !== '') $room['result']['seats'][$i]['lwhy'] = $aw['lwhy'];
            if ($aw['rk']) $room['result']['seats'][$i]['rk'] = $aw['rk'];
            if ($aw['bounty']) $room['result']['seats'][$i]['bounty'] = $aw['bounty'];
            if (!empty($aw['boss'])) { $room['result']['seats'][$i]['boss'] = $aw['boss']; if (!empty($aw['boss']['koban'])) { $eco = load(ECO); $acc = eco_get($eco, $aw['pid']); eco_credit($acc, $aw['boss']['koban'], 'Beat the Shogun'); $eco[$aw['pid']] = $acc; save(ECO, $eco); } }
        }
    });
    $room['ver']++;
    if (!empty($room['tourney'])) tourney_table_done($room);   // the best real player here moves on
}

//MC 2026-10-12 Live chat. Short messages between the players at a table (not spectators), kept with the room: the last 40,
//   gone when the room is. Each word is checked against the same blocked list as names (whole words only, so "class" or
//   "assassin" are fine) and a bad one shows as stars; links and @handles are cut, so chat can't be used to spam or dox.
//   One message a second and 8 in 30 seconds per seat. The admin can switch chat off (Admin > Players, live_chat).
const CHAT_KEEP = 40;
function chat_clean($t) {
    $t = trim(preg_replace('/[\x00-\x1F\x7F\x{200B}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{2064}]/u', ' ', is_scalar($t) ? (string)$t : ''));
    $t = preg_replace('/\s+/u', ' ', $t);
    $t = preg_replace('~\b(?:https?://|www\.)\S+|\b[a-z0-9-]+\.(?:com|io|xyz|net|org|gg|ru|me|link|app|fun|co)\b\S*~i', '[link]', $t);
    $t = preg_replace('/(^|\s)@\w+/u', '$1@…', $t);
    $t = mb_substr($t, 0, 120);
    $extra = is_file(BLOCKED_NAMES) ? (array)load(BLOCKED_NAMES) : [];
    $bad = array_map(fn($b) => strtolower(preg_replace('/[^a-z0-9]/i', '', (string)$b)), array_merge(NAME_BAD, NAME_BAD_WHOLE, $extra));
    return preg_replace_callback('/[\p{L}\p{N}\']+/u', function ($m) use ($bad) {
        $w = strtolower(preg_replace('/[^a-z0-9]/i', '', $m[0])); $sq = preg_replace('/(.)\1+/', '$1', $w);
        foreach ($bad as $b) { if ($b === '' || strlen($b) < 3) continue; if ($w === $b || $sq === preg_replace('/(.)\1+/', '$1', $b) || ($w !== '' && strpos($w, $b) === 0 && strlen($w) - strlen($b) <= 3 && !in_array($w, NAME_OK_INSIDE, true))) return str_repeat('*', mb_strlen($m[0])); }
        return $m[0];
    }, $t);
}
function chat_add(&$room, $seat, $text) {
    if (empty(eco_settings()['live_chat'])) return 'Chat is switched off right now.';
    $t = chat_clean($text);
    if ($t === '' || trim(str_replace('*', '', $t)) === '') return 'Write a message first.';
    $mine = array_values(array_filter($room['chat'] ?? [], fn($m) => $m['seat'] === $seat));
    $now = now();
    if ($mine && $now - end($mine)['ts'] < 1) return 'Slow down a little.';
    if (count(array_filter($mine, fn($m) => $now - $m['ts'] < 30)) >= 8) return 'That\'s a lot of messages. Wait a few seconds.';
    $room['chat'][] = ['id' => bin2hex(random_bytes(4)), 'seat' => $seat, 't' => $t, 'ts' => $now];
    $room['chat'] = array_slice($room['chat'], -CHAT_KEEP);
    $room['ver']++;
    return '';
}
function view($room, $seat) {
    $t = now();
    $v = ['ok' => true, 'code' => $room['code'], 'status' => $room['status'], 'public' => $room['public'], 'you' => $seat,
        'host' => $seat === 0, 'ver' => $room['ver'], 'now' => $t,
        'seats' => array_map(fn($s) => ['name' => $s['name'], 'avatar' => $s['avatar'] ?? '', 'img' => !empty($s['avatar']) ? shadow_img($s['avatar']) : '', 'holder' => !empty($s['holder']), 'human' => !empty($s['human']), 'cos' => $s['cos'] ?? [],
            'away' => !empty($s['away']) || !empty($s['gone']), 'style' => $s['style'] ?? '', 'tag' => !empty($s['human']) && !empty($s['pid']) ? substr($s['pid'], 0, 6) : '', 'aura' => !empty($s['avatar']) && !empty($s['holder']) ? shadow_aura($s['avatar']) : ''] + (!empty($s['boss']) ? ['boss' => true] : []), $room['seats']),
        'reacts' => array_values(array_filter($room['reacts'], fn($r) => $t - $r['ts'] < 6)),
        'chat' => $seat >= 0 ? array_values($room['chat'] ?? []) : [], 'chatOn' => !empty(eco_settings()['live_chat']),   //MC 2026-10-12 live chat (players only)
        'watchers' => count(array_filter($room['watch'] ?? [], fn($w) => $w > $t - 15))];
    //MC 2026-10-15 late join: how long a bot seat stays open to someone joining (watchers get a Jump in button)
    if ($room['status'] === 'playing' && late_seat($room) >= 0) $v['lateUntil'] = (float)$room['started'] + LATE_JOIN;
    if ($room['status'] === 'waiting' && $room['public']) { $v['startsAt'] = quick_starts($room); $v['canHold'] = quick_starts($room) + 1 < $room['created'] + QUICK_HOLD_MAX; $v['held'] = !empty($room['hold']); }
    if ($room['g']) {
        $g = $room['g'];
        $v['game'] = ['round' => $g['round'], 'turn' => $g['turn'], 'start' => $g['start'], 'phase' => $room['phase'],
            'deck' => count($g['regionDeck']), 'discard' => count($g['regionDiscard']), 'discardList' => $g['regionDiscard'], 'over' => $g['over'],
            'players' => array_map(fn($p) => ['name' => $p['name'], 'regions' => $p['regions'], 'hand' => count($p['hand']),
                'shield' => $p['shield'], 'skip' => $p['skip'], 'lone' => !empty($p['lone']), 'paper' => !empty($p['paper']), 'harvest' => (int)($p['harvest'] ?? 0), 'style' => $p['style'] ?? ''], $g['players']),
            'plays' => $g['plays'], 'played' => !empty($g['played']), 'truce' => $g['truce'] ?? -1, 'season' => $g['deck'] ?? [],
            'hand' => $g['players'][$seat]['hand'] ?? [], 'log' => array_slice($g['log'], -30),
            'deadline' => $room['deadline']];
    }
    if ($room['result']) $v['result'] = $room['result'];
    if ($fv = fair_live_view($room)) $v['fair'] = $fv;   //MC 2026-10-15 the seal, and the seed once it's over
    if (!empty($room['tourney'])) { $v['tourney'] = $room['tourney']; if ($room['status'] === 'waiting') $v['startsAt'] = $room['tstart'] ?? 0; }
    if (!empty($room['rematch'])) $v['rematch'] = $room['rematch'];
    if (!empty($room['boss'])) { $v['boss'] = array_intersect_key($room['boss'], ['edge' => 1, 'koban' => 1, 'per' => 1]); foreach ($v['seats'] as &$vs) if (!empty($vs['boss'])) $vs['img'] = '/' . BOSS_AVATAR . '?t=' . (int)@filemtime(dirname(__DIR__) . '/' . BOSS_AVATAR); unset($vs); }   //MC 2026-10-13 ?t= is the mask file's time, so a mask replaced in the admin shows at the boss table at once
    return $v;
}

function lobby_add($code) {
    with_lock(function () use ($code) { $l = load(LOBBY); $l[$code] = now(); save(LOBBY, $l); });
}
function lobby_drop($code) {
    with_lock(function () use ($code) { $l = load(LOBBY); unset($l[$code]); save(LOBBY, $l); });
}
function cleanup() {
    if (random_int(1, 20) !== 1 || !is_dir(ROOMS)) return;
    foreach (glob(ROOMS . '/*.php') as $f) {
        if (filemtime($f) < time() - 3 * 3600) {
            //MC 2026-10-14 a boss match abandoned mid-game goes on the Shogun record as a quit before its room is swept,
            //   so walking away from a losing match no longer leaves the record looking all wins (Fair play table)
            $room = load($f);
            if (!empty($room['boss']) && ($room['status'] ?? '') === 'playing' && empty($room['result'])) { try { boss_quit($room, (int)filemtime($f)); } catch (Throwable $e) {} }
            @unlink($f); @unlink($f . '.lock');
        }
    }
}

