<?php
//MC 2026-10-18 the auto burn: one call runs the whole fee loop with the dedicated buyback wallet. Claim the swap fees
//   from Jupiter's referral program (permissionless, the funds can only go to the partner wallet), unwrap the SOL,
//   buy $SHY with it through our own swap, burn the $SHY, record it on the Treasury page and post the burn card.
//   The wallet is small on purpose: it only ever holds fees in transit, never the treasury. Its key is set by the
//   owner in Admin, lives in DATA_DIR behind the guard header, is never shown back, and signs only here.
//   Every step is idempotent (each one drains what the one before left), so a run that stops midway finishes on the
//   next press. Guard rails: the marketing wallet's key is refused, and a wallet holding over 25 SOL stops the run.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('BUYBACK_CFG', DATA_DIR . '/buyback.php');
const BUYBACK_RESERVE = 15000000;    // lamports kept back for fees and rent
const BUYBACK_MIN_SWAP = 5000000;    // under 0.005 SOL the swap is dust; wait for more
const BUYBACK_MAX_SOL = 25;          // a wallet this rich is the wrong wallet; stop
const BUYBACK_USDC = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';

function buyback_cfg() {
    $c = is_file(BUYBACK_CFG) ? load(BUYBACK_CFG) : [];
    return (is_array($c) ? $c : []) + ['w' => '', 'sk' => '', 'auto' => 0, 'last' => 0, 'log' => []];
}
function buyback_save($c) { with_lock(function () use ($c) { save(BUYBACK_CFG, $c); }); }
// the owner pastes the wallet's secret; '' on success, or what is wrong in plain words
function buyback_set_wallet($secret) {
    $kp = sol_keypair($secret);
    if (!$kp) return 'That is not a Solana private key. Export it from the buyback wallet in Phantom (Settings, Show Private Key).';
    if ($kp[1] === (function_exists('mw_address') ? mw_address() : MW_DEFAULT)) return 'That is the marketing wallet. The buyback runs from a small dedicated wallet, never the treasury. Make a fresh wallet for it.';
    $c = buyback_cfg();
    $c['w'] = $kp[1]; $c['sk'] = base64_encode($kp[0]);
    buyback_save($c);
    return '';
}
function buyback_tokens($owner) {
    $r = rpc('getTokenAccountsByOwner', [$owner, ['programId' => SOL_TOKEN], ['encoding' => 'jsonParsed']]);
    $out = [];
    foreach ($r['value'] ?? [] as $a) {
        $i = $a['account']['data']['parsed']['info'] ?? [];
        $amt = (int)($i['tokenAmount']['amount'] ?? 0);
        if ($amt > 0) $out[] = ['acct' => (string)($a['pubkey'] ?? ''), 'mint' => (string)($i['mint'] ?? ''), 'amount' => $amt, 'decimals' => (int)($i['tokenAmount']['decimals'] ?? 0)];
    }
    return $out;
}
function buyback_lamports($pk) { $r = rpc('getBalance', [$pk]); return is_array($r) ? (int)($r['value'] ?? 0) : (int)$r; }

// the whole loop; returns the step list it also stores in the config
function buyback_run() {
    @set_time_limit(120);
    $steps = [];
    $say = function ($k, $st, $text, $sig = '') use (&$steps) { $steps[] = ['k' => $k, 'st' => $st, 'text' => $text, 'sig' => $sig]; };
    $c = buyback_cfg();
    $burnedShy = 0.0; $burnSig = '';
    try {
        if ($c['w'] === '' || $c['sk'] === '') { $say('wallet', 'fail', 'No buyback wallet linked yet. Link one below first.'); return buyback_done($c, $steps, 0, ''); }
        $sk = base64_decode($c['sk']); $pub = $c['w'];
        $lam = buyback_lamports($pub);
        if ($lam / 1e9 > BUYBACK_MAX_SOL) { $say('wallet', 'fail', 'The wallet holds over ' . BUYBACK_MAX_SOL . ' SOL. That looks like the wrong wallet, so nothing was touched.'); return buyback_done($c, $steps, 0, ''); }

        // 1: claim the fees from the referral program (only possible when the buyback wallet is the referral partner)
        $sc = swap_cfg();
        if ($sc['ref'] === '') $say('claim', 'skip', 'No referral account saved in the fee settings, so there is nothing to claim.');
        else {
            $ra = sol_referral_read($sc['ref']);
            if (!$ra) $say('claim', 'skip', 'The referral account could not be read from the chain.');
            elseif ($ra['partner'] !== $pub) $say('claim', 'skip', 'The referral account pays its fees to ' . substr($ra['partner'], 0, 4) . '...' . substr($ra['partner'], -4) . ', not the buyback wallet, so claiming stays at referral.jup.ag. To automate it, make the buyback wallet the partner there.');
            else {
                $admin = sol_project_admin($ra['project']);
                $toClaim = $admin !== null ? buyback_tokens($sc['ref']) : [];
                if ($admin === null) $say('claim', 'skip', 'The referral project could not be read from the chain.');
                elseif (!$toClaim) $say('claim', 'skip', 'Nothing is waiting on the referral account.');
                foreach ($toClaim as $t) {
                    $bh = sol_blockhash();
                    if (!$bh) { $say('claim', 'fail', 'The chain gave no blockhash. Try again in a moment.'); break; }
                    $ix = sol_ix_claim_v2($pub, $ra['project'], $admin, $sc['ref'], $t['acct'], $pub, $t['mint']);
                    $sig = sol_send_b64(sol_tx([$ix], $pub, $bh, $sk));
                    if ($sig === '') { $say('claim', 'fail', 'The claim did not reach the chain.'); continue; }
                    $ok = sol_confirmed($sig, 6);
                    $nm = $t['mint'] === SOL_WSOL ? 'SOL' : ($t['mint'] === BUYBACK_USDC ? 'USDC' : substr($t['mint'], 0, 4));
                    $say('claim', $ok ? 'ok' : 'fail', ($ok ? 'Claimed ' : 'Claim sent but not yet confirmed: ') . rtrim(rtrim(number_format($t['amount'] / 10 ** $t['decimals'], 6), '0'), '.') . ' ' . $nm . ' in fees.', $sig);
                }
            }
        }

        // 2: unwrap any wrapped SOL into plain SOL
        $wsolAccts = array_filter(buyback_tokens($pub), fn($t) => $t['mint'] === SOL_WSOL);
        if (!$wsolAccts) $say('unwrap', 'skip', 'No wrapped SOL to unwrap.');
        foreach ($wsolAccts as $t) {
            $bh = sol_blockhash();
            $sig = $bh ? sol_send_b64(sol_tx([sol_ix_close_account($t['acct'], $pub, $pub)], $pub, $bh, $sk)) : '';
            $ok = $sig !== '' && sol_confirmed($sig, 6);
            $say('unwrap', $ok ? 'ok' : 'fail', $ok ? 'Unwrapped ' . rtrim(rtrim(number_format($t['amount'] / 1e9, 6), '0'), '.') . ' SOL.' : 'The unwrap did not land. Press Auto burn again in a minute.', $sig);
        }

        // 3: buy $SHY with everything above the fee reserve, through the same swap the site uses
        $spend = buyback_lamports($pub) - BUYBACK_RESERVE;
        $did = false;
        foreach (array_merge($spend >= BUYBACK_MIN_SWAP ? [[SWAP_SOL, (string)$spend, 'SOL', 1e9]] : [],
            array_map(fn($t) => [BUYBACK_USDC, (string)$t['amount'], 'USDC', 1e6], array_filter(buyback_tokens($pub), fn($t) => $t['mint'] === BUYBACK_USDC && $t['amount'] >= 1000000))) as [$inMint, $amt, $nm, $d]) {
            $did = true;
            [$code, $j] = swap_order($inMint, SWAP_SHY, $amt, $pub, '');
            if ($code !== 200 || empty($j['transaction']) || empty($j['requestId'])) { $say('swap', 'fail', 'Jupiter gave no route for the ' . $nm . '. Try again in a moment.'); continue; }
            $signed = sol_sign_b64($j['transaction'], $sk, $pub);
            if (!$signed) { $say('swap', 'fail', 'The swap could not be signed (the order was not for this wallet).'); continue; }
            [$c2, $x] = swap_jup('POST', '/swap/v2/execute', [], ['signedTransaction' => $signed, 'requestId' => (string)$j['requestId']], 45);
            if ($c2 === 200 && ($x['status'] ?? '') === 'Success' && !empty($x['signature'])) {
                $got = (float)($x['outputAmountResult'] ?? ($x['totalOutputAmount'] ?? $j['outAmount'] ?? 0)) / 1e6;
                $say('swap', 'ok', 'Bought ' . number_format($got) . ' $SHY with ' . rtrim(rtrim(number_format($amt / $d, 6), '0'), '.') . ' ' . $nm . '.', (string)$x['signature']);
            } else $say('swap', 'fail', 'The ' . $nm . ' swap did not go through' . (isset($x['code']) ? ' (code ' . (int)$x['code'] . ')' : '') . '. Press Auto burn again in a minute.');
        }
        if (!$did) $say('swap', 'skip', 'Nothing above the ' . rtrim(rtrim(number_format(BUYBACK_RESERVE / 1e9, 3), '0'), '.') . ' SOL fee reserve to spend yet.');

        // 4: burn every $SHY the wallet holds
        $dec = mint_decimals(SHY_MINT) ?? 6;
        $shyAccts = array_filter(buyback_tokens($pub), fn($t) => $t['mint'] === SHY_MINT);
        if (!$shyAccts) $say('burn', 'skip', 'No $SHY in the wallet to burn.');
        foreach ($shyAccts as $t) {
            $bh = sol_blockhash();
            $sig = $bh ? sol_send_b64(sol_tx([sol_ix_burn_checked($t['acct'], SHY_MINT, $pub, $t['amount'], $dec)], $pub, $bh, $sk)) : '';
            $ok = $sig !== '' && sol_confirmed($sig, 10);
            $shy = round($t['amount'] / 10 ** $dec, 2);
            if ($ok) { $burnedShy += $shy; $burnSig = $sig; }
            $say('burn', $ok ? 'ok' : 'fail', $ok ? number_format($shy) . ' $SHY burned, gone for good.' : 'The burn did not land. Press Auto burn again in a minute; nothing is lost, the $SHY is still in the wallet.', $sig);
        }

        // 5: put it on the record: the Treasury page, the burn tracker, and the Telegram card
        if ($burnedShy > 0) {
            with_lock(function () use ($burnSig, $burnedShy) {
                $log = load(DATA_DIR . '/treasury-log.php'); $log = is_array($log) ? array_values($log) : [];
                foreach ($log as $x) if (($x['sig'] ?? '') === $burnSig) return;
                $log[] = ['t' => time(), 'kind' => 'burn', 'shy' => $burnedShy, 'usd' => 0, 'sig' => $burnSig, 'note' => 'Swap fee buyback'];
                save(DATA_DIR . '/treasury-log.php', $log);
                @unlink(DATA_DIR . '/treasury-cache.php');
            });
            tg_burn((int)round($burnedShy), $burnSig, 'Swap fee buyback');
            $say('record', 'ok', 'On the Treasury page, and the burn card is on its way to Telegram.');
        } else $say('record', 'skip', 'Nothing burned this run, so nothing to record.');
    } catch (Throwable $e) {
        $say('error', 'fail', 'Stopped: ' . $e->getMessage());
    }
    return buyback_done($c, $steps, $burnedShy, $burnSig);
}
function buyback_done($c, $steps, $shy, $sig) {
    $c['last'] = time();
    $c['log'] = ['t' => time(), 'steps' => $steps, 'shy' => $shy, 'sig' => $sig];
    buyback_save($c);
    return $steps;
}
//MC the weekly clock, from api/cron.php: runs the loop itself when the owner switched Auto on and a week has passed,
//   but only once something worth claiming or spending is there, so quiet weeks cost nothing
function buyback_tick() {
    $c = buyback_cfg();
    if (empty($c['auto']) || $c['w'] === '' || time() - (int)$c['last'] < 6.5 * 86400) return;
    $sc = swap_cfg();
    $worth = buyback_lamports($c['w']) > BUYBACK_RESERVE + BUYBACK_MIN_SWAP;
    if (!$worth && $sc['ref'] !== '') foreach (buyback_tokens($sc['ref']) as $t) if ($t['amount'] > 0) $worth = true;
    if (!$worth) { $c['last'] = time() - 6 * 86400; buyback_save($c); return; }   // look again tomorrow-ish
    buyback_run();
    if (function_exists('track')) track('buyback_auto');
}
