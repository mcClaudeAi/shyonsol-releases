// The 3D war table: the same 40 Regions as the flat map, raised as plates on a command table you can orbit and zoom.
// Built from assets/map.json (the flat map's own outlines), so both maps always agree on what a Region is and where.
// play.js owns the game: it tells this module who holds what (paint), whose turn it is (setTurn), who is highlighted
// (setHl) and whether a target is being picked (setPicking), and it gets taps and hovers back. Nothing here touches
// the rules, the server or the flat map; if WebGL is missing or anything fails, play.js keeps the flat map.
//MC 2026-10-14 three.js (assets/vendor/three-map.js, r170 with SVGLoader and OrbitControls) is fetched only when a
//   player has the 3D table on, so the flat map never pays for it. Touch: one finger orbits, two zoom. A tap that
//   does not move picks or shows the Region, same as tapping the flat map.
//MC 2026-10-14 second pass, the premium table: real shadows, bevelled plates with a paper grain, a felt with radar
//   rings and a brass lip in a walnut frame, command pieces instead of flat hexes (a dark base and a floating gem in
//   the holder's colour over a soft glow), pulsing target rings when a card wants a Region, dust in the air, a
//   hover lift on desktop, and a My regions view that flies to what you hold. The page behind the canvas is a CSS
//   gradient, so the renderer clears to transparent and the table sits in the room instead of on a flat colour.
(function () {
  "use strict";
  var S = 0.012, W = 1000, H = 475;              // map units to table units; the flat map's own size
  var LAND_H = 0.14, BEV = 0.022;                // how far a plate rises off the table, and its rounded lip
  var OPEN = "#8d9c52", OPEN_SIDE = "#4a5630", GONE = "#2b2030", GONE_SIDE = "#1a1420";
  var vendor = null;                             // the script tag, once asked for

  function supported() {
    try {
      var c = document.createElement("canvas");
      var gl = c.getContext("webgl2") || c.getContext("webgl");
      if (!gl) return false;
      var ext = gl.getExtension("WEBGL_lose_context"); if (ext) ext.loseContext();
      return true;
    } catch (e) { return false; }
  }
  // fetch three.js once; resolves when window.THREE is there
  function load(src) {
    if (window.THREE && window.ShyThreeAddons) return Promise.resolve();
    if (!vendor) {
      vendor = new Promise(function (res, rej) {
        var s = document.createElement("script"); s.src = src; s.async = true;
        s.onload = function () { window.THREE && window.ShyThreeAddons ? res() : rej(new Error("three missing")); };
        s.onerror = function () { rej(new Error("three failed to load")); };
        document.head.appendChild(s);
      });
    }
    return vendor;
  }
  function hex(c) { return new window.THREE.Color(c); }
  function mix(a, b, t) { return hex(a).lerp(hex(b), t); }
  // a seeded noise so every load of the table looks the same
  function rng(seed) { var s = seed >>> 0; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  function tex(T, c, srgb) { var t = new T.CanvasTexture(c); if (srgb) t.colorSpace = T.SRGBColorSpace; t.anisotropy = 8; return t; }

  // the felt: dark green cloth with a fine grain, a drafting grid, radar rings and a soft vignette
  function feltTexture(T) {
    var w = 1024, h = 512, c = document.createElement("canvas"); c.width = w; c.height = h;
    var x = c.getContext("2d"), r = rng(7);
    x.fillStyle = "#0f2219"; x.fillRect(0, 0, w, h);
    var img = x.getImageData(0, 0, w, h), d = img.data;
    for (var i = 0; i < d.length; i += 4) { var n = (r() - .5) * 14; d[i] += n; d[i + 1] += n * 1.3; d[i + 2] += n; }
    x.putImageData(img, 0, 0);
    x.lineWidth = 1;
    x.strokeStyle = "rgba(150,220,180,.08)";
    for (i = 0; i <= w; i += 32) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, h); x.stroke(); }
    for (var j = 0; j <= h; j += 32) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(w, j + .5); x.stroke(); }
    x.strokeStyle = "rgba(150,220,180,.17)";
    for (i = 0; i <= w; i += 128) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, h); x.stroke(); }
    for (j = 0; j <= h; j += 128) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(w, j + .5); x.stroke(); }
    x.strokeStyle = "rgba(170,230,195,.07)";
    for (i = 1; i <= 5; i++) { x.beginPath(); x.ellipse(w / 2, h / 2, i * 115, i * 115, 0, 0, Math.PI * 2); x.stroke(); }
    x.beginPath(); x.moveTo(w / 2 + .5, 0); x.lineTo(w / 2 + .5, h); x.moveTo(0, h / 2 + .5); x.lineTo(w, h / 2 + .5); x.stroke();
    // corner ticks, like a plotting table
    x.strokeStyle = "rgba(220,240,225,.28)"; x.lineWidth = 2;
    [[18, 18, 1, 1], [w - 18, 18, -1, 1], [18, h - 18, 1, -1], [w - 18, h - 18, -1, -1]].forEach(function (k) {
      x.beginPath(); x.moveTo(k[0], k[1] + 26 * k[3]); x.lineTo(k[0], k[1]); x.lineTo(k[0] + 26 * k[2], k[1]); x.stroke();
    });
    var v = x.createRadialGradient(w / 2, h / 2, 140, w / 2, h / 2, 640);
    v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.62)");
    x.fillStyle = v; x.fillRect(0, 0, w, h);
    return tex(T, c, true);
  }
  // walnut for the frame: long grain with a little variation
  function woodTexture(T) {
    var w = 1024, h = 128, c = document.createElement("canvas"); c.width = w; c.height = h;
    var x = c.getContext("2d"), r = rng(11);
    x.fillStyle = "#4a3523"; x.fillRect(0, 0, w, h);
    for (var i = 0; i < 260; i++) {
      var y = r() * h, a = .05 + r() * .12, k = r();
      x.strokeStyle = k < .5 ? "rgba(20,10,4," + a + ")" : "rgba(170,120,70," + a + ")"; x.lineWidth = .5 + r() * 2.2;
      x.beginPath(); x.moveTo(0, y); x.bezierCurveTo(w * .3, y + (r() - .5) * 10, w * .7, y + (r() - .5) * 10, w, y + (r() - .5) * 6); x.stroke();
    }
    var t = tex(T, c, true); t.wrapS = t.wrapT = T.RepeatWrapping; return t;
  }
  // paper grain for the plates: pale noise the plate colour multiplies, also used as a bump so light catches it
  function grainTexture(T) {
    var n = 256, c = document.createElement("canvas"); c.width = n; c.height = n;
    var x = c.getContext("2d"), r = rng(3), img = x.createImageData(n, n), d = img.data;
    for (var i = 0; i < d.length; i += 4) { var v = 222 + (r() - .5) * 46; d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = 255; }
    x.putImageData(img, 0, 0);
    var t = tex(T, c, true); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(1.6, 1.6); return t;
  }
  // the room: a dark green glow above the table fading to near black, wrapped around the scene as a sky dome
  function skyTexture(T) {
    var c = document.createElement("canvas"); c.width = 8; c.height = 256;
    var x = c.getContext("2d"), g = x.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, "#07100c"); g.addColorStop(.42, "#0c1c15"); g.addColorStop(.56, "#1a3f31"); g.addColorStop(.68, "#0c1c15"); g.addColorStop(1, "#050a08");
    x.fillStyle = g; x.fillRect(0, 0, 8, 256);
    return tex(T, c, true);
  }
  // a soft round glow for under the pieces and the dust
  function glowTexture(T) {
    var n = 128, c = document.createElement("canvas"); c.width = n; c.height = n;
    var x = c.getContext("2d"), g = x.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
    g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(.35, "rgba(255,255,255,.45)"); g.addColorStop(1, "rgba(255,255,255,0)");
    x.fillStyle = g; x.fillRect(0, 0, n, n);
    return tex(T, c, false);
  }
  // a Region's outline, from the flat map's path, as table shapes: x across, y toward the far edge, flipped from screen
  function shapesFor(T, A, d) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg"><path d="' + d + '"/></svg>';
    var paths = new A.SVGLoader().parse(svg).paths;
    var out = [];
    paths.forEach(function (p) {
      A.SVGLoader.createShapes(p).forEach(function (sh) {
        var fix = function (path) { path.curves.forEach(function (cv) { ["v0", "v1", "v2", "v3"].forEach(function (k) { var pt = cv[k]; if (pt && pt.isVector2) pt.set((pt.x - W / 2) * S, (H / 2 - pt.y) * S); }); }); };
        fix(sh); (sh.holes || []).forEach(fix);
        out.push(sh);
      });
    });
    return out;
  }

  function mount(opts) {
    var T = window.THREE, A = window.ShyThreeAddons;
    var el = opts.el, MAP = opts.map, names = opts.regions, COLORS = opts.colors, hooks = opts.hooks || {};
    var reduce = !!opts.reduce, me = typeof opts.me === "number" ? opts.me : 0;
    var canvas = document.createElement("canvas"); canvas.className = "g-map3d-canvas";
    el.appendChild(canvas);
    var coarse = matchMedia("(pointer: coarse)").matches;
    //MC 2026-10-14 an opaque canvas: additive glows over a transparent canvas came out wrong once the browser
    //   composited them, so the room gradient is a sky dome inside the scene instead of CSS behind it
    var renderer = new T.WebGLRenderer({ canvas: canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, coarse ? 1.5 : 2));
    renderer.setClearColor(0x060d0a, 1);
    renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
    var scene = new T.Scene();
    var camera = new T.PerspectiveCamera(38, 2, 0.1, 60);
    var VIEWS = { overview: { p: [0, 7.0, 5.6], t: [0, 0, -0.35] }, cinematic: { p: [1.1, 2.2, 6.1], t: [0, 0.15, -0.5] } };
    camera.position.set(0, 12, 7);
    var glow = glowTexture(T);
    var sky = new T.Mesh(new T.SphereGeometry(45, 24, 16), new T.MeshBasicMaterial({ map: skyTexture(T), side: T.BackSide, fog: false, toneMapped: false }));
    sky.position.y = -6; scene.add(sky);

    // ---- light: a warm key from the upper left that throws the shadows, a cool rim from behind, a soft sky
    scene.add(new T.HemisphereLight(0xd6ecd8, 0x0a160f, .9));
    var key = new T.DirectionalLight(0xfff0d2, 1.6); key.position.set(-6, 10, 5); key.castShadow = true;
    key.shadow.mapSize.set(coarse ? 1024 : 2048, coarse ? 1024 : 2048);
    key.shadow.camera.left = -7.2; key.shadow.camera.right = 7.2; key.shadow.camera.top = 4.6; key.shadow.camera.bottom = -4.6;
    key.shadow.camera.near = 2; key.shadow.camera.far = 30; key.shadow.bias = -0.0006; key.shadow.normalBias = .012; key.shadow.radius = 3;
    scene.add(key);
    var rimL = new T.DirectionalLight(0x8fc4ff, .55); rimL.position.set(5, 4, -7); scene.add(rimL);
    scene.add(new T.AmbientLight(0xffffff, .16));

    // ---- the table: felt, a brass lip, a walnut frame, and a pool of light on the floor beneath it
    var FW = W * S + .7, FH = H * S + .7;
    var felt = new T.Mesh(new T.PlaneGeometry(FW, FH), new T.MeshStandardMaterial({ map: feltTexture(T), roughness: .96, metalness: 0 }));
    felt.rotation.x = -Math.PI / 2; felt.receiveShadow = true; scene.add(felt);
    var brass = new T.Mesh(new T.BoxGeometry(FW + .14, .05, FH + .14), new T.MeshStandardMaterial({ color: hex("#c9a455"), metalness: .85, roughness: .32 }));
    brass.position.y = -.035; scene.add(brass);
    var wood = woodTexture(T), woodMat = new T.MeshStandardMaterial({ map: wood, color: hex("#8a6a48"), roughness: .62, metalness: .05 });
    var wframe = new T.Group(); scene.add(wframe);
    [[0, -(FH / 2 + .3), FW + .9, .5], [0, FH / 2 + .3, FW + .9, .5], [-(FW / 2 + .3), 0, .5, FH + .9], [FW / 2 + .3, 0, .5, FH + .9]].forEach(function (b) {
      var m = new T.Mesh(new T.BoxGeometry(b[2], .24, b[3]), woodMat); m.position.set(b[0], -.1, b[1]); m.receiveShadow = true; m.castShadow = true; wframe.add(m);
    });
    var pool = new T.Mesh(new T.PlaneGeometry(FW * 2.4, FH * 3.2), new T.MeshBasicMaterial({ map: glow, color: hex("#1d4a36"), transparent: true, opacity: .55, depthWrite: false }));
    pool.rotation.x = -Math.PI / 2; pool.position.y = -.26; scene.add(pool);

    // ---- the Regions as bevelled plates with a coastline, a piece each, and the lookups to paint them
    var grain = grainTexture(T);
    var sideOpen = new T.MeshStandardMaterial({ color: hex(OPEN_SIDE), roughness: .9 });
    var sideGone = new T.MeshStandardMaterial({ color: hex(GONE_SIDE), roughness: .9 });
    var coastMat = new T.LineBasicMaterial({ color: hex("#eef3d8"), transparent: true, opacity: .28 });
    var coastHot = new T.LineBasicMaterial({ color: hex("#ffffff"), transparent: true, opacity: .75 });
    var R = {}, pick = [], land = new T.Group(); land.rotation.x = -Math.PI / 2; land.position.y = BEV; scene.add(land);
    var markers = new T.Group(); scene.add(markers);
    var baseGeo = new T.CylinderGeometry(.15, .175, .04, 6), gemGeo = new T.OctahedronGeometry(.115, 0);
    var pinGeo = new T.CylinderGeometry(.024, .032, .045, 10), pinTop = new T.SphereGeometry(.03, 12, 10);
    var domeGeo = new T.IcosahedronGeometry(.38, 1), shellGeo = new T.SphereGeometry(.37, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2);
    var ringGeo = new T.RingGeometry(.3, .35, 48), glowGeo = new T.PlaneGeometry(1.15, 1.15);
    var pinMat = new T.MeshStandardMaterial({ color: hex("#d9d3b8"), roughness: .65, emissive: hex("#d9d3b8"), emissiveIntensity: .06 });
    var TOP = LAND_H + BEV * 2;
    names.forEach(function (n) {
      var r = MAP.regions[n]; if (!r) return;
      var shapes;
      try { shapes = shapesFor(T, A, r.d); } catch (e) { return; }   //MC 2026-10-14 one odd outline never takes the table down
      if (!shapes.length) return;
      var geo = new T.ExtrudeGeometry(shapes, { depth: LAND_H, bevelEnabled: true, bevelThickness: BEV, bevelSize: BEV * .8, bevelSegments: 2, curveSegments: 4 });
      var top = new T.MeshStandardMaterial({ color: hex(OPEN), map: grain, bumpMap: grain, bumpScale: .006, roughness: .78, metalness: 0, emissive: hex(COLORS[0]), emissiveIntensity: 0 });
      var mesh = new T.Mesh(geo, [top, sideOpen]);
      mesh.castShadow = true; mesh.receiveShadow = true;
      mesh.userData.region = n; land.add(mesh); pick.push(mesh);
      // the coastline: the outline drawn just above the plate so it reads like an inked map
      var coast = new T.Group(); coast.position.z = LAND_H + BEV + .004; land.add(coast);
      shapes.forEach(function (sh) {
        [sh].concat(sh.holes || []).forEach(function (path) {
          var pts = path.getPoints(4), arr = new Float32Array(pts.length * 3);
          pts.forEach(function (p, i) { arr[i * 3] = p.x; arr[i * 3 + 1] = p.y; arr[i * 3 + 2] = 0; });
          var g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(arr, 3));
          coast.add(new T.LineLoop(g, coastMat));
        });
      });
      // the piece sits on the plate at the Region's centre
      var mk = new T.Group(); mk.position.set((r.c[0] - W / 2) * S, TOP, (r.c[1] - H / 2) * S); markers.add(mk);
      var pin = new T.Group(); mk.add(pin);
      var pinA = new T.Mesh(pinGeo, pinMat); pinA.position.y = .025; pinA.castShadow = true; pinA.userData.region = n; pin.add(pinA); pick.push(pinA);
      var pinB = new T.Mesh(pinTop, pinMat); pinB.position.y = .07; pinB.userData.region = n; pin.add(pinB); pick.push(pinB);
      var own = new T.Group(); own.visible = false; mk.add(own);
      var halo = new T.Mesh(glowGeo, new T.MeshBasicMaterial({ map: glow, color: hex(COLORS[0]), transparent: true, opacity: .8, blending: T.AdditiveBlending, depthWrite: false }));
      halo.rotation.x = -Math.PI / 2; halo.position.y = .012; own.add(halo);
      var base = new T.Mesh(baseGeo, new T.MeshStandardMaterial({ color: hex(COLORS[0]), metalness: .15, roughness: .5, emissive: hex(COLORS[0]), emissiveIntensity: .2, flatShading: true })); base.position.y = .02; base.castShadow = true; base.userData.region = n; own.add(base); pick.push(base);
      var gem = new T.Mesh(gemGeo, new T.MeshStandardMaterial({ color: hex(COLORS[0]), metalness: .1, roughness: .35, emissive: hex(COLORS[0]), emissiveIntensity: .6, flatShading: true }));
      gem.position.y = .2; gem.castShadow = true; gem.userData.region = n; own.add(gem); pick.push(gem);
      var dome = new T.Mesh(domeGeo, new T.MeshBasicMaterial({ color: hex("#bfe9ff"), wireframe: true, transparent: true, opacity: .35, depthWrite: false }));
      dome.position.y = .08; dome.visible = false; mk.add(dome);
      var shell = new T.Mesh(shellGeo, new T.MeshBasicMaterial({ color: hex("#bfe9ff"), transparent: true, opacity: .1, depthWrite: false, side: T.DoubleSide }));
      shell.position.y = .08; shell.visible = false; mk.add(shell);
      var ring = new T.Mesh(ringGeo, new T.MeshBasicMaterial({ color: hex("#ff5d73"), transparent: true, opacity: .9, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide }));
      ring.rotation.x = -Math.PI / 2; ring.position.y = .02; ring.visible = false; mk.add(ring);
      R[n] = { mesh: mesh, top: top, coast: coast, pin: pin, own: own, halo: halo, gem: gem, base: base, dome: dome, shell: shell, ring: ring, mk: mk,
               state: "open", color: "", flags: {}, flash: 0, drop: 0, lift: 0, phase: Math.random() * 6.28, cx: mk.position.x, cz: mk.position.z };
    });

    // ---- dust in the air over the table, drifting slowly: the room has depth
    var dust = null, dustPos = null, dustSeed = null;
    if (!reduce) {
      var N = coarse ? 70 : 140, r0 = rng(21); dustPos = new Float32Array(N * 3); dustSeed = new Float32Array(N * 2);
      for (var i = 0; i < N; i++) { dustPos[i * 3] = (r0() - .5) * FW * 1.1; dustPos[i * 3 + 1] = .15 + r0() * 2.6; dustPos[i * 3 + 2] = (r0() - .5) * FH * 1.3; dustSeed[i * 2] = r0() * 6.28; dustSeed[i * 2 + 1] = .3 + r0(); }
      var dg = new T.BufferGeometry(); dg.setAttribute("position", new T.BufferAttribute(dustPos, 3));
      dust = new T.Points(dg, new T.PointsMaterial({ map: glow, color: hex("#d8f0dc"), size: .07, transparent: true, opacity: .32, blending: T.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
      scene.add(dust);
    }

    // ---- camera and controls
    var controls = new A.OrbitControls(camera, canvas);
    controls.enablePan = false; controls.enableDamping = true; controls.dampingFactor = .08;
    controls.rotateSpeed = .55; controls.zoomSpeed = .9;
    controls.minDistance = 3.4; controls.maxDistance = 13; controls.minPolarAngle = .18; controls.maxPolarAngle = 1.34;
    controls.touches = { ONE: T.TOUCH.ROTATE, TWO: T.TOUCH.DOLLY_PAN };
    var dirty = true, tween = null, raf = 0, dead = false;
    controls.addEventListener("change", function () { dirty = true; });
    function flyTo(p, t, ms) {
      var from = camera.position.clone(), to = new T.Vector3().fromArray(p), t0 = new T.Vector3().copy(controls.target), t1 = new T.Vector3().fromArray(t);
      if (reduce || !ms) { camera.position.copy(to); controls.target.copy(t1); controls.update(); dirty = true; tween = null; return; }
      var start = performance.now();
      tween = function (now) {
        var k = Math.min(1, (now - start) / ms); k = k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
        camera.position.lerpVectors(from, to, k); controls.target.lerpVectors(t0, t1, k);
        dirty = true; if (k >= 1) tween = null;
      };
    }
    function view(name, ms) {
      if (name === "mine") {
        // fly to what the player holds: the middle of their Regions, close, from a little in front
        var xs = 0, zs = 0, c = 0;
        names.forEach(function (n) { var x = R[n]; if (x && x.state === me) { xs += x.cx; zs += x.cz; c++; } });
        if (!c) { name = "overview"; } else {
          xs /= c; zs /= c;
          var spread = 0; names.forEach(function (n) { var x = R[n]; if (x && x.state === me) spread = Math.max(spread, Math.hypot(x.cx - xs, x.cz - zs)); });
          var d = Math.min(9, Math.max(3.6, 3 + spread * 1.3));
          flyTo([xs * .9, d * .62, zs + d * .78], [xs, .1, zs], ms); if (hooks.view) hooks.view("mine"); return;
        }
      }
      var v = VIEWS[name] || VIEWS.overview;
      flyTo(v.p, v.t, ms); if (hooks.view) hooks.view(VIEWS[name] ? name : "overview");
    }
    controls.addEventListener("start", function () { tween = null; if (hooks.view) hooks.view(null); });

    // ---- painting
    var turn = null, hl = null, picking = false, hovered = null;
    function look(n, now) {
      var x = R[n]; if (!x) return;
      var ownIdx = typeof x.state === "number", gone = x.state === "gone";
      var base = gone ? hex(GONE) : ownIdx ? mix(x.color, OPEN, .3) : hex(OPEN);
      var dim = hl != null && (!ownIdx || x.state !== hl) ? .4 : 1;
      x.top.color.copy(base).multiplyScalar(dim);
      x.mesh.material[1] = gone ? sideGone : sideOpen;
      var e = 0;
      if (ownIdx) {
        x.top.emissive.set(x.color);
        if (turn === x.state) e = .1 + .12 * (.5 + .5 * Math.sin(now / 320 + x.phase));
        if (hl === x.state) e = Math.max(e, .28);
        if (x.flags.pickable) e = Math.max(e, .25 + .25 * (.5 + .5 * Math.sin(now / 170)));
      }
      if (x.flash > now) { var f = (x.flash - now) / 650; x.top.emissive.set("#ffffff").lerp(hex(ownIdx ? x.color : OPEN), 1 - f); e = Math.max(e, .9 * f); }
      x.top.emissiveIntensity = e;
      // hover lift on desktop: the plate rises a touch and its coastline brightens
      var want = hovered === n ? .05 : 0;
      x.lift += (want - x.lift) * (reduce ? 1 : .25);
      x.mesh.position.z = x.lift; x.coast.position.z = LAND_H + BEV + .004 + x.lift;
      x.coast.children.forEach(function (l) { l.material = hovered === n ? coastHot : coastMat; });
      x.mk.position.y = TOP + x.lift;
      x.own.visible = ownIdx; x.pin.visible = !ownIdx && !gone;
      if (ownIdx) {
        var col = hex(x.color);
        x.gem.material.color.copy(col); x.gem.material.emissive.copy(col);
        x.gem.material.emissiveIntensity = x.flags.pickable ? 1.1 : (turn === x.state ? .85 : .6);
        x.base.material.color.copy(col).multiplyScalar(.55); x.base.material.emissive.copy(col); x.base.material.emissiveIntensity = .25;
        x.halo.material.color.copy(col); x.halo.material.opacity = turn === x.state ? .7 + .3 * (.5 + .5 * Math.sin(now / 320 + x.phase)) : .6;
        var d = x.drop > now ? (x.drop - now) / 480 : 0;
        x.gem.position.y = .2 + d * d * 1.2 + (reduce ? 0 : .018 * Math.sin(now / 700 + x.phase));
        x.gem.rotation.y = reduce ? .6 : now / 1900 + x.phase;
        x.own.scale.setScalar(picking && !x.flags.pickable ? .82 : 1);
      }
      var sh = ownIdx && !!x.flags.shield;
      x.dome.visible = sh; x.shell.visible = sh;
      if (sh) {
        var dc = hex(x.color).lerp(hex("#ffffff"), .6);
        x.dome.material.color.copy(dc); x.shell.material.color.copy(dc);
        x.dome.rotation.y = now / 2600; x.dome.material.opacity = .28 + .12 * (.5 + .5 * Math.sin(now / 900 + x.phase));
      }
      var tg = !!x.flags.pickable;
      x.ring.visible = tg;
      if (tg) { var k = (now / 1100 + x.phase) % 1; x.ring.scale.setScalar(.9 + k * .55); x.ring.material.opacity = .95 * (1 - k); }
      x.mesh.visible = true;
    }
    function paint(n, state, color, flags) {
      var x = R[n]; if (!x) return;
      var was = x.state, now = performance.now();
      x.state = state; x.color = color || ""; x.flags = flags || {};
      if (was !== state && was !== undefined) { x.flash = now + 650; if (typeof state === "number") x.drop = now + 480; }
      look(n, now); dirty = true;
    }
    function setTurn(i) { turn = i; dirty = true; }
    function setHl(i) { hl = i; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }
    function setPicking(on) { picking = !!on; canvas.style.cursor = on ? "crosshair" : ""; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }

    // ---- size
    function size() {
      var w = el.clientWidth, h = el.clientHeight; if (!w || !h) return;
      renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); dirty = true;
    }
    var ro = new ResizeObserver(size); ro.observe(el); size();

    // ---- pointer: hover tells (and lifts), a still tap picks
    var ray = new T.Raycaster(), ndc = new T.Vector2(), down = null;
    function hit(e) {
      var b = canvas.getBoundingClientRect();
      ndc.set(((e.clientX - b.left) / b.width) * 2 - 1, -((e.clientY - b.top) / b.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      var hits = ray.intersectObjects(pick, false);
      for (var i = 0; i < hits.length; i++) { var o = hits[i].object; if (o.visible && o.userData.region && (!o.parent || o.parent.visible)) return o.userData.region; }
      return null;
    }
    function hover(n) { if (hovered === n) return; hovered = n; dirty = true; }
    canvas.addEventListener("pointermove", function (e) {
      if (e.pointerType !== "mouse" || down) return;
      var n = hit(e); hover(n);
      if (n) { if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType); } else if (hooks.leave) hooks.leave();
    });
    canvas.addEventListener("pointerdown", function (e) { down = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId }; });
    canvas.addEventListener("pointerup", function (e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), dt = performance.now() - down.t; down = null;
      if (moved > 9 || dt > 600) return;
      var n = hit(e); if (!n) { hover(null); if (hooks.leave) hooks.leave(); return; }
      if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType);
      if (hooks.tap) hooks.tap(n);
    });
    canvas.addEventListener("pointercancel", function () { down = null; });
    canvas.addEventListener("pointerleave", function () { down = null; hover(null); if (hooks.leave) hooks.leave(); });
    //MC 2026-10-14 our own dispose forces a context loss too, so only a loss on a live table counts as a failure
    canvas.addEventListener("webglcontextlost", function (e) { e.preventDefault(); if (dead) return; dead = true; if (hooks.fail) hooks.fail("context"); });

    // ---- frames: capped (phones at 30), paused while the tab is hidden; the dust and the pieces keep it alive
    var last = 0, hidden = false, shown = false;
    document.addEventListener("visibilitychange", function () { hidden = document.hidden; if (!hidden) dirty = true; });
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      if (hidden) return;
      if (tween) tween(now);
      var moved = controls.update();
      if (now - last < (coarse ? 32 : 15) && !moved && !dirty) return;
      if (dust) {
        var p = dust.geometry.attributes.position, a = p.array;
        for (var i = 0, j = 0; i < a.length; i += 3, j += 2) { a[i + 1] += Math.sin(now / 1400 * dustSeed[j + 1] + dustSeed[j]) * .0012; a[i] += Math.cos(now / 2300 + dustSeed[j]) * .0008; }
        p.needsUpdate = true;
      }
      names.forEach(function (n) { look(n, now); });
      dirty = false; last = now;
      renderer.render(scene, camera);
      if (!shown) { shown = true; el.classList.add("is-ready"); }
    }
    raf = requestAnimationFrame(frame);
    view("overview", 0); camera.position.set(-2.5, 13, 9.5); controls.target.set(0, 0, 0); view("overview", 1500);

    function dispose() {
      dead = true; cancelAnimationFrame(raf); ro.disconnect();
      try { controls.dispose(); } catch (e) {}
      scene.traverse(function (o) { if (o.geometry) o.geometry.dispose(); var m = o.material; if (m) (Array.isArray(m) ? m : [m]).forEach(function (q) { if (q.map) q.map.dispose(); if (q.bumpMap) q.bumpMap.dispose(); q.dispose(); }); });
      try { renderer.dispose(); renderer.forceContextLoss(); } catch (e) {}
      if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
      el.classList.remove("is-ready");
    }
    return { paint: paint, setTurn: setTurn, setHl: setHl, setPicking: setPicking, view: function (v) { view(v, 900); }, resize: size, dispose: dispose, canvas: canvas };
  }

  window.ShyMap3D = { supported: supported, load: load, mount: mount };
})();
