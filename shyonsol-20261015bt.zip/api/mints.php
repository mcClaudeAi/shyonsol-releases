<?php
// The live mint tracker on the NFTs page: how many of the 1,335 Shytoshi Shadows are minted, who's collecting, which
// Auras are out, and the newest mints with their art. Read straight from Solana (the DAS lookup the holder check uses),
// at most once a minute for everyone; while one visit refreshes it, every other visit gets the last answer.
// A Shadow's mint time is when this first saw it. The first look marks everything already out as "before tracking",
// and the newest few get their real mint time from their first transaction on Solana.
// GET ?a=stats
// GET ?a=one&n=145   one minted Shadow up close (art, Aura, rarity, holder shortened); not minted yet gives minted:false
//MC 2026-10-15 first version
define('SHY_API', 1);
require __DIR__ . '/common.php';
require_once __DIR__ . '/holders.php';

const MINT_TOTAL = 1335;
const MINT_CACHE = DATA_DIR . '/cache-mints.php';
const MINT_SEEN = DATA_DIR . '/mints-seen.php';
const MINT_ALL = DATA_DIR . '/cache-mints-all.php';   //MC 2026-10-15 every minted Shadow by number, for ?a=one (the wall's close-up)   // asset id => ['n' => number, 't' => first seen ts (0 = before tracking), 'tx' => 1 once looked up]

function mt_rpc($method, $params, $timeout = 12) {
    $c = shy_config();
    $url = !empty($c['das_url']) ? $c['das_url'] : 'https://mainnet.helius-rpc.com/?api-key=' . rawurlencode($c['helius'] ?? '');
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(['jsonrpc' => '2.0', 'id' => 'mt', 'method' => $method, 'params' => $params]),
        CURLOPT_RETURNTRANSFER => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false || $code !== 200) return null;
    $j = json_decode($raw, true);
    return is_array($j) && array_key_exists('result', $j) ? $j['result'] : null;
}
function mt_short($w) { return strlen($w) > 10 ? substr($w, 0, 4) . '...' . substr($w, -4) : $w; }

// every Shadow minted so far, newest first
function mt_fetch() {
    $items = [];
    for ($page = 1; $page <= 3; $page++) {
        $r = mt_rpc('getAssetsByGroup', ['groupKey' => 'collection', 'groupValue' => SHADOWS_COLLECTION, 'page' => $page, 'limit' => 1000, 'sortBy' => ['sortBy' => 'created', 'sortDirection' => 'desc']]);
        if (!is_array($r) || !isset($r['items'])) return null;
        foreach ($r['items'] as $it) {
            if (!empty($it['burnt'])) continue;
            if (!preg_match('/#\s*(\d{1,5})/', (string)($it['content']['metadata']['name'] ?? ''), $m)) continue;
            $img = $it['content']['links']['image'] ?? ($it['content']['files'][0]['uri'] ?? '');
            $tr = nft_traits($it);
            $items[] = ['id' => (string)($it['id'] ?? ''), 'n' => (int)$m[1], 'img' => preg_match('#^https://#', $img) ? $img : '', 'owner' => (string)($it['ownership']['owner'] ?? ''),
                'aura' => (string)($tr['aura'] ?? ''), 'rank' => (string)($tr['rarity rank'] ?? ($tr['rank'] ?? ''))];
        }
        if (count($r['items']) < 1000) break;
    }
    return $items;
}
// when a Shadow was minted: the time of the oldest transaction on its address
function mt_mint_time($id) {
    $r = mt_rpc('getSignaturesForAddress', [$id, ['limit' => 1000]], 8);
    if (!is_array($r) || !$r) return 0;
    $last = end($r);
    return (int)($last['blockTime'] ?? 0);
}
function mt_build($items) {
    $seen = load(MINT_SEEN); $first = !$seen; $now = time();
    foreach ($items as $x) if ($x['id'] !== '' && !isset($seen[$x['id']])) $seen[$x['id']] = ['n' => $x['n'], 't' => $first ? 0 : $now];
    // the newest few without a real time get one from Solana (a few per refresh, once each)
    $looked = 0;
    foreach (array_slice($items, 0, 12) as $x) {
        if ($looked >= 4) break;
        $s = &$seen[$x['id']];
        if (empty($s['tx'])) { $t = mt_mint_time($x['id']); $looked++; $s['tx'] = 1; if ($t > 0) $s['t'] = $t; }
        unset($s);
    }
    save(MINT_SEEN, $seen);
    $owners = []; $auras = [];
    foreach ($items as $x) { if ($x['owner'] !== '') $owners[$x['owner']] = ($owners[$x['owner']] ?? 0) + 1; $a = $x['aura'] !== '' ? $x['aura'] : 'Unknown'; $auras[$a] = ($auras[$a] ?? 0) + 1; }
    arsort($owners); arsort($auras);
    // mints per day for the last 14 days (by first seen)
    $days = []; for ($i = 13; $i >= 0; $i--) $days[gmdate('Y-m-d', $now - $i * 86400)] = 0;
    $d24 = 0;
    foreach ($seen as $s) { if (empty($s['t'])) continue; $d = gmdate('Y-m-d', $s['t']); if (isset($days[$d])) $days[$d]++; if ($s['t'] > $now - 86400) $d24++; }
    $recent = array_map(fn($x) => ['n' => $x['n'], 'img' => $x['img'], 'aura' => $x['aura'], 'rank' => $x['rank'], 'asset' => $x['id'], 'owner' => mt_short($x['owner']), 't' => (int)($seen[$x['id']]['t'] ?? 0)], array_slice($items, 0, 16));
    $top = []; foreach (array_slice($owners, 0, 5, true) as $w => $n) $top[] = ['w' => mt_short($w), 'n' => $n];
    //MC 2026-10-15 the wall on the NFTs page: every minted number with its Aura (as an index into wa), newest first
    $wa = array_keys($auras); $wi = array_flip($wa); $wall = [];
    $all = [];
    foreach ($items as $x) {
        $wall[] = [$x['n'], $wi[$x['aura'] !== '' ? $x['aura'] : 'Unknown'] ?? 0];
        $all[$x['n']] = ['n' => $x['n'], 'img' => $x['img'], 'aura' => $x['aura'], 'rank' => $x['rank'], 'asset' => $x['id'], 'owner' => mt_short($x['owner']), 't' => (int)($seen[$x['id']]['t'] ?? 0)];
    }
    save(MINT_ALL, $all);
    $minted = min(MINT_TOTAL, count($items));
    $since = 0; foreach ($seen as $s) if (!empty($s['t']) && (!$since || $s['t'] < $since)) $since = $s['t'];
    return ['total' => MINT_TOTAL, 'minted' => $minted, 'left' => MINT_TOTAL - $minted, 'holders' => count($owners), 'last24' => $d24,
        'days' => array_map(fn($d, $n) => ['d' => $d, 'n' => $n], array_keys($days), $days), 'auras' => array_map(fn($a, $n) => ['a' => $a, 'n' => $n], array_keys($auras), $auras),
        'recent' => $recent, 'top' => $top, 'tracking' => $since, 'at' => $now, 'wa' => $wa, 'wall' => $wall];
}

$a = $_GET['a'] ?? 'stats';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
if ($a === 'one') {
    $n = (int)($_GET['n'] ?? 0);
    if ($n < 1 || $n > MINT_TOTAL) fail('No Shadow with that number.');
    $all = is_file(MINT_ALL) ? load(MINT_ALL) : [];
    header('Cache-Control: public, max-age=30');
    out(isset($all[$n]) ? ['ok' => true, 'minted' => true] + $all[$n] : ['ok' => true, 'minted' => false, 'n' => $n]);
}
if ($a !== 'stats') fail('unknown action');
$c = is_file(MINT_CACHE) ? load(MINT_CACHE) : [];
$fresh = !empty($c['at']) && time() - $c['at'] < 60;
if (!$fresh) {
    // one refresh at a time; anyone else gets the last answer straight away
    $lf = @fopen(DATA_DIR . '/mints.lock', 'c');
    if ($lf && flock($lf, LOCK_EX | LOCK_NB)) {
        try {
            $c2 = is_file(MINT_CACHE) ? load(MINT_CACHE) : [];
            if (empty($c2['at']) || time() - $c2['at'] >= 60) {
                $items = mt_fetch();
                if ($items !== null) { $c = mt_build($items); save(MINT_CACHE, $c); }
                elseif ($c) { $c['at'] = time() - 30; save(MINT_CACHE, $c); }   // Solana didn't answer: keep the last numbers, try again in 30s
            } else $c = $c2;
        } finally { flock($lf, LOCK_UN); fclose($lf); }
    }
}
if (!$c) fail('The mint numbers are loading. Try again in a moment.', 503);
header('Cache-Control: public, max-age=20');
out(['ok' => true] + $c);
