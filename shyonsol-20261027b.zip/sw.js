// Shy on Solana: browser notifications for friend requests, challenges and Duels.
// A push carries no message; this asks the site what's new and shows it. Nothing else is cached or intercepted.
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener("push", function (e) {
  e.waitUntil(self.registration.pushManager.getSubscription().then(function (sub) {
    if (!sub) return null;
    return fetch("/api/friends.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "push-pull", endpoint: sub.endpoint }) })
      .then(function (r) { return r.json(); }).catch(function () { return null; });
  }).then(function (j) {
    var t = j && j.ok ? j : { title: "Shilluminati Online", body: "Something new is waiting for you.", url: "/play?friends=1" };
    //MC 2026-10-18 renotify only for a rival at the door (the server says); the morning call and Dojo news land quietly
    return self.registration.showNotification(t.title, {
      body: t.body, tag: t.tag || "shy", renotify: t.re !== 0, icon: "/assets/art/icon-192.png", badge: "/assets/art/icon-192.png",
      vibrate: t.re !== 0 ? [70, 40, 70] : [50], data: { url: t.url || "/play" }
    });
  }));
});

self.addEventListener("notificationclick", function (e) {
  e.notification.close();
  var url = new URL((e.notification.data && e.notification.data.url) || "/play", self.location.origin).href;
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) if (list[i].url.indexOf(self.location.origin) === 0 && "navigate" in list[i]) return list[i].navigate(url).then(function (c) { return c && c.focus(); });
    return self.clients.openWindow(url);
  }));
});
