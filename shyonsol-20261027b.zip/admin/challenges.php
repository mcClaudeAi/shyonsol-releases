<?php
//MC 2026-10-22 Admin > Community challenges (api/vslib.php does the work). Refresh pulls a fresh batch of established
//   coin communities from DexScreener; every row waits here as New until a person looks at it. Approve opens that
//   community's page and card, Skip sets it aside, Block keeps it off the list for good. Post on X opens the X
//   composer in a new tab with the @handle, the words and the link ready, for a person to read, edit and send from the
//   brand account. Posts a day are capped, and a community can't be tagged again for a set number of days.
if (!defined('SHY_API')) exit;
require_once dirname(__DIR__) . '/api/vslib.php';

const VS_ST_LABEL = ['new' => 'To review', 'ok' => 'Approved', 'posted' => 'Challenged', 'skip' => 'Skipped', 'block' => 'Blocked'];

function vs_money($n) { $n = (float)$n; return '$' . ($n >= 1e9 ? round($n / 1e9, 1) . 'B' : ($n >= 1e6 ? round($n / 1e6, 1) . 'M' : ($n >= 1e3 ? round($n / 1e3) . 'K' : (string)round($n)))); }
function vs_posts_today($d) { return (int)($d['posts'][today()] ?? 0); }

function vs_admin_actions($do) {
    if ($do === 'vs-refresh') {
        $r = vs_refresh();
        if (empty($r['ok'])) go('players', $r['error'] ?? 'Refresh failed.', 'challenges');
        $w = $r['why'];
        go('players', 'Found ' . $r['added'] . ' new ' . ($r['added'] === 1 ? 'community' : 'communities') . ' to review' . ($r['updated'] ? ' and refreshed the numbers on ' . $r['updated'] . ' already listed' : '') . '. Looked at ' . $r['pairs'] . ' pools (searched ' . implode(', ', $r['seeds']) . '): ' . $w['young'] . ' too young, ' . $w['small'] . ' too small or quiet, ' . $w['nox'] . ' with no X account, ' . $w['falling'] . ' falling hard today.', 'challenges');
    }
    if ($do === 'vs-lookup') {
        $r = vs_lookup((string)($_POST['q'] ?? ''));
        if (empty($r['ok'])) go('players', $r['error'], 'challenges');
        $sts = ['new' => 'It is waiting under To review.', 'ok' => 'It was already approved.', 'posted' => 'It was already challenged.', 'skip' => 'It was skipped before: it is under Skipped.', 'block' => 'It is blocked, so it stays under Blocked.'];
        go('players', ($r['added'] ? 'Added ' : 'Found ') . $r['name'] . ', it passes the filters. ' . ($sts[$r['st']] ?? ''), 'challenges');
    }
    if ($do === 'vs-set') {
        $slug = (string)($_POST['c'] ?? ''); $st = (string)($_POST['st'] ?? '');
        if (!in_array($st, ['ok', 'skip', 'block', 'new'], true)) go('players', 'Pick what to do with it.', 'challenges');
        $msg = with_lock(function () use ($slug, $st) {
            $d = vs_all(); if (!isset($d['list'][$slug])) return 'That community is not on the list any more.';
            $was = $d['list'][$slug]['st'];
            // approving a community that was already challenged keeps its challenged date
            $d['list'][$slug]['st'] = $st === 'ok' && !empty($d['list'][$slug]['posted']) ? 'posted' : $st;
            $d['list'][$slug]['by'] = me()['username'] ?? ''; $d['list'][$slug]['at'] = time();
            save(VS_FILE, $d);
            $n = $d['list'][$slug]['name'];
            return ['ok' => 'Approved ' . $n . '. Its page is live at shyonsol.io/vs/' . $slug . ' and its card is ready.', 'skip' => 'Skipped ' . $n . '.', 'block' => 'Blocked ' . $n . '. It stays off the list, even when a refresh finds it again.', 'new' => 'Moved ' . $n . ' back to review.'][$st] . ($was === 'block' && $st !== 'block' ? ' (unblocked)' : '');
        });
        if ($st === 'ok') { $c = vs_all()['list'][$slug] ?? null; if ($c && ($c['img'] ?? '') !== '') vs_logo_fetch($slug, $c['img']); }
        go('players', $msg, 'challenges');
    }
    if ($do === 'vs-settings') {
        with_lock(function () {
            $d = vs_all();
            $chains = strtolower(preg_replace('/[^a-z0-9,]/i', '', (string)($_POST['chains'] ?? 'solana')));
            $d['cfg'] = ['chains' => $chains !== '' ? $chains : 'solana', 'age' => max(30, min(2000, (int)($_POST['age'] ?? 150))), 'liq' => max(0, (int)($_POST['liq'] ?? 50000)),
                'vol' => max(0, (int)($_POST['vol'] ?? 20000)), 'mc' => max(0, (int)($_POST['mc'] ?? 1000000)), 'drop' => max(5, min(95, (int)($_POST['drop'] ?? 40))),
                'cap' => max(1, min(20, (int)($_POST['cap'] ?? 5))), 'gap' => max(1, min(365, (int)($_POST['gap'] ?? 30))), 'per' => max(5, min(60, (int)($_POST['per'] ?? 25)))];
            save(VS_FILE, $d);
        });
        go('players', 'Challenge settings saved. The next Refresh uses them.', 'challenges');
    }
    //MC 2026-10-22 Post on X: counted against today's cap, the community marked Challenged, then this tab goes to the X
    //   composer with the words. The form opens in a new tab, so the admin page stays where it was.
    if ($do === 'vs-post') {
        $slug = (string)($_POST['c'] ?? '');
        $text = trim(preg_replace("/[ \t]+/", ' ', str_replace("\r", '', (string)($_POST['text'] ?? ''))));
        $res = with_lock(function () use ($slug, $text) {
            $d = vs_all(); $c = $d['list'][$slug] ?? null; $cfg = vs_cfg($d);
            if (!$c || !vs_live($c)) return ['err' => 'Approve the community before posting its challenge.'];
            if (vs_posts_today($d) >= (int)$cfg['cap']) return ['err' => 'That is ' . (int)$cfg['cap'] . ' challenge posts today already, the daily limit. Tagging many accounts in a day is what gets an X account flagged.'];
            if (!empty($c['posted']) && time() - (int)$c['posted'] < (int)$cfg['gap'] * 86400) return ['err' => $c['name'] . ' was challenged ' . ago((int)$c['posted']) . '. It can be tagged again after ' . (int)$cfg['gap'] . ' days.'];
            if ($text === '') $text = vs_post_text($c);
            $link = vs_link($slug);
            if (strpos($text, $link) === false) $text .= "\n" . $link;
            $d['list'][$slug]['posted'] = time(); $d['list'][$slug]['st'] = 'posted'; $d['list'][$slug]['pby'] = me()['username'] ?? '';
            $d['posts'][today()] = vs_posts_today($d) + 1;
            $d['posts'] = array_slice($d['posts'], -30, null, true);
            save(VS_FILE, $d);
            return ['url' => 'https://x.com/intent/tweet?text=' . rawurlencode(mb_substr($text, 0, 600))];
        });
        if (isset($res['err'])) go('players', $res['err'], 'challenges');
        header('Location: ' . $res['url'], true, 303); exit;
    }
}

function vs_section() {
    $d = vs_all(); $cfg = vs_cfg($d); $rw = can('players', 2);
    $by = ['new' => 0, 'ok' => 0, 'posted' => 0, 'skip' => 0, 'block' => 0];
    foreach ($d['list'] as $c) $by[$c['st']] = ($by[$c['st']] ?? 0) + 1;
    $f = (string)($_GET['vf'] ?? ''); if (!isset($by[$f])) $f = $by['new'] ? 'new' : ($by['ok'] ? 'ok' : 'new');
    $today = vs_posts_today($d);
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    echo '<h2 id="challenges">Community challenges <small>' . ($by['ok'] + $by['posted']) . ' live &middot; ' . $by['new'] . ' to review &middot; ' . $today . ' of ' . (int)$cfg['cap'] . ' posts today</small></h2>';
    echo '<p class="muted">Refresh finds established coin communities on DexScreener: at least ' . (int)$cfg['age'] . ' days old, ' . vs_money($cfg['liq']) . ' liquidity, ' . vs_money($cfg['vol']) . ' traded in 24 hours, ' . vs_money($cfg['mc']) . ' market cap, not down ' . (int)$cfg['drop'] . '% or more today, and an X account listed on their DexScreener page. Each search is random, so every press turns up a different batch. Check each one before approving: an old coin with an X account is not always a good one. Approving opens its page at shyonsol.io/vs/&lt;name&gt; with its own card. <b>Post on X</b> opens the X composer in a new tab with the tag, the words and the link ready; read it, change anything, and post it from the brand account. Up to ' . (int)$cfg['cap'] . ' a day, and the same community can only be tagged once every ' . (int)$cfg['gap'] . ' days.</p>';
    if ($rw) echo '<form method="post" class="bar">' . $csrf . '<button name="do" value="vs-refresh">Refresh the list</button><span class="muted small">' . ($d['last'] ? 'Last refreshed ' . h(ago((int)$d['last'])) . '.' : 'Not refreshed yet.') . ' Takes a few seconds.</span></form>'
        . '<form method="post" class="bar">' . $csrf . '<input name="q" placeholder="Look up one: a name, a ticker or a contract address" maxlength="64" required style="min-width:320px" autocomplete="off" spellcheck="false"><button name="do" value="vs-lookup" class="ghost">Look it up</button><span class="muted small">Same filters. It lands under To review if it passes.</span></form>';
    echo '<details class="vs-cfg"' . (!$d['list'] ? ' open' : '') . '><summary>What counts as established</summary><form method="post" class="settings">' . $csrf . '<fieldset class="fs"' . ($rw ? '' : ' disabled') . '><legend>Filters</legend>'
        . '<label><span>Chains</span><input name="chains" value="' . h($cfg['chains']) . '"><small>Comma separated, as DexScreener names them: solana, base, ethereum, bsc.</small></label>'
        . '<label><span>At least this many days old</span><input name="age" type="number" min="30" value="' . (int)$cfg['age'] . '"><small>150 is about five months.</small></label>'
        . '<label><span>Liquidity at least ($)</span><input name="liq" type="number" min="0" value="' . (int)$cfg['liq'] . '"></label>'
        . '<label><span>24 hour volume at least ($)</span><input name="vol" type="number" min="0" value="' . (int)$cfg['vol'] . '"></label>'
        . '<label><span>Market cap at least ($)</span><input name="mc" type="number" min="0" value="' . (int)$cfg['mc'] . '"></label>'
        . '<label><span>Leave out if down this % today</span><input name="drop" type="number" min="5" max="95" value="' . (int)$cfg['drop'] . '"></label>'
        . '<label><span>New rows per refresh</span><input name="per" type="number" min="5" max="60" value="' . (int)$cfg['per'] . '"></label>'
        . '<label><span>Challenge posts a day</span><input name="cap" type="number" min="1" max="20" value="' . (int)$cfg['cap'] . '"><small>Keep it low: X flags accounts that tag a lot of strangers.</small></label>'
        . '<label><span>Days before tagging the same one again</span><input name="gap" type="number" min="1" max="365" value="' . (int)$cfg['gap'] . '"></label>'
        . '</fieldset>' . ($rw ? '<div class="bar"><button name="do" value="vs-settings">Save filters</button></div>' : '') . '</form></details>';
    if (!$d['list']) { echo '<p class="muted">Nothing on the list yet. Press Refresh the list.</p>'; return; }
    echo '<p class="bar vs-tabs">';
    foreach (VS_ST_LABEL as $k => $l) echo '<a class="btn' . ($k === $f ? '' : ' ghost') . '" href="?p=vs&amp;vf=' . $k . '#challenges">' . h($l) . ' <i>' . (int)$by[$k] . '</i></a>';
    echo '</p>';
    $rows = array_filter($d['list'], fn($c) => $c['st'] === $f);
    uasort($rows, fn($a, $b) => $f === 'posted' ? ($b['posted'] <=> $a['posted']) : ($b['liq'] <=> $a['liq']));
    if (!$rows) { echo '<p class="muted">None here.</p>'; return; }
    echo '<div class="tw"><table class="vs-t"><thead><tr><th></th><th>Community</th><th>On X</th><th>Market cap</th><th>Liquidity</th><th>24h volume</th><th>24h</th><th></th></tr></thead><tbody>';
    foreach (array_slice($rows, 0, 80, true) as $slug => $c) {
        $logo = '<img src="/api/vs.php?a=logo&amp;c=' . h(rawurlencode($slug)) . '" alt="" width="36" height="36" loading="lazy" style="border-radius:50%;background:#150e2b" onerror="this.style.visibility=\'hidden\'">';
        $who = '<b>' . h($c['name']) . '</b><small>$' . h(strtoupper($c['sym'])) . ' &middot; ' . (int)floor($c['age'] / 30.4) . ' months &middot; ' . h($c['chain']) . ($c['url'] ? ' &middot; <a href="' . h($c['url']) . '" target="_blank" rel="noopener">chart</a>' : '') . '</small>';
        $acts = '';
        $set = fn($st, $label, $cls = '', $confirm = '') => '<form method="post">' . $csrf . '<input type="hidden" name="c" value="' . h($slug) . '"><input type="hidden" name="st" value="' . $st . '"><button name="do" value="vs-set"' . ($cls ? ' class="' . $cls . '"' : '') . ($confirm ? ' data-confirm="' . h($confirm) . '"' : '') . '>' . $label . '</button></form>';
        if ($rw) {
            if (in_array($c['st'], ['new', 'skip'], true)) $acts .= $set('ok', 'Approve') . ($c['st'] === 'new' ? $set('skip', 'Skip', 'ghost') : '') . $set('block', 'Block', 'danger', 'Block ' . $c['name'] . '? It never comes back on the list.');
            if (vs_live($c)) {
                $wait = !empty($c['posted']) && time() - (int)$c['posted'] < (int)$cfg['gap'] * 86400;
                $full = $today >= (int)$cfg['cap'];
                $acts .= '<form method="post" target="_blank" class="vs-post">' . $csrf . '<input type="hidden" name="c" value="' . h($slug) . '"><textarea name="text" rows="3" maxlength="500">' . h(vs_post_text($c)) . '</textarea><span class="muted small">The link to its page goes on the end.</span><button name="do" value="vs-post"' . ($wait || $full ? ' disabled' : '') . '>Post on X</button>' . ($wait ? '<small class="muted">Challenged ' . h(ago((int)$c['posted'])) . '. Again in ' . (int)ceil(((int)$cfg['gap'] * 86400 - (time() - (int)$c['posted'])) / 86400) . ' days.</small>' : ($full ? '<small class="muted">Today\'s ' . (int)$cfg['cap'] . ' posts are used.</small>' : '')) . '</form>';
                $acts .= '<a class="btn ghost" href="/vs/' . h($slug) . '" target="_blank" rel="noopener">Open page</a><a class="btn ghost" href="/api/share.php?vs=' . h(rawurlencode($slug)) . '&amp;h=' . h(substr(md5((string)time()), 0, 6)) . '" target="_blank" rel="noopener">Card</a>' . $set('skip', 'Take down', 'ghost', 'Take ' . $c['name'] . '\'s page down?');
            }
            if ($c['st'] === 'block') $acts .= $set('skip', 'Unblock', 'ghost');
        }
        $pc = (float)$c['pc'];
        echo '<tr><td>' . $logo . '</td><td>' . $who . '</td><td><a class="xh" href="https://x.com/' . h($c['x']) . '" target="_blank" rel="noopener">@' . h($c['x']) . '</a></td><td>' . vs_money($c['mc']) . '</td><td>' . vs_money($c['liq']) . '</td><td>' . vs_money($c['vol']) . '</td><td>' . ($pc >= 0 ? '<i class="ok">+' . h($pc) . '%</i>' : '<i class="' . ($pc <= -15 ? 'bad' : 'warn') . '">' . h($pc) . '%</i>') . '</td><td class="acts">' . $acts . '</td></tr>';
    }
    echo '</tbody></table></div>';
    if (count($rows) > 80) echo '<p class="muted small">Showing the 80 with the most liquidity of ' . count($rows) . '.</p>';
}
