// Profile Studio: the part of the Dojo Shop that dresses up your public player page. It lives on the profile page only.
// Tap anything to try it on in the preview; buy with Koban, then wear it. The showcase and motto are one-time unlocks.
(function () {
  "use strict";
  var SHOP = "api/shop.php";
  //MC 2026-10-10 two new tabs for the animated collection: Frames (around your picture) and Seals (stamped on its corner)
  var TABS = [["banner", "Banners"], ["pframe", "Frames"], ["seal", "Seals"], ["plate", "Nameplates"], ["pfx", "Effects"], ["accent", "Accents"], ["showcase", "Showcase"], ["motto", "Motto"], ["extras", "Extras"]];
  var RAR = { rare: "Rare", epic: "Epic", legendary: "Legendary", mythic: "Mythic", imperial: "Imperial", dev: "Dev" };   //MC 2026-10-24 Imperial
  var LEAD = {
    banner: "The art behind your page header, the first thing visitors see.",
    plate: "How your name is written on your page.",
    pfx: "A little weather drifting over your page header.",
    pframe: "An animated frame around your picture. It shows on your page, and next to your name on the leaderboards and in Friends.",
    seal: "A seal stamped on the corner of your picture as your page opens.",
    accent: "The colour of your page's cards, borders and highlights.",
    showcase: "Pin three cards to your page, in any finish you own.",
    motto: "A short line under your name. Up to 60 characters, no links.",
    extras: "More for your page: bring your picture to life, and count your visitors."
  };
  //MC 2026-10-10 the Animated finishes too, so a showcased one has its name
  var FIN_N = { gold: "Gold Leaf", crimson: "Blood Moon", neon: "Neon Shrine", holo: "Holo Foil", shadow: "Shadow Ink", ink: "Ink Bleed", seal: "Vermilion Seal", smoke: "Smoke Wisp", kintsugi: "Kintsugi", sakura: "Sakura Drift", ember: "Ember Rise", frost: "Frost Creep", koi: "Koi Pond", raijin: "Raijin Crackle", glitch: "Glitch Scan", aurora: "Aurora Veil", cosmos: "Night Sky", regalia: "Imperial Gilt" };
  var ACC = { vermilion: "#ff5d4a", jade: "#2ef0b0", violet: "#b78cff", ice: "#8fe3ff", gold: "#f2c35b", obsidian: "#2a2838", sakura: "#ff8fb0", ocean: "#5aa8ff", ember: "#ff8a3d" };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function koban(n) { return '<span class="kb"><i class="kb-coin" aria-hidden="true"></i>' + fmt(n) + '</span>'; }
  function short(id) { return id.replace(/^[a-z]+_/, ""); }
  // what a holder actually pays (same rounding as the server's koban_price)
  function price(base, disc) { return Math.max(5, Math.round(base * (100 - (disc || 0)) / 100 / 5) * 5); }

  function mount(el, ctx) {
    // ctx: { post(url, body), name, avatar (html), onLook(page) }
    var S = { tab: "banner", cat: null, me: null, try: null, msg: "", busy: false, pick: null, pg: {} };
    var L = window.ShyLook;
    //MC 2026-10-10 the animated collection (items with a rarity) comes first in each tab, cheapest first
    function items(slot) {
      var l = (S.cat.items || []).filter(function (x) { return x.slot === slot && (!x.dev || owns(x.id)); });   //MC 2026-10-12 the Dev collection only shows to its owner
      return l.filter(function (x) { return x.rarity; }).sort(function (a, b) { return ((b.rarity === "imperial") - (a.rarity === "imperial")) || a.koban - b.koban; }).concat(l.filter(function (x) { return !x.rarity; }));
    }
    function owns(id) { return S.me.owned.indexOf(id) >= 0; }
    function worn(slot) { var id = S.me.eq[slot]; return id && owns(id) ? id : ""; }
    // the page as saved, with whatever is being tried on laid over it
    function look() {
      var pg = {}, p = S.me.page || {};
      ["banner", "plate", "pfx", "accent", "pframe", "seal"].forEach(function (k) { if (p[k]) pg[k] = p[k]; });
      if (p.motto) pg.motto = p.motto;
      if (S.try) { if (S.try.id === "") delete pg[S.try.slot]; else pg[S.try.slot] = short(S.try.id); }
      if (S.draft != null) pg.motto = S.draft;
      return pg;
    }
    function preview() {
      var pg = look(), st = (ctx.stats && ctx.stats()) || { wr: 0, best: 0 };
      var ti = S.try && S.try.id ? S.cat.items.filter(function (x) { return x.id === S.try.id; })[0] || {} : {}, t = ti.name || "";
      return '<div class="st-prev-wrap' + L.page(pg) + '"><div class="st-prev ' + L.head(pg) + '">' + (L.layers ? L.layers(pg, 11) : L.fx(pg, 11)) +
        (L.avatar ? L.avatar(pg, '<div class="st-pav">' + ctx.avatar() + '</div>') : '<div class="st-pav">' + ctx.avatar() + '</div>') + '<div class="st-pid"><span class="pp-k">Your page</span><b class="st-pname' + L.name(pg) + '" data-i18n-skip>' + esc(ctx.name() || "Your name") + '</b>' +
        (pg.motto ? '<p class="pp-motto" dir="auto" data-i18n-skip>' + esc(pg.motto) + '</p>' : "") +
        '<div class="st-ptiles"><span class="pp-tile"><small>Win rate</small><b>' + st.wr + '%</b></span><span class="pp-tile"><small>Best game</small><b>' + st.best + '</b></span></div></div></div>' +
        '<div class="st-prev-bar">' + (t ? '<span>Trying on <b>' + esc(t) + '</b>' + (ti.desc ? '<small class="st-desc">' + esc(ti.desc) + '</small>' : "") + '</span><button type="button" class="btn btn-line btn-sm" data-st-untry>Back to yours</button>' : '<span>This is your page right now. Tap anything to try it on.</span>') +
        (ctx.url() ? '<a class="btn btn-line btn-sm" href="' + esc(ctx.url()) + '" target="_blank" rel="noopener">Open your page ↗</a>' : "") + '</div></div>';
    }
    function swatch(it) {
      var k = short(it.id);
      if (it.slot === "banner") return '<span class="st-sw st-sw-b pg-look pgb-' + k + '">' + (L.bg ? L.bg({ banner: k }) : "") + '</span>';
      //MC 2026-10-10 frames and seals try themselves on a small copy of your picture
      if (it.slot === "pframe" || it.slot === "seal") { var o = {}; o[it.slot] = k; return '<span class="st-sw st-sw-' + (it.slot === "seal" ? "s" : "r") + '">' + L.avatar(o, '<span class="st-swav">' + ctx.avatar() + '</span>') + '</span>'; }
      if (it.slot === "plate") return '<span class="st-sw st-sw-n"><b class="pgn-' + k + '">Aa</b></span>';
      if (it.slot === "pfx") return '<span class="st-sw st-sw-f">' + L.fx({ pfx: k }, 3) + '</span>';
      if (it.slot === "accent") return '<span class="st-sw st-sw-a" style="--c:' + (ACC[k] || "#888") + '"><i></i><i></i><i></i></span>';
      return "";
    }
    function card(it) {
      var own = owns(it.id), on = worn(it.slot) === it.id, trying = S.try && S.try.id === it.id;
      var act;
      if (on) act = '<button type="button" class="btn btn-line btn-sm on" data-st-equip="' + it.slot + ':">Wearing</button>';
      else if (own) act = '<button type="button" class="btn btn-mint btn-sm" data-st-equip="' + it.slot + ':' + it.id + '">Wear</button>';
      else if (it.holder) act = '<span class="st-lock">$SHY holders</span>';
      else if (it.koban) { var pr = price(it.koban, S.me.disc); act = '<button type="button" class="btn btn-red btn-sm" data-st-buy="' + it.id + '"' + (S.me.koban < pr ? ' data-short="' + pr + '"' : "") + '>' + koban(pr) + '</button>'; }
      else act = '<span class="st-lock">Not for sale</span>';
      return '<div class="st-it' + (on ? " on" : "") + (trying ? " try" : "") + '" data-st-try="' + it.id + '" data-slot="' + it.slot + '" tabindex="0" role="button" aria-label="Try on ' + esc(it.name) + '">' + swatch(it) +
        '<div class="st-it-t"><b>' + esc(it.name) + '</b>' + (it.tag ? '<em>' + esc(it.tag) + '</em>' : "") + (RAR[it.rarity] ? '<em class="st-r r-' + it.rarity + '">' + RAR[it.rarity] + '</em>' : "") + (it.holder ? '<em class="h">Holders</em>' : "") + '</div><div class="st-it-a">' + act + '</div></div>';
    }
    function unlockCard(id, title, text) {
      var it = S.cat.items.filter(function (x) { return x.id === id; })[0];
      if (!it) return "";
      var pr = price(it.koban, S.me.disc);
      return '<div class="st-unlock"><div><b>' + title + '</b><p>' + text + '</p></div><button type="button" class="btn btn-red" data-st-buy="' + id + '"' + (S.me.koban < pr ? ' data-short="' + pr + '"' : "") + '>Unlock for ' + koban(pr) + '</button></div>';
    }
    function showcase() {
      if (!owns("unlock_showcase")) return unlockCard("unlock_showcase", "Card Showcase", "Pin three cards to your page in any finish you own: your Holo Foil pulls, your Shadow Ink, the card you win with. Visitors see them big, right under your stats.");
      var deck = S.cat.deck || {}, ids = Object.keys(deck).sort(function (a, b) { return deck[a].name.localeCompare(deck[b].name); });
      var cur = (S.pick || (S.me.pg && S.me.pg.show) || []).map(function (x) { return Array.isArray(x) ? { card: x[0], fin: x[1] } : x; });
      while (cur.length < 3) cur.push({ card: "", fin: "" });
      S.pick = cur;
      var vf = S.me.vf || {};
      return '<div class="st-show">' + cur.map(function (x, i) {
        var fins = Object.keys(vf[x.card] || {}).filter(function (f) { return vf[x.card][f]; });
        return '<div class="st-slot"><span class="st-slot-n">' + (i + 1) + '</span>' +
          '<span class="st-slot-art cf' + (x.fin ? " vf-" + esc(x.fin) : "") + '">' + (x.card ? '<img src="assets/cards/' + esc(x.card) + '.webp" alt="">' : '<i>Empty</i>') + '</span>' +
          '<label><small>Card</small><select data-st-card="' + i + '"><option value="">Empty</option>' + ids.map(function (c) { return '<option value="' + c + '"' + (c === x.card ? " selected" : "") + '>' + esc(deck[c].name) + ((vf[c] && Object.keys(vf[c]).length) ? " ✦" : "") + '</option>'; }).join("") + '</select></label>' +
          '<label><small>Finish</small><select data-st-fin="' + i + '"' + (x.card ? "" : " disabled") + '><option value="">Plain card</option>' + fins.map(function (f) { return '<option value="' + f + '"' + (f === x.fin ? " selected" : "") + '>' + FIN_N[f] + '</option>'; }).join("") + '</select></label></div>';
      }).join("") + '</div><p class="st-note">✦ marks cards you own a finish for. Finishes come from the Dojo Shop, your Scroll and mastering cards.</p><div class="st-save"><button type="button" class="btn btn-mint" data-st-show>Save showcase</button></div>';
    }
    function motto() {
      if (!owns("unlock_motto")) return unlockCard("unlock_motto", "Motto", "A short line under your name on your page: a war cry, a flex, a riddle. Up to 60 characters. Links and handles aren't allowed.");
      var v = S.draft != null ? S.draft : (S.me.pg && S.me.pg.motto) || "";
      return '<div class="st-motto"><input data-st-motto dir="auto" maxlength="60" value="' + esc(v) + '" placeholder="Fortune favours the shy." autocomplete="off"><span class="st-count">' + v.length + ' / 60</span></div><div class="st-save"><button type="button" class="btn btn-mint" data-st-mottosave>Save motto</button>' + (v ? '<button type="button" class="btn btn-line" data-st-mottoclear>Remove</button>' : "") + '</div>';
    }
    //MC 2026-10-09 Extras: the Living Portrait and the Visit Counter. Each is bought once and then always on.
    function extras() {
      var src = (/src="([^"]+)"/.exec(ctx.avatar() || "") || [])[1] || "";
      var demo = window.ShyLiving && src ? '<div class="st-ex-demo">' + ShyLiving.html(src.replace(/&amp;/g, "&"), { size: "92px", fb: "assets/art/masks/unbound.svg" }) + '</div>' : "";
      function one(id, title, text, art) {
        var it = S.cat.items.filter(function (x) { return x.id === id; })[0];
        if (!it) return "";
        if (owns(id)) return '<div class="st-unlock st-ex on">' + art + '<div><b>' + title + '</b><p>' + text + '</p></div><span class="owned">On your page</span></div>';
        var pr = price(it.koban, S.me.disc);
        return '<div class="st-unlock st-ex">' + art + '<div><b>' + title + '</b><p>' + text + '</p></div><button type="button" class="btn btn-red" data-st-buy="' + id + '"' + (S.me.koban < pr ? ' data-short="' + pr + '"' : "") + '>Unlock for ' + koban(pr) + '</button></div>';
      }
      return one("unlock_portrait", "Living Portrait", "Your picture on your page comes alive: it floats, turns in 3D and catches the light, like the Shadows in the game. A holder's own Shadow glows in its Aura colour.", demo) +
        one("unlock_visits", "Visit Counter", "Shows how many people have opened your page, right under your name. Each visitor counts once a day.", '<div class="st-ex-demo st-ex-count"><b>128</b><small>visits</small></div>');
    }
    function body() {
      if (S.tab === "extras") return extras();
      if (S.tab === "showcase") return showcase();
      if (S.tab === "motto") return motto();
      //MC 2026-10-09 six to a page. The grid had grown past two screens; a tab opens on the page with what you're wearing
      var list = items(S.tab), PER = 6;
      if (!S.pg[S.tab]) { var w = worn(S.tab), wi = -1; list.forEach(function (x, i) { if (x.id === w) wi = i; }); S.pg[S.tab] = wi >= 0 ? Math.floor(wi / PER) + 1 : 1; }
      var pp = window.ShyPager ? ShyPager.slice(list, PER, S.pg[S.tab]) : { items: list };
      return '<div class="st-grid">' + pp.items.map(card).join("") + '</div>' + (window.ShyPager ? ShyPager.html(pp, "st") : "") +
        (worn(S.tab) ? '<p class="st-note"><button type="button" class="st-link" data-st-equip="' + S.tab + ':">Take off your ' + esc((TABS.filter(function (t) { return t[0] === S.tab; })[0] || [])[1] || "").toLowerCase().replace(/s$/, "") + '</button></p>' : "");
    }
    function draw() {
      if (!S.cat || !S.me) { el.innerHTML = '<div class="pf-h"><h2>Profile Studio</h2></div><p class="pf-empty">Opening the studio…</p>'; return; }
      el.innerHTML = '<div class="st-top"><div><span class="pf-k st-k">Dojo Shop · Profile Studio</span><h2>Dress up your page</h2><p>Banners, nameplates, effects and more for your public player page. Only sold here.</p></div>' +
        //MC 2026-10-10 Get more lands on Buy Koban in the shop's Mint, not on today's deals
        '<div class="st-bal"><small>Your Koban</small><b>' + koban(S.me.koban) + '</b>' + (S.me.disc ? '<span class="st-disc">Holder price: ' + S.me.disc + '% off</span>' : "") + '<a href="/play#shop-koban" class="st-link">Get more →</a></div></div>' +
        '<div class="st-main">' + preview() + '<div class="st-side"><nav class="st-tabs" role="tablist">' + TABS.map(function (t) { return '<button type="button" role="tab" data-st-tab="' + t[0] + '"' + (t[0] === S.tab ? ' class="on" aria-selected="true"' : ' aria-selected="false"') + '>' + t[1] + '</button>'; }).join("") + '</nav>' +
        '<p class="st-lead">' + LEAD[S.tab] + '</p>' + (S.msg ? '<p class="st-msg">' + esc(S.msg) + '</p>' : "") + body() + '</div></div>';
    }
    function setMe(me) { if (me) { S.me = me; if (ctx.onLook) ctx.onLook(me.page || {}); } }
    async function load() {
      var a = await Promise.all([fetch(SHOP + "?a=catalog").then(function (r) { return r.json(); }).catch(function () { return {}; }), ctx.post(SHOP, { a: "me" })]);
      if (a[0] && a[0].ok) S.cat = a[0];
      if (a[1] && a[1].ok) setMe(a[1].me);
      if (!S.cat || !S.me) { el.innerHTML = '<div class="pf-h"><h2>Profile Studio</h2></div><p class="pf-empty">The studio couldn\'t open right now. Refresh to try again.</p>'; return; }
      draw();
    }
    async function act(body, ok) {
      if (S.busy) return; S.busy = true; S.msg = "";
      var j = await ctx.post(SHOP, body);
      S.busy = false;
      if (j.ok) { setMe(j.me); if (ok) ok(j); } else S.msg = j.error || "That didn't work. Try again.";
      draw();
    }
    el.addEventListener("click", function (e) {
      var b;
      var pg = window.ShyPager && ShyPager.hit(e, "st");
      if (pg) {
        S.pg[S.tab] = pg.page; draw();
        // keep the grid in view when a page change makes the list shorter
        var t = el.querySelector(".st-tabs"); if (t) { var r = t.getBoundingClientRect(); if (r.top < 0) scrollTo({ top: scrollY + r.top - 12, behavior: "smooth" }); }
        return;
      }
      if ((b = e.target.closest("[data-st-tab]"))) { S.tab = b.dataset.stTab; S.try = null; S.msg = ""; draw(); return; }
      if (e.target.closest("[data-st-untry]")) { S.try = null; draw(); return; }
      if ((b = e.target.closest("[data-st-buy]"))) {
        e.stopPropagation();
        var it = S.cat.items.filter(function (x) { return x.id === b.dataset.stBuy; })[0];
        if (b.dataset.short) { S.msg = "You need " + fmt(+b.dataset.short - S.me.koban) + " more Koban for " + it.name + ". Get more in the Dojo Shop."; draw(); return; }
        act({ a: "buy", item: b.dataset.stBuy }, function (j) {
          S.try = null; S.msg = it ? it.name + " is yours" + (it.slot === "unlock" && !/^unlock_(portrait|visits)$/.test(it.id) ? "." : " and on your page now.") : "";
          //MC 2026-10-24 an Imperial piece comes out of its box with its number, wearing a copy of your picture
          if (j && j.imp && it && window.ShyImp) {
            var o = {}; o[it.slot] = short(it.id);
            var art = it.slot === "banner" ? '<div class="iv-pv pgb-box pg-look pgb-' + short(it.id) + '">' + L.bg(o) + '</div>' : it.slot === "plate" ? '<div class="iv-pv plate-box"><b class="pgn-' + short(it.id) + '" data-i18n-skip>' + esc(ctx.name() || "Your name") + '</b></div>' :
              it.slot === "pfx" ? '<div class="iv-pv pgfx-box">' + L.fx(o, 5) + '</div>' : '<div class="iv-pv pfr-box">' + L.avatar(o, '<span class="iv-av">' + ctx.avatar() + '</span>') + '</div>';
            ShyImp.ceremony({ name: it.name, desc: it.desc, no: j.imp.no, rank: j.imp.rank, rankName: j.imp.name, up: j.imp.up, art: art });
          }
        });
        return;
      }
      if ((b = e.target.closest("[data-st-equip]"))) { e.stopPropagation(); var p = b.dataset.stEquip.split(":"); act({ a: "equip", slot: p[0], item: p[1] || "" }, function () { S.try = null; }); return; }
      if (e.target.closest("[data-st-show]")) {
        var show = (S.pick || []).filter(function (x) { return x.card; });
        act({ a: "page", show: show }, function () { S.pick = null; S.msg = show.length ? "Showcase saved." : "Showcase cleared."; });
        return;
      }
      if (e.target.closest("[data-st-mottosave]")) { var v = (S.draft != null ? S.draft : (S.me.pg && S.me.pg.motto) || "").trim(); act({ a: "page", motto: v }, function () { S.draft = null; S.msg = v ? "Motto saved." : "Motto removed."; }); return; }
      if (e.target.closest("[data-st-mottoclear]")) { act({ a: "page", motto: "" }, function () { S.draft = null; S.msg = "Motto removed."; }); return; }
      if ((b = e.target.closest("[data-st-try]"))) {
        var id = b.dataset.stTry; S.try = S.try && S.try.id === id ? null : { slot: b.dataset.slot, id: id }; draw();
        //MC 2026-10-09 on phones the preview is way above the item grid, so try-on happened off screen. Bring it into view
        if (S.try && matchMedia("(max-width:760px)").matches) { var pv = el.querySelector(".st-prev-wrap"); if (pv) { var r = pv.getBoundingClientRect(); if (r.top < 0 || r.top > innerHeight * 0.5) scrollTo({ top: scrollY + r.top - 12, behavior: "smooth" }); } }
      }
    });
    el.addEventListener("keydown", function (e) { var b = e.target.closest && e.target.closest("[data-st-try]"); if (b && (e.key === "Enter" || e.key === " ") && e.target === b) { e.preventDefault(); b.click(); } });
    el.addEventListener("change", function (e) {
      var c = e.target.closest("[data-st-card]"), f = e.target.closest("[data-st-fin]");
      if (c) { S.pick[+c.dataset.stCard] = { card: c.value, fin: "" }; draw(); }
      if (f) { S.pick[+f.dataset.stFin].fin = f.value; draw(); }
    });
    el.addEventListener("input", function (e) {
      var m = e.target.closest("[data-st-motto]"); if (!m) return;
      S.draft = m.value;
      var c = el.querySelector(".st-count"); if (c) c.textContent = m.value.length + " / 60";
      var pv = el.querySelector(".st-prev .pp-motto");
      if (pv) pv.textContent = m.value; else { var nm = el.querySelector(".st-pname"); if (nm && m.value) nm.insertAdjacentHTML("afterend", '<p class="pp-motto" dir="auto" data-i18n-skip>' + esc(m.value) + '</p>'); }
    });
    draw(); load();
    return { reload: load };
  }
  window.ShyStudio = { mount: mount };
})();
