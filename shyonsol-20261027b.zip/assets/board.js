// The leaderboard: one component for the Play page and the Stats page.
// Top 3 on a podium, pages of 10 that swap in place (the page never jumps), a Find me button that opens
// the page your name is on, and a tap on any player for their record.
(function () {
  "use strict";
  var root = document.querySelector("[data-shyboard]");
  if (!root) return;
  var API = "api/lb.php";
  var AV = (function () { var s = document.querySelector('script[src*="board.js"]'); var m = s && /[?&]v=([\w.-]+)/.exec(s.src); return m ? "?v=" + m[1] : ""; })();
  var UNBOUND = "assets/art/masks/unbound.svg" + AV;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  function store(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function myTag() { return (store("shy-lb-pid") || "").slice(0, 6); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }

  var TABS = [["live", "Live"], ["ranked", "Ranked"], ["all", "All time"], ["week", "Week"], ["daily", "Daily"], ["holders", "Holders"], ["shadows", "Shadows"]];
  var SUB = {
    all: "Every finished game adds points: 5 per Region you hold, plus 100 for a win or 50 for a tie. Easy and hints each halve it.",
    week: "Points earned since Monday (UTC). Resets every week, so anyone can top it.",
    daily: "One shot each, same deck for everyone. Your first Daily run of the day is the one that counts.",
    live: "Live matches only. The server runs every game, so nobody can fake these. Beating real players earns +20 each.",
    ranked: "This season's ranked ladder: live matches with at least one other real player move your Rank Points. Win for +30, finish 2nd for +5. Bronze, Silver, Gold, Jade, then Shogun. Every season starts again at 0, and your final tier pays Koban.",
    holders: "Verified Shadow holders only, all points since Monday (UTC). Prizes are paid on the Weekly League and Holder Cup boards.",
    shadows: "Every Shytoshi Shadow keeps its own record. Sell it and the record goes with it, so a proven Shadow is worth more."
  };
  var EMPTY = {
    daily: "Nobody has played today's Daily yet. Take the top spot.", live: "No live matches yet. Be the first name up here.", ranked: "No ranked matches this season yet. Play a live match against a real player to get on the ladder.",
    holders: "No verified holders have played this week yet.", shadows: "No Shadow has a record yet. Holders, connect your wallet and start one."
  };
  var S = { board: root.dataset.default || "live", page: 1, pages: 1, data: null, open: -1, busy: false, owned: function () { return []; } };

  root.innerHTML =
    '<div class="sb-tabs" role="tablist">' + TABS.map(function (t) { return '<button type="button" role="tab" data-sb-tab="' + t[0] + '">' + t[1] + '</button>'; }).join("") + '</div>' +
    '<p class="sb-sub" id="sb-sub"></p>' +
    '<div class="sb-head"><small id="sb-total">Loading...</small><span class="sb-acts"><button type="button" class="sb-btn" data-sb-me hidden>Find me</button>' +
    (root.dataset.statsLink ? '<a class="sb-btn" href="stats.html#board">All stats</a>' : "") + '<button type="button" class="sb-btn" data-sb-refresh aria-label="Refresh">Refresh</button></span></div>' +
    '<div class="sb-stage" id="sb-stage"><div class="sb-podium" id="sb-podium"></div><ol class="sb-list" id="sb-list"><li class="sb-empty">Loading the board...</li></ol></div>' +
    '<nav class="sb-pager" id="sb-pager" hidden aria-label="Leaderboard pages"></nav>' +
    '<p class="sb-fine">Names are public. Be nice. Scores from this site only.</p>';
  var $ = function (id) { return document.getElementById(id); };

  // ---------- one player ----------
  //MC 2026-10-09 non-breaking space between each number and its noun so the podium never shows "140 / matches" on two lines (en; the translated strings get text-wrap:balance in css)
  function sub(r) {
    if (S.board === "shadows") return fmt(r.wins) + (r.wins === 1 ? "\u00a0win" : "\u00a0wins") + " &middot; " + fmt(r.games) + (r.games === 1 ? "\u00a0game" : "\u00a0games");
    if (S.board === "live") return fmt(r.pvp_w || 0) + (r.pvp_w === 1 ? "\u00a0live win" : "\u00a0live wins") + " &middot; " + fmt(r.pvp_g) + (r.pvp_g === 1 ? "\u00a0match" : "\u00a0matches");
    if (S.board === "daily") return fmt(r.regions) + " Regions, " + (r.result === "win" ? "won" : r.result === "tie" ? "tied" : "lost");
    if (S.board === "ranked") return '<em class="rank-b r-' + esc(r.rank) + '">' + esc(r.rankName) + '</em> ' + fmt(r.rk_w) + (r.rk_w === 1 ? "\u00a0win" : "\u00a0wins") + " &middot; " + fmt(r.rk_n) + (r.rk_n === 1 ? "\u00a0match" : "\u00a0matches");
    return fmt(r.wins) + (r.wins === 1 ? "\u00a0win" : "\u00a0wins") + " &middot; " + fmt(r.games) + (r.games === 1 ? "\u00a0game" : "\u00a0games");
  }
  function name(r) { return S.board === "shadows" ? "Shadow #" + r.n : r.name; }
  // a holder's Shadow, else the player's Shadow skin, else the Unbound hood
  // a verified Shadow glows in its Aura colour, with its Halo if the holder wears one
  function look(r) { return r.img && /^[a-z]+$/.test(r.aura || "") ? " av-aura au-" + r.aura + (r.cos && /^[a-z]+$/.test(r.cos.halo || "") ? " hl-" + r.cos.halo : "") : ""; }
  function img(r) { var k = r.cos && r.cos.skin; return r.img || (/^[a-z]+$/.test(k || "") ? "assets/art/skins/skin_" + k + ".svg" + AV : UNBOUND); }
  //MC 2026-10-10 $SHY Army Ranks with their emblems, in place of the Bronze to Kami tier pills
  //MC 2026-10-11 "Kusama King / Queen" with spaces, as the server, the Token page and the profile spell it
  var TIERS = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King / Queen", supreme: "Shytoshi Supreme" };
  //MC 2026-10-11 rows (not the podium) split their chips in two: the Founder title and the rank emblem stay in the row on
  //   phones, the rest (X, other titles, Holder, badges) sit in .sb-x2s, which is display:contents on wider screens (so
  //   nothing changes there) and hidden on phones, where the open record shows them all instead (.sb-dtags)
  function tags(r, split) {
    if (S.board === "shadows") return S.owned().indexOf(String(r.n)) >= 0 ? '<em class="lb-holder">Yours</em>' : "";
    var founder = r.cos && r.cos.title === "Founder";
    var x = r.x ? (window.ShyX ? ShyX.badge(r.x) : '<a class="sb-x" href="https://x.com/' + esc(r.x) + '" target="_blank" rel="noopener" title="@' + esc(r.x) + ' on X">\u{1D54F}</a>') : "";
    var title = (r.cos && r.cos.imp > 0 && r.cos.imp < 5 ? '<i class="imp-cr c' + (r.cos.imp | 0) + '" title="Imperial crest"></i>' : "") + (r.cos && r.cos.title ? '<em class="lb-title' + (r.cos.tim ? " imp" : "") + '">' + esc(r.cos.title) + '</em>' : "");   //MC 2026-10-24 the Imperial crest and title
    var holder = r.holder ? '<em class="lb-holder" title="Verified Shadow holder">Holder' + (r.avatar ? " #" + esc(r.avatar) : "") + '</em>' : "";
    var tier = r.cos && TIERS[r.cos.tier] ? '<em class="tier-b rk t-' + r.cos.tier + '" title="$SHY Army Rank" data-i18n-skip><img src="/assets/ranks/' + r.cos.tier + '-64.webp" alt="" width="17" height="17"><span class="tb-n">' + TIERS[r.cos.tier] + '</span></em>' : "";
    var badges = r.badges ? '<em class="lb-bdg" title="Badges">\u{1F3C5} ' + r.badges + '</em>' : "";
    if (!split) return x + title + holder + tier + badges;
    var more = x + (founder ? "" : title) + holder + badges;
    return (founder ? title : "") + tier + (more ? '<span class="sb-x2s">' + more + '</span>' : "");
  }
  //MC 2026-10-11 how far a row moved since the board's first look today (api/lbmoves.php), as a small arrow by the rank
  function moved(r) {
    var m = r.mv;
    if (m === "new") return '<i class="sb-mv new" title="New on the board today">' + "•" + '</i>';
    if (typeof m !== "number" || !m) return "";
    return '<i class="sb-mv ' + (m > 0 ? "up" : "down") + '" title="' + (m > 0 ? "Up " + m + " since yesterday" : "Down " + (-m) + " since yesterday") + '">' + (m > 0 ? "▲" : "▼") + Math.min(99, Math.abs(m)) + '</i>';
  }
  function isMe(r) { return S.board === "shadows" ? S.owned().indexOf(String(r.n)) >= 0 : r.pid === myTag(); }
  function detail(r) {
    var bits = [];
    if (S.board === "shadows") bits = [["Wins", fmt(r.wins)], ["Games", fmt(r.games)], ["Win rate", r.games ? Math.round(r.wins / r.games * 100) + "%" : "-"], ["Best game", fmt(r.best) + " Regions"]];
    else if (S.board === "daily") bits = [["Regions", fmt(r.regions)], ["Result", r.result === "win" ? "Won" : r.result === "tie" ? "Tied" : "Lost"], ["All-time wins", fmt(r.wins)], ["Best game", fmt(r.best) + " Regions"]];
    else bits = [["Wins", fmt(r.wins)], ["Games", fmt(r.games)], ["Win rate", r.games ? Math.round(r.wins / r.games * 100) + "%" : "-"], ["Best game", fmt(r.best) + " Regions"]].concat(r.pvp_g ? [["Live record", fmt(r.pvp_w || 0) + " of " + fmt(r.pvp_g)]] : []);
    var all = S.board === "shadows" ? "" : tags(r);
    return '<div class="sb-detail">' + (all ? '<div class="sb-dtags lb-line">' + all + '</div>' : "") + bits.map(function (b) { return '<span><small>' + b[0] + '</small><b>' + b[1] + '</b></span>'; }).join("") +
      (S.board === "daily" && r.rp ? '<a class="sb-dlink sb-pp" href="/play?replay=' + esc(r.rp) + '" data-replay="' + esc(r.rp) + '">▶ Watch the replay</a>' : "") +
      (S.board === "shadows" ? '<a class="sb-dlink" href="nfts.html">See the Shadows</a>' : (r.on && !isMe(r) && r.pid ? '<button type="button" class="sb-dlink sb-inv" data-fr-invite="' + esc(r.pid) + '"><i class="fr-on"></i>Online now: invite to a match</button>' : "") + (r.name ? '<a class="sb-dlink sb-pp" href="/p/' + encodeURIComponent(String(r.name).replace(/ /g, "_")) + '">Full profile →</a>' : "") + (r.x ? '<a class="sb-dlink" href="https://x.com/' + esc(r.x) + '" target="_blank" rel="noopener"><span data-i18n-skip>@' + esc(r.x) + '</span> on X</a>' : "")) + '</div>';
  }
  //MC 2026-10-09 the green dot: this player has the site open right now
  //MC 2026-10-10 the Profile Studio portrait frame, still on the board and playing when the row is hovered
  function pfr(r, html) { return r.cos && /^[a-z]+$/.test(r.cos.pfr || "") && window.ShyLook && ShyLook.frame ? ShyLook.frame(r.cos.pfr, html) : html; }
  function onDot(r) { return r.on ? '<i class="on-dot" title="Online now" aria-label="Online now"></i>' : ""; }
  function row(r, rank, key) {
    var ring = r.cos && r.cos.ring ? " ring-" + esc(r.cos.ring) : "";
    return '<li class="sb-row' + (isMe(r) ? " me" : "") + (r.holder || S.board === "shadows" ? " holder" : "") + (S.open === key ? " open" : "") + '" data-k="' + key + '">' +
      '<button type="button" class="sb-r" aria-expanded="' + (S.open === key) + '"><span class="sb-rank">' + rank + moved(r) + '</span>' +
      pfr(r, '<span class="sb-av' + look(r) + '"><img src="' + esc(img(r)) + '" alt="" loading="lazy" decoding="async" onerror="this.src=\'' + UNBOUND + '\'">' + onDot(r) + '</span>') +
      '<span class="sb-name"><b class="lb-line">' + (r.house ? '<em class="lb-house" data-i18n-skip>' + esc(r.house) + '</em>' : "") + '<span class="lb-nm' + ring + '" data-i18n-skip>' + esc(name(r)) + '</span>' + tags(r, true) + '</b><small>' + sub(r) + '</small></span>' +
      '<span class="sb-pts">' + fmt(r.points) + '<small>' + (S.board === "ranked" ? "RP" : "pts") + '</small></span></button>' + (S.open === key ? detail(r) : "") + '</li>';
  }
  // the top 3: same badges as the list, set on gold, silver and bronze. Each spot opens its record; on desktop it tilts
  // toward the pointer with a sheen of light (never with reduced motion).
  var PLACE = ["1st", "2nd", "3rd"], METAL = ["Gold", "Silver", "Bronze"], podUid = 0;
  //MC 2026-10-09 the podium rate has to match the record printed next to it. It always used all-time wins/games, so Ranked showed "2 wins · 2 matches 83% won"
  function rate(r) {
    var w = r.wins, g = r.games;
    if (S.board === "ranked") { w = r.rk_w; g = r.rk_n; }
    else if (S.board === "live") { w = r.pvp_w; g = r.pvp_g; }
    return S.board === "daily" || !g ? "" : Math.round((w || 0) / g * 100) + "% won";
  }
  function podium(top) {
    var order = [0, 1, 2];
    return order.map(function (i) {
      var r = top[i];
      if (!r) return '<div class="sb-pd p' + (i + 1) + ' empty"><span class="sb-medal" aria-hidden="true">' + (i + 1) + '</span><span class="sb-pav"><i>?</i></span><span class="sb-pinfo"><b>Open spot</b><small class="sb-psub">Play to take it</small></span></div>';
      var ring = r.cos && r.cos.ring ? " ring-" + esc(r.cos.ring) : "", t = tags(r), wr = rate(r);
      //MC 2026-10-11 named by its own place and name text (aria-labelledby) instead of aria-label="1st place: <name>",
      // which held a player name and so could never be translated. The place text is translated with the page.
      var uid = "sbpd" + (++podUid) + "-";
      return '<div role="button" tabindex="0" class="sb-pd p' + (i + 1) + (isMe(r) ? " me" : "") + (S.open === "p" + i ? " open" : "") + '" data-k="p' + i + '" aria-expanded="' + (S.open === "p" + i) + '" aria-labelledby="' + uid + 'a ' + uid + 'b">' +
        '<span class="sb-glare" aria-hidden="true"></span>' +
        '<span class="sb-medal" title="' + METAL[i] + '" aria-hidden="true"><i>' + (i + 1) + '</i></span>' +
        '<span class="sb-pring">' + (i === 0 ? '<span class="sb-crown" aria-hidden="true"></span>' : "") + pfr(r, '<span class="sb-pav' + look(r) + '"><img src="' + esc(img(r)) + '" alt="" loading="lazy" decoding="async" onerror="this.src=\'' + UNBOUND + '\'"></span>') + onDot(r) + '</span>' +
        '<span class="sb-pinfo"><span class="sb-pplace" id="' + uid + 'a">' + PLACE[i] + (isMe(r) ? ' &middot; <em>You</em>' : "") + '</span>' + moved(r) +
        '<b class="sb-pname">' + (r.house ? '<em class="lb-house" data-i18n-skip>' + esc(r.house) + '</em>' : "") + '<span class="lb-nm' + ring + '" data-i18n-skip id="' + uid + 'b">' + esc(name(r)) + '</span></b>' +
        (t ? '<span class="sb-ptags">' + t + '</span>' : "") +
        '<span class="sb-ppts">' + fmt(r.points) + ' <small>' + (S.board === "ranked" ? "RP" : "pts") + '</small></span>' +
        '<span class="sb-pmeta"><small class="sb-psub">' + sub(r) + '</small>' + (wr ? '<small class="sb-wr">' + wr + '</small>' : "") + '</span></span></div>';
    }).join("");
  }
  // pointer tilt for the podium (mouse and pen only, and not with reduced motion)
  var tiltOK = !reduce && window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (tiltOK) {
    var raf = 0;
    root.addEventListener("pointermove", function (e) {
      var c = e.target.closest && e.target.closest(".sb-pd:not(.empty)"); if (!c) return;
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(function () {
        var b = c.getBoundingClientRect(), x = (e.clientX - b.left) / b.width, y = (e.clientY - b.top) / b.height;
        c.style.setProperty("--rx", ((0.5 - y) * 8).toFixed(2) + "deg"); c.style.setProperty("--ry", ((x - 0.5) * 10).toFixed(2) + "deg");
        c.style.setProperty("--gx", (x * 100).toFixed(1) + "%"); c.style.setProperty("--gy", (y * 100).toFixed(1) + "%");
        c.classList.add("tilt");
      });
    });
    root.addEventListener("pointerout", function (e) {
      var c = e.target.closest && e.target.closest(".sb-pd"); if (!c || c.contains(e.relatedTarget)) return;
      c.classList.remove("tilt"); c.style.removeProperty("--rx"); c.style.removeProperty("--ry");
    });
  }
  root.addEventListener("keydown", function (e) {
    var c = e.target.closest && e.target.closest(".sb-pd[role=button]");
    if (c && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); c.click(); }
  });

  // ---------- the board ----------
  function draw() {
    var j = S.data || {}, top = j.top || [], off = (S.page - 1) * (j.per || 10);
    var list = $("sb-list"), pod = $("sb-podium");
    S.pages = j.pages || 1;
    if (!top.length) {
      pod.innerHTML = ""; pod.hidden = true;
      list.innerHTML = '<li class="sb-empty">' + (EMPTY[S.board] || "No scores yet. Be the first on the board.") + '</li>';
    } else {
      var first = S.page === 1;
      pod.hidden = !first;
      pod.innerHTML = first ? podium(top) : "";
      var rows = (first ? top.slice(3) : top).map(function (r, k) { var at = (first ? 3 : 0) + k; return row(r, off + at + 1, "r" + at); }).join("");
      // your own spot stays in view when it's on another page
      var mine = j.me, onPage = mine && top.some(function (r) { return isMe(r); });
      if (mine && !onPage) rows += '<li class="sb-gap" aria-hidden="true">&middot; &middot; &middot;</li>' + row(mine, mine.rank, "me");
      list.innerHTML = rows || (first && top.length <= 3 ? "" : '<li class="sb-empty">No more players.</li>');
    }
    var total = j.total || 0;
    //MC 2026-10-09 thousands separator to match the KPI tile above ("1533" vs "1,533"), and Ranked says which ladder it counts
    $("sb-total").textContent = S.board === "shadows" ? fmt(total) + (total === 1 ? " Shadow" : " Shadows") + " with a record" :
      fmt(total) + " " + (total === 1 ? "player" : "players") + (S.board === "daily" ? " today" : S.board === "week" ? " this week" : S.board === "live" ? " in live matches" : S.board === "holders" ? " holding Shadows" : S.board === "ranked" ? " this season" : "");
    $("sb-sub").textContent = SUB[S.board];
    var meBtn = root.querySelector("[data-sb-me]");
    meBtn.hidden = !(j.me && j.me.rank && Math.ceil(j.me.rank / (j.per || 10)) !== S.page);
    pager();
    watchMe();
  }
  //MC 2026-10-11 phones: while the board is on screen but your own row (or podium spot) on it is scrolled away, a bar
  //   above the tab bar shows your place and points, with the arrow for today's move; a tap scrolls your row into view
  //   and makes it glow. Wider screens don't get it (the whole page of ten fits there).
  var phone = window.matchMedia ? matchMedia("(max-width:760px)") : null;
  var bar = null, seeBoard = false, seeMe = true, meEl = null, pio = null, barKey = "";
  function mine() { return root.querySelector(".sb-row.me, .sb-pd.me"); }
  function barShow() {
    var m = S.data && S.data.me, show = !!(phone && phone.matches && m && m.rank && seeBoard && !seeMe && meEl);
    if (!show) { if (bar && !bar.hidden) { bar.classList.remove("in"); bar.hidden = true; } return; }
    if (!bar) {
      bar = document.createElement("button"); bar.type = "button"; bar.className = "sb-mebar"; bar.hidden = true;
      bar.addEventListener("click", function () {
        var el = mine(); if (!el) return;
        el.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
        el.classList.remove("sb-flash"); void el.offsetWidth; el.classList.add("sb-flash");
      });
      document.body.appendChild(bar);
    }
    var key = S.board + "|" + m.rank + "|" + m.points + "|" + (m.mv || "");
    if (key !== barKey) {
      barKey = key;
      bar.innerHTML = '<span class="sb-mb-k">You</span><b class="sb-mb-r">#' + fmt(m.rank) + '</b>' + moved(m) + '<span class="sb-mb-n" data-i18n-skip>' + esc(name(m)) + '</span>' +
        '<span class="sb-mb-p">' + fmt(m.points) + ' <small>' + (S.board === "ranked" ? "RP" : "pts") + '</small></span><span class="sb-mb-go" aria-hidden="true">&darr;</span>';
      bar.setAttribute("aria-label", "Show your row on the board");
    }
    var tb = document.querySelector(".tabbar"), h = tb && getComputedStyle(tb).display !== "none" ? tb.getBoundingClientRect().height : 0;
    bar.style.bottom = Math.round(h + 10) + "px";
    if (bar.hidden) { bar.hidden = false; requestAnimationFrame(function () { bar.classList.add("in"); }); }
  }
  function watchMe() {
    if (!pio) return;
    if (meEl) pio.unobserve(meEl);
    meEl = mine(); seeMe = true;
    if (meEl) pio.observe(meEl);
    barShow();
  }
  if ("IntersectionObserver" in window) {
    new IntersectionObserver(function (es) { seeBoard = es[es.length - 1].isIntersecting; barShow(); }, { rootMargin: "0px 0px -38% 0px" }).observe(root);   //MC 2026-10-18 the bar showed the moment the board section touched the bottom edge, before a single row was visible
    // the bottom 90px of the screen is under the tab bar and this bar, so a row there doesn't count as seen
    pio = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.target === meEl) seeMe = e.isIntersecting; }); barShow(); }, { rootMargin: "0px 0px -90px 0px", threshold: 0.6 });
    if (phone && phone.addEventListener) phone.addEventListener("change", barShow);
  }
  function pager() {
    var el = $("sb-pager"), n = S.pages, p = S.page;
    el.hidden = n <= 1;
    if (n <= 1) { el.innerHTML = ""; return; }
    var nums = [], add = function (x) { if (nums.indexOf(x) < 0 && x >= 1 && x <= n) nums.push(x); };
    add(1); add(p - 1); add(p); add(p + 1); add(n);
    nums.sort(function (a, b) { return a - b; });
    var h = '<button type="button" class="sb-pg nav" data-pg="' + (p - 1) + '"' + (p <= 1 ? " disabled" : "") + ' aria-label="Previous page">&lsaquo;</button>';
    nums.forEach(function (x, i) {
      if (i && x - nums[i - 1] > 1) h += '<span class="sb-dots">&hellip;</span>';
      h += '<button type="button" class="sb-pg' + (x === p ? " on" : "") + '" data-pg="' + x + '"' + (x === p ? ' aria-current="page"' : "") + '>' + x + '</button>';
    });
    h += '<button type="button" class="sb-pg nav" data-pg="' + (p + 1) + '"' + (p >= n ? " disabled" : "") + ' aria-label="Next page">&rsaquo;</button>';
    el.innerHTML = h;
  }
  function tabs() { root.querySelectorAll("[data-sb-tab]").forEach(function (b) { var on = b.dataset.sbTab === S.board; b.classList.toggle("on", on); b.setAttribute("aria-selected", on); }); }
  var seq = 0;
  async function load(which, page) {
    if (which && which !== S.board) { S.board = which; S.page = 1; }
    if (page) S.page = page;
    S.open = -1;
    var pd = $("sb-pdetail"); if (pd) pd.remove();
    tabs();
    var my = ++seq, stage = $("sb-stage");
    // keep the stage's height while the next page loads, so nothing below it moves
    stage.style.minHeight = stage.offsetHeight + "px";
    stage.classList.add("loading");
    try {
      var url = S.board === "shadows" ? "api/holder.php?a=shadows&pg=" + S.page : API + "?a=top&b=" + S.board + "&pg=" + S.page + "&me=" + myTag();
      var j = await (await fetch(url, { cache: "no-store" })).json();
      if (my !== seq) return;
      if (!j.ok) throw new Error();
      S.data = j; S.page = j.page || 1;
      if (S.board === "shadows" && j.top) j.top.forEach(function (r) { r.name = "Shadow #" + r.n; });
      draw();
    } catch (e) {
      if (my !== seq) return;
      $("sb-list").innerHTML = '<li class="sb-empty">The leaderboard is offline right now.</li>'; $("sb-podium").hidden = true;
    }
    stage.classList.remove("loading");
    requestAnimationFrame(function () { stage.style.minHeight = ""; });
  }

  // ---------- taps ----------
  root.addEventListener("click", function (e) {
    var t = e.target.closest("[data-sb-tab]");
    if (t) { load(t.dataset.sbTab); return; }
    var pg = e.target.closest("[data-pg]");
    if (pg && !pg.disabled) {
      load(null, +pg.dataset.pg);
      // only when the top of the board has scrolled away, bring it back, gently
      var r = root.getBoundingClientRect();
      if (r.top < 0) window.scrollBy({ top: r.top - 90, behavior: reduce ? "auto" : "smooth" });
      return;
    }
    if (e.target.closest("[data-sb-refresh]")) { load(); return; }
    if (e.target.closest("[data-sb-me]")) { var m = S.data && S.data.me; if (m) load(null, Math.ceil(m.rank / (S.data.per || 10))); return; }
    if (e.target.closest(".sb-dlink, .sb-x, a")) return;
    var k = e.target.closest("[data-k]");
    if (k) toggle(k.dataset.k);
  });
  // opening or closing a record touches only that record: the rest of the board stays exactly as it is (no redraw, no
  // replayed animations, no pictures loading again)
  function rec(key) {
    var j = S.data || {};
    if (key === "me") return j.me;
    var i = +key.slice(1);
    return (j.top || [])[i];
  }
  function shut(key) {
    var el = root.querySelector('[data-k="' + key + '"]'); if (!el) return;
    el.classList.remove("open");
    if (key.charAt(0) === "p") { el.setAttribute("aria-expanded", "false"); var b = $("sb-pdetail"); if (b) b.remove(); }
    else { var bt = el.querySelector(".sb-r"); if (bt) bt.setAttribute("aria-expanded", "false"); var d = el.querySelector(".sb-detail"); if (d) d.remove(); }
  }
  function toggle(key) {
    var was = S.open;
    if (was !== -1) shut(was);
    if (was === key) { S.open = -1; return; }
    var el = root.querySelector('[data-k="' + key + '"]'), r = rec(key);
    if (!el || !r) { S.open = -1; return; }
    S.open = key;
    el.classList.add("open");
    if (key.charAt(0) === "p") {
      el.setAttribute("aria-expanded", "true");
      var box = document.createElement("div"); box.id = "sb-pdetail"; box.className = "sb-pdetail";
      box.innerHTML = '<b data-i18n-skip>' + esc(name(r)) + '</b>' + detail(r);
      $("sb-podium").after(box);
    } else {
      var bt = el.querySelector(".sb-r"); if (bt) bt.setAttribute("aria-expanded", "true");
      el.insertAdjacentHTML("beforeend", detail(r));
    }
  }

  window.ShyBoard = {
    load: function (which) { return load(which || null, which ? 1 : null); },
    board: function () { return S.board; },
    setOwned: function (fn) { S.owned = fn; }
  };
  tabs();
  // load when it gets near the screen, so the page above it isn't held up
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { io.disconnect(); if (!S.data) load(); } }, { rootMargin: "600px" });
    io.observe(root);
  } else load();
})();
