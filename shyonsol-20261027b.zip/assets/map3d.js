// The 3D war table: the same 40 Regions as the flat map, raised as plates on a command table you can orbit and zoom.
// Built from assets/map.json (the flat map's own outlines), so both maps always agree on what a Region is and where.
// play.js owns the game: it tells this module who holds what (paint), whose turn it is (setTurn), who is highlighted
// (setHl) and whether a target is being picked (setPicking), and it gets taps and hovers back. Nothing here touches
// the rules, the server or the flat map; if WebGL is missing or anything fails, play.js keeps the flat map.
//MC 2026-10-14 three.js (assets/vendor/three-map.js, r170 with SVGLoader and OrbitControls) is fetched only when a
//   player has the 3D table on, so the flat map never pays for it. Touch: one finger orbits, two zoom. A tap that
//   does not move picks or shows the Region, same as tapping the flat map.
//MC 2026-10-14 second pass, the premium table: real shadows, bevelled plates with a paper grain, a felt with radar
//   rings and a brass lip in a walnut frame, command pieces instead of flat hexes (a dark base and a floating gem in
//   the holder's colour over a soft glow), pulsing target rings when a card wants a Region, dust in the air, a
//   hover lift on desktop, and a My regions view that flies to what you hold. The page behind the canvas is a CSS
//   gradient, so the renderer clears to transparent and the table sits in the room instead of on a flat colour.
(function () {
  "use strict";
  var S = 0.012, W = 1000, H = 475;              // map units to table units; the flat map's own size
  var LAND_H = 0.14, BEV = 0.022;                // how far a plate rises off the table, and its rounded lip
  var OPEN = "#8d9c52", OPEN_SIDE = "#4a5630", GONE = "#2b2030", GONE_SIDE = "#1a1420";
  var vendor = null;                             // the script tag, once asked for

  function supported() {
    try {
      var c = document.createElement("canvas");
      var gl = c.getContext("webgl2") || c.getContext("webgl");
      if (!gl) return false;
      var ext = gl.getExtension("WEBGL_lose_context"); if (ext) ext.loseContext();
      return true;
    } catch (e) { return false; }
  }
  // fetch three.js once; resolves when window.THREE is there
  function load(src) {
    if (window.THREE && window.ShyThreeAddons) return Promise.resolve();
    if (!vendor) {
      vendor = new Promise(function (res, rej) {
        var s = document.createElement("script"); s.src = src; s.async = true;
        s.onload = function () { window.THREE && window.ShyThreeAddons ? res() : rej(new Error("three missing")); };
        s.onerror = function () { rej(new Error("three failed to load")); };
        document.head.appendChild(s);
      });
    }
    return vendor;
  }
  function hex(c) { return new window.THREE.Color(c); }
  function mix(a, b, t) { return hex(a).lerp(hex(b), t); }
  // a seeded noise so every load of the table looks the same
  function rng(seed) { var s = seed >>> 0; return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  function tex(T, c, srgb) { var t = new T.CanvasTexture(c); if (srgb) t.colorSpace = T.SRGBColorSpace; t.anisotropy = 8; return t; }

  // the felt: dark green cloth with a fine grain, a drafting grid, radar rings and a soft vignette
  function feltTexture(T, F) {
    var w = 1024, h = 512, c = document.createElement("canvas"); c.width = w; c.height = h;
    var x = c.getContext("2d"), r = rng(7);
    x.fillStyle = F.cloth; x.fillRect(0, 0, w, h);
    var img = x.getImageData(0, 0, w, h), d = img.data;
    for (var i = 0; i < d.length; i += 4) { var n = (r() - .5) * 14; d[i] += n; d[i + 1] += n * 1.3; d[i + 2] += n; }
    x.putImageData(img, 0, 0);
    x.lineWidth = 1;
    x.strokeStyle = "rgba(" + F.line + ",.08)";
    for (i = 0; i <= w; i += 32) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, h); x.stroke(); }
    for (var j = 0; j <= h; j += 32) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(w, j + .5); x.stroke(); }
    x.strokeStyle = "rgba(" + F.line + ",.17)";
    for (i = 0; i <= w; i += 128) { x.beginPath(); x.moveTo(i + .5, 0); x.lineTo(i + .5, h); x.stroke(); }
    for (j = 0; j <= h; j += 128) { x.beginPath(); x.moveTo(0, j + .5); x.lineTo(w, j + .5); x.stroke(); }
    x.strokeStyle = "rgba(" + F.line + ",.07)";
    for (i = 1; i <= 5; i++) { x.beginPath(); x.ellipse(w / 2, h / 2, i * 115, i * 115, 0, 0, Math.PI * 2); x.stroke(); }
    x.beginPath(); x.moveTo(w / 2 + .5, 0); x.lineTo(w / 2 + .5, h); x.moveTo(0, h / 2 + .5); x.lineTo(w, h / 2 + .5); x.stroke();
    // corner ticks, like a plotting table
    x.strokeStyle = "rgba(220,240,225,.28)"; x.lineWidth = 2;
    [[18, 18, 1, 1], [w - 18, 18, -1, 1], [18, h - 18, 1, -1], [w - 18, h - 18, -1, -1]].forEach(function (k) {
      x.beginPath(); x.moveTo(k[0], k[1] + 26 * k[3]); x.lineTo(k[0], k[1]); x.lineTo(k[0] + 26 * k[2], k[1]); x.stroke();
    });
    //MC 2026-10-24 Celestial Table: a gold sixteen-petal crest woven into the middle of the cloth, rays running out of it
    if (F.kiku) {
      x.save(); x.translate(w / 2, h / 2);
      x.strokeStyle = "rgba(" + F.line + ",.1)"; x.lineWidth = 2;
      for (i = 0; i < 32; i++) { var ra = i * Math.PI / 16; x.beginPath(); x.moveTo(Math.cos(ra) * 120, Math.sin(ra) * 120); x.lineTo(Math.cos(ra) * 700, Math.sin(ra) * 700); x.stroke(); }
      x.fillStyle = "rgba(" + F.line + ",.13)"; x.strokeStyle = "rgba(" + F.line + ",.34)"; x.lineWidth = 2;
      for (i = 0; i < 16; i++) { x.save(); x.rotate(i * Math.PI / 8 + Math.PI / 16); x.beginPath(); x.ellipse(0, -66, 15, 42, 0, 0, Math.PI * 2); x.fill(); x.stroke(); x.restore(); }
      for (i = 0; i < 16; i++) { x.save(); x.rotate(i * Math.PI / 8); x.beginPath(); x.ellipse(0, -44, 10, 28, 0, 0, Math.PI * 2); x.fill(); x.stroke(); x.restore(); }
      x.beginPath(); x.arc(0, 0, 20, 0, Math.PI * 2); x.fillStyle = "rgba(" + F.line + ",.3)"; x.fill(); x.stroke();
      x.beginPath(); x.arc(0, 0, 112, 0, Math.PI * 2); x.stroke(); x.beginPath(); x.arc(0, 0, 118, 0, Math.PI * 2); x.lineWidth = 1; x.stroke();
      x.restore();
    }
    var v = x.createRadialGradient(w / 2, h / 2, 140, w / 2, h / 2, 640);
    v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.62)");
    x.fillStyle = v; x.fillRect(0, 0, w, h);
    return tex(T, c, true);
  }
  // walnut for the frame: long grain with a little variation
  function woodTexture(T) {
    var w = 1024, h = 128, c = document.createElement("canvas"); c.width = w; c.height = h;
    var x = c.getContext("2d"), r = rng(11);
    x.fillStyle = "#4a3523"; x.fillRect(0, 0, w, h);
    for (var i = 0; i < 260; i++) {
      var y = r() * h, a = .05 + r() * .12, k = r();
      x.strokeStyle = k < .5 ? "rgba(20,10,4," + a + ")" : "rgba(170,120,70," + a + ")"; x.lineWidth = .5 + r() * 2.2;
      x.beginPath(); x.moveTo(0, y); x.bezierCurveTo(w * .3, y + (r() - .5) * 10, w * .7, y + (r() - .5) * 10, w, y + (r() - .5) * 6); x.stroke();
    }
    var t = tex(T, c, true); t.wrapS = t.wrapT = T.RepeatWrapping; return t;
  }
  // paper grain for the plates: pale noise the plate colour multiplies, also used as a bump so light catches it
  function grainTexture(T) {
    var n = 256, c = document.createElement("canvas"); c.width = n; c.height = n;
    var x = c.getContext("2d"), r = rng(3), img = x.createImageData(n, n), d = img.data;
    for (var i = 0; i < d.length; i += 4) { var v = 222 + (r() - .5) * 46; d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = 255; }
    x.putImageData(img, 0, 0);
    var t = tex(T, c, true); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(1.6, 1.6); return t;
  }
  // the room: a dark green glow above the table fading to near black, wrapped around the scene as a sky dome
  function skyTexture(T, F) {
    var c = document.createElement("canvas"); c.width = 8; c.height = 256;
    var x = c.getContext("2d"), g = x.createLinearGradient(0, 0, 0, 256);
    g.addColorStop(0, F.skyTop); g.addColorStop(.42, F.skyLow); g.addColorStop(.56, F.sky); g.addColorStop(.68, F.skyLow); g.addColorStop(1, "#050a08");
    x.fillStyle = g; x.fillRect(0, 0, 8, 256);
    return tex(T, c, true);
  }
  // a soft round glow for under the pieces and the dust
  function glowTexture(T) {
    var n = 128, c = document.createElement("canvas"); c.width = n; c.height = n;
    var x = c.getContext("2d"), g = x.createRadialGradient(n / 2, n / 2, 0, n / 2, n / 2, n / 2);
    g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(.35, "rgba(255,255,255,.45)"); g.addColorStop(1, "rgba(255,255,255,0)");
    x.fillStyle = g; x.fillRect(0, 0, n, n);
    return tex(T, c, false);
  }
  //MC 2026-10-14 the Dojo's war table cosmetics. Four slots, each a parameter set this module reads: felt (cloth, frame,
  //   lip and the room's light), land (the plates' finish), piece (the shape of a holder's command pieces) and air (what
  //   drifts over the table). Animated ones add one cheap layer each: a scrolling plane, a flash, a geometry that turns.
  //   Every look here is a single draw call or less on top of the base table, so a phone keeps its frame rate.
  var FELTS = {
    "":        { cloth: "#0f2219", line: "150,220,180", frame: "#8a6a48", brass: "#c9a455", pool: "#1d4a36", sky: "#1a3f31", skyLow: "#0c1c15", skyTop: "#07100c", rough: .96, metal: 0 },
    crimson:   { cloth: "#2a0d14", line: "255,190,160", frame: "#3a2016", brass: "#d9b45a", pool: "#4a1626", sky: "#4a1a28", skyLow: "#1c0a10", skyTop: "#0e0508", rough: .96, metal: 0 },
    midnight:  { cloth: "#0b1430", line: "140,200,255", frame: "#1d1f33", brass: "#b9c2d6", pool: "#17305e", sky: "#1b2f60", skyLow: "#0a1128", skyTop: "#05081a", rough: .95, metal: 0 },
    obsidian:  { cloth: "#0a0a10", line: "180,150,255", frame: "#121018", brass: "#8f84b8", pool: "#2a1f4e", sky: "#231a44", skyLow: "#0d0a1c", skyTop: "#06040e", rough: .22, metal: .35 },
    ocean:     { cloth: "#07263a", line: "120,225,255", frame: "#1d3c48", brass: "#9fd7e8", pool: "#0f4f6e", sky: "#0f4258", skyLow: "#061a26", skyTop: "#030d14", rough: .5, metal: .1, anim: "ocean" },
    storm:     { cloth: "#0b0d16", line: "200,210,255", frame: "#171826", brass: "#aeb4c8", pool: "#1b2248", sky: "#1c2350", skyLow: "#0a0d22", skyTop: "#050714", rough: .9, metal: 0, anim: "storm" },
    //MC 2026-10-24 Imperial: indigo silk, a gold crest woven in, gold light shimmering over it and a sun that breathes
    takama:    { cloth: "#151a4a", line: "255,212,120", frame: "#24140a", brass: "#f2c35b", pool: "#3a2a6e", sky: "#3a2660", skyLow: "#140c34", skyTop: "#06041a", rough: .62, metal: .18, anim: "heaven", kiku: true },
  };
  var LANDS = {
    "":        { top: "#8d9c52", side: "#4a5630", gone: "#2b2030", rough: .78, metal: 0, em: "#000000", emi: 0, coast: "#eef3d8", coastA: .28 },
    jade:      { top: "#52ad86", side: "#235a48", gone: "#1e2a2a", rough: .32, metal: .05, em: "#1f6a4e", emi: .22, coast: "#dafff0", coastA: .4 },
    obsidian:  { top: "#1c1c26", side: "#0b0b12", gone: "#0a0a0e", rough: .2, metal: .55, em: "#2a2a3a", emi: .25, coast: "#ffffff", coastA: .5 },
    gold:      { top: "#d9ad3c", side: "#7a5812", gone: "#3a2c14", rough: .28, metal: .6, em: "#7a5210", emi: .3, coast: "#fff4c6", coastA: .5 },
    holo:      { top: "#0e3448", side: "#071a25", gone: "#0a1218", rough: .4, metal: 0, em: "#19c8ff", emi: .5, coast: "#8df0ff", coastA: .7, anim: "holo" }
  };
  var AIRS = { "": "dust", fireflies: "fireflies", sakura: "sakura", snow: "snow", embers: "embers", lanterns: "lanterns", kiku: "kiku" };   //MC 2026-10-24 kiku: Golden Petals
  // merge small parts into one geometry so a piece stays one draw call; parts are [geometry, x, y, z, rx, ry, rz]
  function merged(T, parts) {
    var pos = [], nor = [], m = new T.Matrix4(), e = new T.Euler();
    parts.forEach(function (p) {
      var g = p[0].toNonIndexed(); e.set(p[4] || 0, p[5] || 0, p[6] || 0); m.makeRotationFromEuler(e); m.setPosition(p[1] || 0, p[2] || 0, p[3] || 0); g.applyMatrix4(m);
      pos.push(g.getAttribute("position").array); nor.push(g.getAttribute("normal").array); g.dispose();
    });
    var n = 0; pos.forEach(function (a) { n += a.length; });
    var P = new Float32Array(n), N = new Float32Array(n), o = 0;
    pos.forEach(function (a, i) { P.set(a, o); N.set(nor[i], o); o += a.length; });
    var out = new T.BufferGeometry(); out.setAttribute("position", new T.BufferAttribute(P, 3)); out.setAttribute("normal", new T.BufferAttribute(N, 3));
    return out;
  }
  // the command pieces: a still part and, for the ones that move, a part that turns and bobs on top
  function pieceGeo(T, kind) {
    var B = T.BoxGeometry, C = T.CylinderGeometry, pi = Math.PI;
    if (kind === "torii") return { still: merged(T, [[new B(.04, .3, .04), -.1, .15, 0], [new B(.04, .3, .04), .1, .15, 0], [new B(.34, .04, .05), 0, .31, 0], [new B(.26, .03, .04), 0, .23, 0], [new B(.05, .05, .03), 0, .27, 0]]), y: 0 };
    if (kind === "pagoda") return { still: merged(T, [[new B(.26, .04, .26), 0, .02, 0], [new C(0, .19, .07, 4), 0, .075, 0, 0, pi / 4], [new B(.18, .05, .18), 0, .13, 0], [new C(0, .15, .06, 4), 0, .185, 0, 0, pi / 4], [new B(.11, .04, .11), 0, .235, 0], [new C(0, .1, .09, 4), 0, .3, 0, 0, pi / 4]]), y: 0 };
    if (kind === "katana") return { still: merged(T, [[new B(.12, .02, .12), 0, .02, 0], [new B(.03, .1, .03), 0, .08, 0], [new B(.022, .34, .06), 0, .3, 0, 0, 0, .2], [new C(0, .03, .07, 4), 0, .485, -.012, 0, pi / 4, .2]]), y: 0 };
    if (kind === "koban") return { still: merged(T, [[new C(.13, .13, .03, 18), 0, .015, 0], [new C(.13, .13, .03, 18), .012, .048, .008], [new C(.13, .13, .03, 18), -.008, .081, -.01]]), spin: new C(.12, .12, .028, 18), y: .17 };
    //MC 2026-10-24 Sacred Mirrors: the Yata mirror on a stand (it turns and catches the light), a ring of sunlight over it
    if (kind === "regalia") return { still: merged(T, [[new C(.15, .17, .03, 16), 0, .015, 0], [new B(.05, .07, .05), 0, .065, 0], [new C(.115, .115, .022, 8), 0, .2, 0, pi / 2, 0, 0], [new C(.09, .09, .028, 24), 0, .2, 0, pi / 2, 0, 0], [new B(.012, .2, .012), -.1, .14, 0, 0, 0, .25], [new B(.012, .2, .012), .1, .14, 0, 0, 0, -.25]]), spin: new T.TorusGeometry(.085, .012, 8, 32), y: .38 };
    if (kind === "dragon") return { still: merged(T, [[new C(.14, .16, .035, 8), 0, .017, 0]]), spin: new T.TorusKnotGeometry(.085, .028, 48, 8, 2, 3), y: .21 };
    return { still: new T.OctahedronGeometry(.115, 0), y: .2 };
  }
  // petal, flake, ember and lantern sprites, drawn once
  function spriteTexture(T, kind) {
    var n = 64, c = document.createElement("canvas"); c.width = n; c.height = n; var x = c.getContext("2d");
    if (kind === "petal") { x.fillStyle = "#ffb7d0"; x.beginPath(); x.moveTo(32, 6); x.bezierCurveTo(52, 10, 58, 36, 32, 58); x.bezierCurveTo(6, 36, 12, 10, 32, 6); x.fill(); x.fillStyle = "rgba(255,255,255,.35)"; x.beginPath(); x.ellipse(26, 22, 7, 11, -.6, 0, 6.3); x.fill(); }
    else if (kind === "kpetal") { var gk = x.createLinearGradient(20, 4, 44, 60); gk.addColorStop(0, "#fff6d0"); gk.addColorStop(.45, "#f2c35b"); gk.addColorStop(1, "#b07a1e"); x.fillStyle = gk; x.beginPath(); x.moveTo(32, 2); x.bezierCurveTo(46, 12, 46, 44, 32, 62); x.bezierCurveTo(18, 44, 18, 12, 32, 2); x.fill(); x.strokeStyle = "rgba(255,250,225,.9)"; x.lineWidth = 2; x.beginPath(); x.moveTo(32, 8); x.lineTo(32, 54); x.stroke(); }   //MC 2026-10-24 Golden Petals
    else if (kind === "lantern") { var g = x.createRadialGradient(32, 34, 2, 32, 34, 30); g.addColorStop(0, "rgba(255,230,170,1)"); g.addColorStop(.45, "rgba(255,150,80,.85)"); g.addColorStop(1, "rgba(255,120,60,0)"); x.fillStyle = g; x.fillRect(0, 0, n, n); x.fillStyle = "rgba(255,240,200,.95)"; x.beginPath(); x.roundRect(22, 16, 20, 32, 8); x.fill(); x.fillStyle = "#6a3a1a"; x.fillRect(20, 13, 24, 4); x.fillRect(20, 47, 24, 4); }
    else { var g2 = x.createRadialGradient(32, 32, 0, 32, 32, 32); g2.addColorStop(0, "rgba(255,255,255,1)"); g2.addColorStop(.4, "rgba(255,255,255,.6)"); g2.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g2; x.fillRect(0, 0, n, n); }
    return tex(T, c, true);
  }
  // a Region's outline, from the flat map's path, as table shapes: x across, y toward the far edge, flipped from screen
  function shapesFor(T, A, d) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg"><path d="' + d + '"/></svg>';
    var paths = new A.SVGLoader().parse(svg).paths;
    var out = [];
    paths.forEach(function (p) {
      A.SVGLoader.createShapes(p).forEach(function (sh) {
        var fix = function (path) { path.curves.forEach(function (cv) { ["v0", "v1", "v2", "v3"].forEach(function (k) { var pt = cv[k]; if (pt && pt.isVector2) pt.set((pt.x - W / 2) * S, (H / 2 - pt.y) * S); }); }); };
        fix(sh); (sh.holes || []).forEach(fix);
        out.push(sh);
      });
    });
    return out;
  }

  function mount(opts) {
    var T = window.THREE, A = window.ShyThreeAddons;
    var el = opts.el, MAP = opts.map, names = opts.regions, COLORS = opts.colors, hooks = opts.hooks || {};
    var reduce = !!opts.reduce, me = typeof opts.me === "number" ? opts.me : 0;
    var canvas = document.createElement("canvas"); canvas.className = "g-map3d-canvas";
    el.appendChild(canvas);
    var coarse = matchMedia("(pointer: coarse)").matches;
    //MC 2026-10-14 an opaque canvas: additive glows over a transparent canvas came out wrong once the browser
    //   composited them, so the room gradient is a sky dome inside the scene instead of CSS behind it
    //MC 2026-10-14 phones: no multisampling at a high pixel density (the density hides the edges), a lower pixel cap,
    //   a smaller plain shadow map, pieces that do not cast shadows, and the loop stops while the table is scrolled off
    //   screen or the tab is hidden. A phone at the end of a long match was dropping frames; this is where it went.
    var dpr = window.devicePixelRatio || 1;
    var renderer = new T.WebGLRenderer({ canvas: canvas, antialias: !(coarse && dpr >= 1.5), alpha: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(dpr, coarse ? 1.3 : 2));
    renderer.setClearColor(0x060d0a, 1);
    renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = coarse ? T.PCFShadowMap : T.PCFSoftShadowMap;
    var scene = new T.Scene();
    var camera = new T.PerspectiveCamera(38, 2, 0.1, 60);
    // phones sit closer and lower: the box is short and the bar needs the top strip, so the table fills the rest
    var VIEWS = coarse ? { overview: { p: [0, 6.4, 5.2], t: [0, 0, 0.1] }, cinematic: { p: [1.0, 2.0, 5.6], t: [0, 0.15, -0.4] } }
                       : { overview: { p: [0, 7.0, 5.6], t: [0, 0, -0.35] }, cinematic: { p: [1.1, 2.2, 6.1], t: [0, 0.15, -0.5] } };
    camera.position.set(0, 12, 7);
    var glow = glowTexture(T);
    var F = FELTS[""], L = LANDS[""], airKind = "dust", pieceOf = {}, pieceCache = {};
    var sky = new T.Mesh(new T.SphereGeometry(45, 24, 16), new T.MeshBasicMaterial({ map: skyTexture(T, F), side: T.BackSide, fog: false, toneMapped: false }));
    sky.position.y = -6; scene.add(sky);

    // ---- light: a warm key from the upper left that throws the shadows, a cool rim from behind, a soft sky
    scene.add(new T.HemisphereLight(0xd6ecd8, 0x0a160f, .9));
    var key = new T.DirectionalLight(0xfff0d2, 1.6); key.position.set(-6, 10, 5); key.castShadow = true;
    key.shadow.mapSize.set(coarse ? 768 : 2048, coarse ? 768 : 2048);
    key.shadow.camera.left = -7.2; key.shadow.camera.right = 7.2; key.shadow.camera.top = 4.6; key.shadow.camera.bottom = -4.6;
    key.shadow.camera.near = 2; key.shadow.camera.far = 30; key.shadow.bias = -0.0006; key.shadow.normalBias = .012; key.shadow.radius = 3;
    scene.add(key);
    var rimL = new T.DirectionalLight(0x8fc4ff, .55); rimL.position.set(5, 4, -7); scene.add(rimL);
    scene.add(new T.AmbientLight(0xffffff, .16));

    // ---- the table: felt, a brass lip, a walnut frame, and a pool of light on the floor beneath it
    var FW = W * S + .7, FH = H * S + .7;
    var felt = new T.Mesh(new T.PlaneGeometry(FW, FH), new T.MeshStandardMaterial({ map: feltTexture(T, F), roughness: F.rough, metalness: F.metal }));
    felt.rotation.x = -Math.PI / 2; felt.receiveShadow = true; scene.add(felt);
    var brass = new T.Mesh(new T.BoxGeometry(FW + .14, .05, FH + .14), new T.MeshStandardMaterial({ color: hex(F.brass), metalness: .85, roughness: .32 }));
    brass.position.y = -.035; scene.add(brass);
    var wood = woodTexture(T), woodMat = new T.MeshStandardMaterial({ map: wood, color: hex(F.frame), roughness: .62, metalness: .05 });
    var wframe = new T.Group(); scene.add(wframe);
    [[0, -(FH / 2 + .3), FW + .9, .5], [0, FH / 2 + .3, FW + .9, .5], [-(FW / 2 + .3), 0, .5, FH + .9], [FW / 2 + .3, 0, .5, FH + .9]].forEach(function (b) {
      var m = new T.Mesh(new T.BoxGeometry(b[2], .24, b[3]), woodMat); m.position.set(b[0], -.1, b[1]); m.receiveShadow = true; m.castShadow = true; wframe.add(m);
    });
    var pool = new T.Mesh(new T.PlaneGeometry(FW * 2.4, FH * 3.2), new T.MeshBasicMaterial({ map: glow, color: hex(F.pool), transparent: true, opacity: .55, depthWrite: false }));
    pool.rotation.x = -Math.PI / 2; pool.position.y = -.26; scene.add(pool);
    // the animated felt layers: a caustic sheet for Living Ocean, rolling cloud shadow and lightning for Raijin Storm
    var sheetTex = (function () { var n = 256, c = document.createElement("canvas"); c.width = n; c.height = n; var x = c.getContext("2d"), r = rng(5); x.fillStyle = "#000"; x.fillRect(0, 0, n, n); x.filter = "blur(1.5px)"; x.strokeStyle = "rgba(255,255,255,.5)"; x.lineWidth = 1.6; for (var i = 0; i < 90; i++) { x.beginPath(); var cx = r() * n, cy = r() * n, rr = 6 + r() * 20; x.ellipse(cx, cy, rr, rr * (.5 + r() * .5), r() * 3, 0, 6.3); x.stroke(); } var t = tex(T, c, false); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(5, 2.5); return t; })();
    var sheet = new T.Mesh(new T.PlaneGeometry(FW, FH), new T.MeshBasicMaterial({ map: sheetTex, color: hex("#7fe0ff"), transparent: true, opacity: .1, blending: T.AdditiveBlending, depthWrite: false }));
    sheet.rotation.x = -Math.PI / 2; sheet.position.y = .006; sheet.visible = false; scene.add(sheet);
    var cloudTex = (function () { var n = 256, c = document.createElement("canvas"); c.width = n; c.height = n; var x = c.getContext("2d"), r = rng(9); x.fillStyle = "#fff"; x.fillRect(0, 0, n, n); for (var i = 0; i < 40; i++) { var g = x.createRadialGradient(r() * n, r() * n, 0, r() * n, r() * n, 30 + r() * 70); g.addColorStop(0, "rgba(0,0,0,.5)"); g.addColorStop(1, "rgba(0,0,0,0)"); x.fillStyle = g; x.fillRect(0, 0, n, n); } var t = tex(T, c, false); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(2, 1); return t; })();
    var cloud = new T.Mesh(new T.PlaneGeometry(FW + 1.2, FH + 1.2), new T.MeshBasicMaterial({ map: cloudTex, transparent: true, opacity: .45, blending: T.MultiplyBlending, depthWrite: false }));
    cloud.rotation.x = -Math.PI / 2; cloud.position.y = LAND_H + BEV * 2 + .09; cloud.visible = false; scene.add(cloud);
    var bolt = 0, nextBolt = 0;

    // ---- the Regions as bevelled plates with a coastline, a piece each, and the lookups to paint them
    var grain = grainTexture(T);
    var sideOpen = new T.MeshStandardMaterial({ color: hex(L.side), roughness: .9 });
    var sideGone = new T.MeshStandardMaterial({ color: hex(GONE_SIDE), roughness: .9 });
    var coastMat = new T.LineBasicMaterial({ color: hex(L.coast), transparent: true, opacity: L.coastA });
    var scanTex = (function () { var c = document.createElement("canvas"); c.width = 4; c.height = 64; var x = c.getContext("2d"); x.fillStyle = "#000"; x.fillRect(0, 0, 4, 64); x.fillStyle = "#fff"; x.fillRect(0, 0, 4, 2); x.fillStyle = "rgba(255,255,255,.3)"; x.fillRect(0, 16, 4, 1); x.fillRect(0, 32, 4, 1); x.fillRect(0, 48, 4, 1); var t = tex(T, c, false); t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(1, 9); return t; })();
    var coastHot = new T.LineBasicMaterial({ color: hex("#ffffff"), transparent: true, opacity: .75 });
    var R = {}, pick = [], land = new T.Group(); land.rotation.x = -Math.PI / 2; land.position.y = BEV; scene.add(land);
    var markers = new T.Group(); scene.add(markers);
    var baseGeo = new T.CylinderGeometry(.15, .175, .04, 6), gemGeo = new T.OctahedronGeometry(.115, 0);
    var pinGeo = new T.CylinderGeometry(.024, .032, .045, 10), pinTop = new T.SphereGeometry(.03, 12, 10);
    var domeGeo = new T.IcosahedronGeometry(.38, 1), shellGeo = new T.SphereGeometry(.37, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2);
    var ringGeo = new T.RingGeometry(.3, .35, 48), glowGeo = new T.PlaneGeometry(1.15, 1.15);
    var pinMat = new T.MeshStandardMaterial({ color: hex("#d9d3b8"), roughness: .65, emissive: hex("#d9d3b8"), emissiveIntensity: .06 });
    var TOP = LAND_H + BEV * 2;
    names.forEach(function (n) {
      var r = MAP.regions[n]; if (!r) return;
      var shapes;
      try { shapes = shapesFor(T, A, r.d); } catch (e) { return; }   //MC 2026-10-14 one odd outline never takes the table down
      if (!shapes.length) return;
      var geo = new T.ExtrudeGeometry(shapes, { depth: LAND_H, bevelEnabled: true, bevelThickness: BEV, bevelSize: BEV * .8, bevelSegments: 2, curveSegments: 4 });
      var top = new T.MeshStandardMaterial({ color: hex(OPEN), map: grain, bumpMap: grain, bumpScale: .006, roughness: .78, metalness: 0, emissive: hex(COLORS[0]), emissiveIntensity: 0 });
      var mesh = new T.Mesh(geo, [top, sideOpen]);
      mesh.castShadow = true; mesh.receiveShadow = true;
      mesh.userData.region = n; land.add(mesh); pick.push(mesh);
      // the coastline: the outline drawn just above the plate so it reads like an inked map
      var coast = new T.Group(); coast.position.z = LAND_H + BEV + .004; land.add(coast);
      shapes.forEach(function (sh) {
        [sh].concat(sh.holes || []).forEach(function (path) {
          var pts = path.getPoints(4), arr = new Float32Array(pts.length * 3);
          pts.forEach(function (p, i) { arr[i * 3] = p.x; arr[i * 3 + 1] = p.y; arr[i * 3 + 2] = 0; });
          var g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(arr, 3));
          coast.add(new T.LineLoop(g, coastMat));
        });
      });
      // the piece sits on the plate at the Region's centre
      var mk = new T.Group(); mk.position.set((r.c[0] - W / 2) * S, TOP, (r.c[1] - H / 2) * S); markers.add(mk);
      var pin = new T.Group(); mk.add(pin);
      var pinA = new T.Mesh(pinGeo, pinMat); pinA.position.y = .025; pinA.castShadow = !coarse; pinA.userData.region = n; pin.add(pinA); pick.push(pinA);
      var pinB = new T.Mesh(pinTop, pinMat); pinB.position.y = .07; pinB.userData.region = n; pin.add(pinB); pick.push(pinB);
      var own = new T.Group(); own.visible = false; mk.add(own);
      var halo = new T.Mesh(glowGeo, new T.MeshBasicMaterial({ map: glow, color: hex(COLORS[0]), transparent: true, opacity: .8, blending: T.AdditiveBlending, depthWrite: false }));
      halo.rotation.x = -Math.PI / 2; halo.position.y = .012; own.add(halo);
      var base = new T.Mesh(baseGeo, new T.MeshStandardMaterial({ color: hex(COLORS[0]), metalness: .15, roughness: .5, emissive: hex(COLORS[0]), emissiveIntensity: .2, flatShading: true })); base.position.y = .02; base.castShadow = !coarse; base.userData.region = n; own.add(base); pick.push(base);
      var gem = new T.Mesh(gemGeo, new T.MeshStandardMaterial({ color: hex(COLORS[0]), metalness: .1, roughness: .35, emissive: hex(COLORS[0]), emissiveIntensity: .6, flatShading: true }));
      gem.position.y = .2; gem.castShadow = !coarse; gem.userData.region = n; own.add(gem); pick.push(gem);
      var spin = new T.Mesh(gemGeo, gem.material); spin.visible = false; spin.castShadow = !coarse; spin.userData.region = n; own.add(spin); pick.push(spin);
      var dome = new T.Mesh(domeGeo, new T.MeshBasicMaterial({ color: hex("#bfe9ff"), wireframe: true, transparent: true, opacity: .35, depthWrite: false }));
      dome.position.y = .08; dome.visible = false; mk.add(dome);
      var shell = new T.Mesh(shellGeo, new T.MeshBasicMaterial({ color: hex("#bfe9ff"), transparent: true, opacity: .1, depthWrite: false, side: T.DoubleSide }));
      shell.position.y = .08; shell.visible = false; mk.add(shell);
      var ring = new T.Mesh(ringGeo, new T.MeshBasicMaterial({ color: hex("#ff5d73"), transparent: true, opacity: .9, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide }));
      ring.rotation.x = -Math.PI / 2; ring.position.y = .02; ring.visible = false; mk.add(ring);
      R[n] = { mesh: mesh, top: top, coast: coast, pin: pin, own: own, halo: halo, gem: gem, spin: spin, pieceKind: "", base: base, dome: dome, shell: shell, ring: ring, mk: mk,
               state: "open", color: "", flags: {}, flash: 0, drop: 0, sink: 0, boom: 0, boomColor: "", lift: 0, phase: Math.random() * 6.28, cx: mk.position.x, cz: mk.position.z };
    });

    // ---- the air over the table: dust by default, or what the Dojo sold (petals, snow, embers, fireflies, lanterns).
    //   One Points object, one draw call, a few hundred numbers nudged per frame.
    var air = null, airPos = null, airSeed = null, airCol = null, airN = 0, airGlow = null;
    function airBuild(kind) {
      if (air) { scene.remove(air); air.geometry.dispose(); air.material.dispose(); air = null; }
      if (airGlow) { scene.remove(airGlow); airGlow.geometry.dispose(); airGlow.material.dispose(); airGlow = null; }
      if (reduce) return;
      var r0 = rng(21), half = coarse ? .5 : 1, spec = {
        dust:      { n: 140, map: glow, color: "#d8f0dc", size: .07, op: .32, add: true },
        fireflies: { n: 80,  map: glow, color: "#ffd36a", size: .15, op: .95, add: true, vc: true },
        sakura:    { n: 150, map: spriteTexture(T, "petal"), color: "#ffc6da", size: .24, op: .95, add: false },
        snow:      { n: 220, map: glow, color: "#ffffff", size: .06, op: .75, add: false },
        embers:    { n: 130, map: glow, color: "#ff9a3c", size: .1, op: .95, add: true, vc: true },
        lanterns:  { n: 14,  map: spriteTexture(T, "lantern"), color: "#ffffff", size: .9, op: 1, add: false },
        kiku:      { n: 130, map: spriteTexture(T, "kpetal"), color: "#ffffff", size: .36, op: 1, add: false, glow: true }
      }[kind] || null;
      if (!spec) return;
      airN = Math.round(spec.n * half); airPos = new Float32Array(airN * 3); airSeed = new Float32Array(airN * 3); airCol = spec.vc ? new Float32Array(airN * 3) : null;
      for (var i = 0; i < airN; i++) {
        airPos[i * 3] = (r0() - .5) * FW * 1.1; airPos[i * 3 + 1] = .15 + r0() * 2.6; airPos[i * 3 + 2] = (r0() - .5) * FH * 1.3;
        airSeed[i * 3] = r0() * 6.28; airSeed[i * 3 + 1] = .3 + r0(); airSeed[i * 3 + 2] = r0();
        if (airCol) { airCol[i * 3] = 1; airCol[i * 3 + 1] = 1; airCol[i * 3 + 2] = 1; }
      }
      var g = new T.BufferGeometry(); g.setAttribute("position", new T.BufferAttribute(airPos, 3));
      if (airCol) g.setAttribute("color", new T.BufferAttribute(airCol, 3));
      var m = new T.PointsMaterial({ map: spec.map, color: hex(spec.color), size: spec.size, transparent: true, opacity: spec.op, blending: spec.add ? T.AdditiveBlending : T.NormalBlending, depthWrite: false, sizeAttenuation: true, vertexColors: !!spec.vc, alphaTest: spec.add ? 0 : .08 });
      air = new T.Points(g, m); scene.add(air);
      if (kind === "lanterns" || spec.glow) {
        var gg = new T.BufferGeometry(); gg.setAttribute("position", new T.BufferAttribute(airPos, 3));
        airGlow = new T.Points(gg, new T.PointsMaterial({ map: glow, color: hex(spec.glow ? "#ffd27a" : "#ff9a4a"), size: spec.glow ? .62 : 1.4, transparent: true, opacity: spec.glow ? .42 : .35, blending: T.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
        scene.add(airGlow);
      }
    }
    function airStep(now) {
      if (!air) return;
      var a = airPos, k = airKind, c = airCol, dt = 1;
      for (var i = 0, j = 0; i < airN; i++, j += 3) {
        var s0 = airSeed[j], s1 = airSeed[j + 1], s2 = airSeed[j + 2];
        if (k === "dust") { a[j + 1] += Math.sin(now / 1400 * s1 + s0) * .0012; a[j] += Math.cos(now / 2300 + s0) * .0008; }
        else if (k === "fireflies") { a[j] += Math.cos(now / 900 * s1 + s0) * .003; a[j + 1] += Math.sin(now / 1100 * s1 + s0 * 2) * .002; a[j + 2] += Math.sin(now / 1300 + s0) * .002; var b = .5 + .5 * Math.sin(now / 350 * s1 + s0 * 5); b = b * b * b; c[j] = b; c[j + 1] = b * .85; c[j + 2] = b * .4; }
        else if (k === "sakura") { a[j + 1] -= .006 * s1 * dt; a[j] += Math.sin(now / 700 + s0) * .004; a[j + 2] += Math.cos(now / 900 + s0) * .002; if (a[j + 1] < .1) { a[j + 1] = 2.8; a[j] = (s2 - .5) * FW * 1.1 + Math.sin(now / 500) * .5; } }
        else if (k === "snow") { a[j + 1] -= .004 * s1; a[j] += Math.sin(now / 1200 + s0) * .0025; if (a[j + 1] < .05) a[j + 1] = 2.9; }
        else if (k === "embers") { a[j + 1] += .005 * s1; a[j] += Math.sin(now / 500 * s1 + s0) * .003; if (a[j + 1] > 2.9) { a[j + 1] = .05; a[j] = (s2 - .5) * FW; } var e = .4 + .6 * Math.abs(Math.sin(now / 220 * s1 + s0)); var hgt = a[j + 1] / 2.9; c[j] = e; c[j + 1] = e * (.55 - hgt * .4); c[j + 2] = e * .12 * (1 - hgt); }
        else if (k === "kiku") { a[j + 1] -= .0032 * s1; a[j] += Math.sin(now / 1100 + s0) * .0032; a[j + 2] += Math.cos(now / 1500 + s0 * 2) * .0022; if (a[j + 1] < .1) { a[j + 1] = 2.9; a[j] = (s2 - .5) * FW * 1.1; } }
        else if (k === "lanterns") { a[j + 1] += .0016 * s1; a[j] += Math.sin(now / 2600 + s0) * .0015; a[j + 2] += Math.cos(now / 3100 + s0) * .001; if (a[j + 1] > 3.2) { a[j + 1] = .3; a[j] = (s2 - .5) * FW * 1.2; } }
      }
      air.geometry.attributes.position.needsUpdate = true;
      if (c) air.geometry.attributes.color.needsUpdate = true;
      if (airGlow) airGlow.geometry.attributes.position.needsUpdate = true;
    }
    airBuild("dust");

    // ---- camera and controls
    var controls = new A.OrbitControls(camera, canvas);
    controls.enablePan = false; controls.enableDamping = true; controls.dampingFactor = .08;
    controls.rotateSpeed = .55; controls.zoomSpeed = .9;
    controls.minDistance = 2.4; controls.maxDistance = 13; controls.minPolarAngle = .18; controls.maxPolarAngle = 1.34;
    controls.touches = { ONE: T.TOUCH.ROTATE, TWO: T.TOUCH.DOLLY_PAN };
    var dirty = true, tween = null, raf = 0, dead = false;
    controls.addEventListener("change", function () { dirty = true; });
    function flyTo(p, t, ms) {
      var from = camera.position.clone(), to = new T.Vector3().fromArray(p), t0 = new T.Vector3().copy(controls.target), t1 = new T.Vector3().fromArray(t);
      if (reduce || !ms) { camera.position.copy(to); controls.target.copy(t1); controls.update(); dirty = true; tween = null; return; }
      var start = performance.now();
      tween = function (now) {
        var k = Math.min(1, (now - start) / ms); k = k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
        camera.position.lerpVectors(from, to, k); controls.target.lerpVectors(t0, t1, k);
        dirty = true; if (k >= 1) tween = null;
      };
    }
    function view(name, ms) {
      if (name === "mine") {
        // fly to what the player holds: the middle of their Regions, close, from a little in front
        var xs = 0, zs = 0, c = 0;
        names.forEach(function (n) { var x = R[n]; if (x && x.state === me) { xs += x.cx; zs += x.cz; c++; } });
        if (!c) { name = "overview"; } else {
          xs /= c; zs /= c;
          var spread = 0; names.forEach(function (n) { var x = R[n]; if (x && x.state === me) spread = Math.max(spread, Math.hypot(x.cx - xs, x.cz - zs)); });
          var d = Math.min(9, Math.max(3.6, 3 + spread * 1.3));
          flyTo([xs * .9, d * .62, zs + d * .78], [xs, .1, zs], ms); if (hooks.view) hooks.view("mine"); return;
        }
      }
      var v = VIEWS[name] || VIEWS.overview;
      flyTo(v.p, v.t, ms); if (hooks.view) hooks.view(VIEWS[name] ? name : "overview");
      follow = name === "cinematic"; following = false; queue.length = 0;
    }
    //MC 2026-10-14 Cinematic follows the action: every change on the table (a Region gained, lost, traded or destroyed)
    //   is queued, changes that land together are framed as one shot, the camera flies in low, holds on it, then
    //   returns to its seat. Any drag, another view, or a card waiting for a target hands the camera back.
    var follow = false, following = false, holdUntil = 0, queue = [], born = performance.now();
    controls.addEventListener("start", function () { tween = null; follow = false; following = false; queue.length = 0; if (hooks.view) hooks.view(null); });
    function shot(now) {
      while (queue.length && now - queue[0].t > 8000) queue.shift();   // a shot that waited through a whole turn is stale
      if (!queue.length || now - queue[0].t < 140) return;
      var t0 = queue[0].t, batch = [];
      while (queue.length && queue[0].t - t0 < 260) batch.push(queue.shift());
      var cx = 0, cz = 0; batch.forEach(function (e) { cx += e.x; cz += e.z; }); cx /= batch.length; cz /= batch.length;
      var spread = 0; batch.forEach(function (e) { spread = Math.max(spread, Math.hypot(e.x - cx, e.z - cz)); });
      var d = 2.6 + spread * 1.4;
      flyTo([cx + d * .28, d * .62, cz + d * .8], [cx, .15, cz], 700);
      following = true; holdUntil = now + 700 + 1300 + Math.min(600, batch.length * 150);
    }

    // ---- painting
    var turn = null, hl = null, picking = false, hovered = null, WHITE = hex("#ffffff"), PINK = hex("#ff5d73");
    function look(n, now) {
      var x = R[n]; if (!x) return;
      var ownIdx = typeof x.state === "number", gone = x.state === "gone";
      if (x.colKey !== x.color + "|" + x.state + "|" + L.top) {   // colours are built once per change, never per frame
        x.colKey = x.color + "|" + x.state + "|" + L.top;
        x.col = ownIdx ? hex(x.color) : hex(L.top);
        x.baseCol = gone ? hex(L.gone) : ownIdx ? mix(x.color, L.top, .3) : hex(L.top);
        x.domeCol = ownIdx ? hex(x.color).lerp(WHITE, .6) : WHITE;
      }
      var dim = hl != null && (!ownIdx || x.state !== hl) ? .4 : 1;
      x.top.color.copy(x.baseCol).multiplyScalar(dim);
      x.mesh.material[1] = gone ? sideGone : sideOpen;
      var e = 0;
      if (ownIdx) {
        x.top.emissive.set(x.color);
        if (turn === x.state) e = .1 + .12 * (.5 + .5 * Math.sin(now / 320 + x.phase));
        if (hl === x.state) e = Math.max(e, .28);
        if (x.flags.pickable) e = Math.max(e, .25 + .25 * (.5 + .5 * Math.sin(now / 170)));
      }
      if (x.flash > now) { var f = (x.flash - now) / 650; x.top.emissive.copy(WHITE).lerp(x.col, 1 - f); e = Math.max(e, .9 * f); }
      if (!ownIdx && !(x.flash > now)) x.top.emissive.set(L.em);
      x.top.emissiveIntensity = Math.max(e, ownIdx || gone ? 0 : L.emi);
      if (L.anim === "holo" && ownIdx) x.top.emissiveIntensity = Math.max(x.top.emissiveIntensity, .35);
      // hover lift on desktop: the plate rises a touch and its coastline brightens
      var want = hovered === n ? .05 : 0;
      x.lift += (want - x.lift) * (reduce ? 1 : .25);
      // a destroyed Region sinks into the table and stays low; it is still there to read, just drowned
      var sunk = gone ? 1 : 0;
      if (x.sink > now) { var sk = 1 - (x.sink - now) / 900; sk = sk * sk; sunk = gone ? sk : 1 - sk; }
      var dz = x.lift - sunk * LAND_H * .8;
      x.mesh.position.z = dz; x.coast.position.z = LAND_H + BEV + .004 + dz;
      x.coast.children.forEach(function (l) { l.material = hovered === n ? coastHot : coastMat; });
      x.coast.visible = !gone || x.sink > now;
      x.mk.position.y = TOP + dz;
      x.own.visible = ownIdx; x.pin.visible = !ownIdx && !gone;
      if (ownIdx) {
        var col = x.col, want = pieceOf[x.state] || "";
        if (x.pieceKind !== want) {
          var pg = pieceCache[want] || (pieceCache[want] = want ? pieceGeo(T, want) : { still: gemGeo, y: .2 }); x.pieceKind = want;
          x.gem.geometry = pg.still; x.gem.userData.turn = !want;
          x.spin.geometry = pg.spin || gemGeo; x.spin.visible = !!pg.spin; x.spin.userData.y = pg.y;
        }
        x.gem.material.color.copy(col); x.gem.material.emissive.copy(col);
        x.gem.material.emissiveIntensity = x.flags.pickable ? 1.1 : (turn === x.state ? .85 : .6);
        x.base.material.color.copy(col).multiplyScalar(.55); x.base.material.emissive.copy(col); x.base.material.emissiveIntensity = .25;
        x.halo.material.color.copy(col); x.halo.material.opacity = turn === x.state ? .7 + .3 * (.5 + .5 * Math.sin(now / 320 + x.phase)) : .6;
        var d = x.drop > now ? (x.drop - now) / 480 : 0;
        var gy = x.gem.userData.turn === false ? 0 : .2;
        x.gem.position.y = gy + d * d * 1.2 + (x.gem.userData.turn === false ? 0 : (reduce ? 0 : .018 * Math.sin(now / 700 + x.phase)));
        x.gem.rotation.y = x.gem.userData.turn === false ? (x.pieceKind === "katana" ? x.phase : .6) : (reduce ? .6 : now / 1900 + x.phase);
        if (x.spin.visible) { x.spin.position.y = x.spin.userData.y + d * d * 1.2 + (reduce ? 0 : .025 * Math.sin(now / 600 + x.phase)); x.spin.rotation.y = reduce ? 0 : now / 1100 + x.phase; x.spin.rotation.x = x.pieceKind === "dragon" ? now / 2400 : 0; }
        x.own.scale.setScalar(picking && !x.flags.pickable ? .82 : 1);
      }
      var sh = ownIdx && !!x.flags.shield;
      x.dome.visible = sh; x.shell.visible = sh;
      if (sh) {
        x.dome.material.color.copy(x.domeCol); x.shell.material.color.copy(x.domeCol);
        x.dome.rotation.y = now / 2600; x.dome.material.opacity = .28 + .12 * (.5 + .5 * Math.sin(now / 900 + x.phase));
      }
      var tg = !!x.flags.pickable;
      x.ring.visible = tg || x.boom > now;
      if (x.boom > now) {
        // the shock ring of a change: red for a loss or a kill, the new holder's colour for a gain
        var bk = 1 - (x.boom - now) / 900; x.ring.scale.setScalar(.8 + bk * 2.6); x.ring.material.opacity = .9 * (1 - bk) * (1 - bk);
        x.ring.material.color.set(x.boomColor || "#ff5d73");
      } else if (tg) { var k = (now / 1100 + x.phase) % 1; x.ring.scale.setScalar(.9 + k * .55); x.ring.material.opacity = .95 * (1 - k); x.ring.material.color.copy(PINK); }
      x.mesh.visible = true;
    }
    function paint(n, state, color, flags) {
      var x = R[n]; if (!x) return;
      var was = x.state, now = performance.now();
      x.state = state; x.color = color || ""; x.flags = flags || {};
      if (was !== state && was !== undefined) {
        x.flash = now + 650; if (typeof state === "number") x.drop = now + 480;
        if (state === "gone" || was === "gone") x.sink = now + 900;
        if (now - born > 600) {
          x.boom = now + 900; x.boomColor = typeof state === "number" ? x.color : "#ff5d73";
          if (follow) queue.push({ n: n, x: x.cx, z: x.cz, t: now });
        }
      }
      look(n, now); dirty = true;
    }
    function setTurn(i) { turn = i; dirty = true; }
    // the Dojo's war table cosmetics: felt, land, air for the viewer; pieces per seat (rivals bring their own in live matches)
    function setLook(o) {
      o = o || {};
      var nf = FELTS[o.felt] ? o.felt : "", nl = LANDS[o.land] ? o.land : "", na = AIRS[o.air] ? AIRS[o.air] : "dust";
      if (FELTS[nf] !== F) {
        F = FELTS[nf];
        var old = felt.material.map; felt.material.map = feltTexture(T, F); if (old) old.dispose();
        felt.material.roughness = F.rough; felt.material.metalness = F.metal; felt.material.needsUpdate = true;
        old = sky.material.map; sky.material.map = skyTexture(T, F); if (old) old.dispose(); sky.material.color.setScalar(1);
        brass.material.color.set(F.brass); woodMat.color.set(F.frame); pool.material.color.set(F.pool);
        sheet.visible = F.anim === "ocean" || F.anim === "heaven"; cloud.visible = F.anim === "storm";
        sheet.material.color.set(F.anim === "heaven" ? "#ffcf6a" : "#7fe0ff"); key.color.set(F.anim === "heaven" ? "#ffe2b0" : "#fff0d2"); key.intensity = 1.6; rimL.intensity = .55; bolt = 0; nextBolt = performance.now() + 1500;
      }
      if (LANDS[nl] !== L) {
        L = LANDS[nl];
        sideOpen.color.set(L.side); coastMat.color.set(L.coast); coastMat.opacity = L.coastA;
        names.forEach(function (n) { var x = R[n]; if (!x) return; x.top.roughness = L.rough; x.top.metalness = L.metal; x.top.emissiveMap = L.anim === "holo" ? scanTex : null; x.top.transparent = L.anim === "holo"; x.top.opacity = L.anim === "holo" ? .88 : 1; x.top.needsUpdate = true; });
      }
      if (na !== airKind) { airKind = na; airBuild(na); }
      var pieces = o.pieces || {};
      pieceOf = {}; Object.keys(pieces).forEach(function (k) { pieceOf[+k] = pieces[k] || ""; });
      names.forEach(function (n) { look(n, performance.now()); }); dirty = true;
    }
    //MC 2026-10-24 a Shadow's card lands on the table (assets/shadowplay.js): a white flash on the key light, a kick of
    //   the camera toward the table and back, and a shockwave ring on the felt in the card's colour. One cheap mesh.
    var strikeRing = new T.Mesh(ringGeo, new T.MeshBasicMaterial({ color: hex("#ffffff"), transparent: true, opacity: 0, depthWrite: false, side: T.DoubleSide }));
    strikeRing.rotation.x = -Math.PI / 2; strikeRing.position.y = TOP + .03; strikeRing.visible = false; scene.add(strikeRing);
    var strike = 0;
    function pulse(col) {
      if (reduce) return;
      strike = performance.now(); strikeRing.material.color.set(col || "#ffffff"); strikeRing.visible = true;
      var p = camera.position.clone(), tg = controls.target.clone(); tween = null;
      var d = tg.clone().sub(p).normalize().multiplyScalar(.9), from = p.clone(), kicked = p.clone().add(d), start = strike;
      tween = function (now) {
        var k = Math.min(1, (now - start) / 420), e = k < .35 ? k / .35 : 1 - (k - .35) / .65;
        camera.position.lerpVectors(from, kicked, e * e); dirty = true; if (k >= 1) tween = null;
      };
      dirty = true;
    }
    function setHl(i) { hl = i; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }
    function setPicking(on) { picking = !!on; canvas.style.cursor = on ? "crosshair" : ""; names.forEach(function (n) { look(n, performance.now()); }); dirty = true; }

    // ---- size
    function size() {
      var w = el.clientWidth, h = el.clientHeight; if (!w || !h) return;
      renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); dirty = true;
    }
    var ro = new ResizeObserver(size); ro.observe(el); size();

    // ---- pointer: hover tells (and lifts), a still tap picks
    var ray = new T.Raycaster(), ndc = new T.Vector2(), down = null;
    function hit(e) {
      var b = canvas.getBoundingClientRect();
      ndc.set(((e.clientX - b.left) / b.width) * 2 - 1, -((e.clientY - b.top) / b.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      var hits = ray.intersectObjects(pick, false);
      for (var i = 0; i < hits.length; i++) { var o = hits[i].object; if (o.visible && o.userData.region && (!o.parent || o.parent.visible)) return o.userData.region; }
      return null;
    }
    function hover(n) { if (hovered === n) return; hovered = n; dirty = true; }
    canvas.addEventListener("pointermove", function (e) {
      if (e.pointerType !== "mouse" || down) return;
      var n = hit(e); hover(n);
      if (n) { if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType); } else if (hooks.leave) hooks.leave();
    });
    canvas.addEventListener("pointerdown", function (e) { down = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId }; });
    canvas.addEventListener("pointerup", function (e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), dt = performance.now() - down.t; down = null;
      if (moved > 9 || dt > 600) return;
      var n = hit(e); if (!n) { hover(null); if (hooks.leave) hooks.leave(); return; }
      if (hooks.tip) hooks.tip(n, e.clientX, e.clientY, e.pointerType);
      if (hooks.tap) hooks.tap(n);
    });
    canvas.addEventListener("pointercancel", function () { down = null; });
    canvas.addEventListener("pointerleave", function () { down = null; hover(null); if (hooks.leave) hooks.leave(); });
    //MC 2026-10-14 our own dispose forces a context loss too, so only a loss on a live table counts as a failure
    canvas.addEventListener("webglcontextlost", function (e) { e.preventDefault(); if (dead) return; dead = true; if (hooks.fail) hooks.fail("context"); });

    // ---- frames: capped (phones at 30), paused while the tab is hidden; the dust and the pieces keep it alive
    var last = 0, hidden = false, shown = false, offscreen = false;
    document.addEventListener("visibilitychange", function () { hidden = document.hidden; if (!hidden) dirty = true; });
    var io = window.IntersectionObserver ? new IntersectionObserver(function (es) { offscreen = !es[0].isIntersecting; if (!offscreen) dirty = true; }, { threshold: 0.02 }) : null;
    if (io) io.observe(el);
    var held = false;   //MC 2026-10-25 held still under a Shadow cut-in (the table is dimmed anyway) until the card lands
    function hold(on) { held = !!on; if (!held) dirty = true; }
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      if (hidden || held || (offscreen && shown)) return;
      if (tween) tween(now);
      if (follow && !picking) {
        if (!tween && (!following || now > holdUntil)) shot(now);
        if (following && !queue.length && !tween && now > holdUntil + 500) { following = false; flyTo(VIEWS.cinematic.p, VIEWS.cinematic.t, 1000); }
      }
      var moved = controls.update();
      if (now - last < (coarse ? 38 : 15) && !moved && !dirty) return;
      airStep(now);
      if (F.anim === "ocean") { sheetTex.offset.set(now / 26000, -now / 31000); sheet.material.opacity = .08 + .04 * Math.sin(now / 1700); }
      else if (F.anim === "heaven") { sheetTex.offset.set(now / 52000, now / 61000); sheet.material.opacity = .035 + .03 * Math.sin(now / 2100); var br = .5 + .5 * Math.sin(now / 2600); key.intensity = 1.5 + br * .45; sky.material.color.setScalar(1 + br * .25); }
      else if (F.anim === "storm") {
        cloudTex.offset.set(now / 38000, now / 52000);
        if (now > nextBolt) { bolt = now + 140 + Math.random() * 160; nextBolt = now + 2200 + Math.random() * 5200; }
        var fl = bolt > now ? (.4 + .6 * Math.random()) : 0;
        key.intensity = 1.6 + fl * 3.2; sky.material.color.setScalar(1 + fl * 1.6); rimL.intensity = .55 + fl * 2;
      }
      if (L.anim === "holo") scanTex.offset.y = -now / 2600;
      if (strike) { var sk = (now - strike) / 700; if (sk >= 1) { strike = 0; strikeRing.visible = false; key.intensity = F.anim === "storm" ? key.intensity : 1.6; } else { strikeRing.scale.setScalar(.5 + sk * 9); strikeRing.material.opacity = (1 - sk) * .75; key.intensity = 1.6 + (1 - sk) * 2.6; dirty = true; } }
      names.forEach(function (n) { look(n, now); });
      dirty = false; last = now;
      renderer.render(scene, camera);
      if (!shown) { shown = true; el.classList.add("is-ready"); }
    }
    raf = requestAnimationFrame(frame);
    view("overview", 0); camera.position.set(-2.5, 13, 9.5); controls.target.set(0, 0, 0); view("overview", 1500);

    function dispose() {
      dead = true; cancelAnimationFrame(raf); ro.disconnect(); if (io) io.disconnect();
      try { controls.dispose(); } catch (e) {}
      scene.traverse(function (o) { if (o.geometry) o.geometry.dispose(); var m = o.material; if (m) (Array.isArray(m) ? m : [m]).forEach(function (q) { if (q.map) q.map.dispose(); if (q.bumpMap) q.bumpMap.dispose(); q.dispose(); }); });
      try { renderer.dispose(); renderer.forceContextLoss(); } catch (e) {}
      if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
      el.classList.remove("is-ready");
    }
    return { paint: paint, setTurn: setTurn, setHl: setHl, setPicking: setPicking, setLook: setLook, pulse: pulse, hold: hold, view: function (v) { view(v, 900); }, resize: size, dispose: dispose, canvas: canvas };
  }

  window.ShyMap3D = { supported: supported, load: load, mount: mount };
})();
