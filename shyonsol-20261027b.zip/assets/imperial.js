//MC 2026-10-24 The Imperial Regalia, the tier above Mythic. This file is the unsealing: when an Imperial piece is bought
//   (in the Dojo, the Imperial Vault or the Profile Studio) a lacquered box drops in, its 帝 seal glows and breaks, the lid
//   lifts in a burst of light and the piece rises out of it with its number. Tap or Escape closes it once it has opened.
//   Reduced motion skips straight to the open box. The Vault itself is drawn by shop.js; its styles are in imperial.css.
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function pad(n) { n = String(Math.max(0, n | 0)); return n.length < 3 ? ("00" + n).slice(-3) : n; }
  var open = null;
  // o: { name, desc, no, rank, rankName, up, art (html), sfx(fn), onClose(fn), wear (label, fn) }
  function ceremony(o) {
    close(true);
    var el = document.createElement("div");
    el.className = "imc" + (reduce ? " now" : "");
    el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", (o.name || "Imperial piece") + ", Imperial No. " + pad(o.no));
    var sov = o.up && o.rank >= 4;
    el.innerHTML = '<div class="imc-veil"></div><div class="imc-rays" aria-hidden="true"></div><div class="imc-dust" aria-hidden="true">' + new Array(19).join("<i></i>") + '</div>' +
      '<div class="imc-box" aria-hidden="true"><div class="imc-base"><i></i></div><div class="imc-lid"><i class="imc-cord"></i><b class="imc-seal">帝</b></div></div>' +
      '<div class="imc-rev"><div class="imc-art">' + (o.art || "") + '</div>' +
      '<span class="imc-k">The Imperial Regalia</span><h3>' + esc(o.name) + '</h3>' +
      '<div class="imc-no"><small>Imperial</small><b data-i18n-skip>No. ' + pad(o.no) + '</b></div>' +
      (o.desc ? '<p class="imc-d">' + esc(o.desc) + '</p>' : "") +
      (o.up ? '<p class="imc-up' + (sov ? " sov" : "") + '"><i class="imp-cr c' + (o.rank | 0) + '" aria-hidden="true"></i> ' + (sov ? "Every piece is yours. You are <b>Sovereign</b>, with the title and the ring no one can buy." : "Your Imperial crest rises to <b>" + esc(o.rankName) + "</b>. It shows next to your name everywhere.") + '</p>' : "") +
      '<div class="imc-act">' + (o.wear ? '<button type="button" class="btn btn-red" data-imc-wear>' + esc(o.wear.label) + '</button>' : "") + '<button type="button" class="btn btn-line" data-imc-x>Close</button></div></div>';
    // inside the open shop: the shop pauses every animation outside itself while it's up
    var shop = document.getElementById("shop");
    (shop && !shop.hidden ? shop : document.body).appendChild(el);
    open = { el: el, o: o, at: Date.now() + (reduce ? 0 : 2300), ae: document.activeElement };
    requestAnimationFrame(function () { el.classList.add("go"); });
    if (o.sfx) { try { o.sfx("select"); } catch (e) {} setTimeout(function () { try { o.sfx("badge"); } catch (e) {} }, reduce ? 0 : 1500); }
    if (navigator.vibrate && !reduce) try { setTimeout(function () { navigator.vibrate([30, 40, 60]); }, 1500); } catch (e) {}
    setTimeout(function () { var b = el.querySelector("[data-imc-wear]") || el.querySelector("[data-imc-x]"); if (b && open && open.el === el) b.focus({ preventScroll: true }); }, reduce ? 30 : 2400);
    el.addEventListener("click", function (e) {
      if (e.target.closest("[data-imc-wear]")) { var w = o.wear; close(); if (w && w.fn) w.fn(); return; }
      if (e.target.closest("[data-imc-x]") || (Date.now() > open.at && !e.target.closest(".imc-act"))) close();
    });
  }
  function close(quiet) {
    if (!open) return;
    var x = open; open = null;
    x.el.classList.add("out");
    setTimeout(function () { x.el.remove(); }, quiet ? 0 : 320);
    if (!quiet && x.o.onClose) x.o.onClose();
    if (!quiet && x.ae && document.contains(x.ae) && x.ae.focus) try { x.ae.focus({ preventScroll: true }); } catch (e) {}
  }
  document.addEventListener("keydown", function (e) {
    if (!open) return;
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); return; }
    if (e.key === "Tab") { e.stopPropagation(); var f = [].slice.call(open.el.querySelectorAll("button")); if (!f.length) return; var i = f.indexOf(document.activeElement); if (i < 0 || (e.shiftKey && i === 0) || (!e.shiftKey && i === f.length - 1)) { e.preventDefault(); f[e.shiftKey ? f.length - 1 : 0].focus(); } }
  }, true);
  // the crest beside a name: 1 Noble, 2 Court, 3 Regent, 4 Sovereign
  var RANK = { 1: "Noble", 2: "Court", 3: "Regent", 4: "Sovereign" };
  function crest(n) { n = n | 0; return n >= 1 && n <= 4 ? '<i class="imp-cr c' + n + '" title="Imperial crest: ' + RANK[n] + '" aria-label="Imperial crest: ' + RANK[n] + '"></i>' : ""; }
  window.ShyImp = { ceremony: ceremony, close: close, crest: crest, pad: pad, isOpen: function () { return !!open; } };
})();
