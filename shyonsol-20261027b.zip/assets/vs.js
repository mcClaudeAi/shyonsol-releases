//MC 2026-10-22 A community challenge page (/vs/<slug>): names the community everywhere, fills the board, the bar to beat,
//   the tug of war and the countdown, points the Play button at /play?vs=<slug> (friends.js signs a new profile up
//   for that community there), and builds the rally share links. The board comes inside the page (window.SHY_VS from
//   api/vspage.php) and refreshes every minute while the page is open.
(function () {
  "use strict";
  function $(id) { return document.getElementById(id); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  var noMove = false; try { noMove = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
  var m = location.pathname.match(/^\/vs\/([a-z0-9-]{1,40})\/?$/), slug = m ? m[1] : "";
  var B = window.SHY_VS || null, pid = "", painted = false;
  try { pid = localStorage.getItem("shy-lb-pid") || ""; } catch (e) {}
  function txt(id, t) { var el = $(id); if (el) el.textContent = t; }
  function left(ends) {
    var s = Math.max(0, ends - Math.floor(Date.now() / 1000)), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), mm = Math.floor(s % 3600 / 60);
    return d ? d + "d " + h + "h" : (h ? h + "h " + mm + "m" : mm + "m");
  }
  function rows(list, bar, them) {
    return list.map(function (r) { return '<li' + (them && bar && r.pts > bar ? ' class="cm-podium"' : "") + '><b data-i18n-skip>' + esc(r.name) + "</b><span>" + fmt(r.pts) + "</span></li>"; }).join("");
  }
  function count(el, to) {
    if (!el) return; if (noMove || painted || to < 2) { el.textContent = fmt(to); return; }
    var t0 = performance.now(), ms = 1100;
    (function step(t) { var k = Math.min(1, (t - t0) / ms); k = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(to * k)); if (k < 1) requestAnimationFrame(step); })(t0);
  }
  function paint(b) {
    if (!b) return;
    var n = b.name, sym = b.sym ? "$" + String(b.sym).toUpperCase() : "";
    txt("vs-name", n); txt("vs-their-h", n + "'s"); txt("vs-tk", sym || n);
    txt("vs-lead", b.months + " months in and " + n + " is still standing. Think its holders can beat the Shilluminati leaders this week?");
    $("vs-play").innerHTML = "Play a free hand for " + esc(n) + ' <svg viewBox="0 0 24 24" aria-hidden="true" width="18" height="18"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    $("vs-play").href = "/play?vs=" + encodeURIComponent(b.slug);
    txt("vs-step2-h", "Every point counts for " + n);
    txt("vs-rally-h", "Rally " + n);
    txt("vs-st-months", b.months);
    count($("vs-st-players"), b.players); txt("vs-st-pl-l", b.players === 1 ? "player for " + n : "players for " + n);
    txt("vs-st-ends", left(b.ends));
    var lg = $("vs-logo"), ini = $("vs-ini");
    if (ini) ini.textContent = (b.sym || n || "?").slice(0, 3).toUpperCase();
    if (lg && b.logo && !lg.src) { lg.onload = function () { lg.hidden = false; }; lg.onerror = function () { lg.hidden = true; }; lg.src = b.logo; }
    $("vs-ours").innerHTML = b.ours.length ? rows(b.ours, 0, false) : '<li><b>The board is open</b><span>0</span></li>';
    $("vs-theirs").innerHTML = rows(b.theirs, b.bar, true);
    var em = $("vs-empty");
    if (!b.theirs.length) { em.textContent = "Nobody yet. The first hand you play puts " + n + " on the board."; em.hidden = false; } else em.hidden = true;
    count($("vs-bar"), b.bar + 1);
    txt("vs-bar-note", b.beat ? n + " already broke into our top three. Keep it there." : (b.bar ? "Score " + fmt(b.bar + 1) + " this week to pass our #3 and take the podium." : "Our board is open this week. Any score takes the top."));
    // the tug of war: their week against our top three
    var us = b.ours.reduce(function (a, r) { return a + r.pts; }, 0), them = b.sum || 0, tot = us + them;
    var w = tot ? Math.max(4, Math.min(96, Math.round(them / tot * 100))) : 50;
    txt("vs-tug-them-n", fmt(them)); txt("vs-tug-us-n", fmt(us)); txt("vs-tug-them-l", n + " this week");
    var tg = $("vs-tug-them"), tu = $("vs-tug-us");
    if (noMove || painted) { tg.style.width = w + "%"; tu.style.width = (100 - w) + "%"; }
    else { tg.style.width = "50%"; tu.style.width = "50%"; setTimeout(function () { tg.style.width = w + "%"; tu.style.width = (100 - w) + "%"; }, 250); }
    // their own links, and the rally shares
    var link = location.origin + "/vs/" + b.slug;
    var say = "I'm playing Shilluminati for " + n + ". Help us take the top of the board this week. Free in the browser, no wallet:";
    $("vs-x").href = "https://x.com/intent/tweet?text=" + encodeURIComponent(say + (b.x ? " @" + b.x : "") + "\n" + link);
    $("vs-tg").href = "https://t.me/share/url?url=" + encodeURIComponent(link) + "&text=" + encodeURIComponent(say);
    var xh = $("vs-xh"); if (b.x) { xh.textContent = "@" + b.x + " on X"; xh.href = "https://x.com/" + encodeURIComponent(b.x); xh.hidden = false; }
    var dx = $("vs-dex"); if (b.url && /^https:\/\/dexscreener\.com\//.test(b.url)) { dx.href = b.url; dx.hidden = false; }
    painted = true;
  }
  function who(side) {
    var el = $("vs-me"); if (!el || !B) return;
    if (side === "them") { el.textContent = "You're playing for " + B.name; el.className = "cm-me"; el.hidden = false; }
    else if (side === "home") { el.textContent = "You play for the Shilluminati. Defend the top spots."; el.className = "cm-me home"; el.hidden = false; }
  }
  async function refresh() {
    if (!slug) return;
    try {
      var j = await (await fetch("/api/vs.php?a=board&c=" + encodeURIComponent(slug) + (pid ? "&me=" + pid : ""))).json();
      if (j && j.ok) { B = j.board; paint(B); who(j.me || (pid && localStorage.getItem("shy-lb-name") ? "home" : "")); }
    } catch (e) {}
  }
  $("vs-copy") && $("vs-copy").addEventListener("click", function () {
    var link = location.origin + "/vs/" + slug, b = $("vs-copy");
    var done = function () { b.textContent = "Copied"; setTimeout(function () { b.textContent = "Copy link"; }, 1500); };
    try { navigator.clipboard.writeText(link).then(done, function () { window.prompt("Copy the link", link); }); } catch (e) { window.prompt("Copy the link", link); }
  });
  if (B) paint(B);
  refresh();
  setInterval(function () { if (!document.hidden) refresh(); }, 60000);
  setInterval(function () { if (B) txt("vs-st-ends", left(B.ends)); }, 30000);
})();
