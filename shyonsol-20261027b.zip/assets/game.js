// Shilluminati Online: game rules engine. Plain functions so it runs in the browser and in tests.
// Rules follow Shytoshi's final design (Feb 6, 2025): 40 Regions, a 71-card Chaos deck, start with 2 Regions and
// 5 Chaos cards, draw 1 Chaos card a turn, Regions only come from cards, game ends when the Region deck runs out
// or someone holds 15. The server keeps an exact copy of this file in api/engine.php to replay and verify games.
(function (root) {
  "use strict";

  var REGIONS = ["Eastern North America", "Western North America", "Western Canada", "Eastern Canada", "Central America",
    "Caribbean", "Andes", "Amazonia", "Brazilian Highlands", "Southern Cone", "British Isles", "Scandinavia", "Western Europe",
    "Central Europe", "Eastern Europe", "Iberia", "Mediterranean", "Balkans", "North Africa", "West Africa", "Central Africa",
    "East Africa", "Southern Africa", "Southeast Africa", "Middle East", "Persia", "Arabian Peninsula", "Central Asia",
    "Western Siberia", "Far East", "South Asia", "Northern China", "Southern China", "Korean Peninsula", "Japan", "Indochina",
    "Indonesia", "Western Australia", "Eastern Australia", "Pacific Islands"];

  // kind: attack (aimed at rivals, can be blocked), gain, defense, global (everyone), trick (cards and turns), passive (reacts on its own)
  // target: "pick" (you choose a rival), "leader" (the rival with the most Regions), "none"
  // no: the card's number in the community list of 127 (0 = added in Shytoshi's final balancing)
  var CARDS = {
    // ---- attacks ----
    meteor:      { no: 52, name: "Meteor Strike", kind: "attack", target: "pick", text: "Destroy 2 Regions from one rival." },
    superweapon: { no: 77, name: "Secret Superweapon", kind: "attack", target: "pick", text: "Destroy 2 Regions from any rival of your choice." },
    plasma:      { no: 50, name: "Plasma Storm", kind: "attack", target: "pick", text: "Destroy 3 of a rival's Regions and draw 2 Chaos cards." },
    drone:       { no: 56, name: "Drone Strike", kind: "attack", target: "pick", text: "Destroy 1 Region of your choice." },
    sub:         { no: 3, name: "Hidden Nuclear Submarine", kind: "attack", target: "pick", text: "Destroy 1 Region and force its owner to discard 1 Chaos card." },
    drones:      { no: 14, name: "Unstoppable Drones", kind: "attack", target: "pick", text: "Destroy 1 Region of your choice, then the next player discards 1 Chaos card." },
    dictator:    { no: 63, name: "Rise of a Dictator", kind: "attack", target: "pick", text: "Steal 1 Region from any rival." },
    border:      { no: 108, name: "Border Conflict Escalates", kind: "attack", target: "pick", text: "Steal 1 Region from any rival of your choice." },
    coup:        { no: 54, name: "Coup d'État", kind: "attack", target: "leader", text: "Steal 1 Region from the rival with the most Regions." },
    empire:      { no: 114, name: "Shadow Empire", kind: "attack", target: "leader", text: "Steal 2 Regions from the rival with the most. They draw 2 Chaos cards." },
    endera:      { no: 21, name: "End of an Era", kind: "attack", target: "leader", text: "Destroy 2 Regions from the rival with the most Regions." },
    pact:        { no: 34, name: "Mutual Destruction Pact", kind: "attack", target: "pick", text: "You and one rival both lose 2 Regions and draw 3 Chaos cards each." },
    censor:      { no: 89, name: "Mass Media Censorship", kind: "attack", target: "pick", text: "Choose a rival to skip their next turn." },
    epidemic:    { no: 68, name: "Epidemic Containment", kind: "attack", target: "pick", text: "Choose a rival to lose their next turn." },
    newleader:   { no: 70, name: "New Global Leader", kind: "attack", target: "pick", text: "Choose any rival to skip their next turn." },
    prophecy:    { no: 24, name: "False Prophecy", kind: "attack", target: "pick", text: "Choose a rival to skip their next turn, and you draw 2 Chaos cards." },
    unicoup:     { no: 30, name: "Universal Coup", kind: "attack", target: "none", text: "Steal 1 Region from every rival." },
    machines:    { no: 23, name: "Rise of the Machines", kind: "attack", target: "none", text: "Destroy 1 Region from every rival." },
    popcontrol:  { no: 85, name: "Population Control Agenda", kind: "attack", target: "none", text: "Every rival discards 1 Region." },
    // ---- gains ----
    atlantis:    { no: 62, name: "Discovery of Atlantis", kind: "gain", target: "none", text: "Draw 2 Regions from the Region deck." },
    surge:       { no: 16, name: "Power Surge", kind: "gain", target: "none", text: "Gain 1 Region and draw 1 Chaos card." },
    resource:    { no: 44, name: "Resource Surge", kind: "gain", target: "none", text: "Gain 1 Region and draw 3 Chaos cards." },
    space:       { no: 65, name: "Space Race Victory", kind: "gain", target: "none", text: "Gain 1 Region from the discard pile, or the deck if it's empty." },
    solar:       { no: 37, name: "Solar Harvesting", kind: "gain", target: "none", text: "Gain 2 Regions, but skip your next turn." },
    era:         { no: 123, name: "Era of Expansion", kind: "gain", target: "none", text: "Gain 3 Regions, but skip your next turn." },
    reinforce:   { no: 125, name: "Reinforcements Arrive", kind: "gain", target: "none", text: "Gain 2 Regions and draw 2 Chaos cards." },
    prophecyful: { no: 40, name: "Prophecy Fulfilled", kind: "gain", target: "none", text: "Gain 1 Region from the Region deck and draw 1 Chaos card." },
    galactic:    { no: 41, name: "Galactic Expansion", kind: "gain", target: "none", text: "Gain 2 Regions, and the player with the fewest Regions gains 1." },
    galconsp:    { no: 97, name: "Galactic Conspiracy", kind: "gain", target: "none", text: "Gain 2 Regions, and the player with the most Regions loses 1." },
    tunnels:     { no: 84, name: "Underground Tunnels", kind: "gain", target: "none", text: "Gain 1 Region from the discard pile, or the deck if it's empty." },
    summit:      { no: 82, name: "Secret Society Summit", kind: "gain", target: "none", text: "Gain 1 Region, but skip your next turn." },
    underworld:  { no: 36, name: "Rise of the Underworld", kind: "global", target: "none", text: "Draw 3 Regions from the discard pile and share them among the players with the fewest." },
    rekindled:   { no: 46, name: "Rekindled Hope", kind: "global", target: "none", text: "The 2 players with the fewest Regions each gain 1 from the discard pile." },
    secretgov:   { no: 79, name: "Secret Government Project", kind: "gain", target: "none", text: "Gain 1 Region, then look at the top 5 Chaos cards and keep the best one." },
    awakening:   { no: 87, name: "The Great Awakening", kind: "gain", target: "none", text: "Gain 1 Region, and every rival skips their next turn." },
    // ---- defense ----
    bunker:      { no: 12, name: "Underground Bunker", kind: "defense", target: "none", text: "No attacks on your Regions for the next 2 rounds." },
    irondome:    { no: 0, name: "Iron Dome", kind: "defense", target: "none", text: "No attacks on your Regions for the next 3 rounds." },
    stronghold:  { no: 117, name: "The Last Stronghold", kind: "defense", target: "none", text: "Prevent all attacks on you for the next 3 rounds." },
    lone:        { no: 120, name: "Lone Survivor", kind: "defense", target: "none", text: "Prevent all attacks on you until you hold 3 Regions or more." },
    coop:        { no: 0, name: "Cooperative Defense", kind: "defense", target: "none", text: "You and the rival with the fewest Regions are safe from attacks for 2 rounds." },
    failedcoup:  { no: 66, name: "Failed Coup", kind: "passive", target: "none", text: "Keep it in your hand. It cancels the next attack on you and you draw 1 Chaos card." },
    assassin:    { no: 53, name: "Failed Assassination Attempt", kind: "passive", target: "none", text: "Keep it in your hand. It cancels the next attack on you, and the attacker skips their next turn." },
    decoy:       { no: 102, name: "Holographic Decoy", kind: "passive", target: "none", text: "Keep it in your hand. It cancels the next attack targeting you." },
    // ---- everyone ----
    boom:        { no: 4, name: "Population Boom", kind: "global", target: "none", text: "All players (including you) draw 1 Region." },
    forgotten:   { no: 0, name: "Rise of the Forgotten", kind: "global", target: "none", text: "The player with the fewest Regions draws 4 Regions." },
    overthrow:   { no: 9, name: "Global Overthrow", kind: "global", target: "none", text: "The player with the fewest Regions gains 2 Regions from the discard pile." },
    resistance:  { no: 121, name: "Rise of the Resistance", kind: "global", target: "none", text: "Players with fewer than 3 Regions each gain 1 Region." },
    taxation:    { no: 38, name: "Universal Taxation", kind: "global", target: "none", text: "Players with 3 or more Regions discard 1. Players with fewer gain 1 from the deck." },
    audit:       { no: 0, name: "Global Audit", kind: "global", target: "none", text: "Every player with 7 or more Regions loses 3. Bunkers and domes block it." },
    rebellion:   { no: 5, name: "Unexpected Rebellion", kind: "global", target: "none", text: "The player with the most Regions discards 2 Regions." },
    zombie:      { no: 51, name: "Zombie Apocalypse", kind: "global", target: "none", text: "All players discard 1 Region." },
    negotiations:{ no: 7, name: "Failed Negotiations", kind: "global", target: "none", text: "Each player passes 1 Region to the discard pile." },
    locusts:     { no: 112, name: "Locusts Eat Everything", kind: "global", target: "none", text: "Destroy 1 Region from every player." },
    plague:      { no: 59, name: "Plague Outbreak", kind: "global", target: "none", text: "Destroy 1 Region from every player with 2 or more." },
    flood:       { no: 11, name: "The Great Flood", kind: "global", target: "none", text: "Destroy 1 Region from every player with 2 or more Regions." },
    ww3:         { no: 58, name: "World War III", kind: "global", target: "none", text: "Every player with 3 or more Regions discards 2." },
    mutiny:      { no: 1, name: "Global Mutiny", kind: "global", target: "none", text: "Every player (including you) discards 1 Region and 1 Chaos card." },
    alien:       { no: 22, name: "Alien Abduction Frenzy", kind: "global", target: "none", text: "All players (including you) discard 1 Region and 1 Chaos card." },
    nuclear:     { no: 6, name: "Nuclear Chain Reaction", kind: "global", target: "none", text: "The next player loses 1 Region, then the next, around the table until someone has none left to lose." },
    famine:      { no: 69, name: "The Great Famine", kind: "global", target: "none", text: "All players discard 1 Region. Anyone with none skips their next turn." },
    extinction:  { no: 73, name: "Extinction Level Event", kind: "global", target: "none", text: "Destroy 5 Regions at random from all players." },
    winter:      { no: 81, name: "Eternal Winter", kind: "global", target: "none", text: "Every other player skips their next turn. Back to you!" },
    renaissance: { no: 42, name: "Cultural Renaissance", kind: "global", target: "none", text: "All players draw 1 Chaos card." },
    blackhole:   { no: 17, name: "Black Hole Event", kind: "global", target: "none", text: "Every player discards their whole hand and draws 5 Chaos cards." },
    anarchy:     { no: 26, name: "Global Anarchy", kind: "global", target: "none", text: "All players discard their hands. Everyone draws 4 new Chaos cards." },
    cern:        { no: 35, name: "CERN Goes Haywire", kind: "global", target: "none", text: "Every player passes their whole hand to the player on their left." },
    // ---- tricks ----
    double:      { no: 8, name: "Double Disaster", kind: "trick", target: "none", text: "Play another Chaos card this turn." },
    blitz:       { no: 124, name: "Blitz Tactics", kind: "trick", target: "none", text: "Play 2 more Chaos cards this turn." },
    gravity:     { no: 33, name: "Gravity Collapse", kind: "trick", target: "none", text: "Discard the top 5 Chaos cards, then take another turn." },
    madsci:      { no: 10, name: "Mad Scientist's Experiment", kind: "trick", target: "none", text: "Draw 2 random Chaos cards from the discard pile." },
    superai:     { no: 43, name: "Superintelligent A.I.", kind: "trick", target: "none", text: "Look at the top 10 Chaos cards. Keep the best 3 and shuffle the rest back." },
    neural:      { no: 98, name: "Neural Network Hack", kind: "trick", target: "none", text: "Look at the top 10 Chaos cards and keep the best 2." },
    pandora:     { no: 27, name: "Pandora's Box", kind: "trick", target: "none", text: "Draw 5 Chaos cards, then discard your 3 weakest." },
    conspiracy:  { no: 13, name: "Global Conspiracy Unveiled", kind: "trick", target: "none", text: "Look at every rival's hand and make each discard their best card." },
    currency:    { no: 109, name: "Currency Collapse", kind: "trick", target: "none", text: "Every rival discards 2 Chaos cards. You draw 2." },
    netcrash:    { no: 60, name: "Global Internet Crash", kind: "trick", target: "none", text: "No one draws Chaos cards on their turn until your next turn." },
    tides:       { no: 2, name: "Tides of Power", kind: "trick", target: "none", text: "Trade your whole hand with the player on your left." },
    quantum:     { no: 99, name: "Quantum Rift", kind: "trick", target: "pick", text: "Swap your whole hand with any rival's hand." },
    falsememory: { no: 100, name: "False Memory Implant", kind: "trick", target: "none", text: "Undo what the last Chaos card did to everyone's Regions." },
    // ---- season cards: never in the original deck. A season's winning card joins play through useSeason(), always after
    // the cards above, so games with the original deck deal exactly as they always have. ----
    kamikaze:    { no: 0, season: 2, name: "Divine Wind", kind: "global", target: "none", text: "Every player, you too, discards 1 Chaos card. Then you draw 2 Regions." },
    decree:      { no: 0, season: 2, name: "Shogun's Decree", kind: "attack", target: "leader", text: "Steal 1 Region from the rival with the most. If you have the fewest Regions, steal 2." },
    ninja:       { no: 0, season: 2, name: "Ninja Infiltration", kind: "attack", target: "pick", text: "Steal 1 Region from any rival. Bunkers, domes and Lone Survivor don't stop it." },
    paper:       { no: 0, season: 2, name: "Paper Fortress", kind: "defense", target: "none", text: "Block the next attack on you. When it breaks, draw 1 Chaos card." },
    harvest:     { no: 0, season: 2, name: "Rice Harvest", kind: "gain", target: "none", text: "Draw 1 Region now and 1 more at the start of your next turn." },
    ronin:       { no: 0, season: 2, name: "Ronin for Hire", kind: "trick", target: "pick", text: "Take a random Chaos card from a rival's hand." },
    truce:       { no: 0, season: 2, name: "Tea Ceremony Truce", kind: "global", target: "none", text: "No one can attack until your next turn. Draw 1 Chaos card." },
    eclipse:     { no: 0, season: 2, name: "Eclipse", kind: "passive", target: "none", text: "Keep it in your hand. The next rival who steals from you loses 1 Region instead." }
  };
  // The 71 cards in the deck, one copy each. Cards in CARDS but not listed here are kept for testing other mixes.
  var DECK = ["meteor", "superweapon", "plasma", "galactic", "sub", "drones", "dictator", "border", "coup", "empire", "endera", "pact", "prophecyful", "epidemic",
    "newleader", "prophecy", "unicoup", "machines", "popcontrol", "atlantis", "surge", "resource", "space", "solar", "era", "secretgov", "awakening",
    "bunker", "irondome", "stronghold", "lone", "coop", "failedcoup", "assassin", "decoy", "boom", "forgotten", "overthrow", "galconsp", "taxation",
    "audit", "rebellion", "reinforce", "negotiations", "locusts", "plague", "flood", "ww3", "mutiny", "alien", "nuclear", "famine", "extinction", "winter",
    "renaissance", "blackhole", "anarchy", "cern", "double", "blitz", "gravity", "madsci", "superai", "neural", "pandora", "conspiracy", "currency",
    "netcrash", "tides", "quantum", "falsememory"];
  // rules that the balancing runs can switch; the shipped game uses these values
  var RULES = { claim: "pass", passWorth: null };
  function setDeck(list) { Object.keys(CARDS).forEach(function (id) { CARDS[id].n = 0; }); list.forEach(function (id) { CARDS[id].n = (CARDS[id].n || 0) + 1; }); }
  setDeck(DECK);
  // the season cards in play on top of the original deck (one added per season, never taken out of the original 71)
  var SEASON = [];
  function useSeason(list) {
    SEASON = (list || []).filter(function (id) { return CARDS[id] && CARDS[id].season && DECK.indexOf(id) < 0; });
    setDeck(DECK.concat(SEASON));
    return SEASON.slice();
  }

  // rough worth of each card in hand, used when a card keeps or discards "the best" or "the weakest"
  var WORTH = { reinforce: 6, prophecyful: 4, galactic: 5, galconsp: 5.5, tunnels: 3.5, summit: 3, underworld: 3, rekindled: 3, meteor: 6, superweapon: 6, plasma: 7, drone: 4, sub: 4.5, drones: 4.5, dictator: 5, border: 5, coup: 5, empire: 7, endera: 6,
    pact: 3, censor: 3, epidemic: 3, newleader: 3, prophecy: 4, unicoup: 7, machines: 5, popcontrol: 5, atlantis: 6, surge: 4, resource: 5,
    space: 3.5, solar: 4.5, era: 5, secretgov: 4.5, awakening: 7, bunker: 4, irondome: 5, stronghold: 5, lone: 3, coop: 4, failedcoup: 5,
    assassin: 5.5, decoy: 4.5, boom: 3, forgotten: 4, overthrow: 3, resistance: 3, taxation: 3, audit: 3.5, rebellion: 3.5, zombie: 2.5,
    negotiations: 2.5, locusts: 2.5, plague: 2.5, flood: 2.5, ww3: 3, mutiny: 2.5, alien: 2.5, nuclear: 3, famine: 2.5, extinction: 3,
    winter: 6, renaissance: 2, blackhole: 2, anarchy: 2, cern: 2, double: 4, blitz: 5, gravity: 5, madsci: 3.5, superai: 5, neural: 4,
    pandora: 4, conspiracy: 4, currency: 4, netcrash: 2.5, tides: 2, quantum: 2.5, falsememory: 3,
    kamikaze: 5, decree: 5.5, ninja: 5.5, paper: 4.5, harvest: 4.5, ronin: 3.5, truce: 3.5, eclipse: 5 };

  var PASS_WORTH = 5;
  // rival personalities: how much each leans toward its favorite kind of card
  var STYLE = { hawkAttack: 0.4, hawkGain: -0.1, buildGain: 0.25, buildDefense: 0.25, buildAttack: 0.05, wild: 1.8, attackScale: 1, leaderBonus: 0 };   // how much a bot values claiming a Region by passing
  var MAX_ROUNDS = 30;   // a safety net only; games end on the Region deck or 15 Regions long before this
  var WIN_AT = 15;

  // Seeded random numbers. The server runs the exact same generator to replay and verify games.
  function seeded(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  // The three rivals and their styles for a game. Same order of random draws as the server.
  var BOTS = ["Neon Ronin", "Iron Monk", "Paper Tiger", "Night Crane", "Jade Fox", "Silent Oni"];
  function setupRivals(rnd) {
    var names = shuffle(BOTS.slice(), rnd).slice(0, 3);
    var styles = shuffle(["hawk", "builder", "wild"], rnd);
    return { names: names, styles: styles };
  }

  //MC 2026-10-09 a bigger cast of rivals. Players kept meeting the same six names. The seats are still drawn from the
  //original six exactly as before (the server replays every game from its seed, and Duels and Daily replays reuse old
  //seeds), so nothing about the game changes. Only the names and looks shown are swapped, picked from the seed with
  //a separate random stream, so the same seed always shows the same rivals for everyone.
  //Each entry: name, mask art, colour shift (degrees) so masks that share art still look different.
  var PERSONAS = [
    ["Neon Ronin", "ronin", 0], ["Iron Monk", "monk", 0], ["Paper Tiger", "tiger", 0], ["Night Crane", "crane", 0], ["Jade Fox", "kitsune", 0], ["Silent Oni", "oni", 0],
    ["Ash Kitsune", "kitsune", 200], ["Velvet Shogun", "ronin", 300], ["Static Monk", "monk", 160], ["Copper Crane", "crane", 30], ["Hollow Ronin", "ronin", 120],
    ["Rain Tiger", "tiger", 180], ["Ember Oni", "oni", 30], ["Glass Fox", "kitsune", 260], ["Midnight Heron", "crane", 220], ["Cobalt Samurai", "ronin", 200],
    ["Lantern Monk", "monk", 320], ["Golden Tanuki", "kitsune", 50], ["Thunder Kappa", "oni", 120], ["Frost Ninja", "ronin", 170], ["Red Daruma", "monk", 340],
    ["Shadow Tengu", "oni", 260], ["Ivory Tiger", "tiger", 80], ["Obsidian Crane", "crane", 300], ["Moon Kitsune", "kitsune", 140], ["Storm Oni", "oni", 190],
    ["Rust Shogun", "ronin", 20], ["Smoke Daimyo", "ronin", 240], ["Silk Viper", "tiger", 300], ["Ghost Lantern", "monk", 200], ["Willow Sage", "monk", 90],
    ["Koi Ronin", "ronin", 330], ["Dusk Tiger", "tiger", 250], ["Paper Crane", "crane", 140]
  ];
  function rivalNames(names, seed) {
    var r = seeded(((seed >>> 0) ^ 0x9E3779B9) >>> 0), pool = PERSONAS.map(function (p) { return p[0]; });
    shuffle(pool, r);
    return names.map(function (n, i) { return pool[i] || n; });
  }
  function persona(name) {
    var clean = String(name || "").replace(/ \((bot|left)\)$/, "");
    for (var i = 0; i < PERSONAS.length; i++) if (PERSONAS[i][0] === clean) return PERSONAS[i];
    return null;
  }

  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(rnd() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function rint(g, n) { return Math.floor(g.rnd() * n); }

  //MC 2026-10-18 forged matches: opts.decks is one 40-card list per seat. The pool is every deck shuffled together and
  //   each opening hand comes from its owner's cards, mirroring api/engine.php eng_new exactly (the /fair rebuild needs it)
  function drawOwn(g, want) {
    for (var i = g.chaosDeck.length - 1; i >= 0; i--) {
      var id = g.chaosDeck[i];
      if ((want[id] || 0) > 0) { want[id]--; g.chaosDeck.splice(i, 1); return id; }
    }
    return drawChaos(g);
  }
  function newGame(names, humanIndex, rnd, opts) {
    rnd = rnd || Math.random;
    opts = opts || {};
    var decks = opts.decks && opts.decks.length ? opts.decks : null;
    var chaos = [];
    if (decks) decks.forEach(function (list) { (list || []).forEach(function (id) { if (CARDS[id]) chaos.push(id); }); });
    else Object.keys(CARDS).forEach(function (id) { for (var k = 0; k < CARDS[id].n; k++) chaos.push(id); });
    var g = {
      rnd: rnd, round: 1, turn: 0, over: false, log: [], easy: !!opts.easy, plays: 0, played: false, extraTurn: false, noDraw: -1, truce: -1, snap: null, blocks: 0,
      regionDeck: shuffle(REGIONS.slice(), rnd), regionDiscard: [],
      chaosDeck: shuffle(chaos, rnd), chaosDiscard: [],
      players: names.map(function (n, i) { return { name: n, bot: i !== humanIndex, style: (opts.styles && opts.styles[i]) || "", regions: [], hand: [], shield: 0, skip: 0, lone: false, paper: false, harvest: 0 }; })
    };
    g.start = g.turn = Math.floor(rnd() * names.length);
    g.players.forEach(function (p, i) {
      var easyMe = g.easy && i === humanIndex;
      var want = null;
      if (decks) { want = {}; (decks[i] || []).forEach(function (id) { want[id] = (want[id] || 0) + 1; }); }
      for (var k = 0; k < (easyMe ? 3 : 2); k++) p.regions.push(g.regionDeck.pop());
      for (var k2 = 0; k2 < (easyMe ? 6 : 5); k2++) { var c = want ? drawOwn(g, want) : drawChaos(g); if (c) p.hand.push(c); }
    });
    if (decks) g.forged = true;
    return g;
  }

  function say(g, who, text, kind) { g.log.push({ who: who, text: text, kind: kind || "info" }); }
  function plural(n, w) { return n + " " + w + (n === 1 ? "" : "s"); }

  // ---------- decks ----------
  function drawChaos(g) {
    if (!g.chaosDeck.length) {
      if (!g.chaosDiscard.length) return null;
      g.chaosDeck = shuffle(g.chaosDiscard, g.rnd); g.chaosDiscard = [];
    }
    return g.chaosDeck.pop();
  }
  function giveChaos(g, p, k) { var got = 0; for (var i = 0; i < k; i++) { var c = drawChaos(g); if (c) { p.hand.push(c); got++; } } return got; }
  function discardRandom(g, p, k) {
    var n = 0;
    for (var i = 0; i < k && p.hand.length; i++) { g.chaosDiscard.push(p.hand.splice(rint(g, p.hand.length), 1)[0]); n++; }
    return n;
  }
  function discardHand(g, p) { while (p.hand.length) g.chaosDiscard.push(p.hand.pop()); }
  // index of the strongest (or weakest) card in a list; ties go to the earliest
  function bestIndex(list, weakest) {
    var bi = -1, bv = 0;
    list.forEach(function (id, i) { var v = WORTH[id] || 0; if (bi < 0 || (weakest ? v < bv : v > bv)) { bi = i; bv = v; } });
    return bi;
  }
  function gainFromDeck(g, p, k) { var got = 0; for (var i = 0; i < k && g.regionDeck.length; i++) { p.regions.push(g.regionDeck.pop()); got++; } return got; }
  function gainFromDiscard(g, p, k) {
    var got = 0;
    for (var i = 0; i < k && g.regionDiscard.length; i++) { p.regions.push(g.regionDiscard.splice(rint(g, g.regionDiscard.length), 1)[0]); got++; }
    return got;
  }
  function loseRegions(g, p, k) {
    var lost = 0;
    for (var i = 0; i < k && p.regions.length; i++) { g.regionDiscard.push(p.regions.splice(rint(g, p.regions.length), 1)[0]); lost++; }
    return lost;
  }
  function stealRegions(g, from, to, k) {
    var got = 0;
    for (var i = 0; i < k && from.regions.length; i++) { to.regions.push(from.regions.splice(rint(g, from.regions.length), 1)[0]); got++; }
    return got;
  }

  // ---------- who ----------
  function rivalLeader(g, pi) {
    var best = -1, bi = -1;
    g.players.forEach(function (p, i) {
      if (i === pi) return;
      if (p.regions.length > best || (p.regions.length === best && g.rnd() < 0.5)) { best = p.regions.length; bi = i; }
    });
    return bi;
  }
  // most (or fewest) Regions among a set of seats, ties broken at random
  function pickBy(g, seats, fewest) {
    var best = null, ids = [];
    seats.forEach(function (i) {
      var c = g.players[i].regions.length;
      if (best === null || (fewest ? c < best : c > best)) { best = c; ids = [i]; } else if (c === best) ids.push(i);
    });
    return ids.length ? ids[rint(g, ids.length)] : -1;
  }
  function allSeats(g) { return g.players.map(function (_, i) { return i; }); }
  function rivals(g, pi) { return allSeats(g).filter(function (i) { return i !== pi; }); }
  function nextSeat(g, pi) { return (pi + 1) % g.players.length; }

  // ---------- defense ----------
  function walled(p) { return p.shield > 0 || (p.lone && p.regions.length < 3); }
  // a single aimed attack: walls first, then a reaction card from hand. Returns true if it goes through.
  // steal: the attack takes Regions (an Eclipse in hand answers it). pierce: walls don't stop it (Ninja Infiltration).
  function defend(g, attacker, target, steal, pierce) {
    var t = g.players[target];
    if (!pierce && t.shield > 0) { g.blocks++; say(g, target, t.name + "'s defenses hold. Attack blocked.", "block"); return false; }
    if (!pierce && t.lone && t.regions.length < 3) { g.blocks++; say(g, target, t.name + " is a Lone Survivor. Attack blocked.", "block"); return false; }
    if (t.paper) { t.paper = false; g.blocks++; giveChaos(g, t, 1); say(g, target, t.name + "'s Paper Fortress takes the hit and breaks. Attack blocked.", "block"); return false; }
    if (steal) {
      var ec = t.hand.indexOf("eclipse");
      if (ec >= 0) {
        t.hand.splice(ec, 1); g.chaosDiscard.push("eclipse"); g.blocks++; loseRegions(g, g.players[attacker], 1);
        (g.pcx = g.pcx || []).push([target, "eclipse"]); //MC 2026-10-13 a reaction fired from hand counts as a play for its holder (mirrors engine.php)
        say(g, target, t.name + " reveals an Eclipse. " + g.players[attacker].name + " loses a Region instead.", "block"); return false;
      }
    }
    var react = ["assassin", "failedcoup", "decoy"];
    for (var r = 0; r < react.length; r++) {
      var at = t.hand.indexOf(react[r]);
      if (at < 0) continue;
      t.hand.splice(at, 1); g.chaosDiscard.push(react[r]); g.blocks++;
      (g.pcx = g.pcx || []).push([target, react[r]]); //MC 2026-10-13 mirrors engine.php, so solo replays agree move for move
      if (react[r] === "failedcoup") { giveChaos(g, t, 1); say(g, target, t.name + " reveals a Failed Coup. Attack cancelled.", "block"); }
      else if (react[r] === "assassin") { addSkip(g.players[attacker], 1); say(g, target, t.name + " survives a Failed Assassination Attempt. " + g.players[attacker].name + " skips their next turn.", "block"); }
      else say(g, target, t.name + "'s Holographic Decoy takes the hit. Attack cancelled.", "block");
      return false;
    }
    return true;
  }
  // effects that sweep over every rival: only walls (bunkers, domes, Lone Survivor) stop them
  function sweep(g, target) {
    var t = g.players[target];
    if (walled(t)) { g.blocks++; say(g, target, t.name + "'s defenses hold.", "block"); return false; }
    return true;
  }
  function addSkip(p, k) { p.skip = Math.min(3, p.skip + k); }

  // ---------- turns ----------
  function startTurn(g) {
    var p = g.players[g.turn];
    g.plays = 0;
    if (p.shield > 0) p.shield--;
    if (p.lone && p.regions.length >= 3) p.lone = false;
    if (g.noDraw === g.turn) g.noDraw = -1;
    if (g.truce === g.turn) { g.truce = -1; say(g, g.turn, "The truce ends.", "info"); }
    if (p.harvest > 0) { var hv = gainFromDeck(g, p, p.harvest); p.harvest = 0; if (hv) say(g, g.turn, p.name + " brings in the harvest: " + plural(hv, "Region") + ".", "gain"); }
    if (p.skip > 0) {
      p.skip--;
      say(g, g.turn, p.name + " skips this turn.", "skip");
      return { skipped: true };
    }
    if (RULES.claim === "turn" && gainFromDeck(g, p, 1)) say(g, g.turn, p.name + " claims a Region.", "claim");
    g.played = false;
    if (g.noDraw < 0) giveChaos(g, p, 1);
    g.plays = 1;
    return { skipped: false };
  }

  function canPlay(id) { return !!CARDS[id] && CARDS[id].kind !== "passive"; }
  function hasPlayable(p) { for (var i = 0; i < p.hand.length; i++) if (canPlay(p.hand[i])) return true; return false; }
  // after a play, can the same player go again this turn?
  function morePlays(g, pi) { return g.plays > 0 && !g.over && hasPlayable(g.players[pi]); }

  //MC 2026-10-12 False Memory only undoes the last card while the map is still as that card left it (see api/engine.php map_key)
  function mapKey(g) { return g.players.map(function (p) { return p.regions.join(","); }).join("|") + "#" + g.regionDeck.length + "#" + g.regionDiscard.length; }
  function snapOk(g) { return !!g.snap && g.snap.after === mapKey(g); }
  function snapshot(g) {
    return { r: g.players.map(function (p) { return p.regions.slice(); }), deck: g.regionDeck.slice(), disc: g.regionDiscard.slice() };
  }

  function play(g, pi, handIndex, target) {
    var p = g.players[pi], id = p.hand[handIndex], c = CARDS[id];
    if (!c || !canPlay(id) || g.plays <= 0) return false;
    if (c.target === "pick" && (target == null || target === pi || !g.players[target])) return false;
    var before = snapshot(g);
    g.plays--; g.played = true;
    p.hand.splice(handIndex, 1); g.chaosDiscard.push(id);
    if (c.target === "leader") target = rivalLeader(g, pi);
    var t = target != null && target >= 0 ? g.players[target] : null;
    var n, i, q;
    say(g, pi, p.name + " plays " + c.name + (c.target === "pick" && t ? " on " + t.name : "") + ".", "play");
    if (c.kind === "attack" && g.truce >= 0) { say(g, pi, "The truce holds. The attack does nothing.", "block"); g.snap = before; g.snap.after = mapKey(g); return true; }
    switch (id) {
      // -- attacks --
      case "meteor": case "superweapon":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 2); say(g, target, t.name + " loses " + plural(n, "Region") + ".", "hit"); } break;
      case "plasma":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 3); say(g, target, t.name + " loses " + plural(n, "Region") + ".", "hit"); }
        giveChaos(g, p, 2); break;
      case "drone":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 1); say(g, target, t.name + " loses " + plural(n, "Region") + ".", "hit"); } break;
      case "sub":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 1); discardRandom(g, t, 1); say(g, target, t.name + " loses " + plural(n, "Region") + " and a card.", "hit"); } break;
      case "drones":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 1); say(g, target, t.name + " loses " + plural(n, "Region") + ".", "hit"); }
        q = g.players[nextSeat(g, pi)]; if (discardRandom(g, q, 1)) say(g, nextSeat(g, pi), q.name + " discards a card.", "hit"); break;
      case "dictator": case "border": case "coup":
        if (defend(g, pi, target, true)) { n = stealRegions(g, t, p, 1); say(g, pi, p.name + " steals " + plural(n, "Region") + " from " + t.name + ".", "hit"); } break;
      case "empire":
        if (defend(g, pi, target, true)) { n = stealRegions(g, t, p, 2); giveChaos(g, t, 2); say(g, pi, p.name + " steals " + plural(n, "Region") + " from " + t.name + ".", "hit"); } break;
      case "endera":
        if (defend(g, pi, target)) { n = loseRegions(g, t, 2); say(g, target, t.name + " has the most and loses " + plural(n, "Region") + ".", "hit"); } break;
      case "pact":
        if (defend(g, pi, target)) { loseRegions(g, p, 2); loseRegions(g, t, 2); giveChaos(g, p, 3); giveChaos(g, t, 3); say(g, pi, p.name + " and " + t.name + " each lose 2 Regions and draw 3 cards.", "hit"); } break;
      case "censor": case "epidemic": case "newleader":
        if (defend(g, pi, target)) { addSkip(t, 1); say(g, target, t.name + " will skip their next turn.", "hit"); } break;
      case "prophecy":
        if (defend(g, pi, target)) { addSkip(t, 1); say(g, target, t.name + " will skip their next turn.", "hit"); }
        giveChaos(g, p, 2); break;
      case "unicoup":
        rivals(g, pi).forEach(function (r) { if (sweep(g, r)) stealRegions(g, g.players[r], p, 1); });
        say(g, pi, p.name + " takes a Region from every rival they can reach.", "hit"); break;
      case "machines": case "popcontrol":
        rivals(g, pi).forEach(function (r) { if (sweep(g, r)) loseRegions(g, g.players[r], 1); });
        say(g, pi, "Every rival in reach loses a Region.", "hit"); break;
      // -- gains --
      case "atlantis": n = gainFromDeck(g, p, 2); say(g, pi, p.name + " gains " + plural(n, "Region") + ".", "gain"); break;
      case "surge": n = gainFromDeck(g, p, 1); giveChaos(g, p, 1); say(g, pi, p.name + " gains " + plural(n, "Region") + " and a card.", "gain"); break;
      case "resource": n = gainFromDeck(g, p, 1); giveChaos(g, p, 3); say(g, pi, p.name + " gains " + plural(n, "Region") + " and 3 cards.", "gain"); break;
      case "space": n = gainFromDiscard(g, p, 1) || gainFromDeck(g, p, 1); say(g, pi, p.name + " gains " + plural(n, "Region") + ".", "gain"); break;
      case "solar": n = gainFromDeck(g, p, 2); addSkip(p, 1); say(g, pi, p.name + " gains " + plural(n, "Region") + " and rests a turn.", "gain"); break;
      case "era": n = gainFromDeck(g, p, 3); addSkip(p, 1); say(g, pi, p.name + " begins an Era of Expansion and gains " + plural(n, "Region") + ".", "gain"); break;
      case "reinforce": n = gainFromDeck(g, p, 2); giveChaos(g, p, 2); say(g, pi, p.name + " gains " + plural(n, "Region") + " and 2 cards.", "gain"); break;
      case "prophecyful": n = gainFromDeck(g, p, 1); giveChaos(g, p, 1); say(g, pi, p.name + " gains " + plural(n, "Region") + " and a card.", "gain"); break;
      case "galactic":
        n = gainFromDeck(g, p, 2); i = pickBy(g, allSeats(g), true); gainFromDeck(g, g.players[i], 1);
        say(g, pi, p.name + " gains " + plural(n, "Region") + ", and " + g.players[i].name + " gains 1.", "gain"); break;
      case "galconsp":
        n = gainFromDeck(g, p, 2); i = pickBy(g, rivals(g, pi), false); if (sweep(g, i)) loseRegions(g, g.players[i], 1);
        say(g, pi, p.name + " gains " + plural(n, "Region") + " and the leader loses one.", "gain"); break;
      case "tunnels": n = gainFromDiscard(g, p, 1) || gainFromDeck(g, p, 1); say(g, pi, p.name + " tunnels into " + plural(n, "Region") + ".", "gain"); break;
      case "summit": n = gainFromDeck(g, p, 1); addSkip(p, 1); say(g, pi, p.name + " gains " + plural(n, "Region") + " and rests a turn.", "gain"); break;
      case "underworld":
        for (i = 0; i < 3 && g.regionDiscard.length; i++) { n = pickBy(g, allSeats(g), true); gainFromDiscard(g, g.players[n], 1); }
        say(g, pi, "The underworld rises. The players with the fewest Regions take back the lost land.", "gain"); break;
      case "rekindled":
        var lows = allSeats(g).sort(function (a, b) { return g.players[a].regions.length - g.players[b].regions.length || a - b; }).slice(0, 2);
        lows.forEach(function (k) { gainFromDiscard(g, g.players[k], 1); });
        say(g, pi, "Hope returns to the two smallest nations.", "gain"); break;
      case "secretgov":
        n = gainFromDeck(g, p, 1);
        var top = []; for (i = 0; i < 5 && g.chaosDeck.length; i++) top.push(g.chaosDeck.pop());
        if (top.length) { i = bestIndex(top); p.hand.push(top.splice(i, 1)[0]); while (top.length) g.chaosDeck.push(top.pop()); }
        say(g, pi, p.name + " gains " + plural(n, "Region") + " and a hand-picked card.", "gain"); break;
      case "awakening":
        n = gainFromDeck(g, p, 1); rivals(g, pi).forEach(function (r) { addSkip(g.players[r], 1); });
        say(g, pi, p.name + " gains " + plural(n, "Region") + ". Everyone else skips their next turn.", "gain"); break;
      // -- defense --
      case "bunker": p.shield = Math.max(p.shield, 2); say(g, pi, p.name + " is safe in a bunker for 2 rounds.", "gain"); break;
      case "irondome": case "stronghold": p.shield = Math.max(p.shield, 3); say(g, pi, p.name + " is protected for 3 rounds.", "gain"); break;
      case "lone": p.lone = true; say(g, pi, p.name + " can't be attacked until they hold 3 Regions.", "gain"); break;
      case "coop":
        n = pickBy(g, rivals(g, pi), true); p.shield = Math.max(p.shield, 2); g.players[n].shield = Math.max(g.players[n].shield, 2);
        say(g, pi, p.name + " and " + g.players[n].name + " are protected for 2 rounds.", "gain"); break;
      // -- everyone --
      case "boom": g.players.forEach(function (x) { gainFromDeck(g, x, 1); }); say(g, pi, "Everyone draws a Region.", "gain"); break;
      case "forgotten": n = pickBy(g, allSeats(g), true); i = gainFromDeck(g, g.players[n], 4); say(g, n, g.players[n].name + " has the fewest and draws " + plural(i, "Region") + ".", "gain"); break;
      case "overthrow":
        n = pickBy(g, allSeats(g), true); i = gainFromDiscard(g, g.players[n], 2);
        say(g, n, g.players[n].name + (i ? " rises up and gains " + plural(i, "Region") + "." : " rises up, but there's nothing left to take back."), "gain"); break;
      case "resistance": g.players.forEach(function (x) { if (x.regions.length < 3) gainFromDeck(g, x, 1); }); say(g, pi, "Anyone under 3 Regions gains one.", "gain"); break;
      case "taxation":
        g.players.forEach(function (x) { if (x.regions.length >= 3) loseRegions(g, x, 1); else gainFromDeck(g, x, 1); });
        say(g, pi, "Taxes: the rich pay a Region, the poor get one.", "hit"); break;
      case "audit":
        g.players.forEach(function (x, k) { if (x.regions.length >= 7 && sweep(g, k)) { loseRegions(g, x, 3); say(g, k, x.name + " is audited and loses 3 Regions.", "hit"); } });
        say(g, pi, "The audit is done.", "info"); break;
      case "rebellion": n = pickBy(g, allSeats(g), false); loseRegions(g, g.players[n], 2); say(g, n, g.players[n].name + " has the most and loses 2 Regions.", "hit"); break;
      case "zombie": case "negotiations": case "locusts":
        g.players.forEach(function (x) { loseRegions(g, x, 1); }); say(g, pi, "Everyone loses a Region.", "hit"); break;
      case "plague": case "flood":
        g.players.forEach(function (x) { if (x.regions.length >= 2) loseRegions(g, x, 1); }); say(g, pi, "Everyone with 2 or more loses a Region.", "hit"); break;
      case "ww3": g.players.forEach(function (x) { if (x.regions.length >= 3) loseRegions(g, x, 2); }); say(g, pi, "Everyone with 3 or more loses 2 Regions.", "hit"); break;
      case "mutiny": case "alien":
        g.players.forEach(function (x) { loseRegions(g, x, 1); discardRandom(g, x, 1); });
        say(g, pi, "Everyone loses a Region and a Chaos card.", "hit"); break;
      case "nuclear":
        var at = pi;
        for (var k = 0; k < g.players.length; k++) {
          at = nextSeat(g, at);
          var v = g.players[at];
          if (!v.regions.length) { say(g, at, v.name + " has nothing left to lose. The chain reaction stops.", "info"); break; }
          loseRegions(g, v, 1);
          say(g, at, v.name + " loses a Region in the blast.", "hit");
        }
        break;
      case "famine":
        g.players.forEach(function (x) { if (x.regions.length) loseRegions(g, x, 1); else addSkip(x, 1); });
        say(g, pi, "Famine spreads. Everyone loses a Region, and anyone with none skips their next turn.", "hit"); break;
      case "extinction":
        for (i = 0; i < 5; i++) {
          var owners = []; g.players.forEach(function (x, k) { for (var r = 0; r < x.regions.length; r++) owners.push(k); });
          if (!owners.length) break;
          loseRegions(g, g.players[owners[rint(g, owners.length)]], 1);
        }
        say(g, pi, "Extinction: 5 Regions are wiped off the map.", "hit"); break;
      case "winter": rivals(g, pi).forEach(function (r) { addSkip(g.players[r], 1); }); say(g, pi, "Eternal Winter. Everyone else skips their next turn.", "skip"); break;
      case "renaissance": g.players.forEach(function (x) { giveChaos(g, x, 1); }); say(g, pi, "Everyone draws a Chaos card.", "gain"); break;
      case "blackhole": case "anarchy":
        g.players.forEach(function (x) { discardHand(g, x); });
        g.players.forEach(function (x) { giveChaos(g, x, id === "blackhole" ? 5 : 4); });
        say(g, pi, "Every hand is thrown away and redrawn.", "info"); break;
      case "cern":
        var hands = g.players.map(function (x) { return x.hand; });
        g.players.forEach(function (x, k) { x.hand = hands[(k - 1 + hands.length) % hands.length]; });
        say(g, pi, "Every hand moves one seat to the left.", "info"); break;
      // -- tricks --
      case "double": g.plays += 1; say(g, pi, p.name + " may play another card.", "info"); break;
      case "blitz": g.plays += 2; say(g, pi, p.name + " may play 2 more cards.", "info"); break;
      case "gravity":
        for (i = 0; i < 5 && g.chaosDeck.length; i++) g.chaosDiscard.push(g.chaosDeck.pop());
        g.extraTurn = true; say(g, pi, p.name + " will take another turn.", "info"); break;
      case "madsci":
        n = 0; for (i = 0; i < 2 && g.chaosDiscard.length > 1; i++) { p.hand.push(g.chaosDiscard.splice(rint(g, g.chaosDiscard.length - 1), 1)[0]); n++; }
        if (n < 2) giveChaos(g, p, 2 - n);
        say(g, pi, p.name + " pulls 2 cards from the discard pile.", "gain"); break;
      case "superai": case "neural":
        var look = []; for (i = 0; i < 10 && g.chaosDeck.length; i++) look.push(g.chaosDeck.pop());
        for (i = 0; i < (id === "superai" ? 3 : 2) && look.length; i++) p.hand.push(look.splice(bestIndex(look), 1)[0]);
        g.chaosDeck = g.chaosDeck.concat(shuffle(look, g.rnd));
        say(g, pi, p.name + " studies the deck and keeps the best cards.", "gain"); break;
      case "pandora":
        giveChaos(g, p, 5);
        for (i = 0; i < 3 && p.hand.length; i++) g.chaosDiscard.push(p.hand.splice(bestIndex(p.hand, true), 1)[0]);
        say(g, pi, p.name + " opens Pandora's Box.", "gain"); break;
      case "conspiracy":
        rivals(g, pi).forEach(function (r) { var h = g.players[r].hand; if (h.length) g.chaosDiscard.push(h.splice(bestIndex(h), 1)[0]); });
        say(g, pi, "Every rival loses their best card.", "hit"); break;
      case "currency":
        rivals(g, pi).forEach(function (r) { discardRandom(g, g.players[r], 2); }); giveChaos(g, p, 2);
        say(g, pi, "Every rival discards 2 cards and " + p.name + " draws 2.", "hit"); break;
      case "netcrash": g.noDraw = pi; say(g, pi, "The internet is down. No one draws on their turn until " + p.name + " plays again.", "info"); break;
      case "tides":
        q = g.players[nextSeat(g, pi)]; n = p.hand; p.hand = q.hand; q.hand = n;
        say(g, pi, p.name + " trades hands with " + q.name + ".", "info"); break;
      case "quantum": n = p.hand; p.hand = t.hand; t.hand = n; say(g, pi, p.name + " swaps hands with " + t.name + ".", "info"); break;
      // -- season cards --
      case "kamikaze":
        g.players.forEach(function (x, k) { discardRandom(g, x, 1); });
        n = gainFromDeck(g, p, 2); say(g, pi, p.name + " calls a divine wind that scatters every hand, and gains " + plural(n, "Region") + ".", "gain"); break;
      case "decree":
        var fewest = g.players.every(function (x, k) { return k === pi || p.regions.length <= x.regions.length; });
        if (defend(g, pi, target, true)) { n = stealRegions(g, t, p, fewest ? 2 : 1); say(g, pi, p.name + " decrees it and takes " + plural(n, "Region") + " from " + t.name + ".", "hit"); } break;
      case "ninja":
        if (defend(g, pi, target, true, true)) { n = stealRegions(g, t, p, 1); say(g, pi, p.name + " slips past the walls and steals " + plural(n, "Region") + " from " + t.name + ".", "hit"); } break;
      case "paper": p.paper = true; say(g, pi, p.name + " raises a Paper Fortress. It blocks the next attack.", "gain"); break;
      case "harvest":
        n = gainFromDeck(g, p, 1); p.harvest += 1; say(g, pi, p.name + " gains " + plural(n, "Region") + ". More comes in next turn.", "gain"); break;
      case "ronin":
        if (t.hand.length) { p.hand.push(t.hand.splice(rint(g, t.hand.length), 1)[0]); say(g, pi, p.name + " hires a ronin and takes a card from " + t.name + ".", "hit"); }
        else say(g, pi, t.name + " has no cards to take.", "info");
        break;
      case "truce": g.truce = pi; giveChaos(g, p, 1); say(g, pi, "A truce is called. No one can attack until " + p.name + "'s next turn.", "info"); break;
      case "falsememory":
        if (snapOk(g)) {
          var s = g.snap;
          g.players.forEach(function (x, k) { x.regions = s.r[k].slice(); });
          g.regionDeck = s.deck.slice(); g.regionDiscard = s.disc.slice();
          say(g, pi, "Memories rewritten. The last card's effect on the map is undone.", "info");
        } else say(g, pi, "There's nothing to undo yet.", "info");
        break;
    }
    g.snap = before; g.snap.after = mapKey(g);
    return true;
  }

  function endTurn(g) {
    // a turn spent building instead of playing claims a Region
    if (RULES.claim === "pass" && g.plays > 0 && !g.played && gainFromDeck(g, g.players[g.turn], 1)) say(g, g.turn, g.players[g.turn].name + " claims a Region.", "claim");
    g.plays = 0;
    var top = 0; g.players.forEach(function (p) { if (p.regions.length > top) top = p.regions.length; });
    if (!g.regionDeck.length || top >= WIN_AT) { g.over = true; return true; }
    if (g.extraTurn) { g.extraTurn = false; return false; }
    g.turn = nextSeat(g, g.turn);
    if (g.turn === g.start) {
      if (g.round >= MAX_ROUNDS) { g.over = true; return true; }
      g.round++;
    }
    return false;
  }

  function standings(g) {
    return g.players.map(function (p, i) { return { i: i, name: p.name, regions: p.regions.length, hand: p.hand.length }; })
      .sort(function (a, b) { return b.regions - a.regions || b.hand - a.hand; });
  }
  function winners(g) {
    var s = standings(g), top = s[0];
    return s.filter(function (x) { return x.regions === top.regions && x.hand === top.hand; }).map(function (x) { return x.i; });
  }

  // ---------- bots ----------
  // How much a bot likes playing a card right now. Higher is better; nothing under 0.5 gets played.
  function botChoose(g, pi, noiseOverride) {
    var noise = noiseOverride != null ? noiseOverride : (g.easy ? 3.5 : 0.6);
    var p = g.players[pi], best = null, bestScore = RULES.claim === "pass" && !g.played && g.regionDeck.length ? (RULES.passWorth || PASS_WORTH) : 0.5;
    var mine = p.regions.length, others = rivals(g, pi);
    var counts = g.players.map(function (x) { return x.regions.length; });
    var top = Math.max.apply(null, others.map(function (i) { return counts[i]; }));
    var low = Math.min.apply(null, counts);
    var avg = others.reduce(function (a, i) { return a + counts[i]; }, 0) / others.length;
    var lead = mine - avg;                       // positive when I'm ahead
    var leader = rivalLeader(g, pi);
    var deckLeft = g.regionDeck.length;
    var endNear = deckLeft <= 6 || top >= WIN_AT - 3;
    function openRival() {
      var bi = -1, bv = -1;
      others.forEach(function (i) {
        var q = g.players[i];
        if (walled(q)) return;
        var v = g.easy && noiseOverride == null ? g.rnd() * 10 : counts[i] + (noise ? g.rnd() * 0.5 : 0);
        if (v > bv) { bv = v; bi = i; }
      });
      return bi;
    }
    var reach = others.filter(function (i) { return !walled(g.players[i]); });
    var reachRegions = reach.reduce(function (a, i) { return a + Math.min(1, counts[i]); }, 0);
    p.hand.forEach(function (id, h) {
      var c = CARDS[id], s = 0, t = null;
      if (!canPlay(id)) return;
      if (c.kind === "attack" && g.truce >= 0) return;     // a truce makes every attack a wasted card
      if (id === "ninja" || id === "ronin") {
        // Ninja ignores walls, so aim at the biggest rival; Ronin takes from the fullest hand
        var bi2 = -1, bv2 = -1;
        others.forEach(function (i) { var v = (id === "ninja" ? counts[i] : g.players[i].hand.length) + (noise ? g.rnd() * 0.5 : 0); if (v > bv2) { bv2 = v; bi2 = i; } });
        t = bi2;
        if (t < 0) return;
        s = id === "ninja" ? (counts[t] ? 1.5 + 2 * 1.1 + counts[t] * 0.35 + (walled(g.players[t]) ? 0.8 : 0) : 0.1) : (g.players[t].hand.length ? 1.6 + Math.min(4, g.players[t].hand.length) * 0.15 : 0);
      } else if (c.target === "pick" || c.target === "leader") {
        t = c.target === "pick" ? openRival() : leader;
        if (t == null || t < 0) return;
        var tc = counts[t], open = !walled(g.players[t]);
        if (id === "censor" || id === "epidemic" || id === "newleader" || id === "prophecy") s = open ? 1.4 + tc * 0.3 + (id === "prophecy" ? 1.6 : 0) : (id === "prophecy" ? 1.6 : 0.1);
        else if (id === "pact") s = open && tc >= mine ? 1 + (tc - mine) * 0.5 : 0;
        else if (id === "quantum") s = g.players[t].hand.length - p.hand.length > 1 ? 1.5 : 0;
        else {
          var hit = { meteor: 2, superweapon: 2, plasma: 3, drone: 1, sub: 1.3, drones: 1.3, dictator: 2, border: 2, coup: 2, empire: 4.5, endera: 2, decree: mine <= low ? 4 : 2 }[id] || 1;
          s = open && tc ? (1.5 + hit * 1.1 + tc * 0.35) * STYLE.attackScale + (t === leader && counts[t] >= top ? STYLE.leaderBonus : 0) : (id === "plasma" ? 1.2 : 0.1);
        }
      } else if (id === "unicoup") s = reachRegions * 1.6;
      else if (id === "machines" || id === "popcontrol") s = reachRegions * 0.9 + (lead < 0 ? 0.8 : 0);
      else if (c.kind === "gain") {
        var amt = { atlantis: 2, surge: 1.3, resource: 1.8, space: 1, solar: 2, era: 3, secretgov: 1.5, awakening: 2.6, reinforce: 2.6, prophecyful: 1.3, galactic: 1.8, galconsp: 2.4, tunnels: 1, summit: 1, harvest: 1.8 }[id];
        s = deckLeft || id === "space" ? 1.8 + amt * 1.3 : 0.3;
        if (id === "solar" || id === "summit") s -= 1.4;
        if ((id === "space" || id === "tunnels") && !g.regionDiscard.length && !deckLeft) s = 0.3;
        if (id === "era") s -= 1.4;
      } else if (c.kind === "defense") {
        var exposed = mine + (lead > 0 ? 3 : 0);
        if (id === "lone") s = mine < 3 && !p.lone ? 2.5 : 0;
        else if (id === "paper") s = p.paper || p.shield > 0 ? 0 : 0.8 + exposed * 0.35;
        else s = p.shield > 0 ? 0 : 0.6 + exposed * 0.35 + (id === "coop" ? 0.3 : 0) + (id === "bunker" ? 0 : 0.4);
      } else if (c.kind === "global") {
        var behind = -lead;   // symmetric losses help whoever is behind
        switch (id) {
          case "boom": s = 1.6; break;
          case "underworld": case "rekindled": s = g.regionDiscard.length ? (mine === low ? 3.2 : 0.8) : 0.2; break;
          case "forgotten": s = mine === low ? 5 : 0.2; break;
          case "overthrow": s = mine === low && g.regionDiscard.length ? 3.5 : 0.2; break;
          case "resistance": s = mine < 3 ? 3 : 0.3; break;
          case "taxation": s = mine < 3 ? 2 + behind * 0.4 : 0.6 + behind * 0.4; break;
          case "audit": s = mine < 7 && top >= 7 ? 2 + (top - 7) * 0.5 : (top >= 7 ? -3 : 0); break;
          case "rebellion": s = mine < top ? 3 : -4; break;
          case "zombie": case "negotiations": case "locusts": case "mutiny": case "alien": case "famine":
            s = 1 + behind * 0.6; break;
          case "plague": case "flood": s = mine < 2 ? 3 : 1 + behind * 0.5; break;
          case "ww3": s = mine < 3 ? 3 + (top >= 3 ? 1 : 0) : 0.6 + behind * 0.5; break;
          case "nuclear": s = counts[nextSeat(g, pi)] ? 1.2 + behind * 0.5 : 0.2; break;
          case "extinction": s = 0.8 + behind * 0.5; break;
          case "winter": s = 4.5; break;
          case "renaissance": s = 1; break;
          case "blackhole": case "anarchy": s = p.hand.length <= 3 ? 1.8 : 0.4; break;
          case "cern": s = g.players[(pi - 1 + counts.length) % counts.length].hand.length - p.hand.length >= 2 ? 1.5 : 0.2; break;
          case "kamikaze": s = deckLeft ? 4 - (p.hand.length <= 2 ? 0.8 : 0) : 0.3; break;
          case "truce": s = 1 + Math.max(0, lead) * 0.5 - (p.hand.some(function (x) { return CARDS[x] && CARDS[x].kind === "attack"; }) ? 0.8 : 0); break;
        }
      } else if (c.kind === "trick") {
        var playable = p.hand.filter(function (x, k) { return k !== h && canPlay(x); }).length;
        switch (id) {
          case "double": s = playable >= 1 ? 2.6 : 0; break;
          case "blitz": s = playable >= 2 ? 3.6 : (playable ? 1.5 : 0); break;
          case "gravity": s = 3; break;
          case "madsci": s = 1.8; break;
          case "superai": s = 3.2; break;
          case "neural": s = 2.6; break;
          case "pandora": s = 2.2; break;
          case "conspiracy": s = 2.4; break;
          case "currency": s = 2.4; break;
          case "netcrash": s = 1; break;
          case "tides": s = g.players[nextSeat(g, pi)].hand.length - p.hand.length >= 2 ? 1.5 : 0.2; break;
          case "falsememory":
            if (!snapOk(g)) { s = 0; break; }
            var was = g.snap.r[pi].length, nowGap = (was - mine), rivalGain = 0;
            others.forEach(function (i) { rivalGain += counts[i] - g.snap.r[i].length; });
            s = 0.5 + nowGap * 1.5 + rivalGain * 0.8; break;
        }
      }
      // rival personalities (never applied to hints)
      if (noiseOverride == null && p.style) {
        if (p.style === "hawk") { if (c.kind === "attack" && s > 0.5) s += STYLE.hawkAttack; if (c.kind === "gain") s -= STYLE.hawkGain; }
        else if (p.style === "builder") { if (c.kind === "gain") s += STYLE.buildGain; if (c.kind === "defense" && p.shield <= 0) s += STYLE.buildDefense; if (c.kind === "attack") s -= STYLE.buildAttack; }
        else if (p.style === "wild") s += g.rnd() * STYLE.wild;
      }
      s += noise ? g.rnd() * noise : 0;
      if (s > bestScore) { bestScore = s; best = { hand: h, target: t }; }
    });
    return best;
  }
  // a whole bot turn after startTurn: keep playing while the turn allows it
  function botTurn(g, pi, noise) {
    var guard = 0;
    while (g.plays > 0 && !g.over && guard++ < 8) {
      var ch = botChoose(g, pi, noise);
      if (!ch) break;
      play(g, pi, ch.hand, ch.target);
    }
  }

  // ---------- look-ahead hints ----------
  // Copy the game, hiding what the player can't know: rival hands and both decks get reshuffled.
  function determinize(g, pi, rnd) {
    var c = JSON.parse(JSON.stringify({ round: g.round, turn: g.turn, start: g.start, easy: g.easy, plays: g.plays, played: g.played, extraTurn: g.extraTurn, noDraw: g.noDraw, truce: g.truce == null ? -1 : g.truce,
      snap: g.snap, blocks: 0, regionDeck: g.regionDeck, regionDiscard: g.regionDiscard, chaosDeck: g.chaosDeck, chaosDiscard: g.chaosDiscard, players: g.players }));
    c.rnd = rnd; c.log = []; c.over = false;
    var pool = c.chaosDeck.slice(), sizes = [];
    c.players.forEach(function (p, i) { sizes[i] = p.hand.length; if (i !== pi) { pool = pool.concat(p.hand); p.hand = []; } });
    shuffle(pool, rnd);
    c.players.forEach(function (p, i) { if (i !== pi) for (var k = 0; k < sizes[i]; k++) p.hand.push(pool.pop()); });
    c.chaosDeck = pool;
    shuffle(c.regionDeck, rnd);
    return c;
  }
  function finishOut(c) {
    var guard = 0;
    while (!c.over && guard++ < 200) {
      var r = startTurn(c);
      if (!r.skipped) botTurn(c, c.turn);
      endTurn(c);
    }
  }
  function value(c, pi) {
    var w = winners(c), mine = c.players[pi].regions.length;
    return (w.indexOf(pi) >= 0 ? (w.length > 1 ? 50 : 100) : 0) + mine * 5;
  }
  // Every legal option for the player whose turn it is, including passing.
  function options(g, pi) {
    var out = [{ hand: -1, target: null }], seen = {};
    g.players[pi].hand.forEach(function (id, h) {
      if (!canPlay(id) || seen[id]) return;
      seen[id] = 1;
      if (CARDS[id].target === "pick") g.players.forEach(function (q, t) { if (t !== pi) out.push({ hand: h, target: t }); });
      else out.push({ hand: h, target: null });
    });
    return out;
  }
  // Plays each option forward many times and returns the one that scores best on average.
  // Runs one playout per option in turn, so a slow phone that hits the time budget still has a fair sample of each.
  function suggest(g, pi, sims, budgetMs) {
    sims = sims || 30;
    var opts = options(g, pi), best = null, bestV = -1, rnd = Math.random;
    var now = typeof performance !== "undefined" && performance.now ? function () { return performance.now(); } : Date.now;
    var t0 = now(), budget = budgetMs || 0, minSims = Math.min(sims, 8), done = 0;
    opts.forEach(function (o) { o.total = 0; });
    for (var k = 0; k < sims; k++) {
      opts.forEach(function (o) {
        var c = determinize(g, pi, rnd);
        if (o.hand >= 0) { play(c, pi, o.hand, o.target); botTurn(c, pi, 0); }
        endTurn(c);
        finishOut(c);
        o.total += value(c, pi);
      });
      done = k + 1;
      if (budget && done >= minSims && now() - t0 > budget) break;
    }
    opts.forEach(function (o) {
      o.value = o.total / done; delete o.total;
      if (o.value > bestV) { bestV = o.value; best = o; }
    });
    return best && best.hand >= 0 ? best : null;
  }

  var api = { DECK: DECK, RULES: RULES, STYLE: STYLE, setDeck: setDeck, useSeason: useSeason, season: function () { return SEASON.slice(); }, seeded: seeded, setupRivals: setupRivals, rivalNames: rivalNames, persona: persona, PERSONAS: PERSONAS, BOTS: BOTS, suggest: suggest, REGIONS: REGIONS, CARDS: CARDS, WIN_AT: WIN_AT, MAX_ROUNDS: MAX_ROUNDS, newGame: newGame,
    startTurn: startTurn, play: play, endTurn: endTurn, canPlay: canPlay, hasPlayable: hasPlayable, morePlays: morePlays, botChoose: botChoose, botTurn: botTurn,
    standings: standings, winners: winners };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ShyGame = api;
})(this);
