// $SHY market data on the token page and the home hero: the live card, price charts, the what-if calculator
// and the supply ring. Data comes from api/market.php (cached on the server); charts are plain SVG, drawn once
// per data load, and hovering only moves two elements, so nothing reflows while the pointer moves.
(function () {
  "use strict";
  var $ = function (id) { return document.getElementById(id); };
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var PAIR_ADDR = "FkXXLYB169GkEMTx3r6zJ4MXFFu29AY9w9cyj77hHVhb";
  var FALLBACK_SUPPLY = 499800000;
  var pair = null, cache = {};

  // ---------- formatting ----------
  function usd(n) {
    n = Number(n); if (!isFinite(n)) return "--";
    var a = Math.abs(n);
    if (a >= 1e9) return "$" + (n / 1e9).toFixed(a >= 1e10 ? 1 : 2).replace(/\.0+$/, "") + "B";
    if (a >= 1e6) return "$" + (n / 1e6).toFixed(a >= 1e7 ? 1 : 2).replace(/\.0+$/, "") + "M";
    if (a >= 1000) return "$" + Math.round(n).toLocaleString("en-US");
    if (a >= 1) return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (a === 0) return "$0";
    return "$" + n.toPrecision(3);
  }
  function capFmt(n) { return n >= 1e9 ? "$" + (n / 1e9).toFixed(n >= 1e10 ? 0 : 1).replace(/\.0$/, "") + "B" : n >= 1e6 ? "$" + (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, "") + "M" : "$" + Math.round(n / 1e3) + "K"; }
  function px(n) { n = Number(n); if (!isFinite(n) || n <= 0) return "--"; return n >= 1 ? "$" + n.toFixed(4) : "$" + n.toPrecision(4); }
  function num(n) { return Math.round(n).toLocaleString("en-US"); }
  function pct(a, b) { return b ? (a / b - 1) * 100 : 0; }
  function dateOf(t, withTime) {
    var L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined, d = new Date(t * 1000);   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
    try { return d.toLocaleString(L, withTime ? { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" } : { month: "short", day: "numeric", year: "numeric" }); } catch (e) { return d.toDateString(); }
  }

  // ---------- data ----------
  function get(q) {
    if (cache[q]) return cache[q];
    cache[q] = fetch("api/market.php?" + q).then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error(j.error); return j; });
    cache[q].catch(function () { delete cache[q]; });
    return cache[q];
  }
  function candles(tf, n) { return get("a=candles&tf=" + tf + (n ? "&n=" + n : "")).then(function (j) { return j.c; }); }   //MC 2026-10-18 n: the sparks only need the last few days, not 1,000 rows

  // ---------- an area chart in SVG ----------
  var uid = 0;
  function chart(box, rows, opt) {
    opt = opt || {};
    if (!box || !rows || rows.length < 2) return null;
    var W = Math.max(200, box.clientWidth), H = opt.h || Math.max(120, box.clientHeight || 160), pad = opt.pad || 6, id = "mg" + (++uid);
    var lo = Infinity, hi = -Infinity;
    rows.forEach(function (r) { if (r[1] < lo) lo = r[1]; if (r[1] > hi) hi = r[1]; });
    var span = hi - lo || hi * 0.01 || 1;
    // x follows time, not candle count: quiet hours with no trades don't get squeezed out
    var t0 = rows[0][0], tN = rows[rows.length - 1][0], tS = tN - t0 || 1;
    var x = function (i) { return pad + (W - pad * 2) * (rows[i][0] - t0) / tS; };
    var y = function (v) { return pad + (H - pad * 2) * (1 - (v - lo) / span); };
    var d = rows.map(function (r, i) { return (i ? "L" : "M") + x(i).toFixed(1) + " " + y(r[1]).toFixed(1); }).join("");
    var up = rows[rows.length - 1][1] >= rows[0][1];
    var col = opt.color || (up ? "#2ef0b0" : "#ff5d73");
    var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" preserveAspectRatio="none" aria-hidden="true">' +
      '<defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + col + '" stop-opacity=".38"/><stop offset="1" stop-color="' + col + '" stop-opacity="0"/></linearGradient></defs>' +
      '<path d="' + d + 'L' + x(rows.length - 1).toFixed(1) + ' ' + H + 'L' + pad + ' ' + H + 'Z" fill="url(#' + id + ')"/>' +
      '<path class="mk-line" d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + (opt.stroke || 2) + '" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>' +
      (opt.hover ? '<line class="mk-x" x1="0" x2="0" y1="0" y2="' + H + '" stroke="rgba(255,255,255,.35)" stroke-dasharray="3 4" visibility="hidden"/><circle class="mk-dot" r="5" fill="' + col + '" stroke="#150f2e" stroke-width="2" visibility="hidden"/>' : "") +
      (opt.endDot ? '<circle cx="' + x(rows.length - 1).toFixed(1) + '" cy="' + y(rows[rows.length - 1][1]).toFixed(1) + '" r="3.5" fill="' + col + '" class="mk-end"/>' : "") + '</svg>';
    box.innerHTML = svg;
    var s = box.querySelector("svg");
    if (!reduce) { var ln = s.querySelector(".mk-line"); try { var L = ln.getTotalLength(); ln.style.strokeDasharray = L; ln.style.strokeDashoffset = L; ln.getBoundingClientRect(); ln.style.transition = "stroke-dashoffset 1.1s cubic-bezier(.2,.8,.2,1)"; ln.style.strokeDashoffset = "0"; } catch (e) {} }
    var api = { lo: lo, hi: hi, up: up, rows: rows };
    if (opt.hover) {
      var xl = s.querySelector(".mk-x"), dot = s.querySelector(".mk-dot"), tip = opt.tip, raf = 0, last = -1;
      var move = function (cx) {
        var r = s.getBoundingClientRect(), f = (cx - r.left) / r.width, want = t0 + Math.max(0, Math.min(1, f)) * tS, lo2 = 0, hi2 = rows.length - 1;
        while (hi2 - lo2 > 1) { var mid = (lo2 + hi2) >> 1; if (rows[mid][0] < want) lo2 = mid; else hi2 = mid; }
        var i = want - rows[lo2][0] < rows[hi2][0] - want ? lo2 : hi2;
        if (i === last) return; last = i;
        var X = x(i), Y = y(rows[i][1]);
        xl.setAttribute("x1", X); xl.setAttribute("x2", X); dot.setAttribute("cx", X); dot.setAttribute("cy", Y);
        xl.setAttribute("visibility", "visible"); dot.setAttribute("visibility", "visible");
        if (tip) { tip.hidden = false; tip.innerHTML = '<b>' + px(rows[i][1]) + '</b><span data-i18n-skip>' + dateOf(rows[i][0], opt.time) + '</span>'; tip.style.transform = "translateX(" + Math.max(0, Math.min(r.width - tip.offsetWidth, X / W * r.width - tip.offsetWidth / 2)).toFixed(0) + "px)"; }
      };
      var hide = function () { last = -1; xl.setAttribute("visibility", "hidden"); dot.setAttribute("visibility", "hidden"); if (tip) tip.hidden = true; };
      s.addEventListener("pointermove", function (e) { var cx = e.clientX; cancelAnimationFrame(raf); raf = requestAnimationFrame(function () { move(cx); }); });
      s.addEventListener("pointerleave", hide);
      s.addEventListener("pointerdown", function (e) { move(e.clientX); });
    }
    return api;
  }
  function closes(rows, since) {
    var out = rows.filter(function (r) { return !since || r[0] >= since; }).map(function (r) { return [r[0], r[4]]; });
    // a quiet stretch at the start of the window still begins at the price it had then
    if (since) { var before = null; rows.forEach(function (r) { if (r[0] < since) before = r; }); if (before && (!out.length || out[0][0] > since)) out.unshift([since, before[4]]); }
    // the line ends at the live price, right now
    if (pair && out.length) { var nowT = Math.floor(Date.now() / 1000); if (nowT > out[out.length - 1][0]) out.push([nowT, pair.price]); }
    return out;
  }

  // ---------- the live numbers ----------
  function setStat(k, v, cls) {
    document.querySelectorAll('[data-stat="' + k + '"]').forEach(function (el) { el.textContent = v; el.classList.remove("up", "down"); if (cls) el.classList.add(cls); });
  }
  function loadPair() {
    return get("a=pair").then(function (j) {
      pair = j.pair;
      var ch = pair.change;
      setStat("price", px(pair.price));
      setStat("change", (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%", ch >= 0 ? "up" : "down");
      setStat("mcap", usd(pair.mcap)); setStat("liq", usd(pair.liq)); setStat("vol", usd(pair.vol));
      var fl = $("tk-flow"), tot = pair.buys + pair.sells;
      if (fl && tot > 0) {
        //MC 2026-10-11 the row keeps its space while it waits (.tk-wait), it used to appear and push the card 37 px taller
        fl.hidden = false; fl.classList.remove("tk-wait");
        $("tk-buys").style.transform = "scaleX(" + (pair.buys / tot).toFixed(3) + ")";
        $("tk-buys-n").textContent = num(pair.buys) + " buys";
        $("tk-sells-n").textContent = num(pair.sells) + " sells";
      }
      var vc = $("vs-circ"); if (vc && pair.supply) vc.textContent = "~" + num(pair.supply);
      document.dispatchEvent(new CustomEvent("shy:pair", { detail: pair }));
      return pair;
    });
  }
  // keep it fresh while the page is open
  setInterval(function () { if (document.hidden) return; delete cache["a=pair"]; loadPair().then(function () { if (wi.ready) wi.draw(); }).catch(function () {}); }, 60000);

  // ---------- token hero: 7 day sparkline ----------
  var spark = $("tk-spark");
  if (spark) candles("hour", 200).then(function (rows) {
    var r7 = closes(rows, rows[rows.length - 1][0] - 7 * 86400);
    var c = chart(spark, r7, { h: 110, endDot: true, hover: true, tip: null });
    if (c) { $("tk-lo").textContent = px(c.lo); $("tk-hi").textContent = px(c.hi); }
  }).catch(function () { spark.hidden = true; var rg = document.querySelector(".tk-range"); if (rg) rg.hidden = true; });

  // ---------- home hero: sparkline in the price chip ----------
  var hs = $("hero-spark");
  if (hs) candles("hour", 200).then(function (rows) { chart(hs, closes(rows, rows[rows.length - 1][0] - 7 * 86400), { h: 34, pad: 2, stroke: 1.6 }); }).catch(function () { hs.remove(); });

  // ---------- the big chart ----------
  var pc = $("pc");
  if (pc) {
    var plot = $("pc-plot"), tip = $("pc-tip"), pro = $("pc-pro"), range = "7d";
    var R = { "1d": ["m15", 86400, "Past 24 hours", true], "7d": ["hour", 7 * 86400, "Past 7 days", true], "30d": ["hour", 30 * 86400, "Past 30 days", true], "all": ["day", 0, "", false] };
    var drawRange = function () {
      var cfg = R[range];
      if (!cfg) return;
      candles(cfg[0]).then(function (rows) {
        var since = cfg[1] ? rows[rows.length - 1][0] - cfg[1] : 0;
        var c = chart(plot, closes(rows, since), { h: plot.clientHeight || 360, hover: true, tip: tip, time: cfg[3], pad: 10, stroke: 2.4 });
        if (!c) return;
        var first = c.rows[0][1], lastv = c.rows[c.rows.length - 1][1], ch = pct(lastv, first);
        var el = $("pc-chg"); el.textContent = (ch >= 0 ? "+" : "") + ch.toFixed(2) + "%"; el.className = ch >= 0 ? "up" : "down";
        // the free price API keeps about 6 months, so "All" says where its history starts
        $("pc-lab").innerHTML = cfg[2] || 'Since <span data-i18n-skip>' + dateOf(c.rows[0][0]) + '</span>';
        $("pc-hl").innerHTML = "Low <b>" + px(c.lo) + "</b> &middot; High <b>" + px(c.hi) + "</b>";
      }).catch(function () { plot.innerHTML = '<p class="pc-err">The price history isn\'t loading right now. Try Pro chart.</p>'; });
    };
    pc.querySelector(".pc-tabs").addEventListener("click", function (e) {
      var b = e.target.closest("[data-r]"); if (!b) return;
      pc.querySelectorAll("[data-r]").forEach(function (x) { x.classList.toggle("on", x === b); });
      range = b.dataset.r;
      var isPro = range === "pro";
      pro.hidden = !isPro; pc.querySelector(".pc-body").hidden = isPro; pc.classList.toggle("is-pro", isPro);
      if (isPro && !pro.firstChild) pro.innerHTML = '<iframe src="https://dexscreener.com/solana/' + PAIR_ADDR + '?embed=1&loadChartSettings=0&trades=0&tabs=0&info=0&chartLeftToolbar=0&chartTheme=dark&theme=dark&chartStyle=1&chartType=usd&interval=60" title="$SHY on DexScreener" loading="lazy" allow="clipboard-write"></iframe>';
      if (!isPro) drawRange();
    });
    // draw when it comes near the screen, redraw on a real width change
    var seen = false, lastW = 0, rz = 0;
    var io = new IntersectionObserver(function (es) { if (es[0].isIntersecting && !seen) { seen = true; lastW = plot.clientWidth; drawRange(); io.disconnect(); } }, { rootMargin: "200px" });
    io.observe(pc);
    window.addEventListener("resize", function () { clearTimeout(rz); rz = setTimeout(function () { if (seen && range !== "pro" && Math.abs(plot.clientWidth - lastW) > 20) { lastW = plot.clientWidth; drawRange(); } }, 200); }, { passive: true });
  }

  // ---------- what if ----------
  var wi = { ready: false };
  var wiEl = $("wi");
  if (wiEl) (function () {
    var amtIn = $("wi-amt"), cap = $("wi-cap"), when = "now", day = null, shown = 0, tw = 0;
    var MIN = 5, MAX = 9;   // market cap slider: $100K to $1B on a log scale
    var MILES = [1e6, 5e6, 1e7, 5e7, 1e8, 5e8, 1e9];
    var capOf = function (v) { return Math.pow(10, MIN + (MAX - MIN) * v / 1000); };
    var posOf = function (c) { return Math.max(0, Math.min(1000, (Math.log10(c) - MIN) / (MAX - MIN) * 1000)); };
    var supply = function () { return pair && pair.supply > 1e6 ? pair.supply : FALLBACK_SUPPLY; };
    var buyPrice = function () {
      if (!pair) return 0;
      if (when === "now" || !day || !day.length) return pair.price;
      if (when === "launch") return day[0][4];
      var t = day[day.length - 1][0] - (+when) * 86400, best = null;
      for (var i = 0; i < day.length; i++) { if (day[i][0] <= t) best = day[i]; else break; }
      return best ? best[4] : 0;
    };
    // ticks under the slider, and where today's market cap sits on it
    var ticks = $("wi-ticks");
    ticks.innerHTML = [1e5, 1e6, 1e7, 1e8, 1e9].map(function (c) { return '<span style="left:' + (posOf(c) / 10) + '%">' + capFmt(c) + '</span>'; }).join("") + '<i class="wi-today" id="wi-today" hidden><b>Today</b></i>';
    var tween = function (to) {
      var el = $("wi-val"), from = shown, t0 = 0;
      cancelAnimationFrame(tw);
      if (reduce || !isFinite(from)) { shown = to; el.textContent = usd(to); return; }
      var step = function (ts) { if (!t0) t0 = ts; var k = Math.min(1, (ts - t0) / 380), e = 1 - Math.pow(1 - k, 3); shown = from + (to - from) * e; el.textContent = usd(shown); if (k < 1) tw = requestAnimationFrame(step); };
      tw = requestAnimationFrame(step);
    };
    wi.draw = function () {
      if (!pair) return;
      var amt = Math.max(0, Math.min(1e7, parseFloat(amtIn.value) || 0));
      var bp = buyPrice(), S = supply(), c = capOf(+cap.value), tp = c / S;
      var tok = bp > 0 ? amt / bp : 0, val = tok * tp, now = tok * pair.price, x = amt > 0 ? val / amt : 0;
      $("wi-buy").innerHTML = bp > 0 ? 'at <b>' + px(bp) + '</b> per $SHY' + (when !== "now" && day ? ' <span class="wi-when-d" data-i18n-skip>(' + (when === "launch" ? dateOf(day[0][0]) : dateOf(day[day.length - 1][0] - (+when) * 86400)) + ')</span>' : "") : "No price for that date yet";
      $("wi-cap-v").textContent = capFmt(c);
      $("wi-cap-p").textContent = px(tp) + " per $SHY";
      tween(val);
      var xe = $("wi-x"); xe.textContent = x >= 0.995 ? (x >= 100 ? Math.round(x).toLocaleString("en-US") : x.toFixed(x >= 10 ? 1 : 2)) + "x" : "-" + Math.round((1 - x) * 100) + "%"; xe.className = "wi-x " + (x >= 1 ? "up" : "down");
      $("wi-tok").textContent = num(tok);
      var nowEl = $("wi-now"); nowEl.textContent = usd(now); nowEl.className = now >= amt ? "up" : "down";
      $("wi-px").textContent = px(tp);
      cap.style.setProperty("--p", (cap.value / 10) + "%");
      var td = $("wi-today"); if (td && pair.mcap) { td.hidden = false; td.style.left = (posOf(pair.mcap) / 10) + "%"; }
      // the ladder: what the same bag is worth at each milestone above today
      var near = MILES.reduce(function (a, m) { return Math.abs(Math.log(m / c)) < Math.abs(Math.log(a / c)) ? m : a; }, MILES[0]);
      $("wi-ladder").innerHTML = MILES.filter(function (m) { return !pair.mcap || m > pair.mcap; }).map(function (m) {
        var v = tok * (m / S), w = Math.max(4, Math.min(100, Math.log10(Math.max(1, v / Math.max(amt, 1)) * 10) / 4 * 100));
        return '<li' + (m === near ? ' class="on"' : "") + '><button type="button" data-cap="' + m + '"><span class="wi-lc">' + capFmt(m) + '</span><span class="wi-lbar"><i style="transform:scaleX(' + (w / 100).toFixed(3) + ')"></i></span><b>' + usd(v) + '</b></button></li>';
      }).join("");
    };
    wiEl.addEventListener("click", function (e) {
      var b = e.target.closest(".wi-chips button");
      if (b) {
        var g = b.parentNode.dataset.wi;
        b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
        if (g === "amt") amtIn.value = b.dataset.v; else when = b.dataset.v;
        wi.draw(); return;
      }
      var l = e.target.closest("[data-cap]");
      if (l) { cap.value = Math.round(posOf(+l.dataset.cap)); wi.draw(); }
    });
    amtIn.addEventListener("input", function () { wiEl.querySelectorAll('[data-wi="amt"] button').forEach(function (x) { x.classList.toggle("on", x.dataset.v === amtIn.value); }); wi.draw(); });
    cap.addEventListener("input", wi.draw);
    cap.value = Math.round(posOf(1e7));
    loadPair().then(function () {
      wi.ready = true; wi.draw();
      return candles("day").then(function (rows) {
        day = rows;
        // dates older than the history can't be picked
        var first = rows[0][0], last = rows[rows.length - 1][0];
        wiEl.querySelectorAll('[data-wi="when"] button').forEach(function (b) { var n = +b.dataset.v; if (n && last - n * 86400 < first) b.disabled = true; });
        wi.draw();
      });
    }).catch(function () { wiEl.querySelectorAll('[data-wi="when"] button:not([data-v="now"])').forEach(function (b) { b.disabled = true; }); });
  })();
  else if ($("tk-live") || $("vs") || $("hero-spark")) loadPair().catch(function () {});

  // ---------- supply ring: drawn when it scrolls into view ----------
  var vs = $("vs");
  if (vs) {
    var go = function () {
      vs.classList.add("on");
      var n = vs.querySelector("[data-vs-count]"); if (!n || reduce) return;
      var t0 = 0; var step = function (ts) { if (!t0) t0 = ts; var k = Math.min(1, (ts - t0) / 1400), e = 1 - Math.pow(1 - k, 3); n.textContent = Math.round(50 * e); if (k < 1) requestAnimationFrame(step); };
      requestAnimationFrame(step);
    };
    if (reduce || !("IntersectionObserver" in window)) go();
    else { var vio = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { go(); vio.disconnect(); } }, { threshold: 0.35 }); vio.observe(vs); }
  }
  // home hero: a soft light follows the pointer and the Shadow tilts toward it (desktop only, one frame at a time)
  var hero = $("hero"), core = $("hero-core");
  if (hero && core && !reduce && window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches) {
    var hraf = 0, hx = 0, hy = 0;
    hero.addEventListener("pointermove", function (e) {
      hx = e.clientX; hy = e.clientY;
      if (hraf) return;
      hraf = requestAnimationFrame(function () {
        hraf = 0;
        var r = hero.getBoundingClientRect(), c = core.getBoundingClientRect();
        hero.style.setProperty("--mx", (hx - r.left).toFixed(0) + "px"); hero.style.setProperty("--my", (hy - r.top).toFixed(0) + "px");
        var dx = (hx - (c.left + c.width / 2)) / r.width, dy = (hy - (c.top + c.height / 2)) / r.height;
        core.style.setProperty("--ry", (dx * 10).toFixed(2) + "deg"); core.style.setProperty("--rx", (-dy * 10).toFixed(2) + "deg");
      });
      hero.classList.add("lit");
    }, { passive: true });
    hero.addEventListener("pointerleave", function () { hero.classList.remove("lit"); core.style.setProperty("--rx", "0deg"); core.style.setProperty("--ry", "0deg"); });
  }
  // stop the hero's moving parts while it's scrolled away
  if (hero && "IntersectionObserver" in window) new IntersectionObserver(function (es) { hero.classList.toggle("off", !es[0].isIntersecting); }).observe(hero);
  // days since launch
  var age = $("vf-age");
  if (age) { var days = Math.floor((Date.now() - Date.parse(age.dataset.launch + "T00:00:00Z")) / 86400000); if (days > 0) age.textContent = num(days) + " days on Solana and counting"; }
})();
