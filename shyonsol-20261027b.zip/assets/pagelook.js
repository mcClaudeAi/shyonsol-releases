// Profile Studio looks, shared by the public player page, the profile page and the studio preview.
// A page look is {banner, plate, pfx, accent}; each is an item id without its slot prefix.
(function () {
  "use strict";
  var OK = /^[a-z]+$/;
  function ok(v) { return typeof v === "string" && OK.test(v); }
  // seeded so the same page always scatters its particles the same way
  function rnd(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  var FX = {
    snow: { n: 26, s: [3, 7], d: [9, 16], sw: [-30, 30], rot: 0 },
    sakura: { n: 18, s: [6, 10], d: [8, 14], sw: [40, 140], rot: 540 },
    fireflies: { n: 16, s: [3, 5], d: [4, 8], sw: [-60, 60], rot: 0 },
    embers: { n: 20, s: [2, 4], d: [5, 9], sw: [-40, 40], rot: 0 },
    koban: { n: 14, s: [7, 10], d: [6, 11], sw: [-20, 20], rot: 720 },
    storm: { n: 46, s: [8, 14], d: [0.7, 1.3], sw: [-40, -40], rot: 0 },
    //MC 2026-10-09 three new effects (styled in style.css, .pgfx-maple, .pgfx-lanterns, .pgfx-stars)
    maple: { n: 16, s: [7, 11], d: [9, 15], sw: [40, 140], rot: 540 },
    lanterns: { n: 12, s: [7, 11], d: [10, 16], sw: [-30, 30], rot: 0 },
    stars: { n: 7, s: [50, 90], d: [3.5, 6.5], sw: [0, 0], rot: 0 },
    //MC 2026-10-10 eight animated effects from the new Studio collection (styled in profile-fx.css)
    sweep: { n: 1, s: [1, 1], d: [6, 6], sw: [0, 0], rot: 0 },
    ash: { n: 28, s: [5, 10], d: [10, 17], sw: [0, 0], rot: 0 },
    goldust: { n: 26, s: [9, 17], d: [2.4, 4.6], sw: [0, 0], rot: 0 },
    sparks: { n: 24, s: [12, 24], d: [1.4, 2.8], sw: [0, 0], rot: 0 },
    inkdrops: { n: 9, s: [7, 11], d: [4, 6.5], sw: [0, 0], rot: 0 },
    wisps: { n: 9, s: [13, 21], d: [7, 11], sw: [0, 0], rot: 0 },
    cranes: { n: 5, s: [22, 34], d: [15, 24], sw: [0, 0], rot: 0 },
    hanabi: { n: 5, s: [70, 120], d: [3.6, 5.4], sw: [0, 0], rot: 0 },
    shikigami: { n: 10, s: [16, 26], d: [9, 15], sw: [0, 0], rot: 0 },
    kiku: { n: 22, s: [7, 12], d: [7, 12], sw: [0, 0], rot: 0 }   //MC 2026-10-24 Heaven's Light: gold petals down the light shafts   //MC 2026-10-12 Dev: ofuda talismans, kanji picked by v0/v1/v2 in CSS
  };
  function fx(id, seed) {
    var c = FX[id]; if (!c) return "";
    var r = rnd(seed || 7), h = "";
    for (var i = 0; i < c.n; i++) {
      var s = c.s[0] + r() * (c.s[1] - c.s[0]), d = c.d[0] + r() * (c.d[1] - c.d[0]);
      //MC 2026-10-08 drift and spin used to ride in as CSS variables inside the keyframes, which iPhone Safari didn't
      //   animate, so the particles sat frozen. Each particle now picks one of three fixed paths (v0, v1, v2) and only
      //   its place, size, speed and start point come from inline style.
      h += '<i class="v' + Math.floor(r() * 3) + '" style="left:' + (r() * 100).toFixed(1) + '%;--y:' + (r() * 90).toFixed(1) + '%;--s:' + s.toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></i>';
    }
    return '<div class="pgfx pgfx-' + id + '" aria-hidden="true">' + h + '</div>';
  }
  //MC 2026-10-10 the animated Studio collection. Banners get a layer of moving parts (.pgbg) under the header text, frames
  //   wrap the picture (.pfr) with a layer behind it and one in front, seals (.pseal) stamp onto its corner. Everything
  //   moves with transform and opacity where it can, so phones stay smooth; profile-fx.css holds the looks and stops them
  //   all for reduced motion. On lists (leaderboards, Friends) frames come in "still" and only play on hover.
  var uid = 0;
  function petals(r, n, cls, x0, x1) {
    var h = "";
    for (var i = 0; i < n; i++) { var d = 7 + r() * 7; h += '<em class="' + cls + ' v' + Math.floor(r() * 3) + '" style="left:' + (x0 + r() * (x1 - x0)).toFixed(1) + '%;--s:' + (5 + r() * 6).toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></em>'; }
    return h;
  }
  function bloom(x, y, s) {
    var h = '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')">';
    for (var a = 0; a < 360; a += 72) h += '<ellipse cx="0" cy="-5" rx="3.6" ry="5.2" transform="rotate(' + a + ')" fill="#ffc4d3" stroke="#ff8fb0" stroke-width=".7"/>';
    return h + '<circle r="1.9" fill="#ffe08a"/><circle r=".8" fill="#e0542a"/></g>';
  }
  var BG = {
    inkclouds: function () {
      return '<b class="sun"></b><i class="c c1"></i><i class="c c2"></i><i class="c c3"></i><i class="c c4"></i>' +
        '<svg class="mt" viewBox="0 0 400 120" preserveAspectRatio="none"><path d="M0 120V78Q40 46 72 66T132 52Q172 14 214 58T302 46Q352 26 400 62V120Z" fill="#2a2420" opacity=".55"/><path d="M0 120V96Q60 76 122 92T246 84T400 90V120Z" fill="#15110f"/></svg>';
    },
    washirain: function () {
      var w = "";
      [[150, 0, 162, 70, 150, 170], [172, 0, 178, 60, 170, 140], [128, 0, 136, 50, 124, 120], [194, 0, 196, 40, 190, 95], [108, 0, 112, 36, 104, 80]].forEach(function (p) {
        var d = "M" + p[0] + " " + p[1] + "Q" + p[2] + " " + p[3] + " " + p[4] + " " + p[5];
        w += '<path d="' + d + '" stroke="#2a241f" stroke-width="1.1" fill="none"/><path d="' + d + '" stroke="#3d4a2c" stroke-width="3" stroke-dasharray="5 4" fill="none" opacity=".75"/>';
      });
      return '<svg class="wil" viewBox="0 0 200 180" preserveAspectRatio="xMaxYMin meet">' + w + '</svg><b class="hk">雨</b><i class="rn r1"></i><i class="rn r2"></i><s class="rp p1"></s><s class="rp p2"></s><s class="rp p3"></s><s class="rp p4"></s>';
    },
    emberstorm: function (r) {
      var h = '<b class="gl"></b><i class="sm s1"></i><i class="sm s2"></i><svg class="cs" viewBox="0 0 160 120" preserveAspectRatio="xMaxYMax meet"><path d="M18 120V96H8L30 84H24L52 72H44L72 58H64L80 44L96 58H88L116 72H108L136 84H130L152 96H142V120Z" fill="#120606"/><path d="M60 120V102H100V120M74 96H86V88H74Z" fill="#2a0c08"/><path d="M80 44V33" stroke="#120606" stroke-width="2.4"/><path d="M72 58Q80 50 88 58M64 72Q80 62 96 72" stroke="#3a0c08" stroke-width="1.4" fill="none"/></svg>';
      for (var i = 0; i < 24; i++) { var d = 3 + r() * 4; h += '<em class="e v' + Math.floor(r() * 3) + '" style="left:' + (5 + r() * 90).toFixed(1) + '%;--s:' + (2 + r() * 3).toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></em>'; }
      return h;
    },
    sakurawind: function (r) {
      var b = "";
      [[262, 14, 1.2], [238, 26, 1], [214, 22, 1.25], [198, 40, .9], [176, 50, 1.15], [150, 58, 1], [128, 70, 1.2], [104, 76, .95], [84, 90, 1.1], [64, 98, .9], [186, 70, .85], [168, 86, 1], [226, 6, .9], [116, 102, .9], [96, 116, 1]].forEach(function (p) { b += bloom(p[0], p[1], p[2]); });
      return '<b class="moon"></b><svg class="br" viewBox="0 0 300 200" preserveAspectRatio="xMaxYMin meet"><g class="sway"><path d="M310 2C262 22 220 18 172 50S96 76 56 100" stroke="#2a1820" stroke-width="7" stroke-linecap="round" fill="none"/><path d="M190 36C186 56 176 70 168 86M128 70C120 86 112 100 98 116M236 20C232 8 224 2 214 -2" stroke="#2a1820" stroke-width="3.2" stroke-linecap="round" fill="none"/>' + b + '</g></svg>' + petals(r, 10, "p", 10, 100);
    },
    matsuri: function () {
      var h = '<svg class="rf" viewBox="0 0 400 80" preserveAspectRatio="none"><path d="M0 80V52L30 40L60 52V44L96 30L132 44V54L170 38L212 54V46L250 32L290 46V56L330 42L370 54L400 46V80Z" fill="#070513"/></svg><svg class="str" viewBox="0 0 100 60" preserveAspectRatio="none"><path d="M0 5Q50 30 100 8M0 26Q50 50 100 22" stroke="#000" stroke-opacity=".55" stroke-width=".35" fill="none" vector-effect="non-scaling-stroke"/></svg>';
      [[0, 5, 30, 8, [.12, .3, .5, .7, .88]], [26, 22, 50, 22, [.06, .24, .42, .6, .78, .94]]].forEach(function (s, si) {
        s[4].forEach(function (t, i) {
          var y = (1 - t) * (1 - t) * s[0] + 2 * (1 - t) * t * s[2] + t * t * s[3];
          h += '<i class="ln' + (si ? " fr" : "") + (i % 2 ? " o" : "") + '" style="left:' + (t * 100).toFixed(1) + '%;top:' + (y / 60 * 100).toFixed(1) + '%;animation-delay:-' + (i * 0.7 + si * 0.4).toFixed(1) + 's"><b>' + (i % 3 === 1 ? "祭" : "") + '</b></i>';
        });
      });
      return h;
    },
    dawn: function () {
      return '<b class="halo"></b><b class="sun"></b><i class="mist m1"></i><svg class="mts" viewBox="0 0 400 140" preserveAspectRatio="none"><path d="M0 140V70L40 50L78 72L130 30L178 66L214 52L262 80L318 36L362 60L400 48V140Z" fill="#8c7d72" opacity=".55"/><path d="M0 140V92L52 70L96 94L150 62L206 98L250 80L300 100L352 74L400 90V140Z" fill="#40352f"/><path d="M0 140V114L70 100L130 116L200 104L272 120L340 106L400 116V140Z" fill="#14100e"/></svg><i class="mist m2"></i><i class="bd"><svg viewBox="0 0 60 20"><path d="M2 10Q7 5 12 10Q17 5 22 10M34 14Q38 10 42 14Q46 10 50 14" stroke="#1a1410" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg></i>';
    },
    koi: function () {
      function fish(body, spots) {
        return '<svg class="fish" viewBox="0 0 60 24"><path class="tl" d="M12 12L1 4Q5 12 1 20Z" fill="' + body + '" opacity=".9"/><ellipse cx="28" cy="4.6" rx="5" ry="2.2" fill="' + body + '" opacity=".8"/><ellipse cx="28" cy="19.4" rx="5" ry="2.2" fill="' + body + '" opacity=".8"/><path d="M9 12C19 3 42 3 55 10C58 12 58 12 55 14C42 21 19 21 9 12Z" fill="' + body + '"/>' + spots + '<circle cx="50" cy="10.4" r="1.1" fill="#111"/></svg>';
      }
      return '<i class="cau c1"></i><i class="cau c2"></i><div class="orb o1">' + fish("#f6efe6", '<ellipse cx="44" cy="11" rx="7" ry="4" fill="#e8442a"/><ellipse cx="26" cy="12.5" rx="6" ry="4.2" fill="#e8442a"/>') + '</div><div class="orb o2">' + fish("#f2b63c", '<path d="M20 9C28 7 38 7 46 9" stroke="#fff3c4" stroke-width="1.6" fill="none" opacity=".7"/>') + '</div>' +
        '<svg class="pads" viewBox="0 0 200 120" preserveAspectRatio="xMaxYMid meet"><path d="M150 30a16 11 0 1 0 2 0L162 38Z" fill="#2f7a4c"/><path d="M60 92a20 13 0 1 0 2 0L76 102Z" fill="#2a6d44"/><path d="M176 96a12 8 0 1 0 2 0L186 102Z" fill="#337f50"/><g transform="translate(62 90)"><ellipse rx="3" ry="7" fill="#ffb7c9"/><ellipse rx="3" ry="7" transform="rotate(50)" fill="#ff9fb8"/><ellipse rx="3" ry="7" transform="rotate(-50)" fill="#ff9fb8"/><circle r="2" fill="#ffe08a"/></g></svg><s class="rp p1"></s><s class="rp p2"></s>';
    },
    kinpaku: function (r) {
      var h = '<i class="leaf"></i><svg class="pine" viewBox="0 0 200 140" preserveAspectRatio="xMaxYMax meet"><path d="M160 140C158 110 168 92 150 70S120 46 92 40" stroke="#120d08" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M150 70C170 60 182 46 196 40" stroke="#120d08" stroke-width="4" fill="none"/>' +
        [[92, 40, 26], [130, 54, 22], [186, 40, 20], [158, 92, 18], [70, 52, 16]].map(function (c) { return '<path d="M' + (c[0] - c[2]) + ' ' + c[1] + 'Q' + c[0] + ' ' + (c[1] - c[2] * .8) + ' ' + (c[0] + c[2]) + ' ' + c[1] + 'Z" fill="#1d4a2e"/><path d="M' + (c[0] - c[2]) + ' ' + c[1] + 'Q' + c[0] + ' ' + (c[1] - c[2] * .8) + ' ' + (c[0] + c[2]) + ' ' + c[1] + '" stroke="#0c1f13" stroke-width="1.4" fill="none"/>'; }).join("") + '</svg><i class="swp"></i>';
      for (var i = 0; i < 8; i++) { var d = 7 + r() * 6; h += '<em class="fl" style="left:' + (20 + r() * 78).toFixed(1) + '%;--s:' + (3 + r() * 4).toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></em>'; }
      return h;
    },
    hokusai: function () {
      return '<b class="sky"></b><svg class="fuji" viewBox="0 0 120 50"><path d="M0 50L48 8Q60 2 72 8L120 50Z" fill="#2c4a7c"/><path d="M38 17L48 8Q60 2 72 8L82 17L74 14L68 20L60 13L52 21L46 14Z" fill="#f4ecd8"/></svg><i class="wv w3"><b></b></i><i class="wv w2"><b></b></i><i class="wv w1"><b></b></i>';
    },
    eye: function () {
      var g = "pgEyeG" + (++uid);
      return '<i class="st s1"></i><i class="st s2"></i><i class="rays"></i><b class="glow"></b><svg class="pyr" viewBox="0 0 120 80"><defs><linearGradient id="' + g + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe9a6"/><stop offset=".5" stop-color="#d9a128"/><stop offset="1" stop-color="#7a4f0e"/></linearGradient></defs><path d="M60 22L110 80H10Z" fill="#1a1230" stroke="url(#' + g + ')" stroke-width="1.6"/><path d="M38 48H82M27 61H93M17 72H103M50 48V61M70 48V61M40 61V72M60 61V72M80 61V72" stroke="#d9a128" stroke-opacity=".5" stroke-width=".8"/></svg>' +
        '<span class="cap"><svg viewBox="0 0 60 44"><path d="M30 2L58 42H2Z" fill="#1a1230" stroke="#ffd76a" stroke-width="2"/></svg><i class="ew"><i class="iris"></i></i></span>';
    }
  };
  //MC 2026-10-12 Dev banner: Amaterasu rising behind a torii in the sea. Rays turn, the sun breathes, its path shimmers on
  //   the water, cranes cross in front and gold motes rise. Plain divs and two small SVGs so phones keep up.
  BG.amaterasu = function (r) {
    var crane = '<svg viewBox="0 0 40 20"><path d="M0 11Q10 9 18 10L23 4Q28 1 32 3L26 7Q30 9 40 8Q31 12 22 13Q12 14 0 11Z" fill="#1a0b14"/></svg>', h = "";
    h += '<b class="rays"></b><b class="halo"></b><b class="sun"></b><i class="cl c1"></i><i class="cl c2"></i>' +
      '<div class="sea"><i class="path"></i><i class="glint g1"></i><i class="glint g2"></i></div>' +
      '<svg class="torii" viewBox="0 0 100 80"><path d="M2 8Q50 -2 98 8L95 15Q50 7 5 15Z" fill="#e0341f"/><path d="M4 8Q50 -1 96 8" stroke="#2a0d0a" stroke-width="2.2" fill="none"/><rect x="12" y="24" width="76" height="5" fill="#d02f1c"/><rect x="45" y="14" width="10" height="11" fill="#c22818"/><path d="M22 14H30L31 80H21Z" fill="#c22818"/><path d="M70 14H78L79 80H69Z" fill="#c22818"/><rect x="19" y="74" width="14" height="6" fill="#1c0a08"/><rect x="67" y="74" width="14" height="6" fill="#1c0a08"/></svg>' +
      '<i class="tref"></i>';
    for (var i = 0; i < 3; i++) h += '<span class="crane k' + i + '">' + crane + '</span>';
    for (var j = 0; j < 12; j++) { var d = 5 + r() * 6; h += '<em class="mo" style="left:' + (8 + r() * 88).toFixed(1) + '%;--s:' + (2 + r() * 3).toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></em>'; }
    return h;
  };
  function bg(pg) {
    var k = pg && ok(pg.banner) ? pg.banner : "";
    return k && BG[k] ? '<div class="pgbg pgbg-' + k + '" aria-hidden="true"><div class="pa">' + BG[k](rnd(29)) + '</div></div>' : "";
  }
  // portrait frames: [behind the picture, in front of it]. SVGs use a 100 unit box centred on the picture
  function arcPath(r, a0, a1) {
    var p = function (a) { a = a * Math.PI / 180; return (r * Math.cos(a)).toFixed(2) + " " + (r * Math.sin(a)).toFixed(2); };
    return "M" + p(a0) + "A" + r + " " + r + " 0 " + (Math.abs(a1 - a0) > 180 ? 1 : 0) + " " + (a1 > a0 ? 1 : 0) + " " + p(a1);
  }
  function svg(cls, body) { return '<svg class="' + cls + '" viewBox="-50 -50 100 100">' + body + '</svg>'; }
  var FR = {
    koban: function () {
      var c = "", g = "pfrK" + (++uid);
      for (var a = 0; a < 360; a += 60) c += '<g transform="rotate(' + a + ') translate(0 -44)"><ellipse rx="4.4" ry="6.4" fill="url(#' + g + ')" stroke="#7a4f00" stroke-width=".7"/><path d="M-2.4 -2.6H2.4M-2.8 0H2.8M-2.4 2.6H2.4" stroke="#8a5d00" stroke-width=".55"/><ellipse cx="-1.4" cy="-2.6" rx="1" ry="2" fill="#fff8d8" opacity=".7"/></g>';
      return ["", svg("spin", '<defs><linearGradient id="' + g + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2b8"/><stop offset=".5" stop-color="#f2c044"/><stop offset="1" stop-color="#b47f12"/></linearGradient></defs><circle r="44" fill="none" stroke="#f2c35b" stroke-opacity=".35" stroke-width=".6"/>' + c) + '<i class="tw"></i>'];
    },
    sakura: function () {
      var b = "";
      for (var a = 0; a < 360; a += 36) { var rr = a * Math.PI / 180; b += '<path d="' + arcPath(44, a, a + 30) + '" stroke="#4a2a2a" stroke-width="1.4" fill="none"/>' + bloom((44 * Math.cos(rr)).toFixed(2), (44 * Math.sin(rr)).toFixed(2), a % 72 ? .62 : .82); }
      return ["", svg("breathe", b) + '<em class="pt pt1"></em><em class="pt pt2"></em><em class="pt pt3"></em>'];
    },
    ink: function () {
      return [svg("", '<circle r="47" fill="#efe3c6"/><circle r="47" fill="none" stroke="#c9b48a" stroke-width=".6"/>'),
        svg("enso", '<path class="e1" pathLength="100" d="' + arcPath(43, -70, 262) + '" stroke="#141010" stroke-width="5.2" stroke-linecap="round" fill="none"/><path class="e2" pathLength="100" d="' + arcPath(44.6, -64, 250) + '" stroke="#141010" stroke-width="1.6" stroke-linecap="round" fill="none" opacity=".55"/><rect x="30" y="30" width="9" height="9" rx="1.2" fill="#c8281e" transform="rotate(-8 34 34)"/>')];
    },
    hanko: function () {
      var id = "pfrH" + (++uid);
      return ['<b class="gw"></b>', svg("spin slow", '<defs><path id="' + id + '" d="' + arcPath(44.6, -90, 269.9) + '"/></defs><circle r="45" fill="none" stroke="#c8281e" stroke-width="9"/><circle r="49.2" fill="none" stroke="#c8281e" stroke-width=".9"/><circle r="40.6" fill="none" stroke="#f3e6c8" stroke-width=".5" opacity=".7"/><text font-size="6.2" font-weight="700" fill="#f6ead2" font-family="\'Shippori Mincho B1\',\'Noto Serif JP\',\'Yu Mincho\',serif" letter-spacing="1.1" dy="2.1"><textPath href="#' + id + '">勝 運 ・ 影 ・ 金 ・ 忍 ・ 天 下 ・ 勝 運 ・ 影 ・ 金 ・ 忍 ・ 天 下 ・</textPath></text>')];
    },
    lightning: function () {
      var r = rnd(97), sets = ["", "", ""];
      for (var s = 0; s < 3; s++) for (var b = 0; b < 3; b++) {
        var a0 = s * 40 + b * 120 + r() * 20, len = 30 + r() * 30, d = "", n = 7;
        for (var i = 0; i <= n; i++) { var a = (a0 + len * i / n) * Math.PI / 180, rr = 44 + (i % 2 ? 1 : -1) * (1.5 + r() * 3.5); d += (i ? "L" : "M") + (rr * Math.cos(a)).toFixed(1) + " " + (rr * Math.sin(a)).toFixed(1); }
        sets[s] += '<path d="' + d + '" stroke="#bfe9ff" stroke-width="1.5" fill="none" stroke-linejoin="round"/><path d="' + d + '" stroke="#fff" stroke-width=".6" fill="none"/>';
      }
      return ['<b class="gw"></b>', '<div class="spin">' + sets.map(function (x, i) { return svg("bolt b" + i, '<circle r="44" fill="none" stroke="#5ab8ff" stroke-opacity=".28" stroke-width="1"/>' + x); }).join("") + '</div>'];
    },
    foxfire: function () {
      return ['<b class="gw"></b>', svg("", '<circle r="44" fill="none" stroke="#8fa8ff" stroke-opacity=".25" stroke-width=".8" stroke-dasharray="1 3"/>') + '<div class="spin">' + [0, 120, 240].map(function (a) { return '<i class="ff" style="transform:rotate(' + a + 'deg)"><b></b></i>'; }).join("") + '</div>'];
    },
    dragon: function () {
      var g = "pfrD" + (++uid), body = "", segs = [[-4, -70, 7.2], [-68, -150, 5.8], [-148, -215, 4.4], [-213, -262, 3]];
      segs.forEach(function (s) { body += '<path d="' + arcPath(43, s[0], s[1]) + '" stroke="#5a3404" stroke-width="' + (s[2] + 1.6) + '" fill="none" stroke-linecap="round"/>'; });
      segs.forEach(function (s) { var p = arcPath(43, s[0], s[1]); body += '<path d="' + p + '" stroke="url(#' + g + ')" stroke-width="' + s[2] + '" fill="none" stroke-linecap="round"/><path d="' + p + '" stroke="#8a5408" stroke-width="' + (s[2] * .62).toFixed(2) + '" stroke-dasharray="1.1 1.9" fill="none" opacity=".6"/>'; });
      body += '<path d="' + arcPath(40.6, -8, -200) + '" stroke="#fff1b8" stroke-width=".8" fill="none" opacity=".55"/>';
      for (var a = -16; a > -240; a -= 14) { var w = a > -70 ? 7.2 : a > -150 ? 5.8 : 4.4, rr = 43 + w / 2, t = a * Math.PI / 180, t2 = (a - 5) * Math.PI / 180; body += '<path d="M' + (rr * Math.cos(t)).toFixed(1) + ' ' + (rr * Math.sin(t)).toFixed(1) + 'L' + ((rr + 3) * Math.cos(t2 + .03)).toFixed(1) + ' ' + ((rr + 3) * Math.sin(t2 + .03)).toFixed(1) + 'L' + (rr * Math.cos(t2)).toFixed(1) + ' ' + (rr * Math.sin(t2)).toFixed(1) + 'Z" fill="#c8281e"/>'; }
      // legs with claws on the outside of the coil
      [-38, -122, -196].forEach(function (a) { body += '<g transform="rotate(' + a + ') translate(46.5 0)"><path d="M0 0L5.5 1.5" stroke="#e8b23a" stroke-width="2" stroke-linecap="round"/><path d="M5.5 1.5L9 -.6M5.5 1.5L9.4 2.4M5.5 1.5L8 4.8" stroke="#fff0b0" stroke-width=".9" stroke-linecap="round"/></g>'; });
      // the head, open-jawed, with horns, a red mane and long whiskers, pointing the way it travels
      body += '<g transform="translate(43 1) rotate(90) scale(1.3)"><path d="M-9 -4Q-14 -10 -12 -15Q-8 -10 -5 -8Q-8 -14 -4 -17Q-2 -11 1 -7.5Q0 -12 4 -13Q3 -8 4.5 -6Z" fill="#c8281e"/>' +
        '<path d="M2 -6C-3 -12 -9 -13 -15 -11.5M5 -6.6C2 -13 -2 -16.5 -8 -17.5" stroke="#f6e3a0" stroke-width="1.3" fill="none" stroke-linecap="round"/>' +
        '<path d="M-9 -4.6C-2 -8 6 -8 11 -4.4L17.5 -3.4C19.6 -2.8 19.6 -1 17.6 -.6L12 0L17 1.4C18.8 1.8 18.4 3.6 16.6 3.8L10 3.8C6 7.2 -2 7.6 -9 4.8Z" fill="url(#' + g + ')" stroke="#5a3404" stroke-width=".8" stroke-linejoin="round"/>' +
        '<path d="M12.4 -.2L13.4 1.2L14.4 -.1L15.4 1.2" stroke="#fff" stroke-width=".6" fill="none"/><circle cx="7" cy="-3.3" r="1.5" fill="#c8281e"/><circle cx="7.4" cy="-3.7" r=".5" fill="#fff"/>' +
        '<path d="M16 -2.6C21 -9 27 -6 29 -13M15 3C21 9 26 6 29 12" stroke="#ffd76a" stroke-width=".7" fill="none" stroke-linecap="round"/></g>' +
        '<g transform="rotate(30) translate(44 0)"><circle r="5.6" fill="#ff9a3c" opacity=".35"/><circle r="4.2" fill="#fff6d8"/><path d="M-2 -1.5Q0 -3.8 2.4 -1.6" stroke="#ff7a2a" stroke-width=".8" fill="none"/></g>';
      return ['<b class="gw"></b>', svg("spin", '<defs><linearGradient id="' + g + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0a8"/><stop offset=".55" stop-color="#e8b23a"/><stop offset="1" stop-color="#b07a1e"/></linearGradient></defs>' + body)];
    },
    eye: function () {
      var dots = "";
      for (var a = 0; a < 360; a += 45) dots += '<circle cx="' + (47 * Math.cos(a * Math.PI / 180)).toFixed(1) + '" cy="' + (47 * Math.sin(a * Math.PI / 180)).toFixed(1) + '" r="' + (a % 90 ? .8 : 1.3) + '" fill="#ffe9a6"/>';
      return ['<b class="rays"></b><b class="gw"></b>', svg("", '<rect x="-38.5" y="-38.5" width="77" height="77" rx="19" fill="none" stroke="#e8b23a" stroke-width="1.4"/><rect x="-41.5" y="-41.5" width="83" height="83" rx="21" fill="none" stroke="#e8b23a" stroke-opacity=".45" stroke-width=".6"/>') + svg("spin slow", dots) +
        '<span class="cap"><svg viewBox="0 0 60 44"><path d="M30 3L57 41H3Z" fill="#1a1230" stroke="#ffd76a" stroke-width="2.4"/></svg><i class="ew"><i class="iris"></i></i></span>'];
    }
  };
  //MC 2026-10-12 Dev frame: an aurora and a turning ring of kanji behind the picture, a torii floating over it and two
  //   sparks orbiting the other way. textPath needs a unique id per copy, same as the gradients above.
  FR.torii = function () {
    var g = "pfrT" + (++uid), txt = "開発者 ・ 創 ・ 影の道 ・ 開発者 ・ 創 ・ 影の道 ・ ";
    var ring = '<defs><path id="' + g + '" d="M0 -45.5A45.5 45.5 0 1 1 -0.01 -45.5"/></defs><circle r="49" fill="none" stroke="#ffcf6a" stroke-opacity=".5" stroke-width=".5"/><circle r="41.5" fill="none" stroke="#ffcf6a" stroke-opacity=".35" stroke-width=".5" stroke-dasharray="1 2.4"/>' +
      '<text font-size="6.6" font-weight="700" fill="#ffe3a0" letter-spacing=".6" font-family="Shippori Mincho B1,Noto Serif JP,Hiragino Mincho ProN,Yu Mincho,serif"><textPath href="#' + g + '">' + txt + '</textPath></text>';
    var torii = '<svg viewBox="0 0 100 70"><path d="M0 9Q50 -3 100 9L96 18Q50 8 4 18Z" fill="#ff4a2c"/><path d="M3 8Q50 -2 97 8" stroke="#1e0806" stroke-width="3" fill="none"/><rect x="12" y="28" width="76" height="6" fill="#ec3a20"/><rect x="45" y="17" width="10" height="12" fill="#d8301a"/><path d="M21 17H31L32 70H20Z" fill="#d8301a"/><path d="M69 17H79L80 70H68Z" fill="#d8301a"/></svg>';
    return ['<b class="aur"></b><b class="gw"></b>' + svg("spin ring", ring),
      '<div class="orb">' + svg("", '<circle cx="0" cy="-47" r="2" fill="#fff6d8"/><circle cx="0" cy="-47" r="4.4" fill="#ffd76a" opacity=".35"/><circle cx="0" cy="47" r="1.6" fill="#ffd0f0"/><circle cx="0" cy="47" r="3.8" fill="#ff8fd0" opacity=".3"/>') + '</div>' +
      '<span class="tor">' + torii + '</span>'];
  };
  //MC 2026-10-24 the Imperial Regalia for your page: Plain of High Heaven (banner), The Three Treasures (frame) and the
  //   Chrysanthemum Seal. SVG gradients need an id of their own on every copy, so each draw takes a fresh suffix.
  function impSvg(kind) {
    var U = "i" + (++uid);
    if (kind === "mirror") return "<svg class=\"im-mir\" viewBox=\"-50 -50 100 100\">" + "<defs><linearGradient id='m_"+U+"' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#fff3c4'/><stop offset='.45' stop-color='#e8b23a'/><stop offset='1' stop-color='#7a4f0e'/></linearGradient><radialGradient id='f_"+U+"' cx='.42' cy='.38' r='.7'><stop offset='0' stop-color='#fffdf2'/><stop offset='.3' stop-color='#ffe9a6'/><stop offset='.7' stop-color='#e0a63a'/><stop offset='1' stop-color='#8a5a12'/></radialGradient></defs><circle cx='38' cy='0' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='26.87' cy='26.87' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='0' cy='38' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='-26.87' cy='26.87' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='-38' cy='0' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='-26.87' cy='-26.87' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='-0' cy='-38' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle cx='26.87' cy='-26.87' r='11.5' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle r='41' fill='url(#m_"+U+")' stroke='#4a2c04' stroke-width='1.2'/><circle r='35' fill='#3a2206'/><circle r='32' fill='url(#f_"+U+")'/><circle r='32' fill='none' stroke='#fff6d8' stroke-opacity='.5' stroke-width='.8'/>" + "</svg>";
    if (kind === "kiku") return "<svg class=\"im-kik\" viewBox=\"-50 -50 100 100\">" + "<defs><linearGradient id='g_"+U+"' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#fff3c4'/><stop offset='.5' stop-color='#f2c35b'/><stop offset='1' stop-color='#b07a1e'/></linearGradient></defs><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(11.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(33.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(56.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(78.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(101.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(123.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(146.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(168.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(191.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(213.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(236.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(258.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(281.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(303.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(326.25)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-31' rx='7.4' ry='17.5' transform='rotate(348.75)' fill='#b07a1e' stroke='#5a3604' stroke-width='1.2'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(0)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(22.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(45)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(67.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(90)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(112.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(135)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(157.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(180)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(202.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(225)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(247.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(270)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(292.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(315)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><ellipse cx='0' cy='-28' rx='8.2' ry='19' transform='rotate(337.5)' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.4'/><circle r='11' fill='url(#g_"+U+")' stroke='#5a3604' stroke-width='1.6'/><circle r='5' fill='#fff3c4' opacity='.8'/>" + "</svg>";
    if (kind === "mag") return "<svg class=\"im-mag\" viewBox=\"-12 -12 24 24\">" + "<defs><linearGradient id='j_"+U+"' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#8fffe0'/><stop offset='.5' stop-color='#21b585'/><stop offset='1' stop-color='#0a5a42'/></linearGradient></defs><path d='M9 -3A7 7 0 1 0 -1.6 3.1C-3 6 -5 8.2 -7.6 10.4C0.6 9.6 6.6 6.2 8.4 0.8A7 7 0 0 0 9 -3Z' fill='url(#j_"+U+")' stroke='#06362a' stroke-width='.7'/><path d='M-2 -7.4A6 6 0 0 1 6.6 -6' stroke='#fff' stroke-opacity='.75' stroke-width='1.2' fill='none' stroke-linecap='round'/><circle cx='2' cy='-3' r='2.1' fill='#062a20' stroke='#ffe7a3' stroke-width='.7'/>" + "</svg>";
    return "<svg class=\"im-swd\" viewBox=\"0 0 16 100\">" + "<defs><linearGradient id='b_"+U+"' x1='0' x2='1'><stop offset='0' stop-color='#9fb8d8'/><stop offset='.5' stop-color='#ffffff'/><stop offset='1' stop-color='#8aa2c4'/></linearGradient><linearGradient id='h_"+U+"' x1='0' x2='1'><stop offset='0' stop-color='#b07a1e'/><stop offset='.5' stop-color='#fff0b0'/><stop offset='1' stop-color='#b07a1e'/></linearGradient></defs><path d='M8 0L12.4 9V70H3.6V9Z' fill='url(#b_"+U+")' stroke='#324766' stroke-width='.6'/><path d='M8 3V68' stroke='#fff' stroke-width='.7' opacity='.8'/><rect x='0.5' y='69' width='15' height='4.6' rx='1.4' fill='url(#h_"+U+")' stroke='#5a3604' stroke-width='.6'/><rect x='5' y='73.4' width='6' height='18' rx='1' fill='#2a1006'/><path d='M5 77H11M5 81H11M5 85H11M5 89H11' stroke='#e8b23a' stroke-width='1.1'/><circle cx='8' cy='95' r='3.6' fill='none' stroke='url(#h_"+U+")' stroke-width='2'/>" + "</svg>";
  }
  BG.takama = function (r) {
    var h = '<b class="rays"></b><b class="halo"></b><span class="sun">' + impSvg("mirror") + '</span>' +
      '<i class="st"></i><span class="swd">' + impSvg("sword") + '</span><span class="jwl"><i></i>' + impSvg("mag") + impSvg("mag") + impSvg("mag") + '</span>' +
      '<i class="cl c1"></i><i class="cl c2"></i><i class="cl c3"></i>';
    for (var j = 0; j < 14; j++) { var d = 5 + r() * 6; h += '<em class="mo" style="left:' + (6 + r() * 90).toFixed(1) + '%;--s:' + (2 + r() * 3).toFixed(1) + 'px;animation-duration:' + d.toFixed(2) + 's;animation-delay:-' + (r() * d).toFixed(2) + 's"></em>'; }
    return h;
  };
  FR.regalia = function () {
    return ['<b class="rays"></b><b class="gw"></b><span class="kr spin slow">' + impSvg("kiku") + '</span>',
      svg("", '<circle r="44.5" fill="none" stroke="#f2c35b" stroke-width="1.6"/><circle r="47.5" fill="none" stroke="#f2c35b" stroke-opacity=".5" stroke-width=".7"/><circle r="41.5" fill="none" stroke="#fff3c4" stroke-opacity=".45" stroke-width=".5" stroke-dasharray="1 2.2"/>') +
      '<div class="orb"><span class="t0">' + impSvg("mirror") + '</span><span class="t1">' + impSvg("sword") + '</span><span class="t2">' + impSvg("mag") + '</span></div>'];
  };
  var SEAL = {
    kage: '<b>影</b><i class="ring"></i>', kin: '<b>金</b><i class="gl"></i>', oni: '<i class="gw"></i><b>鬼</b>',
    mon: '<svg viewBox="-50 -50 100 100"><circle r="47" fill="#14100c" stroke="#e8b23a" stroke-width="4"/><g class="tm" fill="#f2c35b">' + [0, 120, 240].map(function (a) { return '<path transform="rotate(' + a + ')" d="M0 -34A12 12 0 1 1 0 -10A23 23 0 0 0 -31 5A34 34 0 0 1 0 -34Z"/>'; }).join("") + '</g></svg>',
    ryu: '<i class="edge"></i><i class="in"></i><b>龍</b>', kami: '<i class="ry"></i><i class="disc"></i><b>神</b>',
    eye: '<svg viewBox="0 0 60 54"><path d="M30 3L57 50H3Z" fill="#1a1230" stroke="#ffd76a" stroke-width="3" stroke-linejoin="round"/></svg><i class="ew"><i class="iris"></i></i>',
    kiku: '<i class="ry"></i><i class="disc"></i><b class="km"></b><i class="gl"></i>',   //MC 2026-10-24 Chrysanthemum Seal (the crest is drawn by profile-fx.css)
    dev: '<i class="sp"></i><i class="bx"><i class="edge"></i></i><i class="in"></i><b>創</b><i class="gl"></i>'   //MC 2026-10-12 Dev: Creator Seal
  };
  // the picture wrapped in its frame and seal (both optional); still: for lists, where it only plays on hover
  function wrap(fr, seal, inner, still) {
    var f = ok(fr) && FR[fr] ? FR[fr]() : null, s = ok(seal) && SEAL[seal] ? seal : "";
    if (!f && !s) return inner;
    return '<span class="pfr' + (f ? " pfr-" + fr : "") + (still ? " still" : "") + '">' + (f && f[0] ? '<span class="pfr-b" aria-hidden="true">' + f[0] + '</span>' : "") + inner +
      (f ? '<span class="pfr-f" aria-hidden="true">' + f[1] + '</span>' : "") + (s ? '<span class="pseal pseal-' + s + '" aria-hidden="true">' + SEAL[s] + '</span>' : "") + '</span>';
  }
  window.ShyLook = {
    head: function (pg) { return "pg-look" + (pg && ok(pg.banner) ? " pgb-" + pg.banner : ""); },
    name: function (pg) { return pg && ok(pg.plate) ? " pgn-" + pg.plate : ""; },
    page: function (pg) { return pg && ok(pg.accent) ? " pga-" + pg.accent : ""; },
    fx: function (pg, seed) { return pg && ok(pg.pfx) ? fx(pg.pfx, seed) : ""; },
    //MC 2026-10-10 the banner's moving layer and the page effect together, for the page header
    layers: function (pg, seed) { return bg(pg) + (pg && ok(pg.pfx) ? fx(pg.pfx, seed) : ""); },
    bg: bg,
    avatar: function (pg, inner) { return pg ? wrap(pg.pframe, pg.seal, inner, false) : inner; },
    frame: function (fr, inner) { return wrap(fr, "", inner, true); },
    seal: function (k) { return ok(k) && SEAL[k] ? '<span class="pseal pseal-' + k + '" aria-hidden="true">' + SEAL[k] + '</span>' : ""; }
  };
})();
