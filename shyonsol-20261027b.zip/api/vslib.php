<?php
//MC 2026-10-22 Community challenges. Admin presses Refresh and the site pulls a fresh batch of established coin
//   communities from DexScreener's free API: old enough (5 months by default), still liquid and trading, not falling
//   off a cliff today, and with an X account listed on their DexScreener page. The team reviews every row, approves the
//   ones worth challenging, and each approved community gets its own page (/vs/<slug>) with a card drawn for it and a
//   live scoreboard: their players against our leaders this week. Posting to X is one tap that opens the composer
//   with the @handle, the text and the link ready; a person reads it and presses Post. Nothing here ever posts or
//   tags anyone on its own. X treats automated mentions as spam, and a person writing to another community gets
//   more replies anyway.
if (!defined('SHY_API')) { http_response_code(404); exit; }
define('VS_FILE', DATA_DIR . '/vs.php');           // ['list' => [slug => community], 'm' => [pid => [c, t]], 'cfg' => [...], 'last' => t, 'posts' => [day => n]]
define('VS_LOGOS', DATA_DIR . '/vs-logos');
const VS_DEFAULTS = ['chains' => 'solana', 'age' => 150, 'liq' => 50000, 'vol' => 20000, 'mc' => 1000000, 'drop' => 40, 'cap' => 5, 'gap' => 30, 'per' => 25];
// coins that are infrastructure, not communities: stables, wrapped and staked SOL, the big protocol tokens
const VS_SKIP_SYM = ['SOL', 'WSOL', 'USDC', 'USDT', 'USDS', 'PYUSD', 'USDE', 'DAI', 'JUP', 'RAY', 'JTO', 'PYTH', 'ORCA', 'MSOL', 'JITOSOL', 'BSOL', 'JUPSOL', 'INF', 'WBTC', 'CBBTC', 'WETH', 'ETH', 'BTC', 'W', 'HNT', 'RENDER', 'DRIFT', 'KMNO', 'TNSR', 'ZEUS', 'CLOUD'];
// what each Refresh searches DexScreener for, a different handful every press. Searching plain words ("cat", "dog")
//   mostly turns up last week's copycats, so the pool is the names of communities that have been around, and the
//   filters still decide: a name on this list that has died, lost its X or dried up never makes the review list.
//   The takeovers and top boosts DexScreener lists add new names on every press, and the admin can look up any coin
//   by name, ticker or address.
const VS_SEEDS = ['popcat', 'dogwifhat', 'bonk', 'mew', 'book of meme', 'michi', 'goatseus', 'peanut the squirrel', 'fartcoin', 'gigachad', 'retardio', 'slerf', 'myro',
    'ponke', 'moo deng', 'chill guy', 'ai16z', 'zerebro', 'pudgy penguins', 'sigma', 'billy', 'mother iggy', 'gamestop', 'wen', 'samoyedcoin', 'neiro', 'spx6900',
    'useless', 'aura', 'troll', 'housecoin', 'wojak', 'maneki', 'shark cat', 'catwifhat', 'nub', 'analos', 'hege', 'lock in', 'fwog', 'smog', 'mumu', 'silly dragon',
    'duko', 'daddy tate', 'bert', 'griffain', 'pippin', 'alchemist', 'vine', 'buttcoin', 'titcoin', 'skibidi', 'giko', 'apu', 'jeo boden', 'tremp', 'harambe',
    'lmao', 'bodo', 'kitty', 'manifest', 'mumu the bull', 'pepe solana', 'doge solana', 'shiba solana', 'mog solana', 'brett solana', 'turbo solana', 'monkey',
    'baby', 'cat', 'dog', 'frog', 'chad', 'based', 'whale', 'bull', 'bear', 'samurai', 'ninja', 'ape', 'king', 'cto', 'community'];

function vs_all() { $d = load(VS_FILE); return (is_array($d) ? $d : []) + ['list' => [], 'm' => [], 'cfg' => [], 'last' => 0, 'posts' => []]; }
function vs_cfg($d = null) { $d = $d ?? vs_all(); return array_merge(VS_DEFAULTS, array_intersect_key((array)($d['cfg'] ?? []), VS_DEFAULTS)); }
function vs_api_base() { return rtrim((string)(shy_config()['ds_api'] ?? 'https://api.dexscreener.com'), '/'); }   // ds_api only for local testing
function vs_get($path, $timeout = 7) {
    $ch = curl_init(vs_api_base() . $path);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_USERAGENT => 'shyonsol.io',
        CURLOPT_HTTPHEADER => ['Accept: application/json']]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : null;
}
// the X handle from a DexScreener socials list (x.com or twitter.com links), '' when there is none
function vs_handle($socials) {
    foreach ((array)$socials as $s) {
        $u = (string)($s['url'] ?? ''); $t = strtolower((string)($s['type'] ?? ''));
        if ($t !== 'twitter' && $t !== 'x' && !preg_match('~//(www\.)?(x|twitter)\.com/~i', $u)) continue;
        if (preg_match('~(?:x|twitter)\.com/(?:#!/)?@?([A-Za-z0-9_]{1,15})(?:[/?#]|$)~i', $u, $m) && !in_array(strtolower($m[1]), ['i', 'home', 'search', 'intent', 'share', 'hashtag'], true)) return $m[1];
    }
    return '';
}
// a short page address from the ticker, kept unique in the list
function vs_slug($sym, $name, $addr, $list) {
    $base = strtolower(preg_replace('/[^a-z0-9]+/i', '', $sym)) ?: strtolower(preg_replace('/[^a-z0-9]+/i', '', $name));
    $base = substr($base !== '' ? $base : 'coin', 0, 20);
    foreach ($list as $sl => $c) if (($c['addr'] ?? '') === $addr) return $sl;
    $s = $base; $n = 2;
    while (isset($list[$s])) $s = $base . '-' . strtolower(substr(preg_replace('/[^a-z0-9]/i', '', $addr), 0, 3 + $n++));
    return $s;
}
function vs_clean_text($s, $max = 40) { return mb_substr(trim(preg_replace('/[\x00-\x1F\x7F<>]+/u', '', (string)$s)), 0, $max); }
// does this pair pass the filters? Returns the community record or null (with $why set for the count)
function vs_pick($p, $cfg, &$why) {
    $chains = array_filter(array_map('trim', explode(',', strtolower((string)$cfg['chains']))));
    $chain = strtolower((string)($p['chainId'] ?? ''));
    if ($chains && !in_array($chain, $chains, true)) { $why = 'chain'; return null; }
    $bt = (array)($p['baseToken'] ?? []); $addr = (string)($bt['address'] ?? ''); $sym = (string)($bt['symbol'] ?? '');
    if ($addr === '' || $addr === SHY_MINT || in_array(strtoupper(preg_replace('/[^a-z0-9]/i', '', $sym)), VS_SKIP_SYM, true)) { $why = 'skip'; return null; }
    $age = (int)floor((time() - (int)(($p['pairCreatedAt'] ?? 0) / 1000)) / 86400);
    if (empty($p['pairCreatedAt']) || $age < (int)$cfg['age']) { $why = 'young'; return null; }
    $liq = (float)($p['liquidity']['usd'] ?? 0); $vol = (float)($p['volume']['h24'] ?? 0); $mc = (float)($p['marketCap'] ?? $p['fdv'] ?? 0); $pc = (float)($p['priceChange']['h24'] ?? 0);
    if ($liq < (float)$cfg['liq'] || $vol < (float)$cfg['vol'] || $mc < (float)$cfg['mc']) { $why = 'small'; return null; }
    if ($pc <= -abs((float)$cfg['drop'])) { $why = 'falling'; return null; }
    $h = vs_handle($p['info']['socials'] ?? []);
    if ($h === '') { $why = 'nox'; return null; }
    $tg = ''; foreach ((array)($p['info']['socials'] ?? []) as $s) if (strtolower((string)($s['type'] ?? '')) === 'telegram') { $tg = (string)$s['url']; break; }
    return ['addr' => $addr, 'chain' => $chain, 'name' => vs_clean_text($bt['name'] ?? $sym), 'sym' => vs_clean_text($sym, 16), 'x' => $h, 'tg' => preg_match('~^https://t\.me/[A-Za-z0-9_+/]{2,64}$~', $tg) ? $tg : '',
        'img' => (string)($p['info']['imageUrl'] ?? ''), 'url' => (string)($p['url'] ?? ''), 'age' => $age, 'liq' => round($liq), 'vol' => round($vol), 'mc' => round($mc), 'pc' => round($pc, 1)];
}
// one press of Refresh: a few random searches plus DexScreener's community takeovers and top boosted tokens, every pair
// through the filters, the best pair per token kept, and up to cfg[per] new rows added as 'new' for the team to review.
// Rows already on the list keep their status (and a blocked coin never comes back); their numbers are refreshed.
function vs_refresh($seeds = null) {
    $d = vs_all(); $cfg = vs_cfg($d);
    $pool = VS_SEEDS; shuffle($pool); $seeds = $seeds ?? array_slice($pool, 0, 8);
    $pairs = []; $calls = 0; $fails = 0;
    foreach ($seeds as $q) { $calls++; $j = vs_get('/latest/dex/search?q=' . rawurlencode($q)); if ($j === null) { $fails++; continue; } foreach ((array)($j['pairs'] ?? []) as $p) $pairs[] = $p; }
    // takeovers and boosts give token addresses; their pairs come from the tokens lookup, 30 at a time
    $addrs = [];
    foreach (['/community-takeovers/latest/v1', '/token-boosts/top/v1'] as $src) {
        $calls++; $j = vs_get($src); if ($j === null) { $fails++; continue; }
        foreach ((array)$j as $t) if (is_array($t) && ($t['chainId'] ?? '') !== '' && preg_match('/^[A-Za-z0-9]{20,64}$/', (string)($t['tokenAddress'] ?? ''))) $addrs[strtolower($t['chainId'])][(string)$t['tokenAddress']] = 1;
    }
    $chains = array_filter(array_map('trim', explode(',', strtolower((string)$cfg['chains']))));
    foreach ($addrs as $chain => $set) {
        if ($chains && !in_array($chain, $chains, true)) continue;
        foreach (array_chunk(array_keys($set), 30) as $chunk) { $calls++; $j = vs_get('/tokens/v1/' . rawurlencode($chain) . '/' . implode(',', $chunk)); if ($j === null) { $fails++; continue; } foreach ((array)$j as $p) if (is_array($p)) $pairs[] = $p; }
    }
    if (!$pairs && $fails >= $calls) return ['ok' => false, 'error' => 'DexScreener could not be reached. Try again in a minute.'];
    $best = []; $why = ['chain' => 0, 'skip' => 0, 'young' => 0, 'small' => 0, 'falling' => 0, 'nox' => 0];
    foreach ($pairs as $p) {
        $w = ''; $c = vs_pick($p, $cfg, $w);
        if (!$c) { if (isset($why[$w])) $why[$w]++; continue; }
        if (!isset($best[$c['addr']]) || $c['liq'] > $best[$c['addr']]['liq']) $best[$c['addr']] = $c;
    }
    $res = vs_merge($best, (int)$cfg['per']);
    return ['ok' => true, 'added' => $res['added'], 'updated' => $res['updated'], 'pairs' => count($pairs), 'passed' => count($best), 'why' => $why, 'seeds' => $seeds];
}
// new rows go in as 'new' (up to $limit of them); rows already listed keep their status and get fresh numbers
function vs_merge($best, $limit) {
    return with_lock(function () use ($best, $limit) {
        $d = vs_all(); $added = 0; $upd = 0;
        $byAddr = []; foreach ($d['list'] as $sl => $c) $byAddr[$c['addr'] ?? ''] = $sl;
        uasort($best, fn($a, $b) => $b['liq'] <=> $a['liq']);
        foreach ($best as $addr => $c) {
            if (isset($byAddr[$addr])) {   // known: fresh numbers, same status
                $sl = $byAddr[$addr];
                foreach (['age', 'liq', 'vol', 'mc', 'pc', 'img', 'url', 'x', 'tg'] as $k) $d['list'][$sl][$k] = $c[$k];
                $d['list'][$sl]['seen'] = time(); $upd++;
                continue;
            }
            if ($added >= $limit) continue;
            $sl = vs_slug($c['sym'], $c['name'], $addr, $d['list']);
            $d['list'][$sl] = $c + ['st' => 'new', 'found' => time(), 'seen' => time(), 'posted' => 0];
            $byAddr[$addr] = $sl; $added++;
        }
        // the list stays a working size: the oldest skipped rows go first (blocked ones stay, so they never come back)
        if (count($d['list']) > 400) { $sk = array_filter($d['list'], fn($c) => $c['st'] === 'skip'); uasort($sk, fn($a, $b) => $a['seen'] <=> $b['seen']); foreach (array_slice(array_keys($sk), 0, count($d['list']) - 400) as $k) unset($d['list'][$k]); }
        $d['last'] = time();
        save(VS_FILE, $d);
        return ['added' => $added, 'updated' => $upd];
    });
}
//MC 2026-10-22 look up one coin by hand (a name, a ticker or a contract address): the best matching pool through the same
//   filters. Added as New for review when it passes; when it doesn't, the answer says which filter stopped it.
function vs_lookup($q) {
    $q = trim((string)$q); if ($q === '' || strlen($q) > 64) return ['ok' => false, 'error' => 'Type a name, a ticker or a contract address.'];
    $d = vs_all(); $cfg = vs_cfg($d);
    $isAddr = preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $q) || preg_match('/^0x[a-fA-F0-9]{40}$/', $q);
    $pairs = [];
    if ($isAddr) { foreach (array_filter(array_map('trim', explode(',', strtolower((string)$cfg['chains'])))) as $ch) { $j = vs_get('/tokens/v1/' . rawurlencode($ch) . '/' . rawurlencode($q)); foreach ((array)$j as $p) if (is_array($p)) $pairs[] = $p; } }
    else { $j = vs_get('/latest/dex/search?q=' . rawurlencode($q)); if ($j === null) return ['ok' => false, 'error' => 'DexScreener could not be reached. Try again in a minute.']; $pairs = (array)($j['pairs'] ?? []); }
    $want = strtolower(ltrim($q, '$'));
    $match = array_values(array_filter($pairs, fn($p) => $isAddr ? strcasecmp((string)($p['baseToken']['address'] ?? ''), $q) === 0 : (strtolower(trim((string)($p['baseToken']['symbol'] ?? ''))) === $want || strtolower(trim((string)($p['baseToken']['name'] ?? ''))) === $want)));
    if (!$match) return ['ok' => false, 'error' => 'No coin on DexScreener goes by "' . $q . '" exactly. Try its ticker, its full name or its contract address.'];
    usort($match, fn($a, $b) => (float)($b['liquidity']['usd'] ?? 0) <=> (float)($a['liquidity']['usd'] ?? 0));
    $why = ''; $c = vs_pick($match[0], $cfg, $why);
    $words = ['chain' => 'it is not on ' . $cfg['chains'], 'skip' => 'it is infrastructure (a stable, wrapped or protocol token) or our own', 'young' => 'its biggest pool is younger than ' . (int)$cfg['age'] . ' days', 'small' => 'its liquidity, volume or market cap is under the filters', 'falling' => 'it is down more than ' . (int)$cfg['drop'] . '% today', 'nox' => 'DexScreener lists no X account for it'];
    if (!$c) return ['ok' => false, 'error' => trim((string)($match[0]['baseToken']['name'] ?? $q)) . ' did not pass: ' . ($words[$why] ?? 'it did not pass the filters') . '.'];
    $r = vs_merge([$c['addr'] => $c], 1);
    $sl = ''; foreach (vs_all()['list'] as $k => $x) if ($x['addr'] === $c['addr']) $sl = $k;
    return ['ok' => true, 'added' => $r['added'], 'name' => $c['name'], 'slug' => $sl, 'st' => vs_all()['list'][$sl]['st'] ?? 'new'];
}
// the community's logo, kept on our own server (the page and the card never load DexScreener's CDN for it)
function vs_logo_file($slug) {
    foreach (['png', 'jpg', 'webp', 'gif'] as $e) { $f = VS_LOGOS . '/' . $slug . '.' . $e; if (is_file($f)) return $f; }
    return '';
}
function vs_logo_fetch($slug, $url) {
    if ($f = vs_logo_file($slug)) return $f;
    $ok = preg_match('~^https://cdn\.dexscreener\.com/~', $url) || (!empty(shy_config()['ds_api']) && strpos($url, (string)shy_config()['ds_api']) === 0);
    if (!$ok) return '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4, CURLOPT_USERAGENT => 'shyonsol.io', CURLOPT_FOLLOWLOCATION => false]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false || $code !== 200 || strlen($raw) > 3000000) return '';
    $info = @getimagesizefromstring($raw);
    $ext = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'][$info['mime'] ?? ''] ?? '';
    if ($ext === '' || ($info[0] ?? 0) < 16) return '';
    if (!is_dir(VS_LOGOS)) @mkdir(VS_LOGOS, 0755, true);
    $f = VS_LOGOS . '/' . $slug . '.' . $ext;
    @file_put_contents($f . '.tmp', $raw); @rename($f . '.tmp', $f);
    return is_file($f) ? $f : '';
}
// who is playing for whom. A new profile that opens a challenge link plays for that community; anyone with games
// already on the board is one of ours (they defend the top spots instead).
function vs_member($pid, $d = null) { $d = $d ?? vs_all(); return (string)($d['m'][$pid]['c'] ?? ''); }
function vs_live($c) { return in_array($c['st'] ?? '', ['ok', 'posted'], true); }
// the scoreboard: their players this week against our top three this week
function vs_board($slug, $d = null, $players = null) {
    $d = $d ?? vs_all(); $c = $d['list'][$slug] ?? null;
    if (!$c) return null;
    $players = $players ?? load(PLAYERS); $wk = week_key();
    $ban = function_exists('banned_in') ? banned_in($players) : [];
    $ours = []; $theirs = []; $n = 0;
    foreach ($players as $pid => $p) {
        if (isset($ban[$pid]) || !empty($p['moved']) || empty($p['games']) || ($p['name'] ?? '') === '' || !empty($p['hide'])) continue;
        $pts = ($p['wk'] ?? '') === $wk ? (int)($p['wpts'] ?? 0) : 0;
        $m = (string)($d['m'][$pid]['c'] ?? '');
        if ($m === $slug) { $n++; if ($pts > 0) $theirs[] = ['name' => (string)$p['name'], 'pts' => $pts, 'games' => (int)$p['games']]; }
        elseif ($m === '' && $pts > 0) $ours[] = ['name' => (string)$p['name'], 'pts' => $pts, 'games' => (int)$p['games']];
    }
    usort($ours, fn($a, $b) => $b['pts'] <=> $a['pts']); usort($theirs, fn($a, $b) => $b['pts'] <=> $a['pts']);
    $ours = array_slice($ours, 0, 3); $top = array_slice($theirs, 0, 3);
    $bar = $ours ? end($ours)['pts'] : 0;
    $beat = 0; foreach ($theirs as $t) foreach ($ours as $o) if ($t['pts'] > $o['pts']) $beat = max($beat, 1);
    $sum = array_sum(array_column($theirs, 'pts'));
    return ['slug' => $slug, 'name' => $c['name'], 'sym' => $c['sym'], 'x' => $c['x'], 'tg' => $c['tg'] ?? '', 'url' => $c['url'], 'age' => (int)$c['age'], 'months' => max(1, (int)floor($c['age'] / 30.4)),
        'mc' => (int)$c['mc'], 'logo' => vs_logo_file($slug) !== '' || ($c['img'] ?? '') !== '' ? '/api/vs.php?a=logo&c=' . rawurlencode($slug) : '',
        'ours' => $ours, 'theirs' => $top, 'players' => $n, 'active' => count($theirs), 'sum' => $sum, 'bar' => $bar, 'beat' => (bool)$beat,
        'ends' => strtotime('monday next week 00:00 UTC')];
}
// the card's fingerprint: it changes when anything drawn on the card changes, so X and Telegram fetch the new card
function vs_card_hash($b) { return substr(sha1(json_encode([$b['name'], $b['sym'], $b['months'], array_map(fn($x) => [$x['name'], $x['pts']], $b['ours']), $b['theirs'] ? [$b['theirs'][0]['name'], $b['theirs'][0]['pts']] : 0, $b['players'], 'v1'])), 0, 10); }
// the post the X composer opens with. Four ways to say it, picked by the community so a second look keeps its wording.
function vs_post_text($c, $variant = null) {
    $n = $c['name']; $h = '@' . $c['x']; $mo = max(1, (int)floor(((int)$c['age']) / 30.4));
    $all = [
        'gm ' . $h . '. ' . $mo . ' months in and ' . $n . ' is still standing, respect. Think your holders can beat the Shilluminati leaders? Free card game, plays in the browser, no wallet needed. The board is live:',
        $h . ' a challenge for ' . $n . ' holders: knock the Shilluminati leaders off the top of the board this week. One free hand, no wallet, right in your browser.',
        'Calling ' . $n . ' holders. Our top three are waiting. Play a free hand of Shilluminati for ' . $h . ' and see how high you climb:',
        $n . ' vs $SHY. Your community against our leaders on the Shilluminati board this week. Free to play, no wallet needed. ' . $h . ', you in?',
    ];
    $i = $variant === null ? crc32((string)$c['addr']) % count($all) : ((int)$variant % count($all));
    return $all[$i];
}
function vs_link($slug) { return 'https://shyonsol.io/vs/' . $slug; }
