<?php
//MC 2026-10-23 a tournament's share link (/t/<id>): a tiny page whose preview picture is the event's own card (name,
//   date, prizes, entry, seats), so a post on X or Telegram shows exactly what it is. People who open it land on the
//   Play page's tournament hall to sign up; the crawlers that build link previews read the card from the meta.
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

$id = strtolower((string)($_GET['t'] ?? ''));
$t = preg_match('/^[a-f0-9]{10}$/', $id) ? (tourney_db()['list'][$id] ?? null) : null;
if (!$t) { http_response_code(404); header('Content-Type: text/html; charset=utf-8'); @readfile(dirname(__DIR__) . '/404.html'); exit; }
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$url = tourney_link($t);
$img = tourney_card_url($t);
$title = $t['name'] . ' | Shilluminati Online tournament';
$desc = tourney_pitch($t);
$to = '/play#tourney';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
    . '<title>' . $e($title) . '</title>'
    . '<meta name="description" content="' . $e($desc) . '">'
    . '<meta property="og:type" content="website"><meta property="og:site_name" content="Shy on Solana">'
    . '<meta property="og:title" content="' . $e($title) . '"><meta property="og:description" content="' . $e($desc) . '">'
    . '<meta property="og:url" content="' . $e($url) . '">'
    . '<meta property="og:image" content="' . $e($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
    . '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@ShyOnSol_"><meta name="twitter:title" content="' . $e($title) . '">'
    . '<meta name="twitter:description" content="' . $e($desc) . '"><meta name="twitter:image" content="' . $e($img) . '">'
    . '<link rel="canonical" href="' . $e($url) . '">'
    . '<script>location.replace(' . json_encode($to) . ');</script>'
    . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0620;color:#fff;font:600 17px "Inter",system-ui,sans-serif}a{color:#ff5d73}</style>'
    . '</head><body><p><a href="' . $e($to) . '">Sign up for ' . $e($t['name']) . '</a></p></body></html>';
