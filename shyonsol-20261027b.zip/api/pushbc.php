<?php
//MC 2026-10-18 the important browser notifications, sent from cron: your Shadow back from an expedition, the Daily
//   going live, the weekly reset, a big new Dojo piece, and a timed offer about to leave. Friend requests, game
//   invites and Duel challenges already push the moment they happen (friendslib); this file covers the ones no
//   player's request triggers. The rails against noise: each event is announced exactly once (push-bc.php
//   remembers), at most BC_CAP broadcast knocks per player per UTC day, the Daily call goes only to players who
//   actually play Dailies, nothing broadcasts before the morning hour, and the first run after this ships is a
//   quiet one that only takes a snapshot, so nobody gets a backlog of knocks.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('PUSHBC', DATA_DIR . '/push-bc.php');   // ['seeded', 'daily' => day, 'wk' => week, 'new' => [id => ts], 'end' => [id => ts], 'n' => [pid => [day, count]]]
if (!defined('EXPEDITIONS')) define('EXPEDITIONS', DATA_DIR . '/expeditions.php');
if (!defined('BC_DAILY_RUNS')) define('BC_DAILY_RUNS', DATA_DIR . '/daily-runs.php');
const BC_CAP = 2;            // broadcast knocks per player per day; a Shadow coming home is personal and not counted
const BC_BIG = 5000;         // Koban from which a new Dojo piece is worth a knock
const BC_HOUR = 13;          // nothing broadcast before 13:00 UTC, the same morning hour the Telegram call uses
const BC_EPOCH = '2026-10-06';

function bc_hour() { return (int)(shy_config()['bc_hour'] ?? BC_HOUR); }
function bc_daily_no($day) { return (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime(BC_EPOCH . ' 00:00:00 UTC')) / 86400) + 1; }

// one notice to each of these players and one wake per device. A kind replaces its older self in the notice list,
// so yesterday's Daily call never piles under today's. $cap=false for personal news that should always arrive.
function bc_notify(array $pids, $kind, $data, $cap = true) {
    if (!$pids) return 0;
    $sent = with_lock(function () use ($pids, $kind, $data, $cap) {
        $st = load(PUSHBC); $st = is_array($st) ? $st : [];
        $day = gmdate('Y-m-d'); $ok = [];
        foreach (array_unique($pids) as $pid) {
            $n = $st['n'][$pid] ?? ['', 0];
            if ($n[0] !== $day) $n = [$day, 0];
            if ($cap && $n[1] >= BC_CAP) continue;
            $st['n'][$pid] = [$day, $n[1] + ($cap ? 1 : 0)];
            $ok[] = $pid;
        }
        if (count($st['n'] ?? []) > 4000) $st['n'] = array_slice($st['n'], -2000, null, true);
        save(PUSHBC, $st);
        if ($ok) {
            $all = load(NOTICES);
            foreach ($ok as $pid) {
                $list = array_values(array_filter($all[$pid] ?? [], fn($x) => $x['k'] !== $kind));
                array_unshift($list, ['id' => bin2hex(random_bytes(4)), 'k' => $kind, 'from' => '', 'd' => $data, 'ts' => time(), 'seen' => false]);
                $all[$pid] = array_slice($list, 0, 30);
            }
            save(NOTICES, $all);
        }
        return $ok;
    });
    foreach ($sent as $pid) push_queue($pid, ['k' => $kind]);
    return count($sent);
}

// everything the Dojo sells that a knock could be about: id, name, Koban/USD price, and its sale window
function bc_goods() {
    $cat = eco_catalog(); $out = [];
    foreach (array_merge($cat['items'] ?? [], $cat['offers'] ?? [], $cat['goods'] ?? []) as $it) {
        if (empty($it['id']) || empty($it['name'])) continue;
        $out[] = ['id' => (string)$it['id'], 'name' => (string)$it['name'],
            'kb' => (int)($it['koban'] ?? ($it['koban_price'] ?? 0)), 'usd' => (float)($it['usd'] ?? 0),
            'from' => (int)($it['from'] ?? 0), 'end' => (int)($it['end'] ?? ($it['until'] ?? 0))];
    }
    return $out;
}

function bc_tick() {
    $subs = array_keys(load(PUSHSUBS));
    if (!$subs) return [];
    $o = [];
    // Shadows home from expeditions: personal, uncapped, any hour (there is Koban waiting)
    $back = with_lock(function () use ($subs) {
        $db = load(EXPEDITIONS); $now = time(); $hit = []; $dirty = false;
        foreach ($subs as $pid) {
            foreach ($db[$pid]['act'] ?? [] as $i => $a) {
                if ($now >= (int)($a['end'] ?? 0) && empty($a['pn'])) { $db[$pid]['act'][$i]['pn'] = 1; $dirty = true; $hit[$pid] = ($hit[$pid] ?? 0) + (int)($a['koban'] ?? 0); }
            }
        }
        if ($dirty) save(EXPEDITIONS, $db);
        return $hit;
    });
    $nx = 0;
    foreach ($back as $pid => $k) $nx += bc_notify([$pid], 'expback', ['k' => $k], false);
    if ($nx) $o['exp'] = $nx;
    if ((int)gmdate('G') < bc_hour()) return $o;

    // decide and mark every broadcast under one lock, so a second cron never sends the same thing twice
    $day = gmdate('Y-m-d'); $wk = gmdate('o-W'); $now = time();
    $todo = with_lock(function () use ($day, $wk, $now) {
        $st = load(PUSHBC); $st = is_array($st) ? $st : [];
        $t = ['daily' => false, 'weekly' => false, 'new' => [], 'end' => []];
        $first = empty($st['seeded']);
        if (($st['daily'] ?? '') !== $day) { $st['daily'] = $day; $t['daily'] = !$first; }
        if (($st['wk'] ?? '') !== $wk) { $st['wk'] = $wk; $t['weekly'] = !$first; }
        foreach (bc_goods() as $g) {
            $live = ($g['from'] === 0 || $now >= $g['from']) && ($g['end'] === 0 || $now < $g['end']);
            $big = $g['kb'] >= BC_BIG || $g['usd'] >= 9.99;
            if (!isset($st['new'][$g['id']])) { $st['new'][$g['id']] = $now; if ($big && $live && !$first) $t['new'][] = $g['name']; }
            if ($big && $live && $g['end'] > 0 && $g['end'] - $now <= 48 * 3600 && empty($st['end'][$g['id']])) { $st['end'][$g['id']] = $now; if (!$first) $t['end'][] = $g['name']; }
        }
        $st['seeded'] = 1;
        save(PUSHBC, $st);
        return $t;
    });
    if ($todo['daily']) {
        // only players who ran a Daily in the last ten days hear the morning call
        $dr = load(BC_DAILY_RUNS); $recent = [];
        for ($i = 1; $i <= 10; $i++) foreach (array_keys((array)($dr[gmdate('Y-m-d', $now - $i * 86400)] ?? [])) as $p) $recent[$p] = 1;
        $n = bc_notify(array_values(array_intersect($subs, array_keys($recent))), 'daily', ['no' => bc_daily_no($day)]);
        if ($n) $o['daily'] = $n;
    }
    if ($todo['weekly']) { $n = bc_notify($subs, 'weekly', []); if ($n) $o['weekly'] = $n; }
    if ($todo['new']) { $n = bc_notify($subs, 'shopnew', ['names' => array_slice($todo['new'], 0, 3), 'n' => count($todo['new'])]); if ($n) $o['shopnew'] = $n; }
    if ($todo['end']) { $n = bc_notify($subs, 'shopend', ['name' => $todo['end'][0], 'n' => count($todo['end'])]); if ($n) $o['shopend'] = $n; }
    return $o;
}
