<?php
// Trophies on Solana: the big wins are minted as compressed NFTs to the winner's own wallet.
//
// What earns one: winning the Weekly League, winning a tournament, joining the 15 Club, a Grandmaster card, finishing a
// ranked season in Jade or Shogun, and holding for 90 and 180 days (Diamond Hands, Ancient Holder). Each trophy has a
// fixed id (for example champ-2026-W42-<player>), so the same win can never mint twice, here or at the minting service.
//
// Minting goes through Crossmint's minting API (compressed NFTs on Solana; they pay the network fee and hold no key of
// ours). The team sets the API key and collection in Admin > Shop > Trophies; until then trophies are recorded and wait.
// A winner with no wallet connected keeps theirs waiting too, and it mints the first time a pass finds a wallet.
// Passes run from the site's background tick (a few mints at a time, never inside the site lock) and from cron.
//MC 2026-10-15 first version
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('TROPHIES', DATA_DIR . '/trophies.php');     // id => ['pid', 'kind', 'name', 'desc', 't', 'st' => wait|mint|done|fail, ...]
define('TROPHY_CFG', DATA_DIR . '/trophy-cfg.php'); // ['on', 'key', 'col', 'env' => prod|staging]
const TROPHY_KINDS = [
    'champ'   => ['League Champion', 'Won the Shilluminati Online Weekly League'],
    'cup'     => ['Tournament Champion', 'Won a Shilluminati Online tournament'],
    'club15'  => ['15 Club', 'Won a game holding 15 Regions'],
    'master'  => ['Grandmaster', 'Mastered a Chaos card to Grandmaster'],
    'rkjade'  => ['Jade Ranked', 'Finished a ranked season in Jade'],
    'rkshogun'=> ['Ranked Shogun', 'Finished a ranked season in Shogun'],
    'diamond' => ['Diamond Hands', 'Held a $SHY rank for 90 days'],
    'ancient' => ['Ancient Holder', 'Held a $SHY rank for 180 days'],
    //MC 2026-10-26 the score clubs: all-time points on the leaderboard. The Million Club is the top of the ladder.
    'pts100k' => ['100K Club', 'Scored 100,000 all-time points'],
    'pts250k' => ['250K Club', 'Scored 250,000 all-time points'],
    'pts500k' => ['500K Club', 'Scored 500,000 all-time points'],
    'pts1m'   => ['Million Club', 'Scored 1,000,000 all-time points'],
];
const SCORE_CLUBS = [100000 => 'pts100k', 250000 => 'pts250k', 500000 => 'pts500k', 1000000 => 'pts1m'];
//MC 2026-10-26 a score just went up: every club it crossed is a trophy (minted to their wallet), a title they can wear
//   and a post in the chat. Each club is given once ('once' in the id), so a score that's corrected down and climbs
//   back never earns it twice. Called from both places points are added (lb.php solo and Daily, livelib.php live).
function score_clubs($pid, $before, $after) {
    if ($after <= $before) return [];
    $got = [];
    foreach (SCORE_CLUBS as $at => $kind) if ($before < $at && $after >= $at) $got[] = $kind;
    if (!$got) return [];
    $eco = load(ECO);
    if (isset($eco[$pid]) && function_exists('eco_grant_item')) { $a = eco_get($eco, $pid); foreach ($got as $k) eco_grant_item($a, 'title_' . $k); $eco[$pid] = $a; save(ECO, $eco); }
    foreach ($got as $k) trophy_award($pid, $k, 'once');
    return $got;
}

function trophy_cfg() {
    $c = is_file(TROPHY_CFG) ? load(TROPHY_CFG) : [];
    return ['on' => !empty($c['on']), 'key' => (string)($c['key'] ?? ''), 'col' => (string)($c['col'] ?? 'default-solana'), 'env' => ($c['env'] ?? 'prod') === 'staging' ? 'staging' : 'prod'];
}
function trophy_ready() { $c = trophy_cfg(); return $c['on'] && strlen($c['key']) > 20; }

// a win happened: record its trophy (once). $tag makes it unique (the week, the tournament, the card...). Call anywhere;
// it takes the site lock itself unless the caller already holds it.
function trophy_id($pid, $kind, $tag) { return $kind . '-' . preg_replace('/[^a-z0-9-]/', '', strtolower((string)$tag)) . '-' . substr($pid, 0, 10); }
function trophy_award($pid, $kind, $tag, $what = '') {
    if (!isset(TROPHY_KINDS[$kind]) || !preg_match('/^[a-f0-9]{16}$/', (string)$pid)) return;
    $id = trophy_id($pid, $kind, $tag);
    $fn = function () use ($id, $pid, $kind, $what) {
        $all = load(TROPHIES);
        if (isset($all[$id])) return;
        $all[$id] = ['pid' => $pid, 'kind' => $kind, 'what' => mb_substr((string)$what, 0, 40), 't' => time(), 'st' => 'wait', 'tries' => 0];
        save(TROPHIES, $all);
        if (function_exists('tg_trophy')) tg_trophy($pid, $kind, mb_substr((string)$what, 0, 40));   //MC 2026-10-15 and in the Telegram chat
    };
    (function_exists('lock_depth') && lock_depth() > 0) ? $fn() : with_lock($fn);
}
// the NFT's name (32 characters at most) and description (64)
function trophy_meta($id, $r) {
    [$name, $desc] = TROPHY_KINDS[$r['kind']];
    $n = $name . ($r['what'] !== '' ? ' · ' . $r['what'] : '');
    if (mb_strlen($n) > 32) $n = mb_substr($n, 0, 31) . '…';
    $pl = load(PLAYERS)[$r['pid']]['name'] ?? '';
    $d = $desc . ($pl !== '' ? ' as ' . $pl : '') . '.';
    if (mb_strlen($d) > 64) $d = $desc . '.';
    return ['name' => $n, 'symbol' => 'SHYT', 'description' => $d,
        'image' => 'https://shyonsol.io/assets/art/trophy/' . $r['kind'] . '.png',
        'attributes' => array_values(array_filter([
            ['trait_type' => 'Trophy', 'value' => $name],
            $r['what'] !== '' ? ['trait_type' => 'For', 'value' => $r['what']] : null,
            $pl !== '' ? ['trait_type' => 'Player', 'value' => $pl] : null,
            ['trait_type' => 'Won', 'value' => gmdate('Y-m-d', $r['t'])],
            ['trait_type' => 'Game', 'value' => 'Shilluminati Online'],
        ]))];
}
// one call to the minting API. PUT is idempotent by our trophy id: asking again only reports how it went.
function trophy_call($id, $wallet, $meta) {
    $c = trophy_cfg();
    $host = $c['env'] === 'staging' ? 'https://staging.crossmint.com' : 'https://www.crossmint.com';
    $cfgBase = function_exists('shy_config') ? (string)(shy_config()['trophy_api'] ?? '') : '';   // a test server, set only in a test config
    $url = ($cfgBase !== '' ? $cfgBase : $host) . '/api/2022-06-09/collections/' . rawurlencode($c['col']) . '/nfts/' . rawurlencode('shy-' . $id);
    $body = json_encode(['recipient' => 'solana:' . $wallet, 'metadata' => $meta, 'compressed' => true, 'reuploadLinkedFiles' => true, 'sendNotification' => false], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => 'PUT', CURLOPT_POSTFIELDS => $body, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-API-KEY: ' . $c['key']]]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    return ['code' => $code, 'j' => is_array($j) ? $j : []];
}
// a pass: up to $n trophies sent or checked. Network outside the lock, results saved inside it.
//MC 2026-10-15 $report: hand back what happened (for the admin's Send now button) instead of a count
function trophy_tick($n = 3, $force = false, $report = false) {
    $rep = ['ready' => trophy_ready(), 'sent' => 0, 'done' => 0, 'mint' => 0, 'err' => [], 'nowallet' => [], 'later' => 0];
    if (!trophy_ready()) return $report ? $rep : 0;
    $sf = DATA_DIR . '/trophy-tick.php';
    if (!$force && time() - (int)(load($sf)['t'] ?? 0) < 90) return $report ? $rep : 0;
    save($sf, ['t' => time()]);
    $all = load(TROPHIES); $holders = load(HOLDERS);
    $todo = [];
    foreach ($all as $id => $r) {
        if ($r['st'] === 'done' || $r['st'] === 'fail') continue;
        if (!$force && time() - (int)($r['next'] ?? 0) < 0) { $rep['later']++; continue; }   // a press of Send now tries everything waiting
        $w = $r['wallet'] ?? ($holders[$r['pid']]['wallet'] ?? '');
        if (!$w || !valid_wallet($w)) { $rep['nowallet'][$r['pid']] = 1; continue; }   // waits for a connected wallet
        $todo[$id] = $w;
        if (count($todo) >= $n) break;
    }
    $res = [];
    foreach ($todo as $id => $w) {
        $r = $all[$id];
        $x = trophy_call($id, $r['wallet'] ?? $w, trophy_meta($id, $r));   // a trophy keeps the wallet it was first sent to
        $res[$id] = $x + ['w' => $r['wallet'] ?? $w];
    }
    if (!$res) return $report ? $rep : 0;
    with_lock(function () use ($res, &$rep) {
        $all = load(TROPHIES);
        foreach ($res as $id => $x) {
            if (!isset($all[$id])) continue;
            $r = &$all[$id];
            $r['tries'] = (int)$r['tries'] + 1; $r['wallet'] = $x['w']; $r['last'] = time();
            $on = $x['j']['onChain'] ?? [];
            if ($x['code'] >= 200 && $x['code'] < 300) {
                unset($r['err']);
                if (($on['status'] ?? '') === 'success' && !empty($on['mintHash'])) { $r['st'] = 'done'; $r['mint'] = $on['mintHash']; $r['tx'] = $on['txId'] ?? ''; $rep['done']++; }
                else { $r['st'] = 'mint'; $r['next'] = time() + 120; $rep['mint']++; }   // accepted, still minting: ask again in a bit
            } elseif ($x['code'] === 400 || $x['code'] === 403) {
                $r['err'] = mb_substr((string)($x['j']['message'] ?? ('HTTP ' . $x['code'])), 0, 200); $rep['err'][] = $r['err'];
                $r['next'] = time() + 6 * 3600;   // a settings problem: the team sees it in the admin; try again later
                if ($r['tries'] >= 8) $r['st'] = 'fail';
            } else { $r['err'] = $x['code'] ? 'HTTP ' . $x['code'] . (!empty($x['j']['message']) ? ': ' . mb_substr((string)$x['j']['message'], 0, 150) : '') : 'Crossmint could not be reached'; $rep['err'][] = $r['err']; $r['next'] = time() + min(3600, 60 * (1 << min(6, $r['tries']))); }
            unset($r);
        }
        save(TROPHIES, $all);
    });
    $rep['sent'] = count($res);
    return $report ? $rep : count($res);
}
// a player's trophies, newest first, for their profile and player page
function trophies_of($pid) {
    $out = [];
    foreach (load(TROPHIES) as $id => $r) if ($r['pid'] === $pid) $out[] = ['kind' => $r['kind'], 'name' => TROPHY_KINDS[$r['kind']][0], 'what' => $r['what'], 't' => $r['t'], 'st' => $r['st'], 'mint' => $r['mint'] ?? ''];
    usort($out, fn($a, $b) => $b['t'] <=> $a['t']);
    return $out;
}

//MC 2026-10-15 trophies for wins from before trophies existed. Reads the records the site already keeps and lists every
//   trophy they earn, with the same id the live hook would have used, so nothing can be awarded twice (here, by a later
//   run, or by the hook itself):
//     League Champion   1st place in every closed Weekly League (rewards file), and the top of each filed weekly board
//                       from before the League paid prizes
//     Tournament        the champion of every finished tournament
//     15 Club           everyone in the 15 Club
//     Grandmaster       every card an account mastered to level 5
//     Ranked            every past season finished in Jade or Shogun
//     Diamond / Ancient the Diamond Hands and Ancient Holder titles already earned
//   Returns [[pid, kind, tag, what, id, had], ...]; had is true when that trophy is already recorded.
function trophy_backfill_list() {
    $out = []; $have = load(TROPHIES); $seen = [];
    $add = function ($pid, $kind, $tag, $what) use (&$out, &$seen, $have) {
        if (!preg_match('/^[a-f0-9]{16}$/', (string)$pid)) return;
        $id = trophy_id($pid, $kind, $tag);
        if (isset($seen[$id])) return; $seen[$id] = 1;
        $out[] = [$pid, $kind, (string)$tag, mb_substr((string)$what, 0, 40), $id, isset($have[$id])];
    };
    $rw = load(REWARDS);
    foreach ($rw['weeks'] ?? [] as $wk => $w) foreach (array_merge($w['league'] ?? [], $w['lkx'] ?? []) as $r)
        if ((int)($r['place'] ?? 0) === 1 && !empty($r['pid'])) $add($r['pid'], 'champ', $wk, 'Week ' . preg_replace('/^\d{4}-W?/', '', $wk));
    // weeks from before the League paid prizes: the top of each filed weekly board
    $paidWk = array_flip(array_keys((array)($rw['weeks'] ?? [])));
    foreach (load(WEEKS) as $wk => $w) {
        if (isset($paidWk[$wk]) || $wk === week_key() || empty($w['rows'])) continue;
        $rows = $w['rows']; usort($rows, fn($x, $y) => (int)($y['pts'] ?? 0) <=> (int)($x['pts'] ?? 0));
        if (!empty($rows[0]['pid']) && (int)($rows[0]['pts'] ?? 0) > 0) $add($rows[0]['pid'], 'champ', $wk, 'Week ' . preg_replace('/^\d{4}-W?/', '', $wk));
    }
    if (function_exists('tourney_db')) foreach (tourney_db()['list'] as $tid => $t)
        if (($t['status'] ?? '') === 'done' && ($t['champ'] ?? '') !== '') $add($t['champ'], 'cup', $t['id'] ?? $tid, mb_substr((string)($t['name'] ?? ''), 0, 24));
    if (function_exists('bounty_db')) foreach (bounty_db()['club'] as $pid => $c) $add($pid, 'club15', 'once', '');
    foreach (load(PLAYERS) as $pid => $p) foreach (SCORE_CLUBS as $at => $k) if ((int)($p['points'] ?? 0) >= $at) $add($pid, $k, 'once', '');   //MC 2026-10-26 the score clubs
    $eco = load(ECO); $hold = null;
    foreach ($eco as $pid => $a) {
        foreach ($a['cml'] ?? [] as $c => $lv) if ((int)$lv >= 5) $add($pid, 'master', $c, function_exists('deck_card') ? (deck_card($c)['name'] ?? $c) : $c);
        foreach (['title_diamond' => 'diamond', 'title_ancient' => 'ancient'] as $it => $k) if (isset($a['items'][$it])) {
            $hold = $hold ?? load(HOLDERS); $w = $hold[$pid]['wallet'] ?? '';
            if ($w !== '') $add($pid, $k, substr($w, 0, 12), '');
        }
    }
    foreach (load(PLAYERS) as $pid => $p) foreach ($p['rkh'] ?? [] as $sk => $h) {
        $sn = (int)ltrim((string)$sk, 's');
        if (in_array($h['tier'] ?? '', ['jade', 'shogun'], true)) $add($pid, $h['tier'] === 'jade' ? 'rkjade' : 'rkshogun', 's' . $sn, 'Season ' . $sn);
    }
    usort($out, fn($a, $b) => [$a[5], $a[1]] <=> [$b[5], $b[1]]);
    return $out;
}
// record a batch in one save (inside the site lock). Returns how many were new.
//MC 2026-10-15 $announce: post each new one to Telegram (trophies given by hand)
function trophy_award_many($list, $announce = false) {
    $fn = function () use ($list, $announce) {
        $all = load(TROPHIES); $n = 0;
        foreach ($list as [$pid, $kind, $tag, $what]) {
            if (!isset(TROPHY_KINDS[$kind]) || !preg_match('/^[a-f0-9]{16}$/', (string)$pid)) continue;
            $id = trophy_id($pid, $kind, $tag);
            if (isset($all[$id])) continue;
            $all[$id] = ['pid' => $pid, 'kind' => $kind, 'what' => mb_substr((string)$what, 0, 40), 't' => time(), 'st' => 'wait', 'tries' => 0];
            $n++;
            if ($announce && function_exists('tg_trophy')) tg_trophy($pid, $kind, mb_substr((string)$what, 0, 40));
        }
        if ($n) save(TROPHIES, $all);
        return $n;
    };
    return (function_exists('lock_depth') && lock_depth() > 0) ? $fn() : with_lock($fn);
}

