<?php
//MC 2026-10-24 Living Shadows: every Shytoshi Shadow cut out of its square, so the game can lift the figure off its
//   picture and have it play a card (assets/shadowplay.js). The cutting runs on GitHub's machines
//   (checks/shadow_cut.py in the releases repo, every six hours): it asks here which Shadows still need a cut, cuts
//   them and sends each one back. Only Shadows the site has met (a holder connected it) are ever listed.
// GET  ?a=todo&k=                   the Shadows still waiting for a cut (cutter only)
// POST a=put k= n= meta= img=<file> one finished cut (cutter only)
// GET  ?n=                          a Shadow's cut: how to dress and fit it ({ok, has, col, dark, sl, sr, ar, v})
// GET  ?n=&img=1                    the cut itself (webp with transparency)
// GET  ?n=&dep=1                    its depth map (grey webp, near is bright), when the cut has one
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require_once dirname(__DIR__) . '/admin/deploy.php';   // deploy_key: the cutter's key is derived from it

define('CUT_DIR', DATA_DIR . '/cuts');
define('CUT_META', DATA_DIR . '/cuts.php');
const CUT_MAX = 700 * 1024;
function cut_key() { return hash_hmac('sha256', 'shadow-cut', deploy_key()); }
function cut_ok_n($n) { return preg_match('/^\d{1,5}$/', (string)$n) ? (string)(int)$n : ''; }
function cut_json($a, $code = 200) { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff'); echo json_encode($a); exit; }

$in = $_POST + $_GET;
$a = (string)($in['a'] ?? '');

if ($a === 'todo' || $a === 'put') {
    if (!hash_equals(cut_key(), (string)($in['k'] ?? ''))) cut_json(['ok' => false, 'error' => 'wrong key'], 403);
    if ($a === 'todo') {
        $reg = load(SHADOWREG); $meta = load(CUT_META); $rows = [];
        foreach ((is_array($reg) ? $reg : []) as $n => $r) {
            $img = (string)($r['img'] ?? '');
            if ($img === '' || strpos($img, 'https://') !== 0) continue;
            if (isset($meta[$n]) && ($meta[$n]['src'] ?? '') === $img && !empty($meta[$n]['d'])) continue;   // cut already, from this same picture, with its depth
            $rows[] = ['n' => (string)$n, 'img' => $img];
            if (count($rows) >= 300) break;
        }
        cut_json(['ok' => true, 'rows' => $rows]);
    }
    $n = cut_ok_n($in['n'] ?? '');
    $reg = load(SHADOWREG);
    if ($n === '' || empty($reg[$n]['img'])) cut_json(['ok' => false, 'error' => 'unknown Shadow'], 400);
    $f = $_FILES['img'] ?? null;
    $raw = $f && is_uploaded_file($f['tmp_name']) ? (string)file_get_contents($f['tmp_name']) : '';
    if ($raw === '' || strlen($raw) > CUT_MAX || substr($raw, 0, 4) !== 'RIFF' || substr($raw, 8, 4) !== 'WEBP') cut_json(['ok' => false, 'error' => 'not a webp'], 400);
    $m = json_decode((string)($in['meta'] ?? ''), true);
    $hex = fn($c) => preg_match('/^#[0-9a-f]{6}$/', (string)$c) ? (string)$c : '#2a2a32';
    $clip = fn($v, $lo, $hi) => max($lo, min($hi, (float)$v));
    //MC 2026-10-24 the depth map (near is bright), so the figure can turn in 3D on the table
    $df = $_FILES['dep'] ?? null;
    $dep = $df && is_uploaded_file($df['tmp_name']) ? (string)file_get_contents($df['tmp_name']) : '';
    if ($dep !== '' && (strlen($dep) > CUT_MAX || substr($dep, 0, 4) !== 'RIFF' || substr($dep, 8, 4) !== 'WEBP')) $dep = '';
    $row = ['col' => $hex($m['col'] ?? ''), 'dark' => $hex($m['dark'] ?? ''), 'sl' => $clip($m['sl'] ?? .1, 0, .5), 'sr' => $clip($m['sr'] ?? .9, .5, 1), 'ar' => $clip($m['ar'] ?? 1, .3, 3),
        'src' => (string)$reg[$n]['img'], 'v' => substr(sha1($raw . $dep), 0, 8), 't' => time(), 'd' => $dep !== '' ? 1 : 0];
    if (!is_dir(CUT_DIR)) @mkdir(CUT_DIR, 0755, true);
    if (@file_put_contents(CUT_DIR . '/' . $n . '.webp', $raw) === false) cut_json(['ok' => false, 'error' => 'could not save'], 500);
    if ($dep !== '') @file_put_contents(CUT_DIR . '/' . $n . '-d.webp', $dep); else @unlink(CUT_DIR . '/' . $n . '-d.webp');
    with_lock(function () use ($n, $row) { $all = load(CUT_META); $all = is_array($all) ? $all : []; $all[$n] = $row; save(CUT_META, $all); });
    cut_json(['ok' => true, 'n' => $n, 'v' => $row['v']]);
}

$n = cut_ok_n($in['n'] ?? '');
if ($n === '') cut_json(['ok' => false, 'error' => 'which Shadow?'], 400);
$meta = load(CUT_META); $m = is_array($meta) ? ($meta[$n] ?? null) : null;
if (!empty($in['img']) || !empty($in['dep'])) {
    $p = CUT_DIR . '/' . $n . (!empty($in['dep']) ? '-d' : '') . '.webp';
    if (!$m || !is_file($p)) { http_response_code(404); exit; }
    header('Content-Type: image/webp'); header('Cache-Control: public, max-age=31536000, immutable'); header('X-Content-Type-Options: nosniff');
    header('Content-Length: ' . filesize($p)); readfile($p); exit;
}
header('Cache-Control: public, max-age=300');
if (!$m) cut_json(['ok' => true, 'has' => false]);
cut_json(['ok' => true, 'has' => true, 'col' => $m['col'], 'dark' => $m['dark'], 'sl' => $m['sl'], 'sr' => $m['sr'], 'ar' => $m['ar'], 'v' => $m['v'], 'd' => !empty($m['d'])]);
