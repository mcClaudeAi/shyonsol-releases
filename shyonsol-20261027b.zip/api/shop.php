<?php
// Shilluminati shop and rewards API.
// GET  ?a=catalog | ?a=rewards
// POST {a: me|buy|equip|claim|quote|check|claim-tx|card|rpc|history, pid, key, ...}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/xtasks.php';
if (is_file(__DIR__ . '/tg.php')) require_once __DIR__ . '/tg.php';   //MC 2026-10-24 Imperial claims post to the chat


$a = $_GET['a'] ?? '';

// ---------------------------------------------------------------- public reads
function catalog_public() {
    $cat = eco_catalog();
    $set = eco_settings();
    $now = time();
    $offers = array_values(array_filter($cat['offers'], fn($o) => (empty($o['until']) || strtotime($o['until'] . ' 23:59:59 UTC') > $now) && (empty($o['end']) || $o['end'] > $now) && (empty($o['from']) || $o['from'] <= $now)));
    //MC 2026-10-16 'end' is an exact time (the weekend bundle ends at midnight Eastern, not UTC); 'shyOnly' keeps the checkout to $SHY
    foreach ($offers as &$o) { if (!empty($o['until'])) $o['ends'] = strtotime($o['until'] . ' 23:59:59 UTC'); if (!empty($o['end'])) $o['ends'] = (int)$o['end']; if (!empty($o['shy_only'])) $o['shyOnly'] = true; }
    unset($o);
    $s = season_no(); [$s0, $s1] = season_bounds($s);
    $c = shy_config();
    return ['packs' => $cat['packs'], 'offers' => $offers, 'items' => $cat['items'], 'scroll' => scroll_rewards(), 'tiers' => SCROLL_TIERS, 'tierXp' => TIER_XP,
        'season' => ['n' => $s, 'start' => $s0, 'end' => $s1], 'weekEnd' => week_end_ts(), 'now' => $now,
        'mw' => mw_address(), 'shyBonus' => SHY_BONUS, 'open' => !empty($set['shop_open']),
        'shyPx' => price_usd(SHY_MINT), 'burnPct' => (int)$set['burn_pct'],   //MC 2026-10-10 prices shown in $SHY, and the burn on $SHY payments
        'card' => !empty($c['stripe_secret']), 'currencies' => ['SHY' => SHY_MINT, 'SOL' => SOL_MINT, 'USDC' => USDC_MINT],
        'event' => event_now(), 'holderTiers' => $set['htiers'], 'stipend' => $set['hstip'], 'ladder' => HOLDER_LADDER, 'holderPerks' => HOLDER_PERKS, 'holderNames' => HOLDER_NAMES, 'circles' => HOLDER_CIRCLE, 'goods' => $cat['goods'], 'missions' => missions_public(),
        'finishes' => finishes_priced(), 'shelf' => finish_shelf(), 'prem' => finish_prem(), 'collection' => COLLECTION, 'mastery' => MASTERY, 'masteryNames' => MASTERY_NAMES,
        'today' => shop_today(), 'bundle' => bundle_now(), 'seasonCards' => season_cards(), 'deck' => deck_cards(),
        'drops' => drops_public(),   //MC 2026-10-13 limited finish drops
        'holderDisc' => array_map(fn($p) => $p['disc'], HOLDER_PERKS),
        'gift' => ['day' => GIFT_KOBAN, 'sunday' => GIFT_SUNDAY, 'moon' => MOON_DAILY], 'bountyKoban' => BOUNTY_KOBAN, 'xpBoost' => XP_BOOST,
        'bounties' => array_map(fn($id) => ['id' => $id] + BOUNTIES[$id], bounties_week()), 'pool' => pool_share_now(),
        'imp' => ['ids' => imp_ids(), 'n' => (object)imp_stats()['n'], 'steps' => imp_steps(), 'ranks' => IMP_RANK_N]];   //MC 2026-10-24 the Imperial Vault
}
// how much of this week's shop sales goes into next week's League prize pool so far
function pool_share_now() {
    $set = eco_settings(); $rw = load(REWARDS);
    $pct = prize_sales() ? prize_cfg('league')['pct'] : (float)$set['league_share'];   //MC 2026-10-12 the % from Prize budget in 'sales' mode
    return ['pct' => $pct, 'usd' => round(($rw['rev'][week_key()] ?? 0) * $pct / 100, 2)];
}
//MC 2026-10-09 every Play page asks for the reward boards, and building them reads the whole player list. The boards are
//   kept for 15 seconds (one file), with each player's own spot looked up from the kept copy.
function rewards_public($tag = '') {
    $cf = DATA_DIR . '/cache-rewards.php';
    $c = load($cf);
    $src = load_sig(REWARDS) . '|' . load_sig(ECOSET);   // a payout or a settings change in the admin shows at once
    if (!$c || ($c['t'] ?? 0) < time() - 15 || ($c['wk'] ?? '') !== week_key() || ($c['src'] ?? '') !== $src) {
        $c = rewards_build() + ['src' => $src];
        with_lock(function () use ($cf, $c) { save($cf, $c); });
    }
    $r = $c['r'];
    foreach (['league', 'cup', 'seasonBoard'] as $k) { $m = $c['mine'][$k][$tag] ?? null; $r[$k]['me'] = $m ? ['rank' => $m[0], 'pts' => $m[1], 'n' => $m[2], 'ok' => (bool)$m[3], 'w' => (bool)$m[4]] : null; }
    $r['now'] = time();
    return $r;
}
function rewards_build() {
    $set = eco_settings();
    [$players, $holders, $rw] = with_lock(function () { $pl = load(PLAYERS); archive_weeks($pl); rewards_freeze($pl); return [$pl, load(HOLDERS), load(REWARDS)]; });
    $strip = function ($rows, $n) { return array_map(fn($r) => ['tag' => $r['tag'], 'name' => $r['name'], 'pts' => $r['pts'], 'n' => $r['n'], 'ok' => $r['ok'], 'w' => $r['wallet'] !== '', 'tier' => holder_key_new($r['tier']), 'avatar' => $r['avatar'], 'img' => $r['avatar'] ? shadow_img($r['avatar']) : '', 'cos' => $r['cos']], array_slice($rows, 0, $n)); };
    $lg = league_rows($players, $holders, 'league');
    $cup = league_rows($players, $holders, 'cup');
    $sea = league_rows($players, $holders, 'season');
    $pool = league_pool_usd();
    $shyPx = price_usd(SHY_MINT);
    $mine = function ($rows) { $o = []; foreach ($rows as $i => $r) $o[$r['tag']] = [$i + 1, $r['pts'], $r['n'], $r['ok'] ? 1 : 0, $r['wallet'] !== '' ? 1 : 0]; return $o; };
    $past = [];
    foreach (array_slice($rw['weeks'] ?? [], 0, 6, true) as $wk => $w) {
        $past[] = ['wk' => $wk, 'status' => $w['status'], 'pool' => $w['pool']['total'] ?? 0,
            'winners' => array_map(fn($x) => ['place' => $x['place'], 'name' => $x['name'], 'usd' => $x['usd'], 'shy' => $x['shy'] ?? null, 'sig' => $x['sig'] ?? ''], $w['league'])];
    }
    $s = season_no(); [, $send] = season_bounds($s);
    return ['t' => time(), 'wk' => week_key(), 'mine' => ['league' => $mine($lg), 'cup' => $mine($cup), 'seasonBoard' => $mine($sea)],
      'r' => ['ok' => true, 'week' => week_key(), 'weekEnd' => week_end_ts(), 'now' => time(), 'season' => $s, 'seasonEnd' => $send, 'shyPx' => $shyPx,
        //MC 2026-10-12 pools from shop sales; cash: places paid in $SHY, koban: each place's Koban including what the places below cash win instead
        'league' => ['pool' => $pool, 'split' => $set['league_split'], 'rows' => $strip($lg, 25), 'total' => count($lg), 'me' => null, 'cash' => cash_top('league'), 'koban' => prize_kob_public($set['league_split'], $pool['total'], $set['league_koban'], 'league')],
        'cup' => ['pool' => $cupPool = cup_pool_usd(), 'split' => $set['cup_split'], 'rows' => $strip($cup, 10), 'total' => count($cup), 'me' => null, 'cash' => cash_top('cup'), 'koban' => prize_kob_public($set['cup_split'], $cupPool, $set['cup_koban'] ?? [], 'cup')],
        'seasonBoard' => ['pool' => season_pool_usd(), 'split' => $set['season_split'], 'rows' => $strip($sea, 10), 'total' => count($sea), 'me' => null, 'cash' => cash_top('season'), 'koban' => prize_kob_public($set['season_split'], season_pool_usd(), [], 'season')],
        'sales' => prize_sales(),
        'minGames' => $set['min_games'], 'event' => event_now(), 'past' => $past, 'liveCap' => 10]];
}
if ($a === 'catalog') out(['ok' => true] + catalog_public());
if ($a === 'rewards') out(rewards_public(preg_match('/^[a-f0-9]{6}$/', (string)($_GET['me'] ?? '')) ? $_GET['me'] : ''));

// ---------------------------------------------------------------- player actions
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 6000) fail('too large');
$body = json_decode($raw, true) ?: [];
$a = (string)($body['a'] ?? '');
$pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);

function limit_or_fail($what, $max, $window) {
    $ok = with_lock(function () use ($what, $max, $window) { $l = load(LIMITS); $ok = rate_ok($l, $what . ':' . client_ip(), $max, $window); save(LIMITS, $l); return $ok; });
    if (!$ok) fail('Slow down a little and try again.', 429);
}
//MC 2026-10-11 a payment for the team to look at (Admin > Shop > Payment help); one ticket per payment and player
function pay_help_open($pid, $sig, $want, $orders, $why, $note) {
    $new = false;
    $id = with_lock(function () use ($pid, $sig, $want, $orders, $why, $note, &$new) {
        $f = DATA_DIR . '/pay-help.php'; $t = load($f);
        foreach ($t as $id => $x) if ($x['sig'] === $sig && $x['pid'] === $pid) return $id;
        $id = bin2hex(random_bytes(5)); $new = true;
        $t[$id] = ['pid' => $pid, 'sig' => $sig, 'order' => $want, 'orders' => $orders, 'why' => $why, 'note' => $note, 'ts' => time(), 'status' => 'open'];
        $all = load(ORDERS); foreach ($orders as $o) if (isset($all[$o]) && $all[$o]['status'] !== 'paid') $all[$o]['issue'] = $why;
        save(ORDERS, $all);
        save($f, array_slice($t, -300, null, true));
        return $id;
    });
    if ($new) alert_needs('a late payment', 'A payment landed after its 20-minute price hold and no longer covers the price, so it was not delivered on its own.', [['Player', m_player($pid)], ['Transaction', m_tx($sig)], ['Order', mh($want)], ['Request', mh('#' . $id)]], '/admin/?tab=shop#payhelp');
    return $id;
}
// Why a payment failed on Solana, in plain words. The chain's error looks like {"InstructionError":[1,{"Custom":1}]}.
function fail_reason($why, $o) {
    if (stripos($why, 'InsufficientFundsForFee') !== false) return 'fee';
    if (stripos($why, 'InsufficientFundsForRent') !== false) return 'rent';
    if (preg_match('/"Custom":1\b/', $why) || stripos($why, 'InsufficientFunds') !== false) return ($o['cur'] ?? '') === 'SOL' ? 'sol' : 'token';
    if (stripos($why, 'InvalidAccountData') !== false && ($o['cur'] ?? '') !== 'SOL') return 'token';   // the wallet has no account for that coin on Solana
    return '';
}
function fail_msg($why, $o) {
    $cur = $o['cur'] ?? '';
    $amt = isset($o['units'], $o['dec']) ? rtrim(rtrim(number_format($o['units'] / (10 ** $o['dec']), min(6, (int)$o['dec']), '.', ','), '0'), '.') : '';
    $tail = ' Nothing was taken except a tiny network fee.';
    switch (fail_reason($why, $o)) {
        case 'token': return "The wallet didn't have enough $cur. This purchase needs $amt $cur." . $tail . ' Top up the wallet, or pay with a different coin.';
        case 'sol': return "The wallet didn't have enough SOL. This purchase needs $amt SOL plus a tiny network fee." . $tail;
        case 'fee': case 'rent': return 'The wallet needs a little SOL to pay the Solana network fee, even when paying with ' . ($cur === 'SOL' ? 'SOL' : $cur) . '. About 0.001 SOL is plenty.' . $tail;
    }
    return 'The payment failed on Solana.' . $tail . ' Try again, and make sure the wallet has a little SOL for the fee.';
}
// the player's full shop state
function me_view($pid, $eco = null, $holders = null) {
    $eco = $eco ?? load(ECO); $holders = $holders ?? load(HOLDERS);
    $acc = eco_get($eco, $pid);
    eco_dev_grant($acc, $pid);   //MC 2026-10-12 shows the Dev collection as owned before it's first saved
    $h = $holders[$pid] ?? null;
    $tier = holder_tier($h);
    $own = eco_owned($acc, $tier);
    $orders = array_values(array_filter(load(ORDERS), fn($o) => $o['pid'] === $pid));
    usort($orders, fn($x, $y) => $y['ts'] <=> $x['ts']);
    $stip = holder_stip($tier, $h);   //MC 2026-10-10 a Shadow in the wallet keeps the Shadow stipend as the floor
    missions_week_init($acc);
    $bq = bundle_quote($acc, bundle_now());
    return ['koban' => $acc['koban'], 'owned' => array_keys($own), 'eq' => $acc['eq'], 'scroll' => ['s' => $acc['sc']['s'], 'xp' => $acc['sc']['xp'], 'prem' => $acc['sc']['prem'], 'plus' => !empty($acc['sc']['plus']), 'cf' => $acc['sc']['cf'], 'cp' => $acc['sc']['cp']],
        'vf' => (object)$acc['vf'], 'veq' => (object)$acc['veq'], 'cm' => (object)$acc['cm'], 'cml' => (object)$acc['cml'], 'cl' => $acc['cl'], 'colPts' => collection_points($acc),
        'boostXp' => (int)($acc['boost']['xp'] ?? 0), 'gift' => gift_today($acc, $tier) + ['ok' => !empty(load(PLAYERS)[$pid]['games']) || $tier !== '' || !empty($h['wallet'])], 'moon' => (int)($acc['moon'] ?? 0), 'fp' => array_keys($acc['fp']),
        'bundle' => ['left' => $bq['left'], 'full' => $bq['full'], 'price' => koban_price($bq['price'], $tier), 'parts' => count($bq['parts'])],
        'rr' => ['banked' => (int)($acc['rrb'] ?? 0), 'free' => $acc['sc']['prem'] && empty($acc['ms']['free'])], 'disc' => holder_discount($tier),
        'streak' => $acc['st'], 'saver' => (int)($acc['saver'] ?? 0), 'missions' => missions_mine($acc), 'once' => array_keys($acc['once']), 'ledger' => array_slice($acc['ledger'], 0, 30),
        'since' => (int)$acc['since'],   //MC 2026-10-13 the shop shows the Starter Pack banner to accounts in their first week
        'dropn' => (object)($acc['dropn'] ?? []),   //MC 2026-10-13 drop id => the copy number this player owns
        'wallet' => $h['wallet'] ?? '', 'tier' => $tier, 'shy' => isset($h['shy_bal']) ? ['bal' => $h['shy_bal'], 'usd' => $h['shy_usd'] ?? 0] : null,
        //MC 2026-10-11 also shows as collected when this wallet collected on another profile this week
        'stipend' => $tier ? ['koban' => $stip, 'claimed' => ($acc['stip'] ?? '') === week_key() || wallet_stip_taken($h, $tier), 'free' => holder_perks($tier)['free']] : null,
        'next' => $h && !empty($h['wallet']) ? holder_next($h) : null, 'shyb' => SHY_BONUS + holder_perks($tier)['shyb'],
        'loyal' => loyalty_of($h, $tier),   //MC 2026-10-15 time held at your rank, the bonus it adds, the next step
        'xt' => xtasks_mine($acc, $pid, $tier),
        'reacts' => eco_reacts($acc, $tier), 'public' => eco_public($acc, $tier), 'page' => page_public($acc, $tier), 'pg' => $acc['pg'] ?? (object)[],
        'orders' => array_map('order_row', array_slice($orders, 0, 20)),
        'imp' => (object)($acc['imp'] ?? []), 'impN' => imp_count($acc)];   //MC 2026-10-24 your Imperial numbers and how many pieces you hold
}
// run fn(&$eco, &$acc) with the account locked; saves when fn returns without 'err'
function with_account($pid, $kh, $fn) {
    $res = with_lock(function () use ($pid, $kh, $fn) {
        if (!key_ok($pid, $kh)) return ['err' => 'not your profile', 'code' => 403];
        $eco = load(ECO);
        $acc = eco_get($eco, $pid);
        eco_dev_grant($acc, $pid);   //MC 2026-10-12 the Dev collection
        if (empty($eco[$pid])) { $acc['kh'] = $kh; if (!keys_known($pid)) key_add($pid, $kh); }   //MC 2026-10-11 into keys.php too (keys_migrate_once)
        $holders = load(HOLDERS);
        $tier = holder_tier($holders[$pid] ?? null);
        $isNew = empty($eco[$pid]);
        $r = $fn($acc, $tier);
        if (!isset($r['err']) && !$isNew) loyalty_grant($acc, $holders[$pid] ?? null, $tier, $pid);   //MC 2026-10-15 Diamond Hands / Ancient Holder titles
        if (isset($r['err'])) return $r;
        // nothing happened on a profile the shop has never seen: don't create an empty account for it
        if (!($isNew && !$r)) { $eco[$pid] = $acc; save(ECO, $eco); }
        return ($r ?: []) + ['me' => me_view($pid, $eco, $holders)];
    });
    if (isset($res['err'])) { $code = $res['code'] ?? 400; unset($res['code']); $res['error'] = $res['err']; unset($res['err']); out(['ok' => false] + $res, $code); }
    out(['ok' => true] + $res);
}

//MC 2026-10-11 a banned profile can look at its shop but not buy, claim or quote (a paid order can still be checked)
if (!in_array($a, ['me', 'check', 'claim-tx'], true) && player_banned($pid)) fail(BANNED_MSG, 403);

if ($a === 'me') {
    $res = with_lock(function () use ($pid, $kh) {
        if (!key_ok($pid, $kh)) return ['err' => 'not your profile'];
        return ['me' => me_view($pid)];
    });
    if (isset($res['err'])) fail($res['err'], 403);
    out(['ok' => true] + $res + ['catalogVersion' => SCROLL_TIERS . '-' . season_no()]);
}

if ($a === 'buy') {
    limit_or_fail('buy', 60, 600);
    $id = (string)($body['item'] ?? '');
    with_account($pid, $kh, function (&$acc, $tier) use ($id, $pid) {
        if (!eco_settings()['shop_open']) return ['err' => 'The shop is closed for a moment. Try again soon.'];
        $pay = function ($price, $what) use (&$acc) {
            if ($acc['koban'] < $price) return ['err' => 'Not enough Koban.', 'need' => $price - $acc['koban']];
            eco_credit($acc, -$price, $what);
            return null;
        };
        if ($id === 'scroll') {
            if ($acc['sc']['prem']) return ['err' => 'You already have this season\'s Scroll.'];
            if ($e = $pay((int)(array_column(eco_catalog()['offers'], 'koban_price', 'id')['scroll'] ?? 2850), 'Season Scroll')) return $e;   //MC 2026-10-10 charged 950 while the shop showed 2,850 (the price list moved in r, this line didn't)
            $acc['sc']['prem'] = true;
            return ['bought' => 'scroll'];
        }
        if ($g = eco_good($id)) {
            if ($id === 'saver' && (int)($acc['saver'] ?? 0) >= $g['max']) return ['err' => 'You already hold ' . $g['max'] . ' Streak Savers, the most you can keep.'];
            if ($id === 'skip' && intdiv($acc['sc']['xp'], TIER_XP) >= SCROLL_TIERS) return ['err' => 'Your Scroll is already complete this season.'];
            if ($id === 'bounty') { missions_week_init($acc); if (!empty($acc['ms']['b'])) return ['err' => 'Your Bounty Board is already open this week.']; }
            if ($e = $pay(koban_price($g['koban'], $tier, true), $g['name'])) return $e;
            grant_boost($acc, $id);
            return ['bought' => $id];
        }
        $it = eco_item($id);
        if (!$it || empty($it['koban'])) return ['err' => 'That item is not for sale.'];
        if (isset($acc['items'][$id])) return ['err' => 'You already own it.'];
        if (!empty($it['shadow']) && !holds_shadow($pid)) return ['err' => 'Halos are for Shytoshi Shadow holders. Connect a wallet that holds a Shadow to unlock them.', 'mint' => true];
        $deal = today_offer('item', $id);
        $price = koban_price($deal ? $deal['price'] : $it['koban'], $tier);
        $kind = ['halo' => '', 'skin' => '', 'frame' => 'card frame', 'table' => 'table', 'fx' => 'victory effect', 'title' => 'title', 'ring' => 'name ring', 'emote' => 'reactions', 'back' => 'card back', 'share' => 'share card', 'cap' => 'Region effect', 'turn' => 'turn aura',
            'felt' => 'table felt', 'land' => 'land finish', 'piece' => 'command pieces', 'air' => 'table air',
            'banner' => 'page banner', 'plate' => 'nameplate', 'pfx' => 'page effect', 'accent' => 'page accent', 'unlock' => 'for your page',
            'pframe' => 'portrait frame', 'seal' => 'page seal'][$it['slot']] ?? '';   //MC 2026-10-10 the two new Studio slots
        if ($e = $pay($price, $it['name'] . ($kind ? ' ' . $kind : ''))) return $e;
        $acc['items'][$id] = time();
        if (empty($acc['eq'][$it['slot']]) && !in_array($it['slot'], ['emote', 'unlock'], true)) $acc['eq'][$it['slot']] = $id;   // wear the first one right away
        //MC 2026-10-24 an Imperial piece gets its number, may raise the crest, and is announced in the chat
        if (imp_is($id)) {
            [$no, $was, $rank] = imp_claim($acc, $id, $pid);
            imp_tg($pid, $it, $no, $rank, $rank > $was);
            return ['bought' => $id, 'paid' => $price, 'imp' => ['no' => $no, 'rank' => $rank, 'up' => $rank > $was, 'name' => IMP_RANK_N[$rank] ?? '']];
        }
        return ['bought' => $id, 'paid' => $price];
    });
}

// a card finish: on the shelf any day (Gold Leaf, Blood Moon, Neon Shrine), or Holo Foil from today's shop
if ($a === 'finish') {
    limit_or_fail('buy', 60, 600);
    $card = (string)($body['card'] ?? ''); $fin = (string)($body['fin'] ?? '');
    with_account($pid, $kh, function (&$acc, $tier) use ($card, $fin) {
        if (!eco_settings()['shop_open']) return ['err' => 'The shop is closed for a moment. Try again soon.'];
        if (!deck_card($card) || !isset(FINISHES[$fin])) return ['err' => 'That finish is not for sale.'];
        if (!empty($acc['vf'][$card][$fin])) return ['err' => 'You already own it.'];
        $deal = today_offer('fin', $card, $fin);
        //MC 2026-10-10 the Animated finishes are on sale any day too (finish_prem)
        if (!$deal && !in_array($fin, array_merge(finish_shelf(), finish_prem()), true)) return ['err' => $fin === 'holo' ? 'Holo Foil is only sold for the cards in today\'s shop.' : 'That finish is earned, not sold.'];
        $price = koban_price($deal ? $deal['price'] : fin_koban($fin), $tier);
        if ($acc['koban'] < $price) return ['err' => 'Not enough Koban.', 'need' => $price - $acc['koban']];
        eco_credit($acc, -$price, deck_card($card)['name'] . ', ' . FINISHES[$fin]['name']);
        grant_finish($acc, $card, $fin);
        $acc['veq'][$card] = $fin;   // a new finish goes on right away
        return ['bought' => $card . ':' . $fin, 'paid' => $price];
    });
}
// wear a finish on a card ('' = the original ink)
if ($a === 'wear') {
    limit_or_fail('look', 240, 600);
    $card = (string)($body['card'] ?? ''); $fin = (string)($body['fin'] ?? '');
    with_account($pid, $kh, function (&$acc, $tier) use ($card, $fin) {
        if (!deck_card($card)) return ['err' => 'Unknown card.'];
        if ($fin === '') { unset($acc['veq'][$card]); return []; }
        if (empty($acc['vf'][$card][$fin])) return ['err' => "You don't own that finish yet."];
        $acc['veq'][$card] = $fin;
        return [];
    });
}
// a set of finishes (one card in every finish, or one finish on a whole kind) or this week's bundle
if ($a === 'set' || $a === 'bundle') {
    limit_or_fail('buy', 60, 600);
    $set = (string)($body['set'] ?? '');
    $want = (int)($body['price'] ?? -1);
    with_account($pid, $kh, function (&$acc, $tier) use ($a, $set, $want) {
        if (!eco_settings()['shop_open']) return ['err' => 'The shop is closed for a moment. Try again soon.'];
        if ($a === 'bundle') { $b = bundle_now(); $q = bundle_quote($acc, $b); $name = $b['name']; }
        else { $q = set_quote($acc, $set); if (!$q) return ['err' => 'Unknown set.']; $name = $q['name']; }
        if (!$q['parts']) return ['err' => 'You already own everything in it.'];
        $price = koban_price($q['price'], $tier);
        // the price moved since the page was drawn (bought a part elsewhere, a new week): say so instead of charging something else
        if ($want >= 0 && $want !== $price) return ['err' => 'The price changed to ' . number_format($price) . ' Koban. Check it and try again.', 'price' => $price];
        if ($acc['koban'] < $price) return ['err' => 'Not enough Koban.', 'need' => $price - $acc['koban']];
        eco_credit($acc, -$price, $name);
        foreach ($q['parts'] as $p) {
            if (isset($p['item'])) { eco_grant_item($acc, $p['item']); $it = eco_item($p['item']); if ($it['slot'] !== 'emote' && empty($acc['eq'][$it['slot']])) $acc['eq'][$it['slot']] = $p['item']; }
            else grant_finish($acc, $p['card'], $p['fin']);
        }
        return ['bought' => $a === 'bundle' ? 'bundle' : $set, 'paid' => $price, 'n' => count($q['parts'])];
    });
}
// swap a weekly mission: free once a week with the Scroll, then banked rerolls, then the Reroll's Koban price
if ($a === 'reroll') {
    limit_or_fail('buy', 60, 600);
    $slot = (int)($body['slot'] ?? -1);
    with_account($pid, $kh, function (&$acc, $tier) use ($slot) {
        missions_week_init($acc);
        $how = $acc['sc']['prem'] && empty($acc['ms']['free']) ? 'free' : ((int)($acc['rrb'] ?? 0) > 0 ? 'banked' : 'koban');
        $cost = eco_good('reroll')['koban'];
        if ($how === 'koban' && $acc['koban'] < $cost) return ['err' => 'Not enough Koban.', 'need' => $cost - $acc['koban']];
        $why = missions_reroll($acc, $slot);
        if ($why) return ['err' => $why];
        if ($how === 'free') $acc['ms']['free'] = 1;
        elseif ($how === 'banked') $acc['rrb']--;
        else eco_credit($acc, -$cost, 'Mission Reroll');
        return ['rerolled' => $slot, 'how' => $how];
    });
}

// a Daily X task: the player pastes the link to their post; X is asked about it before the account is locked
if ($a === 'xtask') {
    limit_or_fail('xtask', 30, 3600);
    if (!xt_on()) fail('X tasks are switched off right now.', 503);
    $task = (string)($body['task'] ?? '');
    if (!isset(XT_POOL[$task])) fail('Pick a task.');
    $link = xt_parse((string)($body['url'] ?? ''));
    if (!$link) fail('Paste the link to your post. It looks like x.com/yourname/status/123…');
    if (!with_lock(fn() => key_ok($pid, $kh))) fail('not your profile', 403);
    $post = xt_fetch($link[0], $link[1]);
    if (isset($post['err'])) fail($post['err'], 422);
    $site = xt_site_made($pid, $link[1]);
    with_account($pid, $kh, fn(&$acc, $tier) => xt_claim($acc, $pid, $tier, $task, $link[1], $post, $site));
}

if ($a === 'equip') {
    limit_or_fail('look', 240, 600);
    $slot = (string)($body['slot'] ?? ''); $id = (string)($body['item'] ?? '');
    //MC 2026-10-10 two new slots: cap (what plays when you claim a Region) and turn (the glow on your turn)
    //MC 2026-10-14 the war table slots: felt, land, piece, air
    if (!in_array($slot, array_merge(['frame', 'table', 'fx', 'title', 'ring', 'back', 'share', 'skin', 'halo', 'cap', 'turn', 'felt', 'land', 'piece', 'air'], PAGE_SLOTS), true)) fail('bad slot');
    with_account($pid, $kh, function (&$acc, $tier) use ($slot, $id, $pid) {
        if ($id === '') { unset($acc['eq'][$slot]); return []; }
        $it = eco_item($id);
        if (!$it || $it['slot'] !== $slot || !isset(eco_owned($acc, $tier)[$id])) return ['err' => "You don't own that yet."];
        if (!empty($it['dev']) && !eco_dev($pid)) return ['err' => "You don't own that yet."];   //MC 2026-10-12 Dev items stay with the dev
        if (!empty($it['shadow']) && !holds_shadow($pid)) return ['err' => 'Halos show on your own Shadow. Connect the wallet that holds it first.'];
        $acc['eq'][$slot] = $id;
        return [];
    });
}

// Profile Studio: the cards in your showcase and your motto (each needs its unlock)
if ($a === 'page') {
    limit_or_fail('look', 240, 600);
    $show = is_array($body['show'] ?? null) ? array_slice(array_values($body['show']), 0, 12) : null;
    $motto = array_key_exists('motto', $body) ? trim(preg_replace('/\s+/u', ' ', (string)$body['motto'])) : null;
    with_account($pid, $kh, function (&$acc, $tier) use ($show, $motto) {
        $own = eco_owned($acc, $tier);
        if ($show !== null) {
            if (!isset($own['unlock_showcase'])) return ['err' => 'Unlock the Card Showcase first.'];
            $deck = deck_cards(); $clean = []; $seen = [];
            foreach ($show as $x) {
                $c = (string)($x['card'] ?? ''); $f = (string)($x['fin'] ?? '');
                if (!isset($deck[$c]) || isset($seen[$c])) continue;
                if ($f !== '' && empty($acc['vf'][$c][$f])) return ['err' => "You don't own that finish for " . $deck[$c]['name'] . '.'];
                $clean[] = [$c, $f]; $seen[$c] = 1;
                if (count($clean) >= PAGE_SHOW_MAX) break;
            }
            $acc['pg']['show'] = $clean;
        }
        if ($motto !== null) {
            if (!isset($own['unlock_motto'])) return ['err' => 'Unlock the Motto first.'];
            if ($e = motto_problem($motto)) return ['err' => $e];
            $acc['pg']['motto'] = $motto;
        }
        return ['page' => page_public($acc, $tier)];
    });
}

if ($a === 'claim') {
    limit_or_fail('claim', 120, 600);
    $kind = (string)($body['kind'] ?? '');
    with_account($pid, $kh, function (&$acc, $tier) use ($kind, $pid) {
        if ($kind === 'stipend') {
            if (!$tier) return ['err' => 'Holder rewards need a connected wallet holding $SHY or a Shadow.'];
            if (($acc['stip'] ?? '') === week_key()) return ['err' => 'Already collected this week. It refreshes Monday.'];
            $h = load(HOLDERS)[$pid] ?? null;
            //MC 2026-10-11 one stipend per wallet per week, whichever profile it's linked to (see wallet_stip_taken)
            if (wallet_stip_taken($h, $tier)) return ['err' => 'This wallet already collected its stipend this week. It refreshes Monday.'];
            $k = holder_stip($tier, $h);   //MC 2026-10-10 same floor as me_view shows
            eco_credit($acc, $k, 'Holder stipend (' . (HOLDER_NAMES[$tier] ?? $tier) . ')');
            $acc['stip'] = week_key();
            //MC 2026-10-10 Commander and up get the Bounty Board with it, King / Queen and up this season's Scroll, Supreme Scroll+
            $free = holder_free_perks($acc, $tier, $h, $given);
            wallet_stip_mark($h, $tier, $given);
            return ['claimed' => $free ? array_merge([['koban' => $k]], array_map(fn($f) => ['perk' => $f], $free)) : $k];
        }
        if ($kind === 'scroll') {
            // collect every reward you've reached on both tracks
            $tierNow = intdiv($acc['sc']['xp'], TIER_XP);
            $rw = scroll_rewards(); $got = [];
            for ($t = 1; $t <= $tierNow; $t++) {
                foreach ([0 => 'cf', 1 => 'cp'] as $track => $field) {
                    $r = $rw[$t][$track];
                    if (!$r || in_array($t, $acc['sc'][$field], true)) continue;
                    if ($track === 1 && !$acc['sc']['prem']) continue;
                    foreach (grant_reward($acc, $r, "Scroll tier $t") as $g) $got[] = $g + ['t' => $t];
                    $acc['sc'][$field][] = $t;
                }
            }
            if (!$got) return ['err' => 'Nothing new to collect yet. Play to climb the Scroll.'];
            return ['claimed' => $got];
        }
        if ($kind === 'gift') {
            if (empty(load(PLAYERS)[$pid]['games']) && !$tier && empty(load(HOLDERS)[$pid]['wallet'])) return ['err' => 'Finish your first game to start collecting daily gifts.'];
            $g = gift_today($acc, $tier);
            if ($g['claimed']) return ['err' => 'Already collected today. A new gift lands at 00:00 UTC.'];
            eco_credit($acc, $g['koban'], 'Daily gift');
            if ($g['moon']) eco_credit($acc, $g['moon'], 'Koban Moon');
            $acc['gift'] = today();
            return ['claimed' => $g['koban'] + $g['moon']];
        }
        if ($kind === 'collection') {
            $pts = collection_points($acc); $got = [];
            foreach (COLLECTION as $l => $c) {
                if ($pts < $c['at'] || in_array($l, $acc['cl'], true)) continue;
                foreach (grant_reward($acc, $c['reward'], "Collection level $l") as $g) $got[] = $g;
                $acc['cl'][] = $l;
            }
            if (!$got) return ['err' => 'Nothing new yet. Every finish you own adds to your Collection.'];
            return ['claimed' => $got];
        }
        if ($kind === 'mastery') {
            $got = [];
            foreach ($acc['cm'] as $c => $n) {
                $lv = mastery_level($n); $had = (int)($acc['cml'][$c] ?? 0);
                for ($l = $had + 1; $l <= $lv; $l++) {
                    $k = MASTERY[$l][1];
                    eco_credit($acc, $k, deck_card($c)['name'] . ' ' . MASTERY_NAMES[$l]);
                    $got[] = ['koban' => $k];
                    if ($l === 4) {
                        if (grant_finish($acc, $c, 'gold')) $got[] = ['fin' => [$c, 'gold']];
                        else { $rf = finish_refund('gold'); eco_credit($acc, $rf, deck_card($c)['name'] . ' Master (already had Gold Leaf)'); $got[] = ['koban' => $rf]; }
                    }
                    if ($l === 5) { eco_grant_item($acc, 'title_master'); trophy_award($pid, 'master', $c, deck_card($c)['name']); }   //MC 2026-10-15
                }
                $acc['cml'][$c] = max($had, $lv);
            }
            if (!$got) return ['err' => 'Nothing new yet. Play cards to master them.'];
            return ['claimed' => $got];
        }
        return ['err' => 'unknown claim'];
    });
}

// ---------------------------------------------------------------- paying
function order_public($o) {
    return ['id' => $o['id'], 'product' => $o['product'], 'name' => $o['name'], 'usd' => $o['usd'], 'cur' => $o['cur'], 'mint' => $o['mint'], 'units' => (string)$o['units'], 'dec' => $o['dec'],
        'amount' => rtrim(rtrim(number_format($o['units'] / pow(10, $o['dec']), $o['dec'], '.', ''), '0'), '.'), 'to' => $o['to'], 'ref' => $o['ref'], 'exp' => $o['exp'], 'wallet' => $o['wallet'],
        'url' => order_pay_url($o), 'memo' => 'shy:' . $o['id'],
        'burn' => (string)(int)($o['burn'] ?? 0), 'bpct' => (int)($o['bpct'] ?? 0), 'burnAmount' => !empty($o['burn']) ? rtrim(rtrim(number_format($o['burn'] / pow(10, $o['dec']), $o['dec'], '.', ''), '0'), '.') : ''];
}
function product_check($acc, $p) {
    if (!$p) return 'That item is not for sale.';
    if (!empty($p['until']) && strtotime($p['until'] . ' 23:59:59 UTC') < time()) return 'That offer has ended.';
    if (!empty($p['end']) && $p['end'] < time()) return 'That offer has ended.';   //MC 2026-10-16
    if (!empty($p['from']) && $p['from'] > time()) return 'That offer has not started yet.';
    if (!empty($p['once']) && isset($acc['once'][$p['id']])) return 'You already have this one. It is one per player.';
    if (!empty($p['scroll']) && $acc['sc']['prem'] && $p['id'] === 'scroll') return "You already have this season's Scroll.";
    if ($p['id'] === 'scrollplus' && $acc['sc']['prem']) return !empty($acc['sc']['plus']) ? "You already have this season's Scroll+." : 'You already have the Scroll. Get the Scroll+ upgrade instead, it costs less.';
    if ($p['id'] === 'plusup' && (!$acc['sc']['prem'] || !empty($acc['sc']['plus']))) return !empty($acc['sc']['plus']) ? "You already have this season's Scroll+." : 'The upgrade is for Scroll owners. Get Scroll+ instead.';
    if (($p['kind'] ?? '') === 'drop' && !empty($acc['vf'][$p['drop']['card']][$p['drop']['fin']])) return 'You already own that finish on that card.';   //MC 2026-10-13
    return '';
}

if ($a === 'quote') {
    limit_or_fail('quote', 40, 600);
    $prod = (string)($body['product'] ?? ''); $cur = (string)($body['cur'] ?? '');
    $mints = ['SHY' => SHY_MINT, 'SOL' => SOL_MINT, 'USDC' => USDC_MINT];
    if (!isset($mints[$cur])) fail('Pick SHY, SOL or USDC.');
    if (!eco_settings()['shop_open']) fail('The shop is closed for a moment. Try again soon.', 503);
    //MC 2026-10-13 a tournament entry ticket (tk:<id>): priced in $SHY, exactly the fee, $SHY only. The burn share burns
    //   in the buyer's own transaction like every $SHY payment, the rest lands in the marketing wallet, and the pool share
    //   is paid out of it to the winners (or refunded whole if the event is called off).
    $ticket = null;
    if (preg_match('/^tk:[a-f0-9]{10}$/', $prod)) {
        if ($cur !== 'SHY') fail('Tournament entries are paid in $SHY.');
        $tt = tourney_db()['list'][substr($prod, 3)] ?? null;
        if (!$tt || empty($tt['fee'])) fail('That tournament has no entry fee.');
        if ($tt['status'] !== 'signup') fail('Sign-ups for this tournament are closed.');
        if (count($tt['players']) >= $tt['max']) fail('This tournament is full.');
        if (($why = tourney_gate_problem($tt, $pid)) !== '') fail($why, 403);
        if (tourney_ticket_order($tt['id'], $pid)) fail('You already hold an entry for this one. Sign up on the Play page and it counts.');
        $ticket = $tt;
        $p = ['id' => $prod, 'name' => 'Entry: ' . $tt['name'], 'usd' => 0.0, 'kind' => 'ticket'];
    //MC 2026-10-13 a limited finish drop (drop:<id>): $SHY only, exactly the set price, while copies are left
    } elseif (preg_match('/^drop:[a-f0-9]{10}$/', $prod)) {
        if ($cur !== 'SHY') fail('Drops are paid in $SHY.');
        $dd = drop_get(substr($prod, 5));
        if (!$dd || !empty($dd['off'])) fail('That drop is not for sale.');
        if (time() < $dd['start']) fail('This drop has not started yet.');
        if (time() >= $dd['end']) fail('This drop has ended.');
        if ((int)$dd['sold'] >= (int)$dd['n']) fail('Sold out. All ' . (int)$dd['n'] . ' copies are gone.');
        if ((int)$dd['sold'] + drop_reserved($dd['id']) >= (int)$dd['n']) fail('The last copies are in other checkouts right now. Try again in a few minutes.');
        $ticket = ['fee' => (float)$dd['shy']];
        $p = ['id' => $prod, 'name' => deck_card($dd['card'])['name'] . ' in ' . FINISHES[$dd['fin']]['name'], 'usd' => 0.0, 'kind' => 'drop', 'drop' => $dd];
    } else {
        $p = eco_product($prod);
        if ($p && !empty($p['shy_only']) && $cur !== 'SHY') fail('This bundle is paid in $SHY only.');   //MC 2026-10-16
    }
    // prices come from the market; look them up before taking the lock
    $q = $ticket ? units_for_usd(1, SHY_MINT) : units_for_usd($p['usd'] ?? 0, $mints[$cur]);
    if (!$q) fail("Couldn't get a live price right now. Try again in a minute, or pick another coin.", 502);
    if ($ticket) { $q['units'] = (int)round($ticket['fee'] * pow(10, $q['dec'])); $p['usd'] = round($ticket['fee'] * $q['px'], 2); }   // the fee is the price, to the unit
    $res = with_lock(function () use ($pid, $kh, $p, $cur, $mints, $q) {
        if (!key_ok($pid, $kh)) return ['err' => 'not your profile', 'code' => 403];
        $holders = load(HOLDERS);
        $wallet = $holders[$pid]['wallet'] ?? '';
        if (!$wallet) return ['err' => 'Connect your wallet first. Your purchases are kept on it, so you can sign in on any device.', 'code' => 400];
        $eco = load(ECO);
        $why = product_check(eco_get($eco, $pid), $p);
        if ($why) return ['err' => $why, 'code' => 400];
        $orders = load(ORDERS);
        // tidy: drop unpaid orders older than a week
        //MC 2026-10-11 an unpaid order the team still has to look at (an open Payment help request, or a payment problem on
        //   it) is kept, or the admin's "Check with this payment" button disappeared after 7 days
        $held = []; foreach (load(DATA_DIR . '/pay-help.php') as $x) if (($x['status'] ?? '') === 'open') foreach (array_merge((array)($x['orders'] ?? []), [(string)($x['order'] ?? '')]) as $oid) $held[$oid] = 1;
        $orders = array_filter($orders, fn($o) => $o['status'] === 'paid' || $o['ts'] > time() - 7 * 86400 || isset($held[$o['id'] ?? '']) || (!empty($o['issue']) && $o['ts'] > time() - 60 * 86400));
        $id = bin2hex(random_bytes(8));
        $o = ['id' => $id, 'pid' => $pid, 'wallet' => $wallet, 'product' => $p['id'], 'name' => $p['name'], 'usd' => $p['usd'], 'cur' => $cur, 'mint' => $mints[$cur],
            'units' => $q['units'], 'dec' => $q['dec'], 'px' => $q['px'], 'to' => mw_address(), 'ref' => new_reference(), 'ts' => time(), 'exp' => time() + ORDER_TTL, 'status' => 'open', 'checks' => 0];
        //MC 2026-10-10 $SHY payments burn burn_pct of the price in the same transaction
        if ($cur === 'SHY' && ($b = burn_units_for($q['units'], $q['dec'])) > 0) { $o['burn'] = $b; $o['bpct'] = (int)eco_settings()['burn_pct']; }
        $orders[$id] = $o;
        save(ORDERS, $orders);
        return ['order' => $o];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true, 'order' => order_public($res['order'])]);
}

if ($a === 'check') {
    $id = (string)($body['order'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/', $id)) fail('bad order');
    limit_or_fail('check', 600, 600);
    $o = with_lock(function () use ($pid, $kh, $id) {
        if (!key_ok($pid, $kh)) return null;
        $o = load(ORDERS)[$id] ?? null;
        return $o && $o['pid'] === $pid ? $o : null;
    });
    if (!$o) fail('Order not found.', 404);
    if ($o['status'] === 'paid') out(['ok' => true, 'status' => 'paid', 'got' => $o['got'], 'proof' => $o['proof'], 'me' => with_lock(fn() => me_view($pid))]);
    if (time() > $o['ts'] + ORDER_GRACE) out(['ok' => true, 'status' => 'expired']);
    $pub = $o['cur'] === 'CARD' ? ['id' => $o['id'], 'product' => $o['product'], 'cur' => 'CARD'] : order_public($o);
    // card orders: ask Stripe (covers a missed webhook)
    if ($o['cur'] === 'CARD') {
        require_once __DIR__ . '/stripe.php';
        $paid = stripe_session_paid($o['session'] ?? '');
        if (!$paid) out(['ok' => true, 'status' => 'open', 'order' => $pub]);
        $proof = $o['session'];
    } else {
        // the payment can carry a signature from the browser to speed things up, but the chain is what counts
        $sig = (string)($body['sig'] ?? '');
        if ($sig && preg_match('/^[1-9A-HJ-NP-Za-km-z]{64,90}$/', $sig) && ($o['sig'] ?? '') !== $sig) {
            // keep the wallet's signature on the order so it can be checked again later, here or in the admin
            with_lock(function () use ($id, $sig) { $orders = load(ORDERS); if (isset($orders[$id]) && $orders[$id]['status'] !== 'paid') { $orders[$id]['sig'] = $sig; $orders[$id]['sig_ts'] = time(); $orders[$id]['issue'] = ''; save(ORDERS, $orders); } });
        } else $sig = $o['sig'] ?? '';
        $v = verify_payment($o, $sig);
        // remember what went wrong so the buyer's history can say so
        $issue = isset($v['self']) ? 'self' : (isset($v['nopay']) ? 'nopay' : (isset($v['failed']) ? 'failed' : (isset($v['short']) ? 'short' : (isset($v['dropped']) ? 'dropped' : ''))));
        if ($issue !== ($o['issue'] ?? '') && $issue !== '') with_lock(function () use ($id, $issue) { $orders = load(ORDERS); if (isset($orders[$id]) && $orders[$id]['status'] !== 'paid') { $orders[$id]['issue'] = $issue; save(ORDERS, $orders); } });
        if (isset($v['self'])) out(['ok' => true, 'status' => 'failed', 'sig' => $v['self'], 'msg' => 'That payment came from the marketing wallet itself, so nothing changed hands. Connect a different wallet to buy.']);
        if (isset($v['dropped'])) out(['ok' => true, 'status' => 'failed', 'sig' => $v['dropped'], 'msg' => 'Solana never confirmed that payment, so nothing left your wallet. Start a new purchase to try again.']);
        if (isset($v['nopay'])) out(['ok' => true, 'status' => 'failed', 'sig' => $v['nopay'], 'msg' => 'That transaction went through but did not send the payment to the marketing wallet. Contact us with order ' . $o['id'] . '.']);
        if (isset($v['failed'])) out(['ok' => true, 'status' => 'failed', 'sig' => $v['failed'], 'why' => fail_reason($v['why'] ?? '', $o), 'msg' => fail_msg($v['why'] ?? '', $o)]);
        //MC 2026-10-11 paid after the price hold and short of today's price: the team decides (see ORDER_LATE_GRACE)
        if (isset($v['late'])) {
            $tk = pay_help_open($pid, $v['late'], $id, [$id], 'late', '');
            out(['ok' => true, 'status' => 'short', 'late' => true, 'ticket' => $tk, 'got' => $v['got'], 'need' => $v['need'],
                'msg' => 'Your payment arrived after the 20-minute price hold, and the price has moved since. Nothing is lost: the team has it (request #' . $tk . ') and will sort it out.']);
        }
        if (isset($v['short'])) out(['ok' => true, 'status' => 'short', 'got' => $v['got'], 'need' => $o['units'],
            'msg' => 'We found a payment but it was less than the price. Contact us with order ' . $o['id'] . '.']);
        if (empty($v['paid'])) out(['ok' => true, 'status' => time() > $o['exp'] ? 'late' : 'open', 'order' => $pub]);
        $proof = $v['paid'];
    }
    $selfpay = !empty($v['selfpay']);
    $vv = $v ?? [];
    $res = with_lock(function () use ($id, $proof, $selfpay, $vv) {
        $orders = load(ORDERS);
        if ($selfpay && isset($orders[$id])) $orders[$id]['selfpay'] = 1;
        // one payment can only ever pay for one order
        foreach ($orders as $oid => $x) if ($oid !== $id && ($x['proof'] ?? '') === $proof) return ['err' => 'That payment was already used.'];
        $o = fulfill($orders, $id, $proof, $vv);
        return ['o' => $o];
    });
    if (isset($res['err'])) fail($res['err'], 409);
    out(['ok' => true, 'status' => 'paid', 'got' => $res['o']['got'], 'proof' => $proof, 'me' => with_lock(fn() => me_view($pid))]);
}

// "I paid but didn't get it": the buyer pastes the transaction. We match it to one of their orders on Solana and
// deliver straight away; anything we can't match goes to the team in the admin with everything they need.
if ($a === 'claim-tx') {
    limit_or_fail('claimtx', 12, 600);
    $raw = trim((string)($body['tx'] ?? ''));
    $note = mb_substr(trim((string)($body['note'] ?? '')), 0, 300);
    $want = (string)($body['order'] ?? '');
    if (!preg_match('/([1-9A-HJ-NP-Za-km-z]{64,90})/', $raw, $mm)) fail('Paste the transaction link or signature from your wallet or Solscan. It\'s a long code of letters and numbers.');
    $sig = $mm[1];
    [$cands, $wallets, $used] = with_lock(function () use ($pid, $kh, $want, $sig) {
        if (!key_ok($pid, $kh)) return [null, [], false];
        $orders = load(ORDERS);
        foreach ($orders as $x) if (($x['proof'] ?? '') === $sig) return [[], [], $x['pid'] === $pid ? 'mine' : 'other'];
        $c = [];
        foreach ($orders as $id => $o) {
            if ($o['pid'] !== $pid || $o['status'] === 'paid' || ($o['cur'] ?? '') === 'CARD' || $o['ts'] < time() - 7 * 86400) continue;
            if ($want !== '' && $want !== $id) continue;
            $c[$id] = $o;
        }
        uasort($c, fn($x, $y) => $y['ts'] <=> $x['ts']);
        $h = load(HOLDERS);
        $w = array_values(array_unique(array_filter(array_merge([$h[$pid]['wallet'] ?? ''], array_column($c, 'wallet')))));
        return [$c, $w, false];
    });
    if ($cands === null) fail('not your profile', 403);
    if ($used === 'mine') out(['ok' => true, 'status' => 'already', 'msg' => 'That payment already delivered an order. Check your purchase history.', 'me' => with_lock(fn() => me_view($pid))]);
    if ($used === 'other') fail('That payment was already used for another order.');
    $why = ''; $best = null;
    // the order it pays best: the priciest one the amount covers (a payment for a big bundle never fills a small pack)
    foreach (array_slice($cands, 0, 8, true) as $id => $o) {
        $v = tx_pays_manual($o, $sig, $wallets);
        if (isset($v['paid'])) { if (!$best || $o['usd'] > $best[1]['usd']) $best = [$id, $o, $v]; continue; }
        if (isset($v['pending'])) { $why = 'pending'; break; }
        if (isset($v['failed'])) { $why = 'failed'; $failOrder = $o; $failWhy = $v['why'] ?? ''; break; }
        if (isset($v['short'])) $why = 'short';
        elseif (isset($v['late'])) $why = 'late';   //MC 2026-10-11
        elseif (!$why && isset($v['other']) && strpos($v['why'], 'wallet') !== false) $why = 'wallet';
    }
    if ($best) {
        [$id, $o, $v] = $best;
        $res = with_lock(function () use ($id, $v) {
            $orders = load(ORDERS);
            foreach ($orders as $oid => $x) if ($oid !== $id && ($x['proof'] ?? '') === $v['paid']) return ['err' => 'That payment was already used.'];
            if (!empty($v['manual'])) $orders[$id]['matched'] = 'player';
            return ['o' => fulfill($orders, $id, $v['paid'], $v)];
        });
        if (isset($res['err'])) fail($res['err'], 409);
        shop_log('order ' . $id . ' matched by the buyer to ' . $sig);
        out(['ok' => true, 'status' => 'paid', 'order' => $id, 'name' => $res['o']['name'], 'got' => $res['o']['got'], 'proof' => $sig, 'me' => with_lock(fn() => me_view($pid))]);
    }
    if ($why === 'pending') out(['ok' => true, 'status' => 'pending', 'msg' => 'Solana doesn\'t show that transaction yet. If you just sent it, wait a minute and try again.']);
    if ($why === 'failed') out(['ok' => true, 'status' => 'failed', 'msg' => fail_msg($failWhy, $failOrder)]);
    // couldn't match it: hand it to the team with what we know
    $ticket = with_lock(function () use ($pid, $sig, $want, $note, $why, $cands) {
        $f = DATA_DIR . '/pay-help.php';
        $t = load($f);
        foreach ($t as $id => $x) if ($x['sig'] === $sig && $x['pid'] === $pid) return $id;
        $id = bin2hex(random_bytes(5));
        $t[$id] = ['pid' => $pid, 'sig' => $sig, 'order' => $want, 'orders' => array_keys($cands), 'why' => $why, 'note' => $note, 'ts' => time(), 'status' => 'open'];
        save($f, array_slice($t, -300, null, true));
        return $id;
    });
    //MC 2026-10-09 a person has to look at this one: email the team
    alert_needs('a payment we couldn\'t match', 'A player says they paid and the site couldn\'t match it to an order on its own' . ($why === 'short' ? ': the payment was less than the price.' : ($why === 'wallet' ? ': it came from a wallet that isn\'t linked to their profile.' : '.')),
        [['Player', m_player($pid)], ['Transaction', m_tx($sig)], ['Their orders', mh(implode(', ', array_keys($cands)) ?: 'none open')], ['Their note', mh($note !== '' ? $note : 'none')], ['Request', mh('#' . $ticket)]], '/admin/?tab=shop#payhelp');
    $msg = ['short' => 'We found that payment, but it was less than the price of your order.', 'late' => 'We found that payment, but it arrived after the 20-minute price hold and the price has moved since.', 'wallet' => 'That payment came from a wallet that isn\'t linked to your profile, so we can\'t match it on our own.'][$why] ?? 'We couldn\'t match that payment to one of your orders on our own.';
    out(['ok' => true, 'status' => 'help', 'ticket' => $ticket, 'msg' => $msg . ' The team has it now (request #' . $ticket . ') and will sort it out. You\'ll see it in your purchase history once it\'s done.']);
}

if ($a === 'card') {
    limit_or_fail('card', 20, 600);
    $c = shy_config();
    if (empty($c['stripe_secret'])) fail('Card payments are coming soon. Pay with $SHY, SOL or USDC for now.', 503);
    require_once __DIR__ . '/stripe.php';
    $p = eco_product((string)($body['product'] ?? ''));
    if ($p && !empty($p['shy_only'])) fail('This bundle is paid in $SHY only.');   //MC 2026-10-16
    $res = with_lock(function () use ($pid, $kh, $p) {
        if (!key_ok($pid, $kh)) return ['err' => 'not your profile', 'code' => 403];
        $holders = load(HOLDERS);
        $wallet = $holders[$pid]['wallet'] ?? '';
        if (!$wallet) return ['err' => 'Connect your wallet first. Your purchases are kept on it, so you can sign in on any device.', 'code' => 400];
        $why = product_check(eco_get(load(ECO), $pid), $p);
        if ($why) return ['err' => $why, 'code' => 400];
        $id = bin2hex(random_bytes(8));
        return ['o' => ['id' => $id, 'pid' => $pid, 'wallet' => $wallet, 'product' => $p['id'], 'name' => $p['name'], 'usd' => $p['usd'], 'cur' => 'CARD', 'mint' => '', 'units' => 0, 'dec' => 0, 'ts' => time(), 'exp' => time() + 3600, 'status' => 'open']];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    $o = $res['o'];
    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'shyonsol.io');
    $s = stripe_create_session($o, $base . '/play?order=' . $o['id'] . '#shop', $base . '/play#shop');
    if (!$s) fail("Couldn't start a card payment. Try again, or pay with crypto.", 502);
    $o['session'] = $s['id'];
    with_lock(function () use ($o) { $orders = load(ORDERS); $orders[$o['id']] = $o; save(ORDERS, $orders); });
    out(['ok' => true, 'url' => $s['url'], 'order' => $o['id']]);
}

// a narrow window onto Solana for building a payment in the browser (the RPC key stays on the server)
if ($a === 'rpc') {
    limit_or_fail('rpc', 120, 600);
    $m = (string)($body['method'] ?? ''); $params = $body['params'] ?? [];
    if ($m === 'getLatestBlockhash') out(['ok' => true, 'result' => rpc('getLatestBlockhash', [['commitment' => 'confirmed']])]);
    if ($m === 'getAccountInfo') {
        $addr = (string)($params[0] ?? '');
        if (!valid_wallet($addr)) fail('bad address');
        out(['ok' => true, 'result' => rpc('getAccountInfo', [$addr, ['encoding' => 'base64', 'commitment' => 'confirmed']])]);
    }
    // what the paying wallet holds: SOL for the fee and the token being paid with, checked before the wallet is asked to sign
    if ($m === 'funds') {
        $addr = (string)($params[0] ?? ''); $mint = (string)($params[1] ?? '');
        if (!valid_wallet($addr) || ($mint !== '' && !valid_wallet($mint))) fail('bad address');
        $sol = rpc('getBalance', [$addr, ['commitment' => 'confirmed']]);
        $out = ['lamports' => isset($sol['value']) ? (int)$sol['value'] : null, 'units' => null];
        if ($mint !== '' && $mint !== SOL_MINT) {
            $ta = rpc('getTokenAccountsByOwner', [$addr, ['mint' => $mint], ['encoding' => 'jsonParsed', 'commitment' => 'confirmed']]);
            if (isset($ta['value'])) { $u = 0; foreach ($ta['value'] as $acc) $u += (int)($acc['account']['data']['parsed']['info']['tokenAmount']['amount'] ?? 0); $out['units'] = $u; }
        }
        out(['ok' => true, 'result' => $out]);
    }
    fail('not allowed', 403);
}

fail('unknown action');
