<?php
// Houses: small teams of up to 20 players. Members' weekly points add up on the House board, and when the week
// ends every member of the top 3 Houses who played that week gets Koban.
//   houses.php  'h' => id => ['name', 'tag', 'crest', 'color', 'desc', 'open', 'tg', 'owner', 'officers' => [pid => 1],
//                              'members' => [pid => joined], 'reqs' => [pid => asked], 'created']
//               'm' => pid => house id     'cool' => pid => when they last joined (one switch a week)
//               'weeks' => week => ['at', 'rows' => [[id, name, tag, crest, color, pts, n, top => [[name, pts]]]], 'paid' => [...]]
// Functions marked "locked" expect the caller to hold with_lock.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('HOUSES', DATA_DIR . '/houses.php');
const HOUSE_MAX = 20;
const HOUSE_CRESTS = ['moon', 'wave', 'crane', 'fox', 'dragon', 'sakura', 'bolt', 'mountain', 'sun', 'oni', 'koi', 'blade'];
const HOUSE_COLORS = ['crimson', 'gold', 'jade', 'violet', 'sky', 'ink'];

function houses() { $h = load(HOUSES); return $h + ['h' => [], 'm' => [], 'cool' => [], 'weeks' => []]; }
function house_of($pid, $H = null) { $H = $H ?? houses(); $id = $H['m'][$pid] ?? ''; return $id !== '' && isset($H['h'][$id]) ? $id : ''; }
function house_tag_of($pid) { static $H = null; if ($H === null) $H = houses(); $id = house_of($pid, $H); return $id ? $H['h'][$id]['tag'] : ''; }
function house_role($h, $pid) { return $h['owner'] === $pid ? 'owner' : (!empty($h['officers'][$pid]) ? 'officer' : (isset($h['members'][$pid]) ? 'member' : '')); }
function house_settings() { $s = eco_settings(); return ['cost' => (int)($s['house_cost'] ?? 300), 'games' => (int)($s['house_games'] ?? 5), 'prize' => $s['house_prize'] ?? [300, 200, 100], 'on' => !isset($s['house_on']) || !empty($s['house_on'])]; }

// this week's points for every House, best first (members' points this week, wherever they earned them)
function house_board($players, $H = null, $wk = null) {
    $H = $H ?? houses(); $wk = $wk ?? week_key(); $rows = [];
    foreach ($H['h'] as $id => $h) {
        $pts = 0; $n = 0; $top = [];
        foreach ($h['members'] as $p => $_) {
            $x = $players[$p] ?? null; if (!$x) continue;
            $w = ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0;
            $pts += $w; if ($w > 0) $n++;
            $top[] = [$x['name'] ?? '', $w];
        }
        usort($top, fn($a, $b) => $b[1] <=> $a[1]);
        $rows[] = ['id' => $id, 'name' => $h['name'], 'tag' => $h['tag'], 'crest' => $h['crest'], 'color' => $h['color'], 'pts' => $pts, 'n' => $n, 'size' => count($h['members']), 'open' => !empty($h['open']), 'top' => array_slice(array_filter($top, fn($t) => $t[1] > 0), 0, 3)];
    }
    usort($rows, fn($a, $b) => [$b['pts'], $b['n']] <=> [$a['pts'], $a['n']]);
    return $rows;
}

// a week just ended (locked; called from archive_weeks before anyone's weekly points reset): freeze the House board and pay the top 3
function house_freeze_week($wk, $players) {
    $H = houses();
    if (isset($H['weeks'][$wk]) || !$H['h']) return;
    $rows = array_values(array_filter(house_board($players, $H, $wk), fn($r) => $r['pts'] > 0));
    $set = house_settings();
    $paid = [];
    if ($rows && $set['on']) {
        $eco = load(ECO);
        foreach (array_slice($rows, 0, 3) as $place => $r) {
            $k = (int)($set['prize'][$place] ?? 0); if ($k <= 0) continue;
            foreach ($H['h'][$r['id']]['members'] as $p => $_) {
                $x = $players[$p] ?? null;
                if (!$x || ($x['wk'] ?? '') !== $wk || empty($x['wpts'])) continue;   // only members who played that week
                $a = eco_get($eco, $p); eco_credit($a, $k, 'House prize: ' . $r['name'] . ', ' . ['1st', '2nd', '3rd'][$place] . ' of the week'); $eco[$p] = $a;
                $paid[] = [$p, $k];
            }
        }
        save(ECO, $eco);
        if (function_exists('tg_post') && $rows) {
            $lines = []; foreach (array_slice($rows, 0, 3) as $i => $r) $lines[] = ['🥇', '🥈', '🥉'][$i] . ' <b>' . tg_h($r['name']) . '</b> [' . tg_h($r['tag']) . ']: ' . number_format($r['pts']) . ' pts';
            //MC 2026-10-26 with the banners card
            $card = function_exists('tg_card') ? tg_card('house', ['wk' => $wk, 'wn' => (int)substr($wk, 5), 'rows' => array_map(fn($r) => ['name' => $r['name'], 'tag' => $r['tag'], 'pts' => (int)$r['pts'], 'color' => (string)($r['color'] ?? '')], array_slice($rows, 0, 3))]) : '';
            tg_post('weekly', "🏯 <b>House of the week:</b> " . tg_h($rows[0]['name']) . "\n" . implode("\n", $lines) . "\nEvery member who played gets Koban. " . tg_link('/houses', 'See the Houses'), 'house:' . $wk, null, $card);
        }
    }
    $H['weeks'][$wk] = ['at' => time(), 'rows' => array_slice($rows, 0, 20), 'paid' => count($paid)];
    krsort($H['weeks']); $H['weeks'] = array_slice($H['weeks'], 0, 12, true);
    save(HOUSES, $H);
}

// what anyone may see about a House
function house_public($id, $H, $players) {
    $h = $H['h'][$id] ?? null; if (!$h) return null;
    $wk = week_key(); $mem = [];
    $eco = load(ECO); $hol = load(HOLDERS);
    foreach ($h['members'] as $p => $since) {
        $x = $players[$p] ?? []; $tier = holder_tier($hol[$p] ?? null);
        $mem[] = ['id' => substr($p, 0, 6), 'name' => $x['name'] ?? '?', 'slug' => str_replace(' ', '_', $x['name'] ?? ''), 'role' => house_role($h, $p), 'since' => $since,
            'week' => ($x['wk'] ?? '') === $wk ? (int)($x['wpts'] ?? 0) : 0, 'points' => (int)($x['points'] ?? 0), 'wins' => (int)($x['wins'] ?? 0),
            'img' => !empty($x['avatar']) && !empty($x['holder']) ? shadow_img($x['avatar']) : '', 'aura' => !empty($x['avatar']) && !empty($x['holder']) ? shadow_aura($x['avatar']) : '',
            'cos' => isset($eco[$p]) ? eco_public(eco_get($eco, $p), $tier) : []];
    }
    usort($mem, fn($a, $b) => [$b['week'], $b['points']] <=> [$a['week'], $a['points']]);
    $board = house_board($players, $H);
    $place = 0; foreach ($board as $i => $r) if ($r['id'] === $id) { $place = $r['pts'] > 0 ? $i + 1 : 0; break; }
    $hist = [];
    foreach ($H['weeks'] as $w => $x) foreach ($x['rows'] as $i => $r) if ($r['id'] === $id) { $hist[] = ['wk' => $w, 'week' => (int)explode('-', $w)[1], 'place' => $i + 1, 'pts' => $r['pts']]; break; }
    return ['id' => $id, 'name' => $h['name'], 'tag' => $h['tag'], 'crest' => $h['crest'], 'color' => $h['color'], 'desc' => $h['desc'] ?? '', 'open' => !empty($h['open']),
        'tg' => $h['tg'] ?? '', 'created' => $h['created'], 'members' => $mem, 'size' => count($mem), 'max' => HOUSE_MAX,
        'week' => array_sum(array_column($mem, 'week')), 'place' => $place, 'of' => count(array_filter($board, fn($r) => $r['pts'] > 0)), 'hist' => array_slice($hist, 0, 8)];
}
