<?php
// Solana Actions (Blinks): shyonsol.io links that turn into buttons on X, in wallets and anywhere blinks unfurl.
//   GET  /actions.json                      the discovery file (which paths are actions)
//   GET  /api/actions/koban                  Buy Koban with $SHY: one button per pack
//   POST /api/actions/koban/buy?pack=ID       {account} -> the unsigned $SHY payment for that pack
//   POST /api/actions/koban/done?o=ORDER      {account, signature} -> the Koban, once Solana has the payment
//   GET  /api/actions/daily                  Today's Daily Challenge
//   GET  /api/actions/play[?p=TAG]           Play Shilluminati, or beat a player's record (from their hype posts)
//   POST any external-link button             {account} -> {type: external-link, externalLink}
// Koban go to the shyonsol.io profile that wallet is connected to. A wallet that isn't connected to a profile is told
// how to connect it; nothing is charged. The payment is the same transaction the shop builds (paytxlib.php): the price
// to the community wallet with the order's reference, the burn share burned, and a memo. Nothing here signs anything.
//MC 2026-10-15 first version: Koban packs, the Daily and a play / challenge link
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET,POST,PUT,OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, Content-Encoding, Accept-Encoding');
header('Access-Control-Expose-Headers: X-Action-Version, X-Blockchain-Ids');
header('X-Action-Version: 2.4');
header('X-Blockchain-Ids: solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') exit;
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/paytxlib.php';
if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/fairlib.php';

const BL_SITE = 'https://shyonsol.io';
const BL_PACKS = ['k650', 'k1400', 'k3000', 'k8000'];
$path = trim((string)($_GET['p'] ?? ''), '/');
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function bl_out($a, $code = 200) { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); exit; }
function bl_err($msg, $code = 400) { bl_out(['message' => $msg], $code); }
function bl_img($n) { return BL_SITE . '/assets/art/blink/' . $n . '.png?v=' . (defined('SHY_BUILD') ? SHY_BUILD : '1'); }
function bl_body() { $b = json_decode((string)file_get_contents('php://input'), true); return is_array($b) ? $b : []; }
function bl_limit($what, $max, $win) {
    $ok = with_lock(function () use ($what, $max, $win) { $l = load(LIMITS); $r = rate_ok($l, 'bl-' . $what . ':' . client_ip(), $max, $win); save(LIMITS, $l); return $r; });
    if (!$ok) bl_err('Slow down a little and try again.', 429);
}
// the profile a wallet is connected to (the most recently checked one if several), or null
function bl_profile($wallet) {
    $best = null; $t = -1;
    foreach (load(HOLDERS) as $pid => $h) if (($h['wallet'] ?? '') === $wallet && (int)($h['chk'] ?? 0) > $t) { $t = (int)($h['chk'] ?? 0); $best = $pid; }
    if (!$best) return null;
    $p = load(PLAYERS)[$best] ?? [];
    if (player_banned($best)) return ['banned' => true];
    return ['pid' => $best, 'name' => $p['name'] ?? 'your profile'];
}
function bl_daily_no($day) { return (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1; }
function bl_pack_label($p) { return 'Buy ' . number_format($p['koban'] + $p['bonus']) . ' Koban'; }

// ---------- the discovery file
if ($path === '_rules') {
    header('Cache-Control: public, max-age=3600');
    bl_out(['rules' => [
        ['pathPattern' => '/koban', 'apiPath' => '/api/actions/koban'],
        ['pathPattern' => '/daily', 'apiPath' => '/api/actions/daily'],
        ['pathPattern' => '/play', 'apiPath' => '/api/actions/play'],
        ['pathPattern' => '/try', 'apiPath' => '/api/actions/play'],
        ['pathPattern' => '/h/*', 'apiPath' => '/api/actions/play/*'],
        ['pathPattern' => '/api/actions/**', 'apiPath' => '/api/actions/**'],
    ]]);
}

// ---------- external links: every one answers a POST with where to go
$links = [
    'go/play' => BL_SITE . '/try', 'go/daily' => BL_SITE . '/play?daily=1', 'go/fair' => BL_SITE . '/fair', 'go/shop' => BL_SITE . '/shop',
    'go/connect' => BL_SITE . '/profile#wallet', 'go/token' => BL_SITE . '/swap',   //MC 2026-10-18 every Buy button goes to Shy Swap
];
if (isset($links[$path]) || strpos($path, 'go/p/') === 0) {
    if ($method !== 'POST') bl_err('Use POST.', 405);
    $to = $links[$path] ?? '';
    if ($to === '') { $tag = substr($path, 5); if (!preg_match('/^[a-f0-9]{6}$/', $tag)) bl_err('Unknown link.', 404); $to = BL_SITE . '/h/' . $tag . '-1'; }
    bl_out(['type' => 'external-link', 'externalLink' => $to]);
}

// ---------- Buy Koban with $SHY
if ($path === 'koban' && $method === 'GET') {
    header('Cache-Control: public, max-age=300');
    $packs = array_values(array_filter(eco_catalog()['packs'], fn($p) => in_array($p['id'], BL_PACKS, true)));
    $shut = !eco_settings()['shop_open'];
    bl_out(['type' => 'action', 'icon' => bl_img('koban'), 'title' => 'Koban for Shilluminati Online',
        'description' => 'Top up your Shilluminati Online account with $SHY, straight from your wallet. Paying in $SHY adds ' . SHY_BONUS . '% more Koban, and part of every payment is burned for good. Koban go to the profile this wallet is connected to on shyonsol.io. Cosmetics and boosts only: nothing changes who wins.',
        'label' => 'Buy Koban', 'disabled' => $shut,
        'links' => ['actions' => array_merge(array_map(fn($p) => ['type' => 'transaction', 'label' => bl_pack_label($p) . ' · $' . number_format($p['usd'], 2), 'href' => '/api/actions/koban/buy?pack=' . $p['id']], $packs),
            [['type' => 'external-link', 'label' => 'Open the Dojo Shop', 'href' => '/api/actions/go/shop']])]]
        + ($shut ? ['error' => ['message' => 'The shop is closed for a moment. Try again soon.']] : []));
}
if ($path === 'koban/buy') {
    if ($method !== 'POST') bl_err('Use POST.', 405);
    bl_limit('buy', 30, 600);
    $acct = (string)(bl_body()['account'] ?? '');
    if (!valid_wallet($acct)) bl_err('That wallet address is not valid.');
    if (!eco_settings()['shop_open']) bl_err('The shop is closed for a moment. Try again soon.', 503);
    $pack = (string)($_GET['pack'] ?? '');
    $p = in_array($pack, BL_PACKS, true) ? eco_product($pack) : null;
    if (!$p) bl_err('That pack is not for sale.', 404);
    $who = bl_profile($acct);
    if (!$who) bl_err('This wallet is not connected to a Shilluminati Online profile yet. Open shyonsol.io/profile, tap Connect wallet, then come back. Nothing was charged.', 422);
    if (!empty($who['banned'])) bl_err(BANNED_MSG, 403);
    $q = units_for_usd($p['usd'], SHY_MINT);
    if (!$q) bl_err('Couldn\'t get a live $SHY price right now. Try again in a minute.', 502);
    $o = with_lock(function () use ($who, $p, $q, $acct) {
        $orders = load(ORDERS);
        $id = bin2hex(random_bytes(8));
        $o = ['id' => $id, 'pid' => $who['pid'], 'wallet' => $acct, 'product' => $p['id'], 'name' => $p['name'], 'usd' => $p['usd'], 'cur' => 'SHY', 'mint' => SHY_MINT,
            'units' => $q['units'], 'dec' => $q['dec'], 'px' => $q['px'], 'to' => mw_address(), 'ref' => new_reference(), 'ts' => time(), 'exp' => time() + ORDER_TTL, 'status' => 'open', 'checks' => 0, 'via' => 'blink'];
        if (($b = burn_units_for($q['units'], $q['dec'])) > 0) { $o['burn'] = $b; $o['bpct'] = (int)eco_settings()['burn_pct']; }
        $orders[$id] = $o;
        save(ORDERS, $orders);
        return $o;
    });
    if (empty($o['burn'])) bl_err('Payments in $SHY are paused for a moment. Use the Dojo Shop on shyonsol.io.', 503);
    $built = paytx_build($o, $acct);
    if (isset($built['err'])) bl_err($built['err']);
    with_lock(function () use ($o, $acct) { $orders = load(ORDERS); if (isset($orders[$o['id']])) { $orders[$o['id']]['txreq'] = time(); $orders[$o['id']]['txreq_by'] = $acct; save(ORDERS, $orders); } });
    $fmt = fn($u) => rtrim(rtrim(number_format($u / pow(10, $o['dec']), min(2, $o['dec']), '.', ','), '0'), '.');
    bl_out(['type' => 'transaction', 'transaction' => base64_encode($built['tx']),
        'message' => $p['name'] . ' for ' . $who['name'] . ': ' . $fmt($o['units'] - $o['burn']) . ' $SHY to the community wallet and ' . $fmt($o['burn']) . ' $SHY burned.',
        'links' => ['next' => ['type' => 'post', 'href' => '/api/actions/koban/done?o=' . $o['id']]]]);
}
if ($path === 'koban/done') {
    if ($method !== 'POST') bl_err('Use POST.', 405);
    bl_limit('done', 120, 600);
    $id = (string)($_GET['o'] ?? '');
    if (!preg_match('/^[a-f0-9]{16}$/', $id)) bl_err('Unknown order.', 404);
    $b = bl_body(); $sig = (string)($b['signature'] ?? '');
    $o = load(ORDERS)[$id] ?? null;
    if (!$o || ($o['via'] ?? '') !== 'blink') bl_err('Unknown order.', 404);
    $name = load(PLAYERS)[$o['pid']]['name'] ?? 'your profile';
    $done = fn($got) => bl_out(['type' => 'completed', 'icon' => bl_img('done'), 'title' => 'Koban added',
        'description' => '+' . number_format($got) . ' Koban are in ' . $name . '\'s account. Open the Dojo Shop on shyonsol.io to spend them.', 'label' => 'Done']);
    // fulfill() writes what was given as lines like "1,680 Koban" or "2,800 Koban (doubled)"
    $koban = function ($o) { $k = 0; foreach ((array)($o['got'] ?? []) as $g) if (preg_match('/^([\d,]+) Koban/', (string)$g, $m)) $k += (int)str_replace(',', '', $m[1]); return $k; };
    if ($o['status'] === 'paid') $done($koban($o));
    // keep the signature on the order, so the nightly payment check finds it even if this reply never arrives
    if ($sig && preg_match('/^[1-9A-HJ-NP-Za-km-z]{64,90}$/', $sig) && ($o['sig'] ?? '') !== $sig)
        with_lock(function () use ($id, $sig) { $orders = load(ORDERS); if (isset($orders[$id]) && $orders[$id]['status'] !== 'paid') { $orders[$id]['sig'] = $sig; $orders[$id]['sig_ts'] = time(); save(ORDERS, $orders); } });
    $v = verify_payment($o, $sig ?: (string)($o['sig'] ?? ''));
    if (!empty($v['paid'])) {
        $proof = $v['paid'];
        $r = with_lock(function () use ($id, $proof, $v) {
            $orders = load(ORDERS);
            foreach ($orders as $oid => $x) if ($oid !== $id && ($x['proof'] ?? '') === $proof) return ['err' => 1];
            if (!empty($v['selfpay'])) $orders[$id]['selfpay'] = 1;
            return ['o' => fulfill($orders, $id, $proof, $v)];
        });
        if (isset($r['err'])) bl_err('That payment was already used for another order.', 409);
        $done($koban($r['o']));
    }
    if (isset($v['failed']) || isset($v['dropped'])) bl_err('Solana didn\'t complete that payment, so nothing left your wallet. Try again.', 400);
    if (isset($v['short']) || isset($v['late']) || isset($v['nopay'])) bl_err('We found the payment but it needs a look from the team (order ' . $id . '). Message us in the $SHY Telegram and we\'ll sort it out.', 409);
    // not confirmed yet: offer to check again
    bl_out(['type' => 'action', 'icon' => bl_img('koban'), 'title' => 'Waiting for Solana', 'label' => 'Check again',
        'description' => 'Your payment is on its way. As soon as Solana confirms it, ' . $name . ' gets the Koban. Tap Check again in a few seconds.',
        'links' => ['actions' => [['type' => 'post', 'label' => 'Check again', 'href' => '/api/actions/koban/done?o=' . $id]]]]);
}

// ---------- the Daily
if ($path === 'daily' && $method === 'GET') {
    header('Cache-Control: public, max-age=120');
    $day = gmdate('Y-m-d'); $no = bl_daily_no($day);
    $n = count(load(DATA_DIR . '/daily.php')[$day] ?? []);
    bl_out(['type' => 'action', 'icon' => bl_img('daily'), 'title' => 'Daily Challenge #' . $no,
        'description' => 'One deal, the same for everyone, one shot a day. ' . ($n ? number_format($n) . ($n === 1 ? ' player has' : ' players have') . ' taken it so far today. ' : '') . (fair_daily_proof($day) !== null ? 'The deal was sealed a week ahead, so nobody can rig it. ' : '') . 'Free to play, and it counts for the Weekly League.',
        'label' => 'Play the Daily',
        'links' => ['actions' => [['type' => 'external-link', 'label' => 'Play Daily #' . $no, 'href' => '/api/actions/go/daily'], ['type' => 'external-link', 'label' => 'Check the seal', 'href' => '/api/actions/go/fair']]]]);
}

// ---------- Play, or beat a player's record
if (($path === 'play' || preg_match('#^play/[a-f0-9]{6}-[123]$#', $path)) && $method === 'GET') {
    header('Cache-Control: public, max-age=300');
    $tag = strtolower((string)($_GET['p'] ?? ''));
    if (preg_match('#^play/([a-f0-9]{6})-[123]$#', $path, $hm)) $tag = $hm[1];
    $who = null;
    if (preg_match('/^[a-f0-9]{6}$/', $tag)) foreach (load(PLAYERS) as $pid => $p) if (strpos($pid, $tag) === 0 && empty($p['hide'])) { $who = $p; break; }
    if ($who) {
        $w = (int)($who['wins'] ?? 0); $g = (int)($who['games'] ?? 0);
        bl_out(['type' => 'action', 'icon' => bl_img('play'), 'title' => 'Beat ' . $who['name'],
            'description' => $who['name'] . ' has ' . number_format($w) . ($w === 1 ? ' win' : ' wins') . ' in ' . number_format($g) . ($g === 1 ? ' game' : ' games') . ' of Shilluminati Online, the world domination card game. Free in your browser, no signup.',
            'label' => 'Take them on',
            'links' => ['actions' => [['type' => 'external-link', 'label' => 'Play free now', 'href' => '/api/actions/go/play'], ['type' => 'external-link', 'label' => 'See their record', 'href' => '/api/actions/go/p/' . $tag]]]]);
    }
    bl_out(['type' => 'action', 'icon' => bl_img('play'), 'title' => 'Shilluminati Online',
        'description' => 'The world domination card game from the $SHY community. 40 Regions, 71 Chaos cards, live matches, a Daily Challenge and the Shogun. Free in your browser, no signup, playing in ten seconds.',
        'label' => 'Play free',
        'links' => ['actions' => [['type' => 'external-link', 'label' => 'Play free now', 'href' => '/api/actions/go/play'], ['type' => 'external-link', 'label' => 'Today\'s Daily', 'href' => '/api/actions/go/daily'], ['type' => 'external-link', 'label' => 'Buy $SHY', 'href' => '/api/actions/go/token']]]]);
}
bl_err('Unknown action.', 404);
