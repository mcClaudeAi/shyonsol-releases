<?php
//MC 2026-10-18 just enough Solana for the buyback wallet: base58, PDAs, legacy transactions, ed25519 signing, and
//   signing the ready-made transaction Jupiter returns. Built for api/buyback.php; nothing here holds funds, it only
//   signs with the key the owner put in Admin. Checked against @solana/web3.js in /tmp tests (solsign_parity) so the
//   bytes match the real SDK before anything is sent.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const SOL_SYSTEM = '11111111111111111111111111111111';
const SOL_TOKEN = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
const SOL_ATA_PROG = 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL';
const SOL_WSOL = 'So11111111111111111111111111111111111111112';

function sol_compat() {
    if (!class_exists('ParagonIE_Sodium_Core_Curve25519')) {
        $f = __DIR__ . '/lib/sodium_compat/autoload.php';
        if (is_file($f)) require_once $f;
    }
    return class_exists('ParagonIE_Sodium_Core_Curve25519');
}
// base58, shared with the Phantom deeplink code
function sol_b58e($bin) { return ph_b58e($bin); }
function sol_b58d($s) { return ph_b58d($s); }

// Solana's is-on-curve check: a PDA must NOT decode as an ed25519 point
function sol_on_curve($pk32) {
    if (!sol_compat()) return true;   // never happens; being wrong here only makes derivation fail loudly later
    try { ParagonIE_Sodium_Core_Curve25519::ge_frombytes_negate_vartime($pk32); return true; }
    catch (Throwable $e) { return false; }
}
function sol_pda(array $seeds, $programId58) {
    $prog = sol_b58d($programId58);
    for ($bump = 255; $bump >= 0; $bump--) {
        $h = hash('sha256', implode('', $seeds) . chr($bump) . $prog . 'ProgramDerivedAddress', true);
        if (!sol_on_curve($h)) return [sol_b58e($h), $bump];
    }
    return [null, -1];
}
function sol_ata($owner58, $mint58) {
    [$a] = sol_pda([sol_b58d($owner58), sol_b58d(SOL_TOKEN), sol_b58d($mint58)], SOL_ATA_PROG);
    return $a;
}
// the secret from Admin: Phantom's 64-byte export (base58), or a 32-byte seed. Returns [sk64, pubkey58] or null.
function sol_keypair($secret58) {
    $raw = sol_b58d(trim((string)$secret58));
    if ($raw === null) return null;
    if (strlen($raw) === 64) return [$raw, sol_b58e(substr($raw, 32))];
    if (strlen($raw) === 32) {
        if (function_exists('sodium_crypto_sign_seed_keypair')) { $kp = sodium_crypto_sign_seed_keypair($raw); return [sodium_crypto_sign_secretkey($kp), sol_b58e(sodium_crypto_sign_publickey($kp))]; }
        if (sol_compat()) { $kp = ParagonIE_Sodium_Compat::crypto_sign_seed_keypair($raw); return [ParagonIE_Sodium_Compat::crypto_sign_secretkey($kp), sol_b58e(ParagonIE_Sodium_Compat::crypto_sign_publickey($kp))]; }
    }
    return null;
}
function sol_sign($msg, $sk64) {
    if (function_exists('sodium_crypto_sign_detached')) return sodium_crypto_sign_detached($msg, $sk64);
    sol_compat();
    return ParagonIE_Sodium_Compat::crypto_sign_detached($msg, $sk64);
}
function sol_cu16($n) {   // compact-u16
    $out = '';
    while (true) { $b = $n & 0x7f; $n >>= 7; if ($n === 0) { $out .= chr($b); return $out; } $out .= chr($b | 0x80); }
}
function sol_cu16_read($bin, &$i) {
    $n = 0; $shift = 0;
    while (true) { $b = ord($bin[$i++]); $n |= ($b & 0x7f) << $shift; if (!($b & 0x80)) return $n; $shift += 7; }
}
// one instruction: accounts are [pubkey58, signer, writable]
function sol_ix($program58, array $accounts, $data) { return ['p' => $program58, 'a' => $accounts, 'd' => $data]; }

// a legacy transaction: payer first, then the other signers, then writable accounts, then the rest
function sol_tx(array $ixs, $payer58, $blockhash32, $sk64) {
    $meta = [$payer58 => [true, true]];
    foreach ($ixs as $ix) {
        foreach ($ix['a'] as [$pk, $sgn, $wr]) {
            $m = $meta[$pk] ?? [false, false];
            $meta[$pk] = [$m[0] || $sgn, $m[1] || $wr];
        }
        $meta[$ix['p']] = $meta[$ix['p']] ?? [false, false];
    }
    $keys = array_keys($meta);
    usort($keys, function ($x, $y) use ($meta, $payer58) {
        if ($x === $payer58) return -1;
        if ($y === $payer58) return 1;
        $a = $meta[$x]; $b = $meta[$y];
        return [$b[0], $b[1]] <=> [$a[0], $a[1]];   // signers first, writable before read-only
    });
    $idx = array_flip($keys);
    $numSig = 0; $roSigned = 0; $roUnsigned = 0;
    foreach ($keys as $k) { [$sgn, $wr] = $meta[$k]; if ($sgn) { $numSig++; if (!$wr) $roSigned++; } elseif (!$wr) $roUnsigned++; }
    $msg = chr($numSig) . chr($roSigned) . chr($roUnsigned) . sol_cu16(count($keys));
    foreach ($keys as $k) $msg .= sol_b58d($k);
    $msg .= $blockhash32 . sol_cu16(count($ixs));
    foreach ($ixs as $ix) {
        $msg .= chr($idx[$ix['p']]) . sol_cu16(count($ix['a']));
        foreach ($ix['a'] as [$pk]) $msg .= chr($idx[$pk]);
        $msg .= sol_cu16(strlen($ix['d'])) . $ix['d'];
    }
    $sig = sol_sign($msg, $sk64);
    return base64_encode(sol_cu16($numSig) . $sig . str_repeat("\0", 64 * ($numSig - 1)) . $msg);
}
// sign the unsigned transaction Jupiter's order returns (v0 or legacy); the wallet must be its fee payer
function sol_sign_b64($b64, $sk64, $pub58) {
    $raw = base64_decode($b64, true);
    if ($raw === false || strlen($raw) < 70) return null;
    $i = 0;
    $nsig = sol_cu16_read($raw, $i);
    if ($nsig < 1 || $nsig > 8) return null;
    $msg = substr($raw, $i + 64 * $nsig);
    // the first required signer in the message must be our wallet
    $j = 0; $first = ord($msg[0]);
    if ($first & 0x80) $j = 1;   // a versioned message starts with the version byte
    $j += 3;                     // the three header counts
    $nacc = sol_cu16_read($msg, $j);
    if ($nacc < 1 || substr($msg, $j, 32) !== sol_b58d($pub58)) return null;
    $sig = sol_sign($msg, $sk64);
    return base64_encode(substr($raw, 0, $i) . $sig . substr($raw, $i + 64));
}

// ---------- the instructions the buyback needs ----------
function sol_ix_burn_checked($tokenAcct, $mint, $owner, $amount, $decimals) {
    return sol_ix(SOL_TOKEN, [[$tokenAcct, false, true], [$mint, false, true], [$owner, true, false]], chr(15) . pack('P', $amount) . chr($decimals));
}
function sol_ix_close_account($tokenAcct, $dest, $owner) {
    return sol_ix(SOL_TOKEN, [[$tokenAcct, false, true], [$dest, false, true], [$owner, true, false]], chr(9));
}
//MC the Jupiter referral program's claimV2 (TeamRaccoons/referral, idl claimV2): permissionless, the fees always go
//   to the partner wallet, our payer only cranks it. Both fee-out token accounts are init_if_needed by the program.
const SOL_REFER_PROG = 'REFER4ZgmyYx9c6He5XfaTMiGfdLwRnkV4RPp9t9iF3';
function sol_ix_claim_v2($payer, $project, $admin, $referral, $referralTok, $partner, $mint) {
    $disc = substr(hash('sha256', 'global:claim_v2', true), 0, 8);
    return sol_ix(SOL_REFER_PROG, [
        [$payer, true, true],
        [$project, false, false],
        [$admin, false, false],
        [sol_ata($admin, $mint), false, true],
        [$referral, false, false],
        [$referralTok, false, true],
        [$partner, false, false],
        [sol_ata($partner, $mint), false, true],
        [$mint, false, false],
        [SOL_SYSTEM, false, false],
        [SOL_TOKEN, false, false],
        [SOL_ATA_PROG, false, false],
    ], $disc);
}

// ---------- the chain ----------
function sol_blockhash() {
    $r = rpc('getLatestBlockhash', [['commitment' => 'confirmed']]);
    $h = (string)($r['value']['blockhash'] ?? '');
    $b = $h !== '' ? sol_b58d($h) : null;
    return $b !== null && strlen($b) === 32 ? $b : null;
}
function sol_send_b64($b64) {
    //MC 2026-10-18 preflight must simulate at confirmed: the blockhash comes from getLatestBlockhash(confirmed), and
    //   the default finalized simulation does not know it yet, so every send failed with Blockhash not found
    $r = rpc('sendTransaction', [$b64, ['encoding' => 'base64', 'skipPreflight' => false, 'maxRetries' => 3, 'preflightCommitment' => 'confirmed']]);
    return is_string($r) ? $r : (is_array($r) ? (string)($r['value'] ?? '') : '');
}
function sol_confirmed($sig, $tries = 10, $sleep = 800000) {
    for ($k = 0; $k < $tries; $k++) {
        $r = rpc('getSignatureStatuses', [[$sig]]);
        $st = $r['value'][0] ?? null;
        if (is_array($st) && !empty($st['err'])) return false;
        if (is_array($st) && in_array($st['confirmationStatus'] ?? '', ['confirmed', 'finalized'], true)) return true;
        usleep($sleep);
    }
    return false;
}
// the ReferralAccount and Project layouts, from the program source: 8-byte tag, then the fields in order
function sol_referral_read($referral58) {
    $r = rpc('getAccountInfo', [$referral58, ['encoding' => 'base64']]);
    $raw = base64_decode((string)($r['value']['data'][0] ?? ''), true);
    if ($raw === false || strlen($raw) < 74) return null;
    //MC 2026-10-18 share_bps sits right after the project: the partner's cut of each claim, for the fee pool
    return ['partner' => sol_b58e(substr($raw, 8, 32)), 'project' => sol_b58e(substr($raw, 40, 32)), 'share' => (int)(unpack('v', substr($raw, 72, 2))[1] ?? 0)];
}
function sol_project_admin($project58) {
    $r = rpc('getAccountInfo', [$project58, ['encoding' => 'base64']]);
    $raw = base64_decode((string)($r['value']['data'][0] ?? ''), true);
    if ($raw === false || strlen($raw) < 72) return null;
    return sol_b58e(substr($raw, 40, 32));
}
