<?php
// $SHY market data for the token page and the home page: the pair's live numbers and price history.
// GET ?a=pair                      price, 24h change, market cap, liquidity, volume, circulating supply
// GET ?a=candles&tf=m15|hour|day   price history, oldest first: [time, open, high, low, close, volume]
// Everything is cached in shy-data so a busy page never hammers DexScreener or GeckoTerminal.
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';

const MK_PAIR = 'FkXXLYB169GkEMTx3r6zJ4MXFFu29AY9w9cyj77hHVhb';
define('MARKET', DATA_DIR . '/market.php');
const MK_TF = [
    // timeframe => [GeckoTerminal path, aggregate, how many, cache seconds]
    'm15' => ['minute', 15, 200, 120],
    'hour' => ['hour', 1, 1000, 600],
    'day' => ['day', 1, 1000, 3600],
];

function mk_get($url) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_HTTPHEADER => ['Accept: application/json;version=20230302'], CURLOPT_USERAGENT => 'shyonsol.io']);
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : null;
}
// serve from the cache while it's fresh; when a refresh fails, the last good copy is better than nothing
function mk_cached($key, $ttl, $fetch) {
    $c = load(MARKET);
    $e = $c[$key] ?? null;
    if ($e && time() - $e['t'] < $ttl) return [$e['d'], $e['t']];
    // a source that just failed gets 30 seconds of rest before the next try
    if (time() - (int)($c['x_' . $key] ?? 0) < 30) return $e ? [$e['d'], $e['t']] : [null, 0];
    //MC 2026-10-11 one request fetches; everyone else gets the old numbers meanwhile (or, with nothing cached yet, waits for
    //   that one fetch). Every request that found the cache stale used to call the market API at the same moment.
    $lf = @fopen(DATA_DIR . '/market-' . preg_replace('/\W/', '', $key) . '.lock', 'c');
    if ($lf && !flock($lf, LOCK_EX | LOCK_NB)) {
        if ($e) { fclose($lf); return [$e['d'], $e['t']]; }
        flock($lf, LOCK_EX); flock($lf, LOCK_UN); fclose($lf);
        $e = load(MARKET)[$key] ?? null;
        return $e ? [$e['d'], $e['t']] : [null, 0];
    }
    try { $d = $fetch(); } finally { if ($lf) { flock($lf, LOCK_UN); fclose($lf); } }
    if (!$d) with_lock(function () use ($key) { $c = load(MARKET); $c['x_' . $key] = time(); save(MARKET, $c); });
    if ($d) {
        with_lock(function () use ($key, $d) { $c = load(MARKET); $c[$key] = ['t' => time(), 'd' => $d]; save(MARKET, $c); });
        return [$d, time()];
    }
    return $e ? [$e['d'], $e['t']] : [null, 0];
}

$a = $_GET['a'] ?? '';
if ($a === 'pair') {
    header('Cache-Control: public, max-age=30');
    [$d, $t] = mk_cached('pair', 60, function () {
        $j = mk_get('https://api.dexscreener.com/latest/dex/pairs/solana/' . MK_PAIR);
        $p = $j['pair'] ?? ($j['pairs'][0] ?? null);
        if (!$p || empty($p['priceUsd'])) return null;
        $price = (float)$p['priceUsd'];
        $mcap = (float)($p['marketCap'] ?? $p['fdv'] ?? 0);
        return ['price' => $price, 'change' => (float)($p['priceChange']['h24'] ?? 0), 'change1h' => (float)($p['priceChange']['h1'] ?? 0),
            'mcap' => $mcap, 'liq' => (float)($p['liquidity']['usd'] ?? 0), 'vol' => (float)($p['volume']['h24'] ?? 0),
            'buys' => (int)($p['txns']['h24']['buys'] ?? 0), 'sells' => (int)($p['txns']['h24']['sells'] ?? 0),
            'supply' => $price > 0 && $mcap > 0 ? round($mcap / $price) : 0, 'created' => (int)(($p['pairCreatedAt'] ?? 0) / 1000)];
    });
    if (!$d) fail('Market data is unavailable right now.', 503);
    out(['ok' => true, 'pair' => $d, 'at' => $t]);
}
if ($a === 'candles') {
    $tf = (string)($_GET['tf'] ?? 'hour');
    if (!isset(MK_TF[$tf])) fail('unknown timeframe');
    [$path, $agg, $limit, $ttl] = MK_TF[$tf];
    header('Cache-Control: public, max-age=' . min(300, $ttl));
    [$d, $t] = mk_cached('c_' . $tf, $ttl, function () use ($path, $agg, $limit) {
        $j = mk_get('https://api.geckoterminal.com/api/v2/networks/solana/pools/' . MK_PAIR . '/ohlcv/' . $path . '?aggregate=' . $agg . '&limit=' . $limit . '&currency=usd');
        $list = $j['data']['attributes']['ohlcv_list'] ?? null;
        if (!is_array($list) || !$list) return null;
        $rows = [];
        foreach ($list as $r) if (is_array($r) && count($r) >= 5) $rows[] = [(int)$r[0], (float)$r[1], (float)$r[2], (float)$r[3], (float)$r[4], (float)($r[5] ?? 0)];
        usort($rows, fn($x, $y) => $x[0] <=> $y[0]);
        return $rows;
    });
    // GeckoTerminal's free API only goes back 180 days, so daily candles are kept here and the history grows from now on
    if ($d && $tf === 'day') {
        $d = with_lock(function () use ($d) {
            $c = load(MARKET); $keep = [];
            foreach (array_merge($c['day_archive'] ?? [], $d) as $r) $keep[$r[0]] = $r;
            ksort($keep); $keep = array_values($keep);
            $c['day_archive'] = $keep; save(MARKET, $c);
            return $keep;
        });
    }
    if (!$d) fail('Price history is unavailable right now.', 503);
    //MC 2026-10-18 n: only the newest rows. The home page spark pulled 1,000 hourly candles (84KB) to draw 7 days
    $n = (int)($_GET['n'] ?? 0);
    if ($n > 0 && count($d) > $n) $d = array_slice($d, -$n);
    out(['ok' => true, 'tf' => $tf, 'c' => $d, 'at' => $t]);
}
fail('unknown action');
