<?php
// Public numbers for the Stats page: everything players have done, all in one answer. Cached for a minute.
// GET ?a=all
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/statslib.php';

if (!defined('DAILY')) define('DAILY', DATA_DIR . '/daily.php');
define('STATS_CACHE', DATA_DIR . '/stats-cache.php');
const STATS_TTL = 60;

function stats_build() {
    [$players, $st] = with_lock(function () {
        $pl = load(PLAYERS);
        $st = load(STATS);
        if (empty($st['back'])) { $st = stats_backfill($pl); save(STATS, $st); }   // first look: rebuild from players' recent games
        return [$pl, $st];
    });
    $reg = load(SHADOWREG);
    $holders = load(HOLDERS);
    $now = time();

    // lifetime totals, straight from every player record
    $T = ['players' => 0, 'games' => 0, 'wins' => 0, 'live' => 0, 'liveWins' => 0, 'holders' => 0, 'best' => 0, 'points' => 0, 'x' => 0, 'new7' => 0, 'active7' => 0];
    $people = [];
    foreach ($players as $pid => $p) {
        $g = (int)($p['games'] ?? 0);
        if ($g <= 0) continue;
        $T['players']++; $T['games'] += $g; $T['wins'] += (int)($p['wins'] ?? 0);
        $T['live'] += (int)($p['pvp_g'] ?? 0); $T['liveWins'] += (int)($p['pvp_w'] ?? 0);
        if (!empty($p['holder'])) $T['holders']++;
        if (!empty($p['xu'])) $T['x']++;
        $T['best'] = max($T['best'], (int)($p['best'] ?? 0));
        $T['points'] += (int)($p['points'] ?? 0);
        if (($p['since'] ?? 0) > $now - 7 * 86400) $T['new7']++;
        if (($p['last'] ?? 0) > $now - 7 * 86400) $T['active7']++;
        $people[] = ['pid' => $pid, 'p' => $p];
    }

    // the last 90 days, one row per day
    $days = [];
    $start = max(strtotime(gmdate('Y-m-d', $st['since'] ?: $now) . ' 00:00:00 UTC'), $now - 89 * 86400);
    for ($t = strtotime(gmdate('Y-m-d', $start) . ' 00:00:00 UTC'); $t <= $now; $t += 86400) {
        $d = gmdate('Y-m-d', $t);
        $x = $st['d'][$d] ?? stats_blank_day();
        $days[] = ['d' => $d, 'g' => $x['g'], 'solo' => $x['m']['solo'], 'daily' => $x['m']['daily'], 'live' => $x['m']['live'],
            'w' => $x['w'], 'l' => $x['l'], 't' => $x['t'], 'p' => count($x['p']), 'r' => $x['r'], 'h' => $x['h']];
    }

    // leaders
    $row = function ($e, $v) {
        $p = $e['p'];
        return ['name' => $p['name'] ?? '', 'tag' => substr($e['pid'], 0, 6), 'v' => $v, 'g' => (int)$p['games'], 'holder' => !empty($p['holder']),
            'img' => !empty($p['avatar']) ? shadow_img($p['avatar']) : '', 'x' => $p['xu'] ?? ''];
    };
    $top = function ($fn, $min = 0) use ($people, $row) {
        $list = array_values(array_filter($people, fn($e) => (int)$e['p']['games'] >= $min));
        usort($list, fn($a, $b) => $fn($b) <=> $fn($a));
        return array_map(fn($e) => $row($e, $fn($e)), array_slice($list, 0, 5));
    };
    $leaders = [
        'games' => $top(fn($e) => (int)$e['p']['games']),
        'wins' => $top(fn($e) => (int)($e['p']['wins'] ?? 0)),
        'rate' => $top(fn($e) => round(100 * ($e['p']['wins'] ?? 0) / max(1, $e['p']['games']), 1), 20),
        'live' => $top(fn($e) => (int)($e['p']['pvp_w'] ?? 0)),
    ];

    // the busiest Shadows
    $sh = [];
    foreach ($reg as $n => $r) if (($r['games'] ?? 0) > 0) $sh[] = ['n' => (string)$n, 'g' => (int)$r['games'], 'w' => (int)$r['wins'], 'best' => (int)($r['best'] ?? 0), 'img' => $r['img'] ?? ''];
    usort($sh, fn($a, $b) => [$b['w'], $b['g']] <=> [$a['w'], $a['g']]);

    // the latest games across everyone
    $recent = [];
    foreach ($people as $e) foreach (array_slice($e['p']['hist'] ?? [], 0, 6) as $h) $recent[] = ['name' => $e['p']['name'] ?? '', 'm' => stats_mode($h['m'] ?? ''), 'r' => $h['r'] ?? '', 'g' => (int)($h['g'] ?? 0), 't' => (int)$h['t'],
        'img' => !empty($e['p']['avatar']) ? shadow_img($e['p']['avatar']) : ''];
    usort($recent, fn($a, $b) => $b['t'] <=> $a['t']);

    // prizes
    $rw = load(REWARDS);
    $paid = 0; $weeks = 0;
    foreach ($rw['weeks'] ?? [] as $w) { $weeks++; foreach ($w['league'] ?? [] as $x) if (!empty($x['sig'])) $paid += (float)$x['usd']; foreach ($w['cup'] ?? [] as $x) if (!empty($x['sig'])) $paid += (float)$x['usd']; }

    $daily = load(DAILY);
    $more = stats_more($players, $now);
    return $more + ['ok' => true, 'at' => $now, 'since' => (int)($st['since'] ?? $now), 'totals' => $T, 'days' => $days,
        'cards' => $st['c'] ?? new stdClass(), 'cardGames' => (int)($st['cg'] ?? 0), 'cardWins' => (int)($st['cw'] ?? 0), 'cardSince' => (int)($st['csince'] ?? 0),
        'leaders' => $leaders, 'shadows' => array_slice($sh, 0, 6), 'shadowsPlayed' => count($sh), 'recent' => array_slice($recent, 0, 14),
        'league' => ['pool' => league_pool_usd()['total'], 'paid' => round($paid, 2), 'weeks' => $weeks, 'weekEnd' => week_end_ts()],
        'dailyToday' => count($daily[today()] ?? []), 'dailyNo' => daily_no_for(today())];
}
//MC 2026-10-12 the rebuilt Stats page: the Hall of Records (a top 10 for every record, each row a link to the player's page),
//   the biggest wins (single games won with the most Regions, from every player's recent games), players joining each day,
//   how each mode goes, how many Regions games end on, holders against Unbound, ranked tiers, Houses and daily streaks.
//   Banned players are left out everywhere; a hidden profile still shows by name but without a link.
function stats_more($players, $now) {
    $ban = function_exists('banned_in') ? banned_in($players) : [];
    $eco = load(ECO); $boss = load(DATA_DIR . '/boss.php');
    $row = function ($pid, $p, $v, $x = '') {
        $hold = !empty($p['holder']) && !empty($p['avatar']);
        return ['n' => (string)($p['name'] ?? ''), 's' => empty($p['hide']) ? str_replace(' ', '_', (string)($p['name'] ?? '')) : '', 'img' => $hold ? shadow_img($p['avatar']) : '',
            'h' => $hold, 'hs' => function_exists('house_tag_of') ? house_tag_of($pid) : '', 'v' => $v, 'x' => $x];
    };
    $ppl = [];
    foreach ($players as $pid => $p) { if (isset($ban[$pid]) || (int)($p['games'] ?? 0) <= 0 || ($p['name'] ?? '') === '') continue; $ppl[$pid] = $p; }
    $top = function ($fn, $ok = null, $xf = null, $n = 10) use ($ppl, $row) {
        $list = [];
        foreach ($ppl as $pid => $p) { if ($ok && !$ok($p, $pid)) continue; $v = $fn($p, $pid); if ($v === null || $v <= 0) continue; $list[] = [$pid, $p, $v]; }
        usort($list, fn($a, $b) => [$b[2], (int)($b[1]['games'] ?? 0)] <=> [$a[2], (int)($a[1]['games'] ?? 0)]);
        return array_map(fn($e) => $row($e[0], $e[1], $e[2], $xf ? $xf($e[1], $e[0]) : (int)($e[1]['games'] ?? 0) . ' games'), array_slice($list, 0, $n));
    };
    $wk = week_key();
    $rec = [
        'best'   => $top(fn($p) => (int)($p['best'] ?? 0)),
        'wins'   => $top(fn($p) => (int)($p['wins'] ?? 0)),
        'games'  => $top(fn($p) => (int)($p['games'] ?? 0)),
        'rate'   => $top(fn($p) => round(100 * ($p['wins'] ?? 0) / max(1, $p['games']), 1), fn($p) => (int)$p['games'] >= 20),
        'live'   => $top(fn($p) => (int)($p['pvp_w'] ?? 0), null, fn($p) => (int)($p['pvp_g'] ?? 0) . ' live matches'),
        'lrate'  => $top(fn($p) => round(100 * ($p['pvp_w'] ?? 0) / max(1, $p['pvp_g'] ?? 0), 1), fn($p) => (int)($p['pvp_g'] ?? 0) >= 10, fn($p) => (int)($p['pvp_g'] ?? 0) . ' live matches'),
        'points' => $top(fn($p) => (int)($p['points'] ?? 0)),
        'week'   => $top(fn($p) => ($p['wk'] ?? '') === $wk ? (int)($p['wpts'] ?? 0) : 0),
        'streak' => $top(fn($p, $pid) => (int)($eco[$pid]['st']['best'] ?? 0), null, fn($p, $pid) => 'now ' . (int)($eco[$pid]['st']['n'] ?? 0)),
        'badges' => $top(fn($p) => (int)($p['badges'] ?? 0)),
        'ranked' => $top(fn($p) => ($p['rk']['s'] ?? 0) === season_no() ? (int)($p['rk']['rp'] ?? 0) : 0),
        'shogun' => $top(fn($p, $pid) => (int)($boss['p'][$pid]['w'] ?? 0), null, fn($p, $pid) => (int)($boss['p'][$pid]['g'] ?? 0) . ' matches'),
    ];
    foreach ($rec['ranked'] as &$r) $r['x'] = RANK_NAMES[rank_tier($r['v'])] ?? ''; unset($r);

    // the biggest single wins: every won game in each player's recent games, most Regions first, then the newest
    $big = []; $dist = array_fill(0, 16, [0, 0]); $modes = [];
    foreach ($ppl as $pid => $p) foreach ($p['hist'] ?? [] as $h) {
        $m = ($h['m'] ?? '') === 'easy' ? 'easy' : (in_array($h['m'] ?? '', ['live', 'daily'], true) ? $h['m'] : 'normal');
        $g = max(0, min(15, (int)($h['g'] ?? 0))); $won = ($h['r'] ?? '') === 'win';
        $modes[$m] = ($modes[$m] ?? ['g' => 0, 'w' => 0, 'r' => 0]); $modes[$m]['g']++; $modes[$m]['r'] += $g; if ($won) $modes[$m]['w']++;
        $dist[$g][$won ? 1 : 0]++;
        if ($won) $big[] = ['pid' => $pid, 'g' => (int)($h['g'] ?? 0), 'm' => $m, 't' => (int)($h['t'] ?? 0)];
    }
    //MC 2026-10-23 each player's best win of all time joins in, so it stays on the board after it leaves the last 25 games.
    //   Records from before the best win was kept have only the number: one of 15 or more (a game won at the line) shows
    //   on All as an earlier game, with no mode or date.
    foreach ($ppl as $pid => $p) {
        $hw = 0; foreach ($p['hist'] ?? [] as $h) if (($h['r'] ?? '') === 'win') $hw = max($hw, (int)($h['g'] ?? 0));
        if (!empty($p['bw']['g'])) { if ((int)$p['bw']['g'] > $hw) { $bm = ($p['bw']['m'] ?? '') === 'easy' ? 'easy' : (in_array($p['bw']['m'] ?? '', ['live', 'daily'], true) ? $p['bw']['m'] : 'normal'); $big[] = ['pid' => $pid, 'g' => (int)$p['bw']['g'], 'm' => $bm, 't' => (int)($p['bw']['t'] ?? 0)]; } }
        elseif ((int)($p['best'] ?? 0) >= 15 && (int)$p['best'] > $hw) $big[] = ['pid' => $pid, 'g' => (int)$p['best'], 'm' => 'any', 't' => 0];
    }
    usort($big, fn($a, $b) => [$b['g'], $b['t']] <=> [$a['g'], $a['t']]);
    $bigOut = []; $seen = [];
    //MC 2026-10-12 one entry per player name (test data has several profiles with one name; one row each reads better anyway)
    foreach ($big as $b) { if (count($bigOut) >= 24) break; $k = $ppl[$b['pid']]['name'] . '|' . $b['m']; if (isset($seen[$k])) continue; $seen[$k] = 1; $bigOut[] = $row($b['pid'], $ppl[$b['pid']], $b['g'], $b['m']) + ['t' => $b['t'], 'w' => (int)($ppl[$b['pid']]['wins'] ?? 0), 'gm' => (int)($ppl[$b['pid']]['games'] ?? 0)]; }

    // players joining each day (90 days) and how many come back
    $join = []; $active = ['d1' => 0, 'd7' => 0, 'd30' => 0]; $hv = ['h' => [0, 0, 0], 'u' => [0, 0, 0]]; $tiers = array_fill_keys(array_keys(RANK_NAMES), 0); $club = 0;
    foreach ($ppl as $pid => $p) {
        $d = gmdate('Y-m-d', (int)($p['since'] ?? $now)); $join[$d] = ($join[$d] ?? 0) + 1;
        $l = (int)($p['last'] ?? 0);
        if ($l > $now - 86400) $active['d1']++; if ($l > $now - 7 * 86400) $active['d7']++; if ($l > $now - 30 * 86400) $active['d30']++;
        $k = !empty($p['holder']) ? 'h' : 'u'; $hv[$k][0]++; $hv[$k][1] += (int)$p['games']; $hv[$k][2] += (int)($p['wins'] ?? 0);
        if (($p['rk']['s'] ?? 0) === season_no() && !empty($p['rk']['n'])) $tiers[rank_tier((int)($p['rk']['rp'] ?? 0))]++;
        if ((int)($p['best'] ?? 0) >= 15) $club++;
    }
    $growth = []; $tot = 0; ksort($join);
    $first = gmdate('Y-m-d', $now - 89 * 86400);
    foreach ($join as $d => $n) if ($d < $first) $tot += $n;
    for ($t = strtotime($first . ' 00:00:00 UTC'); $t <= $now; $t += 86400) { $d = gmdate('Y-m-d', $t); $n = $join[$d] ?? 0; $tot += $n; $growth[] = [$d, $n, $tot]; }

    // streaks going right now (played today or yesterday)
    $live = [];
    $seenN = [];
    foreach ($ppl as $pid => $p) { $st = $eco[$pid]['st'] ?? null; if (!$st || (int)($st['n'] ?? 0) < 2) continue; if (($st['d'] ?? '') < gmdate('Y-m-d', $now - 86400)) continue; if (isset($seenN[$p['name']])) continue; $seenN[$p['name']] = 1; $live[] = $row($pid, $p, (int)$st['n'], (int)($st['best'] ?? 0)); }
    usort($live, fn($a, $b) => $b['v'] <=> $a['v']);

    $hb = function_exists('house_board') ? array_slice(house_board($players), 0, 8) : [];
    $houses = array_map(fn($h) => ['n' => $h['name'], 'tag' => $h['tag'], 'crest' => $h['crest'], 'c' => $h['color'], 'pts' => (int)$h['pts'], 'size' => (int)$h['size'], 'n2' => (int)$h['n']], $hb);

    return ['rec' => $rec, 'big' => $bigOut, 'growth' => $growth, 'active' => $active, 'modes' => $modes, 'dist' => $dist, 'hv' => $hv, 'tiers' => $tiers,
        'club' => $club, 'streaks' => array_slice($live, 0, 10), 'houses' => $houses];
}
function daily_no_for($day) { return (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1; }

$a = $_GET['a'] ?? 'all';
//MC 2026-10-10 a=when: the When and where section (games by hour of the week, the last month by hour, players online,
//   regions). Its own cache so the main numbers above stay as fast as they were.
if ($a === 'when') {
    require_once __DIR__ . '/whenlib.php';
    $wc = load(DATA_DIR . '/stats-when-cache.php');
    if (!empty($wc['at']) && time() - $wc['at'] < STATS_TTL) out($wc);
    [$players, $st] = with_lock(function () {
        $pl = load(PLAYERS); $st = load(STATS);
        if (empty($st['back'])) $st = stats_backfill($pl);
        if (empty($st['back2'])) { stats_backfill_hours($st, $pl); save(STATS, $st); }
        return [$pl, $st];
    });
    $res = rx_build($players, $st);
    save(DATA_DIR . '/stats-when-cache.php', $res);
    out($res);
}
if ($a === 'boss') {   //MC 2026-10-12 the Shogun section
    require_once __DIR__ . '/bosslib.php';
    $bc = load(DATA_DIR . '/stats-boss-cache.php');
    if (!empty($bc['at']) && time() - $bc['at'] < 30) out($bc);
    $res = boss_public(); save(DATA_DIR . '/stats-boss-cache.php', $res); out($res);
}
if ($a !== 'all') fail('unknown');
$cache = load(STATS_CACHE);
if (!empty($cache['at']) && time() - $cache['at'] < STATS_TTL ) out($cache);
$res = stats_build();
save(STATS_CACHE, $res);
out($res);
