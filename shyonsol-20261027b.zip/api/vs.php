<?php
//MC 2026-10-22 Community challenges, the public side (see vslib.php).
// GET  ?a=board&c=<slug>               the scoreboard for an approved community: their players against our leaders
// GET  ?a=logo&c=<slug>                the community's logo, kept on our server
// POST {a: join, pid, key, c: <slug>}  a new profile that opened a challenge link plays for that community
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/vslib.php';

$a = (string)($_GET['a'] ?? '');
$slug = strtolower((string)($_GET['c'] ?? ''));

if ($a === 'logo') {
    if (!preg_match('/^[a-z0-9-]{1,40}$/', $slug)) { http_response_code(404); exit; }
    $d = vs_all(); $c = $d['list'][$slug] ?? null;
    if (!$c || ($c['st'] ?? '') === 'block') { http_response_code(404); exit; }
    $f = vs_logo_file($slug);
    if ($f === '' && ($c['img'] ?? '') !== '') {
        // one fetch at a time per community, and not again for an hour after a miss
        $miss = VS_LOGOS . '/' . $slug . '.miss';
        if (!is_file($miss) || filemtime($miss) < time() - 3600) { $f = vs_logo_fetch($slug, $c['img']); if ($f === '') { if (!is_dir(VS_LOGOS)) @mkdir(VS_LOGOS, 0755, true); @touch($miss); } }
    }
    if ($f === '') { http_response_code(404); exit; }
    $mime = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif'][pathinfo($f, PATHINFO_EXTENSION)] ?? 'image/png';
    header('Content-Type: ' . $mime); header('Cache-Control: public, max-age=86400'); header('Content-Length: ' . filesize($f));
    readfile($f); exit;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($a === 'board') {
    if (!preg_match('/^[a-z0-9-]{1,40}$/', $slug)) fail('Not found', 404);
    $d = vs_all(); $c = $d['list'][$slug] ?? null;
    if (!$c || !vs_live($c)) fail('That challenge is not open.', 404);
    $b = vs_board($slug, $d);
    $pid = (string)($_GET['me'] ?? '');
    $mine = preg_match('/^[a-f0-9]{16}$/', $pid) ? vs_member($pid, $d) : '';
    out(['ok' => true, 'board' => $b, 'me' => $mine === '' ? '' : ($mine === $slug ? 'them' : 'other')]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$body = json_decode((string)file_get_contents('php://input'), true) ?: [];
if (($body['a'] ?? '') === 'join') {
    $pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? ''); $slug = strtolower((string)($body['c'] ?? ''));
    if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key) || !preg_match('/^[a-z0-9-]{1,40}$/', $slug)) fail('bad request');
    if (player_banned($pid)) fail(BANNED_MSG, 403);
    $kh = hash('sha256', $key);
    $r = with_lock(function () use ($pid, $kh, $slug) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'vsjoin:' . client_ip(), 20, 3600)) { save(LIMITS, $limits); return ['err' => 'Slow down a moment.', 'code' => 429]; }
        save(LIMITS, $limits);
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $d = vs_all(); $c = $d['list'][$slug] ?? null;
        if (!$c || !vs_live($c)) return ['err' => 'That challenge is not open.', 'code' => 404];
        $cur = (string)($d['m'][$pid]['c'] ?? '');
        $games = (int)($players[$pid]['games'] ?? 0);
        if ($cur === $slug) return ['side' => 'them', 'name' => $c['name']];
        // someone already on our board defends it; a player who started for one community stays with it
        if ($cur === '' && $games > 0) return ['side' => 'home', 'name' => $c['name']];
        if ($cur !== '' && $games > 0) return ['side' => 'other', 'name' => (string)($d['list'][$cur]['name'] ?? ''), 'for' => $c['name']];
        key_add($pid, $kh);
        $d['m'][$pid] = ['c' => $slug, 't' => time()];
        save(VS_FILE, $d);
        return ['side' => 'them', 'name' => $c['name'], 'new' => true];
    });
    if (isset($r['err'])) fail($r['err'], $r['code']);
    out(['ok' => true] + $r);
}
fail('unknown action');
