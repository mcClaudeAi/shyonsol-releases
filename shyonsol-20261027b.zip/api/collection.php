<?php
// The Dojo Shop's game side: card finishes and the Collection, card mastery, card backs, share card themes,
// boosts, the daily shop, the weekly bundle, the daily gift and the Koban Moon.
// Everything here is looks, progress and convenience. Nothing changes the cards, the deal or who wins.
// Included by economy.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

// ---------------------------------------------------------------- the deck
// The 71 Chaos cards and their kinds, from the rules engine
function deck_cards() {
    static $d = null;
    if ($d !== null) return $d;
    if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
    require_once __DIR__ . '/engine.php';
    $d = [];
    foreach (CARDS as $id => $c) if (($c['n'] ?? 0) > 0) $d[$id] = ['name' => $c['name'], 'kind' => $c['kind']];
    return $d;
}
function deck_card($id) { return deck_cards()[$id] ?? null; }

// ---------------------------------------------------------------- card finishes
// A finish changes how one card looks wherever it's drawn: your hand, the big card when it's played,
// and in live matches and tournaments, on every rival's screen.
// 'why' is what owning one says about you, shown in the shop. Finishes never change how a card plays.
//MC 2026-10-10 finish prices 3x, with the rest of the shop (see eco_catalog)
//MC 2026-10-10 then +50% again, 2x for the two that move (Gold Leaf's sheen, Holo's foil). Same rounding as eco_catalog
const FINISHES = [
    'gold'    => ['name' => 'Gold Leaf',   'koban' => 1500, 'desc' => 'Hammered gold over the ink.', 'why' => 'Free when you Master a card (100 plays), so it marks a card you really play.'],
    'crimson' => ['name' => 'Blood Moon',  'koban' => 1150, 'desc' => 'Washed in the red of a war moon.', 'why' => 'On the shelf every day. A war-red look for the cards you lean on.'],
    'neon'    => ['name' => 'Neon Shrine', 'koban' => 1800, 'desc' => 'Night-market neon with a soft glow.', 'why' => 'The brightest shelf finish, easy to spot on rivals\' screens in live matches.'],
    'holo'    => ['name' => 'Holo Foil',   'koban' => 4200, 'desc' => 'A moving rainbow foil. Only in the daily shop, three cards a day.', 'rot' => true, 'why' => 'The rarest you can buy. Only three cards get a Holo each day, and a card\'s Holo can take weeks to come back.'],
    'shadow'  => ['name' => 'Shadow Ink',  'earned' => true, 'desc' => 'Smoke and violet light. Earned on the Season Scroll, never sold.', 'why' => 'Never sold. Only that season\'s Scroll gives it, so it shows you were there that season.'],
    //MC 2026-10-10 the Animated finishes: twelve that move on the card, priced per card and well above the shelf.
    //   'rar' is the rarity the shop shows (rare, epic, legendary, mythic). On sale any day, never in the daily picks or the
    //   every-finish card set, so a whole card stays affordable. They do count for kind sets and the Collection.
    'ink'      => ['name' => 'Ink Bleed',      'koban' => 3000,  'rar' => 'rare', 'anim' => true, 'desc' => 'Sumi ink seeps in from the edges and pulls back, like wet paper.', 'why' => 'The quiet one. Reads as old woodblock on every screen it lands on.'],
    'seal'     => ['name' => 'Vermilion Seal', 'koban' => 3000,  'rar' => 'rare', 'anim' => true, 'desc' => 'Your red hanko stamps the corner, again and again.', 'why' => 'A seal on the card says it\'s yours. Rivals see it stamp every time you play it.'],
    'smoke'    => ['name' => 'Smoke Wisp',     'koban' => 3000,  'rar' => 'rare', 'anim' => true, 'desc' => 'Incense smoke curls up across the art.', 'why' => 'A slow, moody finish for the cards you hold back.'],
    'kintsugi' => ['name' => 'Kintsugi',       'koban' => 4500,  'rar' => 'epic', 'anim' => true, 'desc' => 'Gold-mended cracks that glow and fade like embers.', 'why' => 'Broken and mended in gold. A finish for the cards that won you comebacks.'],
    'sakura'   => ['name' => 'Sakura Drift',   'koban' => 4500,  'rar' => 'epic', 'anim' => true, 'desc' => 'Blossom petals drift across the card.', 'why' => 'Petals that never stop falling. Easy to spot in a rival\'s hand.'],
    'ember'    => ['name' => 'Ember Rise',     'koban' => 4500,  'rar' => 'epic', 'anim' => true, 'desc' => 'Sparks climb off the art and a low fire glows underneath.', 'why' => 'Made for Attacks. The card looks like it\'s still burning.'],
    'frost'    => ['name' => 'Frost Creep',    'koban' => 4500,  'rar' => 'epic', 'anim' => true, 'desc' => 'Frost grows in from the corners, glints and melts away.', 'why' => 'Cold and clean. Made for Defense cards and walls.'],
    'koi'      => ['name' => 'Koi Pond',       'koban' => 7500,  'rar' => 'legendary', 'anim' => true, 'desc' => 'Ripples spread across still water while two koi circle below.', 'why' => 'Legendary. Two koi swim under the art for as long as the card is on screen.'],
    'raijin'   => ['name' => 'Raijin Crackle', 'koban' => 7500,  'rar' => 'legendary', 'anim' => true, 'desc' => 'Lightning snaps across the card and lights it white.', 'why' => 'Legendary. The loudest finish in the game, made to be seen across the table.'],
    'glitch'   => ['name' => 'Glitch Scan',    'koban' => 7500,  'rar' => 'legendary', 'anim' => true, 'desc' => 'A scanline rolls down and the colours split and snap back.', 'why' => 'Legendary. The Shilluminati broadcast, hacked. Rivals will look twice.'],
    'aurora'   => ['name' => 'Aurora Veil',    'koban' => 7500,  'rar' => 'legendary', 'anim' => true, 'desc' => 'Northern lights roll over the art in green and violet.', 'why' => 'Legendary. A sky that keeps moving, on every card you put it on.'],
    'cosmos'   => ['name' => 'Night Sky',      'koban' => 12000, 'rar' => 'mythic', 'anim' => true, 'desc' => 'A deep starfield with a slow nebula and the odd shooting star.', 'why' => 'Mythic. The most expensive finish in the shop, so very few cards will ever wear it.'],
    //MC 2026-10-24 Imperial, above Mythic: black lacquer, beaten gold, a chrysanthemum crest and the sun sweeping the art
    'regalia'  => ['name' => 'Imperial Gilt',  'koban' => 30000, 'rar' => 'imperial', 'anim' => true, 'desc' => 'Black lacquer and beaten gold, a gold chrysanthemum crest and a sun that sweeps across the art.', 'why' => 'Imperial, above Mythic. For the one card you never leave home without.'],
];
//MC 2026-10-10 the finishes that existed before the Animated set. A "fully finished" card still means all of these, so
//   adding twelve new finishes didn't take that away from anyone
const FIN_CLASSIC = ['gold', 'crimson', 'neon', 'holo', 'shadow'];
// the Animated finishes, sold any day at full price
function finish_prem() { return array_keys(array_filter(FINISHES, fn($f) => !empty($f['anim']))); }
//MC 2026-10-10 Koban paid out when a reward is a finish the player already owns: a third of the price, about what it
//   was before prices went up 3x, so a duplicate never pays more than it used to
//MC 2026-10-10 still a third after the +50% raise, so it follows the price on its own
function finish_refund($f) { return (int)max(100, round((isset(FINISHES[$f]) ? fin_koban($f) : 900) / 3 / 10) * 10); }
// the finishes anyone can buy any day (Holo rotates, Shadow is earned)
function finish_shelf() { return ['gold', 'crimson', 'neon']; }

// Collection level: one point for every finish you own. Each level pays out once.
const COLLECTION = [
    1  => ['at' => 3,   'reward' => ['koban' => 50]],
    2  => ['at' => 10,  'reward' => ['item' => 'back_seigaiha']],
    3  => ['at' => 20,  'reward' => ['koban' => 150]],
    4  => ['at' => 35,  'reward' => ['item' => 'title_collector']],
    5  => ['at' => 50,  'reward' => ['item' => 'share_archive']],
    6  => ['at' => 75,  'reward' => ['koban' => 300]],
    7  => ['at' => 100, 'reward' => ['item' => 'frame_archive']],
    8  => ['at' => 140, 'reward' => ['koban' => 500]],
    9  => ['at' => 200, 'reward' => ['item' => 'title_curator']],
    10 => ['at' => 284, 'reward' => ['item' => 'back_vault']],
];
function collection_points($a) {
    $n = 0;
    foreach ($a['vf'] ?? [] as $fins) $n += count($fins);
    return $n;
}
function collection_level($a) {
    $pts = collection_points($a); $lv = 0;
    foreach (COLLECTION as $l => $c) if ($pts >= $c['at']) $lv = $l;
    return $lv;
}

// what a collection adds up to, for the profile: level, finishes of each kind, full sets and fully finished cards
function collection_show($a) {
    $deck = deck_cards(); $by = array_fill_keys(array_keys(FINISHES), 0); $kinds = []; $full = 0;
    foreach ($deck as $id => $c) $kinds[$c['kind']][] = $id;
    foreach ($a['vf'] ?? [] as $card => $fins) {
        if (!isset($deck[$card])) continue;
        $mine = array_intersect_key((array)$fins, FINISHES);
        foreach ($mine as $f => $_) $by[$f]++;
        if (!array_diff(FIN_CLASSIC, array_keys($mine))) $full++;   //MC 2026-10-10 the five classic finishes, see FIN_CLASSIC
    }
    // a set: every card of one kind in one finish (all Attacks in Gold Leaf)
    $sets = [];
    foreach ($kinds as $k => $ids) foreach (FINISHES as $f => $_) {
        $all = true;
        foreach ($ids as $id) if (empty($a['vf'][$id][$f])) { $all = false; break; }
        if ($all) $sets[] = ['kind' => $k, 'fin' => $f, 'of' => count($ids)];
    }
    return ['lv' => collection_level($a), 'n' => collection_points($a), 'by' => $by, 'sets' => $sets, 'full' => $full, 'cards' => count($deck)];
}

// Card mastery: every card you play yourself counts toward that card's mastery. Levels pay Koban once,
// and Master (level 4) gives the card's Gold Leaf finish for free.
const MASTERY = [1 => [5, 5], 2 => [15, 10], 3 => [40, 20], 4 => [100, 40], 5 => [200, 80]];   // level => [plays, Koban]
const MASTERY_NAMES = [1 => 'Novice', 2 => 'Adept', 3 => 'Veteran', 4 => 'Master', 5 => 'Grandmaster'];
function mastery_level($plays) { $lv = 0; foreach (MASTERY as $l => [$at]) if ($plays >= $at) $lv = $l; return $lv; }

// ---------------------------------------------------------------- boosts and goods (bought with Koban)
function eco_goods() {
    //MC 2026-10-10 2x (cosmetics went 3x; these help progress, so they rose less)
    //MC 2026-10-10 then +50% with the rest of the shop (Reroll 240 rounded to 250)
    return [
        ['id' => 'saver',  'name' => 'Streak Saver',    'koban' => 750, 'max' => 2, 'desc' => 'Miss a day without losing your daily streak. Used up on its own, one per missed day. Hold up to 2.'],
        ['id' => 'xp3',    'name' => 'XP Boost, 3 days', 'koban' => 750, 'desc' => '+50% Season Scroll XP from every game for 3 days. Buying more adds time.'],
        ['id' => 'xp7',    'name' => 'XP Boost, 7 days', 'koban' => 1500, 'desc' => '+50% Season Scroll XP from every game for 7 days. Buying more adds time.', 'tag' => 'Best value'],
        ['id' => 'skip',   'name' => 'Tier Skip',        'koban' => 450, 'desc' => 'Climb one Season Scroll tier right now.'],
        ['id' => 'reroll', 'name' => 'Mission Reroll',   'koban' => 250,  'desc' => 'Swap one of this week\'s missions for a new one. Scroll owners get one free every week.'],
        ['id' => 'bounty', 'name' => 'Bounty Board',     'koban' => 600, 'desc' => 'Two hard bounties for the rest of this week. Each pays 300 Koban and a Scroll tier. Free every week with Scroll+.'],
    ];
}
function eco_goods_priced() { static $g = null; if ($g === null) { $g = eco_goods(); foreach ($g as &$x) { $x['base'] = $x['koban']; $x['koban'] = shop_px('good', $x['id'], $x['base']); } unset($x); } return $g; }   //MC 2026-10-12
function eco_good($id) { foreach (eco_goods_priced() as $g) if ($g['id'] === $id) return $g; return null; }
const XP_BOOST = 50;   // % extra Scroll XP while a boost runs

// ---------------------------------------------------------------- holder pricing
// Holding $SHY lowers every Koban price in the shop (not Koban packs, not boosts that skip progress).
function holder_discount($tier) { return holder_perks($tier)['disc']; }   //MC 2026-10-10 from the tier ladder in economy.php
//MC 2026-10-12 Koban prices the team sets from Admin > Shop > Shop prices, on top of the prices in the code. Every price is
//   worked out from its code price ("base"): the whole shop %, then the % for its kind (nameplates, card backs...), then
//   the % for its rarity, rounded to a clean number (10s under 1,000, 50s above). A price typed in for one thing wins over
//   all the %s. Kept in shy-data/shop-prices.php; nothing there means every price is the code price, as before.
define('SHOP_PRICES', DATA_DIR . '/shop-prices.php');
function shop_prices() { static $p = null; if ($p === null) { $p = load(SHOP_PRICES); if (!is_array($p)) $p = []; $p += ['all' => 100, 'slot' => [], 'rarity' => [], 'fin' => 100, 'goods' => 100, 'fixed' => [], 'at' => 0, 'by' => '']; } return $p; }
function shop_round($n) { $n = max(10, $n); return (int)($n < 1000 ? round($n / 10) * 10 : round($n / 50) * 50); }
// $kind: item, fin or good. $group: an item's slot. $rar: rarity.
function shop_px($kind, $id, $base, $group = '', $rar = '') {
    $base = (int)$base; if ($base <= 0) return $base;
    $p = shop_prices();
    if (isset($p['fixed'][$kind . ':' . $id])) return max(10, (int)$p['fixed'][$kind . ':' . $id]);
    $pct = (float)$p['all'];
    if ($kind === 'item') $pct = $pct * (float)($p['slot'][$group] ?? 100) / 100 * (float)($p['rarity'][$rar] ?? 100) / 100;
    if ($kind === 'fin') $pct = $pct * (float)$p['fin'] / 100 * (float)($p['rarity'][$rar] ?? 100) / 100;
    if ($kind === 'good') $pct = $pct * (float)$p['goods'] / 100;
    return abs($pct - 100) < 0.001 ? $base : shop_round($base * $pct / 100);
}
// FINISHES with the team's prices ('base' keeps the code price)
function finishes_priced() { static $f = null; if ($f === null) { $f = []; foreach (FINISHES as $k => $x) $f[$k] = ['base' => $x['koban']] + $x; foreach ($f as $k => &$x) $x['koban'] = shop_px('fin', $k, $x['base'], '', $x['rar'] ?? ''); unset($x); } return $f; }
function fin_koban($f) { return (int)(finishes_priced()[$f]['koban'] ?? 0); }
function koban_price($base, $tier, $boost = false) {
    $d = $boost ? 0 : holder_discount($tier);
    return (int)max(5, round($base * (100 - $d) / 100 / 5) * 5);
}

// ---------------------------------------------------------------- the daily shop
// Same for everyone, new at 00:00 UTC. A deal of the day, three Holo Foil cards (the only way to get Holo)
// and four picks at a small discount. The team can roll a fresh shop for the day from the admin (shop_roll in the settings).
function seeded_pick(&$seed, $n) { $seed = ($seed * 1103515245 + 12345) & 0x7fffffff; return $seed % max(1, $n); }
function shop_today($day = null) {
    static $memo = [];
    $day = $day ?? today();
    $roll = (int)(eco_settings()['shop_roll'][$day] ?? 0);
    $key = $day . ($roll ? '#' . $roll : '');
    if (isset($memo[$key])) return $memo[$key];
    $seed = (int)sprintf('%u', crc32('shy-shop-' . $key));
    $cards = array_keys(deck_cards());
    $take = function () use (&$seed, &$cards) { $i = seeded_pick($seed, count($cards)); $c = $cards[$i]; array_splice($cards, $i, 1); return $c; };
    $shelf = finish_shelf();
    // holder-only Halos never take a daily slot: most players couldn't buy them
    // Profile Studio items stay on the profile page, so they never take a daily slot either
    $style = array_values(array_filter(eco_catalog()['items'], fn($it) => !empty($it['koban']) && $it['slot'] !== 'title' && empty($it['shadow']) && !in_array($it['slot'], ['banner', 'plate', 'pfx', 'accent', 'unlock', 'pframe', 'seal'], true)));   //MC 2026-10-10 plus the new Studio frames and seals
    $out = ['day' => $day, 'roll' => $roll, 'ends' => strtotime($day . ' 00:00:00 UTC') + 86400, 'holo' => [], 'picks' => []];
    // deal of the day: alternate between a card finish and a style item
    if (hexdec(substr(md5($key), 0, 2)) % 2 === 0) {
        $c = $take(); $f = $shelf[seeded_pick($seed, count($shelf))];
        $out['deal'] = ['kind' => 'fin', 'card' => $c, 'fin' => $f, 'was' => fin_koban($f), 'off' => 40];
    } else {
        $it = $style[seeded_pick($seed, count($style))];
        $out['deal'] = ['kind' => 'item', 'id' => $it['id'], 'was' => $it['koban'], 'off' => 40];
    }
    for ($i = 0; $i < 3; $i++) $out['holo'][] = ['kind' => 'fin', 'card' => $take(), 'fin' => 'holo', 'was' => fin_koban('holo'), 'off' => 0];
    for ($i = 0; $i < 3; $i++) { $f = $shelf[seeded_pick($seed, count($shelf))]; $out['picks'][] = ['kind' => 'fin', 'card' => $take(), 'fin' => $f, 'was' => fin_koban($f), 'off' => 15]; }
    $dealId = $out['deal']['id'] ?? '';
    $pool = array_values(array_filter($style, fn($it) => $it['id'] !== $dealId));
    $it = $pool[seeded_pick($seed, count($pool))];
    $out['picks'][] = ['kind' => 'item', 'id' => $it['id'], 'was' => $it['koban'], 'off' => 15];
    foreach (['deal'] as $k) $out[$k]['price'] = (int)round($out[$k]['was'] * (100 - $out[$k]['off']) / 100 / 5) * 5;
    foreach (['holo', 'picks'] as $k) foreach ($out[$k] as &$x) { $x['price'] = (int)round($x['was'] * (100 - $x['off']) / 100 / 5) * 5; } unset($x);
    return $memo[$key] = $out;
}
// today's price for a finish or item, if it's on the daily shop (null when it isn't)
function today_offer($kind, $a, $b = '') {
    $t = shop_today();
    foreach (array_merge([$t['deal']], $t['holo'], $t['picks']) as $x) {
        if ($x['kind'] !== $kind) continue;
        if ($kind === 'fin' && $x['card'] === $a && $x['fin'] === $b) return $x;
        if ($kind === 'item' && $x['id'] === $a) return $x;
    }
    return null;
}

// ---------------------------------------------------------------- the weekly bundle
// One themed set a week. The price only counts the parts you don't own yet, 30% off.
const BUNDLES = [
    'oni'      => ['name' => 'Oni Warlord', 'desc' => 'War-red attacks and a table to match.',
        'items' => ['emote_oni', 'table_crimson', 'title_oni', 'back_torii'], 'fin' => 'crimson', 'cards' => ['meteor', 'plasma', 'empire', 'endera', 'superweapon', 'unicoup']],
    'sakura'   => ['name' => 'Sakura Court', 'desc' => 'Blossom season for the builders.',
        'items' => ['frame_sakura', 'table_sakura', 'emote_sakura', 'share_sakura'], 'fin' => 'gold', 'cards' => ['atlantis', 'reinforce', 'galactic', 'galconsp', 'resource', 'surge']],
    'neon'     => ['name' => 'Neon Shogunate', 'desc' => 'Night-market tricks and a glowing card back.',
        'items' => ['back_neon', 'share_neon', 'fx_cyan', 'ring_jade'], 'fin' => 'neon', 'cards' => ['double', 'blitz', 'gravity', 'superai', 'neural', 'conspiracy']],
    'gold'     => ['name' => 'Golden Age', 'desc' => 'Riches for the whole table.',
        'items' => ['table_gold', 'fx_money', 'back_koban', 'emote_riches'], 'fin' => 'gold', 'cards' => ['boom', 'forgotten', 'overthrow', 'taxation', 'audit', 'renaissance']],
    'fortress' => ['name' => 'Iron Fortress', 'desc' => 'Every wall and decoy, dressed for war.',
        'items' => ['frame_obsidian', 'fx_lightning', 'back_dragon', 'title_daimyo'], 'fin' => 'neon', 'cards' => ['bunker', 'irondome', 'stronghold', 'lone', 'failedcoup', 'assassin', 'decoy']],
];
function bundle_now($wk = null) {
    $wk = $wk ?? week_key();
    $ids = array_keys(BUNDLES);
    $id = $ids[(int)sprintf('%u', crc32('shy-bundle-' . $wk)) % count($ids)];
    return ['id' => $id, 'ends' => week_end_ts()] + BUNDLES[$id];
}
// what's left to get in a bundle and what it costs this player (before the holder discount)
function bundle_quote($a, $b) {
    $full = 0; $left = 0; $parts = [];
    foreach ($b['items'] as $id) {
        $it = eco_item($id); if (!$it) continue;
        $p = (int)($it['koban'] ?? 0); $full += $p;
        if (!isset($a['items'][$id])) { $left += $p; $parts[] = ['item' => $id]; }
    }
    foreach ($b['cards'] as $c) {
        $p = fin_koban($b['fin']); $full += $p;
        if (empty($a['vf'][$c][$b['fin']])) { $left += $p; $parts[] = ['card' => $c, 'fin' => $b['fin']]; }
    }
    return ['full' => $full, 'left' => $left, 'price' => (int)round($left * 0.7 / 10) * 10, 'parts' => $parts];
}

// ---------------------------------------------------------------- sets in the Cards tab
// a whole card: every finish on the shelf for one card, 20% off what's missing
// a whole kind: one finish on every card of a kind (all Attacks in Gold Leaf), 25% off what's missing
function set_quote($a, $set) {
    $parts = [];
    if (preg_match('/^card:([a-z0-9]+)$/', $set, $m) && deck_card($m[1])) {
        foreach (finish_shelf() as $f) if (empty($a['vf'][$m[1]][$f])) $parts[] = ['card' => $m[1], 'fin' => $f];
        if (count($parts) < 2) return null;   // the set price is for two or more finishes
        $off = 20; $name = deck_card($m[1])['name'] . ', every finish';
    } elseif (preg_match('/^kind:([a-z]+):([a-z]+)$/', $set, $m) && in_array($m[2], array_merge(finish_shelf(), finish_prem()), true)) {   //MC 2026-10-10 Animated finishes come in kind sets too
        foreach (deck_cards() as $id => $c) if ($c['kind'] === $m[1] && empty($a['vf'][$id][$m[2]])) $parts[] = ['card' => $id, 'fin' => $m[2]];
        $off = 25; $name = 'Every ' . $m[1] . ' card in ' . FINISHES[$m[2]]['name'];
    } else return null;
    $left = 0; foreach ($parts as $p) $left += fin_koban($p['fin']);
    return ['parts' => $parts, 'left' => $left, 'price' => (int)round($left * (100 - $off) / 100 / 10) * 10, 'off' => $off, 'name' => $name];
}

// ---------------------------------------------------------------- granting
function grant_finish(&$a, $card, $fin) {
    if (!deck_card($card) || !isset(FINISHES[$fin])) return false;
    if (!empty($a['vf'][$card][$fin])) return false;
    $a['vf'][$card][$fin] = time();
    if (empty($a['veq'][$card])) $a['veq'][$card] = $fin;   // the first finish on a card goes on right away
    return true;
}
function grant_boost(&$a, $id) {
    if ($id === 'xp3' || $id === 'xp7') { $from = max(time(), (int)($a['boost']['xp'] ?? 0)); $a['boost']['xp'] = $from + ($id === 'xp3' ? 3 : 7) * 86400; return true; }
    if ($id === 'skip') { $a['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, (intdiv($a['sc']['xp'], TIER_XP) + 1) * TIER_XP + $a['sc']['xp'] % TIER_XP); return true; }
    if ($id === 'reroll') { $a['rrb'] = (int)($a['rrb'] ?? 0) + 1; return true; }   // banked rerolls
    if ($id === 'bounty') { missions_week_init($a); $a['ms']['b'] = 1; bounties_settle($a); return true; }
    if ($id === 'saver') { $a['saver'] = min(2, (int)($a['saver'] ?? 0) + 1); return true; }
    return false;
}
// apply one reward (Scroll tiers, collection levels): koban | item | fin | boost
function grant_reward(&$a, $r, $why) {
    $got = [];
    if (isset($r['koban'])) { eco_credit($a, $r['koban'], $why); $got[] = ['koban' => $r['koban']]; }
    if (isset($r['item'])) { eco_grant_item($a, $r['item']); $got[] = ['item' => $r['item']]; }
    if (isset($r['fin'])) {
        // already owned (bought before the reward came up): its Koban value instead
        if (grant_finish($a, $r['fin'][0], $r['fin'][1])) $got[] = ['fin' => $r['fin']];
        else { $k = finish_refund($r['fin'][1]); eco_credit($a, $k, $why . ' (finish already owned)'); $got[] = ['koban' => $k]; }
    }
    if (isset($r['boost'])) { grant_boost($a, $r['boost']); $got[] = ['boost' => $r['boost']]; }
    return $got;
}

// ---------------------------------------------------------------- daily gift and the Koban Moon
const GIFT_KOBAN = 20;       // every day
const GIFT_SUNDAY = 60;      // Sundays
const MOON_DAILY = 60;       // with an active Koban Moon
function gift_today($a, $tier) {
    $k = gmdate('w') === '0' ? GIFT_SUNDAY : GIFT_KOBAN;
    if ($tier) $k *= holder_perks($tier)['gift'];   //MC 2026-10-10 2x to 5x by tier (was double for every holder)
    $moon = (int)($a['moon'] ?? 0) > time() ? MOON_DAILY : 0;
    return ['koban' => $k, 'moon' => $moon, 'claimed' => ($a['gift'] ?? '') === today()];
}
