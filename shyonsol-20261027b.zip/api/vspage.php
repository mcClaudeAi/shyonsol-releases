<?php
//MC 2026-10-22 A community's challenge page (/vs/<slug>): the built vs.html with this community's title, words and
//   card in the head, so a link on X or Telegram previews as that community's own challenge card, and the scoreboard
//   already in the page so it paints at once. Only approved communities have a page; anything else is the 404.
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/vslib.php';

$slug = strtolower((string)($_GET['c'] ?? ''));
$tpl = dirname(__DIR__) . '/vs.html';
$d = preg_match('/^[a-z0-9-]{1,40}$/', $slug) ? vs_all() : null;
$c = $d['list'][$slug] ?? null;
if (!$c || !vs_live($c) || !is_file($tpl)) { http_response_code(404); header('Content-Type: text/html; charset=utf-8'); @readfile(dirname(__DIR__) . '/404.html'); exit; }
$b = vs_board($slug, $d);
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$url = vs_link($slug);
$img = 'https://shyonsol.io/api/share.php?vs=' . rawurlencode($slug) . '&h=' . vs_card_hash($b);
$title = $c['name'] . ' vs the Shilluminati';
$desc = $b['months'] . ' months in and still standing. Can ' . $c['name'] . ' holders beat the Shilluminati leaders this week? Free card game in your browser, no wallet needed.';
$html = (string)file_get_contents($tpl);
$set = function ($attr, $name, $val) use (&$html, $e) {
    $html = preg_replace('~<meta ' . $attr . '="' . preg_quote($name, '~') . '" content="[^"]*">~', '<meta ' . $attr . '="' . $name . '" content="' . $e($val) . '">', $html, 1);
};
$html = preg_replace('~<title>[^<]*</title>~', '<title>' . $e($title) . ' | Shy on Solana</title>', $html, 1);
$set('name', 'description', $desc);
foreach ([['property', 'og:title', $title], ['property', 'og:description', $desc], ['property', 'og:image', $img], ['property', 'og:url', $url], ['property', 'og:image:alt', $title . ' challenge card'],
    ['name', 'twitter:title', $title], ['name', 'twitter:description', $desc], ['name', 'twitter:image', $img], ['name', 'twitter:image:alt', $title . ' challenge card']] as [$at, $nm, $v]) $set($at, $nm, $v);
$html = preg_replace('~<link rel="canonical" href="[^"]*">~', '<link rel="canonical" href="' . $e($url) . '">', $html, 1);
// the board, ready for assets/vs.js (json_encode with the HEX flags can't close the script tag)
$html = str_replace('<!--VS-DATA-->', '<script>window.SHY_VS=' . json_encode($b, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) . ';</script>', $html);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
echo $html;
