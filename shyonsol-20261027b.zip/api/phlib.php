<?php
//MC 2026-10-23 the wallet deeplink helpers, shared by Shy Swap (api/swap.php) and the game's wallet connect
//   (api/wallet.php): base58, the box encryption Phantom and Solflare use for their deeplinks, and the wallet's base
//   address. Moved here unchanged from swap.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }
if (!defined('PH_B58')) define('PH_B58', '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz');
function ph_b58e($bin) {
    $bytes = array_values(unpack('C*', $bin) ?: []); $z = 0; $n = count($bytes);
    while ($z < $n && $bytes[$z] === 0) $z++;
    $d = [];
    foreach ($bytes as $b) { $c = $b; foreach ($d as $k => $v) { $c += $v << 8; $d[$k] = $c % 58; $c = intdiv($c, 58); } while ($c) { $d[] = $c % 58; $c = intdiv($c, 58); } }
    $o = str_repeat('1', $z); for ($k = count($d) - 1; $k >= 0; $k--) $o .= PH_B58[$d[$k]];
    return $o;
}
function ph_b58d($s) {
    $s = (string)$s; if ($s === '' || strspn($s, PH_B58) !== strlen($s)) return null;
    $z = strspn($s, '1'); $b = [];
    for ($i = 0, $L = strlen($s); $i < $L; $i++) { $c = strpos(PH_B58, $s[$i]); foreach ($b as $k => $v) { $c += $v * 58; $b[$k] = $c & 255; $c >>= 8; } while ($c) { $b[] = $c & 255; $c >>= 8; } }
    return str_repeat("\0", $z) . implode('', array_map('chr', array_reverse($b)));
}
//MC 2026-10-17 the live server's PHP has no sodium, so the same box (X25519 with XSalsa20-Poly1305, what Phantom uses)
//   comes from sodium_compat in api/lib when it's missing. 'ph_compat' in the config forces it, for testing.
function ph_native() { return function_exists('sodium_crypto_box_keypair_from_secretkey_and_publickey') && empty(shy_config()['ph_compat']); }
function ph_lib() {
    if (ph_native()) return true;
    if (!class_exists('ParagonIE_Sodium_Compat', false)) { $f = __DIR__ . '/lib/sodium_compat/autoload.php'; if (!is_file($f)) return false; require_once $f; }
    return class_exists('ParagonIE_Sodium_Compat');
}
function ph_keypair() { return ph_native() ? sodium_crypto_box_keypair() : ParagonIE_Sodium_Compat::crypto_box_keypair(); }
function ph_kp_sk($kp) { return ph_native() ? sodium_crypto_box_secretkey($kp) : ParagonIE_Sodium_Compat::crypto_box_secretkey($kp); }
function ph_kp_pk($kp) { return ph_native() ? sodium_crypto_box_publickey($kp) : ParagonIE_Sodium_Compat::crypto_box_publickey($kp); }
function ph_kp($sk, $pk) { return ph_native() ? sodium_crypto_box_keypair_from_secretkey_and_publickey($sk, $pk) : ParagonIE_Sodium_Compat::crypto_box_keypair_from_secretkey_and_publickey($sk, $pk); }
function ph_box($rec, $obj) {
    $nonce = random_bytes(24); $kp = ph_kp(base64_decode($rec['sk']), ph_b58d($rec['phpk']));
    $c = ph_native() ? sodium_crypto_box(json_encode($obj), $nonce, $kp) : ParagonIE_Sodium_Compat::crypto_box(json_encode($obj), $nonce, $kp);
    return [ph_b58e($nonce), ph_b58e($c)];
}
function ph_open($sk, $phpk58, $nonce58, $data58) {
    $pk = ph_b58d($phpk58); $n = ph_b58d($nonce58); $c = ph_b58d($data58);
    if (!$pk || strlen($pk) !== 32 || !$n || strlen($n) !== 24 || !$c) return null;
    $kp = ph_kp(base64_decode($sk), $pk);
    try { $m = ph_native() ? sodium_crypto_box_open($c, $n, $kp) : ParagonIE_Sodium_Compat::crypto_box_open($c, $n, $kp); } catch (Throwable $e) { $m = false; }
    return $m === false || $m === null ? null : json_decode($m, true);
}
if (!defined('TG_SITE_SWAP')) define('TG_SITE_SWAP', 'https://shyonsol.io');
function ph_site() { return shy_config()['site_url'] ?? TG_SITE_SWAP; }
function ph_ok() { return ph_lib(); }

//MC 2026-10-18 Solflare speaks the same deeplink protocol as Phantom (same box encryption, same steps); only the
//   domain and the name of the key parameter in its answer differ, so one flow carries both wallets
function ph_app_base($app) { return $app === 'solflare' ? 'https://solflare.com/ul/v1' : 'https://phantom.app/ul/v1'; }
function ph_app_name($app) { return $app === 'solflare' ? 'Solflare' : 'Phantom'; }
