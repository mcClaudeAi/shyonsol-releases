<?php
//MC 2026-10-19 the Invite page's data: the player's own invite link, the program numbers (from the settings, so
//   Admin changes show at once), their invites with what each has done, and their earnings. Names only on the
//   list, never ids or wallets, and a farmed pair shows as a plain invite with no earnings, so the page never
//   teaches a farmer which gate caught them.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$body = json_decode((string)file_get_contents('php://input'), true) ?: [];
$pid = (string)($body['pid'] ?? '');
$key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('Who is this?', 403);
$kh = hash('sha256', $key);
$ok = with_lock(function () use ($pid, $kh) { $l = load(LIMITS); $r = rate_ok($l, 'refpage:' . client_ip(), 30, 600); save(LIMITS, $l); return $r && key_ok($pid, $kh); });
if (!$ok) fail('Slow down a moment, or sign in again.', 429);
seen_mark($pid);

$players = load(PLAYERS);
$me = $players[$pid] ?? null;
$named = $me && !empty($me['name']) && !empty($me['games']);
require_once __DIR__ . '/friendslib.php';
$sum = ref_summary($pid);
$list = ref_list($pid);
//MC 2026-10-19 the link is the pretty /join/<tag> page now, whose preview is this player's own profile card;
//   'card' is that picture for the preview on the page (the game link inside still binds the same way)
$cardH = $named ? substr(sha1(json_encode([$me['name'], $me['points'] ?? 0, $me['wins'] ?? 0, $me['games'] ?? 0, $me['avatar'] ?? '', $me['holder'] ?? ''])), 0, 8) : '';
out(['ok' => true, 'on' => $sum['on'], 'named' => $named,
    'link' => $named ? 'https://shyonsol.io/join/' . fr_tag($pid) : '',
    'card' => $named ? '/api/share.php?p=' . fr_tag($pid) . '&h=' . $cardH : '',
    'name' => (string)($me['name'] ?? ''),
    'deal' => ['k' => $sum['k'], 'usd' => $sum['usd'], 'usdOn' => $sum['usdOn'], 'gate' => $sum['gate'], 'total' => $sum['total'], 'mint' => $sum['mint'], 'cut' => $sum['cut'], 'new' => $sum['new'], 'games' => $sum['games'], 'days' => $sum['days'], 'cap' => $sum['cap'],
        'ready' => $sum['ready'], 'invGames' => $sum['invGames'], 'myGames' => $sum['myGames'], 'readyIn' => $sum['readyIn']],   //MC 2026-10-22 the come-back rule and when this link starts counting
    'week' => $sum['week'],
    'rows' => $list['rows'], 'koban' => $list['koban'], 'usdPend' => $list['usdPend'], 'usdPaid' => $list['usdPaid'], 'need' => $list['need']]);
