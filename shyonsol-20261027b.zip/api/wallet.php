<?php
//MC 2026-10-23 the game's wallet connect on a phone with no wallet in the browser (Safari, Chrome, Telegram, the
//   home-screen app). Solflare opens only to approve and hands straight back: connect, then sign the holder message.
//   Before, the game sent phones into the wallet's own browser and left them there. The keys for the conversation live
//   here (the same box encryption Shy Swap uses, api/phlib.php); the page holds a random handle, asks how it went, and
//   finishes the usual verify itself with the signature (api/holder.php), so nothing about linking a wallet changes.
//   Solflare answers on /wl/<handle>/<step> (a plain path, so it can add its answer as the query) and that page sends
//   the player back where they started: the game in Telegram (t.me mini app link), or the Play page in the browser.
// GET  ?a=cfg                                  which wallets this site can offer (WalletConnect project id)
// POST {a: new|state|sign|end, pid, key, ...}  the conversation
// GET  ?a=back&s=&st=connect|sign              Solflare's answer (from /wl/<s>/<st>)
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/phlib.php';
ph_lib();   // the box encryption: native sodium, or sodium_compat where the server has none (the live host)
if (is_file(__DIR__ . '/tg.php')) require_once __DIR__ . '/tg.php';

const WL_FILE = DATA_DIR . '/wallet-links.php';
const WL_APPS = ['solflare'];   // Phantom keeps its own flow in the game; the protocol here works for it too
function wl_all() { $d = load(WL_FILE); return is_array($d) ? $d : []; }
function wl_get($id) { return preg_match('/^[a-f0-9]{32}$/', (string)$id) ? (wl_all()[$id] ?? null) : null; }
function wl_put($id, $rec) {
    with_lock(function () use ($id, $rec) {
        $d = wl_all(); $now = time();
        foreach ($d as $k => $v) if (($v['seen'] ?? $v['t']) < $now - 2 * 86400) unset($d[$k]);
        if ($rec === null) unset($d[$id]); else $d[$id] = $rec;
        if (count($d) > 3000) { uasort($d, fn($a, $b) => ($b['seen'] ?? 0) <=> ($a['seen'] ?? 0)); $d = array_slice($d, 0, 2000, true); }
        save(WL_FILE, $d);
    });
}
function wl_rate($what, $n, $per) {
    return with_lock(function () use ($what, $n, $per) { $l = load(LIMITS); $ok = rate_ok($l, 'wl-' . $what . ':' . client_ip(), $n, $per); save(LIMITS, $l); return $ok; });
}
function wl_view($r) { return ['ok' => true, 'stage' => $r['stage'], 'app' => $r['app'], 'wallet' => $r['wallet'], 'sig' => $r['sig'], 'err' => $r['err'], 'at' => $r['at'] ?? 0]; }
// where Solflare's answer sends the player: back into Telegram's mini app, or the Play page in the browser
function wl_home($r, $id) {
    if (($r['ret'] ?? '') === 'tg' && function_exists('tg_app_url')) { $u = tg_app_url('wallet'); if (strpos($u, 'https://t.me/') === 0) return $u; }
    return '/play?wl=' . $id . (($r['ret'] ?? '') === 'app' ? '&away=1' : '') . '#game';
}

$a = (string)($_GET['a'] ?? '');
if ($a === 'cfg') {
    $s = eco_settings();
    out(['ok' => true, 'wc' => (string)($s['wc_pid'] ?? ''), 'dl' => ph_ok()]);
}
if ($a === 'back') {
    header('Cache-Control: no-store');
    $id = (string)($_GET['s'] ?? ''); $stp = ($_GET['st'] ?? '') === 'sign' ? 'sign' : 'connect'; $r = wl_get($id);
    if (!$r) { header('Location: /play#game', true, 302); exit; }
    $name = ph_app_name($r['app']);
    if (isset($_GET['errorCode'])) {
        $r['err'] = (string)$_GET['errorCode'] === '4001' ? 'cancel' : mb_substr(preg_replace('/[^\p{L}\p{N} .,:\'_\-]/u', '', (string)($_GET['errorMessage'] ?? $name . ' could not finish that.')), 0, 160);
        $r['stage'] = $stp === 'sign' ? 'connected' : 'new';
    } elseif ($stp === 'connect') {
        $pk = (string)($_GET['solflare_encryption_public_key'] ?? ($_GET['phantom_encryption_public_key'] ?? ''));
        $m = ph_open($r['sk'], $pk, $_GET['nonce'] ?? '', $_GET['data'] ?? '');
        if ($m && valid_wallet((string)($m['public_key'] ?? '')) && !empty($m['session'])) { $r['phpk'] = $pk; $r['sess'] = (string)$m['session']; $r['wallet'] = (string)$m['public_key']; $r['stage'] = 'connected'; $r['err'] = ''; }
        else $r['err'] = $name . '\'s answer could not be read. Try connecting again.';
    } else {
        $m = $r['phpk'] !== '' ? ph_open($r['sk'], $r['phpk'], $_GET['nonce'] ?? '', $_GET['data'] ?? '') : null;
        $sig = $m ? ph_b58d((string)($m['signature'] ?? '')) : null;
        if ($sig && strlen($sig) === 64) { $r['sig'] = base64_encode($sig); $r['stage'] = 'signed'; $r['err'] = ''; }
        else { $r['err'] = $name . '\'s answer could not be read. Try signing again.'; $r['stage'] = 'connected'; }
    }
    $r['at'] = time(); $r['seen'] = time(); wl_put($id, $r);
    header('Location: ' . wl_home($r, $id), true, 302);
    exit;
}

$raw = file_get_contents('php://input');
if (strlen($raw) > 6000) fail('too large');
$b = json_decode($raw, true) ?: [];
$a = (string)($b['a'] ?? '');
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
if (!ph_ok()) fail('Wallet approval is not available here yet.', 503);
// the conversation belongs to the profile that started it
$mine = function ($id) use ($pid, $kh) { $r = wl_get($id); return $r && $r['pid'] === $pid && hash_equals($r['kh'], $kh) ? $r : null; };

if ($a === 'new') {
    if (!wl_rate('new', 20, 600)) fail('Slow down a little and try again.', 429);
    $app = in_array($b['app'] ?? '', WL_APPS, true) ? $b['app'] : 'solflare';
    $ret = in_array($b['ret'] ?? '', ['web', 'tg', 'app'], true) ? $b['ret'] : 'web';
    $kp = ph_keypair(); $id = bin2hex(random_bytes(16));
    wl_put($id, ['t' => time(), 'seen' => time(), 'app' => $app, 'ret' => $ret, 'pid' => $pid, 'kh' => $kh, 'sk' => base64_encode(ph_kp_sk($kp)), 'pk' => ph_b58e(ph_kp_pk($kp)),
        'phpk' => '', 'sess' => '', 'wallet' => '', 'stage' => 'new', 'sig' => '', 'err' => '', 'at' => 0]);
    $url = ph_app_base($app) . '/connect?' . http_build_query(['app_url' => ph_site(), 'dapp_encryption_public_key' => ph_b58e(ph_kp_pk($kp)),
        'redirect_link' => ph_site() . '/wl/' . $id . '/connect', 'cluster' => 'mainnet-beta']);
    out(['ok' => true, 's' => $id, 'url' => $url]);
}
if ($a === 'state') {
    if (!wl_rate('state', 240, 600)) fail('Slow down a little and try again.', 429);
    $r = $mine((string)($b['s'] ?? ''));
    if (!$r) out(['ok' => true, 'gone' => true]);
    out(wl_view($r));
}
// the holder message to sign: the page fetched it from api/holder.php (nonce) for this wallet
if ($a === 'sign') {
    if (!wl_rate('sign', 30, 600)) fail('Slow down a little and try again.', 429);
    $id = (string)($b['s'] ?? ''); $r = $mine($id);
    if (!$r || $r['sess'] === '' || $r['wallet'] === '') fail('Connect ' . ph_app_name($r['app'] ?? 'solflare') . ' again.', 409);
    $msg = (string)($b['message'] ?? '');
    if ($msg === '' || strlen($msg) > 1200 || strpos($msg, $r['wallet']) === false) fail('bad message');
    [$nonce, $payload] = ph_box($r, ['message' => ph_b58e($msg), 'session' => $r['sess'], 'display' => 'utf8']);
    $r['stage'] = 'signing'; $r['sig'] = ''; $r['err'] = ''; $r['seen'] = time(); wl_put($id, $r);
    $url = ph_app_base($r['app']) . '/signMessage?' . http_build_query(['dapp_encryption_public_key' => $r['pk'], 'nonce' => $nonce,
        'redirect_link' => ph_site() . '/wl/' . $id . '/sign', 'payload' => $payload]);
    out(['ok' => true, 'url' => $url]);
}
if ($a === 'end') {
    $id = (string)($b['s'] ?? ''); if ($mine($id)) wl_put($id, null);
    out(['ok' => true]);
}
fail('unknown action');
