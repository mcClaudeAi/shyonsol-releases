<?php
//MC 2026-10-09 The 15 Club: a monthly bounty for the rarest win in the game. Winning while holding 15 Regions ends a
//game on the spot, and it almost never happens (0 in 3,250 simulated games, even with the best-move hints playing).
//The first player each calendar month (UTC) to do it in a qualifying game takes the bounty, one winner a month.
//MC 2026-10-25 New rule from November 2026: the bounty goes to whoever has the MOST wins holding all 15 Regions in the
//   month, not the first one. Every qualifying 15 Region win counts toward the month's race, the board stays open all
//   month, and the winner is settled once the month is over (UTC). A tie goes to whoever reached that number first.
//   October 2026 was already won and paid under the first-to-do-it rule, so months before BOUNTY_MOST_FROM keep it.
//Qualifying: a verified solo game on Normal with hints off, a first Daily run, or any live match where the player was
//at the table to the end. Duels don't count (two people share the deal). Everyone who does it gets the 15 Club title.
//Entry is free and nothing sold in the shop changes the cards or the deal, so buying Koban never helps anyone win this.
//The bounty is paid by hand from the marketing wallet; the admin marks it paid with the transaction.
//Callers already hold with_lock (lb.php submit, livelib.php end of match), so nothing here takes the lock again.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('BOUNTY', DATA_DIR . '/bounty.php');   // ['cfg' => [on, prize], 'm' => month => winner, 'club' => pid => [n, first, last], 'k' => month => pid => [c, t, n], 'void' => month => pid => 1, 'done' => month => 1]
const BOUNTY_AT = 15;
// the test run before launch: 3,250 full games played by bots and the best-move engine, none won holding all 15
const BOUNTY_SIM = ['games' => 3250, 'wins' => 0, 'best' => 14];
// local testing only: shy-data/config.php can lower it so a test can reach it (like tg_api for the bot)
function bounty_at() { return max(1, (int)(shy_config()['bounty_at'] ?? BOUNTY_AT)); }

function bounty_db() { $d = load(BOUNTY); $d = is_array($d) ? $d : []; return $d + ['cfg' => [], 'm' => [], 'club' => [], 'best' => [], 'k' => [], 'void' => [], 'done' => []]; }
function bounty_cfg($d = null) { $d = $d ?? bounty_db(); return ($d['cfg'] ?? []) + ['on' => true, 'prize' => '$50 in $SHY']; }
function bounty_month($t = null) { return gmdate('Y-m', $t ?? time()); }
function bounty_ends($m = null) { return strtotime(($m ?? bounty_month()) . '-01 00:00:00 UTC +1 month'); }
const BOUNTY_MOST_FROM = '2026-11';   // first month decided by the most 15 Region wins
function bounty_most($m = null) { return strcmp($m ?? bounty_month(), (string)(shy_config()['bounty_most_from'] ?? BOUNTY_MOST_FROM)) >= 0; }   // config override is for local testing only, like bounty_at
//MC 2026-10-25 the month's race: every player with at least one 15 Region win, most wins first, ties to whoever got
//   there first. Players the admin took a win back from for fair play are left out of that month.
function bounty_race($d, $m) {
    $r = [];
    foreach ($d['k'][$m] ?? [] as $pid => $x) { if (!empty($d['void'][$m][$pid]) || (int)($x['c'] ?? 0) < 1) continue; $r[$pid] = $x; }
    uasort($r, fn($a, $b) => [(int)$b['c'], (int)$a['t']] <=> [(int)$a['c'], (int)$b['t']]);
    return $r;
}
// is there a finished month on the new rule that hasn't been given out yet? (cheap, no lock)
function bounty_due($d, $now = null) {
    $cur = bounty_month($now);
    foreach (array_keys($d['k'] ?? []) as $m) if (bounty_most($m) && strcmp($m, $cur) < 0 && empty($d['done'][$m]) && empty($d['m'][$m])) return true;
    return false;
}
// give out every finished month on the new rule. Caller holds with_lock and saves when this returns true.
function bounty_settle(&$d, $now = null) {
    $now = $now ?? time(); $cur = bounty_month($now); $ch = false; $cfg = bounty_cfg($d);
    foreach (array_keys($d['k'] ?? []) as $m) {
        if (!bounty_most($m) || strcmp($m, $cur) >= 0 || !empty($d['done'][$m]) || !empty($d['m'][$m])) continue;
        $d['done'][$m] = 1; $ch = true;
        $race = bounty_race($d, $m); if (!$race) continue;
        $pid = array_key_first($race); $x = $race[$pid]; $c = (int)$x['c']; $name = (string)$x['n'];
        $second = array_values(array_slice($race, 1, 1))[0] ?? null;
        $d['m'][$m] = ['pid' => $pid, 'name' => $name, 'mode' => 'most', 'regions' => bounty_at(), 'wins' => $c, 't' => (int)$x['t'], 'prize' => $cfg['prize'], 'paid' => 0, 'tx' => '', 'settled' => $now];
        $mon = gmdate('F', strtotime($m . '-01'));
        $wins = $c . ($c === 1 ? ' win' : ' wins');
        if (function_exists('alert_bounty')) alert_bounty($pid, $name, 'most', $c, $cfg['prize'], $m);
        if (function_exists('tg_post')) tg_post('bounty', '🏆 <b>' . tg_h($name) . ' takes the ' . $mon . ' 15 Club bounty!</b>' . "\n" . 'The most wins holding all ' . bounty_at() . ' Regions this month: ' . $wins . ($second ? ', ahead of ' . tg_h($second['n']) . ' with ' . (int)$second['c'] . '.' : '.') . ' ' . tg_h($cfg['prize']) . ' is on its way.' . "\n\n" . 'The ' . gmdate('F', bounty_ends($m)) . ' race is already on.', 'bounty:' . $m);
        if (function_exists('tg_user_of')) { $u = tg_user_of($pid); if ($u && !empty($u['dm'])) tg_dm($u['id'], '🏆 <b>You won the ' . $mon . ' 15 Club bounty!</b> Nobody won holding all 15 Regions more than you did (' . $wins . '). ' . tg_h($cfg['prize']) . ' goes to the wallet you connect on your profile. Connect one now if you haven\'t, and the team will send it.', tg_kb_private('🎴 Open the game')); }
    }
    if ($ch && count($d['k'] ?? []) > 4) { krsort($d['k']); $d['k'] = array_slice($d['k'], 0, 4, true); }
    return $ch;
}

// a qualifying game just ended. Returns null when it doesn't count, else what happened for the player.
//MC 2026-10-09 Closest to 15: every qualifying game also counts toward this month's board of the most Regions held at the
//end, so everyone can see who's closing in. One line per player (their best), ties go to whoever got there first.
const BOUNTY_BOARD = 60;   // players kept per month
function bounty_track(&$d, $pid, $name, $regions, $result, $now) {
    $m = bounty_month($now);
    $b = $d['best'][$m] ?? [];
    $cur = $b[$pid] ?? null;
    $won = $result === 'win' ? 1 : 0;
    if ($cur && [$cur['r'], $cur['w']] >= [$regions, $won]) { if ($cur['n'] !== $name) { $b[$pid]['n'] = $name; $d['best'][$m] = $b; return true; } return false; }
    $b[$pid] = ['r' => (int)$regions, 'w' => $won, 't' => $now, 'n' => $name];
    uasort($b, fn($x, $y) => [$y['r'], $y['w'], $x['t']] <=> [$x['r'], $x['w'], $y['t']]);
    $d['best'][$m] = array_slice($b, 0, BOUNTY_BOARD, true);
    // keep the last 3 months only
    if (count($d['best']) > 3) { krsort($d['best']); $d['best'] = array_slice($d['best'], 0, 3, true); }
    return true;
}
function bounty_board($d, $m, $n = 10) {
    $out = []; $i = 0;
    //MC 2026-10-25 from November the board is the month's race: most 15 Region wins first (ties to whoever got there
    //   first), then everyone else by the most Regions they've held at the end, so there's a race even before anyone wins one
    if (bounty_most($m)) {
        $race = bounty_race($d, $m); $rows = [];
        foreach ($race as $pid => $x) $rows[$pid] = ['name' => $x['n'], 'r' => bounty_at(), 'won' => true, 'tag' => substr($pid, 0, 6), 't' => (int)$x['t'], 'k' => (int)$x['c']];
        foreach ($d['best'][$m] ?? [] as $pid => $x) { if (isset($rows[$pid]) || !empty($d['void'][$m][$pid])) continue; $rows[$pid] = ['name' => $x['n'], 'r' => min(bounty_at(), (int)$x['r']), 'won' => (bool)$x['w'], 'tag' => substr($pid, 0, 6), 't' => $x['t'], 'k' => 0]; }
        return array_slice(array_values($rows), 0, $n);
    }
    //MC 2026-10-11 games after the claim never count (the 17 already on October's board came in after it)
    $w = $d['m'][$m] ?? null;
    foreach ($d['best'][$m] ?? [] as $pid => $x) { if ($w && $x['t'] > $w['t'] && $pid !== $w['pid']) continue; $out[] = ['name' => $x['n'], 'r' => min(bounty_at(), (int)$x['r']), 'won' => (bool)$x['w'], 'tag' => substr($pid, 0, 6), 't' => $x['t']]; if (++$i >= $n) break; }
    return $out;
}

function bounty_claim($pid, $name, $mode, $regions, $result) {
    $now = time();
    $d = bounty_db();
    bounty_settle($d, $now);   //MC 2026-10-25 a finished month is given out on the first game after it ends
    //MC 2026-10-09 how rare it is, counted from real games: every game that counts, the wins holding all of them, and
    //   the most anyone has held at the end. Shown on the bounty card next to the test-game figure.
    $m = bounty_month($now);
    $most = bounty_most($m);
    //MC 2026-10-11 once this month's bounty is claimed the month is over: the "Closest to 15" board and this month's game
    //   count stop where they were (a 17 won after the claim still went up on the board, showing 17/15). Games still
    //   count toward the all-time figures, and anyone who does it still joins the 15 Club.
    //MC 2026-10-25 on the new rule nothing is claimed mid-month, so the board and the count run to the end of the month
    $claimed = !$most && !empty($d['m'][$m]);
    $tot = ($d['tot'] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'since' => $now, 'm' => []];
    $tot['g']++; if ($regions >= bounty_at() && $result !== 'loss') $tot['w']++;
    $tot['best'] = max($tot['best'], min(bounty_at(), (int)$regions));
    if (!$claimed) $tot['m'][$m] = ($tot['m'][$m] ?? 0) + 1;
    if (count($tot['m']) > 3) { krsort($tot['m']); $tot['m'] = array_slice($tot['m'], 0, 3, true); }
    $d['tot'] = $tot;
    if (function_exists('track')) track('bounty_games');
    if (!empty(bounty_cfg($d)['on']) && !$claimed) bounty_track($d, $pid, $name, min(bounty_at(), (int)$regions), $result, $now);
    save(BOUNTY, $d);
    if ($regions < bounty_at() || $result === 'loss') return null;
    $cfg = bounty_cfg($d);
    $c = $d['club'][$pid] ?? ['n' => 0, 'first' => $now];
    $c['n']++; $c['last'] = $now; $c['name'] = $name;
    $d['club'][$pid] = $c;
    // the 15 Club title, for everyone who does it
    $eco = load(ECO);
    if (isset($eco[$pid])) { $a = eco_get($eco, $pid); eco_grant_item($a, 'title_club15'); $eco[$pid] = $a; save(ECO, $eco); }
    trophy_award($pid, 'club15', 'once');   //MC 2026-10-15 the first 15 Club win, as a trophy
    $out = ['club' => true, 'title' => 'title_club15', 'month' => $m, 'prize' => $cfg['prize'], 'next' => bounty_ends($m)];
    if ($most) {
        //MC 2026-10-25 count the win toward the month's race and tell the player where it puts them
        if (!empty($cfg['on'])) {
            $k = $d['k'][$m][$pid] ?? ['c' => 0, 't' => $now, 'n' => $name];
            $k['c']++; $k['t'] = $now; $k['n'] = $name;
            $d['k'][$m][$pid] = $k;
            $race = bounty_race($d, $m); $rank = array_search($pid, array_keys($race), true);
            $lead = $race ? $race[array_key_first($race)] : null;
            $out += ['race' => true, 'wins' => (int)$k['c'], 'rank' => $rank === false ? 0 : $rank + 1, 'of' => count($race), 'ends' => bounty_ends($m),
                'leader' => $lead ? ['name' => $lead['n'], 'wins' => (int)$lead['c']] : null, 'void' => !empty($d['void'][$m][$pid])];
        }
    } elseif (!empty($cfg['on']) && empty($d['m'][$m])) {
        $d['m'][$m] = ['pid' => $pid, 'name' => $name, 'mode' => $mode, 'regions' => $regions, 't' => $now, 'prize' => $cfg['prize'], 'paid' => 0, 'tx' => ''];
        $out['won'] = true;
        if (function_exists('alert_bounty')) alert_bounty($pid, $name, $mode, $regions, $cfg['prize'], $m);
        if (function_exists('tg_post')) tg_post('bounty', '🏆 <b>' . tg_h($name) . ' takes the 15 Club bounty!</b>' . "\n" . 'A win holding all ' . bounty_at() . ' Regions, the rarest finish in Shilluminati. ' . tg_h($cfg['prize']) . ' is on its way.' . "\n\n" . 'The next bounty opens ' . gmdate('F j', bounty_ends($m)) . '.', 'bounty:' . $m);
        if (function_exists('tg_user_of')) { $u = tg_user_of($pid); if ($u && !empty($u['dm'])) tg_dm($u['id'], '🏆 <b>You won this month\'s 15 Club bounty!</b> ' . tg_h($cfg['prize']) . ' goes to the wallet you connect on your profile. Connect one now if you haven\'t, and the team will send it.', tg_kb_private('🎴 Open the game')); }
    } else {
        $w = $d['m'][$m] ?? null;
        if ($w) $out['winner'] = $w['name'];
    }
    save(BOUNTY, $d);
    return $out;
}

// what the lobby shows: this month's bounty, open or claimed
function bounty_public($me = '') {
    //MC 2026-10-25 a month that just ended is given out here too, so the lobby shows last month's winner on time even
    //   before anyone finishes a game in the new month. Checked without the lock first so this stays cheap.
    $d = bounty_db();
    if (bounty_due($d)) $d = with_lock(function () { $x = bounty_db(); if (bounty_settle($x)) save(BOUNTY, $x); return $x; });
    $cfg = bounty_cfg($d); $m = bounty_month(); $most = bounty_most($m); $w = $most ? null : ($d['m'][$m] ?? null);
    $board = bounty_board($d, $m);
    $mine = null;
    if (preg_match('/^[a-f0-9]{6}$/', $me)) {
        if ($most) { foreach (bounty_board($d, $m, BOUNTY_BOARD) as $i => $x) if ($x['tag'] === $me) { $mine = ['rank' => $i + 1, 'r' => $x['r'], 'won' => $x['won'], 'k' => $x['k']]; break; } }
        else { $k = 0; foreach ($d['best'][$m] ?? [] as $pid => $x) { if ($w && $x['t'] > $w['t'] && $pid !== $w['pid']) continue; $k++; if (substr($pid, 0, 6) === $me) { $mine = ['rank' => $k, 'r' => min(bounty_at(), (int)$x['r']), 'won' => (bool)$x['w']]; break; } } }
    }
    $club = 0; foreach ($d['club'] as $c) if (($c['last'] ?? 0) >= strtotime($m . '-01 00:00:00 UTC')) $club++;
    // last month's winner, for the card on the new rule
    $pm = gmdate('Y-m', strtotime($m . '-01 00:00:00 UTC -1 month')); $pw = $d['m'][$pm] ?? null;
    $race = $most ? bounty_race($d, $m) : []; $lead = $race ? $race[array_key_first($race)] : null;
    return ['on' => !empty($cfg['on']), 'prize' => $cfg['prize'], 'at' => bounty_at(), 'month' => $m, 'ends' => bounty_ends($m), 'rule' => $most ? 'most' : 'first',
        'winner' => $w ? ['name' => $w['name'], 't' => $w['t'], 'tag' => substr($w['pid'], 0, 6), 'paid' => !empty($w['paid'])] : null,
        'leader' => $lead ? ['name' => $lead['n'], 'wins' => (int)$lead['c']] : null, 'racers' => count($race),
        'last' => $pw ? ['name' => $pw['name'], 'month' => $pm, 'wins' => (int)($pw['wins'] ?? 1), 'rule' => ($pw['mode'] ?? '') === 'most' ? 'most' : 'first', 'paid' => !empty($pw['paid'])] : null,
        'locked' => (bool)$w, 'club' => count($d['club']), 'clubMonth' => $club, 'board' => $board, 'mine' => $mine, 'players' => count($d['best'][$m] ?? []),
        'odds' => ['games' => (int)($d['tot']['g'] ?? 0), 'wins' => (int)($d['tot']['w'] ?? 0), 'best' => min(bounty_at(), (int)($d['tot']['best'] ?? 0)), 'since' => (int)($d['tot']['since'] ?? 0),
            'month' => (int)($d['tot']['m'][$m] ?? 0), 'sim' => BOUNTY_SIM]];
}
