<?php
//MC 2026-10-19 the personal invite link (/join/<tag>): a tiny page whose preview picture is the inviter's own
//   profile card, so a share on X or Telegram shows exactly who is inviting you. People who open it go straight
//   into the game with the invite attached; the crawlers that build link previews read the card from the meta.
define('SHY_API', 1);
require __DIR__ . '/common.php';

$tag = strtolower((string)($_GET['t'] ?? ''));
if (!preg_match('/^[a-f0-9]{6}$/', $tag)) { http_response_code(404); @readfile(dirname(__DIR__) . '/404.html'); exit; }
$players = load(PLAYERS);
$pid = ''; foreach ($players as $id => $p) if (strpos($id, $tag) === 0 && !empty($p['games']) && !empty($p['name'])) { $pid = $id; break; }
if ($pid === '' || !empty($players[$pid]['hide'])) { http_response_code(404); @readfile(dirname(__DIR__) . '/404.html'); exit; }
$p = $players[$pid];
$e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$name = (string)$p['name'];
$site = 'https://shyonsol.io';
$url = $site . '/join/' . $tag;
$to = '/play?friend=' . $tag;
// the picture busts X's and Telegram's cache whenever the card itself changes
$h = substr(sha1(json_encode([$name, $p['points'] ?? 0, $p['wins'] ?? 0, $p['games'] ?? 0, $p['avatar'] ?? '', $p['holder'] ?? ''])), 0, 8);
$img = $site . '/api/share.php?p=' . $tag . '&h=' . $h;
$title = $name . ' invited you to Shilluminati Online';
$desc = 'Play the free $SHY card game in your browser. Join with ' . $name . '\'s link and a welcome gift of Koban is yours.';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
header('X-Robots-Tag: noindex');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
    . '<title>' . $e($title) . '</title>'
    . '<meta name="description" content="' . $e($desc) . '">'
    . '<meta property="og:type" content="website"><meta property="og:site_name" content="Shy on Solana">'
    . '<meta property="og:title" content="' . $e($title) . '"><meta property="og:description" content="' . $e($desc) . '">'
    . '<meta property="og:url" content="' . $e($url) . '">'
    . '<meta property="og:image" content="' . $e($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
    . '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="' . $e($title) . '">'
    . '<meta name="twitter:description" content="' . $e($desc) . '"><meta name="twitter:image" content="' . $e($img) . '">'
    . '<link rel="canonical" href="' . $e($url) . '">'
    . '<script>location.replace(' . json_encode($to) . ');</script>'
    . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0620;color:#fff;font:600 17px "Inter",system-ui,sans-serif}a{color:#ff5d73}</style>'
    . '</head><body><p><a href="' . $e($to) . '">Join ' . $e($name) . ' in Shilluminati Online</a></p></body></html>';
