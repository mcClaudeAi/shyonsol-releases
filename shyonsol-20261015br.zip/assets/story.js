// The Shy Story: the community's Medium posts, listed and read right here on shyonsol.io.
(function () {
  "use strict";
  var root = document.getElementById("story");
  if (!root) return;
  var API = "api/medium.php", list = null, profile = "https://medium.com/@SHY_Community", baseTitle = document.title;

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function day(d) { return new Date(d + "T12:00:00Z").toLocaleDateString(((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined, { month: "long", day: "numeric", year: "numeric" }); }
  function meta(p) { return '<span>' + day(p.date) + '</span>' + (p.mins ? '<span>' + p.mins + ' min read</span>' : ""); }
  function cover(p, cls) {
    return '<div class="st-cover ' + (cls || "") + '">' + (p.img ? '<img src="' + esc(p.img) + '" alt="" loading="lazy">' : '<span class="st-seal" aria-hidden="true">話</span>') + '</div>';
  }
  function href(p) { return "/story?p=" + encodeURIComponent(p.id); }
  async function getj(q) { try { var r = await fetch(API + "?" + q); return await r.json(); } catch (e) { return { ok: false }; } }

  //MC 2026-10-13 the chronicle numbers its chapters: the oldest post is Chapter 1, the newest leads the page
  function chap(n) { return '<span class="st-ch"><i aria-hidden="true">章</i><span>Chapter ' + n + '</span></span>'; }
  function renderList() {
    document.title = baseTitle;
    if (!list || !list.length) { root.innerHTML = '<p class="st-empty">No stories yet. Check back soon.</p>'; return; }
    var first = list[0], rest = list.slice(1), total = list.length;
    var h = '<a class="st-feature reveal in" href="' + href(first) + '" data-p="' + esc(first.id) + '">' + cover(first, "big") +
      '<div class="st-ft"><span class="st-kick">Latest story</span>' + chap(total) + '<h2 data-i18n-skip>' + esc(first.title) + '</h2>' + (first.excerpt ? '<p data-i18n-skip>' + esc(first.excerpt) + '</p>' : "") +
      '<div class="st-meta">' + meta(first) + '</div><span class="btn btn-red">Read the story</span></div></a>';
    if (rest.length) h += '<div class="st-grid">' + rest.map(function (p, i) {
      return '<a class="st-card" href="' + href(p) + '" data-p="' + esc(p.id) + '">' + cover(p) + '<div class="st-ct"><div class="st-meta">' + chap(total - 1 - i) + meta(p) + '</div><h3 data-i18n-skip>' + esc(p.title) + '</h3>' + (p.excerpt ? '<p data-i18n-skip>' + esc(p.excerpt) + '</p>' : "") + '</div></a>';
    }).join("") + '</div>';
    root.innerHTML = h;
  }

  async function renderPost(id) {
    root.innerHTML = '<div class="st-read sk-read"><div></div><div></div><div></div></div>';
    var j = await getj("a=post&id=" + encodeURIComponent(id));
    if (!j.ok) { root.innerHTML = '<p class="st-empty">' + esc(j.error || "That story couldn't be loaded.") + ' <a href="/story" data-back>See all stories</a></p>'; return; }
    var p = j.post;
    document.title = p.title + " | The Shy Story";
    var url = location.origin + location.pathname + "?p=" + encodeURIComponent(p.id);
    var body = p.html ? p.html : '<p>This story lives on Medium for now.</p><p><a href="' + esc(p.link) + '" target="_blank" rel="noopener">Read it on Medium</a></p>';
    var near = [j.newer && ["Newer story", j.newer], j.older && ["Older story", j.older]].filter(Boolean);
    root.innerHTML = '<article class="st-read">' +
      '<a class="st-back" href="/story" data-back>&larr; All stories</a>' +
      (p.tags && p.tags.length ? '<div class="st-tags">' + p.tags.map(function (t) { return '<span data-i18n-skip>' + esc(t) + '</span>'; }).join("") + '</div>' : "") +
      '<h1 data-i18n-skip>' + esc(p.title) + '</h1>' +
      '<div class="st-byline"><span class="st-av">S</span><div><b>' + esc(p.author || "SHY Community") + '</b><div class="st-meta">' + meta(p) + '</div></div></div>' +
      '<div class="prose st-prose" data-i18n-skip>' + body + '</div>' +
      '<div class="st-fin" aria-hidden="true"><i></i><span data-i18n-skip>終</span><i></i></div>' +
      '<div class="st-share"><span>Share this story</span><a class="btn btn-line btn-sm" target="_blank" rel="noopener" href="https://x.com/intent/tweet?text=' + encodeURIComponent(p.title) + '&url=' + encodeURIComponent(url) + '">Post on X</a>' +
      '<a class="btn btn-line btn-sm" target="_blank" rel="noopener" href="https://t.me/share/url?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(p.title) + '">Telegram</a>' +
      '<button class="btn btn-line btn-sm" data-copy-link="' + esc(url) + '">Copy link</button></div>' +
      (near.length ? '<div class="st-near">' + near.map(function (n) { return '<a href="' + href(n[1]) + '" data-p="' + esc(n[1].id) + '"><small>' + n[0] + '</small><b>' + esc(n[1].title) + '</b><span>' + day(n[1].date) + '</span></a>'; }).join("") + '</div>' : "") +
      '<p class="st-src">Also published on <a href="' + esc(p.link || profile) + '" target="_blank" rel="noopener">Medium</a>. Follow <a href="' + esc(profile) + '" target="_blank" rel="noopener">@SHY_Community</a> there for every new chapter.</p>' +
      '</article>';
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  function route() {
    var m = /[?&]p=([^&]+)/.exec(location.search);
    document.body.classList.toggle("reading", !!m);
    if (m) renderPost(decodeURIComponent(m[1])); else renderList();
  }
  root.addEventListener("click", async function (e) {
    var a = e.target.closest("[data-p],[data-back]");
    if (a && !e.metaKey && !e.ctrlKey && !e.shiftKey) {
      e.preventDefault();
      history.pushState(null, "", a.hasAttribute("data-back") ? "/story" : href({ id: a.dataset.p }));
      route();
      if (!a.hasAttribute("data-p")) window.scrollTo({ top: 0 });
      return;
    }
    var c = e.target.closest("[data-copy-link]");
    //MC 2026-10-09 in-app browsers (Telegram) often refuse the clipboard API and the button did nothing.
    //Fall back to the old textarea copy like the CA button in app.js does.
    if (c) {
      var url = c.dataset.copyLink, ok = false;
      try { await navigator.clipboard.writeText(url); ok = true; }
      catch (x) {
        try { var t = document.createElement("textarea"); t.value = url; t.setAttribute("readonly", ""); t.style.position = "fixed"; t.style.opacity = "0"; document.body.appendChild(t); t.select(); ok = document.execCommand("copy"); t.remove(); } catch (y) {}
      }
      if (ok) { c.textContent = "Copied"; setTimeout(function () { c.textContent = "Copy link"; }, 1400); }
    }
  });
  window.addEventListener("popstate", route);

  (async function () {
    var j = await getj("a=list");
    if (j.ok) { list = j.posts; profile = j.profile || profile; }
    route();
  })();
})();
