// Connect X: link an X account for the "Verified with X" badge and post results straight to X from the site.
(function () {
  "use strict";
  var API = "api/x.php";
  var X_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.9 2H22l-6.8 7.8L23 22h-6.2l-4.8-6.3L6.4 22H3.3l7.3-8.3L1 2h6.3l4.4 5.8L18.9 2Zm-1.1 18h1.7L6.3 3.9H4.5L17.8 20Z"/></svg>';
  function store(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  async function call(body) {
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: store("shy-lb-pid"), key: store("shy-lb-key") }, body)) });
      var j = await r.json(); if (!j.ok && !j.status) j.status = r.status; return j;
    } catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  var cache = null;
  async function status(force) {
    if (cache && !force) return cache;
    if (!store("shy-lb-pid")) return { ok: true, enabled: false, linked: false };
    cache = await call({ a: "status" });
    return cache;
  }
  async function start(back) {
    var j = await call({ a: "start", back: back || location.pathname });
    if (j.ok && j.url) { location.href = j.url; return true; }
    return j;
  }
  async function unlink() { cache = null; return call({ a: "unlink" }); }
  //MC 2026-10-11 the player's "Post my wins automatically" switch, and the automatic post itself (the server checks both
  //   switches, the daily cap and that this result card wasn't posted already)
  async function setAuto(on) { var j = await call({ a: "auto", on: !!on }); if (j.ok && cache) cache.auto = !!on; return j; }
  function autoPost(text, sid) { return call({ a: "post", auto: 1, text: text, sid: sid || "" }); }
  //MC 2026-10-11 title "Verified with X" on its own (a dictionary key); with the handle in it, it was English everywhere. The handle is the link's name
  function badge(user, big) {
    if (!user) return "";
    return '<a class="xb' + (big ? " big" : "") + '" href="https://x.com/' + encodeURIComponent(user) + '" target="_blank" rel="noopener" title="Verified with X" aria-label="@' + esc(user) + '">' + X_ICON + (big ? '<span>@' + esc(user) + '</span>' : "") + '<i>&#10003;</i></a>';
  }
  function weight(t) { return t.replace(/https?:\/\/\S+/g, "xxxxxxxxxxxxxxxxxxxxxxx").length; }

  // the composer: edit the result text and post it to X without leaving the page
  var box = null;
  function compose(text, user, done) {
    if (cache && cache.ok && !cache.links) text = text.replace(/[ \t]*https?:\/\/\S+/g, "").trim();
    if (!box) { box = document.createElement("div"); box.className = "xc-modal"; box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-label", "Post to X"); document.body.appendChild(box); }
    var paused = cache && cache.paused;
    box.innerHTML = '<div class="xc-back" data-xc-close></div><div class="xc-panel"><button class="xc-x" data-xc-close aria-label="Close">&times;</button>' +
      '<div class="xc-head"><span class="xc-logo">' + X_ICON + '</span><div><b>Post to X</b><small>as @' + esc(user.username) + '</small></div></div>' +
      '<textarea class="xc-text" rows="7" maxlength="1000">' + esc(text) + '</textarea>' +
      '<div class="xc-row"><small class="xc-count"></small><span class="xc-note">' + (cache && cache.links ? "Your result card shows under the post." : "Posted as text. Want your result card? Use Open in X instead.") + '</span></div>' +
      '<p class="xc-msg' + (paused ? ' bad' : '') + '" role="status">' + (paused ? 'Posting from the site is paused right now. Use Open in X to share your result instead.' : '') + '</p>' +
      '<div class="xc-btns"><button class="btn btn-red" data-xc-post>Post</button><a class="xc-alt" target="_blank" rel="noopener" href="https://x.com/intent/tweet?text=' + encodeURIComponent(text) + '">Open in X instead</a></div></div>';
    box.hidden = false;
    var ta = box.querySelector(".xc-text"), cnt = box.querySelector(".xc-count"), btn = box.querySelector("[data-xc-post]"), msg = box.querySelector(".xc-msg");
    var upd = function () { var n = weight(ta.value); cnt.textContent = (280 - n) + " left"; cnt.classList.toggle("over", n > 280); btn.disabled = n > 280 || !ta.value.trim(); box.querySelector(".xc-alt").href = "https://x.com/intent/tweet?text=" + encodeURIComponent(ta.value); };
    ta.addEventListener("input", upd); upd();
    if (paused) { btn.disabled = true; btn.hidden = true; box.querySelector(".xc-alt").classList.add("btn", "btn-red"); }
    requestAnimationFrame(function () { box.classList.add("in"); ta.focus(); ta.setSelectionRange(0, 0); });
    var close = function () { box.classList.remove("in"); setTimeout(function () { box.hidden = true; }, 180); };
    box.onclick = async function (e) {
      if (e.target.closest("[data-xc-close]")) return close();
      if (!e.target.closest("[data-xc-post]") || btn.disabled) return;
      btn.disabled = true; btn.textContent = "Posting…"; msg.textContent = ""; msg.className = "xc-msg";
      var j = await call({ a: "post", text: ta.value });
      if (j.ok) {
        box.querySelector(".xc-panel").innerHTML = '<div class="xc-done"><span class="xc-logo big">' + X_ICON + '</span><b>Posted.</b><p>Your result is live on X.</p><div class="xc-btns"><a class="btn btn-red" href="' + esc(j.url) + '" target="_blank" rel="noopener">View your post</a><button class="btn btn-line" data-xc-close>Done</button></div></div>';
        if (done) done(j);
      } else {
        btn.disabled = false; btn.textContent = "Post";
        msg.textContent = j.error || "Couldn't post that."; msg.className = "xc-msg bad";
        if (j.status === 401) { cache = null; msg.innerHTML = esc(j.error) + ' <a href="/profile#x">Reconnect</a>'; }
        if (j.status === 503) { if (cache) cache.paused = true; btn.hidden = true; box.querySelector(".xc-alt").classList.add("btn", "btn-red"); }
      }
    };
  }
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && box && !box.hidden) { box.classList.remove("in"); box.hidden = true; } });

  window.ShyX = { status: status, start: start, unlink: unlink, badge: badge, compose: compose, icon: X_ICON, setAuto: setAuto, autoPost: autoPost };
})();
