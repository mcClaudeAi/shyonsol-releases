// Release notes: filter by kind, search, open or fold every release, and keep the date list in step while scrolling.
(function () {
  "use strict";
  var wrap = document.querySelector(".rn-wrap");
  if (!wrap) return;
  var rels = Array.prototype.slice.call(wrap.querySelectorAll("details.rn"));
  var kind = "", q = "", search = document.getElementById("rn-search"), none = document.getElementById("rn-none"), allBtn = document.getElementById("rn-all");
  var openState = rels.map(function (d) { return d.open; });

  //MC 2026-10-09 66 releases on one page made it a long scroll, so the list pages 8 releases at a time. The filter and
  //search work across every release, the date list and #v links jump to the page that holds them.
  var PER = 8, page = 1, pgEl = document.createElement("div"), match = rels.map(function () { return true; });
  pgEl.className = "rn-pg"; wrap.appendChild(pgEl);
  function pageFor(d) { var k = 0, i = rels.indexOf(d); for (var j = 0; j < i; j++) if (match[j]) k++; return Math.floor(k / PER) + 1; }
  function show() {
    var on = rels.filter(function (d, i) { return match[i]; });
    var P = window.ShyPager ? ShyPager.slice(on, PER, page) : { items: on, page: 1, pages: 1 };
    page = P.page;
    rels.forEach(function (d) { d.hidden = P.items.indexOf(d) < 0; });
    wrap.querySelectorAll(".rn-day").forEach(function (day) { day.hidden = !day.querySelector("details.rn:not([hidden])"); });
    pgEl.innerHTML = window.ShyPager ? ShyPager.html(P, "rn") : "";
    none.hidden = on.length > 0;
  }
  function apply(keepPage) {
    var words = q.toLowerCase().split(/\s+/).filter(Boolean);
    rels.forEach(function (d, i) {
      var hits = 0;
      d.querySelectorAll(".rn-list li").forEach(function (li) {
        var t = (li.textContent + " " + d.querySelector(".rn-title").textContent).toLowerCase();
        var ok = (!kind || li.dataset.t === kind) && words.every(function (w) { return t.indexOf(w) >= 0; });
        li.hidden = !ok; if (ok) hits++;
      });
      match[i] = hits > 0;
      // while searching or filtering, open what matches; clear it to go back to how it was
      if (kind || words.length) d.open = !!hits; else d.open = openState[i];
    });
    if (!keepPage) page = 1;
    show();
  }
  function goPage(n, el) {
    page = n; show();
    var t = el || document.getElementById("notes");
    if (t) t.scrollIntoView({ block: "start", behavior: el ? "auto" : "smooth" });
  }
  pgEl.addEventListener("click", function (e) { var h = window.ShyPager && ShyPager.hit(e, "rn"); if (h) goPage(h.page); });
  document.querySelector(".rn-filter").addEventListener("click", function (e) {
    var b = e.target.closest("[data-rn-f]"); if (!b) return;
    kind = b.dataset.rnF;
    this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    apply();
  });
  var st = 0;
  search.addEventListener("input", function () { clearTimeout(st); st = setTimeout(function () { q = search.value.trim(); apply(); }, 120); });
  rels.forEach(function (d, i) { d.addEventListener("toggle", function () { if (!kind && !q) openState[i] = d.open; }); });
  allBtn.addEventListener("click", function () {
    var open = !rels.every(function (d) { return d.open || d.hidden; });
    rels.forEach(function (d, i) { if (!d.hidden) { d.open = open; openState[i] = open; } });
    allBtn.textContent = open ? "Close all" : "Open all";
  });
  // a link straight to one release (#v2026…) or one day (#d-…) turns to its page and opens it
  function reveal(el) {
    if (!el) return false;
    var d = el.tagName === "DETAILS" ? el : el.classList.contains("rn-day") ? el.querySelector("details.rn") : null;
    if (!d || rels.indexOf(d) < 0) return false;
    if (!match[rels.indexOf(d)]) { kind = ""; q = ""; search.value = ""; document.querySelectorAll(".rn-filter button").forEach(function (x) { x.classList.toggle("on", !x.dataset.rnF); }); apply(); }
    page = pageFor(d); show();
    if (el === d) { d.open = true; openState[rels.indexOf(d)] = true; }
    return true;
  }
  function openHash() { var el = location.hash && document.getElementById(location.hash.slice(1)); if (reveal(el)) el.scrollIntoView({ block: "start" }); }
  show(); openHash(); window.addEventListener("hashchange", openHash);
  // the date list and the Latest link turn the page before the browser jumps
  document.addEventListener("click", function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#v"],a[href^="#d-"]'); if (!a) return;
    reveal(document.getElementById(a.getAttribute("href").slice(1)));
  });
  // the date list follows along
  var links = {};
  document.querySelectorAll("[data-rn-day]").forEach(function (a) { links[a.dataset.rnDay] = a; });
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { Object.keys(links).forEach(function (k) { links[k].classList.toggle("on", k === e.target.id); }); } });
    }, { rootMargin: "-30% 0px -60% 0px" });
    wrap.querySelectorAll(".rn-day").forEach(function (d) { io.observe(d); });
  }
})();
