//MC 2026-10-13 the Players page: the whole Shy Army from api/players.php. Live counts roll up in the hero, the top
//   three stand on a podium, and under them every named player with search, filters and sorts. Presence is live, so
//   the On now chip and the green dots refresh themselves while the page is open. A card links to the player's public
//   page unless they made theirs private, and the podium only shows for the untouched all-time view, where it is true.
(function () {
  "use strict";
  var grid = document.getElementById("pd-grid");
  if (!grid) return;
  var API = "api/players.php";
  var AV = (document.querySelector('script[src*="players.js"]') || {}).src;
  AV = AV && AV.indexOf("?") > 0 ? AV.slice(AV.indexOf("?")) : "";
  var UNBOUND = "assets/art/masks/unbound.svg" + AV;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function big(n) { n = +n || 0; return n >= 1e9 ? (n / 1e9).toFixed(1).replace(/\.0$/, "") + "B" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e4 ? (n / 1e3).toFixed(1).replace(/\.0$/, "") + "K" : fmt(n); }
  var TIERS = { sapling: "Shy Sapling", cadet: "Kusama Cadet", scout: "Shy Scout", knight: "Kusama Knight", champion: "Shy Champion", commander: "Kusama Commander", sovereign: "Shy Sovereign", king: "Kusama King/Queen", supreme: "Shytoshi Supreme" };
  var CREST = { moon: "🌙", wave: "🌊", crane: "🕊️", fox: "🦊", dragon: "🐉", sakura: "🌸", bolt: "⚡", mountain: "🗻", sun: "☀️", oni: "👹", koi: "🎏", blade: "⚔️" };
  var S = { q: "", f: "all", s: "points", pg: 1, pages: 1, total: 0, rows: [], meta: null };
  var reduced = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------------------------------------------------------------- hero counts, rolled up once
  var counted = false;
  function stats(meta) {
    var el = document.getElementById("pd-stats");
    if (!el || !meta) return;
    var cells = [
      ["total", "Players", ""],
      ["online", "On the site now", "pd-on"],
      ["new7", "Joined this week", ""],
      ["holders", "Holders", ""]
    ];
    el.innerHTML = cells.map(function (c) {
      return '<div class="pd-st ' + c[2] + '"><b data-pd-n="' + c[0] + '" data-i18n-skip>' + fmt(meta[c[0]]) + '</b><small>' + c[1] + '</small></div>';
    }).join("");
    if (!counted && !reduced) {
      counted = true;
      var t0 = performance.now(), MS = 900;
      (function step(now) {
        var k = Math.min(1, (now - t0) / MS), e = 1 - Math.pow(1 - k, 3);
        cells.forEach(function (c) { var b = el.querySelector('[data-pd-n="' + c[0] + '"]'); if (b) b.textContent = fmt(Math.round(meta[c[0]] * e)); });
        if (k < 1) requestAnimationFrame(step);
      })(t0);
    }
  }

  // ---------------------------------------------------------------- cards
  function face(r, cls) {
    var img = r.img || UNBOUND;
    return '<span class="pd-av ' + (cls || "") + (r.aura && r.aura !== "none" ? " au-" + esc(r.aura) : "") + '">' +
      '<img src="' + esc(img) + '" alt="" loading="lazy" decoding="async">' + (r.on ? '<i class="pd-live" aria-hidden="true"></i>' : "") + '</span>';
  }
  function tierB(r) {
    return r.tier && TIERS[r.tier] ? '<em class="tier-b rk ico t-' + esc(r.tier) + '" title="' + esc(TIERS[r.tier]) + '" data-i18n-skip><img src="/assets/ranks/' + esc(r.tier) + '-64.webp" alt="' + esc(TIERS[r.tier]) + '" width="18" height="18"></em>' : "";
  }
  function houseB(r) {
    return r.house ? '<span class="pd-house c-' + esc(r.house.color) + '" data-i18n-skip>' + (CREST[r.house.crest] || "🏯") + ' ' + esc(r.house.tag) + '</span>' : "";
  }
  function slug(n) { return "/p/" + encodeURIComponent(String(n).replace(/ /g, "_")); }
  function card(r) {
    var tag = r.p ? "a" : "div";
    var isNew = Date.now() / 1000 - r.since < 7 * 86400;
    return '<' + tag + ' class="pd-c' + (r.on ? " on" : "") + '"' + (r.p ? ' href="' + slug(r.name) + '"' : "") + ' data-t="' + esc(r.t) + '">' +
      (isNew ? '<span class="pd-new">New</span>' : "") + face(r) +
      '<span class="pd-nm"><b data-i18n-skip>' + esc(r.name) + '</b>' + tierB(r) + '</span>' +
      '<span class="pd-tags">' + houseB(r) + (r.on ? '<span class="pd-onb"><i class="pd-dot" aria-hidden="true"></i>On now</span>' : "") + '</span>' +
      '<span class="pd-row">' + (S.s === "week"
        ? '<span><b data-i18n-skip>' + fmt(r.w) + '</b> pts this week</span>'
        : '<span><b data-i18n-skip>' + big(r.pts) + '</b> pts</span>') +
      '<span><b data-i18n-skip>' + fmt(r.wins) + '</b> wins</span><span><b data-i18n-skip>' + fmt(r.games) + '</b> games</span></span>' +
      '</' + tag + '>';
  }
  function podium(rows) {
    var el = document.getElementById("pd-podium");
    if (!el) return;
    var on = S.q === "" && S.f === "all" && S.s === "points" && rows.length >= 3;
    el.hidden = !on;
    if (!on) { el.innerHTML = ""; return; }
    var seats = [[rows[1], 2], [rows[0], 1], [rows[2], 3]];   // silver, gold, bronze, the way a podium stands
    el.innerHTML = seats.map(function (s) {
      var r = s[0], tag = r.p ? "a" : "div";
      return '<' + tag + ' class="pd-pod p' + s[1] + '"' + (r.p ? ' href="' + slug(r.name) + '"' : "") + '>' +
        '<span class="pd-medal" data-i18n-skip>' + ["", "🥇", "🥈", "🥉"][s[1]] + '</span>' + face(r, "big") +
        '<b class="pd-pn"><span data-i18n-skip>' + esc(r.name) + '</span>' + tierB(r) + '</b>' + houseB(r) +
        '<span class="pd-pp"><span><i data-i18n-skip>' + big(r.pts) + '</i> pts</span><span aria-hidden="true"> &middot; </span><span><i data-i18n-skip>' + fmt(r.wins) + '</i> wins</span></span>' +
        '</' + tag + '>';
    }).join("");
  }
  function draw(append) {
    var rows = S.rows, podOn = S.q === "" && S.f === "all" && S.s === "points";
    podium(rows);
    var body = podOn && !document.getElementById("pd-podium").hidden ? rows.slice(3) : rows;
    var h = body.map(card).join("");
    if (!h && !append) h = '<p class="pd-empty">' + (S.q ? "Nobody by that name yet. Try part of it." : "Nobody here yet. The next game changes that.") + '</p>';
    grid.innerHTML = h;
    var foot = document.getElementById("pd-foot");
    var left = S.total - rows.length;
    foot.innerHTML = left > 0 ? '<button class="btn btn-line" data-pd-more>Show ' + fmt(Math.min(left, 24)) + ' more</button><span class="pd-count">' + fmt(rows.length) + ' of ' + fmt(S.total) + '</span>'
      : (S.total > 24 ? '<span class="pd-count">All ' + fmt(S.total) + ' shown</span>' : "");
  }

  // ---------------------------------------------------------------- data
  var seq = 0, busy = false;
  function url(pg) {
    return API + "?a=list&f=" + encodeURIComponent(S.f) + "&s=" + encodeURIComponent(S.s) + "&pg=" + pg + (S.q ? "&q=" + encodeURIComponent(S.q) : "");
  }
  function load(more) {
    var my = ++seq, pg = more ? S.pg + 1 : 1;
    if (busy && more) return;
    busy = true;
    if (!more) grid.classList.add("pd-wait");
    fetch(url(pg)).then(function (r) { return r.json(); }).then(function (j) {
      busy = false;
      if (my !== seq || !j || !j.ok) return;
      grid.classList.remove("pd-wait");
      S.pg = j.page; S.pages = j.pages; S.total = j.total; S.meta = j.meta;
      S.rows = more ? S.rows.concat(j.players) : j.players;
      stats(j.meta);
      draw(more);
    }).catch(function () {
      busy = false;
      grid.classList.remove("pd-wait");
      if (!more) grid.innerHTML = '<p class="pd-empty">The Army list is catching its breath. Try again in a minute.</p>';
    });
  }

  // ---------------------------------------------------------------- controls
  var qEl = document.getElementById("pd-q"), tm = null;
  qEl.addEventListener("input", function () {
    clearTimeout(tm);
    tm = setTimeout(function () { S.q = qEl.value.trim(); load(false); }, 280);
  });
  document.getElementById("pd-f").addEventListener("click", function (e) {
    var b = e.target.closest("[data-f]"); if (!b) return;
    S.f = b.dataset.f;
    this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    load(false);
  });
  document.getElementById("pd-s").addEventListener("click", function (e) {
    var b = e.target.closest("[data-s]"); if (!b) return;
    S.s = b.dataset.s;
    this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    load(false);
  });
  document.getElementById("pd-foot").addEventListener("click", function (e) {
    if (e.target.closest("[data-pd-more]")) load(true);
  });

  // presence moves by the second: refresh the counts and the dots on what is showing, without touching the scroll
  setInterval(function () {
    if (document.hidden || !S.meta) return;
    var r = grid.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight * 2) return;
    fetch(url(1)).then(function (x) { return x.json(); }).then(function (j) {
      if (!j || !j.ok) return;
      stats(j.meta);
      var seen = {};
      j.players.forEach(function (p) { seen[p.t] = !!p.on; });
      document.querySelectorAll(".pd-c[data-t]").forEach(function (c) {
        if (!(c.dataset.t in seen)) return;   // a card from a later page: leave it as it was
        var isOn = seen[c.dataset.t];
        if (c.classList.contains("on") === isOn) return;
        c.classList.toggle("on", isOn);
        var av = c.querySelector(".pd-av"), dot = c.querySelector(".pd-live"), tags = c.querySelector(".pd-tags"), ob = c.querySelector(".pd-onb");
        if (isOn && av && !dot) av.insertAdjacentHTML("beforeend", '<i class="pd-live" aria-hidden="true"></i>');
        if (!isOn && dot) dot.remove();
        if (isOn && tags && !ob) tags.insertAdjacentHTML("beforeend", '<span class="pd-onb"><i class="pd-dot" aria-hidden="true"></i>On now</span>');
        if (!isOn && ob) ob.remove();
      });
    }).catch(function () {});
  }, 30000);

  load(false);
})();
