//MC 2026-10-13 the Shytoshi page's premium layer: embers rising over the burn chapter and its tweet card, the fact
//   numbers counting up as they appear, and the chapter rail following the reader. Everything is gated by an
//   IntersectionObserver so nothing animates off screen, embers are a handful of transform-only spans (no layout, no
//   paint storms), and prefers-reduced-motion switches the whole layer off. Phones get fewer embers.
(function () {
  "use strict";
  var reduce = false; try { reduce = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
  var small = false; try { small = matchMedia("(max-width: 480px)").matches; } catch (e) {}

  // ---------- embers over the burn chapter ----------
  var burn = document.getElementById("ch-burn");
  if (burn && !reduce && "IntersectionObserver" in window) {
    var fig = burn.querySelector(".ink-print"), card = burn.querySelector(".x-card");
    var hosts = [fig, card].filter(Boolean);
    hosts.forEach(function (h) {
      h.classList.add("emberbox");
      var n = small ? 5 : 9;
      for (var i = 0; i < n; i++) {
        var s = document.createElement("i");
        s.className = "ember";
        s.style.setProperty("--x", (6 + Math.random() * 88).toFixed(1) + "%");
        s.style.setProperty("--d", (2.6 + Math.random() * 2.8).toFixed(2) + "s");
        s.style.setProperty("--w", (Math.random() * 16 - 8).toFixed(1) + "px");
        s.style.setProperty("--s", (0.5 + Math.random() * 0.7).toFixed(2));
        s.style.animationDelay = (Math.random() * 3).toFixed(2) + "s";
        h.appendChild(s);
      }
    });
    if (card) card.classList.add("x-burned");
    var bio = new IntersectionObserver(function (es) {
      es.forEach(function (e) { e.target.classList.toggle("burning", e.isIntersecting); });
    }, { rootMargin: "60px 0px" });
    hosts.forEach(function (h) { bio.observe(h); });
  } else if (burn) {
    var c2 = burn.querySelector(".x-card"); if (c2) c2.classList.add("x-burned");
  }

  // ---------- the facts count up the first time they appear ----------
  var facts = document.querySelectorAll(".facts b");
  if (facts.length && !reduce && "IntersectionObserver" in window) {
    var fio = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting || e.target.dataset.done) return;
        e.target.dataset.done = "1";
        var m = /^(\d+)(.*)$/.exec(e.target.textContent.trim());
        if (!m || !+m[1]) return;
        var to = +m[1], suf = m[2], el = e.target, t0 = performance.now();
        el.setAttribute("data-i18n-skip", "");
        requestAnimationFrame(function step(t) {
          var k = Math.min(1, (t - t0) / 1200), ease = 1 - Math.pow(1 - k, 3);
          el.textContent = Math.round(to * ease) + suf;
          if (k < 1) requestAnimationFrame(step);
        });
        fio.unobserve(el);
      });
    }, { rootMargin: "0px 0px -8%" });
    facts.forEach(function (b) { fio.observe(b); });
  }

  // ---------- the chapter rail follows the reader ----------
  var toc = document.querySelector(".toc");
  if (toc && "IntersectionObserver" in window) {
    var links = {};
    toc.querySelectorAll("a[href^='#ch-']").forEach(function (a) { links[a.getAttribute("href").slice(1)] = a; });
    var tio = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        toc.querySelectorAll("a").forEach(function (a) { a.classList.remove("now"); });
        var a = links[e.target.id]; if (a) a.classList.add("now");
      });
    }, { rootMargin: "-30% 0px -55%" });
    document.querySelectorAll(".sy-ch[id]").forEach(function (ch) { tio.observe(ch); });   //MC 2026-10-13 the redesigned chapter class
  }
})();
