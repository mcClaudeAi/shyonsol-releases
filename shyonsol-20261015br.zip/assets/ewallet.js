// Get a free Solana wallet with just an email, for players with no wallet app (Telegram, phones, desktops without an
// extension). Crossmint runs the wallet: the player types their email, gets a 6-digit code, and has a Solana wallet,
// all inside this page, so it works in Telegram too (no redirect, no Google sign-in screen that apps block).
// A Crossmint Solana wallet is a smart wallet and can't sign a plain message, so it doesn't link the way Phantom does.
// Instead the server asks Crossmint, with the player's sign-in token, which wallet belongs to them, and links that
// (api/holder.php verify with cm). play.js and profile.js treat it like any wallet: connect() then signMessage().
//MC 2026-10-15 replaces the Phantom embedded wallet: Phantom paused new developer sign-ups. The SDK (Apache-2.0) is
//   self-hosted in assets/vendor/crossmint.js and only loads when someone opens this, so no page pays for it otherwise.
//   The client key comes from the holder status reply.
(function () {
  "use strict";
  var key = "", sdk = null, state = null;
  var AV = (function () { var s = document.querySelector('script[src*="ewallet.js"]'); var v = s && s.src.split("?")[1]; return v ? "?" + v : ""; })();
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function load() {
    if (window.ShyCrossmint) return Promise.resolve(window.ShyCrossmint);
    if (sdk) return sdk;
    sdk = new Promise(function (res, rej) {
      var s = document.createElement("script"); s.src = "/assets/vendor/crossmint.js" + AV; s.async = true;
      s.onload = function () { window.ShyCrossmint ? res(window.ShyCrossmint) : rej(new Error("Couldn't load the wallet service.")); };
      s.onerror = function () { sdk = null; rej(new Error("Couldn't load the wallet service. Check your connection.")); };
      document.head.appendChild(s);
    });
    return sdk;
  }
  function msg(e) {
    var m = String((e && e.message) || e || "");
    if (/otp|code|token/i.test(m) && /invalid|expired|incorrect|wrong/i.test(m)) return "That code didn't work. Check it, or send a new one.";
    if (/origin|api key/i.test(m)) return "Email wallets aren't set up right yet. Tell the team.";
    return m.replace(/^Error:\s*/, "").slice(0, 160) || "Something went wrong. Try again.";
  }

  // ---------- the sheet: email, then the code ----------
  var sheet = null, done = null;
  function open(resolve, reject) {
    close();
    done = { resolve: resolve, reject: reject };
    sheet = document.createElement("div");
    sheet.className = "ew-sheet"; sheet.setAttribute("role", "dialog"); sheet.setAttribute("aria-modal", "true");
    sheet.innerHTML = '<div class="ew-card"><button class="ew-x" type="button" aria-label="Close">&times;</button>' +
      '<span class="ew-k">Free Solana wallet</span><h3>Get a wallet with your email</h3>' +
      '<p class="ew-lead">We\'ll email you a 6-digit code. Your wallet is made by Crossmint and belongs to your email: sign in with the same email anywhere to get back to it.</p>' +
      '<form class="ew-f" data-step="email"><input type="email" name="email" autocomplete="email" inputmode="email" placeholder="you@example.com" required><button class="btn btn-red" type="submit">Send my code</button></form>' +
      '<form class="ew-f" data-step="code" hidden><input type="text" name="code" autocomplete="one-time-code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6-digit code" required><button class="btn btn-red" type="submit">Make my wallet</button>' +
      '<button class="ew-again" type="button">Send a new code</button></form>' +
      '<p class="ew-msg" aria-live="polite"></p><small class="ew-fine">Free, no transaction. Uses Crossmint.</small></div>';
    document.body.appendChild(sheet);
    var f1 = sheet.querySelector('[data-step="email"]'), f2 = sheet.querySelector('[data-step="code"]');
    setTimeout(function () { try { f1.email.focus(); } catch (e) {} }, 50);
    sheet.querySelector(".ew-x").addEventListener("click", function () { cancel(); });
    sheet.addEventListener("click", function (e) { if (e.target === sheet) cancel(); });
    f1.addEventListener("submit", function (e) { e.preventDefault(); sendCode(f1.email.value.trim(), f1, f2); });
    f2.addEventListener("submit", function (e) { e.preventDefault(); confirmCode(f2.code.value.trim(), f2); });
    sheet.querySelector(".ew-again").addEventListener("click", function () { sendCode(state && state.email, f1, f2); });
  }
  function say(t, err) { var m = sheet && sheet.querySelector(".ew-msg"); if (m) { m.textContent = t || ""; m.classList.toggle("err", !!err); } }
  function busy(f, on) { f.querySelectorAll("button,input").forEach(function (x) { x.disabled = on; }); }
  function close() { if (sheet) { sheet.remove(); sheet = null; } }
  function cancel() { close(); if (done) { var d = done; done = null; d.reject(new Error("cancelled")); } }

  async function sendCode(email, f1, f2) {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || "")) { say("Type your email address.", true); return; }
    busy(f1, true); say("Sending your code...");
    try {
      var S = await load();
      var cm = S.createCrossmint({ apiKey: key });
      var auth = S.CrossmintAuth.from(cm);
      var r = await auth.sendEmailOtp(email);
      state = { email: email, emailId: r && (r.emailId || r.id || r.state), auth: auth };
      f1.hidden = true; f2.hidden = false; busy(f2, false);
      say("Code sent to " + email + ". It can take a minute; check spam too.");
      setTimeout(function () { try { f2.code.focus(); } catch (e) {} }, 50);
    } catch (e) { say(msg(e), true); }
    busy(f1, false);
  }
  async function confirmCode(code, f2) {
    if (!/^\d{6}$/.test(code)) { say("The code is 6 digits.", true); return; }
    if (!state) return;
    busy(f2, true); say("Checking your code...");
    try {
      var secret = await state.auth.confirmEmailOtp(state.email, state.emailId, code);
      var mat = await state.auth.handleRefreshAuthMaterial(secret);
      var jwt = mat && mat.jwt;
      if (!jwt) throw new Error("The sign-in didn't finish. Try again.");
      say("Making your wallet...");
      var S = window.ShyCrossmint;
      var cw = S.createCrossmintW({ apiKey: key, jwt: jwt });
      var wallets = S.CrossmintWallets.from(cw), w = null;
      try { w = await wallets.getWallet({ chain: "solana" }); } catch (e) { w = null; }
      if (!w || !w.address) w = await wallets.createWallet({ chain: "solana", recoveryMethods: [{ type: "email", email: state.email }] });
      if (!w || !w.address) throw new Error("Couldn't make the wallet. Try again.");
      var d = done; done = null; close();
      d.resolve(provider(w.address, jwt));
    } catch (e) { say(msg(e), true); busy(f2, false); }
  }
  // shaped like window.phantom.solana for the existing connect code; "signing" hands back the sign-in token, which the
  // server checks with Crossmint instead of a signature
  function provider(address, jwt) {
    var pk = { toString: function () { return address; } };
    return {
      isEmbedded: true, publicKey: pk,
      connect: async function () { return { publicKey: pk }; },
      signMessage: async function () { return { cmJwt: jwt }; }
    };
  }

  window.ShyEW = {
    // the holder status reply carries ew: {ck} when the team turned it on
    set: function (cfg) { key = cfg && cfg.ck ? String(cfg.ck) : ""; },
    ready: function () { return !!key; },
    pending: function () { return false; },
    resume: async function () { return null; },
    // opens the email sheet; resolves with a wallet, or rejects if the player closes it
    start: function () { return new Promise(function (res, rej) { open(res, rej); }); },
    buttons: function (cls) {
      if (!key) return "";
      return '<button class="btn ' + (cls || "btn-line btn-sm") + ' ew-btn" data-ew="email"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m4 7 8 6 8-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>Use my email</button>';
    }
  };
})();
