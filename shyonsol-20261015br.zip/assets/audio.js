// Sound engine for the game: preloads the pack, mixes levels, ducks music under big moments.
(function (root) {
  "use strict";
  var BASE = "assets/sfx/";
  var LEVEL = { tap: 0.55, draw: 0.6, play: 0.75, gain: 0.7, hit: 0.85, block: 0.7, turn: 0.6, global: 0.8,
    skip: 0.7, win: 0.9, lose: 0.75, badge: 0.7, tick: 0.5, match: 0.85, join: 0.6 };
  var DUCK = { hit: 1, global: 1, win: 1, lose: 1, match: 1, block: 1 };
  var ac = null, master = null, sfxBus = null, musicBus = null, buffers = {}, loading = null, musicSrc = null;
  var prefs = { sfx: get("shy-sound") !== "off", music: get("shy-music") === "on" };

  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  function ctx() {
    if (ac) return ac;
    var C = window.AudioContext || window.webkitAudioContext;
    if (!C) return null;
    ac = new C();
    master = ac.createDynamicsCompressor();
    master.threshold.value = -10; master.ratio.value = 4; master.attack.value = 0.003; master.release.value = 0.2;
    master.connect(ac.destination);
    sfxBus = ac.createGain(); sfxBus.gain.value = 0.9; sfxBus.connect(master);
    musicBus = ac.createGain(); musicBus.gain.value = 0; musicBus.connect(master);
    return ac;
  }
  function load() {
    if (loading) return loading;
    var c = ctx();
    if (!c) return (loading = Promise.resolve());
    var names = Object.keys(LEVEL);
    loading = Promise.all(names.map(function (n) {
      return fetch(BASE + n + ".mp3").then(function (r) { return r.arrayBuffer(); })
        .then(function (b) { return new Promise(function (ok, bad) { c.decodeAudioData(b, ok, bad); }); })
        .then(function (buf) { buffers[n] = buf; }).catch(function () {});
    }));
    return loading;
  }
  function loadMusic() {
    var c = ctx();
    if (!c || buffers.music || loadMusic.p) return loadMusic.p || Promise.resolve();
    loadMusic.p = fetch(BASE + "music.mp3").then(function (r) { return r.arrayBuffer(); })
      .then(function (b) { return new Promise(function (ok, bad) { c.decodeAudioData(b, ok, bad); }); })
      .then(function (buf) { buffers.music = buf; }).catch(function () {});
    return loadMusic.p;
  }
  // browsers only allow audio after a tap or key press
  function unlock() {
    var c = ctx(); if (!c) return;
    if (c.state === "suspended") c.resume();
    load();
    if (prefs.music) startMusic();
  }
  ["pointerdown", "keydown", "touchstart"].forEach(function (ev) { addEventListener(ev, unlock, { once: true, passive: true }); });

  function play(name, vol) {
    if (!prefs.sfx) return;
    var c = ctx(); if (!c) return;
    if (c.state === "suspended") c.resume();
    var buf = buffers[name];
    if (!buf) { load(); return; }
    var src = c.createBufferSource(), g = c.createGain();
    src.buffer = buf;
    src.playbackRate.value = name === "tap" || name === "draw" ? 0.96 + Math.random() * 0.08 : 1; // small variation so repeats don't feel robotic
    g.gain.value = (LEVEL[name] || 0.7) * (vol == null ? 1 : vol);
    src.connect(g); g.connect(sfxBus); src.start();
    if (DUCK[name]) duck();
  }
  function duck() {
    if (!musicBus || !prefs.music) return;
    var t = ac.currentTime, g = musicBus.gain;
    g.cancelScheduledValues(t); g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(0.07, t + 0.08); g.linearRampToValueAtTime(0.22, t + 1.6);
  }
  function startMusic() {
    var c = ctx(); if (!c) return;
    loadMusic().then(function () {
      if (!prefs.music || musicSrc || !buffers.music) return;
      musicSrc = c.createBufferSource(); musicSrc.buffer = buffers.music; musicSrc.loop = true;
      musicSrc.connect(musicBus); musicSrc.start();
      var t = c.currentTime; musicBus.gain.cancelScheduledValues(t);
      musicBus.gain.setValueAtTime(0, t); musicBus.gain.linearRampToValueAtTime(0.22, t + 2.5);
    });
  }
  function stopMusic() {
    if (!musicSrc || !ac) return;
    var s = musicSrc, t = ac.currentTime; musicSrc = null;
    musicBus.gain.cancelScheduledValues(t); musicBus.gain.setValueAtTime(musicBus.gain.value, t);
    musicBus.gain.linearRampToValueAtTime(0, t + 0.8);
    setTimeout(function () { try { s.stop(); } catch (e) {} }, 900);
  }
  function setSfx(on) { prefs.sfx = on; set("shy-sound", on ? "on" : "off"); if (on) { unlock(); play("tap"); } }
  function setMusic(on) { prefs.music = on; set("shy-music", on ? "on" : "off"); if (on) { unlock(); startMusic(); } else stopMusic(); }
  // pause music when the tab is hidden
  document.addEventListener("visibilitychange", function () {
    if (!ac) return;
    if (document.hidden) ac.suspend(); else if (prefs.sfx || prefs.music) ac.resume();
  });

  root.ShyAudio = { play: play, setSfx: setSfx, setMusic: setMusic, prefs: prefs, preload: load };
})(this);
