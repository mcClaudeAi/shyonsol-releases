//MC 2026-10-11 the site's pulse, from one cached answer (api/pulse.php?a=now):
//   Play lobby: live tables now, the open one "Join the next live table" gets you into, and the next busy hour, next to
//     the "players online now" faces friends.js already draws in the same box.
//   Home: games today, players online and the last prize paid, with its Solana transaction.
//   Not-found page: a search for players (api/pulse.php?a=find) and cards (the card list comes with the page).
// One request when the page settles, then every 20 seconds only while the lobby or the strip is on screen, so it never
// competes with the page's own first loads or runs under a game.
(function () {
  "use strict";
  var API = "/api/pulse.php";
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function loc() { return (window.SHYI18N && SHYI18N.locale) || document.documentElement.lang || undefined; }
  function myTag() { try { return (localStorage.getItem("shy-lb-pid") || "").slice(0, 6); } catch (e) { return ""; } }
  var later = window.requestIdleCallback ? function (f) { requestIdleCallback(f, { timeout: 1500 }); } : function (f) { setTimeout(f, 400); };

  var last = null, lastAt = 0, busy = false;
  function get() {
    if (busy) return Promise.resolve(last);
    busy = true;
    return fetch(API + "?a=now").then(function (r) { return r.json(); }).then(function (j) {
      busy = false;
      if (j && j.ok) { last = j; lastAt = Date.now(); }
      return last;
    }).catch(function () { busy = false; return last; });
  }
  // "Sat 8 PM" in the visitor's own time and language, "Today 8 PM" for today, and how long until then
  function when(ts) {
    var d = new Date(ts * 1000), now = new Date(), L = loc(), t;
    try { t = d.toLocaleTimeString(L, { hour: "numeric" }); } catch (e) { t = d.getHours() + ":00"; }
    var day = d.toDateString() === now.toDateString() ? "" : (function () { try { return d.toLocaleDateString(L, { weekday: "short" }); } catch (e) { return ""; } })();
    return { day: day, time: t };
  }
  function rel(ts) {
    var s = Math.max(0, ts - Date.now() / 1000);
    try {
      var f = new Intl.RelativeTimeFormat(loc(), { numeric: "auto", style: "short" });
      return s < 3600 ? f.format(Math.max(1, Math.round(s / 60)), "minute") : f.format(Math.round(s / 3600), "hour");
    } catch (e) { return ""; }
  }
  function clock(s) { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ":" + ("0" + s % 60).slice(-2); }

  // ---------------------------------------------------------------- Play lobby
  var lobby = document.getElementById("g-pulse");
  var IC_T = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18M9 10v9"/></svg>';
  var IC_B = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/></svg>';
  function lobbyOn() {
    var st = document.getElementById("g-start");
    return lobby && !document.hidden && !document.documentElement.classList.contains("g-playing") && st && !st.hidden && lobby.offsetParent !== null;
  }
  function tableLine(T) {
    if (!T) return "";
    var n = T.next, left = n ? n.left - (Date.now() - lastAt) / 1000 : 0;
    if (n && left >= 3) return '<span>1 open, starts in</span> <b class="gp-cd" data-i18n-skip>' + clock(left) + '</b>';
    if (T.open > 1) return T.open + " open now";
    return "be the first to sit down";
  }
  function drawLobby(j) {
    if (!lobby) return;
    if (!j) { lobby.hidden = true; return; }
    var T = j.tables || {}, B = j.busy, h = '<div class="gp-lines">';
    h += '<p class="gp-cell gp-tables"><i class="gp-ic">' + IC_T + '</i><span class="gp-tx"><b>' + (T.playing === 1 ? "1 live table" : T.playing ? T.playing + " live tables" : "No live tables") + '</b> <span class="gp-sep" aria-hidden="true">&middot;</span> <span class="gp-sub" data-gp-open>' + tableLine(T) + '</span></span></p>';
    if (B) {
      var w = when(B.ts);
      h += '<p class="gp-cell gp-busy' + (B.now ? " now" : "") + '"><i class="gp-ic">' + IC_B + '</i><span class="gp-tx">' +
        (B.now ? '<b>Busy right now</b> <span class="gp-sep" aria-hidden="true">&middot;</span> <span class="gp-sub">' + (B.avg === 1 ? "about 1 game an hour" : "about " + fmt(B.avg) + " games an hour") + '</span>'
          : '<b>Busiest next</b> <b class="gp-when" data-i18n-skip>' + esc((w.day ? w.day + " " : "") + w.time) + '</b> <span class="gp-sep" aria-hidden="true">&middot;</span> <span class="gp-sub" data-i18n-skip>' + esc(rel(B.ts)) + '</span>') + '</span></p>';
    }
    h += '</div><button type="button" class="btn btn-line btn-sm gp-join" data-gp-join>Join the next live table <span aria-hidden="true">&rarr;</span></button>';
    lobby.innerHTML = h;
    lobby.hidden = false;
    lobby.classList.add("in");
  }
  if (lobby) {
    lobby.addEventListener("click", function (e) {
      if (!e.target.closest("[data-gp-join]")) return;
      // the lobby's own "Find a match": joins the newest open public table, or opens one that bots fill in 30 seconds
      if (window.ShyPlay && ShyPlay.start) ShyPlay.start("live-quick");
      else { var b = document.querySelector('[data-game-start="live-quick"]'); if (b) b.click(); }
    });
    var tick = function () {
      if (!lobbyOn()) return;
      get().then(drawLobby);
    };
    later(function () { get().then(drawLobby); });
    setInterval(tick, 20000);
    // the countdown on the open table, between refreshes
    setInterval(function () {
      if (!last || !lobbyOn()) return;
      var el = lobby.querySelector("[data-gp-open]"), cd = el && el.querySelector(".gp-cd"), n = last.tables && last.tables.next;
      if (!el) return;
      var left = n ? n.left - (Date.now() - lastAt) / 1000 : 0;
      // only the clock's own text changes each second; the sentence around it is redrawn when it really changes
      if (cd && left >= 3) cd.textContent = clock(left);
      else if (cd) el.innerHTML = tableLine(last.tables);
    }, 1000);
    document.addEventListener("visibilitychange", function () { if (!document.hidden && Date.now() - lastAt > 20000) tick(); });
  }

  // ---------------------------------------------------------------- Home
  var home = document.getElementById("hm-pulse");
  function face(f) {
    return f.img ? '<img src="' + esc(f.img) + '" alt="" loading="lazy" decoding="async">' : '<i aria-hidden="true">' + esc((f.n || "?").charAt(0).toUpperCase()) + '</i>';
  }
  function drawHome(j) {
    if (!home) return;
    if (!j) { home.classList.add("off"); return; }
    var set = function (k, html) { var el = home.querySelector('[data-hp="' + k + '"]'); if (el) el.innerHTML = html; };
    set("g", fmt(j.today && j.today.g));
    set("g-sub", j.today && j.today.p ? (j.today.p === 1 ? "by 1 player" : "by " + fmt(j.today.p) + " players") : "Be the first today");
    var me = myTag(), faces = (j.faces || []).filter(function (f) { return f.t !== me; }).slice(0, 5);
    set("on", fmt(j.online));
    set("faces", faces.map(face).join(""));
    set("on-sub", j.online ? "Join a live match" : "Start a live match");
    var P = j.prize;
    if (P) {
      var d = ""; try { d = new Date(P.t * 1000).toLocaleDateString(loc(), { month: "short", day: "numeric" }); } catch (e) {}
      set("prize", (P.shy ? fmt(Math.round(P.shy)) + ' <small>$SHY</small>' : "$" + fmt(P.usd) + ' <small>in $SHY</small>'));
      set("prize-sub", '<span data-i18n-skip>' + esc(P.name) + '</span> &middot; <span data-i18n-skip>' + esc(d) + '</span> &middot; <a href="https://solscan.io/tx/' + encodeURIComponent(P.sig) + '" target="_blank" rel="noopener">Solscan &#8599;</a>');
    } else {
      // the server found no paid prize at all, in the Treasury copy or the results
      set("prize", "None yet");
      set("prize-sub", '<a href="/rules">Weekly League prizes are paid in $SHY</a>');
    }
    home.classList.add("in");
  }
  if (home) {
    later(function () { get().then(drawHome); });
    setInterval(function () {
      if (document.hidden) return;
      var r = home.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) return;
      get().then(drawHome);
    }, 30000);
  }

  // ---------------------------------------------------------------- Hero live line
  //MC 2026-10-13 the LIVE badge in the hero rotates through what's happening right now: players online, tables being
  //   played or forming, games today and a live limited drop. The original "Play Shilluminati Online" stays in the
  //   rotation so the badge still says what the button does. One sentence per turn, a soft fade between, and the digits
  //   stay out of the translation keys the usual way (the runtime folds them into {0}).
  var heroT = document.getElementById("hero-live-t");
  if (heroT) {
    var heroBase = heroT.innerHTML, heroI = 0;
    var heroLines = function (j) {
      var L = [heroBase];
      if (!j) return L;
      var T = j.tables || {};
      if (j.online >= 2) L.push(esc(fmt(j.online)) + " players are on the site right now");
      if (T.playing >= 2) L.push(esc(T.playing) + " live tables are being played right now");
      else if (T.playing === 1) L.push("A live match is being played right now");
      if (T.open >= 1 && T.next) L.push("A live table is forming, sit down now");
      if (j.today && j.today.g >= 10) L.push(esc(fmt(j.today.g)) + " games played so far today");
      var D = j.drop;
      if (D) L.push(D.left <= Math.max(2, Math.ceil(D.n / 10))
        ? "Drop almost gone: " + esc(D.left) + " of " + esc(D.n) + " copies left"
        : "A limited drop is live in the shop");
      return L;
    };
    var heroOn = function () {
      if (document.hidden) return false;
      var r = heroT.getBoundingClientRect();
      return r.bottom > 0 && r.top < innerHeight;
    };
    setInterval(function () {
      if (!heroOn()) return;
      var L = heroLines(last);
      if (L.length < 2) return;
      heroI = (heroI + 1) % L.length;
      var next = L[heroI];
      heroT.classList.add("hl-out");
      setTimeout(function () {
        heroT.innerHTML = next === heroBase ? heroBase : next + ' <span aria-hidden="true">&rarr;</span>';
        heroT.classList.remove("hl-out");
      }, 320);
    }, 5500);
  }

  // ---------------------------------------------------------------- Not-found page search
  var nf = document.getElementById("nf-q");
  if (nf) {
    var out = document.getElementById("nf-res"), CARDS = window.SHY_NF_CARDS || {}, seq = 0, tm = null;
    var norm = function (s) { return String(s || "").toLowerCase(); };
    var slug = function (n) { return "/p/" + encodeURIComponent(String(n).replace(/ /g, "_")); };
    var draw = function (q, players) {
      var t = norm(q), cards = [];
      if (t.length >= 2) Object.keys(CARDS).forEach(function (id) { if (norm(CARDS[id]).indexOf(t) >= 0 && cards.length < 6) cards.push(id); });
      var h = "";
      if (players && players.length) h += '<li class="nf-h">Players</li>' + players.map(function (p) {
        return '<li><a href="' + slug(p.name) + '"><span class="nf-av">' + (p.img ? '<img src="' + esc(p.img) + '" alt="" loading="lazy">' : esc(p.name.charAt(0).toUpperCase())) + '</span><span class="nf-n" data-i18n-skip>' + esc(p.name) + '</span><small>' + fmt(p.points) + ' pts</small></a></li>';
      }).join("");
      if (cards.length) h += '<li class="nf-h">Cards</li>' + cards.map(function (id) {
        return '<li><a href="/cards?card=' + encodeURIComponent(id) + '#deck"><span class="nf-av nf-card"><img src="/assets/cards/' + esc(id) + '.webp" alt="" loading="lazy"></span><span class="nf-n">' + esc(CARDS[id]) + '</span></a></li>';
      }).join("");
      if (!h && t.length >= 2) h = '<li class="nf-none">Nothing by that name. Try part of it, like "Crane" or "Meteor".</li>';
      out.innerHTML = h; out.hidden = !h;
      nf.setAttribute("aria-expanded", h ? "true" : "false");
    };
    nf.addEventListener("input", function () {
      var q = nf.value.trim(), my = ++seq;
      clearTimeout(tm);
      if (q.length < 2) { draw(q, []); return; }
      draw(q, null);   // cards show at once, players when they arrive
      tm = setTimeout(function () {
        fetch(API + "?a=find&q=" + encodeURIComponent(q)).then(function (r) { return r.json(); }).then(function (j) { if (my === seq) draw(q, j && j.ok ? j.players : []); }).catch(function () {});
      }, 280);
    });
    var form = document.getElementById("nf-search");
    if (form) form.addEventListener("submit", function (e) {
      e.preventDefault();
      var a = out.querySelector("a"); if (a) location.href = a.getAttribute("href");
      else if (nf.value.trim()) location.href = "/cards?q=" + encodeURIComponent(nf.value.trim()) + "#deck";
    });
  }
})();
