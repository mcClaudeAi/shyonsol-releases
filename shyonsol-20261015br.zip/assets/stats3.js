//MC 2026-10-12 The rebuilt Stats page (replaces stats.js). Everything here comes from api/stats.php?a=all in one answer:
//   the hero (an odometer of every game played, the headline numbers and a ticker of the latest games), the chapter bar
//   that follows you down the page, the Hall of Records, the biggest wins as player cards, players joining, coming back,
//   holders and Unbound, ranked tiers, hot streaks, Houses, games each day, how games end, mode by mode, the Regions
//   games end on, the latest games, the cards and the Shadows. Charts are plain SVG so phones stay light. The leaderboard
//   (board.js), the Shogun (boss-stats.js) and When and where (stats2.js) draw themselves.
(function () {
  "use strict";
  var API = "api/stats.php?a=all";
  var LANG = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || "en";
  var REDUCE = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var MODES = [["solo", "Solo", "#4cc9f0"], ["daily", "Daily", "#f2c35b"], ["live", "Live", "#ff5d73"]];
  var KIND = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", trick: "Trick", passive: "Passive" };
  var S = null, range = 30, grRange = 30, hidden = {}, csort = "played", showAll = false, bwMode = "", first = true;
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n, d) { return Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: d || 0 }); }
  function pct(a, b) { return b ? Math.round(1000 * a / b) / 10 : 0; }
  function day(d, opt) { try { return new Date(d + "T12:00:00Z").toLocaleDateString(LANG, opt || { month: "short", day: "numeric" }); } catch (e) { return d; } }
  function keep(t) { return '<span data-i18n-skip>' + esc(t) + '</span>'; }   // dates, times and names are never translated
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t)), f;
    try { f = new Intl.RelativeTimeFormat(LANG, { numeric: "auto", style: "narrow" }); } catch (e) { return ""; }
    if (s < 60) return f.format(0, "minute");
    if (s < 3600) return f.format(-Math.floor(s / 60), "minute");
    if (s < 86400) return f.format(-Math.floor(s / 3600), "hour");
    return f.format(-Math.floor(s / 86400), "day");
  }
  function plural(n, one, many) { return fmt(n) + " " + (n === 1 ? one : many); }

  // ---------- players: a Shadow when they hold one, otherwise their initial on a colour of their own ----------
  function hue(s) { var h = 0; s = String(s || ""); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
  function av(r, cls) {
    var inner = r.img ? '<img src="' + esc(r.img) + '" alt="" loading="lazy">' : '<span style="--h:' + hue(r.n) + '" data-i18n-skip>' + esc((r.n || "?").slice(0, 1).toUpperCase()) + '</span>';
    return '<span class="st-av' + (cls ? " " + cls : "") + (r.h ? " hold" : "") + '">' + inner + '</span>';
  }
  function who(r) {
    var nm = '<b data-i18n-skip>' + esc(r.n) + '</b>';
    return r.s ? '<a class="st-who" href="/p/' + encodeURIComponent(r.s) + '">' + nm + '</a>' : '<span class="st-who">' + nm + '</span>';
  }
  function tags(r) { return (r.h ? '<em class="st-tag hold">Holder</em>' : "") + (r.hs ? '<em class="st-tag" data-i18n-skip>' + esc(r.hs) + '</em>' : ""); }

  // ---------- tooltip ----------
  var tip = document.createElement("div"); tip.className = "st-tip"; tip.hidden = true; document.body.appendChild(tip);
  var lastTouch = 0;
  function showTip(html, x, y) {
    tip.innerHTML = html; tip.hidden = false;
    var w = tip.offsetWidth, h = tip.offsetHeight, vw = document.documentElement.clientWidth;
    var left = Math.min(vw - w - 10, Math.max(10, x - w / 2)), top = y - h - 14;
    if (top < 8) top = y + 18;
    tip.style.transform = "translate(" + Math.round(left) + "px," + Math.round(top + window.scrollY) + "px)";
  }
  function hideTip() { tip.hidden = true; }
  document.addEventListener("scroll", hideTip, { passive: true });
  document.addEventListener("touchstart", function (e) { lastTouch = Date.now(); if (!tip.hidden && !(e.target.closest && e.target.closest(".st-chart"))) hideTip(); }, { passive: true });
  //MC 2026-10-09 (kept from stats.js) a mouseleave within a second of a touch is the browser's own, after a tap: ignore it
  function fromTouch(e) { return !!(e && e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) || Date.now() - lastTouch < 1000; }
  function hover(box, sel, html) {
    box.onmousemove = box.ontouchstart = function (e) {
      var t = e.target.closest && e.target.closest(sel); if (!t) return hideTip();
      var pt = e.touches ? e.touches[0] : e, r = t.getBoundingClientRect();
      box.querySelectorAll(sel + ".on").forEach(function (x) { x.classList.remove("on"); }); t.classList.add("on");
      showTip(html(t), pt ? pt.clientX : r.left + r.width / 2, r.top);
    };
    box.onmouseleave = function (e) { if (fromTouch(e)) return; hideTip(); box.querySelectorAll(sel + ".on").forEach(function (x) { x.classList.remove("on"); }); };
  }

  function countUp(el, to, dec) {
    if (REDUCE || !to) { el.textContent = fmt(to, dec); return; }
    var t0 = performance.now(), dur = 1100;
    (function step(t) { var k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(to * e, k < 1 ? 0 : dec); if (k < 1) requestAnimationFrame(step); })(t0);
  }

  // ---------- hero ----------
  function odometer(n) {
    var el = $("st-odo"), s = fmt(n);
    if (el.dataset.v === s) return; el.dataset.v = s;
    el.innerHTML = s.split("").map(function (c, i) {
      if (!/\d/.test(c)) return '<span class="st-odo-sep">' + c + '</span>';
      var d = +c, col = ""; for (var k = 0; k <= 9; k++) col += "<i>" + k + "</i>";
      return '<span class="st-odo-d"><span class="st-odo-c" style="--n:' + d + ';--i:' + i + '">' + col + '</span></span>';
    }).join("");
    if (!REDUCE) { el.classList.remove("go"); void el.offsetWidth; requestAnimationFrame(function () { el.classList.add("go"); }); } else el.classList.add("go");
  }
  //MC 2026-10-12 the Today panel in the hero, back by request: games today counted up live, the change against
  //   yesterday at the same point of nothing-fancier (full yesterday), the split by mode, and the last 14 days as
  //   tappable bars with today burning at the end. Redrawn on every refresh, so the number moves while you watch.
  function today() {
    var days = S.days.slice(-14), t = days[days.length - 1] || { g: 0, p: 0 }, y = days.length > 1 ? days[days.length - 2] : null;
    var big = $("st-today-n"); if (!big) return;
    if (first) countUp(big, t.g || 0); else if (big.dataset.v !== String(t.g)) { big.textContent = fmt(t.g || 0); big.classList.remove("tick"); void big.offsetWidth; big.classList.add("tick"); }
    big.dataset.v = String(t.g);
    var d = $("st-today-delta");
    //MC 2026-10-12 the day is usually mid-run, so a minus against a FULL yesterday would sit red all morning: the chip
    //   only shows once today has passed yesterday
    if (y && y.g > 0 && t.g >= y.g) { var k = Math.round(100 * (t.g - y.g) / y.g); d.hidden = false; d.textContent = "+" + k + "%"; d.className = "st-today-d up"; }
    else d.hidden = true;
    $("st-today-vs").innerHTML = (y ? '<span>' + fmt(y.g || 0) + ' yesterday</span>' : "") + '<span>' + fmt(t.p || 0) + ' players</span>';
    $("st-today-modes").innerHTML = MODES.map(function (m) { return '<span><i style="background:' + m[2] + '"></i>' + m[1] + ' <b data-i18n-skip>' + fmt(t[m[0]] || 0) + '</b></span>'; }).join("");
    var max = Math.max.apply(null, days.map(function (x) { return x.g || 0; }).concat([1]));
    var box = $("st-today-bars");
    box.innerHTML = days.map(function (x, i) {
      return '<button type="button" data-i="' + i + '"' + (i === days.length - 1 ? ' class="now"' : "") + ' aria-label="' + esc(day(x.d)) + '"><i style="--h:' + Math.max(5, Math.round(100 * (x.g || 0) / max)) + '%;--d:' + (i * 45) + 'ms"></i></button>';
    }).join("");
    hover(box, "button", function (el) { var x = days[+el.dataset.i]; return '<b>' + keep(day(x.d, { weekday: "short", month: "short", day: "numeric" })) + (+el.dataset.i === days.length - 1 ? " · today" : "") + '</b><span>Games<em>' + fmt(x.g) + '</em></span><span>Players<em>' + fmt(x.p) + '</em></span>'; });
  }

  function hero() {
    var T = S.totals;
    odometer(T.games);
    //MC 2026-10-13 every game ever played passed 9,000 long ago, and the counter owns up to it once per visit
    if (T.games > 9000 && !document.querySelector(".st-9k")) {
      var od = $("st-odo");
      if (od && od.parentNode) { var k9 = document.createElement("span"); k9.className = "st-9k"; k9.innerHTML = "<span>Over 9,000.</span>"; od.parentNode.insertBefore(k9, od.nextSibling); od.classList.add("odo-9k"); }
    }
    $("st-odo-sub").textContent = fmt(T.new7) + " new players this week, " + fmt(T.players) + " in all";
    var v = { players: T.players, today: S.active ? S.active.d1 : 0, wins: T.wins, live: T.live, best: T.best };
    document.querySelectorAll("[data-hk]").forEach(function (el) { var n = v[el.dataset.hk] || 0; if (first) countUp(el, n); else el.textContent = fmt(n); });
    // the ticker: the latest games, twice over so the loop never shows a gap
    var R = { win: "won", loss: "lost", tie: "tied" }, M = { solo: "a solo game", daily: "the Daily", live: "a live match" };
    var items = (S.recent || []).map(function (g) {
      return '<div class="st-ti r-' + g.r + '">' + (g.img ? '<img src="' + esc(g.img) + '" alt="">' : '<i style="--h:' + hue(g.name) + '"></i>') + '<b data-i18n-skip>' + esc(g.name) + '</b> <div>' + (R[g.r] || "played") + ' ' + M[g.m] + ' with ' + plural(g.g, "Region", "Regions") + '</div><time data-i18n-skip>' + esc(ago(g.t)) + '</time></div>';
    }).join("");
    $("st-tick").innerHTML = items ? items + '<div aria-hidden="true" class="st-tick-dup" data-i18n-skip>' + items + '</div>' : "";
  }

  // ---------- chapter bar: follows the page and marks the chapter you're in ----------
  function chapters() {
    var nav = $("st-nav"); if (!nav || !("IntersectionObserver" in window)) return;
    var links = {}; nav.querySelectorAll("[data-chap]").forEach(function (a) { links[a.dataset.chap] = a; });
    var vis = {};
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { vis[e.target.id] = e.isIntersecting ? e.intersectionRatio : 0; });
      var best = null, bv = 0; Object.keys(vis).forEach(function (k) { if (vis[k] > bv) { bv = vis[k]; best = k; } });
      if (!best) return;
      Object.keys(links).forEach(function (k) { links[k].classList.toggle("on", k === best); });
      var a = links[best], box = nav.querySelector(".st-nav-in");
      if (a && box.scrollWidth > box.clientWidth) box.scrollTo({ left: a.offsetLeft - box.clientWidth / 2 + a.offsetWidth / 2, behavior: REDUCE ? "auto" : "smooth" });
    }, { rootMargin: "-30% 0px -55% 0px", threshold: [0, .01, .2, .5] });
    Object.keys(links).forEach(function (k) { var s = $(k); if (s) io.observe(s); });
    var hero = document.querySelector(".st-hero");
    if (hero) new IntersectionObserver(function (es) { nav.classList.toggle("stuck", !es[0].isIntersecting); }, { rootMargin: "-80px 0px 0px 0px" }).observe(hero);
  }

  // ---------- Hall of Records ----------
  var RECS = [
    ["best", "地", "Most Regions in one game", "Regions"], ["wins", "勝", "Most wins", "wins"], ["games", "戦", "Most games played", "games"],
    ["rate", "率", "Best win rate", "% won", "20 games or more"], ["live", "闘", "Most live wins", "live wins"], ["lrate", "剣", "Best live win rate", "% won", "10 live matches or more"],
    ["points", "点", "Most points, all time", "points"], ["week", "週", "Top of the League this week", "League points"], ["streak", "連", "Longest daily streak", "days"],
    ["ranked", "位", "Highest ranked this season", "Rank Points"], ["shogun", "将", "Most wins against the Shogun", "wins"], ["badges", "章", "Most badges", "badges"]
  ];
  var openRec = {};
  function records() {
    var R = S.rec || {};
    $("st-recs").innerHTML = RECS.map(function (d, i) {
      var L = R[d[0]] || [], c = L[0];
      var dec = d[0] === "rate" || d[0] === "lrate" ? 1 : 0;
      var champ = c ? '<div class="st-rec-c">' + av(c, "xl") + '<div class="st-rec-n">' + who(c) + '<div class="st-tags">' + tags(c) + '</div><div class="st-rec-x">' + esc(c.x) + '</div></div>' +
        '<div class="st-rec-v"><b data-i18n-skip>' + fmt(c.v, dec) + '</b><div>' + d[3] + '</div></div></div>' : '<p class="st-empty">Nobody yet. It could be you.</p>';
      var extra = d[0] === "best" && S.club ? '<p class="st-rec-club"><b>' + fmt(S.club) + '</b> ' + (S.club === 1 ? "player has" : "players have") + ' reached 15 Regions in a game.</p>' : "";
      var rest = L.slice(1);
      return '<article class="st-rec' + (i === 0 ? " st-rec-big" : "") + '" data-r="' + d[0] + '" style="--d:' + (i * 45) + 'ms">' +
        '<div class="st-rec-hd"><span class="st-rec-k" aria-hidden="true" data-i18n-skip>' + d[1] + '</span><div><h3>' + d[2] + '</h3>' + (d[4] ? '<small>' + d[4] + '</small>' : "") + '</div></div>' +
        champ + extra +
        (rest.length ? '<button type="button" class="st-rec-more" aria-expanded="' + !!openRec[d[0]] + '">' + (openRec[d[0]] ? "Hide the top 10" : "See the top 10") + '</button>' +
          '<ol class="st-rec-top" start="2"' + (openRec[d[0]] ? "" : " hidden") + '>' + rest.map(function (r, k) {
            return '<li><span class="st-pos" data-i18n-skip>' + (k + 2) + '</span>' + av(r) + '<div class="st-li-n">' + who(r) + '<small>' + esc(r.x) + '</small></div><b class="st-li-v" data-i18n-skip>' + fmt(r.v, dec) + '</b></li>';
          }).join("") + '</ol>' : "") + '</article>';
    }).join("");
  }

  // ---------- biggest wins ----------
  var MN = { live: "Live", normal: "Solo", easy: "Solo, Easy", daily: "Daily" };
  function bigwins() {
    var L = (S.big || []).filter(function (b) { return !bwMode || b.x === bwMode || (bwMode === "normal" && b.x === "easy"); }).slice(0, 12);
    $("st-bw").innerHTML = L.length ? L.map(function (b, i) {
      var href = b.s ? '/p/' + encodeURIComponent(b.s) : "";
      return '<' + (href ? 'a href="' + href + '"' : "div") + ' class="st-bwc m-' + b.x + (i === 0 ? " first" : "") + '" style="--d:' + (i * 40) + 'ms">' +
        '<div class="st-bwc-rk" data-i18n-skip>#' + (i + 1) + '</div>' + av(b, "lg") +
        '<div class="st-bwc-n"><b data-i18n-skip>' + esc(b.n) + '</b><div class="st-tags">' + tags(b) + '</div></div>' +
        '<div class="st-bwc-v"><b data-i18n-skip>' + fmt(b.v) + '</b><small>Regions</small></div>' +
        '<div class="st-bwc-m"><em class="st-mode m-' + b.x + '">' + (MN[b.x] || "") + '</em><time data-i18n-skip>' + esc(ago(b.t)) + '</time></div>' +
        '<div class="st-bwc-r">' + plural(b.w, "win", "wins") + ' from ' + plural(b.gm, "game", "games") + '</div>' +
        (href ? '<div class="st-bwc-go">See profile</div>' : "") + '</' + (href ? "a" : "div") + '>';
    }).join("") : '<p class="st-empty">No wins in this mode yet.</p>';
  }

  // ---------- players joining ----------
  function growth() {
    var rows = (S.growth || []).slice(-grRange), box = $("st-growth-c");
    if (!rows.length) { box.innerHTML = '<p class="st-empty">No players yet.</p>'; return; }
    var W = Math.max(300, box.clientWidth || 600), H = W < 520 ? 200 : 240, pl = 8, pr = 8, pt = 14, pb = 26;
    var maxN = Math.max(3, Math.max.apply(null, rows.map(function (r) { return r[1]; }))), minT = rows[0][2] - rows[0][1], maxT = Math.max(minT + 1, rows[rows.length - 1][2]);
    var bw = (W - pl - pr) / rows.length, ih = H - pt - pb;
    var yN = function (v) { return pt + ih * (1 - v / maxN); }, yT = function (v) { return pt + ih * (1 - (v - minT) / (maxT - minT)) * .92 + ih * .04; };
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" role="img" aria-label="Players joining each day"><defs><linearGradient id="stg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#f2c35b" stop-opacity=".35"/><stop offset="1" stop-color="#f2c35b" stop-opacity="0"/></linearGradient></defs>';
    rows.forEach(function (r, i) { var x = pl + i * bw, h = Math.max(r[1] ? 2 : 0, pt + ih - yN(r[1])); s += '<rect x="' + (x + bw * .18).toFixed(1) + '" y="' + (pt + ih - h).toFixed(1) + '" width="' + Math.max(1, bw * .64).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="2" class="st-gbar"/>'; });
    var pts = rows.map(function (r, i) { return (pl + i * bw + bw / 2).toFixed(1) + "," + yT(r[2]).toFixed(1); });
    s += '<path d="M' + pts[0].split(",")[0] + ',' + (pt + ih) + 'L' + pts.join("L") + 'L' + pts[pts.length - 1].split(",")[0] + ',' + (pt + ih) + 'Z" fill="url(#stg)"/>';
    s += '<polyline points="' + pts.join(" ") + '" class="st-gline"/>';
    var every = Math.ceil(rows.length / (W < 520 ? 4 : 7));
    rows.forEach(function (r, i) { if (i % every === 0 || i === rows.length - 1) s += '<text x="' + (pl + i * bw + bw / 2).toFixed(1) + '" y="' + (H - 7) + '" class="st-ax" text-anchor="middle">' + esc(day(r[0])) + '</text>'; s += '<rect x="' + (pl + i * bw).toFixed(1) + '" y="' + pt + '" width="' + bw.toFixed(1) + '" height="' + ih + '" class="st-hit" data-i="' + i + '"/>'; });
    box.innerHTML = s + '</svg>';
    hover(box, ".st-hit", function (t) { var r = rows[+t.dataset.i]; return '<b>' + keep(day(r[0], { weekday: "short", month: "short", day: "numeric" })) + '</b><span>New players<em>' + fmt(r[1]) + '</em></span><span>Players so far<em>' + fmt(r[2]) + '</em></span>'; });
    var added = rows.reduce(function (a, r) { return a + r[1]; }, 0);
    $("st-growth-sub").innerHTML = '<span>New players each day, and everyone so far.</span> <span><b>+' + fmt(added) + '</b> in ' + (grRange === 30 ? "the last 30 days" : "the last 90 days") + '.</span>';
  }
  function active() {
    var A = S.active || {}, T = S.totals.players || 1;
    var rows = [["Today", A.d1], ["This week", A.d7], ["This month", A.d30], ["All time", S.totals.players]];
    $("st-active-b").innerHTML = '<div class="st-rings">' + rows.map(function (r) {
      var p = Math.min(1, (r[1] || 0) / T), c = 2 * Math.PI * 26;
      return '<div class="st-ring"><svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="26" class="bg"/><circle cx="32" cy="32" r="26" class="fg" style="stroke-dasharray:' + c.toFixed(1) + ';stroke-dashoffset:' + (c * (1 - p)).toFixed(1) + '"/></svg><b data-i18n-skip>' + fmt(r[1]) + '</b><span>' + r[0] + '</span></div>';
    }).join("") + '</div>';
  }
  function hv() {
    var H = (S.hv || {}).h || [0, 0, 0], U = (S.hv || {}).u || [0, 0, 0];
    var row = function (lab, a, b, cls, unit, dec) { var m = Math.max(a, b, .001); return '<div class="st-cmp"><span class="st-cmp-l">' + lab + '</span><div class="st-cmp-b h"><i style="width:' + (100 * a / m).toFixed(1) + '%"></i><b data-i18n-skip>' + fmt(a, dec) + unit + '</b></div><div class="st-cmp-b u"><i style="width:' + (100 * b / m).toFixed(1) + '%"></i><b data-i18n-skip>' + fmt(b, dec) + unit + '</b></div></div>'; };
    $("st-hv-b").innerHTML = '<div class="st-cmp-key"><span class="h">Holders <b data-i18n-skip>' + fmt(H[0]) + '</b></span><span class="u">Unbound <b data-i18n-skip>' + fmt(U[0]) + '</b></span></div>' +
      row("Win rate", pct(H[2], H[1]), pct(U[2], U[1]), "", "%", 1) + row("Games each", H[0] ? H[1] / H[0] : 0, U[0] ? U[1] / U[0] : 0, "", "", 1) + row("Wins each", H[0] ? H[2] / H[0] : 0, U[0] ? U[2] / U[0] : 0, "", "", 1);
  }
  var TIERS = [["bronze", "Bronze", "#c9895a"], ["silver", "Silver", "#cfd6e4"], ["gold", "Gold", "#f2c35b"], ["jade", "Jade", "#3fd6a0"], ["shogun", "Shogun", "#ff5d73"]];
  function ranked() {
    var T = S.tiers || {}, tot = TIERS.reduce(function (a, t) { return a + (T[t[0]] || 0); }, 0), max = Math.max(1, Math.max.apply(null, TIERS.map(function (t) { return T[t[0]] || 0; })));
    $("st-ranked-b").innerHTML = tot ? '<div class="st-tiers">' + TIERS.slice().reverse().map(function (t) {
      var n = T[t[0]] || 0;
      return '<div class="st-tier" style="--c:' + t[2] + '"><span class="st-tier-n">' + t[1] + '</span><div class="st-tier-b"><i style="width:' + Math.max(n ? 3 : 0, 100 * n / max).toFixed(1) + '%"></i></div><b data-i18n-skip>' + fmt(n) + '</b></div>';
    }).join("") + '</div><p class="st-note">' + plural(tot, "player has", "players have") + ' played ranked this season.</p>' : '<p class="st-empty">Nobody has played ranked this season yet.</p>';
  }
  function streaks() {
    var L = S.streaks || [];
    $("st-streaks-b").innerHTML = L.length ? L.map(function (r, i) {
      return '<li><span class="st-pos" data-i18n-skip>' + (i + 1) + '</span>' + av(r) + '<div class="st-li-n">' + who(r) + '<small>Best ' + plural(r.x, "day", "days") + '</small></div><b class="st-li-v st-fire" data-i18n-skip>' + fmt(r.v) + '</b></li>';
    }).join("") : '<li class="st-empty">No streaks going right now. Play two days in a row to start one.</li>';
  }
  var HC = { violet: "#8b5cf6", red: "#ff5d73", gold: "#f2c35b", jade: "#2ef0b0", sky: "#4cc9f0", rose: "#ff6fd8", ink: "#cfc8ef", orange: "#ff9f43" };
  function houses() {
    var L = S.houses || [], max = Math.max(1, Math.max.apply(null, L.map(function (h) { return h.pts; }).concat([1])));
    $("st-houses-b").innerHTML = L.length ? '<ol class="st-houses">' + L.map(function (h, i) {
      return '<li style="--c:' + (HC[h.c] || "#8b5cf6") + '"><span class="st-pos" data-i18n-skip>' + (i + 1) + '</span><span class="st-crest" data-i18n-skip>' + esc(h.tag) + '</span><div class="st-li-n"><b data-i18n-skip>' + esc(h.n) + '</b><small>' + plural(h.size, "member", "members") + '</small></div>' +
        '<span class="st-hbar"><i style="width:' + (100 * h.pts / max).toFixed(1) + '%"></i></span><b class="st-li-v" data-i18n-skip>' + fmt(h.pts) + '</b></li>';
    }).join("") + '</ol>' : '<p class="st-empty">No Houses yet. Start one from your profile.</p>';
  }

  // ---------- games each day ----------
  function slice() { return S.days.slice(-range); }
  function legend() { $("st-legend").innerHTML = MODES.map(function (m) { return '<button class="st-chip' + (hidden[m[0]] ? " off" : "") + '" data-mode="' + m[0] + '" aria-pressed="' + !hidden[m[0]] + '"><i style="background:' + m[2] + '"></i>' + m[1] + '</button>'; }).join(""); }
  function roundTop(x, y, w, h, r) { r = Math.min(r, h); return "M" + x + "," + (y + h) + "V" + (y + r) + "Q" + x + "," + y + " " + (x + r) + "," + y + "H" + (x + w - r) + "Q" + (x + w) + "," + y + " " + (x + w) + "," + (y + r) + "V" + (y + h) + "Z"; }
  function bars() {
    var rows = slice(), box = $("st-bars");
    var W = Math.max(300, box.clientWidth || 600), H = W < 520 ? 210 : 260, padL = 34, padB = 26, padT = 10;
    var on = MODES.filter(function (m) { return !hidden[m[0]]; });
    var tot = rows.map(function (r) { return on.reduce(function (a, m) { return a + r[m[0]]; }, 0); });
    var max = Math.max(4, Math.max.apply(null, tot)), step = Math.pow(10, Math.floor(Math.log10(max))), nice = Math.ceil(max / step) * step;
    if (nice / step < 3) { step /= 2; nice = Math.ceil(max / step) * step; }
    var y = function (v) { return padT + (H - padT - padB) * (1 - v / nice); };
    var bw = (W - padL) / rows.length, gap = Math.max(1, Math.min(6, bw * .28)), w = Math.max(2, bw - gap);
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" role="img" aria-label="Games each day">';
    for (var g = 0; g <= nice; g += step) s += '<line x1="' + padL + '" x2="' + W + '" y1="' + y(g) + '" y2="' + y(g) + '" class="st-gridl"/><text x="' + (padL - 8) + '" y="' + (y(g) + 4) + '" class="st-ax" text-anchor="end">' + fmt(g) + '</text>';
    var every = Math.ceil(rows.length / (W < 520 ? 5 : 9));
    rows.forEach(function (r, i) {
      var x = padL + i * bw + gap / 2, acc = 0, segs = on.filter(function (m) { return r[m[0]] > 0; });
      segs.forEach(function (m, k) {
        var v = r[m[0]], y0 = y(acc), y1 = y(acc + v), h = Math.max(1, y0 - y1 - (k ? 2 : 0));
        s += k === segs.length - 1 ? '<path d="' + roundTop(x, y1, w, h, Math.min(4, w / 2)) + '" fill="' + m[2] + '"/>' : '<rect x="' + x + '" y="' + y1 + '" width="' + w + '" height="' + h + '" fill="' + m[2] + '"/>';
        acc += v;
      });
      if (i % every === 0 || i === rows.length - 1) s += '<text x="' + (x + w / 2) + '" y="' + (H - 6) + '" class="st-ax" text-anchor="middle">' + esc(day(r.d)) + '</text>';
      s += '<rect x="' + (padL + i * bw) + '" y="' + padT + '" width="' + bw + '" height="' + (H - padT - padB) + '" class="st-hit" data-i="' + i + '"/>';
    });
    box.innerHTML = s + '<line x1="' + padL + '" x2="' + W + '" y1="' + y(0) + '" y2="' + y(0) + '" class="st-base"/></svg>';
    hover(box, ".st-hit", function (t) { var r = rows[+t.dataset.i]; return '<b>' + keep(day(r.d, { weekday: "short", month: "short", day: "numeric" })) + '</b>' + MODES.map(function (m) { return '<span><i style="background:' + m[2] + '"></i>' + m[1] + '<em>' + fmt(r[m[0]]) + '</em></span>'; }).join("") + '<span class="st-tip-sum">Games<em>' + fmt(r.g) + '</em></span><span>Players<em>' + fmt(r.p) + '</em></span>'; });
    var sum = rows.reduce(function (a, r) { return a + r.g; }, 0), best = rows.reduce(function (a, r) { return r.g > a.g ? r : a; }, rows[0] || { g: 0, d: "" }), pl = rows.reduce(function (a, r) { return a + r.p; }, 0);
    $("st-facts").innerHTML = '<div><small>Games</small><b>' + fmt(sum) + '</b></div><div><small>Each day</small><b>' + fmt(rows.length ? sum / rows.length : 0, 1) + '</b></div>' +
      '<div><small>Busiest day</small><b>' + (best && best.g ? keep(day(best.d)) + ' <em>' + fmt(best.g) + '</em>' : "&ndash;") + '</b></div><div><small>Players a day</small><b>' + fmt(rows.length ? pl / rows.length : 0, 1) + '</b></div>';
    $("st-days-sub").innerHTML = '<span>Solo games, Daily Challenge runs and live matches.</span>' + (S.days.length < range ? ' <span>Counting since ' + keep(day(S.days[0].d, { month: "long", day: "numeric" })) + '.</span>' : "");
  }
  function ends() {
    var w = 0, l = 0, t = 0; slice().forEach(function (r) { w += r.w; l += r.l; t += r.t; });
    var all = w + l + t, c = 2 * Math.PI * 46, off = 0;
    var seg = function (v, cls) { var len = all ? c * v / all : 0, s = '<circle cx="60" cy="60" r="46" class="' + cls + '" style="stroke-dasharray:' + Math.max(0, len - (len > 6 ? 3 : 0)).toFixed(1) + ' ' + c.toFixed(1) + ';stroke-dashoffset:' + (-off).toFixed(1) + '"/>'; off += len; return s; };
    $("st-ends-b").innerHTML = '<div class="st-donut"><svg viewBox="0 0 120 120" aria-hidden="true"><circle cx="60" cy="60" r="46" class="bg"/>' + seg(w, "w") + seg(l, "l") + seg(t, "t") + '</svg><div><b data-i18n-skip>' + pct(w, all) + '%</b><span>won by the player</span></div></div>' +
      '<div class="st-keys"><span class="w"><i></i>Wins <b data-i18n-skip>' + fmt(w) + '</b></span><span class="l"><i></i>Losses <b data-i18n-skip>' + fmt(l) + '</b></span><span class="t"><i></i>Ties <b data-i18n-skip>' + fmt(t) + '</b></span></div>' +
      '<p class="st-note">Most games are against the house players, who are built to be tough.</p>';
  }
  var MD = [["normal", "Solo", "Normal against three house players"], ["easy", "Solo, Easy", "Looser house players, half points"], ["daily", "Daily", "The same deck for everyone"], ["live", "Live", "Real players at the table"]];
  function modes() {
    var M = S.modes || {};
    $("st-modes-b").innerHTML = MD.map(function (d) {
      var m = M[d[0]] || { g: 0, w: 0, r: 0 }, r = pct(m.w, m.g), c = 2 * Math.PI * 24;
      return '<div class="st-mode-c m-' + d[0] + '"><div class="st-mode-r"><svg viewBox="0 0 60 60" aria-hidden="true"><circle cx="30" cy="30" r="24" class="bg"/><circle cx="30" cy="30" r="24" class="fg" style="stroke-dasharray:' + c.toFixed(1) + ';stroke-dashoffset:' + (c * (1 - r / 100)).toFixed(1) + '"/></svg><b data-i18n-skip>' + Math.round(r) + '%</b></div>' +
        '<div><h4>' + d[1] + '</h4><small>' + d[2] + '</small><p><span><b data-i18n-skip>' + fmt(m.g) + '</b> games</span><span><b data-i18n-skip>' + fmt(m.g ? m.r / m.g : 0, 1) + '</b> Regions on average</span></p></div></div>';
    }).join("");
  }
  function dist() {
    var D = S.dist || [], box = $("st-dist-c"), tot = D.reduce(function (a, x) { return a + x[0] + x[1]; }, 0);
    if (!tot) { box.innerHTML = '<p class="st-empty">No games yet.</p>'; return; }
    var max = Math.max.apply(null, D.map(function (x) { return x[0] + x[1]; }));
    box.innerHTML = '<div class="st-hist">' + D.map(function (x, i) {
      var h = 100 * (x[0] + x[1]) / max, hw = x[0] + x[1] ? h * x[1] / (x[0] + x[1]) : 0;
      return '<button type="button" class="st-hb" data-i="' + i + '" aria-label="' + i + '"><i class="a" style="--h:' + h.toFixed(1) + '%"></i><i class="w" style="--h:' + hw.toFixed(1) + '%"></i><span>' + (i === 15 ? "15+" : i) + '</span></button>';
    }).join("") + '</div><div class="st-keys sm"><span class="w"><i></i>Won</span><span class="a"><i></i>Lost or tied</span></div>';
    hover(box, ".st-hb", function (t) { var i = +t.dataset.i, x = D[i]; return '<b>' + (i === 15 ? "15 Regions or more" : plural(i, "Region", "Regions")) + '</b><span>Games<em>' + fmt(x[0] + x[1]) + '</em></span><span>Won<em>' + fmt(x[1]) + '</em></span><span>Win rate<em>' + pct(x[1], x[0] + x[1]) + '%</em></span>'; });
  }
  function feed() {
    var M = { solo: "Solo", daily: "Daily", live: "Live" }, R = { win: "Won", loss: "Lost", tie: "Tied" };
    $("st-feed").innerHTML = (S.recent || []).slice(0, 10).map(function (g) {
      return '<li>' + av({ n: g.name, img: g.img }) + '<div class="st-li-n"><b data-i18n-skip>' + esc(g.name) + '</b><small><em class="st-mode m-' + g.m + '">' + M[g.m] + '</em> ' + plural(g.g, "Region", "Regions") + '</small></div><div class="st-res r-' + g.r + '">' + (R[g.r] || "") + '</div><time data-i18n-skip>' + esc(ago(g.t)) + '</time></li>';
    }).join("") || '<li class="st-empty">No games yet.</li>';
  }

  // ---------- cards ----------
  function cards() {
    if (window.ShyGame && window.SHY_SEASON) window.ShyGame.useSeason(window.SHY_SEASON);
    var C = (window.ShyGame && window.ShyGame.CARDS) || {}, data = S.cards || {}, games = S.cardGames, base = pct(S.cardWins, games), body = $("st-cards-b");
    if (!games) { body.innerHTML = '<p class="st-empty">Card stats start counting with the games played from this update on.</p>'; return; }
    var list = Object.keys(C).filter(function (id) { return C[id].n > 0; }).map(function (id) { var d = data[id] || [0, 0, 0]; return { id: id, c: C[id], g: d[0], w: d[1], r: d[0] ? 100 * d[1] / d[0] : 0 }; });
    if (csort === "played") list.sort(function (a, b) { return b.g - a.g || b.r - a.r; });
    else if (csort === "least") list.sort(function (a, b) { return a.g - b.g || a.c.name.localeCompare(b.c.name); });
    else list = list.filter(function (x) { return x.g >= 5; }).sort(function (a, b) { return b.r - a.r || b.g - a.g; });
    var shown = showAll ? list : list.slice(0, 10), topG = Math.max.apply(null, list.map(function (x) { return x.g; }).concat([1]));
    var v = (document.querySelector('script[src*="stats3.js"]') || {}).src || ""; v = v.indexOf("?") > 0 ? v.slice(v.indexOf("?")) : "";
    body.innerHTML = (list.length ? '<div class="st-ctab"><div class="st-crow st-chd"><span></span><span>Card</span><span>Played in</span><span>Win rate <em>&middot; average ' + base + '%</em></span></div>' +
      shown.map(function (x, i) {
        return '<div class="st-crow"><span class="st-pos">' + (i + 1) + '</span><span class="st-cname"><img src="assets/cards/' + x.id + '.webp' + v + '" alt="" loading="lazy"><span><b>' + esc(x.c.name) + '</b><em class="k-' + x.c.kind + '">' + (KIND[x.c.kind] || "") + '</em>' + (x.c.season ? '<em class="gc-season">S' + x.c.season + '</em>' : "") + '</span></span>' +
          '<span class="st-cg"><i style="width:' + (100 * x.g / topG) + '%"></i><b>' + fmt(x.g) + '</b></span>' +
          '<span class="st-cr"><span class="st-rtrack"><i style="width:' + x.r + '%"></i><u style="left:' + base + '%"></u></span><b>' + (x.g ? fmt(x.r, 1) + "%" : "&ndash;") + '</b></span></div>';
      }).join("") + '</div>' : '<p class="st-empty">No card has been played 5 times yet.</p>') +
      (list.length > 10 ? '<button class="btn btn-line btn-sm st-more" data-more>' + (showAll ? "Show the top 10" : "Show all " + list.length + " cards") + '</button>' : "");
    $("st-cards-sub").innerHTML = 'From ' + fmt(games) + ' games since ' + keep(day(new Date(S.cardSince * 1000).toISOString().slice(0, 10), { month: "long", day: "numeric" })) + '.';
  }
  function shadows() {
    var L = S.shadows || [];
    $("st-sh-sub").textContent = S.shadowsPlayed === 1 ? "1 Shytoshi Shadow has played so far." : fmt(S.shadowsPlayed) + " Shytoshi Shadows have played so far.";
    $("st-sh").innerHTML = L.length ? L.map(function (s, i) {
      return '<div class="st-shc' + (i === 0 ? " first" : "") + '">' + (s.img ? '<img src="' + esc(s.img) + '" alt="" loading="lazy">' : '<div class="st-sh-ph" data-i18n-skip>#' + esc(s.n) + '</div>') +
        '<div class="st-shc-t"><b>Shadow #' + esc(s.n) + '</b><small>' + plural(s.w, "win", "wins") + ' &middot; ' + plural(s.g, "game", "games") + '</small></div>' + (i === 0 ? '<span class="st-crown">Most wins</span>' : "") + '</div>';
    }).join("") : '<p class="st-empty">No Shadow has played yet. Connect a wallet with a Shadow to be the first.</p>';
  }
  function prize() {
    var L = S.league, left = Math.max(0, L.weekEnd - Math.floor(Date.now() / 1000)), d = Math.floor(left / 86400), h = Math.floor(left % 86400 / 3600);
    $("st-prize").innerHTML = '<div><small>This week\'s pool</small><b>$' + fmt(L.pool) + '</b><span>in $SHY</span></div><div><small>Paid out so far</small><b>$' + fmt(L.paid) + '</b><span>' + plural(L.weeks, "week finished", "weeks finished") + '</span></div>' +
      '<div><small>Pays out in</small><b data-i18n-skip>' + d + 'd ' + h + 'h</b><span>Monday 00:00 UTC</span></div><div><small>Today\'s Daily</small><b>#' + fmt(S.dailyNo) + '</b><span>' + plural(S.dailyToday, "player so far", "players so far") + '</span></div>';
  }

  function drawAll() {
    hero(); today(); records(); bigwins(); growth(); active(); hv(); ranked(); streaks(); houses();
    legend(); bars(); ends(); modes(); dist(); feed(); cards(); shadows(); prize();
    first = false;
  }
  async function load() {
    try {
      var j = await (await fetch(API, { cache: "no-store" })).json();
      if (!j.ok) throw new Error(j.error || "");
      S = j; drawAll();
      $("st-updated").innerHTML = "Live. Updated " + keep(new Date(j.at * 1000).toLocaleTimeString(LANG, { hour: "numeric", minute: "2-digit" }));
    } catch (e) { if (!S) $("st-updated").textContent = "Couldn't load the numbers. Trying again in a minute."; }
  }
  function seg(b) { b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); }); }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("button"); if (!b || !S) return;
    if (b.dataset.range) { range = +b.dataset.range; seg(b); bars(); ends(); return; }
    if (b.dataset.gr) { grRange = +b.dataset.gr; seg(b); growth(); return; }
    if (b.hasAttribute("data-bw")) { bwMode = b.dataset.bw; seg(b); bigwins(); return; }
    if (b.dataset.mode && b.closest("#st-legend")) { var m = b.dataset.mode; hidden[m] = !hidden[m]; if (MODES.every(function (x) { return hidden[x[0]]; })) hidden[m] = false; legend(); bars(); return; }
    if (b.dataset.csort) { csort = b.dataset.csort; seg(b); cards(); return; }
    if (b.hasAttribute("data-more")) { showAll = !showAll; cards(); return; }
    if (b.classList.contains("st-rec-more")) {
      var r = b.closest(".st-rec").dataset.r, ol = b.nextElementSibling; openRec[r] = !openRec[r];
      ol.hidden = !openRec[r]; b.setAttribute("aria-expanded", openRec[r]); b.textContent = openRec[r] ? "Hide the top 10" : "See the top 10";
    }
  });
  var rt = null;
  window.addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(function () { if (S) { bars(); growth(); } }, 150); });
  chapters();
  load();
  setInterval(function () { if (!document.hidden) load(); }, 60000);
})();
