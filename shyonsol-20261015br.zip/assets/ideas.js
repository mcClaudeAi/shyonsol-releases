// Ideas board on the release notes page: suggestions the team made public, with votes.
(function () {
  "use strict";
  var root = document.getElementById("ideas-list");
  if (!root) return;
  var API = "api/suggest.php", items = [], filter = "all", page = 1;
  var ST = { new: "New", reviewing: "Reviewing", vote: "Community vote", planned: "Planned", building: "Building", shipped: "Shipped", declined: "Not for now" };
  var CAT = { game: "Game idea", cards: "Cards and balance", shop: "Shop and rewards", site: "Website", bug: "Bug fix", other: "Idea" };
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  function me() {
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid) { pid = hex(8); store("shy-lb-pid", pid); }
    if (!key) { key = hex(16); store("shy-lb-key", key); }
    return { pid: pid, key: key };
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  function draw() {
    var list = items.filter(function (x) { return filter === "all" || x.status === filter; });
    //MC 2026-10-13 ideas put to a community vote lead the board, so the vote the team asked for is the first thing seen
    if (filter === "all") list = list.filter(function (x) { return x.status === "vote"; }).concat(list.filter(function (x) { return x.status !== "vote"; }));
    var chips = document.getElementById("ideas-filter");
    if (chips) chips.querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.f === filter); });
    if (!items.length) { root.innerHTML = '<div class="ib-empty"><b>The board is empty, for now.</b><p>Send the first idea. The best ones land here for everyone to vote on.</p><button class="btn btn-red" data-suggest>Suggest an idea</button></div>'; return; }
    if (!list.length) { root.innerHTML = '<p class="ib-none">Nothing with that status yet.</p>'; return; }
    //MC 2026-10-09 the board pages 8 ideas at a time; a status filter starts back on page 1
    var P = window.ShyPager ? ShyPager.slice(list, 8, page) : { items: list, page: 1, pages: 1 };
    page = P.page;
    root.innerHTML = P.items.map(function (x) {
      return '<article class="ib st-' + x.status + '"><button class="ib-vote' + (x.mine ? " on" : "") + '" data-vote="' + esc(x.id) + '" aria-pressed="' + x.mine + '" aria-label="Vote for this idea"><svg viewBox="0 0 24 24"><path d="m6 14 6-6 6 6"/></svg><b>' + x.votes + '</b></button>' +
        '<div class="ib-body"><div class="ib-top"><span class="ib-st">' + (ST[x.status] || x.status) + '</span><span class="ib-cat">' + (CAT[x.cat] || "Idea") + '</span>' + (x.by ? '<span class="ib-by">from ' + esc(x.by) + '</span>' : "") + '</div>' +
        '<h3>' + esc(x.title) + '</h3>' + (x.text && x.text !== x.title ? '<p>' + esc(x.text) + '</p>' : "") +
        (x.reply ? '<div class="ib-reply"><span>Team</span>' + esc(x.reply) + '</div>' : "") + '</div></article>';
    }).join("") + (window.ShyPager ? ShyPager.html(P, "ib") : "");
  }
  async function load() {
    try { var j = await (await fetch(API + "?a=board&me=" + me().pid.slice(0, 6))).json(); if (j.ok) items = j.ideas; } catch (e) {}
    draw();
  }
  document.addEventListener("click", async function (e) {
    var f = e.target.closest("#ideas-filter [data-f]");
    if (f) { filter = f.dataset.f; page = 1; draw(); return; }
    var pg = window.ShyPager && e.target.closest("#ideas-list") && ShyPager.hit(e, "ib");
    if (pg) { page = pg.page; draw(); var h = document.getElementById("ideas-filter"); if (h) h.scrollIntoView({ block: "center", behavior: "smooth" }); return; }
    var v = e.target.closest("[data-vote]");
    if (!v) return;
    var it = items.filter(function (x) { return x.id === v.dataset.vote; })[0]; if (!it) return;
    v.disabled = true;
    var id = me();
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "vote", pid: id.pid, key: id.key, id: it.id }) });
      var j = await r.json();
      if (j.ok) { it.votes = j.votes; it.mine = j.mine; }
      else if (j.error) { v.title = j.error; v.classList.add("shake"); setTimeout(function () { v.classList.remove("shake"); }, 500); }
    } catch (x) {}
    v.disabled = false;
    draw();
  });
  load();
})();
