// Shilluminati page: filter and search the deck, and open any card large.
(function () {
  "use strict";
  var C = window.SHIL_CARDS || {}, K = window.SHIL_KINDS || {};
  var grid = document.getElementById("deck-grid");
  if (!grid) return;
  var q = document.getElementById("deck-q"), none = document.getElementById("deck-none");
  var chips = document.querySelectorAll(".kf"), kind = "all";
  var AV = (document.querySelector('script[src*="cards-page.js"]') || {}).src;
  AV = AV && AV.indexOf("?") > 0 ? AV.slice(AV.indexOf("?")) : "";
  var TARGET = { pick: "You choose which rival it hits.", leader: "It always hits the rival with the most Regions." };

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function visible() { return Array.prototype.filter.call(grid.children, function (b) { return !b.hidden; }); }

  function apply() {
    var term = (q.value || "").trim().toLowerCase(), shown = 0;
    //MC 2026-10-13 the Yours chip narrows every view to the cards this player has played or owns finishes on
    var my = null;
    if (mine && ME) { my = {}; mineIds().forEach(function (c) { my[c] = 1; }); }
    Array.prototype.forEach.call(grid.children, function (b) {
      var c = C[b.dataset.id];
      var ok = (kind === "all" || c.k === kind) && (!term || (c.n + " " + c.t + " " + K[c.k][0]).toLowerCase().indexOf(term) >= 0) && (!my || my[b.dataset.id]);
      b.hidden = !ok; if (ok) shown++;
    });
    none.hidden = shown > 0;
  }
  Array.prototype.forEach.call(chips, function (ch) {
    ch.addEventListener("click", function () {
      kind = ch.dataset.k;
      Array.prototype.forEach.call(chips, function (x) { x.classList.toggle("on", x === ch); x.setAttribute("aria-selected", x === ch); });
      apply();
    });
  });
  q.addEventListener("input", apply);

  // ---- card viewer
  var cv = document.getElementById("cv");
  document.body.appendChild(cv);   // out of <main> so it sits above the phone tab bar
  var body = document.getElementById("cv-body"), cur = null, lastFocus = null;
  function show(id) {
    var c = C[id]; if (!c) return;
    cur = id;
    var k = K[c.k];
    var how = c.k === "passive" ? "You don't play it. Keep it in your hand and it works on its own." :
      c.k === "attack" ? (TARGET[c.g] || "It hits every rival at once.") + " A Defense card or a Reaction can stop it." :
      c.k === "global" ? "It hits the whole table when you play it, and that can include you." :
      c.k === "defense" ? "Play it on your turn and the shield goes up right away." :
      c.k === "gain" ? "Play it on your turn to grow your side of the table." : "Play it on your turn to change the rules for a moment.";
    body.innerHTML = '<div class="cc k-' + c.k + ' big"><span class="cc-art"><img src="assets/cards/' + id + '.webp' + AV + '" alt=""></span>' +
      '<span class="cc-body"><span class="cc-k">' + esc(k[0]) + '</span><b>' + esc(c.n) + '</b><span class="cc-t">' + esc(c.t) + '</span></span></div>' +
      '<div class="cv-info k-' + c.k + '"><span class="cv-type"><span class="kd"></span>' + esc(k[0]) + ' &middot; ' + esc(k[1]) + '</span>' +
      '<p>' + esc(how) + '</p>' + ownView(id) + '<a class="btn btn-red btn-sm" href="/play">Play it now</a></div>';
    if (cv.hidden) { lastFocus = document.activeElement; cv.hidden = false; document.documentElement.classList.add("cv-open"); cv.querySelector(".cv-x").focus(); }
  }
  function close() { cv.hidden = true; cur = null; document.documentElement.classList.remove("cv-open"); if (lastFocus) lastFocus.focus(); }
  function step(d) {
    var list = visible(); if (!list.length) return;
    var i = list.findIndex(function (b) { return b.dataset.id === cur; });
    show(list[(i + d + list.length) % list.length].dataset.id);
  }
  grid.addEventListener("click", function (e) { var b = e.target.closest(".cc"); if (b) show(b.dataset.id); });
  cv.addEventListener("click", function (e) {
    if (e.target.closest("[data-cv-close]")) return close();
    var s = e.target.closest("[data-cv-step]"); if (s) step(+s.dataset.cvStep);
  });
  document.addEventListener("keydown", function (e) {
    if (cv.hidden) return;
    if (e.key === "Escape") close(); else if (e.key === "ArrowRight") step(1); else if (e.key === "ArrowLeft") step(-1);
  });
  var x0 = null;
  cv.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  cv.addEventListener("touchend", function (e) { if (x0 === null) return; var dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 50) step(dx < 0 ? 1 : -1); x0 = null; });
  // ---------------------------------------------------------------- your deck, on the deck
  //MC 2026-10-13 a signed-in player sees their own story on the public deck: mastery stars and play counts on each
  //   card they've played, dots for the finishes they own (the worn one marked), a Yours filter chip, and a strip in
  //   the card viewer with their level, the plays to the next one and their finishes by name. Visitors see the page
  //   exactly as before; the account answers arrive after the page settles and never block it.
  var ME = null, CAT = null, mine = false, LVL = [[5, "Novice"], [15, "Adept"], [40, "Veteran"], [100, "Master"], [200, "Grandmaster"]];
  var FINC = { gold: "#f2c35b", crimson: "#ff5d73", neon: "#4cc9f0", holo: "#b9a0ff", shadow: "#8b5cf6", ink: "#cfd6e4", seal: "#ff3b5c", smoke: "#9aa3b5", kintsugi: "#ffd27a", sakura: "#ffa6c9", ember: "#ff7a4d", frost: "#9fe8ff", koi: "#ff9f43", raijin: "#ffe066", glitch: "#2ef0b0", aurora: "#7ff2c9", cosmos: "#a78bfa" };
  function store(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lvOf(p) { var l = 0; LVL.forEach(function (x, i) { if (p >= x[0]) l = i + 1; }); return l; }
  function stars(l) { var h = ""; for (var i = 0; i < 5; i++) h += '<i class="' + (i < l ? "on" : "") + '">★</i>'; return h; }
  function finName(f) { return CAT && CAT.finishes && CAT.finishes[f] && CAT.finishes[f].name || f; }
  function mineIds() {
    if (!ME) return [];
    var ids = {};
    Object.keys(ME.cm || {}).forEach(function (c) { if (ME.cm[c] > 0) ids[c] = 1; });
    Object.keys(ME.vf || {}).forEach(function (c) { if (Object.keys(ME.vf[c] || {}).length) ids[c] = 1; });
    return Object.keys(ids).filter(function (c) { return C[c]; });
  }
  function ownView(id) {
    if (!ME) return "";
    var p = (ME.cm || {})[id] || 0, fin = Object.keys((ME.vf || {})[id] || {}), worn = (ME.veq || {})[id] || "";
    if (!p && !fin.length) return "";
    var l = lvOf(p), nxt = l < 5 ? LVL[l][0] : 0;
    var h = '<div class="cv-own"><span class="cc-st">' + stars(l) + '</span><span class="cv-ol">' +
      (l ? '<b>' + esc(LVL[l - 1][1]) + '</b><span aria-hidden="true"> · </span>' : "") + '<span>' + p + (p === 1 ? " play" : " plays") + '</span>' +
      (nxt ? '<span aria-hidden="true"> · </span><span>next level at ' + nxt + '</span>' : "") + '</span>';
    if (fin.length) h += '<span class="cv-fins">' + fin.map(function (f) {
      return '<span class="cv-fin' + (f === worn ? " worn" : "") + '"><i style="background:' + (FINC[f] || "#a78bfa") + '"></i><span data-i18n-skip>' + esc(finName(f)) + '</span>' + (f === worn ? ' <small>worn</small>' : "") + '</span>';
    }).join("") + '</span>';
    return h + '</div>';
  }
  function annotate() {
    Array.prototype.forEach.call(grid.children, function (b) {
      var id = b.dataset.id, p = (ME.cm || {})[id] || 0, fin = Object.keys((ME.vf || {})[id] || {});
      var old = b.querySelector(".cc-own"); if (old) old.remove();
      if (!p && !fin.length) return;
      var l = lvOf(p);
      var h = '<span class="cc-own">' + (p ? '<span class="cc-st">' + stars(l) + '</span><em>' + p + '</em>' : "") +
        (fin.length ? '<span class="cc-fd">' + fin.slice(0, 3).map(function (f) { return '<i style="background:' + (FINC[f] || "#a78bfa") + '"></i>'; }).join("") + (fin.length > 3 ? "+" + (fin.length - 3) : "") + '</span>' : "") + '</span>';
      b.insertAdjacentHTML("beforeend", h);
    });
    var bar = document.querySelector(".kfilter");
    var n = mineIds().length;
    if (bar && n && !bar.querySelector("[data-k-mine]")) {
      bar.insertAdjacentHTML("beforeend", '<button class="kf kf-mine" data-k-mine>Yours <i>' + n + '</i></button>');
      bar.querySelector("[data-k-mine]").addEventListener("click", function () {
        mine = !mine; this.classList.toggle("on", mine); apply();
      });
    }
  }
  (function () {
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid || !key) return;
    var later = window.requestIdleCallback ? function (f) { requestIdleCallback(f, { timeout: 2500 }); } : function (f) { setTimeout(f, 800); };
    later(function () {
      fetch("api/shop.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "me", pid: pid, key: key }) })
        .then(function (r) { return r.json(); }).then(function (j) {
          if (!j || !j.ok || !j.me) return;
          ME = j.me;
          annotate();
          var hasFin = Object.keys(ME.vf || {}).some(function (c) { return Object.keys(ME.vf[c] || {}).length; });
          if (hasFin) fetch("api/shop.php?a=catalog").then(function (r) { return r.json(); }).then(function (c) { if (c && c.ok) CAT = c; }).catch(function () {});
        }).catch(function () {});
    });
  })();

  //MC 2026-10-11 links from the not-found page's search: /cards?card=<id> opens that card large, /cards?q=<text> fills the
  //   deck search. Only ids that are in the deck and plain text are taken from the address.
  try {
    var qs = new URLSearchParams(location.search), want = qs.get("card"), term = qs.get("q");
    if (term && term.length <= 40) { q.value = term; apply(); }
    if (want && /^[a-z0-9]{2,30}$/.test(want) && C[want]) {
      var at = grid.querySelector('[data-id="' + want + '"]');
      if (at) at.scrollIntoView({ block: "center" });
      show(want);
    }
  } catch (e) {}
})();
