//MC 2026-10-13 the community half of the living roadmap on the Future page: the Ideas board, live. Ideas open for a
//   vote lead, then what's planned and being built, then ideas that already shipped, each with its vote count and a
//   link to the board. The section's shipped half is written at build time from the release notes.
(function () {
  "use strict";
  var el = document.getElementById("lr-ideas");
  if (!el) return;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var ST = { vote: "Community vote", planned: "Planned", building: "Building", shipped: "Shipped" };
  function row(x) {
    return '<a class="lr-idea st-' + esc(x.status) + '" href="updates.html#ideas"><span class="lr-st">' + (ST[x.status] || esc(x.status)) + '</span>' +
      '<b>' + esc(x.title) + '</b><span class="lr-v"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6"/></svg>' + (+x.votes || 0) + '</span></a>';
  }
  function draw(ideas) {
    var vote = [], work = [], done = [];
    ideas.forEach(function (x) {
      if (x.status === "vote") vote.push(x);
      else if (x.status === "planned" || x.status === "building") work.push(x);
      else if (x.status === "shipped") done.push(x);
    });
    var h = "";
    if (vote.length) h += '<div class="lr-gh">Open for your vote</div>' + vote.slice(0, 3).map(row).join("");
    if (work.length) h += '<div class="lr-gh">On the bench</div>' + work.slice(0, 4).map(row).join("");
    if (done.length) h += '<div class="lr-gh">Ideas that shipped</div>' + done.slice(0, 3).map(row).join("");
    if (!h) h = '<p class="lr-empty">The board is open and waiting for the first ideas. Yours could set the course.</p>';
    el.innerHTML = h;
  }
  var later = window.requestIdleCallback ? function (f) { requestIdleCallback(f, { timeout: 2000 }); } : function (f) { setTimeout(f, 500); };
  later(function () {
    fetch("api/suggest.php?a=board").then(function (r) { return r.json(); }).then(function (j) {
      if (j && j.ok) draw(j.ideas || []);
    }).catch(function () { el.innerHTML = '<p class="lr-empty">The board is taking a breath. Try again in a minute.</p>'; });
  });
})();
