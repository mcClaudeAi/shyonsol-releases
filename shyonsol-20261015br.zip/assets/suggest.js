// Suggest an idea: a small form on every page. Players send an idea or a bug, with an optional screenshot.
(function () {
  "use strict";
  var API = "api/suggest.php";
  var CATS = [["game", "Game idea", "遊"], ["cards", "Cards and balance", "札"], ["shop", "Shop and rewards", "金"], ["site", "Website", "網"], ["bug", "Something broke", "壊"], ["other", "Something else", "他"]];
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  function me() {
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid) { pid = hex(8); store("shy-lb-pid", pid); }
    if (!key) { key = hex(16); store("shy-lb-key", key); }
    return { pid: pid, key: key };
  }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  var box = null, state = { cat: "game", img: "", busy: false }, last = null;

  // floating button on larger screens (the game page has its own spot in the menu)
  if (!/\/play$|\/play\.html$/.test(location.pathname)) {
    var fab = document.createElement("button");
    fab.className = "idea-fab"; fab.type = "button"; fab.setAttribute("data-suggest", "");
    fab.innerHTML = '<span class="idea-bulb" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2V16h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3Z"/></svg></span><span>Suggest an idea</span>';
    document.body.appendChild(fab);
  }

  function open(cat) {
    last = document.activeElement;
    if (cat) state.cat = cat;
    if (!box) { box = document.createElement("div"); box.className = "idea-modal"; box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-label", "Suggest an idea"); document.body.appendChild(box); }
    draw();
    box.hidden = false;
    document.documentElement.classList.add("idea-open");
    requestAnimationFrame(function () { box.classList.add("in"); var t = box.querySelector("textarea"); if (t) t.focus(); });
  }
  function close() {
    if (!box) return;
    box.classList.remove("in");
    document.documentElement.classList.remove("idea-open");
    setTimeout(function () { box.hidden = true; }, 200);
    if (last && last.focus) last.focus();
  }
  function draw(done) {
    var saved = box && box.querySelector("textarea") ? box.querySelector("textarea").value : (store("shy-idea-draft") || "");
    var contact = box && box.querySelector("#idea-contact") ? box.querySelector("#idea-contact").value : (store("shy-idea-contact") || "");
    var h = '<div class="idea-back" data-idea-close></div><div class="idea-panel"><button class="idea-x" data-idea-close aria-label="Close">&times;</button>';
    if (done) {
      h += '<div class="idea-done"><span class="idea-seal big">謝</span><h3>Got it. Thank you.</h3><p>The team reads every suggestion. The good ones go up on the Ideas board, where everyone can vote.</p>' +
        '<div class="idea-btns"><a class="btn btn-red" href="/updates#ideas">See the Ideas board</a><button class="btn btn-line" data-idea-again>Send another</button></div></div></div>';
      box.innerHTML = h; return;
    }
    h += '<div class="idea-head"><span class="idea-seal">案</span><div><h3>Suggest an idea</h3><p>Players have shaped this game since day one. Tell us what would make it better, or what broke.</p></div></div>' +
      '<div class="idea-cats" role="radiogroup" aria-label="What is it about?">' + CATS.map(function (c) {
        return '<button type="button" role="radio" aria-checked="' + (c[0] === state.cat) + '" class="' + (c[0] === state.cat ? "on" : "") + '" data-cat="' + c[0] + '"><i>' + c[2] + '</i>' + c[1] + '</button>';
      }).join("") + '</div>' +
      '<label class="idea-field"><span>' + (state.cat === "bug" ? "What happened, and what did you expect?" : "Your idea") + '</span><textarea maxlength="1500" rows="5" placeholder="' + (state.cat === "bug" ? "I tapped Collect on the Scroll and nothing happened…" : "It would be great if…") + '">' + esc(saved) + '</textarea><small class="idea-count"><b>' + saved.length + '</b> / 1500</small></label>' +
      '<div class="idea-shot">' + (state.img ? '<img src="' + state.img + '" alt="Your screenshot"><button type="button" data-idea-noimg>Remove</button>' :
        '<label class="idea-drop"><input type="file" accept="image/png,image/jpeg,image/webp" hidden><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="m21 15-5-4-9 8"/></svg><span><b>Add a screenshot</b> (optional). Drop it here, paste it, or tap to choose.</span></label>') + '</div>' +
      '<label class="idea-field"><span>How can we reach you? <em>Optional</em></span><input id="idea-contact" maxlength="80" value="' + esc(contact) + '" placeholder="X handle, Telegram or email"></label>' +
      '<input class="idea-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">' +
      '<p class="idea-msg" id="idea-msg" role="status"></p>' +
      '<div class="idea-btns"><button class="btn btn-red" data-idea-send>Send suggestion</button><a class="idea-link" href="/updates#ideas">See what others asked for</a></div></div>';
    box.innerHTML = h;
  }
  function msg(t, bad) { var m = box && box.querySelector("#idea-msg"); if (m) { m.textContent = t; m.classList.toggle("bad", !!bad); } }

  // shrink big screenshots in the browser so they upload fast
  function takeImage(file) {
    if (!file || !/^image\/(png|jpeg|webp)$/.test(file.type)) { msg("Screenshots can be PNG, JPG or WebP.", true); return; }
    if (file.size > 15 * 1024 * 1024) { msg("That image is too big.", true); return; }
    var url = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      var s = Math.min(1, 1600 / Math.max(im.width, im.height)), c = document.createElement("canvas");
      c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      state.img = c.toDataURL("image/jpeg", 0.86);
      draw();
    };
    im.onerror = function () { msg("That image couldn't be read.", true); };
    im.src = url;
  }

  async function send() {
    if (state.busy) return;
    var text = box.querySelector("textarea").value.trim(), contact = box.querySelector("#idea-contact").value.trim();
    if (text.length < 10) { msg("Tell us a little more, at least a sentence.", true); return; }
    state.busy = true;
    var b = box.querySelector("[data-idea-send]"); b.disabled = true; b.textContent = "Sending…";
    var id = me();
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "send", pid: id.pid, key: id.key, cat: state.cat, text: text, contact: contact,
        page: location.pathname, lang: (window.SHYI18N && SHYI18N.lang) || "en", img: state.img, hp: box.querySelector(".idea-hp").value }) });
      var j = await r.json();
      if (!j.ok) throw new Error(j.error || "Couldn't send that right now.");
      store("shy-idea-draft", ""); if (contact) store("shy-idea-contact", contact);
      state.img = ""; state.busy = false;
      draw(true);
    } catch (e) {
      state.busy = false; b.disabled = false; b.textContent = "Send suggestion";
      msg(e.message || "Couldn't send that right now. Try again in a minute.", true);
    }
  }

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-suggest]");
    if (t) { e.preventDefault(); var d = document.getElementById("drawer"); if (d && d.classList.contains("open")) { var c = document.getElementById("close"); if (c) c.click(); } open(t.dataset.suggest || ""); return; }
    if (!box || box.hidden || !e.target.closest(".idea-modal")) return;
    if (e.target.closest("[data-idea-close]")) return close();
    var c2 = e.target.closest("[data-cat]");
    if (c2) { state.cat = c2.dataset.cat; draw(); return; }
    if (e.target.closest("[data-idea-noimg]")) { state.img = ""; draw(); return; }
    if (e.target.closest("[data-idea-again]")) { draw(); return; }
    if (e.target.closest("[data-idea-send]")) send();
  });
  document.addEventListener("input", function (e) {
    if (!box || !e.target.closest(".idea-modal")) return;
    if (e.target.tagName === "TEXTAREA") { store("shy-idea-draft", e.target.value); var n = box.querySelector(".idea-count b"); if (n) n.textContent = e.target.value.length; }
  });
  document.addEventListener("change", function (e) { if (box && e.target.closest(".idea-drop")) takeImage(e.target.files[0]); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && box && !box.hidden) close(); });
  document.addEventListener("paste", function (e) {
    if (!box || box.hidden) return;
    var it = Array.prototype.filter.call((e.clipboardData || {}).items || [], function (x) { return x.type.indexOf("image/") === 0; })[0];
    if (it) { e.preventDefault(); takeImage(it.getAsFile()); }
  });
  document.addEventListener("dragover", function (e) { if (box && !box.hidden && e.target.closest(".idea-drop")) { e.preventDefault(); e.target.closest(".idea-drop").classList.add("over"); } });
  document.addEventListener("drop", function (e) {
    if (!box || box.hidden || !e.target.closest(".idea-drop")) return;
    e.preventDefault(); takeImage(e.dataTransfer.files[0]);
  });
  window.ShySuggest = { open: open };
  if (/[#&]suggest\b/.test(location.hash)) open();
})();
