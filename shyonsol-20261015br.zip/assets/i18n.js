// Languages: the site is written in English and translated in the browser from a dictionary per language.
// Each block of text (a heading, a paragraph, a button) is looked up whole, with its bold words and links kept in place,
// numbers kept as they are, and names (cards, Regions, players) kept or swapped for their local name.
// Anything without a translation stays in English, so nothing ever shows up blank.
(function () {
  "use strict";
  var LANGS = [["en", "English"], ["tr", "Türkçe"], ["es", "Español"], ["pt", "Português"], ["fr", "Français"], ["de", "Deutsch"],
    ["ru", "Русский"], ["vi", "Tiếng Việt"], ["id", "Bahasa Indonesia"], ["zh", "中文"], ["ko", "한국어"], ["fa", "فارسی"]];
  var CODES = LANGS.map(function (l) { return l[0]; });
  var HTML_LANG = { pt: "pt-BR", zh: "zh-CN" };
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }

  // which language: ?lang= in the address, then the visitor's own choice, then their browser
  function pick() {
    var m = /[?&]lang=([a-z]{2})/.exec(location.search);
    if (m && CODES.indexOf(m[1]) >= 0) { store("shy-lang", m[1]); return m[1]; }
    var s = store("shy-lang");
    if (s && CODES.indexOf(s) >= 0) return s;
    var nav = navigator.languages || [navigator.language || "en"];
    for (var i = 0; i < nav.length; i++) {
      var c = String(nav[i] || "").toLowerCase().slice(0, 2);
      if (c === "in") c = "id";
      if (CODES.indexOf(c) >= 0) return c;
    }
    return "en";
  }
  var lang = pick();
  var collect = /[?&]i18n=collect/.test(location.search) || store("shy-i18n-collect") === "1";
  var me = document.currentScript;
  var ver = me && /[?&]v=([^&]+)/.exec(me.src); ver = ver ? ver[1] : "";
  var root = document.documentElement;
  root.lang = HTML_LANG[lang] || lang;
  root.setAttribute("data-lang", lang);
  // Persian reads right to left; the game board, the map and the bracket keep their left-to-right layout in CSS
  var RTL = { fa: 1 };
  if (RTL[lang]) root.dir = "rtl";
  //MC 2026-10-09 one locale for dates and numbers. Persian keeps Latin digits and the Gregorian calendar so dates match the
  // numbers, prices and dated copy around them (Intl with plain "fa" gave Persian digits and Solar Hijri dates next to Latin ones)
  var LOCALE = lang === "fa" ? "fa-u-nu-latn-ca-gregory" : (HTML_LANG[lang] || lang);
  if (lang !== "en" || collect) document.write('<script src="/assets/i18n/names.js?v=' + ver + '"><\/script>');
  if (lang !== "en") {
    root.classList.add("i18n-wait");
    document.write('<script src="/assets/i18n/' + lang + '.js?v=' + ver + '"><\/script>');
    setTimeout(function () { root.classList.remove("i18n-wait"); }, 2500);   // never leave a page hidden
  }

  // ---------------------------------------------------------------- keys
  //MC 2026-10-09 BDI and SHY-BD added: the right-to-left fix below wraps numbers in <bdi data-bd> inside a <shy-bd>, which must not split a sentence into blocks
  var INLINE = { A: 1, B: 1, STRONG: 1, I: 1, EM: 1, SPAN: 1, SMALL: 1, BR: 1, U: 1, S: 1, SUB: 1, SUP: 1, MARK: 1, ABBR: 1, TIME: 1, Q: 1, KBD: 1, IMG: 1, SVG: 1, WBR: 1, DEL: 1, INS: 1, BDI: 1, "SHY-BD": 1 };
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEXTAREA: 1, INPUT: 1, CODE: 1, PRE: 1, SVG: 1, CANVAS: 1, TEMPLATE: 1, IFRAME: 1, VIDEO: 1, AUDIO: 1 };
  var NUM = /\d+(?:[.,:]\d+)*/g;
  var LETTER = /[A-Za-z]{2,}/;
  function skipEl(el) { return SKIP[el.nodeName.toUpperCase()] || (el.hasAttribute && (el.hasAttribute("data-i18n-skip") || el.getAttribute("translate") === "no" || el.isContentEditable)); }
  function isInline(el) {
    if (el.nodeType === 3) return true;
    if (el.nodeType !== 1) return true;
    var t = el.nodeName.toUpperCase();
    if (!INLINE[t] || skipEl(el) && t !== "SVG" && !el.hasAttribute("data-i18n-skip")) return false;
    if (el.hasAttribute("data-i18n-skip")) return true;
    if (t === "SVG" || t === "IMG" || t === "BR" || t === "WBR") return true;
    for (var c = el.firstChild; c; c = c.nextSibling) if (!isInline(c)) return false;
    return true;
  }
  function hasWords(el) { return el.nodeType === 3 ? LETTER.test(el.data) : LETTER.test(el.textContent || ""); }

  // a run of sibling nodes becomes "Play the <0>Daily</0> now <1/>" plus the list of elements behind each number
  function serialize(nodes) {
    var els = [], parts = [];
    function walk(n) {
      if (n.nodeType === 3) { parts.push(n.data); return; }
      if (n.nodeType !== 1) return;
      //MC 2026-10-09 our own bidi wrappers are invisible to the key, so a sentence keeps the key it had before wrapping
      if (n.hasAttribute("data-bd")) { for (var d = n.firstChild; d; d = d.nextSibling) walk(d); return; }
      var t = n.nodeName.toUpperCase(), k = els.length;
      els.push(n);
      // icons, and bits with no words (a price, a count, a timer) stay exactly as they are
      if (t === "SVG" || t === "IMG" || t === "BR" || t === "WBR" || !hasWords(n) || n.hasAttribute("data-i18n-skip")) { parts.push("<" + k + "/>"); return; }
      parts.push("<" + k + ">");
      for (var c = n.firstChild; c; c = c.nextSibling) walk(c);
      parts.push("</" + k + ">");
    }
    nodes.forEach(walk);
    return { els: els, raw: parts.join("").replace(/\s+/g, " ").trim() };
  }
  // numbers become {0}, {1}… (never the ones inside <0> tags or {e0} names)
  function nums(s) {
    var out = [];
    var k = s.split(/(<\/?\d+\/?>|\{e\d+\})/).map(function (part, i) {
      return i % 2 ? part : part.replace(NUM, function (m) { out.push(m); return "{" + (out.length - 1) + "}"; });
    }).join("");
    return { key: k, vals: out };
  }

  // names that stay names: cards, Regions, the house players, plus players in the current game
  var ENT = [], entRe = null;
  function addNames(list) {
    var add = false;
    (list || []).forEach(function (n) { n = String(n || "").trim(); if (n.length > 1 && ENT.indexOf(n) < 0) { ENT.push(n); add = true; } });
    if (!add) return;
    ENT.sort(function (a, b) { return b.length - a.length; });
    entRe = new RegExp("(^|[^\\w])(" + ENT.map(function (n) { return n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }).join("|") + ")(?![\\w])", "g");
  }
  function ents(s) {
    if (!entRe) return null;
    var out = [];
    // names only inside the text, never inside the <0> markers
    var k = s.replace(/(<\/?\d+\/?>)|([^<]+)/g, function (m, tag, txt) {
      if (tag) return tag;
      return txt.replace(entRe, function (mm, pre, name) { out.push(name); return pre + "{e" + (out.length - 1) + "}"; });
    });
    return out.length ? { key: k, vals: out } : null;
  }

  // ---------------------------------------------------------------- dictionary
  function hash(s) { var h = 0x811c9dc5; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
  function dict() { return window.SHY_DICT || null; }
  var seen = collect ? {} : null;
  function note(key, sample) { if (seen && LETTER.test(key.replace(/<\/?\d+\/?>|\{e?\d+\}/g, "")) && !seen[key]) seen[key] = { s: sample.slice(0, 200), p: location.pathname }; }
  // look a key up: numbers first, then with names taken out. Returns the filled-in translation or null.
  function lookup(raw) {
    var n = nums(raw), d = dict();
    var t = d && d.h[hash(n.key)];
    var e = null;
    if (t == null) {
      e = ents(raw);
      if (e) { n = nums(e.key); t = d && d.h[hash(n.key)]; }
    }
    if (seen) note(n.key, raw);
    // only names and numbers (a Region on its own): swap in the local names, no dictionary needed
    if (t == null && e && d && !LETTER.test(n.key.replace(/<\/?\d+\/?>|\{e?\d+\}/g, ""))) t = n.key;
    if (t == null) return null;
    //MC 2026-10-09 text arrows point the reading way in Persian. Most fa strings kept the English →, a few were already ←
    if (BIDI) t = t.replace(/→/g, "←").replace(/↗/g, "↖");
    var nv = n.vals, ev = e ? e.vals : [];
    return t.replace(/\{(e?)(\d+)\}/g, function (m, isE, i) {
      i = +i;
      if (isE) { var nm = ev[i]; return nm == null ? m : (d.e && d.e[nm]) || nm; }
      return nv[i] == null ? m : nv[i];
    });
  }

  // ---------------------------------------------------------------- applying
  var done = new WeakSet();
  function allDone(nodes) {
    var any = false, ok = true;
    function w(n) { if (!ok) return; if (n.nodeType === 3) { if (/\S/.test(n.data)) { any = true; if (!done.has(n)) ok = false; } return; } if (!hasWords(n)) return; for (var c = n.firstChild; c; c = c.nextSibling) w(c); }
    nodes.forEach(w);
    return any && ok;
  }
  function markDone(n) { if (n.nodeType === 3) done.add(n); else for (var c = n.firstChild; c; c = c.nextSibling) markDone(c); }
  // rebuild a run of nodes from its translation, reusing the original elements so the page's own code keeps working
  function rebuild(nodes, els, tr) {
    var toks = tr.match(/<\/?\d+\/?>|[^<]+|</g) || [];
    var used = {}, need = {};
    els.forEach(function (_, i) { need[i] = 1; });
    toks.forEach(function (t) { var m = /^<(\d+)\/?>$/.exec(t); if (m) used[m[1]] = 1; });
    for (var k in need) if (!used[k]) return false;   // a tag went missing: keep the English
    var parent = nodes[0].parentNode, after = nodes[nodes.length - 1].nextSibling;
    var frag = document.createDocumentFragment(), stack = [frag], lead = /^\s/.test(nodes[0].nodeType === 3 ? nodes[0].data : ""), tail = /\s$/.test(nodes[nodes.length - 1].nodeType === 3 ? nodes[nodes.length - 1].data : "");
    toks.forEach(function (t) {
      var top = stack[stack.length - 1], m;
      if ((m = /^<(\d+)\/>$/.exec(t))) top.appendChild(els[+m[1]]);
      else if ((m = /^<(\d+)>$/.exec(t))) { var el = els[+m[1]]; while (el.firstChild) el.removeChild(el.firstChild); top.appendChild(el); stack.push(el); }
      else if (/^<\/\d+>$/.test(t)) { if (stack.length > 1) stack.pop(); }
      else { var tn = document.createTextNode(t); done.add(tn); top.appendChild(tn); }
    });
    if (lead) { var a = document.createTextNode(" "); done.add(a); frag.insertBefore(a, frag.firstChild); }
    if (tail) { var b = document.createTextNode(" "); done.add(b); frag.appendChild(b); }
    nodes.forEach(function (n) { if (n.parentNode === parent && els.indexOf(n) < 0) parent.removeChild(n); });
    parent.insertBefore(frag, after && after.parentNode === parent ? after : null);
    return true;
  }
  // icons and empty bits at either end of a run stay where they are and out of the key
  function isEdge(n) {
    if (n.nodeType === 3) return !/\S/.test(n.data);
    if (n.nodeType !== 1) return true;
    var t = n.nodeName.toUpperCase();
    return t === "SVG" || t === "IMG" || t === "BR" || t === "WBR" || !hasWords(n);
  }
  function doRun(nodes) {
    var a = 0, b = nodes.length;
    while (a < b && isEdge(nodes[a])) a++;
    while (b > a && isEdge(nodes[b - 1])) b--;
    nodes = nodes.slice(a, b);
    // one element wrapping everything (a link in a list item): its inside is the text
    while (nodes.length === 1 && nodes[0].nodeType === 1 && nodes[0].firstChild) return doRun(Array.prototype.slice.call(nodes[0].childNodes));
    if (!nodes.length || !nodes.some(hasWords) || allDone(nodes)) return;
    var s = serialize(nodes);
    if (!s.raw) return;
    var tr = lookup(s.raw);
    if (tr != null && rebuild(nodes, s.els, tr)) return;
    // no whole match: try the pieces (a bold phrase, a link) on their own
    s.els.forEach(function (el) { if (el.parentNode && hasWords(el) && el.firstChild) doRun(Array.prototype.slice.call(el.childNodes)); });
  }
  var ATTRS = ["placeholder", "title", "aria-label", "alt"];
  var attrDone = new WeakMap();
  function doAttrs(el) {
    var seenA = attrDone.get(el) || {};
    ATTRS.forEach(function (a) {
      var v = el.getAttribute(a);
      if (!v || !LETTER.test(v) || seenA[a] === v) return;
      var t = lookup(v.replace(/\s+/g, " ").trim());
      if (t != null) { el.setAttribute(a, t); seenA[a] = t; } else seenA[a] = v;
    });
    attrDone.set(el, seenA);
  }
  function visit(el) {
    if (!el || el.nodeType !== 1) return;
    // a text box keeps what's typed in it, but its hint text is translated
    if ((el.tagName === "INPUT" || el.tagName === "TEXTAREA") && el.hasAttribute("placeholder")) { doAttrs(el); return; }
    if (skipEl(el)) return;
    if (el.hasAttribute("placeholder") || el.hasAttribute("title") || el.hasAttribute("aria-label") || el.hasAttribute("alt")) doAttrs(el);
    var kids = Array.prototype.slice.call(el.childNodes), run = [];
    var flush = function () { if (run.length) { doRun(run); run = []; } };
    for (var i = 0; i < kids.length; i++) {
      var c = kids[i];
      if (c.nodeType === 3 || c.nodeType === 1 && isInline(c)) { run.push(c); if (c.nodeType === 1) attrsIn(c); }
      else if (c.nodeType === 1) { flush(); visit(c); }
    }
    flush();
  }
  function attrsIn(el) {
    if (el.nodeType !== 1) return;
    if (el.hasAttribute("placeholder") || el.hasAttribute("title") || el.hasAttribute("aria-label") || el.hasAttribute("alt")) doAttrs(el);
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) attrsIn(c);
  }
  // the nearest element that holds whole blocks of text
  function blockOf(n) {
    var el = n.nodeType === 1 ? n : n.parentNode;
    while (el && el !== document.body && el.nodeType === 1 && isInline(el)) el = el.parentNode;
    return el;
  }

  // ---------------------------------------------------------------- right to left
  //MC 2026-10-09 in Persian "$SHY" showed as "SHY$", "-0.28%" as "0.28%-", "#4" as "4#" and English lines lost their end period.
  // A number right after Persian letters counts as Arabic for the bidi rules, so the $ % # - around it get pushed to the far side.
  // Tried CSS on [data-stat] first: it only reaches numbers that sit alone in their own element, not $SHY inside a sentence.
  // So after translating, each text node gets one of two fixes, both left-to-right isolates (<bdi dir=ltr data-bd>):
  //  - a node with no Persian in it (English left untranslated, a price, "1 / 12") is wrapped whole, same text node moved inside
  //  - a node with Persian in it gets only its tokens wrapped: $SHY, $60, -0.28%, +50, ~500, 48%, #4, @name, 1 / 12, 88–52
  // The wrappers don't change textContent, and serialize() skips them, so dictionary keys stay the same.
  var BIDI = !!RTL[lang];
  var AR = /[֐-ࣿיִ-﷿ﹰ-﻿]/;
  var BD_NO = "script,style,textarea,select,option,svg,code,pre,title,noscript,template,canvas,[contenteditable],bdi,[data-bd]";
  var TOK = /(^|[^\w$#@.,])([-−+~≈]?\$(?:[A-Za-z]{2,}\b|\d+(?:[.,]\d+)*[KMBkmb]?)|[-−+~≈±]\d+(?:[.,]\d+)*%?|\d+(?:[.,]\d+)*\s?%|#\d+|@[A-Za-z0-9_]{2,}|\d+(?:\s?[\/–]\s?\d+)+)/g;
  function bdi(kid) {
    var b = document.createElement("bdi");
    b.dir = "ltr"; b.setAttribute("data-bd", "");
    if (kid != null) { kid = document.createTextNode(kid); done.add(kid); b.appendChild(kid); }
    return b;
  }
  var runDone = new WeakSet(), INL = { B: 1, STRONG: 1, I: 1, EM: 1, SPAN: 1, A: 1, SMALL: 1, IMG: 1, BR: 1, CODE: 1, SUP: 1, SUB: 1, MARK: 1, U: 1, S: 1, TIME: 1, ABBR: 1, BDI: 1, SVG: 1, "SHY-BD": 1 };
  function inlineOnly(el) {
    // only plain text flow: a flex or grid parent, or a child laid out as a block, would lose its layout inside the wrapper
    var d = getComputedStyle(el).display;
    if (/flex|grid|table/.test(d)) return false;
    for (var c = el.firstElementChild; c; c = c.nextElementSibling) { if (!INL[c.nodeName.toUpperCase()]) return false; var cd = getComputedStyle(c).display; if (cd !== "inline" && cd !== "none") return false; }
    return true;
  }
  function bidiFix(top) {
    // a whole-run isolate whose text got translated later: take it off again
    if (top.querySelectorAll) top.querySelectorAll("bdi[data-bd-run]").forEach(function (r) { if (AR.test(r.textContent)) { var pp = r.parentNode; while (r.firstChild) pp.insertBefore(r.firstChild, r); pp.removeChild(r); runDone.delete(pp); } });
    var w = document.createTreeWalker(top, NodeFilter.SHOW_TEXT), list = [], n;
    while ((n = w.nextNode())) list.push(n);
    list.forEach(function (tn) {
      var s = tn.data, p = tn.parentNode;
      if (!p || p.nodeType !== 1) return;
      // a wrapped English node that got translated later: take the wrapper off again
      if (p.nodeName === "BDI" && p.hasAttribute("data-bd") && p.childNodes.length === 1 && AR.test(s)) { p.parentNode.replaceChild(tn, p); p = tn.parentNode; }
      if (!/[\d$#@A-Za-z]/.test(s) || p.closest(BD_NO)) return;
      if (!AR.test(s)) {
        //MC 2026-10-09 an English sentence split by inline tags ("Added to <b>Shadow #255</b>'s record", text + coin + number)
        //   came out in reverse order in Persian, because each piece got its own LTR isolate. When the whole parent is
        //   English and only holds inline bits, isolate the parent's content once instead of piece by piece.
        if (p.nodeName !== "BDI" && !runDone.has(p) && p.children.length && !AR.test(p.textContent) && inlineOnly(p)) {
          runDone.add(p);
          var r = bdi(null); r.setAttribute("data-bd-run", "");
          while (p.firstChild) r.appendChild(p.firstChild);
          p.appendChild(r);
          return;
        }
        if (p.nodeName === "BDI" && p.hasAttribute("data-bd-run")) return;
        var t = s.trim();
        if (!/[^A-Za-z0-9\s]/.test(t) || !(/[A-Za-z]{2,}/.test(t) || /[\d$]/.test(t))) return;
        var b = bdi(null);
        p.insertBefore(b, tn);
        b.appendChild(tn);
        return;
      }
      TOK.lastIndex = 0;
      if (!TOK.test(s)) return;
      TOK.lastIndex = 0;
      //MC 2026-10-09 the holder is a <shy-bd>, not a <span>: rules like ".trust span" turned a span into a second pill
      var was = done.has(tn), box = document.createElement("shy-bd"), last = 0, m;
      box.setAttribute("data-bd", "");
      function txt(v) { var x = document.createTextNode(v); if (was) done.add(x); box.appendChild(x); }
      while ((m = TOK.exec(s))) {
        var st = m.index + m[1].length;
        if (st > last) txt(s.slice(last, st));
        box.appendChild(bdi(m[2]));
        last = st + m[2].length;
      }
      if (last < s.length) txt(s.slice(last));
      p.replaceChild(box, tn);
    });
  }

  var obs = null, busy = false;
  //MC 2026-10-09 "21h 47m", "2d 20h" and "4W · 12G" never got looked up: they have no two-letter word, so the walker treats them
  // like a plain number. A text node that is only numbers with one-letter units is now looked up on its own ("{0}h {1}m").
  // Done per text node, not in serialize(), so the keys of sentences that hold a countdown (<1/>) stay as they are.
  var UNIT = /\d[A-Za-z]\b/;
  function unitFix(top) {
    var w = document.createTreeWalker(top, NodeFilter.SHOW_TEXT), list = [], n;
    while ((n = w.nextNode())) if (!done.has(n) && UNIT.test(n.data) && !LETTER.test(n.data)) list.push(n);
    list.forEach(function (tn) {
      var p = tn.parentNode;
      if (!p || p.nodeType !== 1 || p.closest(BD_NO + ",[data-i18n-skip],[translate=no]")) return;
      var m = /^(\s*)(.*?)(\s*)$/.exec(tn.data), t = lookup(m[2].replace(/\s+/g, " "));
      if (t == null) return;
      tn.data = m[1] + t + m[3];
      done.add(tn);
    });
  }
  function run(target) {
    if (busy) return;
    busy = true;
    try { visit(target); unitFix(target); if (BIDI) bidiFix(target); if (obs) obs.takeRecords(); } finally { busy = false; }
  }
  function onMut(list) {
    if (busy) return;
    var todo = [];
    list.forEach(function (m) {
      var t = m.type === "attributes" ? m.target : blockOf(m.target);
      if (!t || t.nodeType !== 1 || todo.indexOf(t) >= 0) return;
      if (m.type === "attributes") { if (!busy) { busy = true; try { doAttrs(t); } finally { busy = false; } } return; }
      todo.push(t);
    });
    // skip anything inside another queued element
    todo.filter(function (t) { return !todo.some(function (o) { return o !== t && o.contains(t); }); }).forEach(function (t) { if (t.isConnected) run(t); });
    if (obs) obs.takeRecords();
  }
  var baseTitle = null;
  function doTitle() { if (document.title && document.title !== baseTitle) { var t = lookup(document.title.replace(/\s+/g, " ").trim()); if (t != null) document.title = t; baseTitle = document.title; } }
  // the language picker: a globe button with a list, wherever the page has [data-lang-pick]
  var GLOBE = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.9 5.8 3.9 9s-1.3 6.2-3.9 9c-2.6-2.8-3.9-5.8-3.9-9S9.4 5.8 12 3Z"/></svg>';
  function pickers() {
    var cur = LANGS.filter(function (l) { return l[0] === lang; })[0];
    document.querySelectorAll("[data-lang-pick]").forEach(function (box) {
      if (box.firstChild) return;
      box.setAttribute("data-i18n-skip", "");
      var full = box.getAttribute("data-lang-pick") === "full";
      box.innerHTML = '<button type="button" class="lp-btn" aria-haspopup="listbox" aria-expanded="false" title="Language">' + GLOBE + '<span>' + (full ? cur[1] : cur[0].toUpperCase()) + '</span></button>' +
        '<ul class="lp-list" role="listbox" hidden>' + LANGS.map(function (l) {
          return '<li role="option" aria-selected="' + (l[0] === lang) + '"><button type="button" data-lang-set="' + l[0] + '" lang="' + (HTML_LANG[l[0]] || l[0]) + '">' + l[1] + '<small>' + l[0].toUpperCase() + '</small></button></li>';
        }).join("") + '</ul>';
    });
  }
  document.addEventListener("click", function (e) {
    var set = e.target.closest && e.target.closest("[data-lang-set]");
    if (set) { e.preventDefault(); window.SHYI18N.set(set.getAttribute("data-lang-set")); return; }
    var b = e.target.closest && e.target.closest(".lp-btn");
    document.querySelectorAll(".lp-list").forEach(function (l) {
      var mine = b && l.parentNode === b.parentNode;
      l.hidden = mine ? !l.hidden : true;
      l.parentNode.querySelector(".lp-btn").setAttribute("aria-expanded", String(!l.hidden));
    });
  });
  //MC 2026-10-11 Escape also says the list is closed (aria-expanded stayed "true") and puts focus back on the button of the list that was open
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    document.querySelectorAll(".lp-list").forEach(function (l) {
      var btn = l.parentNode && l.parentNode.querySelector(".lp-btn"), was = !l.hidden;
      l.hidden = true;
      if (btn) btn.setAttribute("aria-expanded", "false");
      if (was && btn && (l.contains(document.activeElement) || document.activeElement === btn || document.activeElement === document.body)) btn.focus();
    });
  });
  function start() {
    pickers();
    if (lang === "en" && !collect) return;
    addNames((window.SHY_NAMES || []).concat([store("shy-lb-name") || ""]));
    run(document.body);
    doTitle();
    obs = new MutationObserver(onMut);
    obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
    new MutationObserver(doTitle).observe(document.querySelector("title") || document.head, { childList: true, characterData: true, subtree: true });
    root.classList.remove("i18n-wait");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();

  // ---------------------------------------------------------------- for page code
  // T("Some sentence with 3 numbers") returns it translated (or as is). Use for text that isn't on the page: posts, alerts.
  function T(s) {
    if (lang === "en" && !collect || s == null) return s;
    return String(s).split("\n").map(function (line) {
      var m = /^(\s*)(.*?)(\s*)$/.exec(line);
      if (!LETTER.test(m[2]) && !UNIT.test(m[2])) return line;   //MC 2026-10-09 "21h 47m" too, see unitFix
      var t = lookup(m[2].replace(/[ \t]+/g, " "));
      return t == null ? line : m[1] + t + m[3];
    }).join("\n");
  }
  window.SHYI18N = {
    lang: lang, langs: LANGS, T: T, addNames: addNames, locale: LOCALE,
    set: function (c) { if (CODES.indexOf(c) < 0) return; store("shy-lang", c); var u = new URL(location.href); u.searchParams.delete("lang"); location.replace(u.toString()); },
    keys: function () { return seen; }, scan: function () { run(document.body); },
    keyOf: function (txt) { var raw = String(txt).replace(/\s+/g, " ").trim(), e = ents(raw); return nums(e ? e.key : raw).key; }
  };
})();
