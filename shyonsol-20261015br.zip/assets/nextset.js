// Season cards on the cards page: the season cards already in the game, and the ballot for the next one.
// Holders see the ballot first and vote; everyone sees it once it's revealed.
(function () {
  "use strict";
  var grid = document.getElementById("ns-grid");
  if (!grid) return;
  var playBox = document.getElementById("ns-play");
  function store(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  //MC 2026-10-11 the date in the site's language (it used the browser's, so a German page could say "Nov 3")
  function day(t) { var L = (window.SHYI18N && SHYI18N.locale) || document.documentElement.lang || undefined; try { return new Date(t * 1000).toLocaleDateString(L, { month: "short", day: "numeric", timeZone: "UTC" }); } catch (e) { return new Date(t * 1000).toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" }); } }
  var me = { pid: store("shy-lb-pid"), key: store("shy-lb-key") };
  var KIND = { attack: "Attack", gain: "Gain", defense: "Defense", global: "Global", trick: "Trick", passive: "Reaction" };
  var AV = (function () { var s = document.querySelector('script[src*="nextset.js"]'); var m = s && /\?v=[^"&]+/.exec(s.getAttribute("src")); return m ? m[0] : ""; })();
  var D = null, msg = "";
  async function call(body) {
    try {
      var r = body ? await fetch("api/cardsets.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) }) : await fetch("api/cardsets.php");
      return await r.json();
    } catch (e) { return { ok: false, error: "Can't reach the server right now." }; }
  }
  function art(id) { return '<span class="ns-art"><img src="assets/cards/' + esc(id) + '.webp' + AV + '" alt="" loading="lazy"></span>'; }
  function renderPlay() {
    var live = (D.inPlay || []);
    if (!playBox) return;
    playBox.hidden = !live.length;
    if (!live.length) return;
    playBox.innerHTML = '<div class="ns-hd"><span class="eyebrow">In the game</span><h2>Season cards</h2><p class="sub">Shuffled in with the original 71 in every game: solo, the Daily, live matches and Duels.</p></div>' +
      '<div class="ns-grid ns-live">' + live.map(function (c) {
        return '<div class="ns-c k-' + esc(c.kind) + '">' + art(c.id) + '<span class="ns-kanji" aria-hidden="true">' + esc(c.kanji) + '</span><span class="ns-k">' + KIND[c.kind] + ' · Season ' + c.season + '</span><b>' + esc(c.name) + '</b><p>' + esc(c.text) + '</p>' +
          '<div class="ns-v"><span>' + (c.live ? "In play since " : "Joins ") + '<b data-i18n-skip>' + day(c.from) + '</b></span><span>' + (c.by === "vote" ? fmt(c.votes) + (c.votes === 1 ? " vote" : " votes") : "") + '</span></div></div>';
      }).join("") + '</div>';
  }
  function render() {
    if (!D || !D.ok) return;
    renderPlay();
    var hd = document.querySelector("#ns > .ns-hd");
    if (!D.set) {
      hd.innerHTML = '<span class="eyebrow">Next season</span><h2>The next ballot is on its way.</h2><p class="sub">Every candidate plays 500,000 test games before it can be voted on. The next set arrives with a site update.</p>';
      grid.innerHTML = ""; return;
    }
    var s = D.set, left = D.each - D.mine.length;
    hd.innerHTML = '<span class="eyebrow">Season ' + s.season + ' ballot · ' + (D.public ? "Open to all" : "Holders' preview") + '</span><h2 data-i18n-skip>' + esc(s.name) + '</h2><p class="sub">' + esc(s.blurb) + '</p>' +
      '<p class="ns-note">Voting closes when Season ' + s.season + ' starts on <b data-i18n-skip>' + day(s.closes) + '</b>. The card with the most votes joins the game that day.</p>' +
      (D.open ? (D.holder ? '<p class="ns-note">You have <b>' + left + '</b> of ' + D.each + ' votes left.</p>' : '<p class="ns-note">$SHY holders vote on which card makes it in.</p>') :
        '<p class="ns-note">' + s.count + ' cards, shown to $SHY holders first. <a href="/token#buy">Hold $SHY</a> and connect your wallet on <a href="/profile">your profile</a> to see them now and vote.</p>') + (msg ? '<p class="ns-msg">' + esc(msg) + '</p>' : "");
    var top = 0; (D.cards || []).forEach(function (c) { if (c.votes > top) top = c.votes; });
    grid.innerHTML = D.cards.map(function (c) {
      var mine = D.mine.indexOf(c.id) >= 0;
      if (!D.open) return '<div class="ns-c locked k-' + esc(c.kind) + '"><span class="ns-kanji" aria-hidden="true">' + esc(c.kanji) + '</span><span class="ns-k">' + KIND[c.kind] + '</span><b>Holders only</b><i class="ns-lock" aria-hidden="true">🔒</i></div>';
      return '<div class="ns-c k-' + esc(c.kind) + (mine ? " voted" : "") + (top && c.votes === top ? " leading" : "") + '">' + art(c.id) + '<span class="ns-kanji" aria-hidden="true">' + esc(c.kanji) + '</span><span class="ns-k">' + KIND[c.kind] + '</span><b>' + esc(c.name) + '</b><p>' + esc(c.text) + '</p>' +
        (c.tested ? '<span class="ns-test" title="Played ' + fmt(c.tested) + ' test games added to the original deck and stayed inside its range">✓ Balance tested</span>' : "") +
        '<div class="ns-v"><span>' + c.votes + (c.votes === 1 ? " vote" : " votes") + '</span>' + (D.holder ? '<button class="btn btn-sm ' + (mine ? "btn-mint" : "btn-line") + '" data-ns-vote="' + esc(c.id) + '"' + (!mine && left <= 0 ? " disabled" : "") + '>' + (mine ? "Voted ✓" : "Vote") + '</button>' : "") + '</div></div>';
    }).join("");
  }
  grid.addEventListener("click", async function (e) {
    var b = e.target.closest("[data-ns-vote]"); if (!b) return;
    b.disabled = true;
    var j = await call({ a: "vote", card: b.dataset.nsVote });
    if (j.ok) { D = j; msg = ""; } else msg = j.error || "That didn't work.";
    render();
  });
  (async function () { D = me.pid && me.key ? await call({ a: "view" }) : await call(null); if (!D.ok) D = await call(null); render(); })();
})();
