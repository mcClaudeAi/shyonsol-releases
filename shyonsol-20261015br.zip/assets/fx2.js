//MC 2026-10-10 The Animated set's moving parts that CSS can't do alone: the seven new victory effects (one canvas each,
//   drawn for about three seconds and then removed), the Region claim effects, the turn aura markup and the layer the
//   animated tables move on. play.js calls in here; shop.js uses the same calls for its previews.
//   Nothing runs with Reduce Motion on. Glows are drawn from one pre-made sprite instead of canvas shadowBlur, which
//   is what made full-screen effects stutter on phones.
(function () {
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var FX = { seal: 1, ink: 1, crane: 1, katana: 1, kobanburst: 1, kanji: 1, dragon: 1 };
  var TABLES = { rain: 3, festival: 3, inkmoon: 3, radar: 3, ember: 3, storm: 3 };
  var CAPS = { stamp: 2, enso: 2, petals: 8, banner: 1, thunder: 2 };
  var R = Math.random;
  function ease(t) { return 1 - Math.pow(1 - t, 3); }
  function clamp(x, a, b) { return x < a ? a : x > b ? b : x; }

  // one soft round glow, drawn once and stamped wherever a spark or a light is needed
  var GLOW = {};
  function glow(col) {
    if (GLOW[col]) return GLOW[col];
    var c = document.createElement("canvas"); c.width = c.height = 64;
    var x = c.getContext("2d"), g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.18, col); g.addColorStop(1, "rgba(0,0,0,0)");
    x.fillStyle = g; x.fillRect(0, 0, 64, 64);
    return (GLOW[col] = c);
  }
  function seal(size, glyph) {
    var c = document.createElement("canvas"); c.width = c.height = Math.ceil(size);
    var x = c.getContext("2d"), s = size, r = s * 0.12;
    x.fillStyle = "#c8102e";
    x.beginPath(); x.moveTo(r, 0); x.arcTo(s, 0, s, s, r); x.arcTo(s, s, 0, s, r); x.arcTo(0, s, 0, 0, r); x.arcTo(0, 0, s, 0, r); x.fill();
    x.strokeStyle = "#fff3e0"; x.lineWidth = s * 0.035; x.strokeRect(s * 0.1, s * 0.1, s * 0.8, s * 0.8);
    x.fillStyle = "#fff3e0"; x.font = "900 " + Math.round(s * 0.56) + "px serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText(glyph, s / 2, s * 0.53);
    // worn stamp: knock out a few flecks so it reads as ink pressed on paper
    x.globalCompositeOperation = "destination-out";
    for (var i = 0; i < 70; i++) { x.globalAlpha = 0.3 + R() * 0.5; x.beginPath(); x.arc(R() * s, R() * s, 0.5 + R() * s * 0.012, 0, 7); x.fill(); }
    return c;
  }
  function splat(rad, col) {
    var n = Math.ceil(rad * 4.2), c = document.createElement("canvas"); c.width = c.height = n;
    var x = c.getContext("2d"), m = n / 2;
    x.fillStyle = col;
    x.beginPath(); x.arc(m, m, rad, 0, 7); x.fill();
    for (var i = 0; i < 9; i++) { var a = R() * 7, d = rad * (0.7 + R() * 0.5); x.beginPath(); x.arc(m + Math.cos(a) * d, m + Math.sin(a) * d, rad * (0.25 + R() * 0.25), 0, 7); x.fill(); }
    for (var j = 0; j < 16; j++) { var b = R() * 7, e = rad * (1.3 + R() * 0.75); x.beginPath(); x.arc(m + Math.cos(b) * e, m + Math.sin(b) * e, rad * (0.04 + R() * 0.09), 0, 7); x.fill(); }
    for (var k = 0; k < 5; k++) {
      var t = R() * 7, l = rad * (1.1 + R() * 0.6);
      x.save(); x.translate(m, m); x.rotate(t); x.beginPath(); x.ellipse(l * 0.62, 0, l * 0.5, rad * 0.07, 0, 0, 7); x.fill(); x.restore();
    }
    return c;
  }
  function coinSprite(r) {
    var c = document.createElement("canvas"); c.width = Math.ceil(r * 1.6) + 4; c.height = Math.ceil(r * 2.2) + 4;
    var x = c.getContext("2d"), cx = c.width / 2, cy = c.height / 2;
    x.fillStyle = "#a8741e"; x.beginPath(); x.ellipse(cx, cy, r * 0.78, r * 1.08, 0, 0, 7); x.fill();
    var g = x.createLinearGradient(0, 0, c.width, c.height); g.addColorStop(0, "#fff0b0"); g.addColorStop(0.45, "#f2c35b"); g.addColorStop(1, "#c8902e");
    x.fillStyle = g; x.beginPath(); x.ellipse(cx, cy, r * 0.68, r * 0.98, 0, 0, 7); x.fill();
    x.strokeStyle = "rgba(140,90,20,.55)"; x.lineWidth = Math.max(1, r * 0.06);
    for (var i = -2; i <= 2; i++) { x.beginPath(); x.moveTo(cx - r * 0.5, cy + i * r * 0.32); x.lineTo(cx + r * 0.5, cy + i * r * 0.32); x.stroke(); }
    x.fillStyle = "#7a4a10"; x.font = "900 " + Math.round(r * 0.7) + "px serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText("壱", cx, cy);
    return c;
  }
  function glyphPoints(ch, size, max) {
    var c = document.createElement("canvas"), n = 160; c.width = c.height = n;
    var x = c.getContext("2d"); x.fillStyle = "#000"; x.font = "900 140px serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText(ch, n / 2, n / 2 + 6);
    var d = x.getImageData(0, 0, n, n).data, pts = [];
    for (var y = 0; y < n; y += 4) for (var xx = 0; xx < n; xx += 4) if (d[(y * n + xx) * 4 + 3] > 140) pts.push([(xx - n / 2) / n * size, (y - n / 2) / n * size]);
    while (pts.length > max) pts.splice(Math.floor(R() * pts.length), 1);
    if (pts.length < 40) { pts = []; for (var i = 0; i < max; i++) { var a = i / max * Math.PI * 2; pts.push([Math.cos(a) * size * 0.4, Math.sin(a) * size * 0.4]); } }
    return pts;
  }

  // ---------------------------------------------------------------- victory effects
  function run(kind, hook) {
    if (reduce || !FX[kind]) return false;
    hook = hook || {};
    var sfx = hook.sfx || function () {}, buzz = hook.buzz || function () {};
    var cv = document.createElement("canvas");
    cv.className = "g-confetti fx2";
    document.body.appendChild(cv);
    var dpr = Math.min(2, window.devicePixelRatio || 1), W = window.innerWidth, H = window.innerHeight, M = Math.min(W, H);
    cv.width = W * dpr; cv.height = H * dpr;
    var ctx = cv.getContext("2d"); ctx.scale(dpr, dpr);
    var LIFE = kind === "dragon" ? 4200 : kind === "kanji" ? 3900 : 3400, t0 = performance.now(), S = {};
    var shake = function () { var el = hook.root; if (!el) return; el.classList.remove("fx2-shake"); void el.offsetWidth; el.classList.add("fx2-shake"); setTimeout(function () { el.classList.remove("fx2-shake"); }, 450); };

    if (kind === "seal") {
      S.img = seal(M * 0.34, "勝"); S.bits = []; S.hit = false;
    } else if (kind === "ink") {
      S.sp = [];
      for (var i = 0; i < 6; i++) S.sp.push({ at: i * 170 + R() * 80, x: W * (0.15 + R() * 0.7), y: H * (0.2 + R() * 0.55), r: M * (0.05 + R() * 0.06), img: null, red: i === 3, drips: [R() * 0.6 - 0.3, R() * 0.6 - 0.3], dl: 0.4 + R() * 0.8 });
    } else if (kind === "crane") {
      S.c = [];
      for (var j = 0; j < 15; j++) {
        var row = j % 5, lead = Math.floor(j / 5);
        S.c.push({ x: -120 - row * 70 - lead * 260 - R() * 40, y: H * (0.22 + lead * 0.2) + (row % 2 ? 1 : -1) * row * 16 + R() * 20, s: M * (0.035 + R() * 0.025), v: W / 1500 * (0.8 + R() * 0.35), ph: R() * 6,
          col: j === 7 ? "#ffd166" : j % 4 === 0 ? "#ff5d73" : "#fff8ec" });
      }
    } else if (kind === "katana") {
      S.sl = []; S.sh = [];
      for (var k = 0; k < 3; k++) { var a = (-0.6 + R() * 0.25) * (k % 2 ? -1 : 1) + (k === 2 ? 0 : 0); var cx = W * (0.35 + R() * 0.3), cy = H * (0.35 + R() * 0.3), L = Math.hypot(W, H);
        S.sl.push({ at: 120 + k * 360, x1: cx - Math.cos(a) * L / 2, y1: cy - Math.sin(a) * L / 2, x2: cx + Math.cos(a) * L / 2, y2: cy + Math.sin(a) * L / 2, done: false }); }
      S.kan = seal(M * 0.3, "斬");
    } else if (kind === "kobanburst") {
      S.spr = [coinSprite(M * 0.04), coinSprite(M * 0.03)]; S.co = []; S.sp = [];
      for (var m = 0; m < 70; m++) { var an = R() * Math.PI * 2, spd = M * (0.01 + R() * 0.018); S.co.push({ x: W / 2, y: H * 0.45, vx: Math.cos(an) * spd, vy: Math.sin(an) * spd - M * 0.012, spin: R() * 6, vs: 0.1 + R() * 0.2, big: R() < 0.4 }); }
      for (var q = 0; q < 40; q++) S.sp.push({ x: W * R(), y: H * R() * 0.8, ph: R() * 6, s: 6 + R() * 10 });
    } else if (kind === "kanji") {
      var gl = ["勝", "天", "覇"][Math.floor(R() * 3)], size = M * 0.62;
      S.pts = glyphPoints(gl, size, W < 600 ? 220 : 320);
      S.cx = W / 2; S.cy = H * 0.42;
      S.p = S.pts.map(function (pt) { return { tx: S.cx + pt[0], ty: S.cy + pt[1], x: S.cx, y: S.cy, sx: 0, sy: 0, vy: 0, c: R() < 0.2 ? "#ff6fd8" : R() < 0.5 ? "#ffd166" : "#fff3c4" }; });
      S.side = [];
      [[0.18, 0.3, 500], [0.82, 0.26, 900], [0.25, 0.62, 1500], [0.78, 0.6, 1900]].forEach(function (b) {
        var parts = []; for (var z = 0; z < 50; z++) { var aa = R() * 7, ss = M * (0.002 + R() * 0.006); parts.push({ vx: Math.cos(aa) * ss, vy: Math.sin(aa) * ss }); }
        S.side.push({ x: W * b[0], y: H * b[1], at: b[2], parts: parts, c: R() < 0.5 ? "#4cc9f0" : "#ff5d73" });
      });
    } else if (kind === "dragon") {
      S.n = 46; S.cl = [];
      for (var u = 0; u < 7; u++) S.cl.push({ x: W * (u / 6) + (R() - 0.5) * 60, y: H * (0.86 + R() * 0.1), r: M * (0.06 + R() * 0.05), v: (R() - 0.5) * 0.3 });
      S.sp = [];
    }

    function dragonAt(p) {
      var x = -0.15 * W + p * 1.3 * W, y = H * 1.15 - p * H * 1.35;
      return [x + Math.sin(p * Math.PI * 5) * M * 0.08, y + Math.cos(p * Math.PI * 5) * M * 0.12];
    }
    function cloud(x, y, r, a) {
      ctx.globalAlpha = a; ctx.fillStyle = "#efe3c8";
      ctx.beginPath(); ctx.arc(x, y, r, Math.PI, 0); ctx.arc(x + r * 1.1, y + r * 0.1, r * 0.7, Math.PI, 0); ctx.arc(x - r * 1.05, y + r * 0.15, r * 0.6, Math.PI, 0); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#c8102e"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y - r * 0.15, r * 0.45, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke();
    }

    var last = t0;
    (function step(t) {
      var k = Math.min(4, Math.max(0.2, (t - last) / 16.7)); last = t;
      var el = t - t0, fade = el > LIFE - 500 ? Math.max(0, (LIFE - el) / 500) : 1;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.globalAlpha = fade;

      if (kind === "seal") {
        var p = clamp(el / 280, 0, 1), sc = 3.2 - 2.2 * (p * p), rot = (-20 + 13 * p) * Math.PI / 180, sz = S.img.width;
        if (p >= 1 && !S.hit) {
          S.hit = true; sfx("hit"); buzz([30, 30, 50]); shake();
          for (var i = 0; i < 46; i++) { var a = R() * 7, s = M * (0.004 + R() * 0.014); S.bits.push({ x: W / 2 + Math.cos(a) * sz * 0.45, y: H * 0.42 + Math.sin(a) * sz * 0.45, vx: Math.cos(a) * s, vy: Math.sin(a) * s, r: 1.5 + R() * 4, c: R() < 0.7 ? "#c8102e" : "#110b08" }); }
        }
        if (S.hit) {
          var ring = clamp((el - 280) / 520, 0, 1);
          ctx.save(); ctx.globalAlpha = fade * (1 - ring) * 0.8; ctx.strokeStyle = "#c8102e"; ctx.lineWidth = 6 * (1 - ring) + 1;
          ctx.beginPath(); ctx.arc(W / 2, H * 0.42, sz * (0.6 + ring * 1.2), 0, 7); ctx.stroke(); ctx.restore();
          S.bits.forEach(function (b) { b.x += b.vx * k; b.y += b.vy * k; b.vx *= Math.pow(0.93, k); b.vy *= Math.pow(0.93, k); ctx.fillStyle = b.c; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.fill(); });
        }
        ctx.save(); ctx.translate(W / 2, H * 0.42); ctx.rotate(rot); ctx.scale(sc, sc);
        ctx.globalAlpha = fade * clamp(el / 120, 0, 1);
        ctx.shadowColor = "rgba(0,0,0,.45)"; ctx.shadowBlur = S.hit ? 0 : 20;
        ctx.drawImage(S.img, -sz / 2, -sz / 2); ctx.restore();
      } else if (kind === "ink") {
        S.sp.forEach(function (s, i) {
          var a = el - s.at; if (a < 0) return;
          if (!s.img) { s.img = splat(s.r, s.red ? "#c8102e" : "rgba(17,11,8,.94)"); if (i % 2 === 0) sfx("hit"); if (i === 0) buzz(25); }
          var g = 0.25 + 0.75 * ease(clamp(a / 260, 0, 1)) + (a < 320 ? Math.sin(clamp(a / 320, 0, 1) * Math.PI) * 0.08 : 0), w = s.img.width * g;
          ctx.drawImage(s.img, s.x - w / 2, s.y - w / 2, w, w);
          var dl = clamp((a - 300) / 1600, 0, 1) * s.dl * M * 0.25;
          if (dl > 0) {
            ctx.strokeStyle = s.red ? "#c8102e" : "rgba(17,11,8,.94)"; ctx.lineCap = "round";
            s.drips.forEach(function (o) { var x = s.x + o * s.r; ctx.lineWidth = s.r * 0.16; ctx.beginPath(); ctx.moveTo(x, s.y); ctx.lineTo(x, s.y + s.r * 0.8 + dl); ctx.stroke(); ctx.beginPath(); ctx.fillStyle = ctx.strokeStyle; ctx.arc(x, s.y + s.r * 0.8 + dl, s.r * 0.13, 0, 7); ctx.fill(); });
          }
        });
      } else if (kind === "crane") {
        S.c.forEach(function (c) {
          c.x += c.v * 16.7 * k * 0.9; var y = c.y + Math.sin(el / 500 + c.ph) * 10 - el * 0.01, f = Math.sin(el / 120 + c.ph);
          ctx.save(); ctx.translate(c.x, y); ctx.scale(c.s / 20, c.s / 20);
          ctx.fillStyle = c.col; ctx.strokeStyle = "rgba(120,20,30,.55)"; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.moveTo(-26, 2); ctx.lineTo(0, -2); ctx.lineTo(28, -8); ctx.lineTo(10, 4); ctx.lineTo(-6, 8); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(4, -30 * f); ctx.lineTo(10, 0); ctx.closePath(); ctx.globalAlpha = fade * 0.95; ctx.fill(); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(-4, 4); ctx.lineTo(2, 22 * f + 6); ctx.lineTo(8, 4); ctx.closePath(); ctx.globalAlpha = fade * 0.75; ctx.fill(); ctx.stroke();
          ctx.globalAlpha = fade; ctx.fillStyle = "#c8102e"; ctx.beginPath(); ctx.moveTo(28, -8); ctx.lineTo(34, -6); ctx.lineTo(27, -5); ctx.fill();
          ctx.restore();
        });
      } else if (kind === "katana") {
        S.sl.forEach(function (s, i) {
          var a = el - s.at; if (a < 0) return;
          if (!s.done) { s.done = true; sfx("hit"); buzz(30); if (i === 2) shake();
            for (var q = 0; q < 26; q++) { var u = R(), px = s.x1 + (s.x2 - s.x1) * (0.2 + u * 0.6), py = s.y1 + (s.y2 - s.y1) * (0.2 + u * 0.6); S.sh.push({ x: px, y: py, vx: (R() - 0.5) * 6, vy: -R() * 5, r: R() * 6, w: 4 + R() * 8, c: R() < 0.5 ? "#c8102e" : "#fff3e0" }); } }
          var g = clamp(a / 110, 0, 1), life = 1 - clamp((a - 160) / 600, 0, 1);
          if (life <= 0) return;
          var xe = s.x1 + (s.x2 - s.x1) * g, ye = s.y1 + (s.y2 - s.y1) * g;
          if (a < 90) { ctx.fillStyle = "rgba(255,255,255," + (0.18 * (1 - a / 90)) + ")"; ctx.fillRect(0, 0, W, H); }
          ctx.lineCap = "round";
          ctx.globalAlpha = fade * life * 0.45; ctx.strokeStyle = "#9fd0ff"; ctx.lineWidth = 14 * life; ctx.beginPath(); ctx.moveTo(s.x1, s.y1); ctx.lineTo(xe, ye); ctx.stroke();
          ctx.globalAlpha = fade * life; ctx.strokeStyle = "#fff"; ctx.lineWidth = 3.5 * life + 0.5; ctx.beginPath(); ctx.moveTo(s.x1, s.y1); ctx.lineTo(xe, ye); ctx.stroke();
        });
        ctx.globalAlpha = fade;
        S.sh.forEach(function (b) { b.vy += 0.22 * k; b.x += b.vx * k; b.y += b.vy * k; b.r += 0.08 * k; ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.r); ctx.fillStyle = b.c; ctx.fillRect(-b.w / 2, -b.w / 4, b.w, b.w / 2); ctx.restore(); });
        var ka = clamp((el - 1150) / 300, 0, 1);
        if (ka > 0) { var ksz = S.kan.width, kscale = 1.4 - 0.4 * ease(ka); ctx.save(); ctx.globalAlpha = fade * ka; ctx.translate(W / 2, H * 0.42); ctx.rotate(-0.12); ctx.scale(kscale, kscale); ctx.drawImage(S.kan, -ksz / 2, -ksz / 2); ctx.restore(); }
      } else if (kind === "kobanburst") {
        if (el < 400) { var fr = el / 400; ctx.globalAlpha = fade * (1 - fr); var gg = glow("rgba(255,214,107,.9)"), gs = M * (0.3 + fr * 0.9); ctx.drawImage(gg, W / 2 - gs / 2, H * 0.45 - gs / 2, gs, gs); ctx.globalAlpha = fade; }
        if (!S.snd) { S.snd = 1; sfx("badge"); buzz(20); }
        S.sp.forEach(function (s) { var tw = 0.5 + 0.5 * Math.sin(el / 160 + s.ph); ctx.globalAlpha = fade * tw * clamp(el / 500, 0, 1); var gi = glow("rgba(255,226,154,.9)"); ctx.drawImage(gi, s.x - s.s, s.y - s.s, s.s * 2, s.s * 2); });
        ctx.globalAlpha = fade;
        S.co.forEach(function (c) {
          c.vy += M * 0.0006 * k; c.x += c.vx * k; c.y += c.vy * k; c.vx *= Math.pow(0.99, k); c.spin += c.vs * k;
          var sp = S.spr[c.big ? 0 : 1], sx = Math.abs(Math.cos(c.spin)) * 0.85 + 0.15;
          ctx.save(); ctx.translate(c.x, c.y); ctx.scale(sx, 1); ctx.drawImage(sp, -sp.width / 2, -sp.height / 2); ctx.restore();
        });
      } else if (kind === "kanji") {
        var B = 650, HOLD = 2500;
        if (el < B) {
          var rp = ease(el / B), ry = H * 1.02 - (H * 1.02 - S.cy) * rp;
          ctx.globalAlpha = fade; var gr = glow("rgba(255,209,102,.9)"); ctx.drawImage(gr, S.cx - 10, ry - 10, 20, 20);
          ctx.strokeStyle = "rgba(255,209,102,.5)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(S.cx, ry); ctx.lineTo(S.cx, ry + 60); ctx.stroke();
        } else {
          if (!S.boom) { S.boom = 1; sfx("badge"); buzz([20, 40, 20]); }
          var cp = ease(clamp((el - B) / 700, 0, 1));
          S.p.forEach(function (q) {
            if (el < HOLD) { q.x = S.cx + (q.tx - S.cx) * cp + Math.sin(el / 90 + q.tx) * (1 - cp) * 20; q.y = S.cy + (q.ty - S.cy) * cp; }
            else { q.vy += 0.12 * k; q.y += q.vy * k; q.x += Math.sin(q.ty) * 0.4 * k; }
            var tw = el > B + 700 && el < HOLD ? 0.75 + 0.25 * Math.sin(el / 120 + q.tx) : 1, sz2 = (el < HOLD ? 7 : 5) * tw;
            ctx.globalAlpha = fade * tw; ctx.drawImage(glow(q.c), q.x - sz2, q.y - sz2, sz2 * 2, sz2 * 2);
          });
        }
        S.side.forEach(function (s) {
          var a = el - s.at; if (a < 0 || a > 1400) return;
          var lf = 1 - a / 1400;
          s.parts.forEach(function (pp) { var x = s.x + pp.vx * a, y = s.y + pp.vy * a + 0.00012 * a * a; ctx.globalAlpha = fade * lf; ctx.drawImage(glow(s.c), x - 4, y - 4, 8, 8); });
        });
      } else if (kind === "dragon") {
        var dp = clamp(el / (LIFE - 700), 0, 1.25);
        S.cl.forEach(function (c) { c.x += c.v * k; cloud(c.x, c.y, c.r, fade * 0.9 * clamp(el / 400, 0, 1)); });
        ctx.globalAlpha = fade;
        if (!S.roar && dp > 0.12) { S.roar = 1; sfx("win"); buzz([40, 30, 40]); }
        for (var n = S.n; n >= 0; n--) {
          var pq = dp - n * 0.0105; if (pq < -0.05) continue;
          var pos = dragonAt(pq), nxt = dragonAt(pq + 0.01), ang = Math.atan2(nxt[1] - pos[1], nxt[0] - pos[0]);
          var rr = M * 0.045 * (1 - n / (S.n + 12)) + 3;
          if (n === 0) {
            ctx.save(); ctx.translate(pos[0], pos[1]); ctx.rotate(ang);
            ctx.fillStyle = "#c8102e"; ctx.beginPath(); ctx.moveTo(rr * 2.2, 0); ctx.quadraticCurveTo(rr * 1.2, -rr * 1.3, -rr * 0.6, -rr * 1.1); ctx.lineTo(-rr * 0.6, rr * 1.1); ctx.quadraticCurveTo(rr * 1.2, rr * 1.3, rr * 2.2, 0); ctx.fill();
            ctx.strokeStyle = "#f2c35b"; ctx.lineWidth = 2; ctx.stroke();
            ctx.strokeStyle = "#f2c35b"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-rr * 0.2, -rr * 0.8); ctx.lineTo(-rr * 1.4, -rr * 1.9); ctx.moveTo(-rr * 0.2, rr * 0.8); ctx.lineTo(-rr * 1.4, rr * 1.9); ctx.stroke();
            ctx.strokeStyle = "#ffe29a"; ctx.lineWidth = 1.5; var wv = Math.sin(el / 140) * rr * 0.5;
            ctx.beginPath(); ctx.moveTo(rr * 1.8, -rr * 0.4); ctx.bezierCurveTo(rr * 2.8, -rr * 1.2 + wv, rr * 3.4, -rr * 0.2, rr * 4.2, -rr * 1 - wv); ctx.moveTo(rr * 1.8, rr * 0.4); ctx.bezierCurveTo(rr * 2.8, rr * 1.2 - wv, rr * 3.4, rr * 0.2, rr * 4.2, rr * 1 + wv); ctx.stroke();
            ctx.fillStyle = "#fff8e6"; ctx.beginPath(); ctx.arc(rr * 0.9, -rr * 0.45, rr * 0.22, 0, 7); ctx.fill(); ctx.fillStyle = "#110b08"; ctx.beginPath(); ctx.arc(rr * 0.95, -rr * 0.45, rr * 0.1, 0, 7); ctx.fill();
            ctx.restore();
            if (R() < 0.6) S.sp.push({ x: pos[0], y: pos[1], vx: (R() - 0.5) * 2, vy: R() * 1.5, l: 1 });
          } else {
            ctx.fillStyle = n % 2 ? "#c8102e" : "#b00d28"; ctx.beginPath(); ctx.arc(pos[0], pos[1], rr, 0, 7); ctx.fill();
            ctx.strokeStyle = "#f2c35b"; ctx.lineWidth = Math.max(1, rr * 0.12); ctx.beginPath(); ctx.arc(pos[0], pos[1], rr * 0.7, ang + 2.2, ang + 4.1); ctx.stroke();
            if (n % 4 === 1) { ctx.save(); ctx.translate(pos[0], pos[1]); ctx.rotate(ang); ctx.fillStyle = "#f2c35b"; ctx.beginPath(); ctx.moveTo(-rr * 0.5, -rr * 0.85); ctx.lineTo(0, -rr * 1.7); ctx.lineTo(rr * 0.5, -rr * 0.85); ctx.fill(); ctx.restore(); }
            if (n === S.n) { ctx.save(); ctx.translate(pos[0], pos[1]); ctx.rotate(ang); ctx.fillStyle = "#f2c35b"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-rr * 3, -rr * 1.8); ctx.lineTo(-rr * 2.2, 0); ctx.lineTo(-rr * 3, rr * 1.8); ctx.fill(); ctx.restore(); }
          }
        }
        S.sp = S.sp.filter(function (s) { s.l -= 0.025 * k; s.x += s.vx * k; s.y += s.vy * k; if (s.l <= 0) return false; ctx.globalAlpha = fade * s.l; ctx.drawImage(glow("rgba(255,209,102,.9)"), s.x - 6, s.y - 6, 12, 12); return true; });
      }
      ctx.globalAlpha = 1;
      if (el < LIFE) requestAnimationFrame(step); else cv.remove();
    })(t0);
    return true;
  }

  // ---------------------------------------------------------------- the animated table layer
  function table(root, k) {
    if (!root) return;
    var on = !!TABLES[k], cur = root.querySelector(":scope > .tbfx");
    root.classList.toggle("tbx", on);
    if (!on) { if (cur) cur.remove(); return; }
    if (cur && cur.dataset.k === k) return;
    if (cur) cur.remove();
    var d = document.createElement("div");
    d.className = "tbfx"; d.dataset.k = k; d.setAttribute("aria-hidden", "true");
    d.innerHTML = new Array(TABLES[k] + 1).join("<i></i>");
    root.insertBefore(d, root.firstChild);
  }
  function tableHTML(k) { return TABLES[k] ? '<div class="tbfx" aria-hidden="true">' + new Array(TABLES[k] + 1).join("<i></i>") + '</div>' : ""; }

  // ---------------------------------------------------------------- Region claim effects
  // drawn on the table itself (root), over the spot where el is, so a redraw of the seat can't cut it short
  function capHTML(k, cls) { return CAPS[k] ? '<span class="capfx cap-' + k + (cls ? " " + cls : "") + '" aria-hidden="true">' + new Array(CAPS[k] + 1).join("<i></i>") + '</span>' : ""; }
  function cap(root, el, k) {
    if (reduce || !CAPS[k] || !root || !el) return false;
    var rr = root.getBoundingClientRect(), er = el.getBoundingClientRect();
    if (!er.width) return false;
    var w = document.createElement("span");
    w.style.cssText = "position:absolute;z-index:8;pointer-events:none;width:0;height:0;left:" + (er.left - rr.left + root.scrollLeft + er.width / 2) + "px;top:" + (er.top - rr.top + root.scrollTop + er.height / 2) + "px";
    w.innerHTML = capHTML(k, "go");
    root.appendChild(w);
    setTimeout(function () { w.remove(); }, 1800);
    return true;
  }
  // ---------------------------------------------------------------- turn auras
  function turnHTML(k) { return k ? '<i class="tu-fx tu-' + k + '" aria-hidden="true"><b></b><b></b><s></s><s></s></i>' : ""; }

  window.ShyFx2 = { has: function (k) { return !!FX[k]; }, run: run, table: table, tableHTML: tableHTML, animTable: function (k) { return !!TABLES[k]; }, cap: cap, capHTML: capHTML, turnHTML: turnHTML };
})();
