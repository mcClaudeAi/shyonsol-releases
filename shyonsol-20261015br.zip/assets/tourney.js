// Shilluminati Online tournaments on the Play page: the start-screen card (sign up, check in, take your seat)
// and the Tournament hall further down (timeline, countdown, prizes, who's in, the live bracket and the rules).
(function () {
  "use strict";
  var P = window.ShyPlay, el = document.getElementById("g-tourney"), hall = document.getElementById("tourney-body");
  if (!P || (!el && !hall)) return;
  var API = "api/tournament.php", T = null, skew = 0, timer = 0, msg = "", busy = false, lastSeat = "", lastEnd = null, loaded = false;
  var keyCard = "", keyHall = "", hl = "", rulesOpen = false, open = {};
  var esc = P.esc;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  try { rulesOpen = localStorage.getItem("shy-tr-rules") === "1"; } catch (e) {}
  function now() { return Date.now() / 1000 + skew; }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function left(ts) {
    var s = Math.max(0, Math.floor(ts - now())), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    if (d) return d + "d " + h + "h";
    if (h) return h + "h " + m + "m";
    return m + ":" + (x < 10 ? "0" : "") + x;
  }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function clock(ts) {
    var s = Math.max(0, Math.floor(ts - now())), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return d ? d + "d " + pad(h) + "h" : h ? h + ":" + pad(m) + ":" + pad(x) : pad(m) + ":" + pad(x);
  }
  function when(ts) {
    var L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined;   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
    try { return new Date(ts * 1000).toLocaleString(L, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }); } catch (e) { return new Date(ts * 1000).toString(); }
  }
  function koban(n) { return '<span class="kb"><i class="kb-coin" aria-hidden="true"></i>' + fmt(n) + '</span>'; }
  async function call(body) {
    try {
      var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: P.me.pid, key: P.me.key }, body)) });
      return await r.json();
    } catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  async function load() {
    var j = await call({ a: "me" });
    if (j.ok) {
      T = j.t;
      if (T) {
        skew = T.now - Date.now() / 1000;
        // the tournament's name and the players in it are names, never translated
        if (window.SHYI18N && SHYI18N.addNames) {
          var nm = [T.name].concat(T.places || []); if (T.next) nm.push(T.next.name);
          (T.rounds || []).forEach(function (r) { r.forEach(function (tb) { nm = nm.concat(tb.seats); }); });
          (T.roster || []).forEach(function (p) { nm.push(p.n); });
          SHYI18N.addNames(nm);
        }
      }
      draw(); seatCheck();
    } else if (!loaded) draw();
    loaded = true;
    schedule();
  }
  function schedule() {
    clearTimeout(timer);
    var fast = T && (T.status === "running" || (T.status === "signup" && now() > T.start - 2100));
    var mine = T && T.you && T.you.joined;
    timer = setTimeout(load, fast ? (mine ? 5000 : 12000) : 30000);
  }
  // players per round: tables of up to 4, one moves on from each, until 4 or fewer play the final table
  function roundsFor(n) { var r = [], x = Math.max(n, 2); while (true) { r.push(x); if (x <= 4) break; x = Math.ceil(x / 4); } return r; }
  function isFinal(r, i) { return r.length === 1 && (i > 0 || T.rounds.length === 1); }
  function playersIn() { return T.rounds.length ? T.rounds[T.rounds.length - 1].reduce(function (t, tb) { return t + tb.seats.length; }, 0) : 0; }
  // every round: the ones played, then the ones still to come (projected from who's in)
  function plan() {
    var out = [], real = T.rounds || [];
    real.forEach(function (r, i) { out.push({ lab: isFinal(r, i) ? "Final table" : "Round " + (i + 1), tables: r.length, real: r }); });
    var ahead = [];
    if (T.status === "signup") ahead = roundsFor(T.checkinOpen ? T.checkedIn : T.count);
    else if (T.status === "running") { var c = real[real.length - 1]; if (c && c.length > 1) ahead = roundsFor(c.length); }
    ahead.forEach(function (n) {
      var tables = Math.ceil(n / 4), per = [];
      for (var t = 0; t < tables; t++) per.push(Math.floor(n / tables) + (t < n % tables ? 1 : 0));
      out.push({ lab: tables === 1 ? "Final table" : "Round " + (out.length + 1), tables: tables, ghost: per });
    });
    return out;
  }

  // the action for this player right now, shared by the card and the hall
  function action() {
    var y = T.you || { joined: false }, act = "";
    if (T.status === "signup") {
      if (!y.joined) {
        //MC 2026-10-13 a paid event says its price on the button; the checkout opens if the entry isn't bought yet
        var joinLab = T.fee > 0 ? (T.checkinOpen ? "Sign up and check in" : "Sign up") + " · " + fmt(T.fee) + " $SHY" : (T.checkinOpen ? "Sign up and check in" : "Sign up free");
        act = (!P.name() ? '<input class="gt-name" maxlength="20" placeholder="Pick your player name" autocomplete="nickname" data-gt-name>' : "") +
          '<button class="btn btn-gold" data-t="join">' + joinLab + '</button>' +
          (T.checkinOpen ? "" : '<small class="gt-hint">Then check in during the last 30 minutes before the start to keep your spot.</small>') +
          (T.fee > 0 ? '<small class="gt-hint">The entry is paid in $SHY and refunded in full if the event is called off.</small>' : "");
      } else if (!y["in"] && T.checkinOpen) {
        act = '<button class="btn btn-gold gt-pulse" data-t="checkin">Check in now</button><small class="gt-hint">Players who aren\'t checked in at the start lose their spot.</small>';
      } else if (!y["in"]) {
        act = '<span class="gt-ok">You\'re signed up.</span><small class="gt-hint">Check in from <span data-i18n-skip>' + esc(when(T.checkin)) + '</span>, 30 minutes before the start.</small><button class="btn btn-line btn-sm gt-leave" data-t="leave">Back out</button>';
      } else {
        act = '<span class="gt-ok">You\'re checked in.</span><small class="gt-hint">Stay on the Play page: your table opens right at the start and you\'re seated automatically.</small><button class="btn btn-line btn-sm gt-leave" data-t="leave">Back out</button>';
      }
    } else if (T.status === "running") {
      var final = (T.rounds[T.rounds.length - 1] || []).length === 1;
      if (y.table) act = '<button class="btn btn-gold gt-pulse" data-t="seat">' + (final ? "Take my seat at the final table" : "Take my seat, round " + y.table.round) + '</button><small class="gt-hint">It starts when everyone is there, or after about 2 minutes. If you\'re late, a bot plays for you until you take your seat.</small>';
      else if (y.joined && y.out === null) act = '<span class="gt-ok">You\'re through. Your next table opens when this round ends.</span>';
      else if (y.joined && y.out === -1) act = '<span class="gt-out">You didn\'t check in, so you\'re watching this one.</span>';
      else if (y.joined) act = '<span class="gt-out">You\'re out after ' + (y.out === 0 ? "round 1" : "round " + (y.out + 1)) + '. Good game.</span>';
      else act = '<small class="gt-hint">Sign-ups are closed. Follow the bracket.</small>';
    } else {
      act = (y.place ? '<span class="gt-ok">You finished #' + y.place + '.</span>' : "") + nextLine();
    }
    return act;
  }
  function nextLine() {
    return T.next ? '<small class="gt-hint">Next: <span data-i18n-skip>' + esc(T.next.name) + ', ' + esc(when(T.next.start)) + '</span>.</small>' +
      (!P.name() ? '<input class="gt-name" maxlength="20" placeholder="Pick your player name" autocomplete="nickname" data-gt-name>' : "") +
      '<button class="btn btn-gold" data-t="join" data-id="' + esc(T.next.id) + '">Sign up for the next one</button>' : "";
  }
  // holder-only and joint events: who can join, and the partner community's banner
  function gateH() {
    if (!T.gate) return "";
    if (T.gate === "partner" && T.partner) {
      var pt = T.partner, logo = /^https:\/\//.test(pt.logo || "") ? '<img src="' + esc(pt.logo) + '" alt="" loading="lazy" referrerpolicy="no-referrer">' : "";
      return '<div class="tr-gate partner">' + logo + '<div><b>A joint event with <span data-i18n-skip>' + esc(pt.name) + '</span></b><small>Open to $SHY holders and <span data-i18n-skip>' + esc(pt.sym || pt.name) + '</span> holders' + (pt.min ? ' (' + fmt(pt.min) + ' or more)' : "") + '. Sign up with the wallet you connected on your profile.</small></div>' +
        (/^https:\/\//.test(pt.url || "") ? '<a href="' + esc(pt.url) + '" target="_blank" rel="noopener">Meet them ↗</a>' : "") + '</div>';
    }
    return '<div class="tr-gate"><span aria-hidden="true">💎</span><div><b>' + esc(T.gateLabel) + '</b><small>Connect the wallet that holds your $SHY on <a href="/profile">your profile</a> to sign up.</small></div></div>';
  }
  function headline() {
    if (T.status === "signup") return T.checkinOpen ? 'Check-in is open. Starts in <span data-tcount="' + T.start + '">' + left(T.start) + '</span>' : 'Starts in <span data-tcount="' + T.start + '">' + left(T.start) + '</span>';
    if (T.status === "running") { var cur = T.rounds[T.rounds.length - 1] || []; return (cur.length === 1 ? "Final table" : "Round " + (T.round + 1)) + " is on"; }
    if (T.status === "done") return T.champ ? '<span data-i18n-skip>' + esc(T.champ) + '</span> won' : "Tournament over";
    return "Called off";
  }
  function keepName(box, fn) {
    var i = box.querySelector("[data-gt-name]"), typed = i ? i.value : "";
    fn();
    var n = box.querySelector("[data-gt-name]"); if (n && typed) n.value = typed;
  }

  // ---------- the card on the start screen: what to do now, then a link down to the hall ----------
  function drawCard() {
    if (!el) return;
    if (!T) { el.hidden = true; return; }
    el.hidden = false;
    var k = JSON.stringify([T.id, T.status, T.checkinOpen, T.count, T.checkedIn, T.round, T.rounds.length && playersIn(), T.champ, T.you, msg, P.name() ? 1 : 0, T.next && T.next.id]);
    if (k === keyCard) return;
    keyCard = k;
    var sub = T.status === "running" ? fmt(playersIn()) + (playersIn() === 1 ? " player still in" : " players still in") :
      fmt(T.count) + (T.count === 1 ? " player signed up" : " players signed up") + (T.status === "signup" && T.checkinOpen ? ", " + fmt(T.checkedIn) + " checked in" : "");
    keepName(el, function () {
      el.innerHTML = '<div class="gt-head"><span class="g-mode-k"><i class="gt-flag" aria-hidden="true"></i>Tournament</span><b data-i18n-skip>' + esc(T.name) + '</b><small>' + sub + '</small></div>' +
        '<div class="gt-st"><b class="gt-clock">' + headline() + '</b>' + (T.status === "signup" ? '<small class="gt-when" data-i18n-skip>' + esc(when(T.start)) + '</small>' : "") + '</div>' +
        '<div class="gt-act">' + action() + '</div>' + (msg ? '<p class="gt-msg">' + esc(msg) + '</p>' : "") +
        '<a class="gt-hall-link" href="#tourney">Bracket, prizes and rules</a>';
    });
  }

  // ---------- the hall ----------
  function phases(pl) {
    var list = [["Sign up", T.status === "signup" && !T.checkinOpen ? "Open now" : "Closed"], ["Check in", T.checkinOpen ? "Open now" : "Last 30 min"]];
    pl.forEach(function (r) { list.push([r.lab, r.tables === 1 ? "1 table" : r.tables + " tables"]); });
    list.push(["Prizes", T.status === "done" ? "Paid" : "Instant"]);
    var cur = T.status === "signup" ? (T.checkinOpen ? 1 : 0) : T.status === "running" ? 2 + T.round : T.status === "done" ? list.length - 1 : -1;
    return { list: list, cur: cur };
  }
  function ring() {
    // how far through the current stage we are; the clock in the middle counts down to the next one
    var c = 2 * Math.PI * 54, f = 0, label = "", target = 0;
    if (T.status === "signup" && !T.checkinOpen) { target = T.checkin; f = 1 - Math.min(1, (T.checkin - now()) / (7 * 86400)); label = "until check-in"; }
    else if (T.status === "signup") { target = T.start; f = 1 - Math.min(1, (T.start - now()) / 1800); label = "until the tables open"; }
    else if (T.status === "running") { var cur = T.rounds[T.rounds.length - 1] || [], d = cur.filter(function (t) { return t.done; }).length; f = cur.length ? d / cur.length : 0; label = d + " of " + cur.length + (cur.length === 1 ? " table done" : " tables done"); }
    else { f = T.status === "done" ? 1 : 0; label = T.status === "done" ? "Complete" : "Called off"; }
    return { c: c, off: c * (1 - Math.max(0, Math.min(1, f))), label: label, target: target };
  }
  function face(n, img, cls) {
    return '<span class="tr-av' + (cls ? " " + cls : "") + '">' + (img ? '<img src="' + esc(img) + '" alt="" loading="lazy" decoding="async">' : '<i>' + esc(String(n || "?").charAt(0).toUpperCase()) + '</i>') + '</span>';
  }
  function drawHall() {
    if (!hall) return;
    if (!T) {
      if (keyHall === "none") return; keyHall = "none";
      hall.innerHTML = '<div class="tr-empty"><i class="gt-flag" aria-hidden="true"></i><div><b>No tournament is scheduled right now.</b><span>New ones are announced in the Telegram chat and right here. The rules below are how every one works.</span></div></div>' + rules();
      wires();
      return;
    }
    var k = JSON.stringify([T, msg, P.name() ? 1 : 0]).replace(/"now":\d+,?/, "");
    if (k === keyHall) return;
    keyHall = k;
    var pl = plan(), ph = phases(pl), rg = ring(), y = T.you || {};
    var st = { signup: ["open", T.checkinOpen ? "Check-in open" : "Sign-ups open"], running: ["live", "Live now"], done: ["done", "Finished"], cancelled: ["off", "Called off"] }[T.status] || ["", ""];
    var h = '<div class="tr-top"><span class="tr-pill ' + st[0] + '">' + st[1] + '</span><h3 data-i18n-skip>' + esc(T.name) + '</h3>' +
      '<div class="tr-meta"><div data-i18n-skip>' + esc(when(T.start)) + '</div><div>' + (T.fee > 0 ? 'Up to ' + fmt(T.max) + ' players &middot; Entry ' + fmt(T.fee) + ' $SHY' : 'Up to ' + fmt(T.max) + ' players &middot; Free to enter') + '</div></div></div>' + gateH();
    // timeline
    h += '<div class="tr-time-wrap"><ol class="tr-time">' + ph.list.map(function (p, i) {
      return '<li class="' + (i < ph.cur ? "past" : i === ph.cur ? "now" : "") + '"><i></i><b>' + p[0] + '</b><small>' + p[1] + '</small></li>';
    }).join("") + '</ol></div>';
    // clock and what to do, then the prizes
    var inner = rg.target ? '<b data-tclock="' + rg.target + '">' + clock(rg.target) + '</b><small>' + rg.label + '</small>' :
      T.status === "running" ? '<b>' + fmt(playersIn()) + '</b><small>' + (playersIn() === 1 ? "player still in" : "players still in") + '</small>' :
      '<b class="tr-ring-ic ' + (T.status === "done" ? "cup" : "off") + '"></b><small>' + rg.label + '</small>';
    // who's in
    var whoH = "", ros = T.roster || [];
    if (ros.length) {
      var shown = ros.slice(0, innerWidth < 560 ? 7 : 10), more = T.count - shown.length;
      whoH = '<div class="tr-who"><div class="tr-stack">' + shown.map(function (p, i) { return '<span style="z-index:' + (20 - i) + '" title="' + esc(p.n) + '">' + face(p.n, p.img, p["in"] ? "in" : "") + '</span>'; }).join("") + (more > 0 ? '<span class="tr-more">+' + fmt(more) + '</span>' : "") + '</div>' +
        '<small>' + fmt(T.count) + (T.count === 1 ? " player signed up" : " players signed up") + (T.checkedIn ? ", " + fmt(T.checkedIn) + " checked in" : "") + '</small></div>';
    }
    h += '<div class="tr-grid"><div class="tr-clock"><div class="tr-ring"><svg viewBox="0 0 128 128" aria-hidden="true"><defs><linearGradient id="trg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe08a"/><stop offset="1" stop-color="#e0453a"/></linearGradient></defs>' +
      '<circle cx="64" cy="64" r="54" class="tr-ring-bg"/><circle cx="64" cy="64" r="54" class="tr-ring-fg" stroke-dasharray="' + rg.c.toFixed(1) + '" stroke-dashoffset="' + rg.off.toFixed(1) + '" data-ring/></svg>' +
      '<div class="tr-ring-in">' + inner + '</div></div>' +
      '<div class="tr-clock-txt"><b class="tr-head">' + headline() + '</b>' + (T.status === "running" ? '<small class="tr-sub">' + rg.label + '</small>' : "") +
      '<div class="tr-act gt-act">' + action() + '</div>' + (msg ? '<p class="gt-msg">' + esc(msg) + '</p>' : "") + whoH + '</div></div>';
    var med = ["1st", "2nd", "3rd", "4th"];
    //MC 2026-10-13 a paid event's $SHY pool grows with every entry: the pool line leads, split 50 / 25 / 15 / 10, and the
    //   Koban prizes (if the team set any) still show beside it
    var poolH = "";
    if (T.fee > 0) {
      var ps = T.pool || { n: 0, shy: 0 }, split = [50, 25, 15, 10];
      poolH = '<div class="tr-pool"><div class="tr-pool-hd"><b data-i18n-skip>' + fmt(ps.shy) + ' $SHY</b><span>' + (T.status === "signup" ? 'in the prize pool so far: ' + T.poolPct + '% of every entry' : 'prize pool from ' + fmt(ps.n) + ' entries') + '</span></div>' +
        (ps.shy > 0 ? '<div class="tr-pool-split">' + split.map(function (pc, i) { var amt = Math.floor(ps.shy * pc / 100); return amt ? '<span><b>' + med[i] + '</b>' + fmt(amt) + ' $SHY</span>' : ""; }).join("") + '</div>' : "") +
        '<small>' + (T.burnPct ? T.burnPct + '% of every entry burns on Solana in your own payment. ' : "") + 'Pool prizes are sent in $SHY to the wallet that paid. If the event is called off, every entry is refunded in full.</small></div>';
    }
    h += '<div class="tr-prizes"><span class="tr-k">Prizes</span>' + poolH + '<div class="tr-pz">' + T.prizes.map(function (p, i) {
      if (!p) return "";
      var who = T.status === "done" && T.places[i] ? '<em data-i18n-skip>' + esc(T.places[i]) + '</em>' : "";
      return '<div class="tp p' + (i + 1) + (T.status === "done" && y.place === i + 1 ? " me" : "") + '"><span>' + med[i] + '</span>' + koban(p) + who + '</div>';
    }).join("") + '<div class="tp title"><span>Winner</span><b>Cup Champion title</b></div></div>' + (T.note ? '<p class="tr-note">' + esc(T.note) + '</p>' : "") + '</div></div>';
    h += bracket(pl) + rules();
    var x = hall.querySelector(".tr-br-scroll"), sx = x ? x.scrollLeft : 0;
    keepName(hall, function () { hall.innerHTML = h; });
    var nx = hall.querySelector(".tr-br-scroll"); if (nx) { nx.scrollLeft = sx; brMore(nx); }
    var f = hall.querySelector("[data-tr-find]"); if (f) f.value = hl;
    wires();
  }
  //MC 2026-10-11 on phones the bracket ran off the right edge with nothing saying it scrolls (the final column was cut at
  // the card edge). While there's more to the right (or left), that side fades out (.more-r / .more-l in style.css)
  function brMore(x) {
    var r = x.scrollWidth - x.clientWidth, at = Math.abs(x.scrollLeft);
    x.classList.toggle("more-r", r > 4 && at < r - 4); x.classList.toggle("more-l", r > 4 && at > 4);
  }
  document.addEventListener("scroll", function (e) { var t = e.target; if (t && t.classList && t.classList.contains("tr-br-scroll")) brMore(t); }, true);
  addEventListener("resize", function () { document.querySelectorAll(".tr-br-scroll").forEach(brMore); });
  // ---------- the bracket ----------
  function bracket(pl) {
    if (!pl.length) return "";
    var me = P.name(), real = T.rounds || [];
    var h = '<section class="tr-br"><div class="tr-br-hd"><div><h4>' + (real.length ? "Bracket" : "The road to the title") + '</h4>' +
      '<small>' + (real.length ? "Tap a name to follow that player's path. Gold is you." : "Tables are drawn at random at the start. With " + fmt(T.checkinOpen ? T.checkedIn : T.count) + " in right now, the champion wins " + pl.length + (pl.length === 1 ? " table." : " tables in a row.")) + '</small></div>' +
      (real.length ? '<input class="tr-find" type="search" placeholder="Find a player" data-tr-find autocomplete="off" spellcheck="false">' : "") + '</div>' +
      '<div class="tr-br-scroll"><div class="tr-br-in"><svg class="tr-lines" aria-hidden="true"></svg>';
    h += pl.map(function (col, ci) {
      var body;
      if (col.real) body = col.real.map(function (tb, ti) {
        // big rounds: a finished table shows just who moved on, tap to see the rest
        var fold = tb.done && tb.win && col.real.length > 4 && !open[ci + "-" + ti] && !(me && tb.seats.indexOf(me) >= 0);
        var seats = fold ? [tb.win] : tb.seats;
        return '<div class="tr-tb' + (tb.done ? " done" : " live") + (fold ? " fold" : "") + '" data-ci="' + ci + '" data-ti="' + ti + '">' + (tb.done ? "" : '<i class="tr-live">Playing</i>' + (tb.watch ? '<a class="tr-watch" href="/play?watch=' + esc(tb.watch) + '" data-watch="' + esc(tb.watch) + '">👁 Watch</a>' : "")) + seats.map(function (n) {
          var cls = (tb.win === n ? "win" : tb.done ? "out" : "") + (me && n === me ? " mine" : "");
          return '<button type="button" class="tr-seat ' + cls + '" data-n="' + esc(n) + '">' + face(n, (T.imgs || {})[n]) + '<span data-i18n-skip>' + esc(n) + '</span>' + (tb.win === n ? '<i class="tr-crown" aria-label="moves on"></i>' : "") + '</button>';
        }).join("") + (fold ? '<button type="button" class="tr-tb-x" data-x="' + ci + "-" + ti + '">+' + (tb.seats.length - 1) + ' more at this table</button>' : (tb.done && col.real.length > 4 && open[ci + "-" + ti] ? '<button type="button" class="tr-tb-x" data-x="' + ci + "-" + ti + '">Show less</button>' : "")) + '</div>';
      }).join("");
      else {
        var show = col.ghost.slice(0, 6);
        body = show.map(function (s2, k) {
          var dots = "";
          for (var q = 0; q < s2; q++) dots += '<span class="tr-av"><i></i></span>';
          return '<div class="tr-tb ghost"><div class="tr-dots">' + dots + '</div><small>' + (ci === 0 ? s2 + " open seats" : s2 + " table winners") + '</small></div>';
        }).join("") + (col.ghost.length > show.length ? '<div class="tr-tb-more">+' + (col.ghost.length - show.length) + ' more tables</div>' : "");
      }
      return '<div class="tr-col"><b class="tr-col-hd">' + col.lab + '</b><div class="tr-col-b">' + body + '</div></div>';
    }).join("");
    h += '<div class="tr-col tr-champ"><b class="tr-col-hd">Champion</b><div class="tr-col-b"><div class="tr-cup' + (T.champ ? " won" : "") + '"' + (T.champ ? ' data-n="' + esc(T.champ) + '"' : "") + '><i class="tr-cup-i" aria-hidden="true"></i><b' + (T.champ ? " data-i18n-skip" : "") + '>' + (T.champ ? esc(T.champ) : "Who takes it?") + '</b></div></div></div>';
    return h + '</div></div></section>';
  }
  // the connector lines: measured once per redraw (and on resize), never per frame
  function lines() {
    var wrap = hall && hall.querySelector(".tr-br-in"), svg = wrap && wrap.querySelector(".tr-lines");
    if (!svg || !T || !T.rounds.length) return;
    var box = wrap.getBoundingClientRect(), out = [];
    svg.setAttribute("width", wrap.scrollWidth); svg.setAttribute("height", wrap.scrollHeight);
    function curve(n, a, b) {
      var x1 = a.right - box.left, y1 = a.top + a.height / 2 - box.top, x2 = b.left - box.left, y2 = b.top + b.height / 2 - box.top, m = (x1 + x2) / 2;
      out.push('<path data-n="' + esc(n) + '" d="M' + x1.toFixed(1) + " " + y1.toFixed(1) + "C" + m.toFixed(1) + " " + y1.toFixed(1) + " " + m.toFixed(1) + " " + y2.toFixed(1) + " " + x2.toFixed(1) + " " + y2.toFixed(1) + '"/>');
    }
    for (var ri = 1; ri < T.rounds.length; ri++) {
      T.rounds[ri].forEach(function (tb, ti) {
        tb.seats.forEach(function (n) {
          var prev = -1;
          T.rounds[ri - 1].forEach(function (pt, pi) { if (pt.win === n) prev = pi; });
          if (prev < 0) return;
          var a = wrap.querySelector('.tr-tb[data-ci="' + (ri - 1) + '"][data-ti="' + prev + '"] [data-n="' + CSS.escape(n) + '"]'), b = wrap.querySelector('.tr-tb[data-ci="' + ri + '"][data-ti="' + ti + '"] [data-n="' + CSS.escape(n) + '"]');
          if (a && b) curve(n, a.getBoundingClientRect(), b.getBoundingClientRect());
        });
      });
    }
    if (T.champ) {
      var a = wrap.querySelector('.tr-tb[data-ci="' + (T.rounds.length - 1) + '"] [data-n="' + CSS.escape(T.champ) + '"]'), c = wrap.querySelector(".tr-cup");
      if (a && c) curve(T.champ, a.getBoundingClientRect(), c.getBoundingClientRect());
    }
    svg.innerHTML = out.join("");
    mark();
  }
  function mark() {
    if (!hall) return;
    var me = P.name(), q = hl.toLowerCase();
    hall.querySelectorAll(".tr-seat[data-n], .tr-lines path, .tr-cup[data-n]").forEach(function (x) {
      var n = (x.getAttribute("data-n") || "").toLowerCase(), on = q && (n === q || (q.length > 1 && n.indexOf(q) === 0));
      x.classList.toggle("hl", !!on);
      x.classList.toggle("mine", !!me && n === me.toLowerCase());
    });
    var br = hall.querySelector(".tr-br"); if (br) br.classList.toggle("focus", !!q);
  }
  function wires() {
    if (reduce) lines(); else requestAnimationFrame(lines);
    var tw = hall.querySelector(".tr-time-wrap"), nw = tw && tw.querySelector("li.now");
    if (tw && nw && tw.scrollWidth > tw.clientWidth) tw.scrollLeft = Math.max(0, nw.offsetLeft - tw.clientWidth / 2 + nw.offsetWidth / 2);
    var d = hall.querySelector("details.tr-rules");
    if (d) d.addEventListener("toggle", function () { rulesOpen = d.open; try { localStorage.setItem("shy-tr-rules", d.open ? "1" : "0"); } catch (e) {} });
  }
  // ---------- the rules, in plain words ----------
  function rules() {
    //MC 2026-10-13 paid events swap the first and last rules for their own
    var paidR = T && T.fee > 0;
    var R = [
      paidR ? ["Entry fee", "This one costs " + fmt(T.fee) + " $SHY to enter, paid from your connected wallet in the shop checkout. " + (T.poolPct || 0) + "% of every entry goes into the $SHY prize pool, and the usual burn share burns in your own payment."]
            : ["Free to enter", "Sign up any time before the start. Spots are limited, so the earliest sign-ups get in."],
      ["Check in", "Check-in opens 30 minutes before the start. If you're signed up but not checked in when it starts, you lose your spot. Signing up in those last 30 minutes checks you in."],
      ["The draw", "At the start, checked-in players are shuffled into tables of up to 4. Bots fill empty seats, and a bot can never move on."],
      ["Take your seat", "Your table opens at the start and the Play page seats you automatically. A table starts when everyone is there, or after about 2 minutes. If you're late, a bot plays your seat until you take it. If you never do, you're out."],
      ["Who moves on", "Each table is a normal live match. The real player who finishes highest moves on and everyone else at the table is out. Highest means most Regions at the end. A tie goes to the player holding more cards."],
      ["Rounds", "Winners are drawn into new tables for the next round, until 4 or fewer are left. They play the final table, which decides 1st to 4th."],
      ["Stay active", "If every real player at a table goes quiet for 45 seconds, the game plays out on its own so the tournament keeps moving."],
      ["Prizes", "Koban prizes land in your account the moment the final table ends, and the winner gets the Cup Champion title. Any extra prize in the note is sent by the team."],
      ["Counts for the League", "Tournament tables with 2 or more real players count as live matches for the Weekly League, inside the daily limit."],
      paidR ? ["Called off", "If fewer than 2 players are checked in at the start, it's called off and every entry fee is refunded in full, in $SHY, to the wallet that paid."]
            : ["Called off", "If fewer than 2 players are checked in at the start, it's called off. Nothing is lost, since it's free to enter."]];
    return '<details class="wl-rules tr-rules"' + (rulesOpen ? " open" : "") + '><summary><span>How tournaments work</span><i>' + R.length + ' rules</i></summary><div class="wl-rules-grid">' +
      R.map(function (r, i) { return '<div><b><span>' + (i + 1) + '</span>' + r[0] + '</b><p>' + r[1] + '</p></div>'; }).join("") + '</div><a class="wl-more" href="/rules#tournaments">Read the official rules</a></details>';
  }

  function draw() { drawCard(); drawHall(); drawEnd(); }
  // after a tournament table, the end screen says what's next
  function drawEnd() {
    var end = document.getElementById("g-end");
    if (!end || end.hidden || !lastEnd || !T || T.id !== lastEnd.id) return;
    var box = document.getElementById("gt-end");
    if (!box) { box = document.createElement("div"); box.id = "gt-end"; box.className = "gt-end"; var anchor = document.getElementById("g-end-list"); if (anchor && anchor.parentNode) anchor.parentNode.insertBefore(box, anchor); else end.appendChild(box); }
    var y = T.you || {}, h;
    if (y.table) h = '<b>You\'re through.</b><span>Your next table is ready.</span><button class="btn btn-gold btn-sm" data-t="seat">Take my seat</button>';
    else if (T.status === "done" && y.place === 1) h = '<b>You won ' + '<span data-i18n-skip>' + esc(T.name) + '</span>!</b><span>Your prize is in your Koban.</span>';
    else if (T.status === "done") h = '<b>' + (y.place ? "You finished #" + y.place + "." : "The tournament is over.") + '</b>' + (T.champ ? '<span><span data-i18n-skip>' + esc(T.champ) + '</span> is the champion.</span>' : "");
    else if (y.out === null) h = '<b>You\'re through.</b><span>Your next table opens when every table in this round is done. Stay on this page.</span>';
    else h = '<b>You\'re out.</b><span>Thanks for playing. Follow the rest of the bracket on the Play page.</span>';
    box.innerHTML = h;
  }
  // take the seat on our own when the player is waiting on this page, not in a game
  function seatCheck() {
    var y = T && T.you;
    if (!y || !y.table || !y.table.secret) return;
    var key = y.table.code;
    if (lastSeat === key || P.liveCode() === key) return;
    var endShown = document.getElementById("g-end") && !document.getElementById("g-end").hidden;
    if (P.busy() && !endShown) return;
    lastSeat = key;
    P.toast("Your tournament table is ready. Taking your seat…");
    setTimeout(function () { if (P.liveCode() !== key) P.joinRoom(y.table); }, 1800);
  }
  // one light tick a second: a few text nodes and one ring attribute, nothing that reflows the page
  setInterval(function () {
    if (document.hidden || !T) return;
    document.querySelectorAll("[data-tcount]").forEach(function (x) { x.textContent = left(+x.dataset.tcount); });
    var c = hall && hall.querySelector("[data-tclock]");
    if (c) { c.textContent = clock(+c.dataset.tclock); var fg = hall.querySelector("[data-ring]"); if (fg) fg.setAttribute("stroke-dashoffset", ring().off.toFixed(1)); }
    if (T.status === "signup" && now() >= T.start && !draw.kick) { draw.kick = 1; setTimeout(function () { draw.kick = 0; load(); }, 1500); }
    if (T.status === "signup" && !T.checkinOpen && now() >= T.checkin && !draw.kick2) { draw.kick2 = 1; setTimeout(function () { draw.kick2 = 0; load(); }, 800); }
  }, 1000);
  var rz = 0;
  window.addEventListener("resize", function () { clearTimeout(rz); rz = setTimeout(lines, 180); }, { passive: true });

  if (hall) {
    hall.addEventListener("click", function (e) {
      var x = e.target.closest("[data-x]");
      if (x) { var id = x.getAttribute("data-x"); if (open[id]) delete open[id]; else open[id] = 1; keyHall = ""; drawHall(); return; }
      var s = e.target.closest(".tr-seat[data-n], .tr-cup[data-n]");
      if (!s) return;
      var n = s.getAttribute("data-n");
      hl = hl === n ? "" : n;
      var f = hall.querySelector("[data-tr-find]"); if (f) f.value = hl;
      mark();
    });
    hall.addEventListener("input", function (e) {
      if (!e.target.matches("[data-tr-find]")) return;
      hl = e.target.value.trim();
      // open any folded table that holds a match, so the path can light up
      var q = hl.toLowerCase(), more = false;
      if (q.length > 1 && T) T.rounds.forEach(function (r, ci) { r.forEach(function (tb, ti) { if (tb.seats.some(function (n) { return n.toLowerCase().indexOf(q) === 0; }) && !open[ci + "-" + ti]) { open[ci + "-" + ti] = 1; more = true; } }); });
      if (more) { var pos = e.target.selectionStart; keyHall = ""; drawHall(); var f = hall.querySelector("[data-tr-find]"); if (f) { f.focus(); try { f.setSelectionRange(pos, pos); } catch (er) {} } }
      else mark();
    });
    var hover = window.matchMedia && matchMedia("(hover: hover)").matches;
    if (hover) {
      hall.addEventListener("mouseover", function (e) { var s = e.target.closest(".tr-seat[data-n]"); if (s && !hl) { hl = s.getAttribute("data-n"); mark(); hl = ""; } });
      hall.addEventListener("mouseout", function (e) { if (e.target.closest(".tr-seat[data-n]") && !hl) mark(); });
    }
  }
  document.addEventListener("click", async function (e) {
    var b = e.target.closest("[data-t]");
    if (!b || !T || busy) return;
    var what = b.dataset.t;
    if (what === "seat") { if (T.you && T.you.table) { lastSeat = T.you.table.code; P.joinRoom(T.you.table); } return; }
    if (what === "join") {
      var scope = b.closest(".gt-act") || document, inp = scope.querySelector("[data-gt-name]"), name = P.name() || (inp ? inp.value.trim() : "");
      if (!/^[A-Za-z0-9 _.\-]{3,20}$/.test(name)) { msg = "Pick a player name first (3 to 20 letters or numbers)."; draw(); var i2 = scope.querySelector("[data-gt-name]") || document.querySelector("[data-gt-name]"); if (i2) i2.focus(); return; }
      busy = true; b.disabled = true;
      var j = await call({ a: "join", name: name, avatar: P.avatar(), id: b.dataset.id || T.id });
      busy = false;
      if (j.ok) { P.setName(name); T = j.t; msg = ""; P.sfx("badge"); P.toast(T.you && T.you["in"] ? "You're in and checked in." : "You're in. Check in during the last 30 minutes."); }
      //MC 2026-10-13 a paid event without a ticket yet: open the shop checkout for the entry. The shy:paid listener
      //   below signs the buyer up on its own the moment the payment lands.
      else if (j.needTicket && window.ShyEco && ShyEco.checkout) {
        pendJoin = { name: name, id: b.dataset.id || T.id, product: j.product };
        msg = "";
        ShyEco.checkout({ id: j.product, name: "Entry: " + (j.tname || T.name), shy: j.fee, shyOnly: true });
      }
      else msg = j.error || "Couldn't sign up.";
      draw(); schedule(); return;
    }
    if (what !== "checkin" && what !== "leave") return;
    busy = true; b.disabled = true;
    var r = await call({ a: what });
    busy = false;
    if (r.ok) { T = r.t; msg = ""; if (what === "checkin") P.sfx("badge"); else P.toast("You backed out. Sign up again any time before it starts."); }
    else msg = r.error || "Something went wrong.";
    draw(); schedule();
  });
  // back on the page (phone unlocked, switched back from another app): check right away so a waiting table seats you
  //MC 2026-10-13 the entry just got paid: sign the buyer up with the name they typed, no second tap needed
  var pendJoin = null;
  document.addEventListener("shy:paid", async function (e) {
    if (!pendJoin || !e.detail || e.detail.product !== pendJoin.product) return;
    var pj = pendJoin; pendJoin = null;
    var j = await call({ a: "join", name: pj.name, avatar: P.avatar(), id: pj.id });
    if (j.ok) { P.setName(pj.name); T = j.t; msg = ""; P.sfx("badge"); P.toast("Entry paid. " + (T.you && T.you["in"] ? "You're in and checked in." : "You're in. Check in during the last 30 minutes.")); }
    else msg = j.error || "Entry paid. Press Sign up to take your spot.";
    draw(); schedule();
  });
  document.addEventListener("visibilitychange", function () { if (!document.hidden && T && (T.status === "running" || T.status === "signup")) load(); });
  document.addEventListener("shy:tourney-end", function (e) { lastEnd = e.detail; load(); });
  load().then(function () { if (location.hash === "#tourney") { var s = document.getElementById("tourney"); if (s) s.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" }); } });
})();
