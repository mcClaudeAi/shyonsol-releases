//MC 2026-10-13 the hidden layer: a console banner, and the five seals. One kanji seal sits in the footer of five pages
//   (Play, Shilluminati, Stats, Token, Shytoshi). Finding all five plays a short rite and pays 900 Koban once per player
//   (api/seals.php). Progress lives in localStorage, wrapped in try/catch so private windows just play along quietly.
//   The numbers and the tone nod at a certain fighting anime without borrowing a single name from it.
(function () {
  "use strict";
  var KEY = "shy-seals";
  var SEALS = { play: "力", cards: "技", stats: "数", token: "金", shytoshi: "影" };   // 力 技 数 金 影
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function found() { try { return JSON.parse(store(KEY) || "[]"); } catch (e) { return []; } }
  function pageKey() {
    var p = location.pathname.replace(/\.html$/, "").replace(/\/$/, "") || "/";
    p = p.slice(1) || "index";
    return SEALS[p] ? p : "";
  }

  // the console banner: a hint for whoever opens the hood
  try {
    console.log("%c力", "font-size:64px;color:#c42a1f;text-shadow:0 0 18px rgba(232,178,58,.8)");
    console.log("%cHidden power sleeps in this site. Five seals, five pages, 900 Koban. The footer remembers.", "color:#e8b23a;font-size:13px");
  } catch (e) {}

  var pk = pageKey();
  if (!pk) return;

  function place() {
    var legal = document.querySelector("footer .legal p:last-of-type");
    if (!legal || document.querySelector(".egg-seal")) return;
    var b = document.createElement("button");
    b.type = "button"; b.className = "egg-seal"; b.setAttribute("data-i18n-skip", "");
    b.setAttribute("aria-label", "A hidden seal");
    b.textContent = SEALS[pk];
    if (found().indexOf(pk) >= 0) b.classList.add("lit");
    b.addEventListener("click", take);
    legal.appendChild(document.createTextNode(" "));
    legal.appendChild(b);
  }

  function take() {
    var f = found();
    var b = document.querySelector(".egg-seal");
    if (f.indexOf(pk) < 0) { f.push(pk); store(KEY, JSON.stringify(f)); }
    if (b) b.classList.add("lit", "woke");
    if (f.length >= 5) return rite(f);
    chip('<span>A seal wakes.</span> <b data-i18n-skip>' + f.length + " / 5</b>");
  }

  function chip(html) {
    var c = document.querySelector(".egg-chip");
    if (!c) { c = document.createElement("div"); c.className = "egg-chip"; document.body.appendChild(c); }
    c.innerHTML = html;
    c.classList.remove("on"); void c.offsetWidth; c.classList.add("on");
    clearTimeout(c._t); c._t = setTimeout(function () { c.classList.remove("on"); }, 3200);
  }

  // all five: the seals join, and the claim goes to the server (once per player)
  function rite(f) {
    var o = document.createElement("div");
    o.className = "egg-rite";
    o.innerHTML = '<div class="egg-rite-in"><div class="egg-ring" data-i18n-skip>' +
      Object.keys(SEALS).map(function (k, i) { return '<i style="--i:' + i + '">' + SEALS[k] + "</i>"; }).join("") +
      '</div><p class="egg-line"><span>The fifth seal.</span> <span>Hidden power is yours.</span></p><p class="egg-pay"></p>' +
      '<button type="button" class="btn egg-close">Return to the world</button></div>';
    document.body.appendChild(o);
    requestAnimationFrame(function () { o.classList.add("on"); });
    o.querySelector(".egg-close").addEventListener("click", function () { o.classList.remove("on"); setTimeout(function () { o.remove(); }, 400); });
    var pay = o.querySelector(".egg-pay");
    if (store("shy-seals-paid")) { pay.innerHTML = "<span>The seals only join once.</span>"; return; }
    var pid = store("shy-lb-pid"), key = store("shy-lb-key");
    if (!pid || !key) { pay.innerHTML = "<span>Play one game first, then the seals will answer.</span>"; return; }
    pay.innerHTML = "<span>The seals are deciding.</span>";
    fetch("/api/seals.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pid: pid, key: key }) })
      .then(function (r) { return r.json().then(function (j) { j.status = r.status; return j; }); })
      .then(function (j) {
        if (j && j.ok) { store("shy-seals-paid", "1"); pay.innerHTML = '<span>Yours:</span> <b data-i18n-skip>+' + j.koban + '</b> <span>Koban.</span>'; }
        else if (j && j.status === 409) { store("shy-seals-paid", "1"); pay.innerHTML = "<span>The seals only join once.</span>"; }
        else pay.innerHTML = "<span>" + ((j && j.error) || "The seals will answer another day.") + "</span>";
      })
      .catch(function () { pay.innerHTML = "<span>The seals will answer another day.</span>"; });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", place);
  else place();
})();

//MC 2026-10-13 the power gauge (profile and public player pages): count the number up, grow the fill, flinch as it
//   passes 9,000, and open the breakdown on tap or Enter. The pages render final values, so with this script absent or
//   motion reduced the gauge still reads right.
(function () {
  "use strict";
  var reduce = false; try { reduce = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function arm(el) {
    if (el.dataset.pwOn) return; el.dataset.pwOn = "1";
    el.addEventListener("click", function () { var b = el.querySelector(".pw-break"); if (b) { b.hidden = !b.hidden; el.setAttribute("aria-expanded", String(!b.hidden)); } });
    el.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); el.click(); } });
    var to = +el.dataset.pw || 0, n = el.querySelector(".pw-n"), fill = el.querySelector(".pw-fill");
    if (reduce || !to || !n) return;
    var w = fill ? fill.style.width : ""; if (fill) fill.style.width = "0%";
    var hit = false, t0 = performance.now();
    requestAnimationFrame(function step(t) {
      var k = Math.min(1, (t - t0) / 1500), e = 1 - Math.pow(1 - k, 3), v = Math.round(to * e);
      n.textContent = fmt(v);
      if (!hit && v >= 9000) { hit = true; el.classList.add("pw-hit"); setTimeout(function () { el.classList.remove("pw-hit"); }, 800); }
      if (k < 1) requestAnimationFrame(step);
    });
    if (fill) requestAnimationFrame(function () { fill.style.width = w; });
  }
  function scan() { document.querySelectorAll(".pw-strip").forEach(arm); }
  if ("MutationObserver" in window) new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", scan); else scan();
})();
