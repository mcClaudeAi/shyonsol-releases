//MC 2026-10-10 the Token page's $SHY Army Ranks: the ladder from the game's own settings (so it always matches the shop), a
//   "how much do you hold?" box that says which rank that is and how far the next one is, and the $SHY the game has burned.
(function () {
  "use strict";
  var lad = document.getElementById("ht-ladder"), amt = document.getElementById("ht-amt"), res = document.getElementById("ht-res");
  if (!lad) return;
  var C = null;
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function short(n) { n = +n || 0; return n >= 1e6 ? (n / 1e6).toLocaleString("en-US", { maximumFractionDigits: 1 }) + "M" : n >= 1e3 ? Math.round(n / 1e3).toLocaleString("en-US") + "K" : fmt(n); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var FREE = { bounty: "Bounty Board every week", scroll: "Season Scroll free", plus: "Scroll+ free" };
  //MC 2026-10-10 the $SHY Army Ranks: nine ranks in three circles, laid out like the community poster, each with its emblem
  var CIRCLES = [["Recruits", ["sapling", "cadet", "scout"]], ["Officers", ["knight", "champion", "commander"]], ["High Command", ["sovereign", "king", "supreme"]]];
  function img(k, small) { return "/assets/ranks/" + k + (small ? "-64" : "") + ".webp"; }
  function chip(k) { return '<em class="tier-b rk t-' + k + '" data-i18n-skip><img src="' + img(k, 1) + '" alt="" width="22" height="22">' + esc(C.holderNames[k]) + '</em>'; }
  function tierOf(bal) { var t = ""; (C.ladder || []).forEach(function (k) { if (bal >= C.holderTiers[k]) t = k; }); return t; }
  function draw() {
    var T = C.holderTiers, S = C.stipend, P = C.holderPerks, N = C.holderNames, L = C.ladder, px = C.shyPx;
    lad.innerHTML = CIRCLES.map(function (c) {
      return '<div class="ht-row rk t-' + c[1][0] + ' reveal in"><h3>' + c[0] + '</h3><ul>' + c[1].map(function (k) {
        var p = P[k], fr = (p.free || []).filter(function (f) { return !(f === "scroll" && p.free.indexOf("plus") >= 0); }), nx = L[L.indexOf(k) + 1];
        // the poster's range: 0 to 5K for the first rank, 5M+ for the last
        var amt = (k === L[0] ? "0" : short(T[k])) + (nx ? "\u2013" + short(T[nx]) : "+") + " $SHY";
        return '<li class="ht-rank rk t-' + k + '" data-t="' + k + '"><div class="ht-em"><img src="' + img(k) + '" alt="" width="256" height="256" loading="lazy"></div>' +
          '<b class="ht-nm rk-nm" data-i18n-skip>' + esc(N[k]) + '</b><span class="ht-amt"><span data-i18n-skip>' + amt + '</span>' + (px && k !== L[0] ? ' <small>about $' + fmt(Math.round(T[k] * px)) + '</small>' : "") + '</span>' +
          '<ul><li><b>' + fmt(S[k]) + '</b> Koban every week</li>' + (p.disc ? '<li><b>' + p.disc + '% off</b> every Koban price</li>' : "") + '<li><b>' + p.gift + 'x</b> daily gift</li><li><b>+' + (C.shyBonus + p.shyb) + '%</b> Koban when you pay in $SHY</li>' +
          fr.map(function (f) { return '<li class="ht-free">' + FREE[f] + '</li>'; }).join("") + '</ul></li>';
      }).join("") + '</ul></div>';
    }).join("");
    calc();
  }
  function calc() {
    if (!C || !amt) return;
    var bal = Math.max(0, +amt.value || 0), t = tierOf(bal), N = C.holderNames, L = C.ladder, i = L.indexOf(t), nx = L[i + 1];
    //MC 2026-10-11 "You" only when the box holds the signed-in player's own balance; any other amount is "This amount".
    // It was a CSS "You" on whatever 100,000 $SHY gave, so a 2M holder saw "You" on Shy Champion. A real element now,
    // so it's translated too (CSS text never was)
    var own = mine != null && Math.floor(bal) === mine;
    lad.querySelectorAll(".ht-rank").forEach(function (el) {
      var on = el.dataset.t === t, y = el.querySelector(".ht-you");
      el.classList.toggle("on", on); el.classList.toggle("mine", on && own);
      if (on) { if (!y) { y = document.createElement("span"); y.className = "ht-you"; el.appendChild(y); } y.textContent = own ? "You" : "This amount"; }
      else if (y) y.remove();
    });
    //MC 2026-10-10 rank names stay as they are in every language (they're names), so each sentence is one dictionary line
    res.innerHTML = t ? '<span>Your rank:</span> ' + chip(t) + ' <span><b>' + fmt(C.stipend[t]) + ' Koban a week</b>' + (C.holderPerks[t].disc ? ', ' + C.holderPerks[t].disc + '% off the shop' : "") + '.</span>' + (nx ? ' <span>' + fmt(C.holderTiers[nx] - bal) + ' more $SHY to reach <b data-i18n-skip>' + esc(N[nx]) + '</b>.</span>' : ' <span>The top of the ranks.</span>')
      : '<span>Any $SHY makes you a <b data-i18n-skip>' + esc(N[L[0]]) + '</b>, the first rank.</span>';
    prog(bal, t, own);
  }
  //MC 2026-10-11 the bar from the rank this amount gives to the next one, and "Buy the difference": it shows the exact
  //   $SHY still needed above the swap box (with Copy) and scrolls there, which also starts the box. The amount isn't
  //   typed into Jupiter's box for the visitor; see the note in build.py.
  var pg = document.getElementById("ht-prog");
  function prog(bal, t, own) {
    if (!pg) return;
    var L = C.ladder, T = C.holderTiers, N = C.holderNames, i = L.indexOf(t), nx = L[i + 1];
    if (!nx) {
      pg.innerHTML = '<div class="hpg-row top"><span class="hpg-end"><img src="' + img(t, 1) + '" alt="" width="34" height="34"><b data-i18n-skip>' + esc(N[t]) + '</b></span><span class="hpg-bar" aria-hidden="true"><i style="width:100%"></i></span></div><p class="hpg-note">' + (own ? "You're at the top of the ranks." : "That's the top of the ranks.") + '</p>';
      return;
    }
    var from = t ? T[t] : 0, need = Math.max(0, Math.ceil(T[nx] - bal)), pct = Math.max(0, Math.min(100, (bal - from) / Math.max(1, T[nx] - from) * 100));
    var px = C.shyPx ? need * C.shyPx : 0;
    pg.innerHTML = '<div class="hpg-row"><span class="hpg-end">' + (t ? '<img src="' + img(t, 1) + '" alt="" width="34" height="34"><b data-i18n-skip>' + esc(N[t]) + '</b>' : '<i class="hpg-zero">0</i>') + '</span>' +
      '<span class="hpg-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.floor(pct) + '" aria-label="Progress to the next rank"><i style="width:' + pct.toFixed(1) + '%"></i></span>' +
      '<span class="hpg-end nx"><img src="' + img(nx, 1) + '" alt="" width="34" height="34"><b data-i18n-skip>' + esc(N[nx]) + '</b></span></div>' +
      '<div class="hpg-foot"><span class="hpg-note"><b>' + Math.floor(pct) + '%</b> <span>of the way.</span> <span>' + fmt(need) + ' $SHY to go' + (px >= 0.01 ? ', about $' + (px < 10 ? px.toFixed(2) : fmt(Math.round(px))) : "") + '.</span></span>' +
      '<button type="button" class="btn btn-red btn-sm" data-ht-buy="' + need + '" data-ht-to="' + nx + '">Buy the difference</button></div>';
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-ht-buy]"); if (!b || !C) return;
    var need = Math.max(0, parseInt(b.getAttribute("data-ht-buy"), 10) || 0), nx = b.getAttribute("data-ht-to"), box = document.getElementById("jup-need");
    if (!box || !need || !C.holderNames[nx]) return;
    var px = C.shyPx ? need * C.shyPx : 0;
    box.innerHTML = '<div class="jn-t"><img src="' + img(nx, 1) + '" alt="" width="40" height="40"><span><small>To reach <b data-i18n-skip>' + esc(C.holderNames[nx]) + '</b></small><b class="jn-amt"><span data-i18n-skip>' + fmt(need) + '</span> $SHY</b>' + (px >= 0.01 ? '<small>About $' + (px < 10 ? px.toFixed(2) : fmt(Math.round(px))) + ' right now, plus a little SOL for fees.</small>' : "") + '</span></div>' +
      '<p class="jn-how">Set $SHY as what you receive and enter this amount, or copy it.</p><div class="jn-b"><button type="button" class="btn btn-line btn-sm" data-jn-copy="' + need + '">Copy amount</button><button type="button" class="jn-x" data-jn-x aria-label="Close">&times;</button></div>';
    box.hidden = false;
    // the amount box sits at the top of the swap card: bring that into view (scrolling there also starts the swap box)
    box.scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "center" });
    setTimeout(function () { try { box.focus({ preventScroll: true }); } catch (x) {} }, 600);
  });
  document.addEventListener("click", function (e) {
    var c = e.target.closest && e.target.closest("[data-jn-copy]"), x = e.target.closest && e.target.closest("[data-jn-x]");
    if (x) { var bx = document.getElementById("jup-need"); if (bx) bx.hidden = true; return; }
    if (!c) return;
    var v = c.getAttribute("data-jn-copy"), done = function () { c.textContent = "Copied"; setTimeout(function () { c.textContent = "Copy amount"; }, 1600); };
    try { navigator.clipboard.writeText(v).then(done, done); } catch (y) { done(); }
  });
  if (amt) amt.addEventListener("input", function () { touched = true; calc(); });
  //MC 2026-10-11 a signed-in holder's box starts at their real $SHY balance (it always said 100,000), so the ranks show where they are
  var mine = null, touched = false;
  (function () {
    var pid = "", key = "";
    try { pid = localStorage.getItem("shy-lb-pid") || ""; key = localStorage.getItem("shy-lb-key") || ""; } catch (e) {}
    if (!amt || !/^[a-f0-9]{16}$/.test(pid) || !/^[a-f0-9]{32}$/.test(key)) return;
    fetch("/api/holder.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "status", pid: pid, key: key }) })
      .then(function (r) { return r.json(); }).then(function (j) {
        if (!j || !j.ok || !j.linked || !j.shy || j.shy.bal == null) return;
        mine = Math.max(0, Math.floor(+j.shy.bal || 0));
        if (!touched) amt.value = mine;
        calc();
      }).catch(function () {});
  })();
  fetch("/api/shop.php?a=catalog").then(function (r) { return r.json(); }).then(function (j) { if (j && j.ok && j.ladder) { C = j; draw(); } }).catch(function () {});
  // what the game has burned so far, next to the launch-day burn
  var g = document.getElementById("vs-game");
  if (g) fetch("/api/treasury.php").then(function (r) { return r.json(); }).then(function (j) {
    if (!j || !j.ok || !j.burns || !j.burns.shy) return;
    g.hidden = false; g.querySelector("b").textContent = fmt(j.burns.shy);
  }).catch(function () {});
})();
