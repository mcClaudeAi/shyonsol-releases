// Houses: this week's House board, your House, founding one, and any House's own page (/houses?h=TAG).
//MC 2026-10-09 clean URLs (/play, /profile, /houses); the .html links cost a redirect on every tap
(function () {
  "use strict";
  var root = document.getElementById("hs");
  if (!root) return;
  var API = "api/house.php";
  var AV = (document.querySelector('script[src*="houses.js"]') || {}).src; AV = AV && AV.indexOf("?") > 0 ? AV.slice(AV.indexOf("?")) : "";
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function hex(n) { var a = new Uint8Array(n); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ("0" + b.toString(16)).slice(-2); }).join(""); }
  var me = { pid: store("shy-lb-pid"), key: store("shy-lb-key") };
  if (!me.pid) { me.pid = hex(8); store("shy-lb-pid", me.pid); }
  if (!me.key) { me.key = hex(16); store("shy-lb-key", me.key); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function left(ts) { var s = Math.max(0, ts - Date.now() / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600); return d ? d + "d " + h + "h" : h + "h " + Math.floor(s % 3600 / 60) + "m"; }
  async function post(body) {
    try { var r = await fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.assign({ pid: me.pid, key: me.key }, body)) }); return await r.json(); }
    catch (e) { return { ok: false, error: "Can't reach the server. Check your connection." }; }
  }
  async function get(q) { try { return await (await fetch(API + "?" + q)).json(); } catch (e) { return { ok: false }; } }

  var CREST = { moon: "🌙", wave: "🌊", crane: "🕊️", fox: "🦊", dragon: "🐉", sakura: "🌸", bolt: "⚡", mountain: "🗻", sun: "☀️", oni: "👹", koi: "🎏", blade: "⚔️" };
  var ROLE = { owner: "Head of the House", officer: "Officer", member: "Member" };
  var PLACE = ["1st", "2nd", "3rd"];
  function crest(h, big) { return '<span class="hs-crest c-' + esc(h.color) + (big ? " big" : "") + '" aria-hidden="true">' + (CREST[h.crest] || "🏯") + '</span>'; }
  function face(m) {
    var src = m.img || (m.cos && /^[a-z]+$/.test(m.cos.skin || "") ? "assets/art/skins/skin_" + m.cos.skin + ".svg" + AV : "assets/art/masks/unbound.svg" + AV);
    return '<img class="hs-av' + (m.img && m.aura ? " av-aura au-" + esc(m.aura) : "") + '" src="' + esc(src) + '" alt="" loading="lazy">';
  }
  var S = { board: null, me: null, view: new URLSearchParams(location.search).get("h") || "", house: null, msg: "", form: blank() };
  //MC 2026-10-09 one place for the found-form defaults. The edit form used to share this object and kept moon/crimson, so Save overwrote the House crest and colour
  function blank() { return { crest: "moon", color: "crimson" }; }
  function days(s) { return Math.max(1, Math.ceil(s / 86400)); }

  function prizeCard() {
    var b = S.board; if (!b) return;
    document.getElementById("hs-prize").innerHTML = '<small>This week\'s prize, per member who plays</small><div class="hs-pz">' + b.prize.map(function (k, i) {
      return '<div class="p' + (i + 1) + '"><span>' + PLACE[i] + '</span><b>' + fmt(k) + '</b><em>Koban</em></div>'; }).join("") + '</div><span class="hs-end">Week ' + b.week + ' ends in <b data-i18n-skip>' + left(b.ends) + '</b></span>';
  }
  function boardH() {
    var b = S.board, rows = b.rows, mine = S.me && S.me.house ? String(S.me.house.id) : "", cool = coolH();
    var h = '<div class="hs-card"><div class="hs-h"><h2>House board</h2><span>Week ' + b.week + ' · ' + fmt(b.count) + (b.count === 1 ? " House" : " Houses") + '</span></div>';
    if (!rows.length) return h + '<p class="hs-empty">No Houses yet. Found the first one and take the top spot.</p></div>';
    h += '<ol class="hs-list">' + rows.map(function (r, i) {
      //MC 2026-10-09 during the one-switch-a-week cooldown show when they can join instead of a Join button that only errors after the tap
      var act = mine ? "" : r.size >= b.max ? '<span class="hs-full">Full</span>' : cool ? '<span class="hs-full">' + cool + '</span>' : '<button class="btn ' + (r.open ? "btn-mint" : "btn-line") + ' btn-sm" data-hs-join="' + esc(r.tag) + '">' + (r.open ? "Join" : "Ask to join") + '</button>';
      return '<li class="' + (String(r.id) === mine ? "mine" : "") + (r.pts && i < 3 ? " top t" + (i + 1) : "") + '"><span class="hs-pl">' + (r.pts ? i + 1 : "–") + '</span>' + crest(r) +
        '<a class="hs-nm" href="/houses?h=' + encodeURIComponent(r.tag) + '"><b data-i18n-skip>' + esc(r.name) + '</b><small><span class="hs-tag" data-i18n-skip>' + esc(r.tag) + '</span> <span>' + r.size + ' / ' + b.max + ' members</span>' +
        (r.top.length ? ' · <span data-i18n-skip>' + r.top.map(function (t) { return esc(t[0]); }).join(", ") + '</span>' : "") + '</small></a>' +
        '<span class="hs-pts"><b>' + fmt(r.pts) + '</b><small>pts</small></span>' + act + '</li>';
    }).join("") + '</ol>';
    if (b.last && b.last.rows.length) h += '<div class="hs-last"><span class="of-k">Week ' + b.last.week + ' winners</span>' + b.last.rows.map(function (r, i) { return '<span class="hs-lw">' + ["🥇", "🥈", "🥉"][i] + ' <b data-i18n-skip>' + esc(r.name) + '</b> <small>' + fmt(r.pts) + ' pts</small></span>'; }).join("") + '</div>';
    return h + '</div>';
  }
  function coolH() { var c = S.me && !S.me.house ? S.me.cool : 0; return c > 0 ? "Join again in " + days(c) + (days(c) === 1 ? " day" : " days") : ""; }
  function houseH(H, mineView) {
    var m = S.me || {}, role = mineView ? m.role : "", lead = role === "owner" || role === "officer";
    var url = location.origin + "/houses?h=" + encodeURIComponent(H.tag);
    var h = '<div class="hs-house c-' + esc(H.color) + '"><div class="hs-hhead">' + crest(H, true) + '<div class="hs-hid"><span class="of-k">' + (mineView ? "Your House" : "House") + (role ? ' · ' + ROLE[role] : "") + '</span><h2 data-i18n-skip>' + esc(H.name) + ' <span class="hs-tag">' + esc(H.tag) + '</span></h2>' +
      (H.desc ? '<p data-i18n-skip>' + esc(H.desc) + '</p>' : "") + '<div class="hs-chips"><span>' + H.size + ' / ' + H.max + ' members</span><span>' + (H.open ? "Anyone can join" : "Asks to join") + '</span>' + (H.tg ? '<a href="' + esc(H.tg) + '" target="_blank" rel="noopener">House chat ↗</a>' : "") + '</div></div>' +
      '<div class="hs-rank"><small>This week</small><b>' + (H.place ? "#" + H.place : "–") + '</b><span>' + fmt(H.week) + ' pts</span></div></div>';
    h += '<div class="hs-acts">' + (mineView ? '<button class="btn btn-line btn-sm" data-hs-copy="' + esc(url) + '">Copy invite link</button><a class="btn btn-line btn-sm" href="https://x.com/intent/tweet?text=' + encodeURIComponent("Join my House " + H.name + " [" + H.tag + "] in Shilluminati Online. Our points add up every week. @ShyOnSol_ $SHY\n" + url) + '" target="_blank" rel="noopener">Recruit on X</a>' +
      (lead ? '<button class="btn btn-line btn-sm" data-hs-edit>Edit House</button>' : "") + '<button class="btn btn-line btn-sm hs-leave" data-hs-leave>Leave</button>' :
      (!m.house ? (H.size >= H.max ? '<span class="hs-full">Full</span>' : coolH() ? '<span class="hs-full">' + coolH() + '</span>' : '<button class="btn btn-red" data-hs-join="' + esc(H.tag) + '">' + (H.open ? "Join this House" : "Ask to join") + '</button>') : "") + '<a class="btn btn-line btn-sm" href="/houses">All Houses</a>') + '</div>';
    if (mineView && lead && m.reqs && m.reqs.length) h += '<div class="hs-reqs"><span class="of-k">Asking to join</span>' + m.reqs.map(function (r) {
      return '<div class="hs-req"><b data-i18n-skip>' + esc(r.name) + '</b><small>' + fmt(r.points) + ' pts · ' + fmt(r.games) + ' games</small><button class="btn btn-mint btn-sm" data-hs-do="accept:' + r.id + '">Let in</button><button class="btn btn-line btn-sm" data-hs-do="decline:' + r.id + '">No</button></div>'; }).join("") + '</div>';
    if (mineView && lead && S.editing) h += editForm(H);
    h += '<ol class="hs-mem">' + H.members.map(function (x, i) {
      var manage = mineView && lead && x.role !== "owner" && x.name !== m.name ? '<details class="hs-more"><summary aria-label="More">···</summary><div>' +
        (role === "owner" ? '<button data-hs-who="' + esc(x.id) + '" data-hs-op="officer">' + (x.role === "officer" ? "Remove officer" : "Make officer") + '</button><button data-hs-who="' + esc(x.id) + '" data-hs-op="lead">Make head of the House</button>' : "") +
        (x.role !== "officer" || role === "owner" ? '<button data-hs-who="' + esc(x.id) + '" data-hs-op="kick">Remove from the House</button>' : "") + '</div></details>' : "";
      return '<li><span class="hs-mn">' + (i + 1) + '</span>' + face(x) + '<a class="hs-mname" href="/p/' + encodeURIComponent(x.slug) + '"><b data-i18n-skip>' + esc(x.name) + '</b><small>' + (x.role !== "member" ? '<span class="hs-role r-' + x.role + '">' + ROLE[x.role] + '</span> ' : "") + '<span>' + fmt(x.points) + ' pts all time</span></small></a>' +
        '<span class="hs-pts"><b>' + fmt(x.week) + '</b><small>this week</small></span>' + manage + '</li>';
    }).join("") + '</ol>';
    if (H.hist && H.hist.length) h += '<div class="hs-hist"><span class="of-k">Past weeks</span>' + H.hist.map(function (w) { return '<span class="' + (w.place <= 3 ? "medal" : "") + '">W' + w.week + ' <b>#' + w.place + '</b> <small>' + fmt(w.pts) + '</small></span>'; }).join("") + '</div>';
    return h + '</div>';
  }
  //MC 2026-10-11 each choice says what it is (the colour swatches were empty buttons to a screen reader, the crests only
  // their emoji) and which one is picked (aria-pressed); the row is a labelled group
  function picker(name, list, cur, render) {
    var nm = function (k) { k = String(k).replace(/[-_]+/g, " "); return k.charAt(0).toUpperCase() + k.slice(1); };
    return '<div class="hs-pick" data-pick="' + name + '" role="group" aria-label="' + (name === "color" ? "Colour" : "Crest") + '">' + list.map(function (k) { return '<button type="button" class="' + (k === cur ? "on" : "") + '" data-pv="' + k + '" aria-pressed="' + (k === cur) + '" aria-label="' + esc(nm(k)) + '" title="' + esc(nm(k)) + '">' + render(k) + '</button>'; }).join("") + '</div>';
  }
  function editForm(H) {
    //MC 2026-10-09 S.form is seeded from the House when Edit opens and keeps what was typed, so picking a crest no longer wipes the text or the checkbox
    var f = S.form, desc = f.desc != null ? f.desc : H.desc, tg = f.tg != null ? f.tg : H.tg, open = f.open != null ? f.open : H.open;
    return '<form class="hs-form" data-hs-editf><label>About the House<input name="desc" maxlength="140" value="' + esc(desc) + '"></label>' +
      '<label>House chat (a t.me link, optional)<input name="tg" value="' + esc(tg) + '" placeholder="https://t.me/…"></label>' +
      '<div class="hs-lab">Crest</div>' + picker("crest", S.board.crests, f.crest || H.crest, function (k) { return CREST[k]; }) +
      '<div class="hs-lab">Colour</div>' + picker("color", S.board.colors, f.color || H.color, function (k) { return '<i class="sw c-' + k + '"></i>'; }) +
      '<label class="hs-chk"><input type="checkbox" name="open"' + (open ? " checked" : "") + '> Anyone can join without asking</label><div class="hs-fb"><button class="btn btn-red btn-sm">Save</button><button type="button" class="btn btn-line btn-sm" data-hs-editx>Cancel</button></div></form>';
  }
  function foundH() {
    var m = S.me, f = S.form;
    var h = '<div class="hs-card hs-found"><div class="hs-h"><h2>Found a House</h2><span>' + (m.cost ? fmt(m.cost) + " Koban" : "Free") + '</span></div>';
    if (m.asked && m.asked.length) h += '<div class="hs-asked">' + m.asked.map(function (x) { return '<span>Waiting on <b data-i18n-skip>' + esc(x.name) + '</b> <button class="hs-x" data-hs-cancel="' + esc(x.tag) + '">Cancel</button></span>'; }).join("") + '</div>';
    if (m.games < m.needGames) return h + '<p class="hs-empty">Play ' + (m.needGames - m.games) + ' more ' + (m.needGames - m.games === 1 ? "game" : "games") + ' to found a House. You can join one any time.</p><a class="btn btn-red btn-sm" href="/play">Play now</a></div>';
    var prev = '<div class="hs-prev c-' + esc(f.color) + '">' + crest(f, true) + '<div><b data-i18n-skip>' + esc(f.name || "Your House") + '</b><span class="hs-tag" data-i18n-skip>' + esc((f.tag || "TAG").toUpperCase()) + '</span></div></div>';
    return h + prev + '<form class="hs-form" data-hs-new><div class="hs-row"><label>Name<input name="name" maxlength="24" required placeholder="House of the Rising Moon" value="' + esc(f.name || "") + '"></label><label class="hs-tagin">Tag<input name="tag" maxlength="4" required placeholder="MOON" value="' + esc(f.tag || "") + '" autocapitalize="characters"></label></div>' +
      '<label>About the House (optional)<input name="desc" maxlength="140" placeholder="Daily grinders. Live every evening UTC." value="' + esc(f.desc || "") + '"></label>' +
      '<div class="hs-lab">Crest</div>' + picker("crest", S.board.crests, f.crest, function (k) { return CREST[k]; }) +
      '<div class="hs-lab">Colour</div>' + picker("color", S.board.colors, f.color, function (k) { return '<i class="sw c-' + k + '"></i>'; }) +
      '<label class="hs-chk"><input type="checkbox" name="open"' + (f.open === false ? "" : " checked") + '> Anyone can join without asking</label>' +
      '<div class="hs-fb"><button class="btn btn-red">Found it' + (m.cost ? ' for ' + fmt(m.cost) + ' Koban' : "") + '</button><small>You have ' + fmt(m.koban) + ' Koban.</small></div></form></div>';
  }
  // ---------------------------------------------------------------- the war map
  //MC 2026-10-13 the week's standings drawn as territory on the real game map: every House with points holds a share
  //   of the 40 Regions in line with its score, grown as one landmass from a seed Region so each House reads as a
  //   country, not confetti. The map is the same assets/map.json the game plays on, drawn fresh here, and it redraws
  //   with the board, so territory shifts while the week is fought.
  var MAPC = { crimson: "#ff5d73", gold: "#f2c35b", jade: "#2ef0b0", violet: "#8b5cf6", sky: "#4cc9f0", ink: "#9f97c9" };
  var mapData = null, mapBusy = false;
  function warH() {
    var b = S.board;
    if (!b || !b.rows || !b.rows.some(function (r) { return r.pts > 0; })) return "";
    return '<div class="hs-card hs-war"><div class="hs-h"><h2>The war map</h2><span>The more points a House earns, the more of the world it holds. It redraws as the week is fought.</span></div>' +
      '<div class="hs-map" id="hs-map"></div><div class="hs-key" id="hs-key"></div></div>';
  }
  function warShade(hex, k) {   // the same colour twice: the second House wears a darker cut of it
    var n = parseInt(hex.slice(1), 16), f = function (x) { return Math.max(0, Math.min(255, Math.round(x * k))); };
    return "#" + [f(n >> 16), f(n >> 8 & 255), f(n & 255)].map(function (x) { return ("0" + x.toString(16)).slice(-2); }).join("");
  }
  function drawWar() {
    var el = document.getElementById("hs-map");
    if (!el || !S.board) return;
    if (!mapData) {
      if (mapBusy) return;
      mapBusy = true;
      fetch("assets/map.json").then(function (r) { return r.json(); }).then(function (m) { mapBusy = false; mapData = m; drawWar(); }).catch(function () { mapBusy = false; });
      return;
    }
    var m = mapData, names = Object.keys(m.regions), R = m.regions;
    var rows = S.board.rows.filter(function (r) { return r.pts > 0; }).slice(0, 8);
    if (!rows.length) return;
    var total = rows.reduce(function (s, r) { return s + r.pts; }, 0);
    var quota = rows.map(function (r) { return Math.max(1, Math.round(r.pts / total * names.length)); });
    for (var g = quota.reduce(function (s, q) { return s + q; }, 0) - names.length; g > 0; g--) {   // over-rounded: trim the biggest
      var bi = 0; quota.forEach(function (q, i) { if (q > quota[bi]) bi = i; });
      if (quota[bi] > 1) quota[bi]--;
    }
    var dist = function (a, b) { var dx = a[0] - b[0], dy = a[1] - b[1]; return dx * dx + dy * dy; };
    var area = function (n) { var b = R[n].b; return (b[1][0] - b[0][0]) * (b[1][1] - b[0][1]); };
    // seeds: the leader takes the biggest Region, each next House lands as far from the others as it can
    var own = {}, seeds = [];
    rows.forEach(function (r, i) {
      var best = null, bs = -1;
      names.forEach(function (n) {
        if (own[n] != null) return;
        var s = seeds.length ? Math.min.apply(null, seeds.map(function (x) { return dist(R[n].c, R[x].c); })) : area(n);
        if (s > bs) { bs = s; best = n; }
      });
      seeds.push(best); own[best] = i;
    });
    // grow in rank order, one Region a round, always the nearest unclaimed one, so each House stays one landmass
    var mine = rows.map(function (_, i) { return [seeds[i]]; }), need = quota.map(function (q) { return q - 1; });
    var open = names.filter(function (n) { return own[n] == null; });
    while (open.length && need.some(function (x) { return x > 0; })) {
      var moved = false;
      for (var i = 0; i < rows.length; i++) {
        if (!need[i] || !open.length) continue;
        var bj = 0, bd = Infinity;
        open.forEach(function (n, j) {
          var d = Math.min.apply(null, mine[i].map(function (x) { return dist(R[n].c, R[x].c); }));
          if (d < bd) { bd = d; bj = j; }
        });
        var took = open.splice(bj, 1)[0];
        own[took] = i; mine[i].push(took); need[i]--; moved = true;
      }
      if (!moved) break;
    }
    var used = {}, fill = rows.map(function (r) {
      var c = MAPC[r.color] || MAPC.crimson, k = used[c] = (used[c] || 0) + 1;
      return k === 1 ? c : warShade(c, 1 - 0.28 * (k - 1));
    });
    var paths = names.map(function (n) {
      var i = own[n], r = R[n];
      if (i == null) return '<path d="' + r.d + '" fill="url(#hswop)" stroke="#0b0724" stroke-width="1.6" stroke-linejoin="round"><title>' + esc(n) + '</title></path>';
      return '<path d="' + r.d + '" fill="' + fill[i] + '" fill-opacity=".88" stroke="#0b0724" stroke-width="1.6" stroke-linejoin="round" data-hs-land="' + esc(rows[i].tag) + '"><title>' + esc(n + " · " + rows[i].name + " · " + fmt(rows[i].pts) + " pts") + '</title></path>';
    }).join("");
    var pins = rows.map(function (r, i) {
      var c = R[seeds[i]].c;
      return '<g transform="translate(' + c[0] + ' ' + c[1] + ')" class="hs-pin"><circle r="15" fill="rgba(11,7,36,.8)" stroke="#fff" stroke-width="2.4"/><text y="6" text-anchor="middle" font-size="17">' + (CREST[r.crest] || "🏯") + '</text></g>';
    }).join("");
    el.innerHTML = '<svg viewBox="0 0 ' + m.w + " " + m.h + '" role="img" aria-label="This week\'s House standings drawn as territory">' +
      '<defs><pattern id="hswop" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="9" height="9" fill="#2b2266"/><rect width="3.5" height="9" fill="#3a2f84"/></pattern>' +
      '<radialGradient id="hswsea" cx="50%" cy="40%" r="75%"><stop offset="0" stop-color="#2a1f6b"/><stop offset=".6" stop-color="#170f43"/><stop offset="1" stop-color="#0b0724"/></radialGradient></defs>' +
      '<rect width="' + m.w + '" height="' + m.h + '" fill="url(#hswsea)" rx="14"/><path d="' + m.grat + '" fill="none" stroke="rgba(160,140,255,.13)" stroke-width=".8"/>' + paths + pins + '</svg>';
    document.getElementById("hs-key").innerHTML = rows.map(function (r, i) {
      return '<a class="hs-kc" href="/houses?h=' + encodeURIComponent(r.tag) + '"><i style="background:' + fill[i] + '"></i><b data-i18n-skip>' + esc(r.name) + '</b><small>' + mine[i].length + ' Regions · ' + fmt(r.pts) + ' pts</small></a>';
    }).join("") + '<span class="hs-kc hs-ku"><i></i><b>Unclaimed</b><small>No points yet</small></span>';
  }
  function render() {
    prizeCard();
    if (!S.board) return;
    var h = S.msg ? '<p class="hs-msg">' + esc(S.msg) + '</p>' : "";
    //MC 2026-10-09 compare ids as strings, the API can send an all-digit id as a number
    if (S.view && S.house) h += houseH(S.house, !!(S.me && S.me.house && String(S.me.house.id) === String(S.house.id)));
    else if (S.me && S.me.house) h += houseH(S.me.house, true);
    h += warH();
    h += '<div class="hs-grid' + (S.me && !S.me.house && !S.view ? "" : " one") + '">' + boardH() + (S.me && !S.me.house && !S.view ? foundH() : "") + '</div>';
    root.innerHTML = h;
    drawWar();
  }
  async function load() {
    var r = await Promise.all([get("a=board"), post({ a: "me" }), S.view ? get("a=get&h=" + encodeURIComponent(S.view)) : Promise.resolve(null)]);
    if (!r[0].ok) { root.innerHTML = '<p class="hs-empty">Couldn\'t load the Houses. Try again in a minute.</p>'; return; }
    S.board = r[0]; S.me = r[1].ok ? r[1].me : null; S.house = r[2] && r[2].ok ? r[2].house : null;
    if (S.view && !S.house) S.msg = "No House by that name. Here are all of them.";
    if (S.house) document.title = S.house.name + " [" + S.house.tag + "] | Houses | Shy on Solana";
    render();
  }
  async function act(body, ok) {
    var j = await post(body);
    if (!j.ok) { S.msg = j.error || "That didn't work. Try again."; render(); return; }
    S.me = j.me; S.msg = ok || ""; if (S.editing) S.form = blank(); S.editing = false;
    var b = await get("a=board"); if (b.ok) S.board = b;
    if (S.view) { var hv = await get("a=get&h=" + encodeURIComponent(S.view)); S.house = hv.ok ? hv.house : null; }
    //MC 2026-10-09 the last one out closes the House, so drop the dead ?h= view and its title instead of leaving the page pointing at nothing
    if (S.view && !S.house) { S.view = ""; try { history.replaceState(null, "", location.pathname); } catch (e) {} document.title = "Houses | Shy on Solana"; }
    render();
  }

  //MC 2026-10-09 the confirm now says what leaving costs: the join cooldown, and the House closing if you're the last one in it
  function leaveH() {
    var m = S.me || {}, H = m.house || {}, c = m.cool > 0 ? days(m.cool) : 0, t = "Tap again to leave";
    if (c) t = "Leave? You can't join another House for " + c + (c === 1 ? " day" : " days");
    if (H.size === 1) t += c ? " and the House closes" : ". The House closes";
    return t;
  }
  root.addEventListener("click", function (e) {
    var b;
    if ((b = e.target.closest("[data-hs-join]"))) { act({ a: "join", h: b.dataset.hsJoin }, "Done."); return; }
    if ((b = e.target.closest("[data-hs-cancel]"))) { act({ a: "cancel", h: b.dataset.hsCancel }); return; }
    if ((b = e.target.closest("[data-hs-leave]"))) { if (b.dataset.sure) act({ a: "leave" }, "You left the House."); else { b.dataset.sure = 1; b.textContent = leaveH(); } return; }
    if ((b = e.target.closest("[data-hs-edit]"))) { var H0 = S.view && S.house ? S.house : S.me.house; S.form = { crest: H0.crest, color: H0.color, desc: H0.desc, tg: H0.tg, open: H0.open }; S.editing = true; render(); return; }
    if ((b = e.target.closest("[data-hs-editx]"))) { S.form = blank(); S.editing = false; render(); return; }
    if ((b = e.target.closest("[data-hs-do]"))) { var p = b.dataset.hsDo.split(":"); act({ a: p[0], who: p[1] }); return; }
    if ((b = e.target.closest("[data-hs-op]"))) { act({ a: b.dataset.hsOp, who: b.dataset.hsWho }); return; }
    if ((b = e.target.closest("[data-pv]"))) { var pk = b.closest("[data-pick]").dataset.pick; S.form[pk] = b.dataset.pv; var form = b.closest("form");
      if (form) { S.form.desc = form.desc.value; S.form.open = form.open.checked; if (form.matches("[data-hs-new]")) { S.form.name = form.name.value; S.form.tag = form.tag.value; } else S.form.tg = form.tg.value; }
      render(); return; }
    if ((b = e.target.closest("[data-hs-copy]"))) { var t = b.textContent, done = function () { b.textContent = "Link copied"; setTimeout(function () { b.textContent = t; }, 1600); }; if (navigator.clipboard) navigator.clipboard.writeText(b.dataset.hsCopy).then(done, done); else done(); }
  });
  root.addEventListener("input", function (e) {
    var f = e.target.closest("[data-hs-new]"); if (!f) return;
    S.form.name = f.name.value; S.form.tag = f.tag.value.toUpperCase();
    var pv = root.querySelector(".hs-prev"); if (pv) { pv.querySelector("b").textContent = S.form.name || "Your House"; pv.querySelector(".hs-tag").textContent = S.form.tag || "TAG"; }
  });
  root.addEventListener("submit", function (e) {
    var f = e.target; e.preventDefault();
    if (f.matches("[data-hs-new]")) act({ a: "create", name: f.name.value, tag: f.tag.value, desc: f.desc.value, open: f.open.checked, crest: S.form.crest, color: S.form.color }, "Your House is open. Share the invite link to fill it.");
    if (f.matches("[data-hs-editf]")) act({ a: "edit", desc: f.desc.value, tg: f.tg.value, open: f.open.checked, crest: S.form.crest, color: S.form.color }, "Saved.");
  });
  //MC 2026-10-13 a tap on a territory opens that House's page
  root.addEventListener("click", function (e) {
    var p = e.target.closest("[data-hs-land]");
    if (p) location.href = "/houses?h=" + encodeURIComponent(p.dataset.hsLand);
  });
  load();
  //MC 2026-10-13 the board refreshes itself each minute, so the prize clock and the war map stay live without
  //   touching the forms the rest of the page may have open
  setInterval(async function () {
    if (document.hidden || !S.board) return;
    var b = await get("a=board");
    if (b.ok) { S.board = b; prizeCard(); drawWar(); }
  }, 60000);
})();
