// The Treasury page: prize payouts with their Solana transactions, the weekly pools, the community wallet and other moves.
(function () {
  "use strict";
  var kp = document.getElementById("ts-kpis");
  if (!kp) return;
  var L = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || undefined;   //MC 2026-10-09 Persian dates: Latin digits, Gregorian calendar
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function usd(n, dec) { return "$" + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: dec ? 2 : 0, maximumFractionDigits: dec ? 2 : 0 }); }
  function big(n) { n = +n || 0; return n >= 1e9 ? (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B" : n >= 1e6 ? (n / 1e6).toFixed(2).replace(/\.?0+$/, "") + "M" : n >= 1e4 ? (n / 1e3).toFixed(1).replace(/\.0$/, "") + "K" : fmt(Math.round(n)); }
  function day(ts) { return new Date(ts * 1000).toLocaleDateString(L, { month: "short", day: "numeric", year: "numeric" }); }
  function left(ts) { var s = Math.max(0, ts - Date.now() / 1000), d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600); return d ? d + "d " + h + "h" : h + "h " + Math.floor(s % 3600 / 60) + "m"; }
  var D = null, filt = "", shown = 12;
  var MOVE = { buy: ["🪙", "Bought $SHY for the prize pool"], burn: ["🔥", "Burned $SHY"], lp: ["💧", "Added liquidity"], marketing: ["📣", "Marketing"], other: ["📄", "Other"] };
  var PLACE = ["", "1st", "2nd", "3rd"];

  //MC 2026-10-13 the totals count up when they first land, the way the burn tracker's do. One queue per render:
  //   cnt() writes a span and remembers the goal, runCnt() rolls every span from 0 to its goal in under a second.
  //   Only the first render animates (a refresh snapping numbers around would read as a glitch), and anyone who asked
  //   their system for reduced motion gets the finished number straight away.
  var reduced = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var cntQ = [], cntN = 0, firstPaint = true;
  function cnt(val, f) {
    val = +val || 0;
    if (reduced || !firstPaint || val <= 0) return '<span data-i18n-skip>' + f(val) + "</span>";
    var id = "ts-cnt" + (++cntN);
    cntQ.push([id, val, f]);
    return '<span id="' + id + '" data-i18n-skip>' + f(0) + "</span>";
  }
  function runCnt() {
    var q = cntQ; cntQ = [];
    if (!q.length) return;
    var t0 = performance.now(), MS = 900;
    (function step(now) {
      var k = Math.min(1, (now - t0) / MS), e = 1 - Math.pow(1 - k, 3);
      q.forEach(function (c) { var el = document.getElementById(c[0]); if (el) el.textContent = c[2](c[1] * e); });
      if (k < 1) requestAnimationFrame(step);
    })(t0);
  }
  // rows that arrived since the last look get a short glow, so a refresh shows what is new
  var seenSig = null;
  function mark(el) {
    if (!seenSig) return;
    el.querySelectorAll("a.ts-tx").forEach(function (a) {
      var m = (a.getAttribute("href") || "").match(/tx\/([^?#]+)/);
      if (m && !seenSig[decodeURIComponent(m[1])]) a.closest("li").classList.add("ts-new");
    });
  }
  function sigs() {
    var s = {};
    [].concat(D.payouts || [], D.moves || [], (D.burns && D.burns.list) || []).forEach(function (r) { if (r.sig) s[r.sig] = 1; });
    return s;
  }

  function kpis() {
    var t = D.totals, n = D.now, w = D.wallet;
    kp.innerHTML =
      '<div class="ts-kpi hot"><small>Paid to players</small><b>' + cnt(t.shy, big) + ' <em>$SHY</em></b><span>' + (t.usd ? "Worth " + usd(t.usd) + " when sent" : "The first prizes go out after week one") + '</span></div>' +
      '<div class="ts-kpi"><small>Prizes sent</small><b>' + cnt(t.payouts, function (v) { return fmt(Math.round(v)); }) + '</b><span>' + fmt(t.winners) + (t.winners === 1 ? " winner" : " winners") + ' over ' + fmt(t.weeks) + (t.weeks === 1 ? " week" : " weeks") + '</span></div>' +
      '<div class="ts-kpi"><small>This week\'s League pool</small><b>' + cnt(n.league, function (v) { return usd(v); }) + '</b><span>' + (n.fromShop ? usd(n.fromShop, 1) + " of it from shop sales · " : "") + 'Ends in <span data-i18n-skip>' + left(n.ends) + '</span></span></div>' +
      '<div class="ts-kpi"><small>Community wallet</small><b>' + (w.shy != null ? cnt(w.shy, big) + ' <em>$SHY</em>' : "–") + '</b><span>' + (w.usd ? "About " + usd(w.usd) + " today" : "Held for prizes and growth") + '</span></div>';
    var sh = document.getElementById("ts-share"); if (sh && n.share) sh.textContent = n.share + "% of sales";
    var bal = document.getElementById("ts-bal");
    if (bal) bal.innerHTML = w.shy != null ? '<b>' + fmt(w.shy) + ' <em>$SHY</em></b><small>' + (w.usd ? "About " + usd(w.usd) + " at today's price" : "") + '</small>' : '<small>Balance unavailable right now.</small>';
  }
  function chart() {
    var el = document.getElementById("ts-chart");
    var P = (D.pools || []).slice(0, 12).reverse();
    if (!P.length) { el.innerHTML = '<p class="ts-empty">The first week\'s pool shows here when it closes.</p>'; return; }
    var max = Math.max.apply(null, P.map(function (p) { return p.league; })) || 1;
    // the top of the scale is the next tidy value (1, 2, 2.5 or 5 times a power of ten), so the gridlines read as real amounts
    var pw = Math.pow(10, Math.floor(Math.log10(max))), top = [1, 2, 2.5, 5, 10].map(function (k) { return k * pw; }).filter(function (v) { return v >= max; })[0];
    var grid = [1, 0.5, 0].map(function (f) { return '<span class="ts-gl" style="bottom:' + (f * 100) + '%"><i>' + usd(top * f) + '</i></span>'; }).join("");
    el.innerHTML = '<div class="ts-plot"><div class="ts-area">' + grid + P.map(function (p) {
      return '<div class="ts-col" title="Week ' + p.week + ': ' + usd(p.league, 1) + '"><div class="ts-bar" style="height:' + (p.league / top * 100) + '%"><span class="ts-shop" style="height:' + (p.league ? p.fromShop / p.league * 100 : 0) + '%"></span></div></div>';
    }).join("") + '</div><div class="ts-xl">' + P.map(function (p) { return '<span><b>' + usd(p.league) + '</b><small>W' + p.week + '</small></span>'; }).join("") + '</div></div>' +
      '<div class="ts-key"><span><i class="k-base"></i>Fixed weekly prize</span><span><i class="k-shop"></i>From shop sales</span></div>';
  }
  function pays() {
    var el = document.getElementById("ts-pay");
    var rows = (D.payouts || []).filter(function (r) { return !filt || r.what.indexOf(filt) === 0; });
    if (!rows.length) { el.innerHTML = '<p class="ts-empty">' + (D.payouts.length ? "No prizes of this kind yet." : "No prizes sent yet. The first week closes Monday 00:00 UTC, and its winners show here with their transactions.") + '</p>'; return; }
    var more = rows.length - shown; rows = rows.slice(0, shown);
    el.innerHTML = '<ul class="ts-list">' + rows.map(function (r) {
      var slug = String(r.name || "").replace(/ /g, "_");
      return '<li><span class="ts-pl p' + Math.min(r.place, 4) + '">' + (PLACE[r.place] || (r.place ? r.place + "th" : "")) + '</span>' +
        '<div class="ts-who">' + (r.name ? '<a href="/p/' + encodeURIComponent(slug) + '" data-i18n-skip>' + esc(r.name) + '</a>' : '<span>Winner</span>') + '<small>' + (/^15 Club/.test(r.what) ? '<span data-i18n-skip>' + esc(r.what) + '</span>' : esc(r.what)) + ' · <span data-i18n-skip>' + day(r.t) + '</span></small></div>' +
        '<div class="ts-amt"><b>' + fmt(Math.round(r.shy)) + ' <em>$SHY</em></b>' + (r.usd ? '<small>' + usd(r.usd, 1) + '</small>' : "") + '</div>' +
        '<a class="ts-tx" href="https://solscan.io/tx/' + encodeURIComponent(r.sig) + '" target="_blank" rel="noopener" title="See it on Solscan">Solscan <span aria-hidden="true">↗</span></a></li>';
    }).join("") + '</ul>' + (more > 0 ? '<button class="btn btn-line btn-sm ts-more" data-tr-more>Show ' + Math.min(more, 24) + ' more</button>' : "");
  }
  function moves() {
    var M = D.moves || []; if (!M.length) return;
    document.getElementById("ts-moves-sec").hidden = false;
    document.getElementById("ts-moves").innerHTML = '<ul class="ts-list">' + M.map(function (m) {
      var k = MOVE[m.kind] || MOVE.other;
      return '<li><span class="ts-ic" aria-hidden="true">' + k[0] + '</span><div class="ts-who"><span>' + k[1] + '</span><small>' + (m.note ? esc(m.note) + ' · ' : "") + '<span data-i18n-skip>' + day(m.t) + '</span></small></div>' +
        '<div class="ts-amt">' + (m.shy ? '<b>' + fmt(Math.round(m.shy)) + ' <em>$SHY</em></b>' : "") + (m.usd ? '<small>' + usd(m.usd, 1) + '</small>' : "") + '</div>' +
        '<a class="ts-tx" href="https://solscan.io/tx/' + encodeURIComponent(m.sig) + '" target="_blank" rel="noopener">Solscan <span aria-hidden="true">↗</span></a></li>';
    }).join("") + '</ul>';
  }
  //MC 2026-10-10 the burn: total burned through the shop and each burn with its transaction
  function burns() {
    var B = D.burns; if (!B || (!B.n && !B.pct)) return;
    document.getElementById("ts-burn-sec").hidden = false;
    document.getElementById("ts-burn-top").innerHTML = '<div class="ts-burn-big"><i class="chip-fire" aria-hidden="true"></i><span class="ts-embers" aria-hidden="true"><i></i><i></i><i></i></span><div><b>' + cnt(B.shy, function (v) { return fmt(Math.round(v)); }) + ' <em>$SHY</em></b><small>' + (B.n ? "burned in " + fmt(B.n) + (B.n === 1 ? " payment" : " payments") : "Nothing burned yet. The first $SHY purchase starts it.") + '</small></div></div>' +
      (B.pct ? '<p>' + B.pct + '% of every $SHY payment in the Dojo Shop is burned in the buyer\'s own transaction, so it never passes through anyone\'s hands. Each one links to its proof on Solana.</p>' : "");
    document.getElementById("ts-burns").innerHTML = (B.list || []).length ? '<ul class="ts-list">' + B.list.map(function (b) {
      return '<li><span class="ts-ic" aria-hidden="true">🔥</span><div class="ts-who">' + (b.name ? '<span data-i18n-skip>' + esc(b.name) + '</span>' : "<span>A player</span>") + '<small><span data-i18n-skip>' + esc(b.what) + '</span> · <span data-i18n-skip>' + day(b.t) + '</span></small></div>' +
        '<div class="ts-amt"><b>' + fmt(Math.round(b.shy)) + ' <em>$SHY</em></b></div><a class="ts-tx" href="https://solscan.io/tx/' + encodeURIComponent(b.sig) + '" target="_blank" rel="noopener">Solscan <span aria-hidden="true">↗</span></a></li>';
    }).join("") + '</ul>' : "";
  }
  document.getElementById("ts-pay").addEventListener("click", function (e) { if (e.target.closest("[data-tr-more]")) { shown += 24; pays(); } });
  document.getElementById("ts-tabs").addEventListener("click", function (e) {
    var b = e.target.closest("button"); if (!b) return;
    filt = b.dataset.k; shown = 12; this.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); }); if (D) pays();
  });
  function draw() {
    kpis(); chart(); pays(); moves(); burns();
    runCnt();
    ["ts-pay", "ts-moves", "ts-burns"].forEach(function (id) { var el = document.getElementById(id); if (el) mark(el); });
    seenSig = sigs();
    firstPaint = false;
  }
  function pull(first) {
    return fetch("api/treasury.php").then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok) throw 0;
      D = j; draw();
    }).catch(function () { if (first) document.getElementById("ts-pay").innerHTML = '<p class="ts-empty">Couldn\'t load the Treasury just now. Try again in a minute.</p>'; });
  }
  pull(true);
  //MC 2026-10-13 the page stays live: a fresh pull every minute while it's open, and rows that arrived glow once
  setInterval(function () {
    if (document.hidden || !D) return;
    pull(false);
  }, 60000);
  document.addEventListener("visibilitychange", function () { if (!document.hidden && D) pull(false); });
})();
