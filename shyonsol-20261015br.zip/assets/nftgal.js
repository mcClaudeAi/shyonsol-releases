//MC 2026-10-13 the living gallery on the NFTs page: every Shadow the site has met (api/holder.php?a=gallery), with
//   filters by aura, a sort by rarity or record, and a Try button that sends that exact Shadow into a free solo game
//   (the same sessionStorage handshake the lobby's Try a Shadow uses). The section stays hidden until there is
//   something real to show, so a fresh site never shows an empty shelf.
(function () {
  "use strict";
  var sec = document.getElementById("ng-sec");
  if (!sec) return;
  var grid = document.getElementById("ng-grid"), bar = document.getElementById("ng-bar");
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  var AURA = { "crimson glow": "crimson", "electric cyan": "cyan", "lightning aura": "lightning", "money aura": "money", "btc aura": "btc" };
  var D = null, aura = "", sort = "rank", shown = 24;
  function rows() {
    var r = (D.rows || []).filter(function (x) { return !aura || x.aura.toLowerCase() === aura; });
    r = r.slice();
    if (sort === "wins") r.sort(function (a, b) { return b.wins - a.wins || b.games - a.games || (a.rank || 9999) - (b.rank || 9999); });
    else r.sort(function (a, b) { return (a.rank || 9999) - (b.rank || 9999) || b.wins - a.wins; });
    return r;
  }
  function barH() {
    var chips = '<div class="ng-f" role="group" aria-label="Aura">' +
      '<button class="' + (aura ? "" : "on") + '" data-ng-aura="">All auras</button>' +
      Object.keys(D.auras || {}).sort().map(function (a) {
        var k = a.toLowerCase();
        return '<button class="' + (aura === k ? "on" : "") + '" data-ng-aura="' + esc(k) + '"><i class="ng-dot au-' + (AURA[k] || "none") + '" aria-hidden="true"></i><span data-i18n-skip>' + esc(a) + '</span> <small>' + D.auras[a] + '</small></button>';
      }).join("") + '</div>' +
      '<div class="ng-f" role="group" aria-label="Order"><button class="' + (sort === "rank" ? "on" : "") + '" data-ng-sort="rank">Rarest first</button><button class="' + (sort === "wins" ? "on" : "") + '" data-ng-sort="wins">Most decorated</button></div>';
    bar.innerHTML = chips;
  }
  function card(x) {
    var k = x.aura.toLowerCase();
    return '<div class="ng-c">' +
      '<span class="ng-img au-' + (AURA[k] || "none") + '"><img src="' + esc(x.img) + '" alt="Shadow #' + esc(x.n) + '" loading="lazy" decoding="async"></span>' +
      '<div class="ng-meta"><b data-i18n-skip>#' + esc(x.n) + '</b>' + (x.rank ? '<small>Rarity #' + fmt(x.rank) + '</small>' : "") + '</div>' +
      (x.aura ? '<span class="ng-aura"><i class="ng-dot au-' + (AURA[k] || "none") + '" aria-hidden="true"></i><span data-i18n-skip>' + esc(x.aura) + '</span></span>' : '<span class="ng-aura ng-mut">No aura trait</span>') +
      '<small class="ng-rec">' + (x.games ? fmt(x.wins) + " wins in " + fmt(x.games) + " games" : "No games yet") + '</small>' +
      '<button class="btn btn-line btn-sm" data-ng-try="' + esc(x.n) + '" data-src="' + esc(x.img) + '">Try this Shadow</button></div>';
  }
  function draw() {
    var r = rows(), more = r.length - shown;
    grid.innerHTML = r.slice(0, shown).map(card).join("") +
      (more > 0 ? '<button class="btn btn-line ng-more" data-ng-more>Show ' + fmt(Math.min(more, 24)) + ' more</button>' : "");
  }
  sec.addEventListener("click", function (e) {
    var b;
    if ((b = e.target.closest("[data-ng-aura]")) !== null && b !== undefined) { aura = b.dataset.ngAura; shown = 24; barH(); draw(); return; }
    if ((b = e.target.closest("[data-ng-sort]"))) { sort = b.dataset.ngSort; shown = 24; barH(); draw(); return; }
    if ((b = e.target.closest("[data-ng-more]"))) { shown += 24; draw(); return; }
    if ((b = e.target.closest("[data-ng-try]"))) {
      try { sessionStorage.setItem("shy-try", JSON.stringify({ n: String(b.dataset.ngTry), src: b.dataset.src })); } catch (x) {}
      location.href = "/play#game";
    }
  });
  var later = window.requestIdleCallback ? function (f) { requestIdleCallback(f, { timeout: 2000 }); } : function (f) { setTimeout(f, 600); };
  later(function () {
    fetch("api/holder.php?a=gallery").then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok || !j.total) return;   // nothing met yet: the section stays hidden
      D = j; sec.hidden = false; barH(); draw();
    }).catch(function () {});
  });
})();
