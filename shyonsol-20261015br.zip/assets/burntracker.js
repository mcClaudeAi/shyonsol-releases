//MC 2026-10-13 the live burn tracker on the Token page (section #bt in build.py), fed by api/treasury.php, which caches
//   for five minutes server side and sends Cache-Control 60s, so this costs the server next to nothing. The total counts
//   up when the panel first scrolls in, the bar shows how much of all $SHY ever minted is gone, the feed links every
//   burn to its transaction on Solscan, and embers rise over the panel only while it is on screen. Reduced motion gets
//   final numbers with nothing moving. Refreshes once a minute while the tab is open.
(function () {
  "use strict";
  var root = document.getElementById("bt");
  if (!root) return;
  var reduce = false; try { reduce = matchMedia("(prefers-reduced-motion: reduce)").matches; } catch (e) {}
  var small = false; try { small = matchMedia("(max-width: 480px)").matches; } catch (e) {}
  var SUPPLY = 1000000000, FOUNDING = 500000000;
  var $ = function (id) { return document.getElementById(id); };
  var fmt = function (n) { return Number(n || 0).toLocaleString("en-US"); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var LANG = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || "en";
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t));
    try {
      var f = new Intl.RelativeTimeFormat(LANG, { numeric: "auto", style: "narrow" });
      if (s < 3600) return f.format(-Math.max(1, Math.floor(s / 60)), "minute");
      if (s < 86400) return f.format(-Math.floor(s / 3600), "hour");
      return f.format(-Math.floor(s / 86400), "day");
    } catch (e) { return ""; }
  }

  var shown = false, total = FOUNDING, counted = false;
  function draw(d) {
    var burns = (d && d.burns) || { shy: 0, n: 0, pct: 0, list: [] };
    total = FOUNDING + (burns.shy || 0);
    var pct = 100 * total / SUPPLY;
    if (counted || reduce || !shown) $("bt-n").textContent = fmt(Math.round(total));
    $("bt-pct").textContent = pct.toFixed(2) + "%";
    $("bt-fill").style.width = Math.min(100, pct).toFixed(2) + "%";
    if (burns.pct > 0) { $("bt-share").hidden = false; $("bt-share-n").textContent = burns.pct + "%"; }
    //MC 2026-10-13 the founding burn card fills from the chain via the server: the signer wallet and the exact day
    if (d && d.founding && d.founding.wallet) {
      var fw = document.querySelector(".bt-f-wallet");
      if (fw) { fw.hidden = false; fw.textContent = d.founding.wallet.slice(0, 4) + "…" + d.founding.wallet.slice(-4); fw.title = d.founding.wallet; }
      if (d.founding.t) { var fwh = document.querySelector(".bt-f-when"); if (fwh) try { fwh.textContent = new Date(d.founding.t * 1000).toLocaleDateString(LANG, { month: "short", day: "numeric", year: "numeric" }); } catch (e) {} }
    }
    feed = burns.list || [];
    drawFeed();
  }
  //MC 2026-10-13 the whole burn history, paged client side: 10 a page, 5 on phones, newest first
  var feed = [], pg = 0;
  function drawFeed() {
    var per = small ? 5 : 10, pages = Math.max(1, Math.ceil(feed.length / per));
    if (pg >= pages) pg = pages - 1; if (pg < 0) pg = 0;
    var pager = $("bt-pager");
    if (pager) { pager.hidden = pages <= 1; $("bt-pg").textContent = (pg + 1) + " / " + pages; pager.querySelector('[data-bpg="-1"]').disabled = pg === 0; pager.querySelector('[data-bpg="1"]').disabled = pg >= pages - 1; }
    var list = feed.slice(pg * per, pg * per + per);
    if (list.length) {
      $("bt-list").innerHTML = list.map(function (x) {
        var who = [x.what, x.name].filter(Boolean).join(" · ");
        var inner = '<span class="bt-flame" aria-hidden="true">🔥</span><b data-i18n-skip>' + fmt(Math.round(x.shy)) + ' $SHY</b>' +
          (who ? '<span class="bt-who" data-i18n-skip>' + esc(who) + '</span>' : "") +
          '<time data-i18n-skip>' + esc(ago(x.t)) + '</time>';
        //MC 2026-10-13 a treasury-move burn logged without its signature still shows, it just has nowhere to link
        if (!x.sig) return '<li><span class="bt-row">' + inner + '</span></li>';
        return '<li><a href="https://solscan.io/tx/' + esc(x.sig) + '" target="_blank" rel="noopener" title="View the transaction">' + inner + '</a></li>';
      }).join("");
    }
  }
  var pager0 = $("bt-pager");
  if (pager0) pager0.addEventListener("click", function (e) {
    var b = e.target.closest("[data-bpg]"); if (!b) return;
    pg += +b.dataset.bpg; drawFeed();
  });
  function load() {
    fetch("api/treasury.php", { cache: "default" }).then(function (r) { return r.json(); })
      .then(function (j) { if (j && j.ok) draw(j); }).catch(function () {});
  }

  // count the total up the first time the panel is seen, and light the embers only while it is on screen
  function countUp() {
    if (counted) return; counted = true;
    if (reduce) { $("bt-n").textContent = fmt(Math.round(total)); return; }
    var el = $("bt-n"), t0 = performance.now();
    requestAnimationFrame(function step(t) {
      var k = Math.min(1, (t - t0) / 1800), e = 1 - Math.pow(1 - k, 3);
      el.textContent = fmt(Math.round(total * e));
      if (k < 1) requestAnimationFrame(step); else el.textContent = fmt(Math.round(total));
    });
  }
  if (!reduce) {
    var n = small ? 6 : 10;
    for (var i = 0; i < n; i++) {
      var s = document.createElement("i");
      s.className = "ember";
      s.style.setProperty("--x", (4 + Math.random() * 92).toFixed(1) + "%");
      s.style.setProperty("--d", (2.8 + Math.random() * 3).toFixed(2) + "s");
      s.style.setProperty("--w", (Math.random() * 18 - 9).toFixed(1) + "px");
      s.style.setProperty("--s", (0.5 + Math.random() * 0.8).toFixed(2));
      s.style.animationDelay = (Math.random() * 3).toFixed(2) + "s";
      root.appendChild(s);
    }
    root.classList.add("emberbox");
  }
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        root.classList.toggle("burning", e.isIntersecting);
        if (e.isIntersecting && !shown) { shown = true; countUp(); }
      });
    }, { rootMargin: "40px 0px" });
    io.observe(root);
  } else { shown = true; countUp(); }
  // a tap on the total flares it, a tiny thing people find by accident
  $("bt-n").addEventListener("click", function () { if (reduce) return; root.classList.remove("bt-flare"); void root.offsetWidth; root.classList.add("bt-flare"); });

  load();
  setInterval(function () { if (!document.hidden) load(); }, 60000);
})();
