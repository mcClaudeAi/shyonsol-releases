// The Fair page: every Daily seal for the week ahead, every opened day, and a checker for live and Shogun matches.
// Everything is checked here in the browser with the same game engine the site plays with (assets/game.js), so the
// page doesn't have to be trusted either. The rules are in api/fairlib.php.
//MC 2026-10-15 first version: Daily seals and proofs, live match seals, and the opening deal rebuilt from the seed
(function () {
  "use strict";
  var G = window.ShyGame, $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  async function sha256(text) {
    var buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
  }
  function fmtDay(d) { var t = new Date(d + "T00:00:00Z"); return t.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", timeZone: "UTC" }); }
  function ago(ts) { var s = Math.max(1, Math.round(Date.now() / 1000 - ts)); return s < 3600 ? Math.round(s / 60) + "m ago" : s < 86400 ? Math.round(s / 3600) + "h ago" : Math.round(s / 86400) + "d ago"; }
  function cardName(id) { return G && G.CARDS[id] ? G.CARDS[id].name : id; }

  // ---------- the Daily ----------
  async function daily() {
    var box = $("fr-daily"); if (!box) return;
    var j;
    try { j = await (await fetch("/api/fair.php?a=daily", { cache: "no-store" })).json(); } catch (e) { box.innerHTML = '<p class="fr-note">Couldn\'t load the seals just now. Refresh to try again.</p>'; return; }
    if (!j.ok || !j.days || !j.days.length) { box.innerHTML = '<p class="fr-note">Sealed Dailies start ' + (j.since ? fmtDay(j.since) : "soon") + '.</p>'; return; }
    box.innerHTML = '<div class="fr-rows">' + j.days.slice().reverse().map(function (d) {
      var open = !!d.proof, now = d.day === j.today;
      return '<div class="fr-row' + (open ? " open" : "") + (now ? " now" : "") + '" data-day="' + esc(d.day) + '">' +
        '<div class="fr-when"><b>Daily #' + d.no + '</b><small>' + fmtDay(d.day) + (now ? " · today" : open ? "" : " · ahead") + '</small></div>' +
        '<div class="fr-hash"><span>Seal</span><code>' + esc(d.seal) + '</code>' + (open ? '<span>Proof</span><code>' + esc(d.proof) + '</code>' : '<em>' + (now ? "Opens when today ends (00:00 UTC)" : "Sealed. Opens after its day.") + '</em>') + '</div>' +
        '<div class="fr-act">' + (open ? '<button class="btn btn-line btn-sm" data-check-day="' + esc(d.day) + '">Check</button><output></output>' : '<span class="fr-lock" aria-hidden="true">🔒</span>') + '</div></div>';
    }).join("") + '</div>';
    box.addEventListener("click", async function (e) {
      var b = e.target.closest("[data-check-day]"); if (!b) return;
      var d = j.days.filter(function (x) { return x.day === b.getAttribute("data-check-day"); })[0], out = b.parentNode.querySelector("output");
      var h = await sha256("shy-daily|" + d.day + "|" + d.proof), seed = parseInt(d.proof.slice(0, 8), 16);
      var ok = h === d.seal && seed === d.seed;
      out.className = ok ? "ok" : "bad";
      out.innerHTML = ok ? "✓ The proof hashes to the seal. Seed " + seed + "." : "✗ Doesn't match.";
    });
  }

  // ---------- live matches ----------
  function rebuild(r) {
    G.useSeason(r.season || []);
    var g = G.newGame(r.names, -1, G.seeded(r.seed), { styles: r.styles });
    if (r.edge && r.edge.length === 2) { var p = g.players[r.edge[0]]; for (var k = 0; k < r.edge[1]; k++) { if (!g.chaosDeck.length) break; p.hand.push(g.chaosDeck.pop()); } }
    G.useSeason([]);
    return g;
  }
  async function check(id) {
    var out = $("fr-live-out"); if (!out) return;
    id = String(id || "").trim().toLowerCase();
    if (!/^[a-z0-9]{3,8}-\d{9,11}$/.test(id)) { out.innerHTML = '<p class="fr-note">Paste a match id like <code>k7q2m-1760541234</code>. It\'s on the Verify link at the end of every live match.</p>'; return; }
    out.innerHTML = '<p class="fr-note">Opening the seal...</p>';
    var r;
    try { r = await (await fetch("/api/fair.php?a=live&id=" + encodeURIComponent(id))).json(); } catch (e) { r = { ok: false, error: "Couldn't reach the server." }; }
    if (!r.ok) { out.innerHTML = '<p class="fr-note bad">' + esc(r.error || "Not found.") + '</p>'; return; }
    var h = await sha256("shy-live|" + r.seed + "|" + r.salt), ok = h === r.seal;
    var g = rebuild(r), names = r.names.map(function (n) { return n.replace(" (bot)", ""); });
    var next = g.chaosDeck.slice(-10).reverse();
    out.innerHTML =
      '<div class="fr-verdict ' + (ok ? "ok" : "bad") + '"><b>' + (ok ? "✓ Seal matches" : "✗ Seal does not match") + '</b><span>' + (r.boss ? "Shogun match" : "Live match") + ' · ended ' + ago(r.end) + '</span></div>' +
      '<dl class="fr-kv"><dt>Seal shown at the start</dt><dd><code>' + esc(r.seal) + '</code></dd><dt>Seed</dt><dd><code>' + r.seed + '</code></dd><dt>Salt</dt><dd><code>' + esc(r.salt) + '</code></dd>' +
      '<dt>sha256("shy-live|' + r.seed + '|' + esc(r.salt) + '")</dt><dd><code>' + esc(h) + '</code></dd></dl>' +
      '<h3 class="fr-h">The opening deal, rebuilt from the seed</h3><p class="fr-note">' + esc(names[g.start]) + ' went first.' + (r.edge && r.edge.length === 2 ? ' ' + esc(names[r.edge[0]]) + ' started with ' + r.edge[1] + ' extra ' + (r.edge[1] === 1 ? "card" : "cards") + ' (the Shogun\'s edge, set in the open before the match).' : "") + '</p>' +
      '<div class="fr-seats">' + g.players.map(function (p, i) {
        return '<div class="fr-seat"><b>' + esc(names[i]) + '</b><small>Regions</small><p>' + p.regions.map(esc).join(", ") + '</p><small>Hand</small><p>' + p.hand.map(function (c) { return esc(cardName(c)); }).join(", ") + '</p></div>';
      }).join("") + '</div>' +
      '<h3 class="fr-h">Next off the Chaos deck</h3><div class="fr-next">' + next.map(function (c, i) { return "<span><i>" + (i + 1) + "</i>" + esc(cardName(c)) + "</span>"; }).join("") + '</div>' +
      '<p class="fr-note">Draws come off the top of this deck in this order. A card that shuffles the deck, or a reshuffle once it runs out, starts a new order from there.</p>';
  }
  async function recent() {
    var box = $("fr-recent"); if (!box) return;
    try {
      var j = await (await fetch("/api/fair.php?a=recent")).json();
      if (!j.ok || !j.rows.length) { box.innerHTML = '<p class="fr-note">No sealed matches yet. The first live match after this update shows up here.</p>'; return; }
      box.innerHTML = j.rows.map(function (r) { return '<button class="fr-m" data-m="' + esc(r.id) + '"><b>' + (r.boss ? "Shogun" : "Live") + '</b><span>' + esc(r.names.join(", ")) + '</span><small>' + ago(r.end) + '</small><code>' + esc(r.seal.slice(0, 10)) + '</code></button>'; }).join("");
    } catch (e) { box.innerHTML = ""; }
  }
  document.addEventListener("click", function (e) {
    var m = e.target.closest("[data-m]"); if (m) { $("fr-id").value = m.getAttribute("data-m"); check(m.getAttribute("data-m")); $("fr-live").scrollIntoView({ behavior: "smooth", block: "start" }); }
  });
  var f = $("fr-form"); if (f) f.addEventListener("submit", function (e) { e.preventDefault(); check($("fr-id").value); });
  daily(); recent();
  var q = new URLSearchParams(location.search).get("m");
  if (q && $("fr-id")) { $("fr-id").value = q; check(q); setTimeout(function () { $("fr-live").scrollIntoView({ block: "start" }); }, 300); }
})();
