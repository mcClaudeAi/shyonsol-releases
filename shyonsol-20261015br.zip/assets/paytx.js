// Builds the payment transaction for a shop order: SOL or an SPL token (SHY, USDC) to the marketing wallet,
// tagged with the order's reference key (so the server can find it on chain) and a memo with the order id.
(function (root) {
  "use strict";
  var ATA_PROGRAM = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
  var MEMO_PROGRAM = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
  var SOL_MINT = "So11111111111111111111111111111111111111112";

  function u64le(n) {
    var b = new Uint8Array(8), v = BigInt(n);
    for (var i = 0; i < 8; i++) { b[i] = Number(v & 255n); v >>= 8n; }
    return b;
  }
  function ata(W, owner, mint, tokenProgram) {
    return W.PublicKey.findProgramAddressSync([owner.toBytes(), tokenProgram.toBytes(), mint.toBytes()], new W.PublicKey(ATA_PROGRAM))[0];
  }
  // o: order from the server; payer: base58 wallet; tokenProgram: owner program of the mint (SPL only); blockhash: recent blockhash
  function build(W, o, payer, tokenProgram, blockhash) {
    var from = new W.PublicKey(payer), to = new W.PublicKey(o.to), ref = new W.PublicKey(o.ref);
    var tx = new W.Transaction({ feePayer: from, recentBlockhash: blockhash });
    if (o.mint === SOL_MINT) {
      // a plain System Program transfer, written out by hand: web3's own helper needs a global Buffer that
      // phone wallets' in-app browsers (Phantom on iOS) don't have, which broke SOL payments there
      var sd = new Uint8Array(12);
      sd[0] = 2;                          // Transfer
      sd.set(u64le(o.units), 4);
      tx.add(new W.TransactionInstruction({ programId: W.SystemProgram.programId, data: sd, keys: [
        { pubkey: from, isSigner: true, isWritable: true }, { pubkey: to, isSigner: false, isWritable: true },
        { pubkey: ref, isSigner: false, isWritable: false }] }));
    } else {
      var mint = new W.PublicKey(o.mint), prog = new W.PublicKey(tokenProgram);
      var src = ata(W, from, mint, prog), dst = ata(W, to, mint, prog);
      // make sure the wallet's token account exists (does nothing if it already does)
      tx.add(new W.TransactionInstruction({ programId: new W.PublicKey(ATA_PROGRAM), data: Uint8Array.of(1), keys: [
        { pubkey: from, isSigner: true, isWritable: true }, { pubkey: dst, isSigner: false, isWritable: true },
        { pubkey: to, isSigner: false, isWritable: false }, { pubkey: mint, isSigner: false, isWritable: false },
        { pubkey: W.SystemProgram.programId, isSigner: false, isWritable: false }, { pubkey: prog, isSigner: false, isWritable: false }] }));
      //MC 2026-10-10 a $SHY order can burn part of the price: the marketing wallet gets the rest, and the burned part is
      //   destroyed from the buyer's own token account in this same transaction (BurnChecked), so it shows on Solscan
      var burn = BigInt(o.burn || 0), send = BigInt(o.units) - burn;
      var data = new Uint8Array(10);
      data[0] = 12;                       // TransferChecked
      data.set(u64le(send), 1);
      data[9] = o.dec;
      tx.add(new W.TransactionInstruction({ programId: prog, data: data, keys: [
        { pubkey: src, isSigner: false, isWritable: true }, { pubkey: mint, isSigner: false, isWritable: false },
        { pubkey: dst, isSigner: false, isWritable: true }, { pubkey: from, isSigner: true, isWritable: false },
        { pubkey: ref, isSigner: false, isWritable: false }] }));
      if (burn > 0n) {
        var bd = new Uint8Array(10);
        bd[0] = 15;                       // BurnChecked
        bd.set(u64le(burn), 1);
        bd[9] = o.dec;
        tx.add(new W.TransactionInstruction({ programId: prog, data: bd, keys: [
          { pubkey: src, isSigner: false, isWritable: true }, { pubkey: mint, isSigner: false, isWritable: true },
          { pubkey: from, isSigner: true, isWritable: false }] }));
      }
    }
    tx.add(new W.TransactionInstruction({ programId: new W.PublicKey(MEMO_PROGRAM), keys: [], data: new TextEncoder().encode(o.memo) }));
    return tx;
  }
  root.ShyPayTx = { build: build, ata: ata };
})(typeof window !== "undefined" ? window : globalThis);
