//MC 2026-10-10 When and where people play: the busy hours of the week as a heatmap, today against a usual day, the last
//   30 days, and where players are from (by the time zone their browser reports). Times show in the reader's own time
//   by default, with a switch to UTC. Data from api/stats.php?a=when, or handed in by the admin Overview as SHY_RX.
//   Plain SVG and HTML, no chart library, so it stays light on phones.
(function () {
  "use strict";
  var mount = document.getElementById("rx-mount");
  if (!mount) return;
  var PRE = window.SHY_RX || null, ADMIN = !!(PRE && PRE.admin);
  var API = "/api/stats.php?a=when";
  var LANG = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || "en";
  var START = "2026-10-10";   // the day regions started counting, for before the first player is saved
  var D = null, layer = "g", win = 1, sel = -1, regSel = -1, lastW = 0, allRegs = false;
  var topPlace = get("shy-rx-tp") || "", topKind = "w", topAll = false;   //MC 2026-10-11 Top players by place
  var tzMode = get("shy-rx-tz") === "utc" ? "utc" : "local";
  var LAYERS = { g: "All games", l: "Live matches", d: "Daily Challenge" };
  //MC 2026-10-10 one ramp per layer, dark ink up to washi paper. Games run through the vermilion of the woodblock art,
  //   live and Daily keep the violet and amber they have in the Games per day chart above
  var RAMP = {
    g: [[46, 33, 72], [96, 36, 70], [170, 42, 48], [224, 69, 58], [243, 139, 82], [250, 207, 150], [253, 244, 227]],
    l: [[46, 33, 72], [74, 46, 128], [116, 78, 206], [150, 112, 236], [196, 172, 252], [238, 230, 255]],
    d: [[46, 33, 72], [94, 56, 34], [168, 96, 32], [216, 136, 40], [246, 192, 98], [255, 240, 204]]
  };
  var CONT = { am: "Americas", eu: "Europe", af: "Africa", as: "Asia", oc: "Oceania", xx: "" };

  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function put(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function fmt(n, d) { return Number(n).toLocaleString("en-US", { maximumFractionDigits: d || 0 }); }
  function keep(t) { return '<span data-i18n-skip>' + esc(t) + '</span>'; }   // names and times already in the reader's language
  function sum(a) { var s = 0; for (var i = 0; i < a.length; i++) s += a[i]; return s; }
  function $(id) { return document.getElementById(id); }

  // ---------- time ----------
  function offH() { return tzMode === "utc" ? 0 : Math.round(-new Date().getTimezoneOffset() / 60); }
  function zoneName() { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ""; } catch (e) { return ""; } }
  function hr(h) { try { return new Date(Date.UTC(2026, 0, 5, ((h % 24) + 24) % 24)).toLocaleTimeString(LANG, { hour: "numeric", timeZone: "UTC" }); } catch (e) { return h + ":00"; } }
  function hrShort(h) { var s = hr(h); return /^\d/.test(s) ? s.replace(/\s?([AP])\.?M\.?/i, function (m, x) { return x.toLowerCase(); }) : s; }
  function wd(dow, style) { try { return new Date(Date.UTC(2026, 0, 4 + dow)).toLocaleDateString(LANG, { weekday: style || "long", timeZone: "UTC" }); } catch (e) { return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][dow]; } }
  function dateLabel(ts, opt) { try { return new Date(ts * 1000).toLocaleDateString(LANG, Object.assign({ timeZone: "UTC" }, opt || { month: "short", day: "numeric" })); } catch (e) { return ""; } }
  function firstDay() { try { var l = new Intl.Locale(LANG), w = l.getWeekInfo ? l.getWeekInfo() : l.weekInfo; if (w && w.firstDay === 7) return 0; } catch (e) {} return 1; }
  function rows() { var f = firstDay(), r = []; for (var i = 0; i < 7; i++) r.push((f + i) % 7); return r; }

  // a UTC hour-of-week series moved into the chosen time zone
  function shift(a) { var o = offH(), out = new Array(168); for (var i = 0; i < 168; i++) out[((i + o) % 168 + 168) % 168] = a[i] || 0; return out; }
  function utcOf(j) { return ((j - offH()) % 168 + 168) % 168; }
  function profile(a) { var p = new Array(24).fill(0); for (var i = 0; i < 168; i++) p[i % 24] += a[i]; return p; }
  function bestPair(a, ring) { var b = -1, bv = -1; for (var i = 0; i < a.length; i++) { var v = a[i] + a[(i + 1) % ring]; if (v > bv) { bv = v; b = i; } } return [b, bv]; }

  function color(L, t) {
    var s = RAMP[L], x = Math.max(0, Math.min(1, t)) * (s.length - 1), i = Math.min(s.length - 2, Math.floor(x)), f = x - i;
    return "rgb(" + [0, 1, 2].map(function (k) { return Math.round(s[i][k] + (s[i + 1][k] - s[i][k]) * f); }).join(",") + ")";
  }

  // ---------- tooltip (hover on a mouse; taps use the readouts under each chart) ----------
  var tip = document.createElement("div"); tip.className = "rx-tip"; tip.hidden = true; tip.setAttribute("role", "presentation"); document.body.appendChild(tip);
  function showTip(html, x, y) {
    tip.innerHTML = html; tip.hidden = false;
    var w = tip.offsetWidth, h = tip.offsetHeight, vw = document.documentElement.clientWidth;
    var left = Math.min(vw - w - 10, Math.max(10, x - w / 2)), top = y - h - 12;
    if (top < 8) top = y + 18;
    tip.style.transform = "translate(" + Math.round(left) + "px," + Math.round(top) + "px)";
  }
  function hideTip() { tip.hidden = true; }
  document.addEventListener("scroll", hideTip, { passive: true });
  function mouse(e) { return !e.pointerType || e.pointerType === "mouse"; }

  // ---------- the frame ----------
  function frame() {
    mount.innerHTML =
      '<div class="rx-bar"><div class="rx-seg" role="group" aria-label="Time zone"><button type="button" data-rx-tz="local">Your time</button><button type="button" data-rx-tz="utc">UTC</button></div>' +
      '<p class="rx-tzname" id="rx-tzname"></p>' + (ADMIN ? "" : '<p class="rx-online" id="rx-online"></p>') + '</div>' +
      '<div class="rx-calls" id="rx-calls">' + [1, 2, 3].map(function () { return '<div class="rx-call sk"></div>'; }).join("") + '</div>' +
      '<article class="rx-card rx-heat" id="rx-heat"><div class="rx-head"><div><h3 class="rx-h3">Busy hours, day by day</h3><p class="rx-sub" id="rx-heat-sub">Games started in each hour of the week. Lighter means busier.</p></div>' +
      '<div class="rx-ctrl"><div class="rx-seg" role="group" aria-label="Show">' + Object.keys(LAYERS).map(function (k) { return '<button type="button" data-rx-layer="' + k + '">' + LAYERS[k] + '</button>'; }).join("") + '</div>' +
      '<div class="rx-seg" role="group" aria-label="Range"><button type="button" data-rx-win="0">4 weeks</button><button type="button" data-rx-win="1">12 weeks</button></div></div></div>' +
      '<div class="rx-hm-box" id="rx-hm"><div class="rx-skel"></div></div>' +
      '<div class="rx-legend" id="rx-legend"></div><div class="rx-read" id="rx-read" aria-live="polite"></div></article>' +
      '<div class="rx-two"><article class="rx-card" id="rx-today"><div class="rx-head"><div><h3 class="rx-h3">Today so far</h3><p class="rx-sub">Games each hour today, against a usual day.</p></div></div>' +
      '<div class="rx-chart" id="rx-today-c"><div class="rx-skel short"></div></div><div class="rx-facts" id="rx-today-f"></div></article>' +
      '<article class="rx-card" id="rx-month"><div class="rx-head"><div><h3 class="rx-h3">The last 30 days</h3><p class="rx-sub">Games each day. Today is still counting.</p></div></div>' +
      '<div class="rx-chart" id="rx-month-c"><div class="rx-skel short"></div></div><div class="rx-facts" id="rx-month-f"></div></article></div>' +
      '<article class="rx-card rx-where" id="rx-where"><div class="rx-head"><div><h3 class="rx-h3">Where players are</h3><p class="rx-sub">Players from the last 90 days, by the time zone their browser reports. Tap a place to see when it plays.</p></div></div>' +
      '<div id="rx-where-b"><div class="rx-skel"></div></div></article>' +
      //MC 2026-10-11 Top players by place: pick a place, see who wins the most there (all games, or live matches only)
      '<article class="rx-card rx-tops" id="rx-tops"><div class="rx-head"><div><h3 class="rx-h3">Top players by place</h3><p class="rx-sub">Who wins the most in each place. Pick a place to see its leaders.</p></div>' +
      '<div class="rx-ctrl"><div class="rx-seg" role="group" aria-label="Rank by"><button type="button" data-rx-tk="w">All wins</button><button type="button" data-rx-tk="l">Live wins</button></div></div></div>' +
      '<div id="rx-tops-b"><div class="rx-skel short"></div></div></article>';
    syncSegs();
  }
  function syncSegs() {
    mount.querySelectorAll("[data-rx-tz]").forEach(function (b) { var on = b.dataset.rxTz === tzMode; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
    mount.querySelectorAll("[data-rx-layer]").forEach(function (b) { var on = b.dataset.rxLayer === layer; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
    mount.querySelectorAll("[data-rx-win]").forEach(function (b) { var on = +b.dataset.rxWin === win; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
    mount.querySelectorAll("[data-rx-tk]").forEach(function (b) { var on = b.dataset.rxTk === topKind; b.classList.toggle("on", on); b.setAttribute("aria-pressed", on); });
  }

  function header() {
    var z = zoneName(), o = -new Date().getTimezoneOffset();
    $("rx-tzname").innerHTML = tzMode === "utc" ? 'All times in UTC.' :
      'All times in your time zone, ' + keep(z ? z.replace(/_/g, " ") : "UTC" + (o >= 0 ? "+" : "") + o / 60) + (o % 60 ? ' (rounded to the hour)' : "");
    var on = $("rx-online");
    if (on) on.innerHTML = '<span class="live-dot"></span><b>' + fmt(D.online) + '</b> ' + (D.online === 1 ? 'player online now' : 'players online now');
  }

  // ---------- callouts ----------
  function calls() {
    var a = D.heat, w = a.g[win], lv = a.l[win], dl = a.d[win];
    var g = shift(w), L = shift(lv), dd = shift(dl), out = [];
    // busiest two hours of the week
    if (sum(w) >= 20) {
      var b = bestPair(g, 168), d0 = Math.floor(b[0] / 24), h0 = b[0] % 24, per = sum(w) / 168;
      out.push(['時', "Busiest time", keep(wd(d0)) + '<div class="rx-ct">' + keep(hr(h0)) + ' to ' + keep(hr(h0 + 2)) + '</div>', (tzMode === "utc" ? "UTC." : "Your time.") + ' ' + fmt(b[1] / 2 / Math.max(per, 0.01), 1) + 'x a usual hour.']);
    } else out.push(['時', "Busiest time", 'Not enough games yet', 'Check back in a few days.']);
    // live tables: the two hours of the day with the most live players, and the best day for it
    if (sum(lv) >= 20) {
      var lp = bestPair(profile(L), 24), byDay = [0, 0, 0, 0, 0, 0, 0];
      L.forEach(function (v, i) { byDay[Math.floor(i / 24)] += v; });
      var bd = byDay.indexOf(Math.max.apply(null, byDay));
      out.push(['戦', "Live tables fill fastest", keep(hr(lp[0])) + ' to ' + keep(hr(lp[0] + 2)), 'Best day: ' + keep(wd(bd)) + '. Find an opponent then.']);
    } else out.push(['戦', "Live tables fill fastest", 'Not enough live matches yet', 'Start one and invite a friend.']);
    // the Daily: when people play it, and when the new one comes out where the reader is
    var reset = keep(hr(offH()));
    if (sum(dl) >= 20) {
      var dp = bestPair(profile(dd), 24);
      out.push(['日', "Daily Challenge rush", keep(hr(dp[0])) + ' to ' + keep(hr(dp[0] + 2)), 'A new Daily comes out at ' + reset + (tzMode === "utc" ? "." : ' your time.')]);
    } else out.push(['日', "Daily Challenge", 'New one at ' + reset, tzMode === "utc" ? 'Every day, 00:00 UTC.' : 'Your time, every day.']);
    $("rx-calls").innerHTML = out.map(function (c) {
      return '<div class="rx-call"><span class="rx-seal" aria-hidden="true">' + c[0] + '</span><div><div class="rx-ck">' + c[1] + '</div><div class="rx-cv' + (c[2].indexOf("Not enough") === 0 ? " soft" : "") + '">' + c[2] + '</div><p>' + c[3] + '</p></div></div>';
    }).join("");
  }

  // ---------- heatmap ----------
  function heat() {
    var box = $("rx-hm"), src = D.heat[layer][win], a = shift(src), dn = D.heat.dn[win];
    var tot = sum(src), max = Math.max.apply(null, a) || 1, R = rows();
    var tall = (box.clientWidth || 600) < 600;
    lastW = box.clientWidth;
    var top = a.slice().sort(function (x, y) { return y - x; })[2] || max, focusJ = sel < 0 ? peak(a) : sel;   // the three busiest hours get a mark
    var cell = function (j, extra) {
      var v = a[j], t = v ? 0.05 + 0.95 * Math.pow(v / max, 1.15) : 0;   //MC 2026-10-10 near linear: a softer curve made quiet nights look busy
      return '<button type="button" class="rx-c' + (v ? "" : " z") + (v && v >= top ? " pk" : "") + (j === sel ? " on" : "") + '" data-j="' + j + '" tabindex="' + (j === focusJ ? 0 : -1) + '"' +
        ' style="' + (v ? "background:" + color(layer, t) + ";" : "") + (extra || "") + '" aria-label="' + esc(wd(Math.floor(j / 24)) + " " + hr(j % 24) + ": " + v) + '" data-i18n-skip></button>';   //MC 2026-10-10 day and hour names come from Intl already
    };
    var h = "";
    if (!tot) {
      box.innerHTML = '<div class="rx-empty"><b>No games here yet.</b><p>' + (layer === "g" ? "The heatmap fills in as games finish." : "Pick All games, or check back once a few have been played.") + '</p></div>';
      $("rx-legend").innerHTML = ""; $("rx-read").innerHTML = ""; return;
    }
    if (!tall) {
      var prof = profile(a), pmax = Math.max.apply(null, prof) || 1, dayT = R.map(function (d) { return sum(a.slice(d * 24, d * 24 + 24)); }), dmax = Math.max.apply(null, dayT) || 1;
      h += '<div class="rx-hm" style="grid-template-columns:52px repeat(24,minmax(0,1fr)) 72px">';
      h += '<span class="rx-corner" aria-hidden="true"></span>' + prof.map(function (v, i) { return '<span class="rx-colbar" aria-hidden="true"><i style="height:' + Math.max(v ? 6 : 0, Math.round(100 * v / pmax)) + '%"></i></span>'; }).join("") + '<span class="rx-corner" aria-hidden="true"></span>';
      R.forEach(function (d, ri) {
        h += '<span class="rx-dl">' + keep(wd(d, "short")) + '</span>';
        for (var x = 0; x < 24; x++) h += cell(d * 24 + x);
        h += '<span class="rx-rowt" title="' + esc(wd(d)) + '" data-i18n-skip><i style="width:' + Math.round(100 * dayT[ri] / dmax) + '%"></i><b>' + fmt(dayT[ri]) + '</b></span>';
      });
      h += '<span></span>';
      for (var x = 0; x < 24; x++) h += '<span class="rx-hl">' + (x % 3 === 0 ? keep(hrShort(x)) : "") + '</span>';
      h += '<div class="rx-hl rx-hl-t">Total</div></div>';
    } else {
      h += '<div class="rx-hm tall" style="grid-template-columns:46px repeat(7,minmax(0,1fr))">';
      h += '<span></span>' + R.map(function (d) { return '<span class="rx-dh">' + keep(wd(d, "short")) + '</span>'; }).join("");
      for (var y = 0; y < 24; y++) {
        h += '<span class="rx-hl">' + (y % 2 === 0 ? keep(hrShort(y)) : "") + '</span>';
        R.forEach(function (d) { h += cell(d * 24 + y); });
      }
      h += '</div>';
    }
    box.innerHTML = h;
    box.classList.toggle("is-tall", tall);
    //MC 2026-10-11 until the window has filled up, the legend counts the days that really have data: it said "the last 12
    // weeks" over about 7 days, while "About N a week" under it divided by the real number of days
    var weeks = D.heat.w[win], dn = (D.heat.dn && D.heat.dn[win]) || [], have = dn.reduce(function (x, y) { return x + (+y || 0); }, 0);
    var span = have && have < weeks * 7 ? fmt(have) + (have === 1 ? " day" : " days") : weeks + " weeks";
    $("rx-legend").innerHTML = '<div>Quiet</div><i style="background:linear-gradient(90deg,' + [0, .25, .5, .75, 1].map(function (t) { return color(layer, 0.05 + 0.95 * t); }).join(",") + ')"></i><div>Busy</div>' +
      '<div class="rx-lg-e"><i class="rx-pkdot" aria-hidden="true"></i><div>The 3 busiest hours</div></div><div class="rx-lg-e rx-lg-t">' + fmt(tot) + ' ' + (layer === "l" ? "live players" : "games") + ' in the last ' + span + '</div>';
    read(sel < 0 ? peak(a) : sel, sel < 0);
    var sub = { g: "Games started in each hour of the week. Lighter means busier.", l: "Players in live matches in each hour of the week. A match counts once for each player at the table.", d: "Daily Challenge runs in each hour of the week." }[layer];
    $("rx-heat-sub").textContent = sub;
  }
  function peak(a) { var b = 0; for (var i = 1; i < 168; i++) if (a[i] > a[b]) b = i; return b; }
  // the line under the heatmap: exact numbers for the cell picked (or the busiest one before anything is picked)
  function read(j, isPeak) {
    var a = shift(D.heat[layer][win]), v = a[j], u = utcOf(j), days = D.heat.dn[win][Math.floor(u / 24)] || 0, per = sum(a) / 168;
    var unit = layer === "l" ? (v === 1 ? "live player" : "live players") : layer === "d" ? (v === 1 ? "Daily run" : "Daily runs") : (v === 1 ? "game" : "games");
    $("rx-read").innerHTML = '<div class="rx-read-k">' + (isPeak ? "Busiest hour" : "Picked") + '</div>' +
      '<div class="rx-read-w">' + keep(wd(Math.floor(j / 24))) + ', ' + keep(hr(j % 24)) + ' to ' + keep(hr(j % 24 + 1)) + '</div>' +
      '<div class="rx-read-v"><b>' + fmt(v) + '</b> ' + unit + '</div>' +
      (days ? '<div class="rx-read-x">About ' + fmt(v / days, 1) + ' a week</div>' : "") +
      (per > 0 ? '<div class="rx-read-x">' + fmt(v / per, 1) + 'x a usual hour</div>' : "");
  }
  function pick(j, focus) {
    var box = $("rx-hm"), b = box.querySelector('[data-j="' + j + '"]'); if (!b) return;
    sel = j;
    box.querySelectorAll(".rx-c.on").forEach(function (x) { x.classList.remove("on"); });
    box.querySelectorAll('.rx-c[tabindex="0"]').forEach(function (x) { x.tabIndex = -1; });
    b.classList.add("on"); b.tabIndex = 0;
    if (focus) b.focus();
    read(j, false);
  }

  // ---------- today against a usual day ----------
  function hourly() {
    var H = D.hrs, o = offH() * 3600, at = D.at, startToday = Math.floor((at + o) / 86400) * 86400 - o;
    var idx = function (ts) { return Math.floor((ts - H.h0) / 3600); };
    var val = function (ts) { var i = idx(ts); return i >= 0 && i < H.g.length ? H.g[i] : null; };
    var firstDay = D.since ? Math.floor(D.since / 86400) * 86400 : at + 86400;   // no games ever: no usual day to compare with
    var nowH = Math.floor((at - startToday) / 3600);
    var today = [], usual = [], nUsual = 0;
    for (var h = 0; h < 24; h++) today.push(h <= nowH ? (val(startToday + h * 3600) || 0) : null);
    for (var k = 1; k <= 28; k++) { var ds = startToday - k * 86400; if (ds + 86400 <= firstDay || idx(ds) < 0) break; nUsual++; }
    for (h = 0; h < 24; h++) { var s = 0; for (k = 1; k <= nUsual; k++) s += val(startToday + h * 3600 - k * 86400) || 0; usual.push(nUsual ? s / nUsual : 0); }
    var days = [];
    for (k = 29; k >= 0; k--) {
      var st = startToday - k * 86400, g = 0, any = false;
      for (h = 0; h < 24; h++) { var v = val(st + h * 3600); if (v !== null) { g += v; any = true; } }
      days.push({ t: st, g: g, any: any && st + 86400 > firstDay, today: k === 0 });
    }
    return { today: today, usual: usual, nUsual: nUsual, nowH: nowH, days: days, startToday: startToday };
  }
  function niceMax(m) { if (m <= 4) return 4; var p = Math.pow(10, Math.floor(Math.log10(m))), n = Math.ceil(m / p) * p; if (n / p < 3) { p /= 2; n = Math.ceil(m / p) * p; } return n; }
  function todayChart() {
    var R = hourly(), box = $("rx-today-c"), W = Math.max(280, box.clientWidth || 520), H = W < 460 ? 190 : 220, pl = 34, pr = 8, pt = 14, pb = 26;
    var max = niceMax(Math.max.apply(null, R.usual.concat(R.today.map(function (v) { return v || 0; })).concat([1])));
    var x = function (h) { return pl + (h + 0.5) * (W - pl - pr) / 24; }, y = function (v) { return pt + (H - pt - pb) * (1 - v / max); };
    var line = function (pts) { return pts.map(function (p, i) { return (i ? "L" : "M") + p[0].toFixed(1) + "," + p[1].toFixed(1); }).join(""); };
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" role="img" aria-label="Games each hour today and on a usual day">';
    for (var g = 0; g <= max; g += max / 2) s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(g) + '" y2="' + y(g) + '" class="rx-gl"/><text x="' + (pl - 7) + '" y="' + (y(g) + 4) + '" class="rx-ax" text-anchor="end">' + fmt(g) + '</text>';
    // the hour we're in
    var nx = x(R.nowH), bw = (W - pl - pr) / 24;
    s += '<rect x="' + (nx - bw / 2) + '" y="' + pt + '" width="' + bw + '" height="' + (H - pt - pb) + '" class="rx-nowband"/>';
    if (R.nUsual) {
      var up = R.usual.map(function (v, h) { return [x(h), y(v)]; });
      s += '<path d="' + line(up) + 'L' + x(23).toFixed(1) + ',' + y(0) + 'L' + x(0).toFixed(1) + ',' + y(0) + 'Z" class="rx-usual-a"/><path d="' + line(up) + '" class="rx-usual-l"/>';
    }
    var tp = []; R.today.forEach(function (v, h) { if (v !== null) tp.push([x(h), y(v)]); });
    if (tp.length) {
      //MC 2026-10-10 the hour we're in has only just started, so the line into it is dashed instead of a cliff
      var done = tp.length > 1 ? tp.slice(0, -1) : tp;
      s += '<path d="' + line(tp) + 'L' + tp[tp.length - 1][0].toFixed(1) + ',' + y(0) + 'L' + tp[0][0].toFixed(1) + ',' + y(0) + 'Z" class="rx-today-a"/><path d="' + line(done) + '" class="rx-today-l"/>' +
        (tp.length > 1 ? '<path d="' + line(tp.slice(-2)) + '" class="rx-today-l part"/>' : "");
      var last = tp[tp.length - 1];
      s += '<circle cx="' + last[0] + '" cy="' + last[1] + '" r="5" class="rx-today-dot"/>';
    }
    [0, 6, 12, 18].forEach(function (h) { s += '<text x="' + x(h) + '" y="' + (H - 7) + '" class="rx-ax" text-anchor="middle">' + esc(hrShort(h)) + '</text>'; });
    s += '<text x="' + Math.min(W - pr - 14, nx) + '" y="' + (pt - 3) + '" class="rx-ax rx-now-t" text-anchor="middle">' + esc(hrShort(R.nowH)) + '</text>';
    for (var h = 0; h < 24; h++) s += '<rect x="' + (x(h) - bw / 2) + '" y="' + pt + '" width="' + bw + '" height="' + (H - pt - pb) + '" class="rx-hit" data-h="' + h + '"/>';
    s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(0) + '" y2="' + y(0) + '" class="rx-base"/></svg>';
    box.innerHTML = s;
    var hit = function (h, cx, cy, touch) {
      box.querySelectorAll(".rx-hit.on").forEach(function (e) { e.classList.remove("on"); });
      var r = box.querySelector('.rx-hit[data-h="' + h + '"]'); if (r) r.classList.add("on");
      var t = R.today[h];
      tipOrRead("rx-today-f", '<div class="rx-th">' + keep(hr(h)) + ' to ' + keep(hr(h + 1)) + '</div>' + tipRow("k-today", "Today", t === null ? "&ndash;" : fmt(t)) +
        (R.nUsual ? tipRow("k-usual", "Usual day", fmt(R.usual[h], 1)) : ""), cx, cy, touch);
    };
    wireHits(box, hit);
    // facts: so far today against a usual day by this time
    var soFar = sum(R.today.map(function (v) { return v || 0; })), part = (D.at - (R.startToday + R.nowH * 3600)) / 3600;
    var usualBy = 0; R.usual.forEach(function (v, h) { if (h < R.nowH) usualBy += v; else if (h === R.nowH) usualBy += v * part; });
    var diff = usualBy >= 1 ? Math.round(100 * (soFar - usualBy) / usualBy) : null;
    todayFacts = '<div><div class="rx-fk">So far today</div><div class="rx-fv">' + fmt(soFar) + '</div></div>' +
      (R.nUsual ? '<div><div class="rx-fk">Usual by now</div><div class="rx-fv">' + fmt(usualBy) + '</div></div><div><div class="rx-fk">Compared with usual</div><div class="rx-fv ' + (diff === null ? "" : diff >= 0 ? "up" : "down") + '">' + (diff === null ? "&ndash;" : (diff >= 0 ? "+" : "") + diff + "%") + '</div></div>' :
        '<div class="rx-wide-f"><div class="rx-fk">Usual day</div><div class="rx-fs">Shows once there are a few days of games.</div></div>');
    todayFacts += '<div class="rx-key"><i class="k-today"></i><div>Today</div>' + (R.nUsual ? '<i class="k-usual"></i><div>Usual day, from the last ' + R.nUsual + ' days</div>' : "") + '</div>';
    $("rx-today-f").innerHTML = todayFacts;
    return R;
  }
  var todayFacts = "", monthFacts = "";
  // the floating tip on a mouse; on a phone the numbers go into the facts row under the chart until the next tap
  //MC 2026-10-10 each label in its own block, so the translator sees "Today" and "Usual day" and not the whole tooltip as one line
  function tipRow(key, label, val) { return '<div class="rx-tl">' + (key ? '<i class="' + key + '"></i>' : "") + '<div>' + label + '</div><em>' + val + '</em></div>'; }
  function tipOrRead(id, html, cx, cy, touch) {
    if (!touch) return showTip(html, cx, cy);
    var el = $(id); el.innerHTML = '<div class="rx-pickrow">' + html + '</div>';
  }
  function wireHits(box, fn) {
    box.onpointermove = function (e) { if (!mouse(e)) return; var t = e.target.closest && e.target.closest(".rx-hit"); if (!t) return hideTip(); fn(+(t.dataset.h || t.dataset.i), e.clientX, e.clientY); };
    box.onpointerleave = function (e) { if (!mouse(e)) return; hideTip(); box.querySelectorAll(".rx-hit.on").forEach(function (x) { x.classList.remove("on"); }); restoreFacts(box); };
    box.onclick = function (e) {
      var t = e.target.closest && e.target.closest(".rx-hit"); if (!t) return;
      var touch = e.pointerType ? e.pointerType !== "mouse" : !matchMedia("(hover:hover)").matches;
      if (!touch) return;
      fn(+(t.dataset.h || t.dataset.i), 0, 0, true);
    };
  }
  function restoreFacts(box) {
    if (box.id === "rx-today-c" && todayFacts) $("rx-today-f").innerHTML = todayFacts;
    if (box.id === "rx-month-c" && monthFacts) $("rx-month-f").innerHTML = monthFacts;
  }

  // ---------- the last 30 days ----------
  function monthChart() {
    var R = hourly(), box = $("rx-month-c"), W = Math.max(280, box.clientWidth || 520), H = W < 460 ? 190 : 220, pl = 34, pr = 4, pt = 14, pb = 26;
    var ds = R.days, max = niceMax(Math.max.apply(null, ds.map(function (d) { return d.g; }).concat([1])));
    var bw = (W - pl - pr) / ds.length, gap = Math.max(2, bw * 0.26), w = bw - gap;
    var y = function (v) { return pt + (H - pt - pb) * (1 - v / max); };
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" height="' + H + '" role="img" aria-label="Games each day for the last 30 days">';
    for (var g = 0; g <= max; g += max / 2) s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(g) + '" y2="' + y(g) + '" class="rx-gl"/><text x="' + (pl - 7) + '" y="' + (y(g) + 4) + '" class="rx-ax" text-anchor="end">' + fmt(g) + '</text>';
    ds.forEach(function (d, i) {
      var x0 = pl + i * bw + gap / 2, dow = new Date((d.t + offH() * 3600) * 1000).getUTCDay(), we = dow === 0 || dow === 6;
      if (d.g > 0) { var hh = Math.max(2, y(0) - y(d.g)); s += '<rect x="' + x0.toFixed(1) + '" y="' + (y(0) - hh).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + hh.toFixed(1) + '" rx="' + Math.min(4, w / 2).toFixed(1) + '" class="rx-db' + (d.today ? " now" : we ? " we" : "") + '"/>'; }
      else if (!d.any) s += '<rect x="' + x0.toFixed(1) + '" y="' + (y(0) - 2) + '" width="' + w.toFixed(1) + '" height="2" class="rx-db none"/>';
      if (i % (W < 460 ? 7 : 5) === 0 && i < ds.length - (W < 460 ? 4 : 2) || d.today) s += '<text x="' + (x0 + w / 2).toFixed(1) + '" y="' + (H - 7) + '" class="rx-ax' + (d.today ? " rx-now-t" : "") + '" text-anchor="' + (d.today ? "end" : "middle") + '">' + esc(d.today ? todayWord() : dateLabel(d.t + offH() * 3600)) + '</text>';
      s += '<rect x="' + (pl + i * bw).toFixed(1) + '" y="' + pt + '" width="' + bw.toFixed(1) + '" height="' + (H - pt - pb) + '" class="rx-hit" data-i="' + i + '"/>';
    });
    s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(0) + '" y2="' + y(0) + '" class="rx-base"/></svg>';
    box.innerHTML = s;
    wireHits(box, function (i, cx, cy, touch) {
      box.querySelectorAll(".rx-hit.on").forEach(function (e) { e.classList.remove("on"); });
      var r = box.querySelector('.rx-hit[data-i="' + i + '"]'); if (r) r.classList.add("on");
      var d = ds[i];
      tipOrRead("rx-month-f", '<div class="rx-th">' + keep(dateLabel(d.t + offH() * 3600, { weekday: "long", month: "short", day: "numeric" })) + '</div>' + tipRow("", "Games", d.any || d.g ? fmt(d.g) : "&ndash;") + (d.today ? '<div class="rx-tl"><div>Still counting</div></div>' : ""), cx, cy, touch);
    });
    // facts: average a day, and which weekday is busiest
    var seen = ds.filter(function (d) { return d.any && !d.today; }), avg = seen.length ? sum(seen.map(function (d) { return d.g; })) / seen.length : 0;
    var wk = [0, 0, 0, 0, 0, 0, 0], wn = [0, 0, 0, 0, 0, 0, 0];
    seen.forEach(function (d) { var dow = new Date((d.t + offH() * 3600) * 1000).getUTCDay(); wk[dow] += d.g; wn[dow]++; });
    var wa = wk.map(function (v, i) { return wn[i] ? v / wn[i] : 0; }), bd = wa.indexOf(Math.max.apply(null, wa));
    monthFacts = '<div><div class="rx-fk">A day, on average</div><div class="rx-fv">' + fmt(avg, avg < 10 ? 1 : 0) + '</div></div><div><div class="rx-fk">Busiest weekday</div><div class="rx-fv">' + (seen.length >= 7 && wa[bd] > 0 ? keep(wd(bd)) : "&ndash;") + '</div></div>';
    monthFacts += '<div class="rx-key"><i class="k-day"></i><div>Weekday</div><i class="k-we"></i><div>Weekend</div><i class="k-now"></i><div>Today</div></div>';
    $("rx-month-f").innerHTML = monthFacts;
  }
  function todayWord() { try { return new Intl.RelativeTimeFormat(LANG, { numeric: "auto" }).format(0, "day"); } catch (e) { return "Today"; } }

  // ---------- right now (the card in the grid below) ----------
  function now() {
    var el = $("rx-now-body"); if (!el) return;
    var R = hourly(), cur = R.today[R.nowH] || 0, usual = R.usual[R.nowH] || 0;
    // the next two busy hours, over the rest of today and the start of tomorrow
    var best = -1, bv = 0;
    for (var k = 1; k <= 12; k++) { var h = (R.nowH + k) % 24, v = R.usual[h] + R.usual[(h + 1) % 24]; if (v > bv) { bv = v; best = h; } }
    var inH = best >= 0 ? (best - R.nowH + 24) % 24 : 0;
    el.innerHTML = '<div class="rx-now-big"><span class="live-dot"></span><b>' + fmt(D.online) + '</b><div>' + (D.online === 1 ? "player online right now." : "players online right now.") + '</div></div>' +
      '<div class="rx-now-rows"><div><div class="rx-nk">This hour</div><div class="rx-nv">' + fmt(cur) + '</div><div class="rx-ns">' + (R.nUsual ? 'games so far, a usual hour has ' + fmt(usual, 1) : 'games so far') + '</div></div>' +
      (R.nUsual && bv > 0 ? '<div><div class="rx-nk">Next busy stretch</div><div class="rx-nv">' + keep(hr(best)) + ' to ' + keep(hr(best + 2)) + '</div><div class="rx-ns">' + (inH <= 1 ? "Starting about now." : 'In about ' + inH + ' hours, ' + (tzMode === "utc" ? "UTC." : "your time.")) + '</div></div>' : "") +
      '</div><a class="rx-link" href="#when">See when people play <span aria-hidden="true">&#8593;</span></a>';
  }

  // ---------- where ----------
  function where() {
    var G = D.geo, b = $("rx-where-b"), since = G.since ? new Date(G.since * 1000).toISOString().slice(0, 10) : START;
    var sinceTxt = keep(dateLabel(Date.parse(since + "T12:00:00Z") / 1000, { month: "short", day: "numeric" }));
    var note = '<p class="rx-note">Counted from the time zone each player\'s browser reports, never from IP addresses or location. ' +
      (ADMIN ? 'Team view: every place is listed, with no minimum.' : 'Places with fewer than ' + G.min + ' players are grouped together.') + ' Counting since ' + sinceTxt + '.</p>';
    if (!G.regions.length) {
      b.innerHTML = '<div class="rx-collect"><div class="rx-globe" aria-hidden="true">' + globe() + '</div><div><span class="rx-seal sm" aria-hidden="true">地</span><h4>Collecting since ' + sinceTxt + '</h4>' +
        '<p>' + (G.n ? fmt(G.n) + (G.n === 1 ? " player counted so far." : " players counted so far.") + ' ' : "") + 'Places show up here once at least ' + G.min + ' players from one place have played.</p></div></div>' + note;
      return;
    }
    var tot = G.n, list = G.regions;
    var top = list[0].n;
    //MC 2026-10-10 the top 8 places, the rest behind a button (22 rows was a long scroll on a phone)
    var shown = allRegs || list.length <= 10 ? list : list.slice(0, 8);
    var rowsH = shown.map(function (r, i) {
      var pct = Math.round(1000 * r.n / tot) / 10;
      return '<li class="rx-reg' + (i === regSel ? " open" : "") + '"><button type="button" data-rx-reg="' + i + '" aria-expanded="' + (i === regSel) + '"><span class="rx-rank">' + (i + 1) + '</span>' +
        '<div class="rx-rname"><div class="rx-rn">' + esc(r.name) + '</div><div class="rx-rc">' + (CONT[r.c] || "") + '</div></div>' +
        '<span class="rx-share"><i style="width:' + Math.max(2, Math.round(100 * r.n / top)) + '%"></i></span><span class="rx-pct">' + fmt(pct, 1) + '%</span><div class="rx-cnt">' + fmt(r.n) + ' ' + (r.n === 1 ? "player" : "players") + '</div>' +
        '<svg class="rx-chev" viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button>' + (i === regSel ? regionDetail(r) : "") + '</li>';
    }).join("");
    var langs = G.langs.length ? '<div class="rx-langs"><h4>Languages</h4><div>' + G.langs.map(function (l) {
      return '<span class="rx-lang">' + keep(langName(l.l)) + '<b>' + (100 * l.n / tot < 1 ? "&lt;1" : fmt(Math.round(100 * l.n / tot))) + '%</b></span>';
    }).join("") + '</div></div>' : "";
    var zones = ADMIN && G.zones ? '<details class="rx-zones"><summary>Every time zone (' + Object.keys(G.zones).length + ')</summary><table><thead><tr><th>Time zone</th><th>Players</th></tr></thead><tbody>' +
      Object.keys(G.zones).map(function (z) { return '<tr><td>' + esc(z) + '</td><td>' + fmt(G.zones[z]) + '</td></tr>'; }).join("") + '</tbody></table></details>' : "";
    b.innerHTML = '<div class="rx-map" id="rx-map">' + band() +
      '<div class="rx-where-g"><div><div class="rx-where-t"><b>' + fmt(tot) + '</b> players counted' + (G.other ? ' <span class="rx-dim">plus ' + fmt(G.other) + ' in smaller places</span>' : "") + '</div><ol class="rx-regs">' + rowsH + '</ol>' +
      (list.length > 10 ? '<button type="button" class="rx-more" data-rx-all>' + (allRegs ? "Show the top 8" : "Show all " + list.length + " places") + '</button>' : "") + '</div>' +
      '<div>' + langs + zones + '</div></div>' + note;
  }
  //MC 2026-10-11 the leaders of one place: a chip per place (the busiest first), then a ranked list with a bar for each
  //   player's wins against the leader's, their win rate, and your own row marked. Top 5, the rest of the top 10 on a tap.
  function tops() {
    var b = $("rx-tops-b"); if (!b) return;
    var places = (D.geo.regions || []).filter(function (r) { return r.top && r.top.n; });
    $("rx-tops").hidden = !places.length;
    if (!places.length) return;
    var cur = places.filter(function (r) { return r.name === topPlace; })[0] || places[0];
    var L = (cur.top[topKind] || []), mine = String(get("shy-lb-pid") || "").slice(0, 6), live = topKind === "l";
    var chips = '<div class="rx-chips" role="tablist" aria-label="Places">' + places.map(function (r) {
      var on = r === cur;
      return '<button type="button" role="tab" aria-selected="' + on + '" class="rx-chip' + (on ? " on" : "") + '" data-rx-tp="' + esc(r.name) + '">' + esc(r.name) + '<small>' + fmt(r.top.n) + '</small></button>';
    }).join("") + '</div>';
    if (!L.length) { b.innerHTML = chips + '<p class="rx-tl-empty">' + (live ? "No live wins from here yet. Play a live match and be the first." : "No wins from here yet.") + '</p>'; return; }
    var max = (live ? L[0].lw : L[0].w) || 1, shown = topAll ? L : L.slice(0, 5);
    var rowsH = shown.map(function (x, i) {
      var w = live ? x.lw : x.w, g = live ? x.lg : x.g, rate = g ? Math.round(100 * w / g) : 0, me = x.tag === mine;
      return '<li class="rx-tl-r' + (i < 3 ? " m" + (i + 1) : "") + (me ? " me" : "") + '" style="--d:' + (i * 45) + 'ms"><span class="rx-tl-n">' + (i + 1) + '</span>' +
        '<div class="rx-tl-who"><a href="/p/' + encodeURIComponent(String(x.name).replace(/ /g, "_")) + '" data-i18n-skip>' + esc(x.name) + '</a>' + (me ? '<em>You</em>' : "") +
        '<span class="rx-tl-bar" aria-hidden="true"><i style="width:' + Math.max(3, Math.round(100 * w / max)) + '%"></i></span></div>' +
        '<div class="rx-tl-v"><b>' + fmt(w) + '</b><small>' + (live ? (w === 1 ? "live win" : "live wins") : (w === 1 ? "win" : "wins")) + '</small><span>' + rate + '% of ' + fmt(g) + '</span></div></li>';
    }).join("");
    b.innerHTML = chips + '<div class="rx-tl-head"><b data-i18n-skip>' + esc(cur.name) + '</b><span>' + fmt(cur.top.n) + (cur.top.n === 1 ? " player with a win" : " players with a win") + '</span></div>' +
      '<ol class="rx-tl">' + rowsH + '</ol>' + (L.length > 5 ? '<button type="button" class="rx-more" data-rx-tall>' + (topAll ? "Show the top 5" : "Show the top " + L.length) + '</button>' : "");
  }
  function langName(code) { try { var n = new Intl.DisplayNames([LANG], { type: "language" }).of(code); return n ? n.charAt(0).toUpperCase() + n.slice(1) : code; } catch (e) { return code; } }
  // a region's hours: a 24 cell strip in the chosen time, and its busiest two hours in its own time
  function regionDetail(r) {
    if (!r.h) return '<div class="rx-regd"><p class="rx-dim">Hours show once ' + D.geo.minHours + ' players from here have played.</p></div>';
    var o = offH(), a = new Array(24).fill(0);
    r.h.forEach(function (v, i) { a[((i + o) % 24 + 24) % 24] += v; });
    var max = Math.max.apply(null, a) || 1, bp = bestPair(r.h, 24)[0], theirs = ((bp + Math.round(r.off / 60)) % 24 + 24) % 24, mine = ((bp + o) % 24 + 24) % 24;
    if (!sum(r.h)) return '<div class="rx-regd"><p class="rx-dim">No games from here in the last 90 days.</p></div>';
    return '<div class="rx-regd"><div class="rx-strip">' + a.map(function (v, i) {
      return '<i style="' + (v ? "background:" + color("g", 0.05 + 0.95 * Math.pow(v / max, 1.15)) : "") + '" title="' + esc(hr(i) + ": " + v) + '"></i>';
    }).join("") + '</div><div class="rx-strip-ax"><span>' + esc(hrShort(0)) + '</span><span>' + esc(hrShort(6)) + '</span><span>' + esc(hrShort(12)) + '</span><span>' + esc(hrShort(18)) + '</span><span>' + esc(hrShort(23)) + '</span></div>' +
      '<p>Busiest from ' + keep(hr(theirs)) + ' to ' + keep(hr(theirs + 2)) + ' their time' +
      (r.off / 60 !== o || tzMode === "utc" ? ', ' + keep(hr(mine)) + ' to ' + keep(hr(mine + 2)) + ' ' + (tzMode === "utc" ? "UTC" : 'your time') : "") + '.</p>' +
      (r.top && r.top.n ? '<button type="button" class="rx-golead" data-rx-tp="' + esc(r.name) + '" data-rx-go="1">See the top players here</button>' : "") + '</div>';
  }
  // the time zone band: UTC-12 on the left to UTC+14 on the right, night shaded where it's dark right now, one ink dot per place
  function band() {
    var mapW = Math.max(280, (mount.querySelector("#rx-where-b") || mount).clientWidth || 800), small = mapW < 600;   //MC 2026-10-10 smaller dots on a phone, they piled up over each other
    var W = 1000, H = 150, x = function (o) { return 20 + (o + 12) / 26 * (W - 40); }, list = D.geo.regions, top = list[0].n;
    var utcH = new Date(D.at * 1000).getUTCHours() + new Date(D.at * 1000).getUTCMinutes() / 60;
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" class="rx-band-bg" aria-hidden="true">';
    for (var o = -12; o < 14; o += 0.25) { var lh = ((utcH + o) % 24 + 24) % 24, dark = lh < 6 || lh >= 20 ? 1 : lh < 7 || lh >= 19 ? 0.5 : 0; if (dark) s += '<rect x="' + x(o).toFixed(1) + '" y="0" width="' + (x(o + 0.25) - x(o) + 0.6).toFixed(1) + '" height="' + H + '" class="rx-night" style="opacity:' + dark + '"/>'; }
    for (o = -12; o <= 14; o += 3) s += '<line x1="' + x(o) + '" x2="' + x(o) + '" y1="0" y2="' + H + '" class="rx-mer"/>';
    s += '</svg>';
    // dots in HTML so they can be buttons; the same x as the svg, which stretches to the box
    var placed = [];
    var dots = list.map(function (r, i) {
      var px = (x(r.off / 60) / W) * 100, rad = (small ? 4 : 6) + (small ? 9 : 18) * Math.sqrt(r.n / top);
      //MC 2026-10-10 places in the same time zone stack up and down: the first height where this dot clears every dot
      //   already placed (in pixels), or the least crowded one. Checking one row at a time let neighbouring rows overlap
      var X = px / 100 * mapW, best = 50, bestHit = Infinity;
      [50, 30, 70, 14, 86, 40, 60, 22, 78].some(function (py) {
        var Y = py / 100 * 150, hit = 0;
        placed.forEach(function (p) { var d = Math.hypot(p.X - X, p.Y - Y) - (p.r + rad + 2); if (d < 0) hit -= d; });
        if (hit < bestHit) { bestHit = hit; best = py; }
        return hit === 0;
      });
      var py = best;
      placed.push({ X: X, Y: best / 100 * 150, r: rad });
      return '<button type="button" class="rx-dot' + (i === regSel ? " on" : "") + (i === 0 ? " top" + (regSel < 0 ? " lbl" : "") : "") + '" data-rx-reg="' + i + '" style="left:' + px.toFixed(2) + '%;top:' + py + '%;--r:' + rad.toFixed(1) + 'px"><span>' + esc(r.name) + '</span></button>';
    }).join("");
    var me = -new Date().getTimezoneOffset() / 60, cont = [[-9, "Americas"], [1.5, "Europe and Africa"], [7.5, "Asia"], [11.5, "Oceania"]];
    return s + '<div class="rx-dots">' + dots + '<div class="rx-me" style="left:' + ((x(me) / W) * 100).toFixed(2) + '%"><div>You</div></div></div>' +
      '<div class="rx-conts" aria-hidden="true">' + cont.map(function (c) { return '<div style="left:' + ((x(c[0]) / W) * 100).toFixed(1) + '%">' + c[1] + '</div>'; }).join("") + '</div></div>' +
      '<div class="rx-map-k"><div><i class="rx-k-night"></i><div>Night right now</div></div><div><i class="rx-k-dot"></i><div>Bigger dot, more players</div></div></div>';
  }
  function globe() {
    return '<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="46" class="g1"/><ellipse cx="60" cy="60" rx="20" ry="46" class="g2"/><ellipse cx="60" cy="60" rx="46" ry="16" class="g2"/><path d="M14 60h92M60 14v92" class="g2"/><circle cx="84" cy="38" r="7" class="g3"/></svg>';
  }

  // ---------- drawing ----------
  function drawAll() { header(); calls(); heat(); todayChart(); monthChart(); where(); tops(); now(); }
  async function load() {
    try {
      var j = PRE ? PRE.data : await (await fetch(API, { cache: "no-store" })).json();
      if (!j || !j.ok) throw new Error((j && j.error) || "");
      var first = !D; D = j;
      if (first) frame();
      drawAll();
    } catch (e) {
      if (!D) mount.innerHTML = '<p class="rx-err">Couldn\'t load these numbers. Trying again in a minute.</p>';
    }
  }

  // ---------- input ----------
  mount.addEventListener("click", function (e) {
    var b;
    if ((b = e.target.closest("[data-rx-tz]"))) { tzMode = b.dataset.rxTz; put("shy-rx-tz", tzMode); sel = -1; syncSegs(); drawAll(); return; }
    if ((b = e.target.closest("[data-rx-layer]"))) { layer = b.dataset.rxLayer; sel = -1; syncSegs(); heat(); return; }
    if ((b = e.target.closest("[data-rx-win]"))) { win = +b.dataset.rxWin; sel = -1; syncSegs(); calls(); heat(); return; }
    if ((b = e.target.closest("[data-rx-all]"))) { allRegs = !allRegs; if (!allRegs && regSel >= 8) regSel = -1; where(); return; }
    if ((b = e.target.closest("[data-rx-reg]"))) { var i = +b.dataset.rxReg; regSel = regSel === i ? -1 : i; if (i >= 8) allRegs = true; where(); var f = mount.querySelector('.rx-regs [data-rx-reg="' + i + '"]'); if (f && b.classList.contains("rx-dot")) f.scrollIntoView({ block: "nearest", behavior: "smooth" }); return; }
    if ((b = e.target.closest("[data-rx-tk]"))) { topKind = b.dataset.rxTk; topAll = false; syncSegs(); tops(); return; }
    if ((b = e.target.closest("[data-rx-tall]"))) { topAll = !topAll; tops(); return; }
    if ((b = e.target.closest("[data-rx-tp]"))) {
      topPlace = b.dataset.rxTp; topAll = false; put("shy-rx-tp", topPlace); tops();
      var on = mount.querySelector(".rx-chip.on"); if (on && on.scrollIntoView) on.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
      if (b.dataset.rxGo) $("rx-tops").scrollIntoView({ block: "start", behavior: "smooth" });
      return;
    }
    if ((b = e.target.closest(".rx-c"))) { pick(+b.dataset.j); return; }
  });
  mount.addEventListener("pointerover", function (e) {
    if (!mouse(e)) return;
    var c = e.target.closest && e.target.closest(".rx-c"); if (!c) return;
    var j = +c.dataset.j, a = shift(D.heat[layer][win]), r = c.getBoundingClientRect();
    read(j, false);
    showTip('<div class="rx-th">' + keep(wd(Math.floor(j / 24), "short")) + ' ' + keep(hr(j % 24)) + '</div>' + tipRow("", LAYERS[layer], fmt(a[j])), r.left + r.width / 2, r.top);
  });
  mount.addEventListener("pointerout", function (e) {
    if (!mouse(e)) return;
    if (e.target.closest && e.target.closest(".rx-c") && !(e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest(".rx-c"))) { hideTip(); var a = shift(D.heat[layer][win]); read(sel < 0 ? peak(a) : sel, sel < 0); }
  });
  // arrow keys move around the heatmap like a grid
  mount.addEventListener("keydown", function (e) {
    var c = e.target.closest && e.target.closest(".rx-c"); if (!c) return;
    var j = +c.dataset.j, d = Math.floor(j / 24), h = j % 24, R = rows(), ri = R.indexOf(d), tall = $("rx-hm").classList.contains("is-tall");
    var mv = { ArrowLeft: tall ? [-1, 0] : [0, -1], ArrowRight: tall ? [1, 0] : [0, 1], ArrowUp: tall ? [0, -1] : [-1, 0], ArrowDown: tall ? [0, 1] : [1, 0] }[e.key];
    if (e.key === "Home") mv = [0, -h]; if (e.key === "End") mv = [0, 23 - h];
    if (!mv) return;
    e.preventDefault();
    ri = Math.max(0, Math.min(6, ri + mv[0])); h = Math.max(0, Math.min(23, h + mv[1]));
    pick(R[ri] * 24 + h, true);
  });
  var rt = null;
  window.addEventListener("resize", function () { clearTimeout(rt); rt = setTimeout(function () { if (!D) return; var w = $("rx-hm") && $("rx-hm").clientWidth; if (w !== lastW) heat(); todayChart(); monthChart(); }, 150); });
  load();
  if (!PRE) setInterval(function () { if (!document.hidden) load(); }, 60000);
})();
