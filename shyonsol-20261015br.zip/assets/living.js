//MC 2026-10-09 Living Shadows: a Shytoshi Shadow drawn with depth so it looks close to 3D without any 3D models.
//The art sits on a glowing plate a little in front of it, the whole card sways and floats in 3D space, a light sweep
//runs across it and motes rise in the Shadow's Aura colour. On a mouse it tilts toward the pointer, on a phone it tilts
//under your finger. All of it is CSS transforms and opacity, so it stays smooth on cheap Android phones. Real 3D
//(three.js and a model per Shadow) was ruled out: no models exist yet and it would be heavy on the phones most
//players use. Reduced motion turns every bit of the movement off.
(function () {
  "use strict";
  var AURAS = { cyan: 1, crimson: 1, lightning: 1, money: 1, btc: 1, none: 1 };
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  // o: { aura: "crimson", size: "160px", cls: "win|lose|enter", alt: "Shadow #255", fb: picture to use if the art fails to load }
  function html(src, o) {
    o = o || {};
    var au = AURAS[o.aura] ? o.aura : "none";
    var motes = ""; for (var i = 0; i < 6; i++) motes += '<i class="ls-mote"></i>';
    return '<div class="ls au-' + au + (o.cls ? " " + esc(o.cls) : "") + '" data-tilt' + (o.size ? ' style="--ls-s:' + esc(o.size) + '"' : "") + '>' +
      '<i class="ls-rays"></i><i class="ls-aura"></i><i class="ls-ground"></i>' +
      '<div class="ls-float"><div class="ls-sway"><div class="ls-card"><i class="ls-plate"></i>' +
      '<img class="ls-img" src="' + esc(src) + '" alt="' + esc(o.alt || "") + '" draggable="false" onerror="' + (o.fb ? "this.onerror=null;this.src='" + esc(o.fb) + "'" : "this.style.visibility='hidden'") + '">' +
      '<i class="ls-shine"></i></div></div></div>' + motes + '</div>';
  }

  // tilt toward the pointer or the finger: anything with data-tilt (Living Shadows and the NFT gallery cards)
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var cur = null, raf = 0, px = 0, py = 0;
  function apply() {
    raf = 0;
    if (!cur) return;
    var r = cur.getBoundingClientRect();
    if (!r.width) return;
    var x = Math.max(-1, Math.min(1, (px - r.left) / r.width * 2 - 1)), y = Math.max(-1, Math.min(1, (py - r.top) / r.height * 2 - 1));
    cur.style.setProperty("--tx", (x * 16).toFixed(1) + "deg");
    cur.style.setProperty("--ty", (-y * 12).toFixed(1) + "deg");
    cur.style.setProperty("--gx", (50 + x * 40).toFixed(0) + "%");
    cur.classList.add("tilting");
  }
  function release(el) { if (!el) return; el.style.removeProperty("--tx"); el.style.removeProperty("--ty"); el.style.removeProperty("--gx"); el.classList.remove("tilting"); }
  function track(el, x, y) {
    if (el !== cur) { release(cur); cur = el; }
    if (!el) return;
    px = x; py = y;
    if (!raf) raf = requestAnimationFrame(apply);
  }
  if (!reduce) {
    // a mouse: tilt while hovering
    document.addEventListener("pointermove", function (e) {
      if (e.pointerType !== "mouse") return;
      track(e.target.closest ? e.target.closest("[data-tilt]") : null, e.clientX, e.clientY);
    }, { passive: true });
    document.addEventListener("pointerleave", function () { track(null); }, { passive: true });
    // a finger: tilt while it rests on or drags across a Shadow, without ever stopping the page from scrolling
    document.addEventListener("touchstart", function (e) { var t = e.touches[0], el = e.target.closest ? e.target.closest("[data-tilt]") : null; if (el && t) track(el, t.clientX, t.clientY); }, { passive: true });
    document.addEventListener("touchmove", function (e) { if (!cur) return; var t = e.touches[0]; if (t) track(cur, t.clientX, t.clientY); }, { passive: true });
    var end = function () { var el = cur; cur = null; setTimeout(function () { if (el !== cur) release(el); }, 120); };
    document.addEventListener("touchend", end, { passive: true });
    document.addEventListener("touchcancel", end, { passive: true });
  }

  // the NFTs page: one big Shadow that steps through the collection, with arrows and a swipe
  function showcase(box) {
    var list = (box.dataset.nfts || "").split("|").filter(Boolean).map(function (x) { var i = x.indexOf(":"); return { n: x.slice(0, i), src: x.slice(i + 1) }; });
    if (!list.length) return;
    var stage = box.querySelector("[data-sc-stage]"), label = box.querySelector("[data-sc-n]"), i = 0, timer = 0;
    function show(k) {
      i = (k + list.length) % list.length;
      var x = list[i];
      stage.innerHTML = html(x.src, { cls: "enter", alt: "Shytoshi Shadow #" + x.n });
      if (label) label.textContent = "#" + x.n;
    }
    function next(d) { clearInterval(timer); show(i + d); if (!reduce) timer = setInterval(function () { if (!document.hidden && box.getBoundingClientRect().top < innerHeight) show(i + 1); }, 4500); }
    box.addEventListener("click", function (e) { var b = e.target.closest("[data-sc]"); if (b) next(b.dataset.sc === "prev" ? -1 : 1); });
    var sx = null;
    stage.addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; }, { passive: true });
    stage.addEventListener("touchend", function (e) { if (sx == null) return; var dx = e.changedTouches[0].clientX - sx; sx = null; if (Math.abs(dx) > 45) next(dx < 0 ? 1 : -1); }, { passive: true });
    next(0);
  }
  function init() { document.querySelectorAll("[data-showcase]").forEach(showcase); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();

  window.ShyLiving = { html: html };
})();
