// Buy $SHY on the token page: Jupiter's own swap box, loaded only when it scrolls into view.
// The swap runs between the visitor's wallet and Jupiter; this site never touches the funds.
(function () {
  "use strict";
  var box = document.getElementById("jup-box");
  if (!box) return;
  var CA = "7d1vpt5eri79nETcL74Punhp3mGkeBgUkMdPWep6pump", SOL = "So11111111111111111111111111111111111111112";
  var started = false;
  function fail() {
    var f = document.getElementById("jup-fail");
    box.hidden = true; if (f) f.hidden = false;
    var lv = document.querySelector(".jup-live"); if (lv) lv.hidden = true;
  }
  // after a swap: welcome them in and point at what holding unlocks in the game
  //MC 2026-10-09 tell the site about the swap so it counts in the team's reports (the server checks it on Solana)
  function logSwap(txid) {
    if (!txid) return;
    var pid = ""; try { pid = localStorage.getItem("shy-lb-pid") || ""; } catch (e) {}
    try { fetch("/api/buylog.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sig: String(txid), pid: pid }), keepalive: true }).catch(function () {}); } catch (e) {}
  }
  function thanks(txid) {
    logSwap(txid);
    var n = document.getElementById("jup-done");
    if (!n) { n = document.createElement("div"); n.id = "jup-done"; n.className = "jup-done"; box.parentNode.appendChild(n); }
    n.innerHTML = '<b>Welcome to the Shy Army.</b><p>Your $SHY is in your wallet. Connect that wallet in the game to unlock holder perks: shop discounts, weekly Koban and holder-only events.</p>' +
      '<div class="hero-actions"><a class="btn btn-red btn-sm" href="/profile">Connect it in the game</a>' + (txid ? '<a class="btn btn-line btn-sm" href="https://solscan.io/tx/' + encodeURIComponent(txid) + '" target="_blank" rel="noopener">See the swap</a>' : "") + '</div>';
  }
  function start() {
    if (started) return; started = true;
    var s = document.createElement("script");
    s.src = "https://plugin.jup.ag/plugin-v1.js"; s.async = true;
    var t = setTimeout(fail, 15000);
    s.onerror = function () { clearTimeout(t); fail(); };
    s.onload = function () {
      clearTimeout(t);
      try {
        window.Jupiter.init({
          displayMode: "integrated",
          integratedTargetId: "jup-box",
          formProps: { initialInputMint: SOL, initialOutputMint: CA, fixedMint: CA },
          containerStyles: { width: "100%", minHeight: "520px", borderRadius: "20px", overflow: "hidden" },
          branding: { logoUri: "https://cdn.dexscreener.com/cms/images/e00545c6c36dd72c37ce8ea099bde5f1f17dd30ce463d9774453065e2d65d7e4?width=128&height=128&quality=95&format=auto", name: "Shy on Solana" },
          defaultExplorer: "Solscan",
          onSuccess: function (r) { thanks(r && r.txid); }
        });
        box.classList.add("on");
      } catch (e) { fail(); }
    };
    document.head.appendChild(s);
  }
  // straight away when someone came here to buy (#buy), otherwise as the box comes into view
  if (location.hash === "#buy" || !("IntersectionObserver" in window)) start();
  else {
    var io = new IntersectionObserver(function (es) { if (es.some(function (e) { return e.isIntersecting; })) { io.disconnect(); start(); } }, { rootMargin: "400px" });
    io.observe(box);
  }
})();
