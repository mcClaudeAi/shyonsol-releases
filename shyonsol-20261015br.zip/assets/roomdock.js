// The room bar: your live room, kept with you while you look around. Players waiting for a match got bored and left
// (an idea from a player); now they can scroll the Play page or open any other page and keep their seat.
// The bar shows the room code, who's in it (a dot per seat), the countdown, and Back to room. When someone joins it
// chimes, buzzes the phone, flashes the tab title and (if you allowed it) sends a browser notification. When the
// match starts it takes you back to the table.
// On the Play page, play.js drives it (ShyDock.show / hide). Everywhere else this file keeps the seat itself: it asks
// the room for news every few seconds with the seat saved in this browser (shy-live), which is also what stops the
// server handing your seat to a bot (it does that after 20 seconds without a word from you).
//MC 2026-10-15 first version
(function () {
  "use strict";
  var API = "/api/live.php";
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function clock(s) { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ":" + ("0" + (s % 60)).slice(-2); }

  // ---------- alerts: a two-note chime, a buzz, the tab title, a notification ----------
  var ac = null;
  function chime(up) {
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      if (ac.state === "suspended") ac.resume();
      var t = ac.currentTime;
      [[up ? 660 : 523, 0], [up ? 990 : 784, 0.12]].forEach(function (n) {
        var o = ac.createOscillator(), gn = ac.createGain();
        o.type = "triangle"; o.frequency.value = n[0];
        gn.gain.setValueAtTime(0.0001, t + n[1]); gn.gain.exponentialRampToValueAtTime(0.18, t + n[1] + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t + n[1] + 0.35);
        o.connect(gn); gn.connect(ac.destination); o.start(t + n[1]); o.stop(t + n[1] + 0.4);
      });
    } catch (e) {}
  }
  var baseTitle = document.title, flashT = 0;
  function flashTitle(msg) {
    clearInterval(flashT); var on = false, n = 0;
    flashT = setInterval(function () { on = !on; document.title = on ? msg : baseTitle; if (++n > 12 && !document.hidden) { clearInterval(flashT); document.title = baseTitle; } }, 900);
  }
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { setTimeout(function () { clearInterval(flashT); document.title = baseTitle; }, 2500); } });
  function notify(title, body) {
    try { if (document.hidden && "Notification" in window && Notification.permission === "granted") new Notification(title, { body: body, icon: "/assets/art/icon-192.png", tag: "shy-room" }); } catch (e) {}
  }
  // someone new sat down: everything at once, so it's noticed wherever you are
  function alertJoin(name, count, n) {
    chime(true);
    try { if (navigator.vibrate) navigator.vibrate([60, 40, 60]); } catch (e) {}
    flashTitle("(" + count + "/" + n + ") " + name + " joined");
    notify(name + " joined your room", count + " of " + n + " seats taken. Tap to go back to the table.");
    pop(name + " joined");
  }
  function alertStart() {
    chime(false);
    try { if (navigator.vibrate) navigator.vibrate([120, 60, 120]); } catch (e) {}
    flashTitle("Your match is starting");
    notify("Your match is starting", "Back to the table, your first turn is coming up.");
  }

  // ---------- the bar ----------
  var el = null, onBack = null, onLeave = null, popT = 0, S = null, tickT = 0;
  function build() {
    if (el) return el;
    el = document.createElement("div");
    el.className = "rdock"; el.setAttribute("role", "region"); el.setAttribute("aria-label", "Your live room");
    el.innerHTML = '<span class="rd-live" aria-hidden="true"></span><div class="rd-main"><b class="rd-h"></b><span class="rd-s"></span></div>' +
      '<div class="rd-seats" aria-hidden="true"></div><span class="rd-pop" aria-live="polite"></span>' +
      '<button type="button" class="rd-bell" title="Alert me when someone joins" aria-label="Alert me when someone joins" hidden>🔔</button>' +
      '<button type="button" class="btn btn-red btn-sm rd-back">Back to room</button>' +
      '<button type="button" class="rd-x" title="Leave the room" aria-label="Leave the room">&times;</button>';
    document.body.appendChild(el);
    el.querySelector(".rd-back").addEventListener("click", function () { if (onBack) onBack(); });
    el.querySelector(".rd-x").addEventListener("click", function (e) {
      var b = e.currentTarget;
      if (!b.classList.contains("sure")) { b.classList.add("sure"); b.textContent = "Leave?"; setTimeout(function () { b.classList.remove("sure"); b.innerHTML = "&times;"; }, 3000); return; }
      if (onLeave) onLeave();
    });
    var bell = el.querySelector(".rd-bell");
    if ("Notification" in window && Notification.permission === "default") {
      bell.hidden = false;
      bell.addEventListener("click", function () { try { Notification.requestPermission().then(function () { bell.hidden = true; }); } catch (e) { bell.hidden = true; } });
    }
    return el;
  }
  function pop(t) { if (!el) return; var p = el.querySelector(".rd-pop"); p.textContent = t; el.classList.add("popped"); clearTimeout(popT); popT = setTimeout(function () { el.classList.remove("popped"); }, 3200); }
  // st: {code, seats:[{name, img, human}], n, startsAt (server seconds), offset, isPublic, host, held, status}
  function draw() {
    if (!el || !S) return;
    var humans = S.seats.filter(function (s) { return s.human; }).length;
    el.querySelector(".rd-h").innerHTML = 'Room <span data-i18n-skip>' + esc(S.code) + '</span>';
    var left = S.startsAt ? S.startsAt - (Date.now() / 1000 + (S.offset || 0)) : null;
    var line = S.status === "playing" ? "Your match is starting" : left != null ? (left > 0 ? "Starts in " + clock(left) : "Starting...") : S.host ? (S.seats.length > 1 ? "Ready to start" : "Invite friends") : "Waiting for the host";
    el.querySelector(".rd-s").textContent = line + " · " + humans + (humans === 1 ? " player" : " players");
    var dots = "";
    for (var i = 0; i < (S.n || 4); i++) {
      var s = S.seats[i];
      dots += s ? '<i class="' + (s.human ? "h" : "b") + (s.me ? " me" : "") + '" title="' + esc(String(s.name || "").replace(" (bot)", "")) + '">' + (s.img ? '<img src="' + esc(s.img) + '" alt="" onerror="this.remove()">' : '<em>' + esc(String(s.name || "?").charAt(0)) + '</em>') + '</i>' : '<i class="o"></i>';
    }
    el.querySelector(".rd-seats").innerHTML = dots;
    el.classList.toggle("go", S.status === "playing");
  }
  function show(st, back, leave) {
    S = st; onBack = back; onLeave = leave;
    build(); draw();
    document.documentElement.classList.add("has-rdock");
    if (!el.classList.contains("in")) requestAnimationFrame(function () { el && el.classList.add("in"); });
    clearInterval(tickT); tickT = setInterval(draw, 1000);
  }
  function hide() {
    clearInterval(tickT);
    if (!el) return;
    el.classList.remove("in");
    document.documentElement.classList.remove("has-rdock");
  }
  window.ShyDock = { show: show, hide: hide, alertJoin: alertJoin, alertStart: alertStart, chime: chime };

  // ---------- on every page but Play: keep the seat and watch the room ----------
  if (document.getElementById("g-room")) return;   // the Play page: play.js does this
  var saved = null; try { saved = JSON.parse(store("shy-live") || "null"); } catch (e) {}
  if (!saved || !saved.code || !saved.secret || Date.now() - (saved.ts || 0) > 2 * 3600e3 || saved.kind === "watch") return;
  var ver = 0, known = null, last = null, gone = false, errs = 0;
  function back() { location.href = "/play#game"; }
  function leave() {
    fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "leave", code: saved.code, seat: saved.seat, secret: saved.secret }) }).catch(function () {});
    store("shy-live", null); hide();
  }
  function poll() {
    if (gone) return;
    fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "state", code: saved.code, seat: saved.seat, secret: saved.secret, ver: ver }) })
      .then(function (r) { return r.json(); }).then(function (v) {
        if (!v || !v.ok) {
          if (v && /not in this room|not found/i.test(v.error || "")) { gone = true; store("shy-live", null); hide(); return; }
          if (++errs > 6) { hide(); }
          return;
        }
        errs = 0;
        if (v.same) return;
        ver = v.ver; last = v;
        if (v.status === "closed" || v.status === "over") { gone = true; store("shy-live", null); hide(); return; }
        var names = v.seats.filter(function (s) { return s.human; }).map(function (s) { return s.name; });
        if (known) names.forEach(function (n, i) { if (known.indexOf(n) < 0 && i !== saved.seat) alertJoin(String(n).replace(" (bot)", ""), names.length, v.seats.length > 4 ? v.seats.length : 4); });
        known = names;
        show({ code: saved.code, seats: v.seats.map(function (s, i) { return { name: s.name, img: s.img, human: s.human, me: i === saved.seat }; }), n: 4,
          startsAt: v.startsAt || (v.tourney ? v.startsAt : 0), offset: v.now - Date.now() / 1000, host: !!v.host, status: v.status }, back, leave);
        if (v.status === "playing") {
          gone = true; alertStart();
          // back to the table: now if this tab is open in front of them, the moment they come back if not
          var go = function () { setTimeout(back, 1200); };
          if (!document.hidden) go(); else document.addEventListener("visibilitychange", function once() { if (!document.hidden) { document.removeEventListener("visibilitychange", once); go(); } });
        }
      }).catch(function () { errs++; })
      .then(function () { if (!gone) setTimeout(poll, document.hidden ? 5000 : 3000); });
  }
  setTimeout(poll, 400);
})();
