//MC 2026-10-13 the admin frame (was sections.js). The server draws a whole tab; this file shows the part of it that
//   belongs to the page you opened (window.ADM from nav.php), adds underline tabs when a page has three or more parts,
//   follows #links to the page that holds them, keeps the page on every form you send (_p), folds sidebar groups,
//   opens the phone menu, the Needs you list and search (Ctrl K or /). Every form and button in the tab is still in the
//   page, just hidden when it belongs to another page.
(function () {
  "use strict";
  var ADM = window.ADM || null;
  var main = document.querySelector("main");
  if (!ADM || !main) return;
  var pages = ADM.pages, cur = ADM.p, P = pages[cur] || {};
  function slug(t) { return String(t).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "part"; }
  function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }

  // ---------------------------------------------------------------- the tab's parts (one per heading)
  // headings sit at different depths (inside view-only/edit wrappers, or inside one big settings form): walk into any
  // box that holds two or more headings of its own, so each heading starts its own part wherever it is
  function heads(el) { return [].filter.call(el.children, function (k) { return k.tagName === "H2" || (k.firstElementChild && k.firstElementChild.tagName === "H2"); }).length; }
  function titleOf(h) { var c = h.cloneNode(true), sm = c.querySelector("small"), badge = sm ? sm.textContent.trim() : ""; if (sm) sm.remove(); return { t: c.textContent.trim(), b: badge }; }
  var secs = [], part = null, intro = [], always = [];
  function walk(box) {
    // a settings form split over several parts keeps its Save buttons (the last rows) visible in every one of them
    var keep = [];
    if (box.tagName === "FORM") for (var k = box.children.length - 1; k >= 0; k--) { var c = box.children[k]; if (c.tagName === "H2" || c.querySelector("h2")) break; if (c.matches("button,.bar,.btns") || c.querySelector("button")) keep.push(c); else break; }
    [].forEach.call(box.children, function (el) {
      if (keep.indexOf(el) >= 0) return;
      if (el.tagName === "SCRIPT" || el.tagName === "LINK" || el.tagName === "STYLE" || (el.tagName === "INPUT" && el.type === "hidden")) return;
      if (el.matches(".flash,.viewonly,.needs-home")) { always.push(el); return; }
      if (el.classList.contains("guide")) { intro.push(el); return; }   // the guide has tabs of its own
      if (el.tagName !== "H2" && heads(el) >= 2) { walk(el); return; }
      var h = el.tagName === "H2" ? el : (el.firstElementChild && el.firstElementChild.tagName === "H2" ? el.firstElementChild : null);
      if (h) { var ti = titleOf(h); part = { title: ti.t, badge: ti.b, key: slug(ti.t), id: "s-" + slug(ti.t), els: [el], h: h }; secs.push(part); return; }
      if (part) part.els.push(el); else intro.push(el);
    });
  }
  walk(main);
  var seen = {}; secs.forEach(function (s) { var id = s.id, n = 2; while (seen[id]) id = s.id + "-" + n++; seen[id] = 1; s.id = id; });

  // which parts each page of this tab shows: its listed headings; a main page also takes any heading no page lists
  var tabPages = Object.keys(pages).filter(function (k) { return pages[k].tab === ADM.tab; });
  var claimed = {};
  tabPages.forEach(function (k) { (pages[k].s || []).forEach(function (t) { claimed[slug(t)] = k; }); });
  function partsOf(k) {
    var pg = pages[k]; if (!pg) return [];
    if (tabPages.length === 1 || !pg.s) return secs.filter(function (s) { return tabPages.length === 1 || !claimed[s.key] || claimed[s.key] === k; });
    var want = {}; pg.s.forEach(function (t) { want[slug(t)] = 1; });
    return secs.filter(function (s) { return want[s.key] || (pg.main && !claimed[s.key]); });
  }
  function pageOfPart(s) { for (var i = 0; i < tabPages.length; i++) if (partsOf(tabPages[i]).indexOf(s) >= 0) return tabPages[i]; return null; }
  function partOf(el) { for (var i = 0; i < secs.length; i++) if (secs[i].els.some(function (e) { return e === el || e.contains(el); })) return secs[i]; return null; }

  var nav = null, mine = [];
  function show(k, partId) {
    cur = k; P = pages[k];
    mine = partsOf(k);
    var showIntro = tabPages.length === 1 || P.main;
    intro.forEach(function (e) { e.hidden = !showIntro; });
    secs.forEach(function (s) { s.els.forEach(function (e) { e.hidden = mine.indexOf(s) < 0; }); });
    if (nav) { nav.remove(); nav = null; }
    var empty = main.querySelector(".pg-empty"); if (empty) empty.remove();
    if (!mine.length && secs.length && !showIntro) { var d = document.createElement("p"); d.className = "pg-empty"; d.textContent = "Nothing on this page for your access. Ask an owner if you need it."; main.appendChild(d); }
    secs.forEach(function (s) { s.h.classList.remove("pg-first"); });
    if (mine.length >= 3) {
      nav = document.createElement("nav"); nav.className = "secnav"; nav.setAttribute("aria-label", "Parts of this page");
      nav.innerHTML = mine.map(function (s) { return '<a href="#' + s.id + '" data-sec="' + s.id + '">' + esc(s.title) + (s.badge && /^\d[\d,]*$/.test(s.badge) ? " <i>" + esc(s.badge) + "</i>" : "") + "</a>"; }).join("");
      mine[0].els[0].before(nav);
      var key = "adm-sec:" + k, pick = partId || store(key) || mine[0].id;
      if (!mine.some(function (s) { return s.id === pick; })) pick = mine[0].id;
      tabTo(pick, false);
    } else if (mine[0]) mine[0].h.classList.add("pg-first");
    // header, crumbs and the sidebar follow the page
    var t = document.querySelector("[data-title]"), d2 = document.querySelector("[data-desc]"), c = document.querySelector("[data-crumb]"), hw = document.querySelector("[data-howto]");
    if (t) t.textContent = P.t; if (d2) d2.textContent = P.d; if (c) c.textContent = P.t; if (hw) hw.href = "?p=guide#g-" + P.guide;
    document.title = P.t + " · Shy admin";
    document.querySelectorAll(".snav a[data-p]").forEach(function (a) { var on = a.dataset.p === k; a.classList.toggle("on", on); if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current"); });
  }
  // for the search index builder (scripts/admin_index): this page's parts and the elements in each
  ADM.parts = function () { return mine.length ? mine.map(function (s) { return { t: s.title, els: s.els }; }) : [{ t: "", els: [main] }]; };
  function tabTo(id, scroll) {
    if (!nav) return;
    mine.forEach(function (s) { var on = s.id === id; s.els.forEach(function (e) { e.hidden = !on; }); });
    nav.querySelectorAll("a").forEach(function (a) { var on = a.dataset.sec === id; a.classList.toggle("on", on); if (on) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current"); });
    store("adm-sec:" + cur, id);
    if (scroll) { var top = nav.getBoundingClientRect().top; if (top < 0 || top > 200) nav.scrollIntoView({ block: "start" }); }
  }
  main.addEventListener("click", function (e) { var a = e.target.closest(".secnav a[data-sec]"); if (!a) return; e.preventDefault(); tabTo(a.dataset.sec, true); history.replaceState(null, "", location.pathname + "?p=" + cur + "#" + a.dataset.sec); });

  // open on the right page: a #link or ?find= inside this tab may belong to one of its other pages
  function target() {
    var h = decodeURIComponent((location.hash || "").slice(1));
    if (h.indexOf("s-") === 0) { var s0 = secs.filter(function (s) { return s.id === h; })[0]; if (s0) return { s: s0, el: null }; }
    var el = h ? document.getElementById(h) : null;
    var f = new URLSearchParams(location.search).get("find");
    if (!el && f) el = findText(f);
    return el ? { s: partOf(el), el: el } : null;
  }
  function findText(q) {
    q = q.toLowerCase();
    var c = main.querySelectorAll("h2,h3,legend,label,th,summary,.fs-d,b");
    for (var i = 0; i < c.length; i++) if ((c[i].textContent || "").toLowerCase().indexOf(q) >= 0) return c[i].closest("label") || c[i];
    return null;
  }
  var tg = target(), start = cur;
  if (tg && tg.s && partsOf(cur).indexOf(tg.s) < 0) { var other = pageOfPart(tg.s); if (other) start = other; }
  show(start, tg && tg.s ? tg.s.id : null);
  if (start !== ADM.p || /[?&]tab=/.test(location.search)) history.replaceState(null, "", location.pathname + "?p=" + start + location.search.replace(/^\?/, "&").replace(/&(tab|p)=[^&]*/g, "") + location.hash);
  if (tg && tg.el && (tg.s || new URLSearchParams(location.search).get("find"))) setTimeout(function () { tg.el.scrollIntoView({ block: "center" }); tg.el.classList.add("hl"); var inp = tg.el.querySelector && tg.el.querySelector("input,select,textarea"); if (inp && new URLSearchParams(location.search).get("find")) try { inp.focus({ preventScroll: true }); } catch (e) {} }, 60);

  // every form remembers the page it was sent from, so the answer comes back here
  document.addEventListener("submit", function (e) {
    var f = e.target; if (!f || f.tagName !== "FORM") return;
    if ((f.method || "get").toLowerCase() === "post") { var x = f.querySelector('input[name="_p"]'); if (!x) { x = document.createElement("input"); x.type = "hidden"; x.name = "_p"; f.appendChild(x); } x.value = cur; }
    else { var tb = f.querySelector('input[name="tab"]'); if (tb && tb.value === ADM.tab && !f.querySelector('input[name="p"]')) { var y = document.createElement("input"); y.type = "hidden"; y.name = "p"; y.value = cur; f.appendChild(y); tb.remove(); } }
  }, true);

  // ---------------------------------------------------------------- unsaved changes
  // long settings forms keep Save at the very bottom; once anything in one changes, a bar at the bottom of the screen
  // offers Save and Undo, and leaving the page asks first
  var dirty = null, bar = null;
  function saveBtn(f) { var b = f.querySelectorAll('button[name="do"]'); return b.length ? b[b.length - 1] : null; }
  function setDirty(f) {
    if (dirty === f) return; dirty = f;
    if (!bar) {
      bar = document.createElement("div"); bar.className = "dirty"; bar.setAttribute("role", "status");
      bar.innerHTML = '<span><b>Unsaved changes</b><small></small></span><button type="button" class="ghost" data-undo>Undo</button><button type="button" class="primary" data-save>Save</button>';
      document.body.appendChild(bar);
      bar.addEventListener("click", function (e) {
        if (!dirty) return;
        if (e.target.closest("[data-undo]")) { dirty.reset(); dirty = null; bar.hidden = true; }
        else if (e.target.closest("[data-save]")) { var b = saveBtn(dirty); if (b) b.click(); }
      });
    }
    var leg = f.querySelector("legend,h2"), h = f.previousElementSibling && f.previousElementSibling.tagName === "H2" ? f.previousElementSibling : null;
    bar.querySelector("small").textContent = (h || leg) ? "in " + titleOf(h || leg).t : "";
    var sb = saveBtn(f); bar.querySelector("[data-save]").textContent = sb ? sb.textContent.trim().slice(0, 28) : "Save";
    bar.hidden = false;
  }
  main.addEventListener("input", function (e) {
    var f = e.target.form; if (!f || (f.method || "").toLowerCase() !== "post" || f.closest(".ro")) return;
    if (f.querySelectorAll("input:not([type=hidden]),select,textarea").length < 6 || !saveBtn(f)) return;
    setDirty(f);
  });
  document.addEventListener("submit", function () { dirty = null; if (bar) bar.hidden = true; });
  window.addEventListener("beforeunload", function (e) { if (dirty) { e.preventDefault(); e.returnValue = ""; } });

  // ---------------------------------------------------------------- player picker (data-pick="players")
  // type part of a name, id or wallet; the matches drop down (best players first) and a tap or Enter picks one. The box
  // then holds that player's exact name, which the form looks up as before.
  document.querySelectorAll('input[data-pick="players"]').forEach(function (inp) {
    var box = document.createElement("div"); box.className = "pick"; box.hidden = true; box.setAttribute("role", "listbox");
    var wrap = document.createElement("span"); wrap.className = "pick-wrap";
    inp.parentNode.insertBefore(wrap, inp); wrap.appendChild(inp); wrap.appendChild(box);
    inp.setAttribute("role", "combobox"); inp.setAttribute("aria-autocomplete", "list"); inp.setAttribute("aria-expanded", "false");
    var list = [], at = -1, timer = null, seq = 0, chosen = "";
    function close() { box.hidden = true; inp.setAttribute("aria-expanded", "false"); at = -1; }
    function draw() {
      if (!list.length) { box.innerHTML = '<p class="pick-none">No player matches that.</p>'; box.hidden = false; return; }
      box.innerHTML = list.map(function (x, i) { return '<button type="button" role="option" data-i="' + i + '"' + (i === at ? ' class="on" aria-selected="true"' : "") + '><b>' + esc(x.n) + '</b>' + (x.h ? '<em>Holder</em>' : "") + '<small>' + esc(x.id) + ' · ' + Number(x.pts).toLocaleString("en-US") + ' pts · ' + x.g + (x.g === 1 ? " game" : " games") + '</small></button>'; }).join("");
      box.hidden = false; inp.setAttribute("aria-expanded", "true");
    }
    function pick(i) { var x = list[i]; if (!x) return; inp.value = x.n; chosen = x.n; inp.dataset.picked = x.id; close(); inp.classList.add("picked"); }
    inp.addEventListener("input", function () {
      inp.classList.remove("picked"); delete inp.dataset.picked;
      var q = inp.value.trim(); clearTimeout(timer);
      if (!q) { close(); return; }
      timer = setTimeout(function () {
        var my = ++seq;
        fetch("?pq=" + encodeURIComponent(q), { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (j) {
          if (my !== seq || !j.ok) return; list = j.p || []; at = list.length ? 0 : -1; draw();
        }).catch(function () {});
      }, 160);
    });
    inp.addEventListener("keydown", function (e) {
      if (box.hidden) return;
      if (e.key === "ArrowDown" || e.key === "ArrowUp") { e.preventDefault(); if (!list.length) return; at = (at + (e.key === "ArrowDown" ? 1 : -1) + list.length) % list.length; draw(); }
      else if (e.key === "Enter" && at >= 0) { e.preventDefault(); pick(at); }
      else if (e.key === "Escape") { e.stopPropagation(); close(); }
    });
    box.addEventListener("mousedown", function (e) { e.preventDefault(); });   // keep focus in the box while picking
    box.addEventListener("click", function (e) { var b = e.target.closest("button[data-i]"); if (b) pick(+b.dataset.i); });
    inp.addEventListener("blur", function () { setTimeout(close, 120); });
  });

  // ---------------------------------------------------------------- sidebar: folding groups, the phone drawer
  var folded = {}; try { folded = JSON.parse(store("adm-fold") || "{}") || {}; } catch (e) {}
  document.querySelectorAll(".sg[data-g]").forEach(function (g) {
    var b = g.querySelector(".sgh"), k = g.dataset.g, has = !!g.querySelector("a.on");
    if (folded[k] && !has) b.setAttribute("aria-expanded", "false");
    b.addEventListener("click", function () { var o = b.getAttribute("aria-expanded") !== "true"; b.setAttribute("aria-expanded", o ? "true" : "false"); folded[k] = !o; store("adm-fold", JSON.stringify(folded)); });
  });
  var onLink = document.querySelector(".snav a.on"); if (onLink && onLink.scrollIntoView) onLink.scrollIntoView({ block: "nearest" });
  var opener = document.querySelector("[data-side-open]"), side = document.getElementById("side");
  function drawer(o) {
    document.body.classList.toggle("side-open", o);
    if (opener) opener.setAttribute("aria-expanded", o ? "true" : "false");
    if (o) { var a = side.querySelector("a.on") || side.querySelector("a"); if (a) a.focus({ preventScroll: true }); } else if (opener && opener.offsetParent) opener.focus();
  }
  if (opener) opener.addEventListener("click", function () { drawer(true); });
  document.querySelectorAll("[data-side-close]").forEach(function (x) { x.addEventListener("click", function () { drawer(false); }); });

  // ---------------------------------------------------------------- Needs you
  var nb = document.querySelector("[data-needs]"), np = document.getElementById("needs-p");
  function needs(o) { if (!np) return; np.hidden = !o; nb.setAttribute("aria-expanded", o ? "true" : "false"); }
  if (nb) nb.addEventListener("click", function (e) { e.stopPropagation(); needs(np.hidden); });
  document.addEventListener("click", function (e) { if (np && !np.hidden && !np.contains(e.target)) needs(false); });

  // ---------------------------------------------------------------- search: pages, parts of pages and settings
  var pal = null, list = null, inp = null, idx = null, res = [], sel = 0, lastFocus = null;
  var GLYPH = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>';
  function base() {
    var out = [];
    Object.keys(pages).forEach(function (k) { var p = pages[k]; out.push({ k: "Page", t: p.l === p.t ? p.t : p.l + " · " + p.t, d: (p.g ? p.g + ". " : "") + p.d, u: "?p=" + k, w: 3 }); });
    // parts of the page you're on (they're all in the document, wherever they sit)
    secs.forEach(function (s) { var k = pageOfPart(s) || cur; out.push({ k: "Section", t: s.title, d: "On " + pages[k].t, u: "?p=" + k + "#" + s.id, w: 2 }); });
    (idx || []).forEach(function (x) { if (!pages[x.p]) return; if (x.p === cur && x.top) return; out.push({ k: x.k, t: x.t, d: (x.k === "Guide" ? "How-to guide" : "On " + pages[x.p].t) + (x.s ? ", " + x.s : ""), u: "?p=" + x.p + (x.a ? "#" + x.a : x.top ? "#s-" + slug(x.t) : "&find=" + encodeURIComponent(x.t)), w: x.top ? 2 : 1 }); });
    return out;
  }
  // only a page's description counts, everything else matches on its own name
  function score(it, words) {
    var t = it.t.toLowerCase(), d = (it.d || "").toLowerCase(), s = 0;
    for (var i = 0; i < words.length; i++) { var w = words[i], a = t.indexOf(w); if (a < 0 && (it.k !== "Page" || d.indexOf(w) < 0)) return 0; s += a === 0 ? 6 : a > 0 ? (t.charAt(a - 1) === " " ? 4 : 2) : 1; }
    return s * 10 + it.w;
  }
  function mark(t, words) { var h = esc(t); words.forEach(function (w) { if (!w) return; h = h.replace(new RegExp("(" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "ig"), "<mark>$1</mark>"); }); return h; }
  function render() {
    var q = inp.value.trim().toLowerCase(), words = q.split(/\s+/).filter(Boolean), all = base();
    if (!words.length) res = all.filter(function (x) { return x.k === "Page"; });
    else {
      res = all.map(function (x) { return { x: x, s: score(x, words) }; }).filter(function (y) { return y.s > 0; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 40).map(function (y) { return y.x; });
      var seenU = {}; res = res.filter(function (x) { if (seenU[x.u]) return false; seenU[x.u] = 1; return true; });
      if (q.length >= 2 && pages.players) res.push({ k: "Player", t: "Find players named “" + inp.value.trim() + "”", d: "Search names, ids and wallets on All players", u: "?p=players&q=" + encodeURIComponent(inp.value.trim()) });
    }
    sel = 0;
    list.innerHTML = res.length ? res.map(function (x, i) { return '<li role="option" id="pal-o' + i + '"' + (i === sel ? ' class="on" aria-selected="true"' : "") + '><a href="' + esc(x.u) + '"><em class="k">' + x.k + "</em><span><b>" + mark(x.t, words) + "</b><small>" + esc(x.d || "") + "</small></span></a></li>"; }).join("") : '<li class="pal-none">Nothing matches. Try a shorter word, like "price" or "pin".</li>';
    inp.setAttribute("aria-activedescendant", res.length ? "pal-o0" : "");
  }
  function move(d) {
    if (!res.length) return;
    var lis = list.querySelectorAll("li[role=option]"); lis[sel].classList.remove("on"); lis[sel].removeAttribute("aria-selected");
    sel = (sel + d + res.length) % res.length; lis[sel].classList.add("on"); lis[sel].setAttribute("aria-selected", "true"); lis[sel].scrollIntoView({ block: "nearest" });
    inp.setAttribute("aria-activedescendant", "pal-o" + sel);
  }
  function go(u) { var a = document.createElement("a"); a.href = u; if (a.pathname === location.pathname && a.search === location.search && a.hash) { location.hash = a.hash; location.reload(); } else location.href = u; }
  function openPal() {
    if (!pal) {
      pal = document.createElement("div"); pal.className = "pal"; pal.hidden = true;
      pal.innerHTML = '<div class="pal-b" role="dialog" aria-modal="true" aria-label="Search the admin"><div class="pal-i">' + GLYPH + '<input type="text" role="combobox" aria-expanded="true" aria-controls="pal-r" aria-autocomplete="list" placeholder="Search pages, sections and settings" autocomplete="off" spellcheck="false"><kbd>Esc</kbd></div><ul class="pal-r" id="pal-r" role="listbox"></ul><div class="pal-f"><span>↑ ↓ to move</span><span>Enter to open</span><span>Ctrl K or / from anywhere</span></div></div>';
      document.body.appendChild(pal);
      list = pal.querySelector(".pal-r"); inp = pal.querySelector("input");
      inp.addEventListener("input", render);
      inp.addEventListener("keydown", function (e) {
        if (e.key === "ArrowDown") { e.preventDefault(); move(1); } else if (e.key === "ArrowUp") { e.preventDefault(); move(-1); }
        else if (e.key === "Enter") { e.preventDefault(); if (res[sel]) go(res[sel].u); }
      });
      pal.addEventListener("click", function (e) { if (e.target === pal) closePal(); var a = e.target.closest(".pal-r a"); if (a) { e.preventDefault(); go(a.getAttribute("href")); } });
      if (ADM.idx) fetch(ADM.idx, { credentials: "same-origin" }).then(function (r) { return r.ok ? r.json() : []; }).then(function (j) { idx = Array.isArray(j) ? j : []; if (!pal.hidden) render(); }).catch(function () {});
    }
    lastFocus = document.activeElement; drawer(false); needs(false);
    pal.hidden = false; inp.value = ""; render(); inp.focus();
  }
  function closePal() { if (!pal || pal.hidden) return; pal.hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus(); }
  document.querySelectorAll("[data-palette]").forEach(function (b) { b.addEventListener("click", openPal); });
  document.addEventListener("keydown", function (e) {
    var typing = /^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || "") || (document.activeElement && document.activeElement.isContentEditable);
    if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "K")) { e.preventDefault(); if (pal && !pal.hidden) closePal(); else openPal(); return; }
    if (e.key === "/" && !typing && !e.ctrlKey && !e.metaKey) { e.preventDefault(); openPal(); return; }
    if (e.key === "Escape") { if (pal && !pal.hidden) closePal(); else if (np && !np.hidden) { needs(false); nb.focus(); } else if (document.body.classList.contains("side-open")) drawer(false); }
  });
})();
