<?php
//MC 2026-10-10 Admin > Fair Play: two accounts that keep sitting at the same table, never attack each other, share a
//   network or a browser, or one walking out of a match to sit with the other. Every finished live match is kept here for
//   30 days (the rooms themselves delete after 3 hours), and a match can be struck from the League in one click.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)
require_once dirname(__DIR__) . '/api/fairplay.php';
if (!defined('ROOMS')) define('ROOMS', DATA_DIR . '/rooms');

function fairplay_actions($do) {
    if ($do === 'fp-settings') {
        if (!is_dir(FP_DIR)) @mkdir(FP_DIR, 0755, true);
        with_lock(function () {
            $s = fp_settings(); $s['priv_league'] = !empty($_POST['priv_league']) ? 1 : 0;
            $s['r_left'] = !empty($_POST['r_left']) ? 1 : 0; $s['r_same'] = !empty($_POST['r_same']) ? 1 : 0;
            $s['r_pair'] = max(0, min(50, (int)($_POST['r_pair'] ?? 3))); $s['r_new'] = max(0, min(200, (int)($_POST['r_new'] ?? 10)));
            save(FP_DIR . '/settings.php', $s);
        });
        go('fairplay', 'Fair Play rules saved. They apply from the next match.');
    }
    if ($do === 'fp-strike') {
        $key = (string)($_POST['key'] ?? '');
        $msg = with_lock(fn() => fp_strike($key, me()['username']));
        $_SESSION['flash'] = $msg;
        header('Location: ./?tab=fairplay' . (isset($_POST['q']) && $_POST['q'] !== '' ? '&q=' . urlencode((string)$_POST['q']) : '') . (isset($_POST['pair']) && $_POST['pair'] !== '' ? '&pair=' . urlencode((string)$_POST['pair']) : '') . '#fp-m');
        exit;
    }
}

function fp_when($t) { return $t ? gmdate('M j, H:i', $t) . ' UTC' : ''; }

function page_fairplay() {
    $players = with_lock(fn() => load(PLAYERS));
    $recs = fp_load(30);
    $imp = fp_import_rooms($recs);
    if ($imp) $recs = fp_load(30);
    $struck = fp_struck();
    $set = fp_settings();
    $edit = can('players', 2);
    $nm = fn($pid) => (string)($players[$pid]['name'] ?? ($pid !== '' ? substr($pid, 0, 6) : ''));
    $plink = fn($pid) => '<a href="?tab=fairplay&amp;q=' . urlencode($pid) . '#fp-m"><b>' . h($nm($pid)) . '</b></a>';

    $multi = array_filter($recs, fn($r) => $r['hum'] >= 2);
    echo '<section class="fp-top"><div><p>Every finished live match with a real player is kept here for 30 days, with who sat where, the moves each player made themselves, who they attacked, and a scrambled code for their network and browser (no address is stored). ' .
        number_format(count($recs)) . ' matches kept, ' . number_format(count($multi)) . ' with two or more real players.' . ($imp ? ' Just saved ' . $imp . ' finished ' . ($imp === 1 ? 'room' : 'rooms') . ' that were still on the server.' : '') . '</p>' .
        '<p class="muted">None of this proves two accounts are one person. Two friends on the same Wi-Fi share a network; the same browser and network in many matches, no attacks on each other and one account that only ever plays the other is the pattern to act on.</p></div>';
    $R = fp_rules(); $dis = $edit ? '' : ' disabled';
    $chk = fn($n, $on) => '<input type="checkbox" name="' . $n . '" value="1"' . ($on ? ' checked' : '') . $dis . '>';
    echo '<form method="post" class="fp-set"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><b class="fp-set-h">Rules for League, Ranked and the +20 per rival</b>' .
        '<label class="fp-cb">' . $chk('r_left', $R['left']) . '<span>A rival who left doesn\'t count <small class="muted">the game had to play their seat, or they never made a move</small></span></label>' .
        '<label class="fp-cb">' . $chk('r_same', $R['same']) . '<span>A rival on the same network and browser doesn\'t count <small class="muted">the match still shows up here as a pair to look at</small></span></label>' .
        '<label><span>Against the same rival, only the first</span><input type="number" name="r_pair" min="0" max="50" value="' . $R['pair'] . '"' . $dis . ' class="fp-n"><span>League matches a day count</span> <small class="muted">0 turns this off</small></label>' .
        '<label><span>New accounts count as a rival after</span><input type="number" name="r_new" min="0" max="200" value="' . $R['new'] . '"' . $dis . ' class="fp-n"><span>games</span> <small class="muted">0 turns this off</small></label>' .
        '<label class="fp-cb">' . $chk('priv_league', !empty($set['priv_league'])) . '<span>Private invite rooms count for the League <small class="muted">off: only quick matches and tournaments earn League points</small></span></label>' .
        '<p class="muted">Matches that miss a rule still count for everything else (Koban, XP, missions, the all-time board), and the player is told why on the results screen. Tournaments are never affected.</p>' .
        ($edit ? '<button name="do" value="fp-settings">Save rules</button>' : '') . '</form></section>';

    // pairs
    $pairs = fp_pairs($recs, $players);
    $flag = array_filter($pairs, fn($p) => $p['score'] >= 2);
    //MC 2026-10-12 what the farming check flagged after live matches (fp_watch in api/fairplay.php), newest first
    $fl = array_reverse((array)(load(FP_FLAGS)['list'] ?? []));
    if ($fl) {
        echo '<h2 id="fp-flags">Flagged by the farming check <small>' . count($fl) . '</small></h2><p class="muted">After every live match, each winner is checked against each real rival: same network or device, a rival who barely moved, a new account that only plays this player, the same pair again and again, and look-alike names. 4 or more and the team gets an email. Nothing is changed in the game: strike the matches below, or ban the alt in Players.</p><div class="tw"><table class="fp-t"><thead><tr><th>When</th><th>Winner and rival</th><th>What the check saw</th><th></th></tr></thead><tbody>';
        foreach (array_slice($fl, 0, 15) as $f) echo '<tr><td class="nw">' . h(ago($f['t'])) . '</td><td><b>' . h($f['wn']) . '</b> vs ' . h($f['on']) . '<small>score ' . (int)$f['score'] . ', match ' . h($f['c']) . ($f['lg'] ? ', ' . number_format($f['lg']) . ' League points' : '') . '</small></td><td><ul class="fp-why">' . implode('', array_map(fn($x) => '<li>' . h($x) . '</li>', $f['why'])) . '</ul></td><td class="nw"><a class="btn ghost sm" href="?tab=fairplay&amp;q=' . h(rawurlencode($f['w'])) . '#fp-m">Their matches</a></td></tr>';
        echo '</tbody></table></div>';
    }
    echo '<h2>Pairs to look at <small>' . count($flag) . ' of ' . count($pairs) . ' pairs who shared a table</small></h2>';
    if (!$flag) echo '<p class="muted">Nothing stands out in the last 30 days.</p>';
    else {
        echo '<div class="tw"><table class="fp-t fp-cards"><thead><tr><th>Players</th><th>Together</th><th>Wins</th><th>Attacks on each other</th><th>League points from these</th><th>Why it stands out</th><th></th></tr></thead><tbody>';
        foreach (array_slice($flag, 0, 40, true) as $id => $p) {
            echo '<tr' . ($p['score'] >= 6 ? ' class="fp-hot"' : '') . '><td data-l="Players">' . $plink($p['a']) . '<br>' . $plink($p['b']) . '</td><td data-l="Together">' . $p['n'] . '<small>' . $p['priv'] . ' private</small></td><td data-l="Wins">' . $p['wa'] . '<br>' . $p['wb'] . '</td>' .
                '<td data-l="Attacks on each other">' . $p['ab'] . ' &rarr;<br>' . $p['ba'] . ' &larr;' . (!empty($p['imp']) ? '<small>some from the log only</small>' : '') . '</td><td data-l="League points">' . number_format($p['lga']) . '<br>' . number_format($p['lgb']) . '</td>' .
                '<td data-l="Why"><ul class="fp-why">' . implode('', array_map(fn($f) => '<li>' . h($f) . '</li>', $p['flags'])) . '</ul></td><td><a class="btnl" href="?tab=fairplay&amp;pair=' . urlencode($id) . '#fp-m">Matches</a></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    // walked out of one match while sitting in another
    $ov = fp_overlaps($recs);
    if ($ov) {
        echo '<h2>Left a match to play another <small>the game played their seat for them meanwhile</small></h2><div class="tw"><table class="fp-t"><tbody>';
        foreach (array_slice($ov, 0, 30) as $o) {
            $a = $recs[$o['left']]; $b = $recs[$o['in']];
            $with = array_values(array_filter(array_map(fn($s) => $s['h'] && $s['pid'] !== $o['pid'] ? $s['pid'] : null, $b['seats'])));
            echo '<tr><td>' . $plink($o['pid']) . '</td><td>Left ' . h($a['pub'] ? 'quick match' : 'private room') . ' <b>' . h($a['c']) . '</b> <small>' . h(fp_when($a['s'])) . '</small></td><td>Played ' . h($b['pub'] ? 'quick match' : 'private room') . ' <b>' . h($b['c']) . '</b>' . ($with ? ' with ' . implode(', ', array_map($plink, $with)) : '') . ' <small>' . h(fp_when($b['s'])) . '</small></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    // look someone up, or one pair's matches
    $q = trim((string)($_GET['q'] ?? '')); $pair = (string)($_GET['pair'] ?? '');
    echo '<h2 id="fp-m">Matches</h2><form method="get" class="bar"><input type="hidden" name="tab" value="fairplay"><input name="q" value="' . h($q) . '" placeholder="Player name or id" list="pnames" style="min-width:240px"><button>Show matches</button>' . ($q !== '' || $pair !== '' ? ' <a href="?tab=fairplay#fp-m">Show all</a>' : '') . '</form>';
    $pid = '';
    if ($q !== '') {
        if (isset($players[$q])) $pid = $q;
        else foreach ($players as $id => $p) if (strcasecmp($p['name'] ?? '', $q) === 0) { $pid = $id; break; }
        if ($pid === '') foreach ($players as $id => $p) if (stripos($p['name'] ?? '', $q) !== false) { $pid = $id; break; }
        if ($pid === '') echo '<p class="bad">No player called ' . h($q) . '.</p>';
    }
    $list = $recs; $title = 'The latest matches with two or more real players';
    if ($pair !== '' && isset($pairs[$pair])) { $list = array_intersect_key($recs, array_flip($pairs[$pair]['keys'])); $title = h($nm($pairs[$pair]['a'])) . ' and ' . h($nm($pairs[$pair]['b'])) . ' together'; }
    elseif ($pid !== '') {
        $list = array_filter($recs, fn($r) => in_array($pid, array_column($r['seats'], 'pid'), true));
        $p = $players[$pid] ?? [];
        $part = []; foreach ($pairs as $x) if ($x['a'] === $pid || $x['b'] === $pid) $part[$x['a'] === $pid ? $x['b'] : $x['a']] = $x['n'];
        arsort($part);
        $title = h($nm($pid));
        echo '<div class="fp-who"><b>' . h($nm($pid)) . '</b> <small>' . h(substr($pid, 0, 8)) . '</small> &middot; joined ' . h($p['since'] ?? 0 ? gmdate('M j, Y', $p['since']) : 'unknown') . ' &middot; ' . number_format($p['games'] ?? 0) . ' games, ' . number_format($p['pvp_g'] ?? 0) . ' live &middot; League this week ' . number_format(($p['lg']['wk'] ?? '') === week_key() ? $p['lg']['pts'] : 0) .
            ($part ? '<br>Shared a table with: ' . implode(', ', array_map(fn($o, $n) => $plink($o) . ' &times;' . $n, array_keys($part), $part)) : '') . '</div>';
    } else $list = $multi;
    echo '<p class="muted">' . $title . ' (' . count($list) . ').</p>';
    foreach (array_slice($list, 0, 60, true) as $key => $r) {
        // the same letter on two seats means the same network (or browser) in this match
        $nets = []; $devs = [];
        foreach ($r['seats'] as $s) { foreach ($s['net'] ?? [] as $n) $nets[$n] = $nets[$n] ?? chr(65 + count($nets)); foreach ($s['dev'] ?? [] as $d) $devs[$d] = $devs[$d] ?? (count($devs) + 1); }
        $st = $struck[$key] ?? null;
        $lg = array_sum(array_column($r['seats'], 'lg'));
        echo '<article class="fp-m' . ($st ? ' struck' : '') . '"><header><b>' . h($r['c']) . '</b><span class="pill">' . ($r['tny'] ? 'Tournament' : ($r['pub'] ? 'Quick match' : 'Private room')) . '</span><span class="muted">' . h(fp_when($r['s'])) . ' to ' . h(gmdate('H:i', $r['e'])) . '</span>' . ($r['imp'] ? '<span class="pill">Saved from the room file</span>' : '') .
            ($st ? '<span class="pill bad">Struck by ' . h($st['by']) . ', ' . h(ago($st['at'])) . '</span>' : ($edit && $lg > 0 ? '<form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="key" value="' . h($key) . '"><input type="hidden" name="q" value="' . h($q) . '"><input type="hidden" name="pair" value="' . h($pair) . '"><button name="do" value="fp-strike" class="danger sm" data-confirm="Take the ' . $lg . ' League points from this match back from everyone who got them?">Strike from the League</button></form>' : '')) . '</header>';
        echo '<div class="tw"><table class="fp-t fp-cards"><thead><tr><th>Seat</th><th>Result</th><th>Their own moves</th><th>Attacked</th><th>Network</th><th>Browser</th><th>League</th></tr></thead><tbody>';
        foreach ($r['seats'] as $i => $s) {
            $att = [];
            foreach ((array)$s['att'] as $t => $n) $att[] = h(preg_replace('/ \(bot\)$/', '', $r['seats'][(int)$t]['name'] ?? '?')) . ($n > 1 ? ' &times;' . $n : '');
            $who = $s['h'] ? $plink($s['pid']) . ($s['gone'] || $s['away'] ? ' <span class="pill warn">left, the game played for them</span>' : '') : h(preg_replace('/ \(bot\)$/', '', $s['name'])) . ' <small>bot</small>';
            echo '<tr' . ($s['h'] ? '' : ' class="fp-bot"') . '><td data-l="Seat">' . $who . '</td><td data-l="Result">' . h(ucfirst($s['res'])) . ' &middot; ' . $s['reg'] . ' Regions, ' . $s['hand'] . ' cards</td>' .
                '<td data-l="Own moves">' . ($s['h'] ? ($r['imp'] ? '<small>not recorded</small>' : $s['acts'] . ' turns, ' . $s['cards'] . ' cards') : '') . '</td><td data-l="Attacked">' . ($att ? implode(', ', $att) : '<small>nobody</small>') . '</td>' .
                '<td data-l="Network">' . implode(' ', array_map(fn($n) => '<span class="fp-k">' . $nets[$n] . '</span>', $s['net'] ?? [])) . '</td><td data-l="Browser">' . implode(' ', array_map(fn($d) => '<span class="fp-k">' . $devs[$d] . '</span>', $s['dev'] ?? [])) . '</td>' .
                '<td data-l="League">' . ($s['lg'] ? number_format($s['lg']) : '') . '</td></tr>';
        }
        echo '</tbody></table></div></article>';
    }
}
