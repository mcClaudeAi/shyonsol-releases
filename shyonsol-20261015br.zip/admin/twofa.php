<?php
// Two-step sign-in for the admin: a 6-digit code from an authenticator app (Google Authenticator, Authy,
// 1Password, Microsoft Authenticator...) on top of the password. Required for owners and anyone who can send
// prize payouts; anyone else can switch it on. Eight one-time recovery codes cover a lost phone.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)

function b32_encode($bin) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    foreach (str_split($bits, 5) as $chunk) $out .= $a[bindec(str_pad($chunk, 5, '0'))];
    return $out;
}
function b32_decode($s) {
    $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
    foreach (str_split(strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $s))) as $c) $bits .= str_pad(decbin(strpos($a, $c)), 5, '0', STR_PAD_LEFT);
    foreach (str_split($bits, 8) as $chunk) if (strlen($chunk) === 8) $out .= chr(bindec($chunk));
    return $out;
}
function totp_at($secret, $step) {
    $h = hash_hmac('sha1', pack('N*', 0) . pack('N*', $step), b32_decode($secret), true);
    $o = ord($h[19]) & 0xf;
    $n = ((ord($h[$o]) & 0x7f) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
    return str_pad((string)($n % 1000000), 6, '0', STR_PAD_LEFT);
}
// the step the code belongs to (one step either side for phone clocks that drift), or null
function totp_step($secret, $code, $last = 0) {
    $code = preg_replace('/\D/', '', (string)$code);
    if (strlen($code) !== 6) return null;
    $now = intdiv(time(), 30);
    for ($s = $now - 1; $s <= $now + 1; $s++) if ($s > $last && hash_equals(totp_at($secret, $s), $code)) return $s;   // a code works once
    return null;
}
function tfa_required($u) {
    if (!$u) return false;
    $p = user_perms($u);
    return ($u['role'] ?? '') === 'owner' || (int)($p['payouts'] ?? 0) >= 2;
}
function tfa_recovery_codes() {
    $out = [];
    for ($i = 0; $i < 8; $i++) $out[] = strtolower(substr(b32_encode(random_bytes(5)), 0, 4) . '-' . substr(b32_encode(random_bytes(5)), 0, 4));
    return $out;
}
// a 6-digit code or a recovery code for this admin. Updates the account (last step, used recovery code). Call inside with_lock.
function tfa_check(&$u, $code) {
    $code = trim((string)$code);
    if (empty($u['tfa'])) return false;
    $step = totp_step($u['tfa'], $code, (int)($u['tfa_last'] ?? 0));
    if ($step !== null) { $u['tfa_last'] = $step; return 'code'; }
    $rc = strtolower(preg_replace('/[^a-z0-9]/i', '', $code));
    foreach ($u['tfa_rc'] ?? [] as $i => $hash) if (strlen($rc) === 8 && password_verify($rc, $hash)) { unset($u['tfa_rc'][$i]); $u['tfa_rc'] = array_values($u['tfa_rc']); return 'recovery'; }
    return false;
}

// ---------- signing in: the second step ----------
function tfa_pending() { $p = $_SESSION['tfa'] ?? null; return $p && time() - $p['at'] < 300 ? $p : null; }
function tfa_login_step($code) {
    $p = tfa_pending();
    if (!$p) { unset($_SESSION['tfa']); return 'That took too long. Sign in again.'; }
    $res = with_lock(function () use ($p, $code) {
        $t = team(); $u = $t[$p['uid']] ?? null;
        if (!$u || empty($u['active'])) return ['err' => 'This admin account is switched off. Ask an owner.'];
        if (($u['locked'] ?? 0) > time()) return ['err' => 'Too many wrong codes. This account is locked for ' . ceil(($u['locked'] - time()) / 60) . ' more minutes.'];
        $kind = tfa_check($u, $code);
        if (!$kind) {
            $u['fails'] = (int)($u['fails'] ?? 0) + 1;
            if ($u['fails'] >= 5) { $u['locked'] = time() + 900; $u['fails'] = 0; }
            $t[$p['uid']] = $u; save(ADMINS, $t);
            return ['err' => 'That code isn\'t right. Use the newest code in your app.', 'fail' => $u['username']];
        }
        $u['fails'] = 0; $u['prev'] = $u['last'] ?? 0; $u['last'] = time();
        $t[$p['uid']] = $u; save(ADMINS, $t);
        return ['kind' => $kind, 'left' => count($u['tfa_rc'] ?? []), 'sv' => (int)$u['sv']];
    });
    if (!empty($res['err'])) { if (!empty($res['fail'])) audit_raw('login-failed', $res['fail'] . ' (code)'); return $res['err']; }
    unset($_SESSION['tfa']);
    login_ok_ip();
    session_regenerate_id(true); $_SESSION['ok'] = 1; $_SESSION['uid'] = $p['uid']; $_SESSION['sv'] = $res['sv']; $_SESSION['seen'] = time();
    $GLOBALS['ME'] = load_me(); audit('login', $res['kind'] === 'recovery' ? 'with a recovery code' : 'with a code');
    go('overview', $res['kind'] === 'recovery' ? 'Signed in with a recovery code. ' . $res['left'] . ' left. If your phone is gone, turn two-step sign-in off and on again in My account.' : '');
}
function page_tfa($err) {
    head_html('Admin sign in');
    echo '<form class="login" method="post"><span class="seal">管</span><h1>Two-step sign-in</h1><p class="muted">Enter the 6-digit code from your authenticator app.</p>' . ($err ? '<p class="err">' . h($err) . '</p>' : '') .
        '<label class="lf"><span>Code</span><input name="code" inputmode="numeric" autocomplete="one-time-code" autofocus required maxlength="12" placeholder="123 456"></label><button name="do" value="login-2fa">Sign in</button>' .
        '<p class="muted small">Lost your phone? Type one of your recovery codes instead. <button name="do" value="login-cancel" class="linkish" formnovalidate>Start over</button></p></form></body></html>';
}

// ---------- my account: switching it on and off ----------
function tfa_actions($do) {
    $me = me();
    if (!empty($me['key'])) go('account', 'The setup key has no account of its own.');
    if ($do === 'tfa-start') {
        $_SESSION['tfa_new'] = b32_encode(random_bytes(20));
        go('account', '');
    }
    if ($do === 'tfa-on') {
        $sec = $_SESSION['tfa_new'] ?? '';
        if ($sec === '') go('account', 'Start again: press Set up two-step sign-in.');
        if (totp_step($sec, (string)($_POST['code'] ?? '')) === null) go('account', 'That code isn\'t right. Check the time on your phone is set automatically, then try the newest code.');
        $codes = tfa_recovery_codes();
        with_lock(function () use ($me, $sec, $codes) {
            $t = team(); $u = $t[$me['id']];
            $u['tfa'] = $sec; $u['tfa_last'] = intdiv(time(), 30); $u['tfa_at'] = time();
            $u['tfa_rc'] = array_map(fn($c) => password_hash(str_replace('-', '', $c), PASSWORD_DEFAULT), $codes);
            $t[$me['id']] = $u; save(ADMINS, $t);
        });
        unset($_SESSION['tfa_new']);
        $_SESSION['tfa_codes'] = $codes;
        audit('tfa-on');
        go('account', 'Two-step sign-in is on. Save your recovery codes now: they are shown only once.');
    }
    if ($do === 'tfa-cancel') { unset($_SESSION['tfa_new']); go('account', ''); }
    if ($do === 'tfa-off') {
        $u0 = team()[$me['id']];
        if (tfa_required($u0)) go('account', 'Your role needs two-step sign-in, so it stays on. To move it to a new phone, use New recovery codes or ask another owner to reset it.');
        $ok = with_lock(function () use ($me) { $t = team(); $u = $t[$me['id']]; if (!tfa_check($u, (string)($_POST['code'] ?? ''))) return false; unset($u['tfa'], $u['tfa_rc'], $u['tfa_last']); $t[$me['id']] = $u; save(ADMINS, $t); return true; });
        if (!$ok) go('account', 'That code isn\'t right.');
        audit('tfa-off');
        go('account', 'Two-step sign-in is off.');
    }
    if ($do === 'tfa-codes') {
        $codes = tfa_recovery_codes();
        $ok = with_lock(function () use ($me, $codes) { $t = team(); $u = $t[$me['id']]; if (!tfa_check($u, (string)($_POST['code'] ?? ''))) return false; $u['tfa_rc'] = array_map(fn($c) => password_hash(str_replace('-', '', $c), PASSWORD_DEFAULT), $codes); $t[$me['id']] = $u; save(ADMINS, $t); return true; });
        if (!$ok) go('account', 'That code isn\'t right.');
        $_SESSION['tfa_codes'] = $codes;
        audit('tfa-codes');
        go('account', 'New recovery codes. The old ones no longer work.');
    }
}
function tfa_section($u) {
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    $req = tfa_required($u);
    $o = '<h2 id="tfa">Two-step sign-in</h2>';
    if (!empty($_SESSION['tfa_codes'])) {
        $codes = $_SESSION['tfa_codes']; unset($_SESSION['tfa_codes']);
        $o .= '<div class="reveal"><b>Your recovery codes</b><p class="muted">Each one signs you in once if your phone is lost. Shown only now: copy them into your password manager or print them.</p><div class="hashline"><code id="rc-codes" class="rc">' . h(implode("\n", $codes)) . '</code><button type="button" class="ghost" data-copy="rc-codes">Copy</button></div></div>';
    }
    if (!empty($u['tfa'])) {
        $left = count($u['tfa_rc'] ?? []);
        $o .= '<div class="tg-status on"><b>On since ' . h(gmdate('M j, Y', $u['tfa_at'] ?? time())) . '</b><span>Every sign-in asks for a code from your authenticator app. ' . $left . ' recovery ' . ($left === 1 ? 'code' : 'codes') . ' left.</span></div>';
        $o .= '<form method="post" class="bar">' . $csrf . '<input name="code" inputmode="numeric" autocomplete="one-time-code" placeholder="Code from your app" required style="width:190px"><button name="do" value="tfa-codes" class="ghost">New recovery codes</button>' . ($req ? '' : '<button name="do" value="tfa-off" class="ghost danger">Turn off</button>') . '</form>';
        return $o;
    }
    $sec = $_SESSION['tfa_new'] ?? '';
    if ($sec === '') {
        $o .= ($req ? '<div class="tg-status"><b>Your role needs two-step sign-in.</b><span>Owners and anyone who can send prize payouts protect their account with a code from an authenticator app. Set it up now to keep going: it takes a minute.</span></div>' : '<p class="muted">Protect your account with a 6-digit code from an authenticator app (Google Authenticator, Authy, 1Password, Microsoft Authenticator) on top of your password.</p>');
        $o .= '<form method="post">' . $csrf . '<button name="do" value="tfa-start">Set up two-step sign-in</button></form>';
        return $o;
    }
    $label = rawurlencode('Shy admin:' . $u['username']);
    $uri = 'otpauth://totp/' . $label . '?secret=' . $sec . '&issuer=' . rawurlencode('Shy admin') . '&digits=6&period=30';
    $o .= '<div class="tfa-setup"><div class="tfa-qr" id="tfa-qr" data-uri="' . h($uri) . '"></div><div><ol class="tg-steps"><li>Open your authenticator app and add an account by scanning this code.</li><li>Can\'t scan? Enter this key by hand: <code class="tfa-key">' . h(trim(chunk_split($sec, 4, ' '))) . '</code></li><li>Type the 6-digit code the app shows.</li></ol>' .
        '<form method="post" class="bar">' . $csrf . '<input name="code" inputmode="numeric" autocomplete="one-time-code" placeholder="123 456" required style="width:150px"><button name="do" value="tfa-on">Turn on</button><button name="do" value="tfa-cancel" class="ghost" formnovalidate>Cancel</button></form></div></div>';
    return $o;
}
