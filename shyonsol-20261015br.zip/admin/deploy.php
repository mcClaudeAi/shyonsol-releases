<?php
//MC 2026-10-13 Admin > Deploy an update: upload a release zip and the server does the whole swap itself. The old way was
//   six manual steps in the file manager (empty public_html, upload, unzip to temp, move, delete temp and zip, rebuild
//   cards) and emptying the folder threw away card-art, which is left out of the zip on purpose. Here the files are
//   unpacked in shy-data, copied over the live site, anything the new release no longer ships is removed, and card-art
//   and .well-known are never touched, so the rebuild step goes away. Owners only.
//MC 2026-10-14 the swap now lives in deploy_run() so two doors share it: the upload form here, and api/deploy-pull.php,
//   which downloads a release from links it is given and deploys it (the "safe to release" path). Every successful
//   deploy keeps its zip in shy-data/releases, so going back is one press on this page.
define('DEPLOY_TMP', DATA_DIR . '/deploy-tmp');
define('DEPLOY_KEEP_DIR', DATA_DIR . '/releases');

// keep these when removing files the new release no longer ships: card art lives outside the zip, .well-known holds the
// SSL checks, cgi-bin is the host's
const DEPLOY_KEEP = ['card-art/', '.well-known/', 'cgi-bin/'];

function deploy_root() { return dirname(__DIR__); }

//MC 2026-10-14 the key api/deploy-pull.php requires; its own secret, separate from the cron key, shown only to owners
function deploy_key() {
    $f = DATA_DIR . '/deploy-key.php';
    $d = load($f);
    if (empty($d['k'])) { $d['k'] = bin2hex(random_bytes(20)); save($f, $d); }
    return $d['k'];
}

function deploy_kept($rel) {
    foreach (DEPLOY_KEEP as $k) if (strpos($rel, $k) === 0) return true;
    return false;
}

// every file under $dir as paths relative to it
function deploy_walk($dir, $base = '') {
    $out = [];
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..') continue;
        $p = $dir . '/' . $f;
        if (is_link($p)) continue;   // a symlink is the host's business, not the release's
        if (is_dir($p)) $out = array_merge($out, deploy_walk($p, $base . $f . '/'));
        else $out[] = $base . $f;
    }
    return $out;
}

function deploy_rmdir($dir) {
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..') continue;
        $p = $dir . '/' . $f;
        is_dir($p) && !is_link($p) ? deploy_rmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

// the version a built page carries in its asset links, e.g. app.js?v=20261013f
function deploy_version($indexHtml) {
    return is_file($indexHtml) && preg_match('/\?v=(\d{8}[a-z]*)/', (string)file_get_contents($indexHtml), $m) ? $m[1] : '';
}

//MC 2026-10-14 a successful deploy keeps its zip, so any of the last few releases can be put back in one press
function deploy_keep_zip($zipPath, $ver) {
    if (!is_dir(DEPLOY_KEEP_DIR)) @mkdir(DEPLOY_KEEP_DIR, 0755, true);
    $name = 'site-' . ($ver !== '' ? $ver : gmdate('Ymd-His')) . '.zip';
    @copy($zipPath, DEPLOY_KEEP_DIR . '/' . $name);
    $all = glob(DEPLOY_KEEP_DIR . '/site-*.zip') ?: [];
    usort($all, fn($a, $b) => filemtime($b) <=> filemtime($a));
    foreach (array_slice($all, 3) as $f) @unlink($f);   // the three newest stay
    return $name;
}

function deploy_kept_zips() {
    $all = glob(DEPLOY_KEEP_DIR . '/site-*.zip') ?: [];
    usort($all, fn($a, $b) => filemtime($b) <=> filemtime($a));
    return $all;
}

//MC 2026-10-14 every deploy, from either door, lands here; the Deploy page shows the last few
function deploy_log($row) {
    $f = DATA_DIR . '/deploy-log.php';
    $d = load($f); $l = is_array($d['l'] ?? null) ? $d['l'] : [];
    array_unshift($l, $row + ['t' => time()]);
    save($f, ['l' => array_slice($l, 0, 20)]);
}

//MC 2026-10-14 the whole swap, callable from the upload form and from api/deploy-pull.php. Validates first and touches
//   nothing on a bad zip. Returns ['err' => why] or the counts. $keep=false skips keeping a copy (a rollback redeploys
//   a zip that is already kept).
function deploy_run($zipPath, $keep = true) {
    if (!class_exists('ZipArchive')) return ['err' => 'This server has no PHP zip support. Ask Hostinger to switch on the zip extension.'];
    @set_time_limit(300);
    $za = new ZipArchive();
    if ($za->open($zipPath) !== true) return ['err' => 'That file is not a readable zip.'];
    $names = [];
    for ($i = 0; $i < $za->numFiles; $i++) {
        $n = $za->getNameIndex($i);
        if (substr($n, -1) === '/') continue;   // folders
        // no path may leave the site folder
        if ($n === '' || $n[0] === '/' || strpos($n, '..') !== false || strpos($n, "\\") !== false || preg_match('/^[A-Za-z]:/', $n)) { $za->close(); return ['err' => 'The zip holds an unsafe path (' . $n . '), so nothing was touched.']; }
        $names[] = $n;
    }
    // it has to look like the site before anything is replaced
    foreach (['index.html', 'api/common.php', 'assets/app.js'] as $need) if (!in_array($need, $names, true)) { $za->close(); return ['err' => 'That zip does not look like a site release (' . $need . ' is missing), so nothing was touched.']; }

    $x = DEPLOY_TMP . '/x';
    deploy_rmdir($x);
    @mkdir($x, 0755, true);
    if (!$za->extractTo($x)) { $za->close(); return ['err' => 'The zip could not be unpacked.']; }
    $za->close();
    $ver = deploy_version($x . '/index.html');

    // copy everything into place first, so no moment has files missing, then take away what the release no longer ships
    $root = deploy_root();
    $new = 0; $upd = 0; $bad = [];
    foreach ($names as $rel) {
        $to = $root . '/' . $rel;
        $dir = dirname($to);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $had = is_file($to);
        //MC 2026-10-14 a plain copy fails on a target the web user can't write (a file left read-only, or written by a
        //   different process once): engine.php was stuck that way and a release's new engine.php never landed, so the
        //   old code kept running after a "successful" deploy. Now a failed copy makes the file writable and tries again,
        //   then as a last resort replaces it (remove, then copy fresh), which works whenever the folder itself is writable.
        if (!@copy($x . '/' . $rel, $to)) {
            @chmod($to, 0644);
            if (!@copy($x . '/' . $rel, $to)) {
                @unlink($to);
                if (!@copy($x . '/' . $rel, $to)) { $bad[] = $rel; continue; }
            }
        }
        $had ? $upd++ : $new++;
    }
    $have = array_flip($names);
    $gone = 0;
    foreach (deploy_walk($root) as $rel) {
        if (isset($have[$rel]) || deploy_kept($rel)) continue;
        if (@unlink($root . '/' . $rel)) $gone++;
    }
    // folders the removals emptied (deepest first so a nested empty chain goes too); rmdir only takes empty folders
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        if (!$f->isDir() || $f->isLink()) continue;
        $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($root) + 1)) . '/';
        if (!deploy_kept($rel)) @rmdir($f->getPathname());   // rmdir only takes empty folders
    }
    if ($keep) deploy_keep_zip($zipPath, $ver);
    deploy_rmdir($x);
    if (function_exists('opcache_reset')) @opcache_reset();   // or the host keeps serving the old PHP for a while
    if (function_exists('masks_heal')) @masks_heal();   //MC 2026-10-13 the update just put stock bot masks back; restore any custom ones
    return ['v' => $ver, 'new' => $new, 'updated' => $upd, 'removed' => $gone, 'failed' => count($bad), 'badlist' => array_slice($bad, 0, 3)];
}

function deploy_result_line($r) {
    return 'Deployed' . ($r['v'] !== '' ? ' version ' . $r['v'] : '') . ': ' . $r['updated'] . ' files updated, ' . $r['new'] . ' added, ' . $r['removed'] . ' removed. Card art was left in place, so there is nothing to rebuild.'
        . ($r['failed'] ? ' ' . $r['failed'] . ' files could not be written (' . implode(', ', $r['badlist']) . '): check folder permissions.' : '');
}

function deploy_actions($do) {
    if ($do === 'deploy-zip') {
        if (!is_owner()) go('deploy', 'Only an owner can deploy an update.');
        $up = $_FILES['zip'] ?? null;
        if (!$up || ($up['error'] ?? 1) !== UPLOAD_ERR_OK) {
            $e = (int)($up['error'] ?? 0);
            go('deploy', $e === UPLOAD_ERR_INI_SIZE || $e === UPLOAD_ERR_FORM_SIZE
                ? 'That zip is bigger than the server accepts (upload limit ' . ini_get('upload_max_filesize') . ', post limit ' . ini_get('post_max_size') . '). Raise the limits in hPanel under PHP configuration.'
                : 'Pick the release zip to upload.');
        }
        if (DEPLOY_TMP === '/deploy-tmp') go('deploy', 'The data folder could not be found, so nothing was touched.');
        deploy_rmdir(DEPLOY_TMP);
        if (!@mkdir(DEPLOY_TMP, 0755, true)) go('deploy', 'Could not make a working folder in shy-data.');
        $zipPath = DEPLOY_TMP . '/up.zip';
        if (!@move_uploaded_file($up['tmp_name'], $zipPath) && !@copy($up['tmp_name'], $zipPath)) { deploy_rmdir(DEPLOY_TMP); go('deploy', 'Could not store the upload.'); }
        $r = deploy_run($zipPath);
        deploy_rmdir(DEPLOY_TMP);
        if (isset($r['err'])) go('deploy', $r['err']);
        deploy_log(['how' => 'upload', 'who' => me()['username'] ?? '', 'v' => $r['v'], 'u' => $r['updated'], 'n' => $r['new'], 'r' => $r['removed']]);
        audit('deploy-done', ['v' => $r['v'], 'new' => $r['new'], 'updated' => $r['updated'], 'removed' => $r['removed']] + ($r['failed'] ? ['failed' => $r['failed']] : []));
        go('deploy', deploy_result_line($r));
    }
    //MC 2026-10-14 put a kept release back: redeploy one of the zips a past deploy saved
    if ($do === 'deploy-prev') {
        if (!is_owner()) go('deploy', 'Only an owner can deploy an update.');
        $name = basename((string)($_POST['zip'] ?? ''));
        $f = DEPLOY_KEEP_DIR . '/' . $name;
        if (!preg_match('/^site-[a-z0-9\-]+\.zip$/', $name) || !is_file($f)) go('deploy', 'That kept release is not here any more.');
        $r = deploy_run($f, false);
        if (isset($r['err'])) go('deploy', $r['err']);
        deploy_log(['how' => 'rollback', 'who' => me()['username'] ?? '', 'v' => $r['v'], 'u' => $r['updated'], 'n' => $r['new'], 'r' => $r['removed']]);
        audit('deploy-done', ['v' => $r['v'], 'rollback' => 1]);
        go('deploy', 'Put back: ' . deploy_result_line($r));
    }
}

function page_deploy() {
    if (!is_owner()) { echo '<p class="viewonly">Only an owner can deploy an update.</p>'; return; }
    $ver = deploy_version(deploy_root() . '/index.html');
    echo '<p class="muted">Upload a release zip and the server swaps the site itself: unpack in shy-data, copy every file into place, remove files the new release no longer ships, clear the PHP cache. <b>card-art</b> and <b>.well-known</b> are never touched, so there is no card rebuild afterwards. Player data lives in shy-data and is never part of a deploy.</p>';
    echo '<p>Running now: <b>' . ($ver !== '' ? 'version ' . h($ver) : 'unknown') . '</b></p>';
    echo '<form method="post" enctype="multipart/form-data" class="bar">'
        . '<input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="back" value="deploy">'
        . '<input type="file" name="zip" accept=".zip" required> '
        . '<button name="do" value="deploy-zip" class="danger" data-confirm="Replace the whole site with this zip?">Deploy</button></form>';
    echo '<p class="muted small">The server accepts uploads up to ' . h(ini_get('upload_max_filesize')) . ' (post limit ' . h(ini_get('post_max_size')) . ').</p>';

    //MC 2026-10-14 kept releases: every deploy saves its zip here, so going back is one press
    $kept = deploy_kept_zips();
    echo '<h3>Go back to an earlier release</h3>';
    if (!$kept) echo '<p class="muted">The next deploy saves its zip here, and from then on any of the last three releases can be put back in one press.</p>';
    else {
        echo '<div class="tw"><table><thead><tr><th>Release</th><th>Deployed</th><th>Size</th><th></th></tr></thead><tbody>';
        foreach ($kept as $f) {
            $n = basename($f);
            echo '<tr><td><b>' . h(preg_replace('/^site-|\.zip$/', '', $n)) . '</b></td><td class="nw">' . h(ago((int)filemtime($f))) . '</td><td class="nw">' . number_format(filesize($f) / 1048576, 1) . ' MB</td>'
                . '<td><form method="post"><input type="hidden" name="csrf" value="' . h(csrf()) . '"><input type="hidden" name="zip" value="' . h($n) . '"><button name="do" value="deploy-prev" class="ghost" data-confirm="Put the whole site back to this release?">Deploy this again</button></form></td></tr>';
        }
        echo '</tbody></table></div>';
    }

    //MC 2026-10-14 the pull door: hand api/deploy-pull.php download links and the zip\'s SHA-256 and the server fetches
    //   and deploys it itself. Made for releases prepared outside this machine, so "safe to release" is one call.
    $pk = deploy_key();
    $site = rtrim(TG_SITE, '/');
    echo '<h3>Pull deploys (deploy by link)</h3>';
    echo '<p class="muted">The site can also fetch a release itself: call <b>api/deploy-pull.php</b> with this key, one or more download links (u1, u2, &hellip;) and the zip\'s SHA-256 (sha). The parts are downloaded, joined, hash-checked and then deployed through the exact same checks as the upload above. A bad link or a wrong hash touches nothing. Keep the key private; anyone holding it can replace the site.</p>';
    echo '<div class="hashline"><code id="deploykey">' . h($pk) . '</code><button type="button" class="ghost" data-copy="deploykey">Copy</button></div>';
    echo '<p class="muted small">Example: <code>' . h($site) . '/api/deploy-pull.php?k=KEY&amp;u1=https://&hellip;/part1&amp;u2=https://&hellip;/part2&amp;sha=&lt;sha256&gt;</code></p>';

    $log = load(DATA_DIR . '/deploy-log.php')['l'] ?? [];
    if ($log) {
        echo '<h3>Recent deploys</h3><div class="tw"><table><thead><tr><th>When</th><th>How</th><th>Version</th><th>Files</th></tr></thead><tbody>';
        foreach (array_slice($log, 0, 8) as $r) echo '<tr><td class="nw">' . h(ago((int)$r['t'])) . '</td><td>' . h($r['how'] . ($r['who'] !== '' ? ' · ' . $r['who'] : '')) . '</td><td><b>' . h($r['v'] ?: '?') . '</b></td><td class="nw">' . (int)$r['u'] . ' updated · ' . (int)$r['n'] . ' added · ' . (int)$r['r'] . ' removed</td></tr>';
        echo '</tbody></table></div>';
    }
}
