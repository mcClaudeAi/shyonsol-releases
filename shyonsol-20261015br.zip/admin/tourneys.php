<?php
// Tournaments in the admin: schedule one (or a weekly series), watch the bracket, start early or call one off.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)

function tourney_actions($do) {
    if ($do === 'tourney-add') {
        $name = trim(preg_replace('/[^A-Za-z0-9 \-!\'&#.]/', '', (string)($_POST['name'] ?? '')));
        $start = strtotime((string)($_POST['start'] ?? '') . ' UTC');
        if ($name === '' || !$start) go('tourneys', 'Give the tournament a name and a start time.');
        if ($start < time() + 300) go('tourneys', 'Pick a start at least 5 minutes from now, so players can sign up and check in.');
        $prizes = array_map(fn($k) => max(0, min(100000, (int)($_POST['p' . $k] ?? 0))), [1, 2, 3, 4]);
        $gate = holder_key_new((string)($_POST['gate'] ?? ''));   //MC 2026-10-10 an old tier key (from a stale form) becomes its rank
        if (!isset(TOURNEY_GATES[$gate])) $gate = '';
        $partner = null;
        if ($gate === 'partner') {
            $pn = trim(mb_substr((string)($_POST['pt_name'] ?? ''), 0, 40)); $pm = trim((string)($_POST['pt_mint'] ?? ''));
            $pu = trim((string)($_POST['pt_url'] ?? '')); $pl = trim((string)($_POST['pt_logo'] ?? '')); $ps = strtoupper(trim(preg_replace('/[^A-Za-z0-9$]/', '', (string)($_POST['pt_sym'] ?? ''))));
            if ($pn === '' || !preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $pm)) go('tourneys', 'A joint event needs the partner\'s name and their token\'s mint address.');
            if ($pu !== '' && !preg_match('#^https://[^\s"<>]+$#', $pu)) go('tourneys', 'The partner\'s website should start with https://');
            if ($pl !== '' && !preg_match('#^https://[^\s"<>]+$#', $pl)) go('tourneys', 'The partner\'s logo should be an https:// image link.');
            $partner = ['name' => $pn, 'mint' => $pm, 'url' => $pu, 'logo' => $pl, 'sym' => $ps !== '' ? (strpos($ps, '$') === 0 ? $ps : '$' . $ps) : $pn, 'min' => max(0, (float)($_POST['pt_min'] ?? 0)), 'code' => tp_code()];
        }
        //MC 2026-10-13 paid events: the entry fee in $SHY and the pool share. A fee needs the shop open to sell tickets.
        $fee = max(0, round((float)($_POST['fee'] ?? 0), 2));
        if ($fee > 0 && !eco_settings()['shop_open']) go('tourneys', 'The shop is closed, so entry tickets can\'t be sold. Open the shop first, or make it free.');
        $t = tourney_new(['name' => mb_substr($name, 0, 48), 'start' => $start, 'max' => max(4, min(128, (int)($_POST['max'] ?? 64))), 'prizes' => $prizes,
            'note' => mb_substr(trim((string)($_POST['note'] ?? '')), 0, 200), 'repeat' => !empty($_POST['repeat']), 'by' => me()['username'], 'gate' => $gate, 'partner' => $partner,
            'fee' => $fee, 'pool_pct' => (int)($_POST['pool_pct'] ?? 60)]);
        tourney_lock(function () use ($t) { $db = tourney_db(); $db['list'][$t['id']] = $t; save(TOURNEY, $db); });
        if (!empty($_POST['announce'])) tg_post('tourney', '🏯 <b>' . tg_h($t['name']) . '</b>: ' . gmdate('l, M j', $t['start']) . ' at ' . gmdate('H:i', $t['start']) . " UTC.\nA knockout of live matches: the best real player at each table moves on, until the final table." .
            ($fee > 0 ? "\n💰 Entry: " . number_format($fee) . ' $SHY. ' . (int)$t['pool_pct'] . '% of every entry goes into the $SHY prize pool, and the fee is refunded if the event is called off.' : '') .
            (array_sum($prizes) ? ' Prizes: ' . implode(', ', array_filter(array_map(fn($k, $i) => $k ? '#' . ($i + 1) . ' ' . number_format($k) . ' Koban' : '', $prizes, array_keys($prizes)))) . '.' : '') . ($t['note'] !== '' ? ' ' . tg_h($t['note']) : '') . ($gate === 'partner' ? "\n🤝 A joint event with " . tg_h($partner['name']) . ': open to $SHY holders and ' . tg_h($partner['sym']) . ' holders.' : ($gate !== '' ? "\n💎 " . tg_h(TOURNEY_GATES[$gate]) . '.' : '')) . "\n" . tg_link('/play#tourney', 'Sign up'), 'tnew:' . $t['id']);
        go('tourneys', 'Scheduled ' . $t['name'] . '. Players can sign up on the Play page now.');
    }
    $id = (string)($_POST['id'] ?? '');
    if ($do === 'tourney-start') {
        $msg = tourney_lock(function () use ($id) {
            $db = tourney_db(); $t = $db['list'][$id] ?? null;
            if (!$t || $t['status'] !== 'signup') return 'Only a tournament that hasn\'t started can be started.';
            // everyone signed up counts as checked in when it's started by hand
            foreach ($t['players'] as &$p) if (empty($p['in'])) $p['in'] = time();
            unset($p);
            $t['start'] = time();
            tourney_start($t);
            $db['list'][$id] = $t; save(TOURNEY, $db);
            return $t['status'] === 'running' ? 'Started. Round 1 tables are open.' : 'Not started: ' . $t['why'];
        });
        go('tourneys', $msg);
    }
    if ($do === 'tourney-cancel') {
        $paidOff = tourney_lock(function () use ($id) {
            $db = tourney_db(); $t = &$db['list'][$id];
            if (!$t || !in_array($t['status'], ['signup', 'running'], true)) return false;
            $t['status'] = 'cancelled'; $t['ended'] = time(); $t['why'] = 'Called off by the team.'; $t['repeat'] = false;
            $tt = $t; unset($t); save(TOURNEY, $db);
            //MC 2026-10-13 a paid event called off refunds every entry: the list lands in Rewards for the payout button
            tourney_refunds($tt);
            if (!empty($tt['fee'])) tg_post('tourney', '🏯 <b>' . tg_h($tt['name']) . '</b> is off. Every entry fee is refunded in $SHY to the wallet that paid.', 'tcancel:' . $id);
            return !empty($tt['fee']);
        });
        go('tourneys', $paidOff ? 'Called off. The entry refunds are on the Rewards tab: Pay everything owed sends them.' : 'Called off. No prizes were paid.');
    }
    if ($do === 'tourney-del') {
        tourney_lock(function () use ($id) { $db = tourney_db(); if (isset($db['list'][$id]) && $db['list'][$id]['status'] !== 'running') { unset($db['list'][$id]); save(TOURNEY, $db); } });
        go('tourneys', 'Removed.');
    }
}

function page_tourneys() {
    tourney_tick(true);
    //MC 2026-10-09 joint events made before partner groups existed get their group code here
    tourney_lock(function () { $db = tourney_db(); $ch = false; foreach ($db['list'] as &$t) if (($t['gate'] ?? '') === 'partner' && empty($t['partner']['code'])) { $t['partner']['code'] = tp_code(); $ch = true; } unset($t); if ($ch) save(TOURNEY, $db); });
    $db = tourney_db(); $edit = can('tourney', 2); $bot = (string)(tg_cfg()['bot'] ?? '');
    $csrf = '<input type="hidden" name="csrf" value="' . h(csrf()) . '">';
    $list = $db['list']; uasort($list, fn($a, $b) => $b['start'] <=> $a['start']);
    $ST = ['signup' => ['warn', 'Sign-ups open'], 'running' => ['on', 'Running'], 'done' => ['on', 'Finished'], 'cancelled' => ['off', 'Called off']];
    echo '<p class="muted">A tournament is a knockout of live matches. Players sign up on the Play page and check in during the last 30 minutes. At the start they\'re seated at tables of up to 4, with bots in empty seats. The best real player at each table moves on until 4 or fewer are left for the final table, which decides 1st to 4th. Koban prizes land the moment it ends, and the winner gets the Cup Champion title.</p>';
    if ($edit) {
        $next = strtotime('next saturday 20:00 UTC');
        echo '<details class="addbox"' . (!$list ? ' open' : '') . '><summary class="btnish primary">Schedule a tournament</summary><form method="post" class="tform">' . $csrf .
            '<div class="grid3"><label>Name<input name="name" value="Weekly Shilluminati Cup" maxlength="48" required></label><label>Starts (UTC)<input name="start" type="datetime-local" value="' . gmdate('Y-m-d\TH:i', $next) . '" required></label><label>Most players<input name="max" type="number" min="4" max="128" value="64"></label></div>' .
            '<div class="grid4"><label>1st place (Koban)<input name="p1" type="number" min="0" value="2000"></label><label>2nd<input name="p2" type="number" min="0" value="1000"></label><label>3rd<input name="p3" type="number" min="0" value="500"></label><label>4th<input name="p4" type="number" min="0" value="250"></label></div>' .
            '<div class="grid2"><label>Entry fee ($SHY, 0 = free)<input name="fee" type="number" step="any" min="0" value="0"></label><label>Prize pool share (% of entries)<input name="pool_pct" type="number" min="0" max="100" value="60"></label></div>' .
            '<p class="muted small">A paid event sells its entry through the shop checkout, in $SHY only, and seats ticket holders only. The usual burn share of every $SHY payment burns in the buyer\'s own transaction; the pool share of collected fees pays 1st to 4th (50 / 25 / 15 / 10) from the Rewards tab, and the rest stays in the marketing wallet. If the event is called off, every entry is refunded in full from the Rewards tab.</p>' .
            '<label>Extra prize note <small class="muted">(optional, shown to players, for example a $SHY prize you send by hand)</small><input name="note" maxlength="200" placeholder="The winner also gets $25 in $SHY."></label>' .
            '<div class="grid2"><label>Who can sign up<select name="gate" data-gate>' . implode('', array_map(fn($k, $v) => '<option value="' . h($k) . '">' . h($k === 'partner' ? 'Joint event: $SHY holders and a partner community' : $v) . '</option>', array_keys(TOURNEY_GATES), TOURNEY_GATES)) . '</select><small class="muted">Holder events check the wallet a player connected on their profile.</small></label></div>' .
            '<fieldset class="pt-box" data-pt hidden><legend>Partner community</legend><div class="grid3"><label>Name<input name="pt_name" maxlength="40" placeholder="Bonk"></label><label>Token ticker<input name="pt_sym" maxlength="12" placeholder="$BONK"></label><label>Hold at least<input name="pt_min" type="number" step="any" min="0" value="0"></label></div>' .
            '<label>Token mint address<input name="pt_mint" placeholder="DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" spellcheck="false"></label><div class="grid2"><label>Website<input name="pt_url" placeholder="https://"></label><label>Logo image link<input name="pt_logo" placeholder="https://…png"></label></div>' .
            '<p class="muted small">The partner\'s holders sign up with the wallet they connect on their profile. Their logo and name show on the tournament card, and $SHY holders can always join too.</p></fieldset>' .
            '<label class="chk"><input type="checkbox" name="repeat" value="1" checked> Repeat every week at the same time</label>' .
            '<label class="chk"><input type="checkbox" name="announce" value="1" checked> Announce it in the Telegram chat</label>' .
            '<div class="bar"><button name="do" value="tourney-add">Schedule</button></div></form></details>';
    }
    if (!$list) { echo '<p class="muted">Nothing scheduled yet.</p>'; return; }
    foreach ($list as $id => $t) {
        $st = $ST[$t['status']] ?? ['', $t['status']];
        $in = count(array_filter($t['players'], fn($p) => !empty($p['in'])));
        echo '<section class="tcard"><div class="tc-head"><div><h2>' . h($t['name']) . ' <span class="pill ' . $st[0] . '">' . h($st[1]) . '</span>' . (!empty($t['repeat']) ? ' <span class="pill">Weekly</span>' : '') . (!empty($t['gate']) ? ' <span class="pill warn">' . h(($t['gate'] === 'partner' ? 'Joint with ' . ($t['partner']['name'] ?? '') : TOURNEY_GATES[tourney_gate($t)] ?? '')) . '</span>' : '') . '</h2>' .   //MC 2026-10-10 old tier gates show as their rank
            '<p class="muted small">' . h(gmdate('D, M j, H:i', $t['start'])) . ' UTC &middot; ' . count($t['players']) . ' signed up, ' . $in . ' checked in &middot; prizes ' . h(implode(' / ', array_map('number_format', $t['prizes']))) . ' Koban' .
            (!empty($t['fee']) ? ' &middot; entry ' . number_format($t['fee']) . ' $SHY, ' . ($pl = tourney_pool($t))['n'] . ' paid, pool ' . number_format($pl['shy']) . ' $SHY (' . (int)$t['pool_pct'] . '%)' : '') .   //MC 2026-10-13 paid events
            ($t['note'] !== '' ? ' &middot; ' . h($t['note']) : '') . (!empty($t['why']) ? ' &middot; ' . h($t['why']) : '') . '</p></div>';
        if ($edit) {
            echo '<div class="bar">';
            if ($t['status'] === 'signup') echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-start" class="ghost" data-confirm="Start ' . h($t['name']) . ' now? Everyone signed up plays, checked in or not.">Start now</button></form>';
            if (in_array($t['status'], ['signup', 'running'], true)) echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-cancel" class="ghost danger" data-confirm="Call off ' . h($t['name']) . '? Nobody gets prizes.">Call off</button></form>';
            elseif ($t['status'] !== 'running') echo '<form method="post">' . $csrf . '<input type="hidden" name="id" value="' . h($id) . '"><button name="do" value="tourney-del" class="ghost" data-confirm="Delete this tournament from the list?">Remove</button></form>';
            echo '</div>';
        }
        echo '</div>';
        //MC 2026-10-09 the partner's Telegram group: linked, or the two steps their admin needs
        if (($t['gate'] ?? '') === 'partner' && in_array($t['status'], ['signup', 'running'], true)) {
            $pc = (string)($t['partner']['code'] ?? '');
            echo !empty($t['partner']['chat'])
                ? '<p class="small"><i class="ok">Partner group linked:</i> ' . h($t['partner']['chat_title'] ?? 'their group') . '. It gets the reminders, the start and the winners by itself.</p>'
                : '<p class="small"><b>Partner group:</b> not linked yet. Send their admin this: <i>Add ' . ($bot !== '' ? '@' . h($bot) : 'our bot') . ' to your Telegram group, then type</i> <code style="user-select:all">/partner ' . h($pc) . '</code> <i>in the group.</i> The announcement goes out there straight away.</p>';
        }
        //MC 2026-10-13 a paid event's $SHY list (pool prizes, or refunds when called off): who, how much, sent or not
        if (!empty($t['fee']) && in_array($t['status'], ['done', 'cancelled'], true)) {
            $tx = load(REWARDS)['tourneys'][$t['id']] ?? null;
            if ($tx) {
                $open = count(array_filter($tx['list'], fn($w) => empty($w['sig']) && empty($w['skip'])));
                echo '<p class="small"><b>' . h($tx['label']) . ':</b> ' . implode(' &middot; ', array_map(fn($w) => h($w['name']) . ' ' . number_format($w['shy']) . ' $SHY' . (!empty($w['sig']) ? ' <i class="ok">paid</i>' : ''), $tx['list'])) .
                    ($open ? ' &middot; <a href="?tab=rewards">Pay everything owed on Rewards sends ' . ($open === count($tx['list']) ? 'them' : 'the rest') . '</a>' : ' &middot; <i class="ok">All sent</i>') . '</p>';
            } elseif ($t['status'] === 'cancelled') echo '<p class="small muted">No entries were sold, so there is nothing to refund.</p>';
        }
        if ($t['status'] === 'done' && $t['places']) {
            echo '<ol class="tc-places">';
            foreach (array_slice($t['places'], 0, 4) as $i => $pid) echo '<li><b>' . h($t['players'][$pid]['name'] ?? '?') . '</b>' . (!empty($t['prizes'][$i]) ? '<small>' . number_format($t['prizes'][$i]) . ' Koban</small>' : '') . '</li>';
            echo '</ol>';
        }
        if ($t['rounds']) {
            echo '<div class="tc-rounds">';
            foreach ($t['rounds'] as $ri => $tables) {
                echo '<div class="tc-round"><b>' . (count($tables) === 1 && $ri > 0 ? 'Final table' : 'Round ' . ($ri + 1)) . '</b>';
                foreach ($tables as $tb) {
                    echo '<div class="tc-table' . ($tb['done'] ? ' done' : '') . '"><small>' . h($tb['code']) . ($tb['done'] ? '' : ' &middot; playing') . '</small>';
                    foreach ($tb['seats'] as $pid) echo '<span' . ($tb['win'] === $pid ? ' class="win"' : '') . '>' . h($t['players'][$pid]['name'] ?? '?') . '</span>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
        } elseif ($t['players'] && $t['status'] === 'signup') {
            echo '<p class="small">' . implode(', ', array_map(fn($p) => h($p['name']) . (!empty($p['in']) ? ' &#10003;' : ''), $t['players'])) . '</p>';
        }
        echo '</section>';
    }
}
