//MC 2026-10-12 Admin > Players > Holdings. Draws the $SHY and Koban board from window.HX (built in admin/index.php):
//   the Army Rank ladder (tap a rank to filter), search by name, id or wallet, sort by $SHY, Koban or Shadows, and a CSV of
//   whatever is filtered. Only 60 rows are drawn at a time so the page stays quick with thousands of players.
//   Row: [pid, name, shy, usd, koban, tier, shadows, wallet, checked, last seen]
(function () {
  "use strict";
  var D = window.HX, list = document.getElementById("hx-list");
  if (!D || !list) return;
  var rows = D.rows, q = "", sortBy = 2, only = "", tier = "", lim = 60;
  var NAMES = {}; D.ladder.forEach(function (t) { NAMES[t[0]] = t[1]; });
  var maxShy = 1, maxKob = 1;
  rows.forEach(function (r) { maxShy = Math.max(maxShy, r[2]); maxKob = Math.max(maxKob, r[4]); });
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function compact(n) { return n >= 1e9 ? (n / 1e9).toFixed(2) + "B" : n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "K" : fmt(n); }
  function ago(t) { if (!t) return "never"; var s = D.now - t; return s < 5400 ? Math.max(1, Math.round(s / 60)) + " min ago" : s < 129600 ? Math.round(s / 3600) + " h ago" : Math.round(s / 86400) + " days ago"; }
  // bars on a log scale: one whale would otherwise flatten every other bar to nothing
  function pct(v, m) { return v > 0 ? Math.max(3, Math.log10(v + 1) / Math.log10(m + 1) * 100) : 0; }

  // ---------- the Army Rank ladder ----------
  var lad = document.getElementById("hx-lad");
  var tot = D.ladder.reduce(function (a, t) { return a + t[2]; }, 0);
  lad.innerHTML = '<div class="hx-strip">' + D.ladder.map(function (t, i) {
    return t[2] ? '<i class="t' + i + '" style="flex:' + t[2] + '" title="' + esc(t[1]) + ': ' + t[2] + '"></i>' : "";
  }).join("") + (tot ? "" : '<i class="none" style="flex:1"></i>') + '</div><div class="hx-chips">' + D.ladder.map(function (t, i) {
    return '<button type="button" class="hx-chip" data-t="' + t[0] + '"' + (t[2] ? "" : " disabled") + '><i class="t' + i + '"></i><span>' + esc(t[1]) + '<small>' + (t[0] === "shadow" ? "holds a Shadow" : fmt(t[3]) + "+ $SHY") + '</small></span><b>' + fmt(t[2]) + '</b></button>';
  }).join("") + '</div>';
  lad.addEventListener("click", function (e) {
    var b = e.target.closest(".hx-chip"); if (!b) return;
    tier = tier === b.dataset.t ? "" : b.dataset.t;
    lad.querySelectorAll(".hx-chip").forEach(function (c) { c.classList.toggle("on", c.dataset.t === tier); });
    lim = 60; draw();
  });

  function seg(id, key, fn) {
    var el = document.getElementById(id);
    el.addEventListener("click", function (e) {
      var b = e.target.closest("button"); if (!b) return;
      el.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
      fn(b.dataset[key]); lim = 60; draw();
    });
  }
  seg("hx-sort", "s", function (v) { sortBy = +v; });
  seg("hx-only", "o", function (v) { only = v; });
  var qi = document.getElementById("hx-q"), qt;
  qi.addEventListener("input", function () { clearTimeout(qt); qt = setTimeout(function () { q = qi.value.trim().toLowerCase(); lim = 60; draw(); }, 120); });
  document.getElementById("hx-more").addEventListener("click", function () { lim += 120; draw(); });

  function filtered() {
    var out = rows.filter(function (r) {
      if (only === "shy" && r[2] <= 0) return false;
      if (only === "kob" && r[4] <= 0) return false;
      if (tier && r[5] !== tier) return false;
      if (q && (r[1].toLowerCase().indexOf(q) < 0 && r[0].indexOf(q) < 0 && r[7].toLowerCase().indexOf(q) < 0)) return false;
      return true;
    });
    out.sort(function (a, b) { return (b[sortBy] - a[sortBy]) || (b[2] - a[2]) || (b[4] - a[4]); });
    return out;
  }
  // a rank number keeps its place in the full order, so #3 stays #3 while you search
  var rankOf = {};
  function ranks() { rankOf = {}; rows.slice().sort(function (a, b) { return (b[sortBy] - a[sortBy]) || (b[2] - a[2]) || (b[4] - a[4]); }).forEach(function (r, i) { rankOf[r[0]] = i + 1; }); }

  function row(r) {
    var n = rankOf[r[0]], name = r[1] || "(no games yet)", tn = r[5] ? NAMES[r[5]] : "";
    var ti = r[5] ? D.ladder.findIndex(function (t) { return t[0] === r[5]; }) : -1;
    var prof = r[1] ? '<a href="/p/' + encodeURIComponent(r[1].replace(/ /g, "_")) + '" target="_blank" rel="noopener">' + esc(name) + "</a>" : '<span class="muted">' + esc(name) + "</span>";
    return '<div class="hx-row' + (n <= 3 && !q && !tier && !only ? " top top" + n : "") + '" role="listitem">' +
      '<span class="hx-n">' + n + '</span>' +
      '<span class="hx-who"><span class="hx-av' + (ti >= 0 ? " t" + ti : "") + '">' + esc((r[1] || "?").charAt(0).toUpperCase()) + '</span><span class="hx-nm">' + prof +
        '<small>' + (tn ? '<em class="hx-tier t' + ti + '">' + esc(tn) + '</em>' : "") + '<code>' + esc(r[0]) + '</code></small></span></span>' +
      '<span class="hx-v hx-shy"><b title="' + fmt(r[2]) + ' $SHY">' + (r[2] ? compact(r[2]) : "0") + '</b><small>' + (r[3] ? "$" + fmt(r[3]) : r[7] ? "no $SHY" : "no wallet") + '</small><i style="width:' + pct(r[2], maxShy).toFixed(1) + '%"></i></span>' +
      '<span class="hx-v hx-kob"><b title="' + fmt(r[4]) + ' Koban">' + fmt(r[4]) + '</b><small>Koban</small><i style="width:' + pct(r[4], maxKob).toFixed(1) + '%"></i></span>' +
      '<span class="hx-sh' + (r[6] ? "" : " muted") + '"><b>' + r[6] + "</b> Shadow" + (r[6] === 1 ? "" : "s") + '</span>' +
      '<span class="hx-w">' + (r[7] ? '<a href="https://solscan.io/account/' + esc(r[7]) + '" target="_blank" rel="noopener">' + esc(r[7].slice(0, 4) + "..." + r[7].slice(-4)) + "</a><small>checked " + ago(r[8]) + "</small>" : '<span class="muted">No wallet</span><small>seen ' + ago(r[9]) + "</small>") + '</span>' +
      "</div>";
  }
  var last = [];
  function draw() {
    ranks(); last = filtered();
    var shy = 0, kob = 0; last.forEach(function (r) { shy += r[2]; kob += r[4]; });
    document.getElementById("hx-count").innerHTML = "<b>" + fmt(last.length) + "</b> " + (last.length === 1 ? "player" : "players") + " &middot; " + fmt(shy) + " $SHY &middot; " + fmt(kob) + " Koban";
    list.innerHTML = '<div class="hx-row hx-head" aria-hidden="true"><span>#</span><span>Player</span><span>$SHY</span><span>Koban</span><span>Shadows</span><span>Wallet</span></div>' +
      (last.length ? last.slice(0, lim).map(row).join("") : '<p class="hx-none">No players match.</p>');
    document.getElementById("hx-more").hidden = last.length <= lim;
  }
  document.getElementById("hx-csv").addEventListener("click", function () {
    var lines = [["rank", "player", "player_id", "shy", "shy_usd", "army_rank", "koban", "shadows", "wallet"].join(",")];
    last.forEach(function (r) { lines.push([rankOf[r[0]], '"' + r[1].replace(/"/g, '""') + '"', r[0], r[2], r[3], r[5] ? NAMES[r[5]] : "", r[4], r[6], r[7]].join(",")); });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([lines.join("\n")], { type: "text/csv" }));
    a.download = "holdings-" + new Date().toISOString().slice(0, 10) + ".csv";
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  });
  draw();
})();
