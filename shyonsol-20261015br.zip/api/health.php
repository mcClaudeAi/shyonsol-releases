<?php
//MC 2026-10-11 The health check, for the team or a monitoring service. Same secret as api/cron.php:
//   https://shyonsol.io/api/health.php?k=YOUR_CRON_KEY
// Answers JSON: level (ok, warn or bad), each check in plain words, and the raw numbers (data file sizes, last cron run,
// site lock wait over the last hour, last Telegram and email errors, backup age, disk use, rooms and shares, PHP).
// The answer is 200 for ok and warn and 503 for bad, so an uptime monitor can alert on it without reading the JSON.
// Without the right key it answers 403 and does nothing else. It changes nothing on the site.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/opslib.php';

$k = (string)($_GET['k'] ?? '');
$want = cron_key();
if ($want === '' || !hash_equals($want, $k)) { http_response_code(403); echo '{"ok":false}'; exit; }
$h = health_get(0);
$checks = [];
foreach ($h['checks'] as $id => [$label, $lvl, $text]) $checks[$id] = ['label' => $label, 'level' => $lvl, 'text' => $text];
out(['ok' => true, 'level' => $h['level'], 'at' => gmdate('c', $h['t']), 'summary' => health_line($h)[1], 'checks' => $checks, 'data' => $h['data']], $h['level'] === 'bad' ? 503 : 200);
