<?php
// Telegram and the game profile.
// POST {a: status|code|prefs|unlink, pid, key}  manage the link from the website profile
// POST {a: webapp, initData, pid, key}           the game opened inside Telegram (Mini App): sign in as the linked profile,
//                                                or link this device's profile to the Telegram account the first time
// POST {a: handoff, pid, key}                    from inside Telegram: a one-time code that opens this same profile in a wallet app
// POST {a: claim, code, pid, key}                the wallet app's browser redeems that code and signs in as the Telegram profile
// POST {a: relink, code, pid, key}               the wallet already had its own profile: Telegram follows it there
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 6000) fail('too large');
$b = json_decode($raw, true) ?: [];
$a = (string)($b['a'] ?? '');
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
$ok = with_lock(function () { $l = load(LIMITS); $ok = rate_ok($l, 'tglink:' . client_ip(), 60, 600); save(LIMITS, $l); return $ok; });
if (!$ok) fail('Slow down a little and try again.', 429);
$c = tg_cfg();

function link_view($pid, $c) {
    $t = tg_user_of($pid);
    return ['ok' => true, 'bot' => $c['bot'] ?? '', 'ready' => $c['token'] !== '' && !empty($c['bot']), 'app' => !empty($c['app']),
        'linked' => (bool)$t, 'user' => $t ? ['un' => $t['un'], 'fn' => $t['fn']] : null, 'dm' => $t ? !empty($t['dm']) : false,
        'notes' => tg_notes($t), 'labels' => TG_NOTES];
}

if ($a === 'webapp') {
    $w = tg_webapp_user((string)($b['initData'] ?? ''), $c['token']);
    if (!$w) fail('Telegram sign-in could not be checked. Close the game and open it again from Telegram.', 403);
    $tgid = (string)$w['user']['id'];
    $res = with_lock(function () use ($tgid, $w, $pid, $kh, $b) {
        $linked = tg_pid_of($tgid);
        if ($linked && $linked !== $pid) {
            // this Telegram account already plays as another profile: sign this device in as that profile
            $newKey = bin2hex(random_bytes(16));
            key_add($linked, hash('sha256', $newKey));
            tg_link_set($tgid, $linked, $w['user'], !empty($b['dm']) ? true : null);
            $p = load(PLAYERS)[$linked] ?? [];
            return ['switch' => $linked, 'key' => $newKey, 'name' => $p['name'] ?? ''];
        }
        if (!$linked) {
            // first time: this device's profile becomes the Telegram account's profile
            if (!key_ok($pid, $kh)) return ['err' => 'not your profile'];
            key_add($pid, $kh);
        }
        tg_link_set($tgid, $pid, $w['user'], !empty($b['dm']) ? true : null);
        return ['name' => load(PLAYERS)[$pid]['name'] ?? ''];
    });
    if (isset($res['err'])) fail($res['err'], 403);
    $cfg = tg_cfg();
    $invite = !empty($cfg['bot']) && !empty($cfg['app']) ? 'https://t.me/' . $cfg['bot'] . '/' . $cfg['app'] . '?startapp=room_' : '';
    out(['ok' => true, 'start' => $w['start'], 'invite' => $invite, 'tg' => ['fn' => $w['user']['first_name'] ?? '', 'un' => $w['user']['username'] ?? '']] + $res);
}

// Telegram's own browser has no wallet, so a holder finishes in Phantom or Solflare. The code carries the profile across.
if ($a === 'claim') {
    $code = strtoupper((string)($b['code'] ?? ''));
    if (!preg_match('/^[A-Z0-9]{10}$/', $code)) fail('That link is not valid. Start again from Telegram.');
    $res = with_lock(function () use ($code) {
        $l = tgl(); $h = $l['h'][$code] ?? null;
        if (!$h || $h['exp'] < time() || !empty($h['used'])) return null;
        $l['h'][$code]['used'] = time(); save(TGLINKS, $l);
        $newKey = bin2hex(random_bytes(16));
        key_add($h['pid'], hash('sha256', $newKey));
        return ['pid' => $h['pid'], 'key' => $newKey, 'name' => load(PLAYERS)[$h['pid']]['name'] ?? ''];
    });
    if (!$res) fail('That link has expired. Go back to Telegram and tap Connect again.', 410);
    out(['ok' => true] + $res);
}

$res = with_lock(function () use ($pid, $kh) { return key_ok($pid, $kh); });
if (!$res) fail('not your profile', 403);

if ($a === 'status') out(link_view($pid, $c));
if ($a === 'code') {
    if ($c['token'] === '' || empty($c['bot'])) fail('Telegram linking isn\'t switched on yet.', 503);
    $code = with_lock(fn() => tg_link_code($pid));
    out(['ok' => true, 'url' => 'https://t.me/' . $c['bot'] . '?start=link_' . $code, 'bot' => $c['bot']]);
}
if ($a === 'prefs') {
    $n = is_array($b['notes'] ?? null) ? $b['notes'] : [];
    $done = with_lock(function () use ($pid, $n) {
        $l = tgl(); $t = $l['p'][$pid] ?? null;
        if ($t === null) return false;
        $cur = tg_notes($l['u'][$t]);
        foreach (TG_NOTES as $k => $_) if (isset($n[$k])) $cur[$k] = (bool)$n[$k];
        $l['u'][$t]['n'] = $cur; $l['u'][$t]['nset'] = true;
        save(TGLINKS, $l); return true;
    });
    if (!$done) fail('Link Telegram first.');
    out(link_view($pid, $c));
}
if ($a === 'handoff') {
    $code = with_lock(function () use ($pid) {
        $l = tgl(); $now = time();
        $l['h'] = array_filter($l['h'], fn($h) => $h['exp'] > $now && $h['pid'] !== $pid);
        $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $code = '';
        for ($i = 0; $i < 10; $i++) $code .= $abc[random_int(0, strlen($abc) - 1)];
        $l['h'][$code] = ['pid' => $pid, 'tg' => $l['p'][$pid] ?? null, 'exp' => $now + 1800];
        save(TGLINKS, $l);
        return $code;
    });
    out(['ok' => true, 'code' => $code]);
}
if ($a === 'relink') {
    $code = strtoupper((string)($b['code'] ?? ''));
    $done = with_lock(function () use ($code, $pid) {
        $l = tgl(); $h = $l['h'][$code] ?? null;
        if (!$h || empty($h['used']) || $h['exp'] < time() || $h['tg'] === null || !isset($l['u'][$h['tg']])) return false;
        // only once the wallet is actually verified on this profile
        if (empty(load(HOLDERS)[$pid]['wallet'])) return false;
        $u = $l['u'][$h['tg']];
        unset($l['h'][$code]); save(TGLINKS, $l);
        tg_link_set($h['tg'], $pid, ['username' => $u['un'] ?? '', 'first_name' => $u['fn'] ?? '']);
        return true;
    });
    out(['ok' => $done]);
}
if ($a === 'unlink') { with_lock(fn() => tg_unlink($pid)); out(link_view($pid, $c)); }
fail('unknown action');
