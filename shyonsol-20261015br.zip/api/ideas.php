<?php
// Suggestions storage, shared by the public API (suggest.php) and the admin.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('IDEAS', DATA_DIR . '/ideas.php');
define('IDEA_FILES', DATA_DIR . '/idea-files');   // screenshots live outside the website; the admin serves them
const IDEA_CATS = ['game' => 'Game idea', 'cards' => 'Cards and balance', 'shop' => 'Shop and rewards', 'site' => 'Website', 'bug' => 'Something broke', 'other' => 'Something else'];
//MC 2026-10-13 'vote': the team puts an idea to the community, the board surfaces it and the chat is told to vote
const IDEA_STATUS = ['new' => 'New', 'reviewing' => 'Reviewing', 'vote' => 'Community vote', 'planned' => 'Planned', 'building' => 'Building', 'shipped' => 'Shipped', 'declined' => 'Not for now'];

// a short headline from the first line of a suggestion
function idea_title($text) {
    $line = trim(strtok($text, "\n"));
    if (mb_strlen($line) <= 70) return $line;
    $cut = mb_substr($line, 0, 67);
    return rtrim(mb_substr($cut, 0, mb_strrpos($cut, ' ') ?: 67), " ,.;:") . '…';
}

// Work out the language of an idea and, if it isn't English, store an English translation with it.
// Runs outside the lock (the translation service can take a few seconds), then saves under it.
function idea_translate($id, $s, $ui = 'en') {
    $lang = tr_lang($s['text'], $ui);
    $en = $lang === 'en' ? '' : tr_english($s['text'], $lang);
    with_lock(function () use ($id, $lang, $en) { $all = load(IDEAS); if (!isset($all[$id])) return; $all[$id]['lang'] = $lang; $all[$id]['en'] = $en; save(IDEAS, $all); });
    return ['lang' => $lang, 'en' => $en] + $s;
}
// the message as the player wrote it, then the English when it's in another language
function idea_body($s) {
    $lang = $s['lang'] ?? 'en';
    if ($lang === 'en') return ['Their message:', $s['text'], ''];
    $name = TR_NAMES[$lang] ?? strtoupper($lang);
    return ['Their message, in ' . $name . ':', $s['text'], '', 'English translation:', ($s['en'] ?? '') !== '' ? $s['en'] : "Couldn't translate it just now. Open it in the admin and press Translate.", ''];
}

// Tell the team by email. Uses the host's mail(); a failed send is logged, the suggestion is still saved.
function idea_email($id, $s) {
    $to = trim((string)(eco_settings()['idea_email'] ?? ''));
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL) || !function_exists('mail')) return false;
    $host = preg_replace('/[^a-z0-9.\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') ?: 'shyonsol.io';
    $site = 'https://' . $host;
    $who = $s['name'] !== '' ? $s['name'] : 'A guest player';
    $lines = [
        IDEA_CATS[$s['cat']] . ' from ' . $who . ($s['x'] ? ' (@' . $s['x'] . ' on X)' : '') . ($s['wallet'] ? ', wallet ' . $s['wallet'] : ''),
        '',
        ...idea_body($s),
        $s['contact'] !== '' ? 'Reply to: ' . $s['contact'] : 'No contact left.',
        $s['page'] !== '' ? 'Sent from: ' . $site . $s['page'] : null,
        $s['file'] !== '' ? 'Screenshot attached in the admin.' : null,
        '',
        'Open it in the admin: ' . $site . '/admin/?tab=ideas#idea-' . $id,
    ];
    // a message in another language gets its English headline in the subject, with the language named
    $lang = $s['lang'] ?? 'en'; $en = $s['en'] ?? '';
    $head = $lang !== 'en' && $en !== '' ? idea_title($en) . ' (' . (TR_NAMES[$lang] ?? $lang) . ')' : idea_title($s['text']);
    $subject = '=?UTF-8?B?' . base64_encode('New ' . strtolower(IDEA_CATS[$s['cat']]) . ': ' . $head) . '?=';
    $headers = "From: Shy on Solana <noreply@$host>\r\nReply-To: noreply@$host\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit";
    $ok = @mail($to, $subject, implode("\n", array_filter($lines, fn($l) => $l !== null)), $headers, "-fnoreply@$host");
    if (!$ok) @file_put_contents(DATA_DIR . '/mail-errors.log', gmdate('c') . " could not email idea $id to $to\n", FILE_APPEND);
    return $ok;
}
