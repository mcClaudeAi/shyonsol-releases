<?php
//MC 2026-10-14 deploy by link: the "safe to release" door. Given the deploy key, one or more HTTPS download links and
//   the zip's SHA-256, the server fetches the parts itself, joins them, checks the hash and runs the exact same swap
//   as Admin > Deploy (deploy_run in admin/deploy.php). A wrong key, a dead link or a wrong hash touches nothing, and
//   every successful deploy keeps its zip in shy-data/releases so the Deploy page can put the previous release back
//   in one press. The key is shown only to owners on the Deploy page and never ships inside a release zip.
// GET or POST: k=<deploy key> u1=<https url> [u2..u8] sha=<sha256 of the whole zip>  -> JSON
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require_once __DIR__ . '/artlib.php';   // masks_heal, so custom bot masks survive the swap like the upload path
require_once dirname(__DIR__) . '/admin/deploy.php';

const DP_MAX_PARTS = 8;
const DP_MAX_BYTES = 100 * 1024 * 1024;

function dp_fail($m, $code = 400) { http_response_code($code); echo json_encode(['ok' => false, 'error' => $m]); exit; }

$in = $_POST + $_GET;
$k = (string)($in['k'] ?? '');
$want = deploy_key();
if ($k === '' || !hash_equals($want, $k)) dp_fail('wrong key', 403);

// a deploy is heavy; a handful an hour is plenty, and a flood of bad calls says someone is guessing
$ok = with_lock(function () { $l = load(LIMITS); $ok = rate_ok($l, 'deploy-pull', 10, 3600); save(LIMITS, $l); return $ok; });
if (!$ok) dp_fail('too many deploys this hour', 429);

$urls = [];
for ($i = 1; $i <= DP_MAX_PARTS; $i++) if (!empty($in['u' . $i])) $urls[] = (string)$in['u' . $i];
if (isset($in['u']) && is_array($in['u'])) foreach ($in['u'] as $u) $urls[] = (string)$u;
$urls = array_slice($urls, 0, DP_MAX_PARTS);
//MC 2026-10-14 https only, with one exception: the machine's own loopback, so the local test server can exercise this
foreach ($urls as $u) if (!preg_match('#^https://[^\s]+$#', $u) && !preg_match('#^http://127\.0\.0\.1[:/][^\s]+$#', $u)) dp_fail('every link must be https');
if (!$urls) dp_fail('give at least one download link (u1=...)');
$sha = strtolower((string)($in['sha'] ?? ''));
if (!preg_match('/^[a-f0-9]{64}$/', $sha)) dp_fail('give the zip\'s SHA-256 (sha=...)');

@set_time_limit(600);
if (DEPLOY_TMP === '/deploy-tmp') dp_fail('data folder missing', 500);
deploy_rmdir(DEPLOY_TMP);
if (!@mkdir(DEPLOY_TMP, 0755, true)) dp_fail('could not make a working folder', 500);
$zipPath = DEPLOY_TMP . '/pull.zip';
$zf = @fopen($zipPath, 'wb');
if (!$zf) { deploy_rmdir(DEPLOY_TMP); dp_fail('could not open a working file', 500); }
//MC 2026-10-14 curl first (always on at Hostinger), the stream wrapper as the fallback where allow_url_fopen is on.
//   Both stream straight into the zip file with the size ceiling enforced mid-download, never into memory.
$total = 0; $over = false;
$pull = function ($u) use ($zf, &$total, &$over) {
    if (function_exists('curl_init')) {
        $ch = curl_init($u);
        curl_setopt_array($ch, [CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => 180, CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_USERAGENT => 'shyonsol-deploy', CURLOPT_SSL_VERIFYPEER => true, CURLOPT_FAILONERROR => true,
            CURLOPT_WRITEFUNCTION => function ($c, $buf) use ($zf, &$total, &$over) {
                $total += strlen($buf);
                if ($total > DP_MAX_BYTES) { $over = true; return -1; }
                return fwrite($zf, $buf);
            }]);
        $ok = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return ($ok !== false || $over) && $code >= 200 && $code < 300;
    }
    $src = @fopen($u, 'rb', false, stream_context_create(['http' => ['timeout' => 180, 'follow_location' => 1, 'max_redirects' => 3, 'user_agent' => 'shyonsol-deploy'], 'ssl' => ['verify_peer' => true]]));
    if (!$src) return false;
    while (!feof($src)) {
        $buf = fread($src, 1 << 20);
        if ($buf === false) break;
        $total += strlen($buf);
        if ($total > DP_MAX_BYTES) { $over = true; break; }
        fwrite($zf, $buf);
    }
    fclose($src);
    return true;
};
foreach ($urls as $n => $u) {
    $got = $pull($u);
    if ($over) { fclose($zf); deploy_rmdir(DEPLOY_TMP); dp_fail('the release is bigger than the ' . (DP_MAX_BYTES >> 20) . ' MB ceiling, nothing was touched', 413); }
    if (!$got) { fclose($zf); deploy_rmdir(DEPLOY_TMP); dp_fail('part ' . ($n + 1) . ' could not be downloaded, nothing was touched', 502); }
}
fclose($zf);
if ($total < 1024) { deploy_rmdir(DEPLOY_TMP); dp_fail('the download came back empty, nothing was touched', 502); }
if (!hash_equals($sha, hash_file('sha256', $zipPath))) { deploy_rmdir(DEPLOY_TMP); dp_fail('the hash does not match the download, nothing was touched', 409); }

$r = deploy_run($zipPath);
deploy_rmdir(DEPLOY_TMP);
if (isset($r['err'])) dp_fail($r['err'], 422);
deploy_log(['how' => 'pull', 'who' => '', 'v' => $r['v'], 'u' => $r['updated'], 'n' => $r['new'], 'r' => $r['removed']]);
echo json_encode(['ok' => true, 'v' => $r['v'], 'updated' => $r['updated'], 'added' => $r['new'], 'removed' => $r['removed'], 'bytes' => $total] + ($r['failed'] ? ['failed' => $r['failed']] : []));
