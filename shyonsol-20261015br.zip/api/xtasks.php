<?php
// Daily X tasks: post on X, paste the link here, get Koban and Scroll XP.
// Posts are checked through X's public embed endpoint (oEmbed), which needs no API key and costs no X credits.
// A post counts when it exists and is public, comes from the player's X account, was posted today (UTC, read from
// the post's own ID), says what the task asks for, and hasn't counted for anything before. One post, one task.
if (!defined('SHY_API')) exit;

define('XTASKS', DATA_DIR . '/x-tasks.php');   // ['h' => handle => pid, 'used' => post id => day, 'log' => latest claims]
const XT_OFFICIAL = 'ShyOnSol_';
const XT_EPOCH = 1288834974657;   // X post IDs carry their own time: (id >> 22) + this, in milliseconds
const XT_XP = 20;                 // Scroll XP per task

// what each task asks for; need: link (a shyonsol.io link), cash ($SHY), official (@ShyOnSol_), friend (another @someone), hash (#Shilluminati), daily (the word Daily)
const XT_POOL = [
    'result' => ['text' => 'Share a game result', 'how' => 'Finish any game and tap Share on X on the end screen. The post needs your result link.', 'need' => ['link']],
    'daily'  => ['text' => 'Share your Daily Challenge', 'how' => "Play today's Daily and share it from the end screen. The post needs the word Daily and your result link.", 'need' => ['daily', 'link']],
    'shill'  => ['text' => 'Post about $SHY', 'how' => 'Anything you like about Shy on Solana, with the $SHY cashtag in it.', 'need' => ['cash']],
    'tag'    => ['text' => 'Challenge a friend', 'how' => 'Tag @ShyOnSol_ and a friend you think can beat you.', 'need' => ['official', 'friend']],
    'hash'   => ['text' => 'Use #Shilluminati', 'how' => 'Post anything about the game with #Shilluminati in it.', 'need' => ['hash']],
];

function xt_daily_no() { return (int)floor((strtotime(today() . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1; }   // same as the Daily's own number
function xt_on() { return !empty(eco_settings()['xt_on']); }
function xt_koban($tier) { $k = (int)eco_settings()['xt_koban']; return $tier ? $k * 2 : $k; }
function xt_bonus($tier) { $k = (int)eco_settings()['xt_bonus']; return $tier ? $k * 2 : $k; }

// today's three tasks: a game result every day, plus two of the others in turn
function xt_today($day = null) {
    $day = $day ?? today();
    $rest = ['daily', 'shill', 'tag', 'hash'];
    $n = hexdec(substr(md5('xt' . $day), 0, 8));
    $a = $rest[$n % 4]; $b = $rest[($n % 4 + 1 + intdiv($n, 4) % 3) % 4];
    return ['result', $a, $b];
}

// the player's X handle: the account they connected on their profile, else the one their first counted post came from
function xt_handle($acc, $pid) {
    $xu = load(PLAYERS)[$pid]['xu'] ?? '';
    return $xu !== '' ? $xu : (string)($acc['xh'] ?? '');
}

// a post link -> [handle from the link, post id], or null
function xt_parse($url) {
    $url = trim($url);
    if (!preg_match('#^(?:https?://)?(?:www\.|mobile\.)?(?:x|twitter)\.com/(?:(\w{1,15})|i/web)/status(?:es)?/(\d{6,25})#i', $url, $m)) return null;
    return [$m[1] !== '' ? $m[1] : 'i', $m[2]];
}
function xt_posted_at($id) { return (int)((((int)$id) >> 22) + XT_EPOCH) / 1000; }

// ask X for the post. -> ['author' => handle, 'text' => plain text] or ['err' => message]
function xt_fetch($handle, $id) {
    $base = shy_config()['x_oembed'] ?? 'https://publish.twitter.com/oembed';
    $ch = curl_init($base . '?' . http_build_query(['url' => "https://twitter.com/$handle/status/$id", 'omit_script' => 1, 'dnt' => 'true', 'hide_thread' => 1]));
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 2, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code === 404 || $code === 403) return ['err' => "X can't show that post. Check the link, and make sure your account isn't private."];
    $j = $code === 200 ? json_decode((string)$raw, true) : null;
    if (!is_array($j) || empty($j['html']) || empty($j['author_url'])) { @file_put_contents(DATA_DIR . '/x-errors.log', gmdate('c') . " oembed $code for $id\n", FILE_APPEND); return ['err' => "X didn't answer just now. Try again in a minute."]; }
    if (!preg_match('#(?:x|twitter)\.com/(\w{1,15})/?$#i', $j['author_url'], $m)) return ['err' => "X didn't answer just now. Try again in a minute."];
    // the post's own words are the <p> inside the embed; links, tags and cashtags are <a> tags whose text is what people see
    $p = preg_match('#<p[^>]*>(.*?)</p>#is', $j['html'], $pm) ? $pm[1] : '';
    $text = html_entity_decode(strip_tags(str_ireplace(['<br>', '<br/>', '<br />'], "\n", $p)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    // X hides links behind t.co, and a link that becomes a preview card isn't in the words at all: follow them to see where they go
    preg_match_all('#href="(https?://[^"]+)"#i', $p, $hm);
    $n = 0;
    foreach (array_unique($hm[1]) as $u) {
        $u = html_entity_decode($u, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('#^https?://t\.co/\w+#i', $u)) { if ($n++ >= 4) continue; $u = xt_unshort($u); }
        if ($u !== '') $text .= "\n" . $u;
    }
    return ['author' => $m[1], 'text' => $text];
}
// where a t.co link goes, without following it any further ('' if X won't say)
function xt_unshort($u) {
    $tco = shy_config()['x_tco'] ?? '';   // only for local testing
    if ($tco !== '') $u = preg_replace('#^https?://t\.co/#i', $tco, $u);
    $ch = curl_init($u);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; ShyOnSol/1.0)']);
    $body = (string)curl_exec($ch); $loc = (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL); curl_close($ch);
    if ($loc === '' && preg_match('#(?:URL=|location\.replace\(")(https?://[^"\'>]+)#i', $body, $bm)) $loc = $bm[1];   // t.co sometimes answers with a page that redirects
    return $loc;
}
// was this post made through the site's own Post to X for this player? Then it's theirs and carries the result link for sure.
function xt_site_made($pid, $id) {
    foreach (load(DATA_DIR . '/x-accounts.php')[$pid]['posts'] ?? [] as $x) if ((string)($x['id'] ?? '') === (string)$id) return true;
    return false;
}

// what the post is missing for this task, in plain words ('' when it has it all)
function xt_missing($task, $text, $author, $site = false) {
    $miss = [];
    foreach (XT_POOL[$task]['need'] as $n) {
        if ($n === 'link' && !$site && stripos($text, 'shyonsol.io') === false) $miss[] = 'a shyonsol.io link';
        if ($n === 'cash' && !preg_match('/\$SHY\b/i', $text)) $miss[] = 'the $SHY cashtag';
        if ($n === 'official' && !preg_match('/@' . XT_OFFICIAL . '\b/i', $text)) $miss[] = '@' . XT_OFFICIAL;
        if ($n === 'hash' && !preg_match('/#Shilluminati\b/i', $text)) $miss[] = '#Shilluminati';
        // the share text names the Daily ("Daily" in English, and "#12" style in every language)
        if ($n === 'daily' && !preg_match('/\bDaily\b/i', $text) && !preg_match('/#' . xt_daily_no() . '\b/', $text)) $miss[] = 'the word Daily';
        if ($n === 'friend') {
            preg_match_all('/@(\w{1,15})/', $text, $mm);
            $others = array_filter($mm[1], fn($u) => strcasecmp($u, XT_OFFICIAL) !== 0 && strcasecmp($u, $author) !== 0);
            if (!$others) $miss[] = 'a friend tagged with @';
        }
    }
    return $miss ? 'That post is missing ' . implode(' and ', $miss) . '.' : '';
}

// the player's tasks for today, for the shop
function xtasks_mine($acc, $pid, $tier) {
    $done = ($acc['xt']['d'] ?? '') === today() ? $acc['xt']['done'] : [];
    $tasks = array_map(fn($id) => ['id' => $id] + XT_POOL[$id] + ['koban' => xt_koban($tier), 'xp' => XT_XP, 'done' => isset($done[$id]), 'url' => isset($done[$id]) ? $done[$id] : ''], xt_today());
    return ['on' => xt_on(), 'tasks' => $tasks, 'bonus' => xt_bonus($tier), 'bonusPaid' => ($acc['xt']['d'] ?? '') === today() && !empty($acc['xt']['b']),
        'handle' => xt_handle($acc, $pid), 'official' => XT_OFFICIAL, 'ends' => strtotime(today() . ' 00:00:00 UTC') + 86400];
}

// count a post for a task. Runs with the lock already held: $post is what xt_fetch returned.
// $site: the post went out through the site's own Post to X, so it's theirs for sure and the link (left off to save X credits) isn't needed.
function xt_claim(&$acc, $pid, $tier, $task, $id, $post, $site = false) {
    if (!in_array($task, xt_today(), true)) return ['err' => 'That task is not on today\'s list. New tasks land at 00:00 UTC.'];
    if (empty(load(PLAYERS)[$pid]['games']) && !$tier && empty(load(HOLDERS)[$pid]['wallet'])) return ['err' => 'Finish your first game to start earning from X tasks.'];
    if (($acc['xt']['d'] ?? '') !== today()) $acc['xt'] = ['d' => today(), 'done' => [], 'b' => false];
    if (isset($acc['xt']['done'][$task])) return ['err' => 'Already done today. New tasks land at 00:00 UTC.'];
    $at = xt_posted_at($id);
    if ($at < strtotime(today() . ' 00:00:00 UTC') || $at > time() + 300) return ['err' => 'That post is from before today. Tasks count posts made today (UTC).'];
    $all = load(XTASKS) + ['h' => [], 'used' => [], 'log' => []];
    if (isset($all['used'][$id])) return ['err' => 'That post has already counted. Each post counts for one task.'];
    $mine = xt_handle($acc, $pid);
    if ($mine !== '' && strcasecmp($mine, $post['author']) !== 0) return ['err' => 'That post is from @' . $post['author'] . '. Your X tasks count posts from @' . $mine . '.'];
    $hk = strtolower($post['author']);
    if ($mine === '' && isset($all['h'][$hk]) && $all['h'][$hk] !== $pid) return ['err' => '@' . $post['author'] . ' already earns X tasks for another player.'];
    if ($why = xt_missing($task, $post['text'], $post['author'], $site)) return ['err' => $why];
    // first counted post ties the X account to this profile
    if ($mine === '') { $acc['xh'] = $post['author']; $all['h'][$hk] = $pid; }
    $url = 'https://x.com/' . $post['author'] . '/status/' . $id;
    $k = xt_koban($tier);
    eco_credit($acc, $k, 'X task: ' . XT_POOL[$task]['text']);
    $acc['sc']['xp'] = min(SCROLL_TIERS * TIER_XP, $acc['sc']['xp'] + XT_XP);
    $acc['xt']['done'][$task] = $url;
    $got = $k; $bonus = 0;
    if (count($acc['xt']['done']) === 3 && empty($acc['xt']['b'])) { $bonus = xt_bonus($tier); eco_credit($acc, $bonus, 'X tasks: all three done'); $acc['xt']['b'] = true; $got += $bonus; }
    $all['used'][$id] = today();
    $all['used'] = array_filter($all['used'], fn($d) => $d >= gmdate('Y-m-d', time() - 3 * 86400));
    array_unshift($all['log'], ['t' => time(), 'pid' => $pid, 'task' => $task, 'url' => $url, 'k' => $got]);
    $all['log'] = array_slice($all['log'], 0, 300);
    save(XTASKS, $all);
    return ['koban' => $got, 'bonus' => $bonus, 'xp' => XT_XP];
}

// a result posted through the site's Post to X counts for today's Daily or game result task on its own
function xt_site_post($pid, $postId, $username, $text) {
    if (!xt_on()) return null;
    return with_lock(function () use ($pid, $postId, $username, $text) {
        $eco = load(ECO);
        $acc = eco_get($eco, $pid);
        $tier = holder_tier(load(HOLDERS)[$pid] ?? null);
        $done = ($acc['xt']['d'] ?? '') === today() ? $acc['xt']['done'] : [];
        $task = null;
        foreach (preg_match('/\bDaily\b/i', $text) || preg_match('/#' . xt_daily_no() . '\b/', $text) ? ['daily', 'result'] : ['result'] as $t) if (in_array($t, xt_today(), true) && !isset($done[$t])) { $task = $t; break; }
        if (!$task) return null;
        $r = xt_claim($acc, $pid, $tier, $task, $postId, ['author' => $username, 'text' => $text], true);
        if (isset($r['err'])) { @file_put_contents(DATA_DIR . '/x-errors.log', gmdate('c') . " x task not counted for a site post ($task): " . $r['err'] . "\n", FILE_APPEND); return null; }
        $eco[$pid] = $acc; save(ECO, $eco);
        return $r + ['task' => $task];
    });
}
