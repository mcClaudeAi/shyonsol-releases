<?php
// New card art published from the admin. Every page loads this before anything draws a card: it lists the cards
// with new art and swaps their pictures in wherever the original drawing appears, and names the season cards in play.
// With no new art and no season cards it sends nothing.
define('SHY_API', 1);
require __DIR__ . '/common.php';
header('Content-Type: application/javascript; charset=utf-8');
header('X-Content-Type-Options: nosniff');

require_once __DIR__ . '/cardsetlib.php';
require_once __DIR__ . '/artlib.php';
$db = load(ART_DB);
$v = (int)($db['_v'] ?? 0);
// the season cards in play right now, for games started without the server (the server sends its own list with every game)
$deck = season_deck_at();
$etag = '"art-' . $v . '-' . implode('.', $deck) . '-' . count(glob(dirname(__DIR__) . '/card-art/*.{webp,jpg}', GLOB_BRACE) ?: []) . '"';
header('ETag: ' . $etag);
header('Cache-Control: public, max-age=300');
if (trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')) === $etag) { http_response_code(304); exit; }

$map = [];
foreach ($db as $id => $e) {
    if ($id === '_v' || empty($e['live']['f']) || !preg_match('/^[a-z0-9]+$/', $id)) continue;
    // an image missing from the server still goes on the list when it can be put back (the first request for it does that);
    // one that can't is left off, so the card shows its original drawing. Images in place get their safe copy once.
    if (is_file(ART_PUB . '/' . $e['live']['f'])) art_keep($e['live']['f']);
    elseif (!art_healable($e['live']['f'])) continue;
    $map[$id] = ['/card-art/' . rawurlencode($e['live']['f']), round($e['live']['fx'] ?? 50) . '% ' . round($e['live']['fy'] ?? 50) . '%'];
}
if ($deck) echo 'window.SHY_SEASON=' . json_encode($deck) . ';';
if (!$map) exit;
echo 'window.SHY_ART=' . json_encode($map, JSON_UNESCAPED_SLASHES) . ';';
?>
(function () {
  var A = window.SHY_ART, re = /assets\/cards\/([a-z0-9]+)\.(?:svg|webp)/;
  //MC 2026-10-11 every card used the full 1040 x 640 file, even a 40 px stats icon (the Cards page weighed 10.6 MB).
  // The server keeps 780, 520, 360 and 260 wide copies (card-art/w780/ ... w260/; made on first request if missing, and a missing
  // one falls back to the full file), so each picture gets a srcset and sizes set to the box it's drawn in. Pictures
  // fill their box (object-fit: cover, 13:8 art), so a tall narrow box needs height x 13/8 of width. offsetWidth is
  // used, not the on-screen rect, so a card flying in at a small scale doesn't get stuck with the small file. A box
  // is measured again whenever its box changes (hidden, not laid out yet, or a new layout); a loaded file only gets bigger.
  // Tried sizes="auto" first: only recent Chrome knows it and only on lazy images, so the rest fetched the 1040 file.
  var RO = window.ResizeObserver ? new ResizeObserver(function (es) {
    es.forEach(function (e) { var i = e.target; if (!i.isConnected || !i.hasAttribute("srcset")) { RO.unobserve(i); return; } size(i); });
  }) : null;
  var todo = [];
  // the height only counts once the picture has loaded: before that an img with no size of its own is 150 px tall (the
  // browser default), which made a 172 x 106 card ask for a 244 px file
  function box(el, tall) { return el ? Math.max(el.offsetWidth || 0, tall ? (el.offsetHeight || 0) * 13 / 8 : 0) : 0; }
  function meas(img) { var t = img.complete && img.naturalWidth > 0; return Math.ceil(box(img, t) || box(img.parentElement, t)); }
  function size(img, w) {
    w = w || meas(img);
    if (!w) return false;
    // screens sharper than 2x get a 2x picture: past that the difference doesn't show, the download does
    var d = window.devicePixelRatio || 1; if (d > 2) w = Math.ceil(w * 2 / d);
    // bigger, or smaller while the picture hasn't loaded yet; by more than a rounding step, since every change of sizes
    // makes the browser fetch the picture again
    var cur = +img.getAttribute("data-artw") || 0;
    if (!cur || w > cur * 1.08 || (w < cur * 0.92 && !img.complete)) { img.setAttribute("data-artw", w); img.sizes = w + "px"; }
    return true;
  }
  // all the measuring after all the src changes, so a batch of new cards costs one layout, not one per card
  function flush() {
    var l = todo; todo = [];
    var ws = l.map(meas);
    l.forEach(function (i, k) {
      size(i, ws[k]); if (RO) RO.observe(i);
      // measured again once loaded, now with its height, for tall narrow boxes like the phone hand
      if (!i.hasAttribute("data-artl")) { i.setAttribute("data-artl", "1"); i.addEventListener("load", function () { if (i.hasAttribute("data-art")) size(i); }); }
    });
  }
  function fix(img) {
    var m = re.exec(img.getAttribute("src") || "");
    if (m && A[m[1]]) {
      var u = A[m[1]][0], f = u.slice(u.lastIndexOf("/") + 1);
      img.removeAttribute("data-artw"); img.setAttribute("data-art", "1");
      img.sizes = "260px";
      img.srcset = "/card-art/w260/" + f + " 260w, /card-art/w360/" + f + " 360w, /card-art/w520/" + f + " 520w, /card-art/w780/" + f + " 780w, " + u + " 1040w";
      img.src = u; img.style.objectPosition = A[m[1]][1];
      todo.push(img);
    } else if (img.hasAttribute("data-art") && (img.getAttribute("src") || "").indexOf("/card-art/") < 0) {
      // the same picture reused for a card without new art: drop the old card's srcset, or it would keep showing
      img.removeAttribute("srcset"); img.removeAttribute("sizes"); img.removeAttribute("data-artw"); img.removeAttribute("data-art"); img.style.objectPosition = "";
    }
  }
  function scan(n) { if (n.nodeType !== 1) return; if (n.tagName === "IMG") fix(n); else if (n.querySelectorAll) Array.prototype.forEach.call(n.querySelectorAll("img"), fix); }
  // cards drawn later by the game, the shop and the stats are caught as they appear
  new MutationObserver(function (ms) {
    ms.forEach(function (m) { if (m.type === "attributes") fix(m.target); else Array.prototype.forEach.call(m.addedNodes, scan); });
    if (todo.length) flush();
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
  scan(document.documentElement); if (todo.length) flush();
  if (A.back) { var st = document.createElement("style"); st.textContent = '.of-art{background-image:url("' + A.back[0] + '")!important}'; (document.head || document.documentElement).appendChild(st); }
})();
