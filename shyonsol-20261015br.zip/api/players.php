<?php
//MC 2026-10-13 the public player directory behind the Players page: every named player, searchable and filterable,
//   with the one answer built from a 60 second cache so a crowd costs the server one scan a minute (the Ideas board
//   lesson). Presence is overlaid per request because it changes by the second and the file is tiny.
// GET ?a=list&q=<name>&f=all|online|holders|houses|new&s=points|wins|week|new&pg=N
//   -> {meta: {total, online, holders, houses, new7, games}, players: [...], page, pages, per}
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';

define('PLAYERS_CACHE', DATA_DIR . '/players-cache.php');
const PD_TTL = 60;
const PD_PER = 24;
const PD_ONLINE = 150;   // same window as the pulse and Friends
const PD_NEW = 7 * 86400;

function pd_limit() {
    $ok = with_lock(function () { $l = load(LIMITS); $ok = rate_ok($l, 'pdir:' . client_ip(), 240, 600); save(LIMITS, $l); return $ok; });
    if (!$ok) fail('Slow down a little and try again.', 429);
}

// the heavy scan, at most once a minute: players joined with holder tiers and Houses, banned and nameless left out
function pd_build() {
    require_once __DIR__ . '/holders.php';
    require_once __DIR__ . '/economy.php';
    require_once __DIR__ . '/houselib.php';
    $now = time();
    $players = load(PLAYERS); $hol = load(HOLDERS); $H = houses();
    $ban = banned_in($players, $hol);
    $rows = []; $nHold = 0; $nHouse = 0; $nNew = 0; $games = 0;
    foreach ($players as $pid => $x) {
        if (!is_array($x) || ($x['name'] ?? '') === '' || isset($ban[$pid])) continue;
        $tier = holder_tier($hol[$pid] ?? null);
        $isHold = !empty($x['holder']) || $tier !== '';
        $hid = house_of($pid, $H); $house = null;
        if ($hid !== '') { $h = $H['h'][$hid]; $house = ['tag' => $h['tag'], 'color' => $h['color'], 'crest' => $h['crest']]; $nHouse++; }
        $new = $now - (int)($x['since'] ?? 0) < PD_NEW;
        if ($isHold) $nHold++;
        if ($new) $nNew++;
        $games += (int)($x['games'] ?? 0);
        $sh = !empty($x['avatar']) && !empty($x['holder']);
        $rows[] = ['t' => substr($pid, 0, 6), 'name' => (string)$x['name'],
            'img' => $sh ? shadow_img($x['avatar']) : '', 'aura' => $sh ? shadow_aura($x['avatar']) : '',
            'tier' => $tier, 'hold' => $isHold ? 1 : 0, 'house' => $house,
            'pts' => (int)($x['points'] ?? 0), 'wins' => (int)($x['wins'] ?? 0), 'games' => (int)($x['games'] ?? 0),
            'w' => ($x['wk'] ?? '') === week_key() ? (int)($x['wpts'] ?? 0) : 0,   // the cache lives a minute, the week a week
            'since' => (int)($x['since'] ?? 0), 'last' => (int)($x['last'] ?? 0), 'badges' => (int)($x['badges'] ?? 0),
            'p' => empty($x['hide']) ? 1 : 0, 'dot' => empty($x['hideon']) ? 1 : 0];
    }
    return ['t' => $now, 'rows' => $rows,
        'meta' => ['total' => count($rows), 'holders' => $nHold, 'houses' => $nHouse, 'new7' => $nNew, 'games' => $games]];
}

if (($_GET['a'] ?? 'list') !== 'list') fail('unknown');
header('Cache-Control: public, max-age=30');
$c = load(PLAYERS_CACHE);
if (empty($c['t']) || time() - (int)$c['t'] > PD_TTL) {
    pd_limit();   // only a rebuild counts against anyone
    $c = pd_build();
    save(PLAYERS_CACHE, $c);
}
$rows = $c['rows']; $now = time();

// presence is seconds-fresh, so it rides on top of the cached scan.
// presence.php keys are full pids; the cache keeps 6 characters for privacy, so match on the prefix once.
$pres = load(DATA_DIR . '/presence.php');
$p6 = [];
foreach ($pres as $pid => $ts) if ($now - (int)$ts < PD_ONLINE) $p6[substr((string)$pid, 0, 6)] = 1;
$nOn = 0;
foreach ($rows as &$r) { $r['on'] = $r['dot'] && isset($p6[$r['t']]) ? 1 : 0; if ($r['on']) $nOn++; unset($r['dot']); }
unset($r);

$q = mb_strtolower(trim(mb_substr((string)($_GET['q'] ?? ''), 0, 40)));
$f = in_array($_GET['f'] ?? 'all', ['all', 'online', 'holders', 'houses', 'new'], true) ? ($_GET['f'] ?? 'all') : 'all';
$s = in_array($_GET['s'] ?? 'points', ['points', 'wins', 'week', 'new'], true) ? ($_GET['s'] ?? 'points') : 'points';
$list = array_values(array_filter($rows, function ($r) use ($q, $f, $now) {
    if ($q !== '' && strpos(mb_strtolower($r['name']), $q) === false) return false;
    if ($f === 'online') return $r['on'] === 1;
    if ($f === 'holders') return $r['hold'] === 1;
    if ($f === 'houses') return $r['house'] !== null;
    if ($f === 'new') return $now - $r['since'] < PD_NEW;
    return true;
}));
usort($list, function ($x, $y) use ($s, $q) {
    if ($q !== '') { $a = mb_strtolower($x['name']) === $q ? 1 : 0; $b = mb_strtolower($y['name']) === $q ? 1 : 0; if ($a !== $b) return $b <=> $a; }
    if ($s === 'wins') return [$y['wins'], $y['pts']] <=> [$x['wins'], $x['pts']];
    if ($s === 'week') return [$y['w'], $y['pts']] <=> [$x['w'], $x['pts']];
    if ($s === 'new') return [$y['since'], $y['pts']] <=> [$x['since'], $x['pts']];
    return [$y['pts'], $y['wins'], $y['last']] <=> [$x['pts'], $x['wins'], $x['last']];
});
$total = count($list); $pages = max(1, (int)ceil($total / PD_PER));
$pg = max(1, min($pages, (int)($_GET['pg'] ?? 1)));
out(['ok' => true, 'meta' => $c['meta'] + ['online' => $nOn], 'total' => $total, 'page' => $pg, 'pages' => $pages, 'per' => PD_PER,
    'players' => array_slice($list, ($pg - 1) * PD_PER, PD_PER)]);
