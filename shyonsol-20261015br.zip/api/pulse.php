<?php
//MC 2026-10-11 the site's pulse in one small answer, for the strip in the Play lobby and the one under the Home hero:
//   who's online (a few faces), live tables open now, the next busy hour from the When and where numbers, games today
//   and the last prize paid. Built at most every 15 seconds and kept in shy-data/pulse-cache.php, so a busy lobby
//   costs one file read per visit. Players who turned off "Show me as online" in Friends never count or show here,
//   banned profiles neither, and a player with a private page counts but never shows a face.
// GET ?a=now            -> {online, faces[], tables{open, playing, next}, busy{now, ts, avg}, today{g, p}, prize{...}}
// GET ?a=find&q=<text>  -> up to 6 players whose name has that text, for the search on the not-found page
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';

define('PULSE_CACHE', DATA_DIR . '/pulse-cache.php');
const PULSE_TTL = 15;
const PULSE_ONLINE = 150;      // same as FR_ONLINE in friendslib.php: seconds since the site was last open
const PULSE_QUICK_WAIT = 30;   // same as QUICK_WAIT in livelib.php: a public table starts this long after it opens

function pulse_limit($what, $max, $window) {
    $ok = with_lock(function () use ($what, $max, $window) { $l = load(LIMITS); $ok = rate_ok($l, $what, $max, $window); save(LIMITS, $l); return $ok; });
    if (!$ok) fail('Slow down a little and try again.', 429);
}

// the hour of the week (UTC, Sunday 00:00 first) that is busy next, from the last 4 full weeks of games by hour.
// "Busy" is the top fifth of the hours that saw games at all. Today isn't counted yet (half a day would look quiet).
function pulse_busy($st, $now) {
    $days = $st['d'] ?? [];
    $sinceDay = gmdate('Y-m-d', (int)($st['since'] ?? $now));
    $sum = array_fill(0, 168, 0); $dn = array_fill(0, 7, 0); $seen = 0;
    for ($i = 1; $i <= 28; $i++) {
        $t = $now - $i * 86400; $d = gmdate('Y-m-d', $t);
        if ($d < $sinceDay) break;
        $dow = (int)gmdate('w', $t); $dn[$dow]++; $seen++;
        $x = $days[$d] ?? null; if (!$x) continue;
        for ($h = 0; $h < 24; $h++) $sum[$dow * 24 + $h] += (int)($x['h'][$h] ?? 0);
    }
    if ($seen < 7) return null;   // under a week of history says nothing about a weekly rhythm
    $avg = [];
    for ($k = 0; $k < 168; $k++) $avg[$k] = $dn[intdiv($k, 24)] ? $sum[$k] / $dn[intdiv($k, 24)] : 0;
    $nz = array_values(array_filter($avg, fn($v) => $v > 0));
    if (count($nz) < 10) return null;
    sort($nz);
    $thr = max(1, $nz[(int)floor(count($nz) * 0.8)]);
    $h0 = intdiv($now, 3600) * 3600;
    for ($j = 0; $j < 168; $j++) {
        $t = $h0 + $j * 3600;
        $k = (int)gmdate('w', $t) * 24 + (int)gmdate('G', $t);
        if ($avg[$k] >= $thr) return ['now' => $j === 0, 'ts' => $t, 'avg' => (int)round($avg[$k])];
    }
    return null;
}

// public tables: open ones still waiting for players (the next one "Find a match" joins) and ones being played now
function pulse_tables($now) {
    $open = 0; $playing = 0; $next = null;
    $dir = DATA_DIR . '/rooms';
    $files = is_dir($dir) ? glob($dir . '/*.php') : [];
    // only rooms touched in the last few minutes can be open or playing (a running table is saved every turn)
    $fresh = [];
    foreach ($files ?: [] as $f) { $m = @filemtime($f); if ($m && $m > $now - 300) $fresh[$f] = $m; }
    arsort($fresh);
    foreach (array_slice(array_keys($fresh), 0, 60) as $f) {
        $r = load($f);
        if (!$r || (empty($r['public']) && empty($r['tourney']))) continue;
        $hum = count(array_filter($r['seats'] ?? [], fn($s) => !empty($s['human'])));
        if ($hum < 1) continue;
        $st = $r['status'] ?? '';
        if ($st === 'waiting' && !empty($r['public']) && empty($r['tourney'])) {
            $left = (int)max((int)($r['created'] ?? 0) + PULSE_QUICK_WAIT, (int)($r['hold'] ?? 0)) - $now;   //MC 2026-10-15 a held room starts later
            if ($left < 3 || count($r['seats'] ?? []) >= 4) continue;   // about to start or full: "Find a match" won't get in
            $open++;
            if (!$next || $left > $next['left']) $next = ['humans' => $hum, 'left' => $left];
        } elseif ($st === 'playing') $playing++;
    }
    return ['open' => $open, 'playing' => $playing, 'next' => $next];
}

function pulse_build() {
    require_once __DIR__ . '/holders.php';
    require_once __DIR__ . '/economy.php';
    require_once __DIR__ . '/statslib.php';
    $now = time();
    $players = load(PLAYERS);
    $pres = load(DATA_DIR . '/presence.php');
    $ban = banned_in($players);
    $on = [];
    foreach ($pres as $p => $ts) if ($now - (int)$ts < PULSE_ONLINE && !empty($players[$p]['name']) && empty($players[$p]['hideon']) && !isset($ban[$p])) $on[$p] = (int)$ts;
    arsort($on);
    $faces = [];
    foreach ($on as $p => $_) {
        $x = $players[$p];
        if (!empty($x['hide'])) continue;   // private page: counted, never shown
        $faces[] = ['n' => $x['name'], 't' => substr($p, 0, 6), 'img' => !empty($x['avatar']) && !empty($x['holder']) ? shadow_img($x['avatar']) : ''];
        if (count($faces) >= 7) break;
    }
    $st = load(STATS);
    $td = $st['d'][gmdate('Y-m-d', $now)] ?? [];
    $prize = null;
    $tc = load(DATA_DIR . '/treasury-cache.php');   // written by api/treasury.php; prizes change rarely, so an old copy is fine
    $pz = $tc['payouts'][0] ?? null;
    if ($pz && !empty($pz['sig'])) $prize = ['name' => (string)($pz['name'] ?? ''), 'shy' => (float)($pz['shy'] ?? 0), 'usd' => (float)($pz['usd'] ?? 0), 'sig' => (string)$pz['sig'], 't' => (int)($pz['t'] ?? 0), 'what' => (string)($pz['what'] ?? '')];
    // no Treasury copy yet (nobody opened the Treasury or Token page since it was cleared): the newest paid prize straight
    // from the results, in dollars only (the $SHY amount needs the token's decimals, which can mean a network call)
    if (!$tc) {
        $best = null;
        $see = function ($w, $at) use (&$best, $players) { if (!empty($w['sig']) && (!$best || (int)($w['paidAt'] ?? $at) > $best['t'])) $best = ['name' => (string)($players[$w['pid'] ?? '']['name'] ?? ($w['name'] ?? '')), 'shy' => 0, 'usd' => (float)($w['usd'] ?? 0), 'sig' => (string)$w['sig'], 't' => (int)($w['paidAt'] ?? $at), 'what' => '']; };
        $rw = load(REWARDS);
        foreach ($rw['weeks'] ?? [] as $w) foreach (array_merge($w['league'] ?? [], $w['cup'] ?? []) as $x) $see($x, (int)($w['at'] ?? 0));
        foreach ($rw['seasons'] ?? [] as $w) foreach ($w['winners'] ?? [] as $x) $see($x, (int)($w['at'] ?? 0));
        if (function_exists('bounty_db')) foreach (bounty_db()['m'] ?? [] as $bw) if (!empty($bw['paid']) && !empty($bw['tx'])) $see(['sig' => $bw['tx'], 'paidAt' => $bw['paid'], 'pid' => $bw['pid'] ?? '', 'name' => $bw['name'] ?? '', 'usd' => $bw['usd'] ?? 0], 0);
        $prize = $best;
    }
    //MC 2026-10-13 the live drop with the fewest copies left, for the hero's live line and the shop nudge
    $drop = null;
    if (function_exists('drops_public')) foreach (drops_public() as $d) {
        if ($d['soldout'] || $d['start'] > $now || $d['end'] <= $now) continue;
        if (!$drop || $d['left'] < $drop['left']) $drop = ['name' => $d['cardName'] . ' in ' . $d['finName'], 'left' => $d['left'], 'n' => $d['n'], 'end' => $d['end']];
    }
    return ['ok' => true, 'at' => $now, 'online' => count($on), 'faces' => $faces, 'tables' => pulse_tables($now), 'busy' => pulse_busy($st, $now),
        'today' => ['g' => (int)($td['g'] ?? 0), 'p' => is_array($td['p'] ?? null) ? count($td['p']) : 0], 'prize' => $prize, 'drop' => $drop];
}

$a = (string)($_GET['a'] ?? 'now');
if ($a === 'now') {
    header('Cache-Control: public, max-age=15');
    $c = load(PULSE_CACHE);
    if (!empty($c['at']) && time() - (int)$c['at'] < PULSE_TTL) out($c);
    pulse_limit('pulse:' . client_ip(), 240, 600);   // only a rebuild costs anything, so only a rebuild counts
    $c = pulse_build();
    save(PULSE_CACHE, $c);
    out($c);
}
if ($a === 'find') {
    header('Cache-Control: no-store');
    $q = mb_strtolower(trim(mb_substr((string)($_GET['q'] ?? ''), 0, 24)));
    if (mb_strlen($q) < 2) out(['ok' => true, 'players' => []]);
    pulse_limit('pfind:' . client_ip(), 60, 600);
    require_once __DIR__ . '/holders.php';
    require_once __DIR__ . '/economy.php';
    $players = load(PLAYERS);
    $ban = banned_in($players);
    $hit = [];
    foreach ($players as $pid => $x) {
        $n = (string)($x['name'] ?? '');
        if ($n === '' || empty($x['games']) || !empty($x['hide']) || isset($ban[$pid])) continue;
        $pos = strpos(mb_strtolower($n), $q);
        if ($pos === false) continue;
        $hit[] = [mb_strtolower($n) === $q ? 2 : ($pos === 0 ? 1 : 0), (int)($x['points'] ?? 0), $n, !empty($x['avatar']) && !empty($x['holder']) ? shadow_img($x['avatar']) : ''];
    }
    usort($hit, fn($x, $y) => [$y[0], $y[1]] <=> [$x[0], $x[1]]);
    out(['ok' => true, 'players' => array_map(fn($h) => ['name' => $h[2], 'img' => $h[3], 'points' => $h[1]], array_slice($hit, 0, 6))]);
}
fail('unknown');
