<?php
// A card art image that isn't in /card-art lands here (see .htaccess). It's put back from the safe copy or rebuilt from
// the original upload, then served; from then on the web server serves the file directly again. If it can't be put
// back, the card's original drawing is shown instead.
define('SHY_API', 1);
require __DIR__ . '/common.php';
require_once __DIR__ . '/artlib.php';
$f = basename((string)($_GET['f'] ?? ''));
if (!preg_match(ART_FILE_RE, $f)) { http_response_code(404); exit; }
//MC 2026-10-11 a smaller size (card-art/w780/, w520/, w360/ or w260/) that isn't there yet is made from the full image on its first
// request; if that can't be done the full image is sent instead, so a page never shows a broken card
$w = (int)($_GET['w'] ?? 0);
if ($w && !in_array($w, art_widths(), true)) { http_response_code(404); exit; }
$rel = $w ? art_size_rel($f, $w) : $f;
@set_time_limit(60);
// repairs take turns on their own lock (not the site-wide one), so a page asking for many missing images never holds up the rest of the site
$ok = is_file(ART_PUB . '/' . $rel);
if (!$ok) {
    $lk = @fopen(DATA_DIR . '/card-art-heal.lock', 'c');
    if ($lk) flock($lk, LOCK_EX);
    $ok = is_file(ART_PUB . '/' . $rel) || art_heal($f, $w);
    if ($lk) { flock($lk, LOCK_UN); fclose($lk); }
}
if (!$ok && $w && is_file(ART_PUB . '/' . $f)) { header('Cache-Control: no-store'); header('Location: /card-art/' . rawurlencode($f), true, 302); exit; }
if (!$ok) {
    $id = explode('-', $f)[0];
    header('Cache-Control: no-store');
    //MC 2026-10-09 the pre-drawn WebP when there is one (the SVG is the source and the fallback)
    $base = is_file(dirname(__DIR__) . '/assets/cards/' . $id . '.svg') ? $id : 'back';
    header('Location: /assets/cards/' . $base . (is_file(dirname(__DIR__) . '/assets/cards/' . $base . '.webp') ? '.webp' : '.svg'), true, 302);
    exit;
}
header('Content-Type: ' . (str_ends_with($f, '.webp') ? 'image/webp' : 'image/jpeg'));
header('Cache-Control: public, max-age=604800');
header('X-Content-Type-Options: nosniff');
readfile(ART_PUB . '/' . $rel);
