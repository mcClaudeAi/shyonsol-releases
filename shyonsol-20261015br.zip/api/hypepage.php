<?php
//MC 2026-10-14 /h/<tag>-<v>: the landing link under a player's own hype post. Its whole job is the unfurl: X reads the
//   tags here and shows that player's hype card (api/share.php?hp=), so the run bragged about in the post is the run in
//   the picture. Anyone who taps it lands on the player's public page; a hidden or unknown player goes to the game.
define('SHY_API', 1);
require __DIR__ . '/common.php';

function hy_h($x) { return htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8'); }

$tag = (string)($_GET['t'] ?? '');
$v = max(1, min(3, (int)($_GET['v'] ?? 1)));
$players = preg_match('/^[a-f0-9]{6}$/', $tag) ? load(PLAYERS) : [];
$p = null;
foreach ($players as $id => $x) if (strpos($id, $tag) === 0 && !empty($x['games'])) { $p = $x; break; }
if (!$p || ($p['name'] ?? '') === '' || !empty($p['hide'])) {
    header('Cache-Control: no-store');
    header('Location: /play', true, 302);
    exit;
}
$name = (string)$p['name'];
$pts = (int)($p['points'] ?? 0); $wins = (int)($p['wins'] ?? 0); $games = (int)($p['games'] ?? 0);
$wr = $games ? round($wins / $games * 100) : 0;

$h = preg_replace('/[^a-z0-9.:\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') ?: 'shyonsol.io';
$site = (strpos($h, '127.0.0.1') === false ? 'https' : 'http') . '://' . $h;
$go = '/p/' . rawurlencode(str_replace(' ', '_', $name));
$title = $name . ' | Shilluminati Online';
$desc = $name . "'s run so far: " . number_format($pts) . ' points, ' . number_format($wins) . ' wins, ' . $wr . '% win rate. Free in your browser, no wallet needed.';
// the image carries the record's own hash, so a changed record gets a fresh unfurl instead of X's cached one
$img = $site . '/api/share.php?hp=' . $tag . '&v=' . $v . '&r=' . substr(sha1($pts . '|' . $wins . '|' . $games), 0, 8);
$url = $site . '/h/' . $tag . '-' . $v;
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=600');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
    . '<title>' . hy_h($title) . '</title>'
    . '<meta name="description" content="' . hy_h($desc) . '">'
    . '<link rel="canonical" href="' . hy_h($url) . '">'
    . '<meta name="robots" content="noindex">'
    . '<meta property="og:type" content="website"><meta property="og:site_name" content="Shy on Solana">'
    . '<meta property="og:title" content="' . hy_h($title) . '"><meta property="og:description" content="' . hy_h($desc) . '">'
    . '<meta property="og:url" content="' . hy_h($url) . '">'
    . '<meta property="og:image" content="' . hy_h($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
    . '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:site" content="@ShyOnSol_"><meta name="twitter:title" content="' . hy_h($title) . '">'
    . '<meta name="twitter:description" content="' . hy_h($desc) . '"><meta name="twitter:image" content="' . hy_h($img) . '">'
    . '</head><body style="margin:0;background:#140d33;color:#fff;font:600 16px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh">'
    . '<p><a href="' . hy_h($go) . '" style="color:#ff5d73">Taking you to their page&hellip;</a></p>'
    . '<script>location.replace(' . json_encode($go) . ');</script></body></html>';
