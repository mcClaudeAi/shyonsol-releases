<?php
// The public Treasury page's data: every prize paid to players with its Solana transaction, the community wallet,
// this week's pool, and the treasury moves the team records in the admin (buys for the prize pool, burns, liquidity).
// GET -> JSON, rebuilt at most every 5 minutes. Wallets of winners are never listed, only names and transactions.

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
define('TREASURY_LOG', DATA_DIR . '/treasury-log.php');     // [{t, kind, shy, usd, sig, note}] entered in the admin
define('TREASURY_CACHE', DATA_DIR . '/treasury-cache.php');
//MC 2026-10-13 the founding burn: Shytoshi's 500M burn on Jan 26, 2025. The signer wallet and exact time are read from
//   the transaction itself once and kept for good (the chain never changes), so the Token page shows them chain-verified.
define('FOUNDING_SIG', '2mGp5RW7Zge6Bp9LkbrTGZZ3uF6LMZsq36kyZQamBJ1mtEoxgVmqBtLghxemUYtcqYmSU1TYLLdgC49E8JEsrX1h');
define('FOUNDING_CACHE', DATA_DIR . '/founding.php');
function tr_founding() {
    $c = load(FOUNDING_CACHE);
    if (!empty($c['wallet'])) return $c;
    $tx = rpc('getTransaction', [FOUNDING_SIG, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]);
    $keys = array_map(fn($k) => is_array($k) ? ($k['pubkey'] ?? '') : $k, $tx['transaction']['message']['accountKeys'] ?? []);
    $c = ['sig' => FOUNDING_SIG, 'wallet' => (string)($keys[0] ?? ''), 't' => (int)($tx['blockTime'] ?? 0)];
    if ($c['wallet'] !== '') with_lock(fn() => save(FOUNDING_CACHE, $c));
    return $c;
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=60');
header('X-Content-Type-Options: nosniff');

function tr_build() {
    $rw = load(REWARDS);
    $players = load(PLAYERS);
    $dec = mint_decimals(SHY_MINT) ?? 6;
    $rows = []; $paidShy = 0.0; $paidUsd = 0.0; $winners = [];
    $add = function ($list, $label, $at) use (&$rows, &$paidShy, &$paidUsd, &$winners, $players, $dec) {
        foreach ($list ?? [] as $w) {
            if (empty($w['sig'])) continue;
            $shy = !empty($w['units']) ? $w['units'] / (10 ** $dec) : 0;
            $name = $players[$w['pid'] ?? '']['name'] ?? ($w['name'] ?? '');
            $rows[] = ['t' => (int)($w['paidAt'] ?? $at), 'what' => $label, 'place' => (int)($w['place'] ?? 0), 'name' => $name,
                'shy' => round($shy, 2), 'usd' => round((float)($w['usd'] ?? 0), 2), 'sig' => $w['sig']];
            $paidShy += $shy; $paidUsd += (float)($w['usd'] ?? 0); $winners[$w['pid'] ?? $name] = 1;
        }
    };
    foreach ($rw['weeks'] ?? [] as $wk => $w) {
        [$y, $n] = explode('-', $wk) + [1 => ''];
        $add($w['league'] ?? [], 'Weekly League, week ' . (int)$n, $w['at'] ?? 0);
        $add($w['cup'] ?? [], 'Holder Cup, week ' . (int)$n, $w['at'] ?? 0);
    }
    foreach ($rw['seasons'] ?? [] as $s => $w) $add($w['winners'] ?? [], 'Season ' . $s . ' Championship', $w['at'] ?? 0);
    //MC 2026-10-10 the 15 Club bounty is a prize too: listed with the others once it's paid
    $bountySigs = [];
    if (function_exists('bounty_db')) foreach (bounty_db()['m'] ?? [] as $m => $bw) {
        if (empty($bw['paid']) || empty($bw['tx'])) continue;
        $bountySigs[$bw['tx']] = 1;
        $add([['sig' => $bw['tx'], 'paidAt' => $bw['paid'], 'place' => 1, 'pid' => $bw['pid'], 'name' => $bw['name'], 'units' => (int)($bw['units'] ?? 0), 'usd' => (float)($bw['usd'] ?? 0)]],
            '15 Club bounty, ' . gmdate('F Y', strtotime($m . '-01')), $bw['paid']);
    }
    usort($rows, fn($a, $b) => $b['t'] <=> $a['t']);
    //MC 2026-10-10 burns: the share of each $SHY shop payment burned in the buyer's own transaction, and any burn the team
    //   made later from the community wallet for a payment that came as a plain transfer
    $burns = []; $burnTot = 0.0;
    foreach (load(ORDERS) as $o) {
        if (($o['status'] ?? '') !== 'paid' || !empty($o['selfpay'])) continue;
        $d = (int)($o['dec'] ?? $dec);
        foreach ([[(int)($o['burned'] ?? 0), $o['proof'] ?? '', $o['paid'] ?? 0], [(int)($o['burn_done'] ?? 0), $o['burn_sig'] ?? '', $o['burn_at'] ?? 0]] as [$u, $sig, $t]) {
            if ($u <= 0 || !$sig) continue;
            $amt = $u / (10 ** $d); $burnTot += $amt;
            $burns[] = ['t' => (int)$t, 'shy' => round($amt, 2), 'what' => $o['name'] ?? '', 'name' => $players[$o['pid']]['name'] ?? '', 'sig' => $sig];
        }
    }
    //MC 2026-10-13 burns recorded as treasury moves (kind burn) join the list: they were counted nowhere, so the
    //   tracker undercounted every burn made outside a shop sale. Deduped by signature against the order burns above.
    $burnSigs = [];
    foreach ($burns as $x) if (!empty($x['sig'])) $burnSigs[$x['sig']] = 1;
    foreach (load(TREASURY_LOG) ?: [] as $m) {
        if (($m['kind'] ?? '') !== 'burn' || (float)($m['shy'] ?? 0) <= 0) continue;
        if (!empty($m['sig']) && isset($burnSigs[$m['sig']])) continue;
        $burnTot += (float)$m['shy'];
        $burns[] = ['t' => (int)($m['t'] ?? 0), 'shy' => round((float)$m['shy'], 2), 'what' => ($m['note'] ?? '') !== '' ? (string)$m['note'] : 'Treasury burn', 'name' => '', 'sig' => (string)($m['sig'] ?? '')];
    }
    usort($burns, fn($a, $b) => $b['t'] <=> $a['t']);
    // the weekly pools, newest first: the fixed part plus the share of the week before's shop sales
    $pools = [];
    foreach ($rw['weeks'] ?? [] as $wk => $w) $pools[] = ['wk' => $wk, 'week' => (int)explode('-', $wk)[1], 'league' => (float)($w['pool']['total'] ?? 0), 'fromShop' => (float)($w['pool']['share'] ?? 0), 'cup' => (float)($w['cupPool'] ?? 0)];
    usort($pools, fn($a, $b) => strcmp($b['wk'], $a['wk']));
    $now = league_pool_usd();
    $set = eco_settings();
    $mw = mw_address();
    $bal = shy_balance($mw);
    $log = load(TREASURY_LOG);
    $log = is_array($log) ? array_values($log) : [];
    $log = array_values(array_filter($log, fn($x) => !isset($bountySigs[$x['sig'] ?? ''])));   // a bounty paid by hand was also logged as a move
    usort($log, fn($a, $b) => ($b['t'] ?? 0) <=> ($a['t'] ?? 0));
    return [
        'at' => time(),
        'wallet' => ['address' => $mw, 'shy' => $bal ? round($bal['bal']) : null, 'usd' => $bal ? round($bal['usd'], 2) : null],
        'totals' => ['shy' => round($paidShy), 'usd' => round($paidUsd, 2), 'payouts' => count($rows), 'winners' => count($winners), 'weeks' => count($rw['weeks'] ?? [])],
        'now' => ['league' => $now['total'], 'fromShop' => $now['share'], 'cup' => cup_pool_usd(), 'share' => prize_sales() ? (int)prize_cfg('league')['pct'] : (int)$set['league_share'], 'ends' => strtotime('next monday 00:00 UTC')],
        'payouts' => array_slice($rows, 0, 200),
        'pools' => array_slice($pools, 0, 26),
        'moves' => array_slice($log, 0, 100),
        'burns' => ['shy' => round($burnTot), 'n' => count($burns), 'pct' => (int)$set['burn_pct'], 'list' => array_slice($burns, 0, 1000)],   //MC 2026-10-13 the whole history: the tracker pages through it client side
        'founding' => tr_founding(),
    ];
}

$c = load(TREASURY_CACHE);
if (empty($c['at']) || $c['at'] < time() - 300) {
    $c = tr_build();
    with_lock(fn() => save(TREASURY_CACHE, $c));
}
out(['ok' => true] + $c);
