<?php
// Plain-text translation into English, for messages players send the team (ideas and bug reports).
// Uses DeepL when a key is set in shy-data/config.php ('deepl_key', the free plan is plenty), otherwise the free
// MyMemory service ('mymemory_email' raises its daily limit from 5,000 to 50,000 characters).
// tr_lang() guesses the language first, so English never costs a call.
if (!defined('SHY_API')) exit;

const TR_NAMES = ['en' => 'English', 'es' => 'Spanish', 'pt' => 'Portuguese', 'fr' => 'French', 'de' => 'German', 'tr' => 'Turkish', 'ru' => 'Russian',
    'vi' => 'Vietnamese', 'id' => 'Indonesian', 'zh' => 'Chinese', 'ko' => 'Korean', 'fa' => 'Persian', 'ja' => 'Japanese', 'ar' => 'Arabic',
    'it' => 'Italian', 'nl' => 'Dutch', 'pl' => 'Polish', 'uk' => 'Ukrainian', 'hi' => 'Hindi', 'th' => 'Thai'];

// Which language a message is in. The writing system settles most; for Latin text, common words decide,
// and the language the player had the site in breaks a tie. Returns a code from TR_NAMES.
function tr_lang($text, $ui = 'en') {
    $ui = isset(TR_NAMES[$ui]) ? $ui : 'en';
    $letters = preg_replace('/[^\p{L}]+/u', '', $text);
    $n = max(1, mb_strlen($letters));
    $share = fn($re) => preg_match_all($re, $letters) / $n;
    if ($share('/\p{Hangul}/u') > .2) return 'ko';
    if ($share('/[\p{Hiragana}\p{Katakana}]/u') > .1) return 'ja';
    if ($share('/\p{Han}/u') > .2) return 'zh';
    if ($share('/\p{Thai}/u') > .2) return 'th';
    if ($share('/\p{Devanagari}/u') > .2) return 'hi';
    if ($share('/\p{Arabic}/u') > .2) return preg_match('/[پچژگک]/u', $text) || $ui === 'fa' ? 'fa' : 'ar';
    if ($share('/\p{Cyrillic}/u') > .2) return preg_match('/[іїєґ]/iu', $text) ? 'uk' : 'ru';
    if (preg_match_all('/[ăâđêôơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]/iu', $text) >= 3) return 'vi';
    // Latin script: count everyday words of each language
    $words = preg_split('/[^\p{L}\']+/u', mb_strtolower($text), -1, PREG_SPLIT_NO_EMPTY);
    if (!$words) return $ui;
    $common = [
        'en' => 'the and to of is it you that in for this with be on are have would should could game can more when add make like not please',
        'es' => 'el la de que y en los las un una es por para con no se del al lo como más pero juego sería muy cuando',
        'pt' => 'o a de que e em os as um uma é para com não do da no na mais mas jogo seria muito quando você',
        'fr' => 'le la les de des et en un une est pour que qui pas dans sur avec ce il jeu serait plus quand vous',
        'de' => 'der die das und ist nicht ein eine zu mit den dem es ich sie spiel wäre wenn auch noch bitte',
        'tr' => 've bir bu da de için ile çok daha oyun olarak gibi ama ne mi olsun olur değil',
        'id' => 'dan yang di ini itu untuk dengan tidak ada akan bisa dari ke game lebih juga saya kalau',
        'it' => 'il lo la di che e un una è per con non sono gioco sarebbe più ma anche',
        'nl' => 'de het een en is van dat niet op te met voor spel zou meer ook maar',
        'pl' => 'i w na nie to jest się że do z co jak gra by więcej ale',
    ];
    $score = [];
    foreach ($common as $lg => $list) { $set = array_flip(explode(' ', $list)); $score[$lg] = count(array_filter($words, fn($w) => isset($set[$w]))); }
    arsort($score);
    $best = array_key_first($score); $top = $score[$best];
    if ($top === 0) return $ui;
    // a tie with English goes to the language the player had the site in
    if ($best === 'en' && $ui !== 'en' && ($score[$ui] ?? -1) === $top) return $ui;
    return $best;
}

function tr_http($url, $post = null, $headers = []) {
    $ch = curl_init($url);
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => $headers];
    if ($post !== null) { $opt[CURLOPT_POST] = true; $opt[CURLOPT_POSTFIELDS] = $post; }
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    return [$code, $raw === false ? null : json_decode($raw, true)];
}
function tr_log($m) { @file_put_contents(DATA_DIR . '/translate-errors.log', gmdate('c') . ' ' . $m . "\n", FILE_APPEND); }

// English text for $text written in $src, or '' if no service could do it right now
function tr_english($text, $src) {
    if ($src === 'en' || trim($text) === '') return '';
    $c = shy_config();
    if (!empty($c['deepl_key'])) {
        $url = (substr($c['deepl_key'], -3) === ':fx' ? 'https://api-free.deepl.com' : 'https://api.deepl.com') . '/v2/translate';
        [$code, $j] = tr_http($c['deepl_api'] ?? $url, http_build_query(['text' => $text, 'target_lang' => 'EN-US']), ['Authorization: DeepL-Auth-Key ' . $c['deepl_key'], 'Content-Type: application/x-www-form-urlencoded']);
        if ($code === 200 && !empty($j['translations'][0]['text'])) return trim($j['translations'][0]['text']);
        tr_log("deepl $code");   // fall through to MyMemory
    }
    // MyMemory takes up to 500 bytes at a time: send it a paragraph or sentence at a time
    $chunks = []; $cur = '';
    foreach (preg_split('/(?<=[.!?。！？\n])\s*/u', $text, -1, PREG_SPLIT_NO_EMPTY) as $s) {
        while (strlen($s) > 450) { $cut = mb_strcut($s, 0, 450); $chunks[] = $cut; $s = substr($s, strlen($cut)); }
        if (strlen($cur . ' ' . $s) > 450 && $cur !== '') { $chunks[] = $cur; $cur = $s; } else $cur = trim($cur . ' ' . $s);
    }
    if ($cur !== '') $chunks[] = $cur;
    $pair = ($src === 'zh' ? 'zh-CN' : $src) . '|en';
    $out = [];
    foreach (array_slice($chunks, 0, 8) as $q) {
        $p = ['q' => $q, 'langpair' => $pair];
        if (!empty($c['mymemory_email'])) $p['de'] = $c['mymemory_email'];
        [$code, $j] = tr_http(($c['mymemory_api'] ?? 'https://api.mymemory.translated.net/get') . '?' . http_build_query($p));
        $t = (string)($j['responseData']['translatedText'] ?? '');
        if ($code !== 200 || (int)($j['responseStatus'] ?? 0) !== 200 || $t === '' || stripos($t, 'MYMEMORY WARNING') !== false) { tr_log("mymemory $code " . substr(json_encode($j), 0, 200)); return ''; }
        $out[] = html_entity_decode($t, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
    return trim(implode(' ', $out));
}
