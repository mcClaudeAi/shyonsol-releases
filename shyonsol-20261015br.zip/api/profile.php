<?php
// Player profile for wallet-connected players: their stats, ranks, items and purchases, and a name change.
// POST a=me      {pid, key}        -> profile (or linked:false)
// POST a=rename  {pid, key, name}  -> new name

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
if (!defined('DAILY')) define('DAILY', DATA_DIR . '/daily.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 2000) fail('too large');
$body = json_decode($raw, true) ?: [];
//MC 2026-10-12 the profile's All matches list: the history, with boss matches marked and given the Shogun's score where the
//   boss record still has that match (wins keep the last 30), so a share says "12 Regions to 10" instead of just "12 Regions".
//   Matches recorded before the boss flag existed are matched to the boss record by time.
//MC 2026-10-13 hist now carries b and v on boss rows itself (livelib writes them), so vs comes straight from the row.
//   Wins from before that fix never reached hist at all, so they come back from the Shogun's own record instead: a recent
//   row of this player's with no hist row near it in time becomes a shown match. Matching by time alone (not score) was
//   wrong here once hist had real boss rows: a win and a backfilled copy of it would both show.
function profile_games($pid, $p) {
    $out = $p['hist'] ?? [];
    foreach ($out as &$h) if (!empty($h['b']) && isset($h['v'])) $h['vs'] = (int)$h['v'];
    unset($h);
    require_once __DIR__ . '/bosslib.php';
    foreach (load(BOSS_DB)['recent'] ?? [] as $x) {
        if (($x['pid'] ?? '') !== $pid) continue;
        $dup = false;
        foreach ($out as $h) if (abs((int)$x['t'] - (int)($h['t'] ?? 0)) < 120) { $dup = true; break; }
        if (!$dup) $out[] = ['t' => (int)$x['t'], 'm' => 'live', 'r' => 'win', 'g' => (int)$x['r'], 'p' => 0, 'b' => 1, 'vs' => (int)$x['b']];
    }
    usort($out, fn($a, $b) => ($b['t'] ?? 0) <=> ($a['t'] ?? 0));
    return array_slice($out, 0, 55);
}

$a = (string)($body['a'] ?? '');
$pid = (string)($body['pid'] ?? '');
$key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);

// position of $pid in a list sorted by $cmp, or 0 when not on it
function place_in($players, $pid, $keep, $score) {
    $rows = [];
    foreach ($players as $id => $p) if ($keep($p)) $rows[] = [$id, $score($p)];
    usort($rows, fn($x, $y) => $y[1] <=> $x[1]);
    foreach ($rows as $i => $r) if ($r[0] === $pid) return ['rank' => $i + 1, 'of' => count($rows)];
    return ['rank' => 0, 'of' => count($rows)];
}

if ($a === 'me') {
    $res = with_lock(function () use ($pid, $kh) {
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $holders = load(HOLDERS);
        $h = $holders[$pid] ?? null;
        if (empty($h['wallet'])) return ['linked' => false, 'name' => $players[$pid]['name'] ?? ''];
        $p = $players[$pid] ?? ['points' => 0, 'wins' => 0, 'games' => 0, 'best' => 0, 'since' => $h['ts'] ?? time()];
        $wk = week_key();
        $eco = load(ECO);
        $acc = eco_get($eco, $pid);
        $tier = holder_tier($h);
        $own = eco_owned($acc, $tier);
        $eq = [];
        foreach (['title', 'ring', 'frame', 'table', 'fx', 'skin', 'halo'] as $slot) {
            $id = $acc['eq'][$slot] ?? '';
            if ($id && isset($own[$id]) && ($it = eco_item($id))) $eq[$slot] = ['id' => $id, 'name' => $it['name']];
        }
        $daily = load(DAILY);
        $dailies = [];
        foreach ($daily as $day => $list) if (isset($list[$pid])) $dailies[] = ['day' => $day, 'points' => $list[$pid]['points'], 'regions' => $list[$pid]['regions'], 'result' => $list[$pid]['result']];
        $orders = array_values(array_filter(load(ORDERS), fn($o) => $o['pid'] === $pid));
        usort($orders, fn($x, $y) => $y['ts'] <=> $x['ts']);
        $lgNow = ($p['lg']['wk'] ?? '') === $wk ? $p['lg'] : ['pts' => 0, 'n' => 0];
        $lgRows = league_rows($players, $holders, 'league');
        $lgRank = 0;
        foreach ($lgRows as $i => $r) if ($r['pid'] === $pid) { $lgRank = $i + 1; break; }
        $reg = load(SHADOWREG);
        $shadows = array_map(fn($n) => ['n' => (string)$n, 'img' => $reg[$n]['img'] ?? '', 'rank' => $reg[$n]['rank'] ?? null, 'aura' => $reg[$n]['aura'] ?? '',
            'wins' => $reg[$n]['wins'] ?? 0, 'games' => $reg[$n]['games'] ?? 0], array_slice($h['shadows'] ?? [], 0, 12));
        return ['linked' => true, 'profile' => [
            'name' => $p['name'] ?? '', 'locked' => !empty($p['nlock']), 'public' => empty($p['hide']) && !empty($p['games']), 'tag' => substr($pid, 0, 6), 'x' => $p['xu'] ?? '', 'since' => $p['since'] ?? ($h['ts'] ?? time()), 'last' => $p['last'] ?? 0,
            'wallet' => $h['wallet'], 'tier' => $tier, 'shy' => isset($h['shy_bal']) ? ['bal' => $h['shy_bal'], 'usd' => $h['shy_usd'] ?? 0] : null,
            'flaunt' => ['shy' => !empty($p['fl']['shy']), 'koban' => !empty($p['fl']['koban'])],   //MC 2026-10-13 what this holder shows off on their public page
            'next' => holder_next($h), 'nextName' => ($nx = holder_next($h)) ? HOLDER_NAMES[$nx['tier']] : '',   //MC 2026-10-10 the next rank and how far it is
            'tierName' => HOLDER_NAMES[$tier] ?? '', 'tierAt' => isset(eco_settings()['htiers'][$tier]) ? (float)eco_settings()['htiers'][$tier] : 0,   //MC 2026-10-10 for the rank badge and its progress bar
            'shadows' => $shadows, 'avatar' => $p['avatar'] ?? '',
            'stats' => ['points' => $p['points'] ?? 0, 'games' => $p['games'] ?? 0, 'wins' => $p['wins'] ?? 0, 'best' => $p['best'] ?? 0,
                'live_g' => $p['pvp_g'] ?? 0, 'live_w' => $p['pvp_w'] ?? 0, 'week' => ($p['wk'] ?? '') === $wk ? ($p['wpts'] ?? 0) : 0, 'badges' => $p['badges'] ?? 0],
            'ranks' => [
                //MC 2026-10-09 added the last tiebreak (fewer games) so this matches lb.php board() and the public page in player.php
                'all' => place_in($players, $pid, fn($x) => !empty($x['games']), fn($x) => [$x['points'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]),
                'week' => place_in($players, $pid, fn($x) => ($x['wk'] ?? '') === $wk && !empty($x['wpts']), fn($x) => [$x['wpts'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]),
                'live' => place_in($players, $pid, fn($x) => !empty($x['pvp_g']), fn($x) => [$x['lpts'] ?? 0, $x['pvp_w'] ?? 0, -($x['pvp_g'] ?? 0)]),
                'league' => ['rank' => $lgRank, 'of' => count($lgRows)]],
            'league' => ['pts' => $lgNow['pts'] ?? 0, 'n' => $lgNow['n'] ?? 0, 'min' => eco_settings()['min_games']],
            'eco' => ['koban' => $acc['koban'], 'streak' => $acc['st'], 'scroll' => ['tier' => intdiv($acc['sc']['xp'], TIER_XP), 'xp' => $acc['sc']['xp'], 'of' => SCROLL_TIERS, 'prem' => $acc['sc']['prem'], 'season' => season_no()],
                'owned' => count($own), 'eq' => $eq, 'col' => collection_show($acc), 'page' => page_public($acc, $tier), 'spent' => $acc['spent_usd'] ?? 0, 'ledger' => array_slice($acc['ledger'], 0, 30)],
            'games' => profile_games($pid, $p), 'dailies' => $dailies,
            'orders' => array_map('order_row', array_slice($orders, 0, 30))]];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

// keep the public page (shyonsol.io/p/name) private, or show it again
if ($a === 'public') {
    $hide = empty($body['on']);
    $res = with_lock(function () use ($pid, $kh, $hide) {
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players) || !isset($players[$pid])) return ['err' => 'not your profile', 'code' => 403];
        if ($hide) $players[$pid]['hide'] = 1; else unset($players[$pid]['hide']);
        save(PLAYERS, $players);
        return ['on' => !$hide];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

//MC 2026-10-13 flaunt: a holder can show their $SHY held and Koban on their public page, off by default. Balances are
//   kept private everywhere else on purpose (player.php even hides the gap to the next rank), so showing one is a choice
//   the holder makes themselves, and only holders get the switch.
if ($a === 'flaunt') {
    $res = with_lock(function () use ($pid, $kh, $body) {
        $players = load(PLAYERS);
        $holders = load(HOLDERS);
        if (!isset($players[$pid]) || !key_ok($pid, $kh, $players, $holders)) return ['err' => 'Not your profile.', 'code' => 403];
        if (empty($holders[$pid]['wallet'])) return ['err' => 'Connect a wallet with $SHY first. Flaunting is for holders.', 'code' => 403];
        $fl = [];
        if (!empty($body['shy'])) $fl['shy'] = 1;
        if (!empty($body['koban'])) $fl['koban'] = 1;
        if ($fl) $players[$pid]['fl'] = $fl; else unset($players[$pid]['fl']);
        save(PLAYERS, $players);
        return ['flaunt' => ['shy' => !empty($fl['shy']), 'koban' => !empty($fl['koban'])]];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

if ($a === 'rename') {
    $raw = (string)($body['name'] ?? '');
    $name = clean_name($raw);
    if ($name === null) fail(name_problem($raw));
    $res = with_lock(function () use ($pid, $kh, $name) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'rename:' . $pid, 6, 86400)) { save(LIMITS, $limits); return ['err' => 'That is a lot of name changes for one day. Try again tomorrow.', 'code' => 429]; }
        save(LIMITS, $limits);
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $holders = load(HOLDERS);
        if (empty($holders[$pid]['wallet'])) return ['err' => 'Connect your wallet to change your name here.', 'code' => 403];
        if (!empty($players[$pid]['nlock'])) return ['err' => 'An admin set this name, so it can\'t be changed here. Ask in Telegram if you need it changed.', 'code' => 403];
        foreach ($players as $id => $p) if ($id !== $pid && strcasecmp($p['name'] ?? '', $name) === 0) return ['err' => 'That name is taken. Try another.', 'code' => 409];
        // the profile name wins over old names saved on other devices; a profile with no games yet gets a record to hold it
        if (!isset($players[$pid])) $players[$pid] = blank_player($kh);
        $players[$pid]['name'] = $name; $players[$pid]['nprof'] = time();
        save(PLAYERS, $players);
        return ['name' => $name];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

//MC 2026-10-14 a=hype {pid, key, seed}: three ready-to-post lines about this player, one per angle (the record, the
//   signature card, the climb), each with the landing link X unfurls their hype card from (/h/<tag>-<v>, hypepage.php).
//   The seed only shuffles the wording, so Refresh gets new lines without drawing new pictures. The post goes out from
//   the player's own X through the intent link, the same free path the match shares use; nothing is posted from here.
if ($a === 'hype') {
    $seed = abs((int)($body['seed'] ?? 0));
    if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
    require_once __DIR__ . '/engine.php';
    $res = with_lock(function () use ($pid, $kh) {
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $p = $players[$pid] ?? [];
        if (($p['name'] ?? '') === '') return ['ready' => false, 'why' => 'name'];
        if (empty($p['games'])) return ['ready' => false, 'why' => 'games'];
        if (!empty($p['hide'])) return ['ready' => false, 'why' => 'private'];
        $eco = load(ECO);
        $acc = isset($eco[$pid]) ? eco_get($eco, $pid) : null;
        $tier = holder_tier(load(HOLDERS)[$pid] ?? null);
        $rank = place_in($players, $pid, fn($x) => !empty($x['games']), fn($x) => [$x['points'] ?? 0, $x['wins'] ?? 0, -($x['games'] ?? 0)]);
        // the card they're known for, with the same precedence as the profile share card: showcase first, then most played
        $card = ''; $plays = 0;
        $pg = $acc ? page_public($acc, $tier) : [];
        if (!empty($pg['show'][0]['id'])) $card = (string)$pg['show'][0]['id'];
        elseif ($acc && !empty($acc['cm'])) { $cm = $acc['cm']; arsort($cm); $card = (string)array_key_first($cm); $plays = (int)reset($cm); }
        if ($card !== '' && !isset(CARDS[$card])) $card = '';
        return ['p' => $p, 'rank' => $rank, 'card' => $card, 'plays' => $plays,
            'week' => ($p['wk'] ?? '') === week_key() ? (int)($p['wpts'] ?? 0) : 0,
            'streak' => $acc ? (int)($acc['st']['n'] ?? 0) : 0];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    if (isset($res['ready'])) out(['ok' => true] + $res);
    $p = $res['p'];
    $pts = (int)($p['points'] ?? 0); $wins = (int)($p['wins'] ?? 0); $games = (int)($p['games'] ?? 0); $best = (int)($p['best'] ?? 0);
    $wr = $games ? round($wins / $games * 100) : 0;
    $Npts = number_format($pts); $Nwins = number_format($wins); $Ngames = number_format($games);
    $rank = (int)$res['rank']['rank']; $of = (int)$res['rank']['of']; $Nrank = number_format($rank); $Nof = number_format($of);
    $card = $res['card'] !== '' ? (string)CARDS[$res['card']]['name'] : '';
    $plays = (int)$res['plays']; $week = (int)$res['week']; $streak = (int)$res['streak'];
    $pick = fn(array $all, $salt) => $all[($seed + $salt) % count($all)];
    // the record, and never a brag about zero wins
    $s1 = $wins > 0 ? [
        "My Shilluminati record so far: $Npts points, $Nwins wins, $wr% win rate. The table remembers everything.",
        "$Ngames games into Shilluminati Online and the ledger reads $Npts points, $Nwins wins. Numbers do the talking.",
        "Win rate $wr% over $Ngames games of Shilluminati. Come change my numbers if you can.",
        "Some people collect tokens. I collect wins: $Nwins and counting in Shilluminati Online.",
    ] : [
        "$Ngames games deep into Shilluminati Online, $Npts points on the board, and the first big win is loading.",
        "New blood at the Shilluminati table: $Npts points in my first $Ngames games. The board will learn my name.",
    ];
    if ($best >= 15) $s1[] = "My best Shilluminati game ended with $best of 40 Regions under my name. The table remembers nights like that.";
    // the signature card
    $s2 = $card !== '' ? [
        "Every Shilluminati player ends up with a signature card. Mine is $card. Ask the last table I sat at.",
        $plays > 1 ? number_format($plays) . " games with $card in hand. At this point it plays itself." : "The deck has 71 hand-inked cards. Mine has one that matters: $card.",
        "You can tell a lot about a player by the card they reach for. I reach for $card.",
    ] : ["I hold a seat at the Shilluminati table: 71 hand-inked cards, live matches and a weekly league. Come find me there."];
    // the climb
    $s3 = [];
    if ($rank > 0) {
        $s3[] = "#$Nrank of $Nof all time in Shilluminati Online, and the climb is not done.";
        $s3[] = "Climbing the Shilluminati board one Region at a time: #$Nrank of $Nof and rising.";
    }
    if ($week > 0) $s3[] = number_format($week) . " points on the Shilluminati board this week, and the week is not over.";
    if ($streak > 1) $s3[] = "Day $streak of my Shilluminati streak. The table keeps pulling me back.";
    if (!$s3) $s3[] = "New name on the Shilluminati board. Watch it climb.";
    //MC 2026-10-14 every post carries exactly three accounts: the game, @ShytoshiKusama, and one from the admin's Solana
    //   gaming list (the same list the admin hype console edits, eco settings mkt_x_tags; the default mirrors
    //   admin/marketing.php MKT_DEFAULT_TAGS). The seed rotates which gaming account each option gets.
    $chal = ['Think you can take a Region off me?', 'Pull up a chair.', 'Easy to learn. Expensive to beat.', 'The table is open.'];
    $gl = [];
    foreach (preg_split('/[\r\n,]+/', (string)(eco_settings()['mkt_x_tags'] ?? "@solana\n@SolanaMobile\n@MagicEden\n@SuperteamDAO\n@StarAtlas\n@Backpack")) as $t) {
        $t = '@' . ltrim(trim($t), '@');
        if (preg_match('/^@[A-Za-z0-9_]{1,15}$/', $t) && strcasecmp($t, '@ShytoshiKusama') !== 0 && strcasecmp($t, '@ShyOnSol_') !== 0) $gl[] = $t;
    }
    $gl = array_values(array_unique($gl));
    preg_match_all('/[#$][A-Za-z][A-Za-z0-9_]{0,30}/', (string)(eco_settings()['x_tags'] ?? ''), $mm);
    $tags = array_slice(array_values(array_unique($mm[0])), 0, 5);
    $finish = function ($t, $salt) use ($pick, $chal, $tags, $gl) {
        $t .= "\n\n" . $pick($chal, $salt) . ' Play free with @ShyOnSol_ @ShytoshiKusama';
        if ($gl) $t .= ' ' . $pick($gl, $salt * 7 + 1);
        foreach ($tags as $tg) if (stripos($t, $tg) === false && strlen($t) + strlen($tg) + 1 < 240) $t .= ' ' . $tg;
        return $t;
    };
    $tag = substr($pid, 0, 6);
    $hh = substr(sha1($pts . '|' . $wins . '|' . $games . '|h1'), 0, 8);
    $posts = [];
    foreach ([1 => $s1, 2 => $s2, 3 => $s3] as $v => $set) $posts[] = ['v' => $v, 't' => $finish($pick($set, $v), $v + 3),
        'img' => 'api/share.php?hp=' . $tag . '&v=' . $v . '&r=' . $hh,
        'url' => 'https://shyonsol.io/h/' . $tag . '-' . $v . '?r=' . $hh];
    out(['ok' => true, 'ready' => true, 'seed' => $seed, 'posts' => $posts]);
}

fail('unknown action');
