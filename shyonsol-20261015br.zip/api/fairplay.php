<?php
//MC 2026-10-10 Fair Play: every finished live match is kept (rooms delete themselves after 3 hours), with who sat where,
//   what each seat actually did, who attacked whom, and a salted hash of each player's network and browser. Nothing here
//   can identify a person on its own; it only tells the admin when two accounts look like the same player.
//   Records are one JSON line per match in fairplay/YYYY-MM.jsonl, so a busy night never rewrites a big file.
if (!defined('SHY_API')) { http_response_code(404); exit; }   //MC 2026-10-11 an include, not a page (opened directly it failed with a 500)
if (!defined('FP_DIR')) define('FP_DIR', DATA_DIR . '/fairplay');

function fp_net() { return substr(client_ip(), 0, 10); }
function fp_dev() { return substr(hash('sha256', 'shy-dev:' . ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '')), 0, 8); }
// called on every request a seat makes: remembers up to 4 networks and 4 browsers per seat
function fp_seen(&$seat) {
    $n = fp_net(); $d = fp_dev();
    if (!isset($seat['fpn'][$n]) && count($seat['fpn'] ?? []) < 4) $seat['fpn'][$n] = 1;
    if (!isset($seat['fpd'][$d]) && count($seat['fpd'] ?? []) < 4) $seat['fpd'][$d] = 1;
}
function fp_settings() {
    $s = is_file(FP_DIR . '/settings.php') ? load(FP_DIR . '/settings.php') : [];
    return $s + ['priv_league' => 1];
}
// private rooms count for the League unless the admin switched that off
function fp_priv_league() { return !empty(fp_settings()['priv_league']); }

// one finished match as a record. $res and $awards are end_game's, or null for a room imported after the fact.
function fp_from_room($room, $res = null, $awards = null) {
    $g = $room['g'] ?? [];
    $seats = [];
    foreach ($room['seats'] ?? [] as $i => $s) {
        $r = $res[$i] ?? ($room['result']['seats'][$i] ?? []);
        $seats[] = ['pid' => (string)($s['pid'] ?? ''), 'name' => (string)($s['name'] ?? ''), 'h' => !empty($s['human']) ? 1 : 0,
            'away' => !empty($s['away']) ? 1 : 0, 'gone' => !empty($s['gone']) ? 1 : 0,
            'reg' => count($g['players'][$i]['regions'] ?? []), 'hand' => count($g['players'][$i]['hand'] ?? []),
            'res' => (string)($r['result'] ?? ''), 'pts' => (int)($r['points'] ?? 0),
            'lg' => (int)($awards[$i]['league'] ?? ($room['result']['seats'][$i]['league'] ?? 0)),
            'acts' => (int)($room['fpt'][$i] ?? 0), 'cards' => count($room['pc'][$i] ?? []),
            'att' => (object)($room['fpa'][$i] ?? []), 'net' => array_keys($s['fpn'] ?? []), 'dev' => array_keys($s['fpd'] ?? []),
            'seen' => (int)($s['seen'] ?? 0)];
    }
    // an imported room has no attack counts: read what the log still holds ("X plays Card on Name")
    if ($res === null) {
        $byName = []; foreach ($seats as $i => $s) $byName[$s['name']] = $i;
        $att = [];
        foreach ($g['log'] ?? [] as $e) if (($e['kind'] ?? '') === 'play' && preg_match('/ on (.+)\.$/', (string)($e['text'] ?? ''), $m) && isset($byName[$m[1]]) && isset($e['who']) && $e['who'] !== $byName[$m[1]]) $att[$e['who']][$byName[$m[1]]] = ($att[$e['who']][$byName[$m[1]]] ?? 0) + 1;
        foreach ($att as $i => $a) if (isset($seats[$i])) { $seats[$i]['att'] = (object)$a; $seats[$i]['part'] = 1; }
    }
    $hum = count(array_filter($seats, fn($s) => $s['h']));
    return ['c' => (string)($room['code'] ?? ''), 's' => (int)($room['created'] ?? 0), 'e' => (int)($room['ended'] ?? time()),
        'pub' => !empty($room['public']) ? 1 : 0, 'tny' => !empty($room['tourney']) ? 1 : 0, 'hum' => $hum,
        'wk' => week_key(), 'sn' => function_exists('season_no') ? season_no() : 0, 'imp' => $res === null ? 1 : 0, 'seats' => $seats];
}
function fp_write($rec) {
    if (!is_dir(FP_DIR)) @mkdir(FP_DIR, 0755, true);
    @file_put_contents(FP_DIR . '/' . gmdate('Y-m', $rec['e'] ?: time()) . '.jsonl', json_encode($rec, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX);
}
// matches with at least one real player, from end_game
function fp_record($room, $res, $awards) {
    if (count(array_filter($room['seats'] ?? [], fn($s) => !empty($s['human']))) < 1) return;
    $rec = fp_from_room($room, $res, $awards);
    fp_write($rec);
    try { fp_watch($rec); } catch (Throwable $e) {}   //MC 2026-10-12 farming check, see below
}

//MC 2026-10-12 Farming watch. After every live match with two or more real players, each winner is checked against each
//   real rival at the table for the signs MrvRhnShy showed in week 41 (two alt accounts handing him 665 League points):
//     same network or device, a rival who barely moved, a brand new rival who only ever plays this player, the same pair
//     over and over with one side winning nearly every time, and names cut from the same letters.
//   Signs add up to a score; at 4 or more the whole team gets an email (the alert list in Admin > Team > Emails, plus every
//   admin with an email on their account) with what was seen and a link to the Fair Play page. One email per pair per day.
//   Nothing is changed in the game: the team decides (strike the matches, ban the alt). The last 50 flags are kept for the
//   Fair Play page.
define('FP_FLAGS', FP_DIR . '/flags.php');
function fp_name_link($a, $b) {
    $a = strtolower(preg_replace('/[^a-z]/i', '', $a)); $b = strtolower(preg_replace('/[^a-z]/i', '', $b));
    if (strlen($a) < 3 || strlen($b) < 3) return '';
    for ($i = 0; $i + 3 <= strlen($a); $i++) { $chunk = substr($a, $i, 3); if (strpos($b, $chunk) !== false && !in_array($chunk, ['shy', 'the', 'and', 'bot', 'man', 'eth', 'sol'], true)) return $chunk; }
    return '';
}
function fp_watch($rec) {
    $hum = array_values(array_filter($rec['seats'], fn($s) => $s['h'] && $s['pid'] !== ''));
    if (count($hum) < 2) return;
    $players = load(PLAYERS); $recent = null; $now = time(); $flags = [];
    foreach ($hum as $w) {
        if ($w['res'] !== 'win') continue;
        foreach ($hum as $o) {
            if ($o['pid'] === $w['pid']) continue;
            $why = []; $score = 0;
            $net = array_intersect($w['net'], $o['net']); $dev = array_intersect($w['dev'], $o['dev']);
            if ($dev) { $score += 3; $why[] = 'They played from the same device (same browser fingerprint).'; }
            if ($net) { $score += 2; $why[] = 'They played from the same network (same internet connection).'; }
            if ($o['away'] || $o['gone']) { $score += 2; $why[] = $o['name'] . ' left or went idle during the match.'; }
            elseif ($o['acts'] <= 2 && $w['acts'] >= 6) { $score += 2; $why[] = $o['name'] . ' made only ' . $o['acts'] . ($o['acts'] === 1 ? ' move' : ' moves') . ', against ' . $w['acts'] . ' for the winner.'; }
            $op = $players[$o['pid']] ?? [];
            $recent = $recent ?? fp_load(7);
            $pair = 0; $pairW = 0; $oAll = 0;
            foreach ($recent as $r) {
                $ids = array_column(array_filter($r['seats'], fn($s) => $s['h']), 'res', 'pid');
                if (isset($ids[$o['pid']])) $oAll++;
                if (isset($ids[$o['pid']], $ids[$w['pid']])) { $pair++; if ($ids[$w['pid']] === 'win') $pairW++; }
            }
            if (($now - (int)($op['since'] ?? $now)) < 3 * 86400 && $oAll >= 2 && $pair / max(1, $oAll) >= 0.7) { $score += 2; $why[] = $o['name'] . ' is a new account (' . max(1, (int)round(($now - (int)($op['since'] ?? $now)) / 3600)) . ' hours old) and ' . $pair . ' of its ' . $oAll . ' matches were against ' . $w['name'] . '.'; }
            if ($pair >= 5 && $pairW / $pair >= 0.8) { $score += 2; $why[] = 'They have played each other ' . $pair . ' times this week and ' . $w['name'] . ' won ' . $pairW . '.'; }
            if ($ch = fp_name_link($w['name'], $o['name'])) { $score += 1; $why[] = 'Their names share "' . $ch . '".'; }
            if ($score >= 4) $flags[] = ['t' => $now, 'w' => $w['pid'], 'wn' => $w['name'], 'o' => $o['pid'], 'on' => $o['name'], 'score' => $score, 'why' => $why, 'c' => $rec['c'], 'lg' => (int)$w['lg'], 'pair' => $pair];
        }
    }
    if (!$flags) return;
    $mail = [];
    fp_flag_lock(function () use ($flags, &$mail) {
        $d = load(FP_FLAGS); $d += ['list' => [], 'sent' => []];
        $day = gmdate('Y-m-d');
        foreach ($flags as $f) {
            $d['list'][] = $f;
            $k = $f['w'] . ':' . $f['o'] . ':' . $day;
            if (empty($d['sent'][$k])) { $d['sent'][$k] = 1; $mail[] = $f; }
        }
        $d['list'] = array_slice($d['list'], -50);
        $d['sent'] = array_filter($d['sent'], fn($k) => substr($k, -10) >= gmdate('Y-m-d', time() - 7 * 86400), ARRAY_FILTER_USE_KEY);
        save(FP_FLAGS, $d);
    });
    foreach ($mail as $f) fp_alert_mail($f);
}
function fp_flag_lock($fn) { $lf = @fopen(FP_DIR . '/flags.lock', 'c'); if (!$lf) return $fn(); flock($lf, LOCK_EX); try { return $fn(); } finally { flock($lf, LOCK_UN); fclose($lf); } }
// the whole team: the alert list plus every admin account with an email
function fp_team_emails() {
    $to = function_exists('mail_cfg') ? mail_cfg()['to'] : [];
    foreach (load(DATA_DIR . '/admins.php') as $u) if (is_array($u) && filter_var($u['email'] ?? '', FILTER_VALIDATE_EMAIL) && empty($u['off'])) $to[] = strtolower($u['email']);
    return array_values(array_unique(array_map('strtolower', $to)));
}
function fp_alert_mail($f) {
    if (!function_exists('mail_alert')) return;
    if (!mail_on('fairplay')) return;   //MC 2026-10-12 who gets it is picked in Admin > Emails (everyone with an email until then)
    $site = function_exists('mail_site') ? mail_site() : 'https://shyonsol.io';
    $lines = implode('', array_map(fn($x) => '<li>' . htmlspecialchars($x, ENT_QUOTES) . '</li>', $f['why']));
    mail_alert('fairplay', '⚠️ Possible League farming: ' . $f['wn'] . ' and ' . $f['on'], 'Fair Play', $f['wn'] . ' may be farming League points',
        'The farming check flagged a live match (' . htmlspecialchars($f['c'], ENT_QUOTES) . '). Nothing was changed in the game. Look at their matches, then strike the ones that shouldn\'t count and ban any alt account.',
        [['h' => 'What the check saw'], ['p' => '<ul style="margin:0;padding-left:18px">' . $lines . '</ul>'],
         ['facts' => [['Winner', htmlspecialchars($f['wn'], ENT_QUOTES)], ['Rival', htmlspecialchars($f['on'], ENT_QUOTES)], ['League points from this match', number_format($f['lg'])], ['Matches together this week', (string)$f['pair']], ['How strong the signs are', $f['score'] . ' (4 or more sends this email)']]]],
        [['Open in Fair Play', $site . '/admin/?tab=fairplay&q=' . rawurlencode($f['w']) . '#fp-m']]);
}
// every record of the last $days days, newest first, keyed by room code (a code can come back later, so code+end)
function fp_load($days = 30) {
    $out = []; $from = time() - $days * 86400;
    //MC 2026-10-11 every month from the first day asked for to now. It read only the first and the current month, so the
    //   90-day view skipped the two in between.
    $months = []; $y = (int)gmdate('Y', $from); $mo = (int)gmdate('n', $from);
    while (sprintf('%04d-%02d', $y, $mo) <= gmdate('Y-m') && count($months) < 40) { $months[] = sprintf('%04d-%02d', $y, $mo); if (++$mo > 12) { $mo = 1; $y++; } }
    foreach ($months as $m) {
        $f = FP_DIR . '/' . $m . '.jsonl';
        if (!is_file($f)) continue;
        foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ln) {
            $r = json_decode($ln, true);
            if (!is_array($r) || ($r['e'] ?? 0) < $from) continue;
            $out[$r['c'] . ':' . $r['e']] = $r;
        }
    }
    uasort($out, fn($a, $b) => $b['e'] <=> $a['e']);
    return $out;
}
// finished rooms still on disk that aren't recorded yet (matches from before this release, or ones that ended while it
// was being uploaded): kept now, before the 3 hour clean-up takes them
function fp_import_rooms($have) {
    if (!defined('ROOMS') || !is_dir(ROOMS)) return 0;
    $codes = []; foreach ($have as $r) $codes[$r['c'] . ':' . $r['e']] = 1;
    $n = 0;
    foreach (glob(ROOMS . '/*.php') as $f) {
        $room = load($f);
        if (($room['status'] ?? '') !== 'over' || empty($room['ended'])) continue;
        $room['code'] = $room['code'] ?? basename($f, '.php');
        if (isset($codes[$room['code'] . ':' . (int)$room['ended']])) continue;
        if (count(array_filter($room['seats'] ?? [], fn($s) => !empty($s['human']))) < 1) continue;
        fp_write(fp_from_room($room)); $n++;
    }
    return $n;
}
function fp_struck() { return is_file(FP_DIR . '/struck.php') ? load(FP_DIR . '/struck.php') : []; }

// pairs of real players who sat together, with everything that makes a pair look like one person
function fp_pairs($recs, $players) {
    $P = [];
    foreach ($recs as $k => $r) {
        $hum = array_values(array_filter(array_keys($r['seats']), fn($i) => $r['seats'][$i]['h'] && $r['seats'][$i]['pid'] !== ''));
        for ($x = 0; $x < count($hum); $x++) for ($y = $x + 1; $y < count($hum); $y++) {
            $a = $r['seats'][$hum[$x]]; $b = $r['seats'][$hum[$y]]; $ia = $hum[$x]; $ib = $hum[$y];
            if (strcmp($a['pid'], $b['pid']) > 0) { [$a, $b] = [$b, $a]; [$ia, $ib] = [$ib, $ia]; }
            $id = $a['pid'] . '|' . $b['pid'];
            $p = &$P[$id];
            $p = $p ?? ['a' => $a['pid'], 'b' => $b['pid'], 'n' => 0, 'priv' => 0, 'wa' => 0, 'wb' => 0, 'ab' => 0, 'ba' => 0, 'net' => 0, 'dev' => 0, 'lga' => 0, 'lgb' => 0, 'keys' => []];
            $p['n']++; if (!$r['pub']) $p['priv']++;
            if ($a['res'] === 'win') $p['wa']++; if ($b['res'] === 'win') $p['wb']++;
            $p['ab'] += (int)(((array)$a['att'])[$ib] ?? 0); $p['ba'] += (int)(((array)$b['att'])[$ia] ?? 0);
            if (array_intersect($a['net'] ?? [], $b['net'] ?? [])) $p['net']++;
            if (array_intersect($a['dev'] ?? [], $b['dev'] ?? [])) $p['dev']++;
            $p['lga'] += $a['lg']; $p['lgb'] += $b['lg'];
            $p['keys'][] = $k;
            if (!empty($r['imp'])) $p['imp'] = 1;   // attack counts for imported matches come from the end of the log only
            unset($p);
        }
    }
    // how many multi-player matches each account played at all, to tell "always together" from "met a few times"
    $multi = [];
    foreach ($recs as $r) if ($r['hum'] >= 2) foreach ($r['seats'] as $s) if ($s['h'] && $s['pid'] !== '') $multi[$s['pid']] = ($multi[$s['pid']] ?? 0) + 1;
    foreach ($P as &$p) {
        $f = []; $score = 0;
        $onlyA = $p['n'] / max(1, $multi[$p['a']] ?? 1); $onlyB = $p['n'] / max(1, $multi[$p['b']] ?? 1);
        if ($p['dev']) { $f[] = 'Same browser and network in ' . $p['dev'] . ' of ' . $p['n']; $score += 6; }
        elseif ($p['net']) { $f[] = 'Same network in ' . $p['net'] . ' of ' . $p['n']; $score += 3; }
        if ($p['n'] >= 2 && $p['ab'] + $p['ba'] === 0) { $f[] = 'Never attacked each other'; $score += 2; }
        if ($p['n'] >= 2 && $p['priv'] === $p['n']) { $f[] = 'Only private rooms'; $score += 1; }
        if ($p['n'] >= 2 && ($p['wa'] === 0 || $p['wb'] === 0) && $p['wa'] + $p['wb'] >= 2) { $f[] = 'Always the same winner'; $score += 1; }
        if (max($onlyA, $onlyB) >= 0.8 && $p['n'] >= 2) { $f[] = 'One of them plays real people almost only with the other'; $score += 2; }
        foreach (['a', 'b'] as $w) { $since = (int)($players[$p[$w]]['since'] ?? 0); if ($since && time() - $since < 14 * 86400 && ($players[$p[$w]]['games'] ?? 0) < 20) { $f[] = fp_name($players, $p[$w]) . ' is a new account with few games'; $score += 1; } }
        $p['flags'] = $f; $p['score'] = $score;
    }
    unset($p);
    uasort($P, fn($x, $y) => [$y['score'], $y['n']] <=> [$x['score'], $x['n']]);
    return $P;
}
function fp_name($players, $pid) { return (string)($players[$pid]['name'] ?? substr($pid, 0, 6)); }
// a seat that walked out of one match while it sat in another at the same time
function fp_overlaps($recs) {
    $by = [];
    foreach ($recs as $k => $r) foreach ($r['seats'] as $s) if ($s['h'] && $s['pid'] !== '') $by[$s['pid']][] = [$k, $r['s'], $r['e'], $s['gone'] || $s['away']];
    $out = [];
    foreach ($by as $pid => $list) {
        foreach ($list as $x) foreach ($list as $y) {
            if ($x[0] === $y[0] || !$x[3] || $y[3]) continue;
            if ($x[1] < $y[2] && $y[1] < $x[2]) $out[] = ['pid' => $pid, 'left' => $x[0], 'in' => $y[0]];
        }
    }
    return $out;
}
// take a match's League points back from everyone who got them (inside with_lock)
function fp_strike($key, $by) {
    $recs = fp_load(60); $r = $recs[$key] ?? null;
    if (!$r) return 'That match isn\'t in the Fair Play records.';
    $st = fp_struck();
    if (isset($st[$key])) return 'That match was already struck.';
    $pl = load(PLAYERS); $took = [];
    foreach ($r['seats'] as $s) {
        if (!$s['h'] || $s['pid'] === '' || $s['lg'] <= 0 || !isset($pl[$s['pid']])) continue;
        $p = &$pl[$s['pid']];
        if (($p['lg']['wk'] ?? '') === $r['wk']) { $p['lg']['pts'] = max(0, $p['lg']['pts'] - $s['lg']); $p['lg']['n'] = max(0, ($p['lg']['n'] ?? 1) - 1); }
        if (($p['sg']['s'] ?? 0) === $r['sn']) { $p['sg']['pts'] = max(0, $p['sg']['pts'] - $s['lg']); $p['sg']['n'] = max(0, ($p['sg']['n'] ?? 1) - 1); }
        unset($p);
        $took[] = $s['name'] . ' -' . $s['lg'];
    }
    save(PLAYERS, $pl);
    //MC 2026-10-12 a match from a week that's already final: the frozen results are corrected too (they used to keep the
    //   points, so a strike after Monday 00:00 UTC changed nothing that was paid out). See league_week_rebuild().
    $wkNote = '';
    $rw = load(REWARDS);
    if ($took && isset($rw['weeks'][$r['wk']])) {
        foreach ($r['seats'] as $s) if ($s['h'] && $s['pid'] !== '' && $s['lg'] > 0) league_week_adjust($rw, $r['wk'], substr($s['pid'], 0, 6), $s['lg'], 1, 'match ' . $r['c'] . ' struck by ' . $by);
        $rb = league_week_rebuild($rw, $r['wk'], $pl);
        $wkNote = ' Week ' . (int)substr($r['wk'], 5) . ' was already final: ' . ($rb['ok'] ? 'its results are corrected. ' . $rb['msg'] . ' Post the corrected results from Admin > Rewards.' : $rb['msg']);
        if ($rb['ok']) save(REWARDS, $rw);
    }
    $st[$key] = ['by' => $by, 'at' => time(), 'took' => $took];
    if (!is_dir(FP_DIR)) @mkdir(FP_DIR, 0755, true);
    save(FP_DIR . '/struck.php', $st);
    @unlink(DATA_DIR . '/cache-rewards.php');
    return $took ? 'Struck from the League: ' . implode(', ', $took) . ' League points.' . $wkNote : 'Marked as struck. Nobody had League points from it.';
}

//MC 2026-10-10 Fair Play rules: which of the other real players at the table count as a real rival for seat $i.
//   Nobody counts if they left (the game played their seat), shares this player's network AND browser, already gave this
//   player today's League matches (the pair cap), or is a new account. A match needs one real rival to count for the League,
//   for Ranked and for the +20 per rival. Each rule has its own switch on the Fair Play page. Tournaments are left alone.
function fp_rules() {
    $s = fp_settings();
    return ['left' => (int)($s['r_left'] ?? 1), 'same' => (int)($s['r_same'] ?? 1), 'pair' => (int)($s['r_pair'] ?? 3), 'new' => (int)($s['r_new'] ?? 10)];
}
// returns [seat => ['ok' => [rival seats], 'why' => reason when none]]  ($players is the board before this match is added)
function fp_rivals($room, $players) {
    $R = fp_rules(); $out = []; $d = today();
    $acted = isset($room['fpt']);   // older test rooms carry no move counts
    $left = function ($j) use ($room, $acted) {
        $s = $room['seats'][$j];
        return !empty($s['gone']) || !empty($s['away']) || ($acted && (int)($room['fpt'][$j] ?? 0) === 0);
    };
    foreach ($room['seats'] as $i => $si) {
        if (empty($si['human']) || empty($si['pid'])) continue;
        $ok = []; $why = '';
        foreach ($room['seats'] as $j => $sj) {
            if ($j === $i || empty($sj['human']) || empty($sj['pid']) || $sj['pid'] === $si['pid']) continue;
            if (!empty($room['tourney'])) { $ok[] = $j; continue; }
            if ($R['left'] && $left($j)) { $why = $why ?: 'left'; continue; }
            if ($R['same'] && array_intersect(array_keys($si['fpn'] ?? []), array_keys($sj['fpn'] ?? [])) && array_intersect(array_keys($si['fpd'] ?? []), array_keys($sj['fpd'] ?? []))) { $why = 'same'; continue; }
            if ($R['new'] > 0 && (int)($players[$sj['pid']]['games'] ?? 0) < $R['new']) { $why = $why === 'same' ? $why : 'new'; continue; }
            $pc = $players[$si['pid']]['lgp'] ?? [];
            if ($R['pair'] > 0 && ($pc['d'] ?? '') === $d && (int)($pc['c'][$sj['pid']] ?? 0) >= $R['pair']) { $why = in_array($why, ['same', 'new'], true) ? $why : 'pair'; continue; }
            $ok[] = $j;
        }
        $out[$i] = ['ok' => $ok, 'why' => $ok ? '' : $why];
    }
    return $out;
}
// after a match counted: one more for each real rival today (feeds the pair cap)
function fp_pair_count(&$p, $room, $rivals) {
    $d = today();
    if (($p['lgp']['d'] ?? '') !== $d) $p['lgp'] = ['d' => $d, 'c' => []];
    foreach ($rivals as $j) { $o = (string)($room['seats'][$j]['pid'] ?? ''); if ($o !== '') $p['lgp']['c'][$o] = ($p['lgp']['c'][$o] ?? 0) + 1; }
}
