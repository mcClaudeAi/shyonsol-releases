<?php
// Card payments through Stripe Checkout. Needs 'stripe_secret' (and 'stripe_webhook' for the webhook) in shy-data/config.php.
// Called directly by Stripe as a webhook (POST with a Stripe-Signature header), or included by shop.php for its helpers.

if (!defined('SHY_API')) {
    header('Content-Type: application/json; charset=utf-8');
    define('SHY_API', 1);
    require __DIR__ . '/common.php';
    require __DIR__ . '/holders.php';
    require __DIR__ . '/economy.php';
    define('STRIPE_WEBHOOK', 1);
}

function stripe_call($method, $path, $fields = null) {
    $c = shy_config();
    if (empty($c['stripe_secret'])) return null;
    $ch = curl_init('https://api.stripe.com/v1/' . $path);
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_USERPWD => $c['stripe_secret'] . ':', CURLOPT_CUSTOMREQUEST => $method];
    if ($fields !== null) $opt[CURLOPT_POSTFIELDS] = http_build_query($fields);
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $j = $raw ? json_decode($raw, true) : null;
    return ($code >= 200 && $code < 300 && is_array($j)) ? $j : null;
}
function stripe_create_session($o, $success, $cancel) {
    $s = stripe_call('POST', 'checkout/sessions', [
        'mode' => 'payment',
        'success_url' => $success, 'cancel_url' => $cancel,
        'client_reference_id' => $o['id'],
        'metadata' => ['order' => $o['id'], 'wallet' => $o['wallet']],
        'payment_intent_data' => ['metadata' => ['order' => $o['id']]],
        'line_items' => [['quantity' => 1, 'price_data' => ['currency' => 'usd', 'unit_amount' => (int)round($o['usd'] * 100),
            'product_data' => ['name' => $o['name'], 'description' => 'Shilluminati Online, digital item. Delivered to your game profile.']]]],
    ]);
    return $s && !empty($s['url']) ? ['id' => $s['id'], 'url' => $s['url']] : null;
}
function stripe_session_paid($sid) {
    if (!preg_match('/^cs_[A-Za-z0-9_]+$/', (string)$sid)) return false;
    $s = stripe_call('GET', 'checkout/sessions/' . $sid);
    return $s && ($s['payment_status'] ?? '') === 'paid';
}

if (defined('STRIPE_WEBHOOK')) {
    $c = shy_config();
    $payload = file_get_contents('php://input');
    $sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    if (empty($c['stripe_webhook']) || !$payload || !$sigHeader) fail('not configured', 400);
    // Stripe-Signature: t=timestamp,v1=hmac
    $parts = [];
    foreach (explode(',', $sigHeader) as $kv) { [$k, $v] = array_pad(explode('=', $kv, 2), 2, ''); $parts[$k][] = $v; }
    $t = (int)($parts['t'][0] ?? 0);
    $expect = hash_hmac('sha256', $t . '.' . $payload, $c['stripe_webhook']);
    $good = false;
    foreach ($parts['v1'] ?? [] as $v1) if (hash_equals($expect, $v1)) $good = true;
    if (!$good || abs(time() - $t) > 600) fail('bad signature', 400);
    $ev = json_decode($payload, true);
    if (($ev['type'] ?? '') === 'checkout.session.completed' && ($ev['data']['object']['payment_status'] ?? '') === 'paid') {
        $sess = $ev['data']['object'];
        $oid = (string)($sess['metadata']['order'] ?? $sess['client_reference_id'] ?? '');
        with_lock(function () use ($oid, $sess) {
            $orders = load(ORDERS);
            if (!isset($orders[$oid]) || ($orders[$oid]['session'] ?? '') !== $sess['id']) return;
            if ((int)($sess['amount_total'] ?? 0) < (int)round($orders[$oid]['usd'] * 100)) return;
            fulfill($orders, $oid, $sess['id']);
        });
    }
    out(['ok' => true]);
}
