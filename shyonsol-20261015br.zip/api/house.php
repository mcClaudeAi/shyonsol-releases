<?php
// Houses for players.
// GET  ?a=board                 this week's House board and last week's winners
// GET  ?a=get&h=<TAG or id>     one House's public page
// POST {a, pid, key, ...}       me | create | edit | join | leave | accept | decline | kick | officer | lead
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

function h_find($H, $q) {
    $q = trim((string)$q); if ($q === '') return '';
    if (isset($H['h'][$q])) return $q;
    //MC 2026-10-09 cast to string. PHP turns all-digit array keys into ints, so ?a=get sent "id":80115311 while "me" sent "80115311" and the House page didn't know it was yours (no Edit or Leave)
    foreach ($H['h'] as $id => $h) if (strcasecmp($h['tag'], $q) === 0) return (string)$id;
    return '';
}
function h_name_ok($n) {
    $n = trim(preg_replace('/\s+/', ' ', (string)$n));
    if (!preg_match('/^[A-Za-z0-9 \'&.\-]{3,24}$/', $n) || !preg_match('/[A-Za-z]/', $n) || name_blocked($n)) return null;
    return $n;
}
function h_tag_ok($t) { $t = strtoupper(trim((string)$t)); return preg_match('/^[A-Z0-9]{2,4}$/', $t) && !name_blocked($t) ? $t : null; }

$a = $_GET['a'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $players = load(PLAYERS); $H = houses();
    if ($a === 'board') {
        $last = null; foreach ($H['weeks'] as $w => $x) { $last = ['wk' => $w, 'week' => (int)explode('-', $w)[1], 'rows' => array_slice($x['rows'], 0, 3)]; break; }
        $set = house_settings();
        out(['ok' => true, 'week' => (int)explode('-', week_key())[1], 'ends' => week_end_ts(), 'rows' => array_slice(house_board($players, $H), 0, 50), 'last' => $last,
            'prize' => $set['prize'], 'cost' => $set['cost'], 'games' => $set['games'], 'max' => HOUSE_MAX, 'crests' => HOUSE_CRESTS, 'colors' => HOUSE_COLORS, 'count' => count($H['h'])]);
    }
    if ($a === 'get') {
        $id = h_find($H, $_GET['h'] ?? '');
        if (!$id) fail('No House by that name.', 404);
        out(['ok' => true, 'house' => house_public($id, $H, $players)]);
    }
    fail('unknown action');
}

$raw = file_get_contents('php://input');
if (strlen($raw) > 4000) fail('too large');
$b = json_decode($raw, true) ?: [];
$a = (string)($b['a'] ?? '');
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);

// everything below runs under the lock with the player's key checked
function h_act($fn) {
    global $pid, $kh;
    $r = with_lock(function () use ($fn, $pid, $kh) {
        $l = load(LIMITS); $ok = rate_ok($l, 'house:' . client_ip(), 120, 600); save(LIMITS, $l);
        if (!$ok) return ['err' => 'Slow down a little and try again.', 'code' => 429];
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $H = houses();
        $r = $fn($H, $players);
        if (!isset($r['err']) && empty($r['nosave'])) save(HOUSES, $H);
        unset($r['nosave']);
        if (!isset($r['err'])) $r['me'] = h_me($H, $players);
        return $r;
    });
    if (isset($r['err'])) { $c = $r['code'] ?? 400; out(['ok' => false, 'error' => $r['err']], $c); }
    out(['ok' => true] + $r);
}
// the asking player's House, their role, and what's waiting on them
function h_me($H, $players) {
    global $pid;
    $id = house_of($pid, $H);
    $asked = []; foreach ($H['h'] as $hid => $h) if (isset($h['reqs'][$pid])) $asked[] = ['id' => $hid, 'name' => $h['name'], 'tag' => $h['tag']];
    $set = house_settings();
    $me = ['house' => $id ? house_public($id, $H, $players) : null, 'role' => $id ? house_role($H['h'][$id], $pid) : '', 'asked' => $asked,
        'name' => $players[$pid]['name'] ?? '', 'games' => (int)($players[$pid]['games'] ?? 0), 'cost' => $set['cost'], 'needGames' => $set['games'],
        'koban' => (int)(load(ECO)[$pid]['koban'] ?? 0), 'cool' => max(0, (int)($H['cool'][$pid] ?? 0) + 7 * 86400 - time())];
    if ($id && in_array($me['role'], ['owner', 'officer'], true)) {
        $me['reqs'] = array_values(array_map(fn($p) => ['id' => substr($p, 0, 6), 'name' => $players[$p]['name'] ?? '?', 'points' => (int)($players[$p]['points'] ?? 0), 'games' => (int)($players[$p]['games'] ?? 0)], array_keys($H['h'][$id]['reqs'] ?? [])));
    }
    return $me;
}
function h_member($H, $id, $tag) { foreach ($H['h'][$id]['members'] as $p => $_) if (strpos($p, strtolower($tag)) === 0) return $p; return ''; }
function h_join(&$H, $id, $p) {
    $H['h'][$id]['members'][$p] = time(); $H['m'][$p] = $id; $H['cool'][$p] = time();
    foreach ($H['h'] as $hid => &$h) unset($h['reqs'][$p]);
    unset($h);
}
function h_leave(&$H, $p) {
    $id = house_of($p, $H); if (!$id) return;
    $h = &$H['h'][$id];
    unset($h['members'][$p], $h['officers'][$p], $H['m'][$p]);
    if (!$h['members']) { unset($H['h'][$id]); return; }   // the last one out closes the House
    if ($h['owner'] === $p) {   // the longest-serving officer, else member, takes over
        $next = ''; $best = PHP_INT_MAX;
        foreach ($h['members'] as $q => $since) { $rank = (!empty($h['officers'][$q]) ? 0 : 1e12) + $since; if ($rank < $best) { $best = $rank; $next = $q; } }
        $h['owner'] = $next; unset($h['officers'][$next]);
    }
}

if ($a === 'me') h_act(fn(&$H, $players) => ['nosave' => 1]);

if ($a === 'create') h_act(function (&$H, $players) use ($pid, $b) {
    $set = house_settings();
    if (!$set['on']) return ['err' => 'Houses are closed right now.'];
    if (house_of($pid, $H)) return ['err' => 'Leave your House first.'];
    if ((int)($players[$pid]['games'] ?? 0) < $set['games']) return ['err' => 'Play ' . $set['games'] . ' games before you found a House.'];
    if (empty($players[$pid]['name'])) return ['err' => 'Pick a player name first.'];
    $name = h_name_ok($b['name'] ?? ''); $tag = h_tag_ok($b['tag'] ?? '');
    if (!$name) return ['err' => 'Pick a House name: 3 to 24 letters, numbers or spaces.'];
    if (!$tag) return ['err' => 'Pick a tag of 2 to 4 letters or numbers, like SHY.'];
    foreach ($H['h'] as $h) { if (strcasecmp($h['name'], $name) === 0) return ['err' => 'That House name is taken.']; if ($h['tag'] === $tag) return ['err' => 'That tag is taken.']; }
    //MC 2026-10-11 the About text goes through the same check as a motto: no links, handles or blocked words
    $desc = trim(preg_replace('/\s+/u', ' ', (string)($b['desc'] ?? '')));
    if ($e = motto_problem($desc, 140, 'House description')) return ['err' => $e];
    $crest = in_array($b['crest'] ?? '', HOUSE_CRESTS, true) ? $b['crest'] : 'moon';
    $color = in_array($b['color'] ?? '', HOUSE_COLORS, true) ? $b['color'] : 'crimson';
    // founding costs Koban, so Houses are worth founding
    $eco = load(ECO); $acc = eco_get($eco, $pid);
    if ($set['cost'] > 0) { if ($acc['koban'] < $set['cost']) return ['err' => 'Founding a House costs ' . number_format($set['cost']) . ' Koban.']; eco_credit($acc, -$set['cost'], 'Founded the House ' . $name); $eco[$pid] = $acc; save(ECO, $eco); }
    $id = bin2hex(random_bytes(4));
    $H['h'][$id] = ['name' => $name, 'tag' => $tag, 'crest' => $crest, 'color' => $color, 'desc' => $desc, 'open' => !empty($b['open']),
        'tg' => '', 'owner' => $pid, 'officers' => [], 'members' => [], 'reqs' => [], 'created' => time()];
    h_join($H, $id, $pid);
    return ['made' => $tag];
});

if ($a === 'edit') h_act(function (&$H, $players) use ($pid, $b) {
    $id = house_of($pid, $H); if (!$id) return ['err' => 'You\'re not in a House.'];
    $h = &$H['h'][$id];
    if (!in_array(house_role($h, $pid), ['owner', 'officer'], true)) return ['err' => 'Only the head of the House and officers can change it.'];
    if (isset($b['desc'])) { $d = trim(preg_replace('/\s+/u', ' ', (string)$b['desc'])); if ($e = motto_problem($d, 140, 'House description')) return ['err' => $e]; $h['desc'] = $d; }   //MC 2026-10-11
    if (isset($b['open'])) $h['open'] = !empty($b['open']);
    if (isset($b['crest']) && in_array($b['crest'], HOUSE_CRESTS, true)) $h['crest'] = $b['crest'];
    if (isset($b['color']) && in_array($b['color'], HOUSE_COLORS, true)) $h['color'] = $b['color'];
    if (isset($b['tg'])) { $t = trim((string)$b['tg']); if ($t !== '' && !preg_match('#^https://t\.me/[A-Za-z0-9_+/]{3,80}$#', $t)) return ['err' => 'The House chat should be a t.me link.']; $h['tg'] = $t; }
    return [];
});

if ($a === 'join') h_act(function (&$H, $players) use ($pid, $b) {
    $id = h_find($H, $b['h'] ?? ''); if (!$id) return ['err' => 'No House by that name.', 'code' => 404];
    if (house_of($pid, $H)) return ['err' => 'Leave your House first.'];
    if (empty($players[$pid]['name'])) return ['err' => 'Pick a player name first: play a game and save your score.'];
    $wait = (int)($H['cool'][$pid] ?? 0) + 7 * 86400 - time();
    if ($wait > 0) return ['err' => 'You can join a new House ' . ($wait > 86400 ? 'in ' . ceil($wait / 86400) . ' days' : 'tomorrow') . '. One switch a week keeps the House board fair.'];
    $h = &$H['h'][$id];
    if (count($h['members']) >= HOUSE_MAX) return ['err' => $h['name'] . ' is full.'];
    if (!empty($h['open'])) { h_join($H, $id, $pid); return ['joined' => $h['tag']]; }
    $h['reqs'][$pid] = time();
    return ['asked' => $h['tag']];
});

if ($a === 'cancel') h_act(function (&$H, $players) use ($pid, $b) { $id = h_find($H, $b['h'] ?? ''); if ($id) unset($H['h'][$id]['reqs'][$pid]); return []; });

if ($a === 'leave') h_act(function (&$H, $players) use ($pid) { if (!house_of($pid, $H)) return ['err' => 'You\'re not in a House.']; h_leave($H, $pid); return ['left' => 1]; });

if (in_array($a, ['accept', 'decline', 'kick', 'officer', 'lead'], true)) h_act(function (&$H, $players) use ($pid, $b, $a) {
    $id = house_of($pid, $H); if (!$id) return ['err' => 'You\'re not in a House.'];
    $h = &$H['h'][$id]; $role = house_role($h, $pid); $tag = strtolower(preg_replace('/[^a-f0-9]/i', '', (string)($b['who'] ?? '')));
    if (strlen($tag) !== 6) return ['err' => 'Pick a player.'];
    if (!in_array($role, ['owner', 'officer'], true)) return ['err' => 'Only the head of the House and officers can do that.'];
    if ($a === 'accept' || $a === 'decline') {
        $p = ''; foreach ($h['reqs'] as $q => $_) if (strpos($q, $tag) === 0) $p = $q;
        if (!$p) return ['err' => 'That request is gone.'];
        if ($a === 'decline') { unset($h['reqs'][$p]); return []; }
        if (house_of($p, $H)) { unset($h['reqs'][$p]); return ['err' => 'They joined another House.']; }
        if (count($h['members']) >= HOUSE_MAX) return ['err' => 'The House is full.'];
        h_join($H, $id, $p);
        if (function_exists('fr_notify') || is_file(__DIR__ . '/friendslib.php')) { require_once __DIR__ . '/friendslib.php'; fr_notify($p, 'house', $pid, ['house' => $h['name']], null, ['url' => '/houses']); }
        return [];
    }
    $p = h_member($H, $id, $tag); if (!$p || $p === $pid) return ['err' => 'Pick a member.'];
    if ($a === 'kick') { if ($p === $h['owner'] || ($role === 'officer' && !empty($h['officers'][$p]))) return ['err' => 'You can\'t remove them.']; h_leave($H, $p); return []; }
    if ($role !== 'owner') return ['err' => 'Only the head of the House can do that.'];
    if ($a === 'officer') { if (!empty($h['officers'][$p])) unset($h['officers'][$p]); else { if (count($h['officers']) >= 4) return ['err' => 'A House has up to 4 officers.']; $h['officers'][$p] = 1; } return []; }
    $h['owner'] = $p; unset($h['officers'][$p]); $h['officers'][$pid] = 1;   // lead: hand the House over and stay on as an officer
    return [];
});

fail('unknown action');
