<?php
// Tournaments for players.
// GET  ?a=state                                  the tournament to show now (public)
// POST {a: me|join|leave|checkin, pid, key, name, avatar}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

tourney_tick();
$a = $_GET['a'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($a !== 'state') fail('unknown action');
    out(['ok' => true, 't' => tourney_public(tourney_pick(tourney_db()))]);
}
$raw = file_get_contents('php://input');
if (strlen($raw) > 4000) fail('too large');
$b = json_decode($raw, true) ?: [];
$a = (string)($b['a'] ?? '');
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
$ok = with_lock(function () use ($pid, $kh) { $l = load(LIMITS); $r = rate_ok($l, 'tourney:' . client_ip(), 240, 600); save(LIMITS, $l); return $r && key_ok($pid, $kh); });
if (!$ok) fail('Slow down a little and try again.', 429);
$t = tourney_pick(tourney_db(), $pid);

if ($a === 'me') out(['ok' => true, 't' => tourney_public($t, $pid)]);
if (!$t) fail('There\'s no tournament on right now.');
$id = (string)($b['id'] ?? $t['id']);
if ($a === 'join') {
    // holder-only and joint events check the player's wallet first
    $tt = tourney_db()['list'][$id] ?? null;
    if ($tt && ($why = tourney_gate_problem($tt, $pid)) !== '') fail($why, 403);
    //MC 2026-10-13 a paid event seats ticket holders only: the ticket is a paid shop order (tk:<id>), checked on chain
    //   like every payment. No ticket answers with needTicket, and the Play page opens the checkout.
    $tk = '';
    if ($tt && !empty($tt['fee'])) {
        $tk = (string)tourney_ticket_order($id, $pid);
        if ($tk === '') out(['ok' => false, 'error' => 'This tournament has an entry fee of ' . number_format($tt['fee']) . ' $SHY. Buy your entry first; it\'s refunded if the event is called off.', 'needTicket' => true, 'fee' => (float)$tt['fee'], 'product' => 'tk:' . $id, 'tname' => $tt['name']], 402);
    }
    // the same name rules as a live match, and the player's look comes along to the table
    $name = clean_name($b['name'] ?? '');
    if ($name === null) fail(name_problem($b['name'] ?? ''));
    $avatar = preg_match('/^\d{1,4}$/', (string)($b['avatar'] ?? '')) ? (string)$b['avatar'] : '';
    if (player_banned($pid)) fail(BANNED_MSG, 403);   //MC 2026-10-11 no tournaments for a banned profile
    //MC 2026-10-11 any Shadow / $SHY lookup that's due happens here, before the lock (see holder_prefetch)
    holder_prefetch($pid, false, $kh);
    $prof = with_lock(function () use ($pid, $kh, $name, $avatar) {
        $players = load(PLAYERS);
        if (!empty($players[$pid]['nlock']) || !empty($players[$pid]['nprof'])) $name = $players[$pid]['name'];
        foreach ($players as $q => $p) if ($q !== $pid && strcasecmp($p['name'] ?? '', $name) === 0) return 'That name is taken. Try another.';
        [$av, $holder] = verified_avatar($pid, $avatar);
        $eco = load(ECO); $acc = eco_get($eco, $pid); $tier = holder_tier(load(HOLDERS)[$pid] ?? null);
        return ['pid' => $pid, 'kh' => $kh, 'name' => $name, 'avatar' => $av, 'holder' => $holder, 'cos' => eco_public($acc, $tier, true), 'reacts' => eco_reacts($acc, $tier)];
    });
    if (is_string($prof)) fail($prof, 409);
    $prof['tk'] = $tk;   //MC 2026-10-13 the paid ticket rides along to the roster
    $r = tourney_join($id, $prof);
} elseif ($a === 'checkin') $r = tourney_checkin($id, $pid);
elseif ($a === 'leave') $r = tourney_leave($id, $pid);
else fail('unknown action');
if (isset($r['err'])) fail($r['err'], 409);
out(['ok' => true, 't' => tourney_public($r['t'], $pid)]);
