<?php
// Shytoshi Shadows ownership: wallet signatures, Helius lookups, and per-Shadow career records.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const SHADOWS_COLLECTION = 'yMEs7PXBh6VfQ611MYDZt9fb1xr73bQLnZm5NhnhbQK';
const HOLD_RECHECK = 6 * 3600;     // look ownership up again after this long
const NONCE_TTL = 600;
define('HOLDERS', DATA_DIR . '/holders.php');   // pid => wallet, owned Shadows, last check
define('SHADOWREG', DATA_DIR . '/shadows.php'); // Shadow number => image + career record
define('NONCES', DATA_DIR . '/nonces.php');

function shy_config() {
    static $cfg = null;
    if ($cfg !== null) return $cfg;
    $f = DATA_DIR . '/config.php';
    $cfg = is_file($f) ? (include $f) : [];
    if (!is_array($cfg)) $cfg = [];
    return $cfg;
}
function holders_enabled() { $c = shy_config(); return !empty($c['das_url']) || (isset($c['helius']) && preg_match('/^[A-Za-z0-9-]{20,}$/', $c['helius']) && stripos($c['helius'], 'PASTE') === false); }

// ---------- base58 ----------
function b58_decode($s) {
    $alpha = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    if ($s === '' || strspn($s, $alpha) !== strlen($s)) return null;
    $bytes = [0];
    for ($i = 0; $i < strlen($s); $i++) {
        $carry = strpos($alpha, $s[$i]);
        for ($j = 0; $j < count($bytes); $j++) { $carry += $bytes[$j] * 58; $bytes[$j] = $carry & 0xff; $carry >>= 8; }
        while ($carry > 0) { $bytes[] = $carry & 0xff; $carry >>= 8; }
    }
    for ($i = 0; $i < strlen($s) && $s[$i] === '1'; $i++) $bytes[] = 0;
    return implode('', array_map('chr', array_reverse($bytes)));
}
function valid_wallet($w) { if (!is_string($w) || !preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $w)) return false; $b = b58_decode($w); return $b !== null && strlen($b) === 32; }

// The exact words a player signs. Rebuilt on the server from the stored nonce, never taken from the browser.
function sign_text($wallet, $pid, $nonce, $issued) {
    return "shyonsol.io wants you to verify your Shytoshi Shadows.\n\n" .
        "This only proves you own this wallet. It is not a transaction and costs nothing.\n\n" .
        "Wallet: $wallet\nPlayer: $pid\nNonce: $nonce\nIssued: " . gmdate('Y-m-d H:i', $issued) . " UTC";
}
// Returns '' when the signature is good, otherwise a short reason code.
function sig_check($wallet, $message, $sigB64) {
    $pk = b58_decode($wallet);
    $sig = base64_decode((string)$sigB64, true);
    if ($pk === null || strlen($pk) !== 32) return 'bad-wallet';
    if ($sig === false || strlen($sig) !== 64) return 'bad-sig-format-' . ($sig === false ? 'b64' : strlen($sig));
    try {
        if (function_exists('sodium_crypto_sign_verify_detached')) return sodium_crypto_sign_verify_detached($sig, $message, $pk) ? '' : 'bad-sig';
        // host without the sodium module: use the bundled pure-PHP Ed25519
        require_once __DIR__ . '/lib/sodium_compat/autoload.php';
        return ParagonIE_Sodium_Compat::crypto_sign_verify_detached($sig, $message, $pk) ? '' : 'bad-sig-compat';
    } catch (Throwable $e) { return 'crypto-error'; }
}
function sig_ok($wallet, $message, $sigB64) { return sig_check($wallet, $message, $sigB64) === ''; }

// ---------- ownership lookup ----------
// Returns [ [n => 255, img => url, asset => id], ... ] or null if the lookup failed.
function das_owned($wallet) {
    $c = shy_config();
    $url = !empty($c['das_url']) ? $c['das_url'] : 'https://mainnet.helius-rpc.com/?api-key=' . rawurlencode($c['helius'] ?? '');
    $owned = [];
    for ($page = 1; $page <= 5; $page++) {
        $body = json_encode(['jsonrpc' => '2.0', 'id' => 'shy', 'method' => 'searchAssets', 'params' => [
            'ownerAddress' => $wallet, 'grouping' => ['collection', SHADOWS_COLLECTION], 'page' => $page, 'limit' => 1000]]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5]);
        $raw = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($raw === false || $code !== 200) return null;
        $j = json_decode($raw, true);
        if (!isset($j['result']['items'])) return null;
        foreach ($j['result']['items'] as $it) {
            if (($it['ownership']['owner'] ?? '') !== $wallet || !empty($it['burnt'])) continue;
            $grp = array_column($it['grouping'] ?? [], 'group_value', 'group_key');
            if (($grp['collection'] ?? '') !== SHADOWS_COLLECTION) continue;
            $name = $it['content']['metadata']['name'] ?? '';
            if (!preg_match('/#\s*(\d{1,5})/', $name, $m)) continue;
            $img = $it['content']['links']['image'] ?? ($it['content']['files'][0]['uri'] ?? '');
            if (!preg_match('#^https://#', $img)) $img = '';
            $tr = nft_traits($it);
            $owned[] = ['n' => (string)(int)$m[1], 'img' => $img, 'asset' => $it['id'] ?? '', 'aura' => $tr['aura'] ?? '', 'rank' => $tr['rarity rank'] ?? ($tr['rank'] ?? '')];
        }
        if (count($j['result']['items']) < 1000) break;
    }
    usort($owned, fn($a, $b) => (int)$a['n'] <=> (int)$b['n']);
    return $owned;
}

// Traits from either the JSON metadata or the Core attributes plugin, as lowercase name => value.
function nft_traits($it) {
    $out = [];
    foreach ((array)($it['content']['metadata']['attributes'] ?? []) as $a) if (isset($a['trait_type'], $a['value'])) $out[strtolower(trim($a['trait_type']))] = trim((string)$a['value']);
    foreach ((array)($it['plugins']['attributes']['data']['attribute_list'] ?? []) as $a) if (isset($a['key'], $a['value']) && !isset($out[strtolower(trim($a['key']))])) $out[strtolower(trim($a['key']))] = trim((string)$a['value']);
    foreach ($out as $k => $v) $out[$k] = mb_substr(preg_replace('/[^\p{L}\p{N} #.\-]/u', '', $v), 0, 40);
    return $out;
}

//MC 2026-10-11 the Shadow and $SHY lookups (up to five Helius pages and an RPC call, 10-12 s timeouts each) ran inside
//   with_lock, so one stale holder froze every other request on the site for as long as Solana took. Callers now run
//   holder_prefetch() BEFORE taking the lock: it decides the same way holder_refresh does whether a lookup is due, makes
//   the calls with no lock held, and keeps the answers for this request. holder_refresh, inside the lock, checks again
//   (another request may have refreshed meanwhile, then nothing is used) and takes the kept answers instead of calling
//   out. A caller that didn't prefetch still works exactly as before.
function &holder_net_cache() { static $c = []; return $c; }
function holder_due($h, $reg, $force) {
    if (!$h || empty($h['wallet']) || !holders_enabled()) return false;
    foreach ($h['shadows'] ?? [] as $n) if (!isset($reg[$n]['tr']) && time() - ($h['tried'] ?? 0) > 300) $force = true;
    return $force || time() - ($h['chk'] ?? 0) >= HOLD_RECHECK;
}
// look up a wallet now, with no lock held ($h = the holder record as last saved). $kh: only for the profile's own key.
function holder_prefetch($pid, $force = false, $kh = null, $h = null) {
    if (!holders_enabled()) return;
    if ($kh !== null && !key_ok($pid, $kh)) return;
    $h = $h ?? (load(HOLDERS)[$pid] ?? null);
    if (!holder_due($h, load(SHADOWREG), $force)) return;
    $c = &holder_net_cache();
    if (isset($c[$h['wallet']])) return;
    $owned = das_owned($h['wallet']);
    $c[$h['wallet']] = ['owned' => $owned, 'sb' => $owned !== null && function_exists('shy_balance') ? shy_balance($h['wallet']) : null];
}
// Refresh one holder's Shadows if the last check is stale (or when forced). Call inside with_lock.
function holder_refresh(&$holders, &$reg, $pid, $force = false) {
    $h = $holders[$pid] ?? null;
    if (!$h || empty($h['wallet']) || !holders_enabled()) return $h;
    // Shadows saved before traits were tracked get looked up once more
    // (at most every few minutes, so a slow lookup service can't stall every request)
    foreach ($h['shadows'] ?? [] as $n) if (!isset($reg[$n]['tr']) && time() - ($h['tried'] ?? 0) > 300) $force = true;
    if (!$force && time() - ($h['chk'] ?? 0) < HOLD_RECHECK) return $h;
    $h['tried'] = time(); $holders[$pid]['tried'] = time();
    $pre = holder_net_cache()[$h['wallet']] ?? null;   //MC 2026-10-11 fetched before the lock, if the caller did
    $owned = $pre ? $pre['owned'] : das_owned($h['wallet']);
    if ($owned === null) return $h; // lookup failed: keep what we knew
    //MC 2026-10-09 one empty answer from the lookup service used to wipe a holder's Shadows on the spot. A game ending at
    //   that moment saved the player as Unbound, and nothing put their Shadow back when the next check found it again
    //   (MrvRhnShy showed Unbound everywhere while his page still said Shadow holder). An empty answer for a wallet that
    //   had Shadows now has to be confirmed by another lookup at least 10 minutes later before the Shadows are dropped.
    if (!$owned && !empty($h['shadows'])) {
        if (empty($h['gone_at'])) { $holders[$pid]['gone_at'] = time(); return $holders[$pid]; }
        if (time() - $h['gone_at'] < 600) return $h;
    }
    unset($h['gone_at']);
    // $SHY held, for holder tiers (kept as it was if Solana can't be reached)
    if (function_exists('shy_balance')) { $sb = $pre ? $pre['sb'] : shy_balance($h['wallet']); if ($sb) { $h['shy_bal'] = $sb['bal']; $h['shy_usd'] = round($sb['usd'], 2); if (function_exists('loyalty_note')) loyalty_note($h['wallet'], $sb['bal']); } }   //MC 2026-10-15 time-held clocks
    $h['shadows'] = array_column($owned, 'n');
    $h['chk'] = time();
    foreach ($owned as $o) {
        $r = $reg[$o['n']] ?? ['wins' => 0, 'games' => 0, 'points' => 0, 'pvp_w' => 0, 'pvp_g' => 0, 'best' => 0];
        if ($o['img']) $r['img'] = $o['img'];
        $r['asset'] = $o['asset'];
        $r['aura'] = $o['aura']; $r['rank'] = $o['rank']; $r['tr'] = 1;
        $reg[$o['n']] = $r;
    }
    $holders[$pid] = $h;
    return $h;
}

//MC 2026-10-09 keep a player's record in step with their wallet: a holder always plays as one of their own Shadows,
//   everyone else is Unbound. The status check used to switch the holder flag back on without putting the Shadow back.
//   Returns true when the record changed.
function holder_sync_player(&$players, $pid, $h) {
    if (!isset($players[$pid])) return false;
    $mine = $h['shadows'] ?? [];
    $has = !empty($h['wallet']) && count($mine) > 0;
    $cur = (string)($players[$pid]['avatar'] ?? '');
    $av = $has ? (in_array($cur, $mine, true) ? $cur : (string)$mine[0]) : '';
    if (!empty($players[$pid]['holder']) === $has && $cur === $av) return false;
    $players[$pid]['holder'] = $has; $players[$pid]['avatar'] = $av;
    return true;
}
// one pass over every holder to repair records left Unbound by the old empty-lookup bug. Runs once. Call inside with_lock.
function holders_repair_once() {
    $flag = DATA_DIR . '/repair-holder-avatars.txt';
    if (is_file($flag)) return;
    $holders = load(HOLDERS); $players = load(PLAYERS); $n = 0;
    foreach ($holders as $pid => $h) if (!empty($h['wallet']) && holder_sync_player($players, $pid, $h)) $n++;
    if ($n) save(PLAYERS, $players);
    @file_put_contents($flag, gmdate('c') . " fixed $n\n");
}

// Which avatar a player may actually use: their own Shadow if they hold it, otherwise none (Unbound).
// Call inside with_lock. Returns [avatar, isHolder].
function verified_avatar($pid, $want) {
    $holders = load(HOLDERS);
    if (empty($holders[$pid]['wallet'])) return ['', false];
    $reg = load(SHADOWREG);
    $before = json_encode([$holders[$pid], count($reg)]);
    $h = holder_refresh($holders, $reg, $pid);
    if (json_encode([$holders[$pid], count($reg)]) !== $before) { save(HOLDERS, $holders); save(SHADOWREG, $reg); }
    $mine = $h['shadows'] ?? [];
    if (!$mine) return ['', false];
    return [in_array((string)$want, $mine, true) ? (string)$want : (string)$mine[0], true];
}

// Add a finished game to a Shadow's career record. Call inside with_lock.
function shadow_record($n, $points, $result, $regions, $live) {
    if ($n === '' || $n === null) return;
    $reg = load(SHADOWREG);
    $r = $reg[$n] ?? ['wins' => 0, 'games' => 0, 'points' => 0, 'pvp_w' => 0, 'pvp_g' => 0, 'best' => 0];
    $r['games']++; $r['points'] += $points; $r['best'] = max($r['best'], $regions);
    if ($result === 'win') $r['wins']++;
    if ($live) { $r['pvp_g'] = ($r['pvp_g'] ?? 0) + 1; if ($result === 'win') $r['pvp_w'] = ($r['pvp_w'] ?? 0) + 1; } //MC 2026-10-09 older rows had no pvp keys
    $r['last'] = time();
    $reg[$n] = $r;
    save(SHADOWREG, $reg);
}
// a Shadow's Aura trait as a short key for styling: cyan, crimson, lightning, money, btc, or none
function shadow_aura($n) {
    static $reg = null; if ($reg === null) $reg = load(SHADOWREG);
    $a = strtolower(trim((string)($reg[$n]['aura'] ?? '')));
    return ['electric cyan' => 'cyan', 'crimson glow' => 'crimson', 'lightning aura' => 'lightning', 'money aura' => 'money', 'btc aura' => 'btc'][$a] ?? 'none';
}
// does this player's connected wallet hold a Shadow right now (as last checked)
function holds_shadow($pid) { $h = load(HOLDERS)[$pid] ?? null; return !empty($h['wallet']) && !empty($h['shadows']); }
function shadow_img($n) { static $reg = null; if ($reg === null) $reg = load(SHADOWREG); return $reg[$n]['img'] ?? ''; }
