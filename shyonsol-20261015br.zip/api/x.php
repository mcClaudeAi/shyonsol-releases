<?php
// Connect X: players link their X account (OAuth 2.0 with PKCE). Linked players get the "Verified with X" badge
// and can post their game results to X straight from the site.
// POST a=status {pid,key}            -> {enabled, linked, user}
// POST a=start  {pid,key,back}       -> {url} (send the browser there)
// GET  a=cb&code&state               -> X sends the player back here; we finish linking and return them to the site
// POST a=post   {pid,key,text}       -> posts to the player's X account
// POST a=unlink {pid,key}

header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/xtasks.php';

define('XACC', DATA_DIR . '/x-accounts.php');   // pid => tokens and the X profile; never sent to browsers
define('XSTATE', DATA_DIR . '/x-states.php');   // sign-ins in progress
const X_SCOPES = 'tweet.read tweet.write users.read offline.access';
const X_AUTH = 'https://x.com/i/oauth2/authorize';

function x_cfg() { $c = shy_config(); return ['id' => $c['x_client_id'] ?? '', 'secret' => $c['x_client_secret'] ?? '', 'api' => rtrim($c['x_api'] ?? 'https://api.x.com', '/')]; }
function x_enabled() { $c = x_cfg(); return $c['id'] !== ''; }
function x_site() { $h = preg_replace('/[^a-z0-9.:\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') ?: 'shyonsol.io'; $s = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || strpos($h, '127.0.0.1') === false ? 'https' : 'http'; return "$s://$h"; }
function x_redirect() { $c = shy_config(); return $c['x_redirect'] ?? (x_site() . '/api/x.php?a=cb'); }
//MC 2026-10-11 where the callback may send the player: a path on this site only. The old pattern let "//2130706433/x"
//   through, which a browser reads as another host (an open redirect).
function x_back_ok($b) { return is_string($b) && preg_match('#^/(?![/\\\\])[a-z0-9\-/]*(\?[a-z0-9=&_\-]*)?$#i', $b) && strpos($b, '//') === false; }
function x_https() { return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') === '443'; }
function b64u($b) { return rtrim(strtr(base64_encode($b), '+/', '-_'), '='); }

function x_http($method, $url, $fields = null, $bearer = null, $json = null) {
    $c = x_cfg();
    $ch = curl_init($url);
    $h = ['Accept: application/json'];
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_CUSTOMREQUEST => $method];
    if ($bearer) $h[] = 'Authorization: Bearer ' . $bearer;
    elseif ($c['secret'] !== '') $h[] = 'Authorization: Basic ' . base64_encode(rawurlencode($c['id']) . ':' . rawurlencode($c['secret']));
    if ($fields !== null) { $h[] = 'Content-Type: application/x-www-form-urlencoded'; $opt[CURLOPT_POSTFIELDS] = http_build_query($fields); }
    if ($json !== null) { $h[] = 'Content-Type: application/json'; $opt[CURLOPT_POSTFIELDS] = json_encode($json); }
    $opt[CURLOPT_HTTPHEADER] = $h;
    curl_setopt_array($ch, $opt);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, $raw === false ? null : json_decode($raw, true)];
}
function x_log($m) { @file_put_contents(DATA_DIR . '/x-errors.log', gmdate('c') . ' ' . $m . "\n", FILE_APPEND); }

// a fresh access token for the player, refreshing it when it has run out; null if they need to connect again
function x_token($pid) {
    $acc = load(XACC)[$pid] ?? null;
    if (!$acc) return null;
    if (($acc['exp'] ?? 0) > time() + 60) return $acc['at'];
    if (empty($acc['rt'])) return null;
    $c = x_cfg();
    [$code, $j] = x_http('POST', $c['api'] . '/2/oauth2/token', ['grant_type' => 'refresh_token', 'refresh_token' => $acc['rt'], 'client_id' => $c['id']]);
    if ($code !== 200 || empty($j['access_token'])) { x_log("refresh failed for $pid ($code) " . json_encode($j)); return null; }
    with_lock(function () use ($pid, $j) {
        $all = load(XACC);
        if (!isset($all[$pid])) return;
        $all[$pid]['at'] = $j['access_token'];
        if (!empty($j['refresh_token'])) $all[$pid]['rt'] = $j['refresh_token'];
        $all[$pid]['exp'] = time() + (int)($j['expires_in'] ?? 7200);
        save(XACC, $all);
    });
    return $j['access_token'];
}
//MC 2026-10-11 the tags the admin set for result posts ($SHY #Solana ...), cleaned: only $cashtags and #hashtags, at most 5
function x_tags() {
    preg_match_all('/[#$][A-Za-z][A-Za-z0-9_]{0,30}/', (string)(eco_settings()['x_tags'] ?? ''), $m);
    return implode(' ', array_slice(array_values(array_unique($m[0])), 0, 5));
}
function x_public($acc) { return $acc ? ['id' => $acc['uid'], 'username' => $acc['username'], 'name' => $acc['name'], 'img' => $acc['img'] ?? '', 'since' => $acc['ts']] : null; }

$a = $_GET['a'] ?? '';
// ---------- X sends the player back ----------
if ($a === 'cb') {
    $state = (string)($_GET['state'] ?? '');
    $st = with_lock(function () use ($state) { $all = load(XSTATE); $s = $all[$state] ?? null; unset($all[$state]); save(XSTATE, array_filter($all, fn($x) => $x['ts'] > time() - 900)); return $s; });
    $back = $st['back'] ?? '/profile';
    if (!x_back_ok($back)) $back = '/profile';   //MC 2026-10-11 checked again on the way out, in case an old state carries a bad one
    $go = function ($res) use ($back) { header('Location: ' . $back . (strpos($back, '?') === false ? '?' : '&') . 'x=' . $res . '#x'); exit; };
    if (!$st || time() - $st['ts'] > 900) $go('expired');
    //MC 2026-10-11 the sign-in has to finish in the browser that started it. start sets a random cookie and keeps its hash
    //   with the state; without it, anyone could start a sign-in on their own profile, send the X link to someone else,
    //   and that person's X account (and its posting rights) landed on the first profile.
    $ck = (string)($_COOKIE['shy_xs'] ?? '');
    setcookie('shy_xs', '', ['expires' => time() - 3600, 'path' => '/api/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => x_https()]);
    if ($ck === '' || empty($st['ck']) || !hash_equals($st['ck'], hash('sha256', $ck))) { x_log('callback from a different browser for ' . ($st['pid'] ?? '?')); $go('expired'); }
    if (!empty($_GET['error'])) $go('cancelled');
    $code = (string)($_GET['code'] ?? '');
    if ($code === '') $go('failed');
    $c = x_cfg();
    [$hc, $tok] = x_http('POST', $c['api'] . '/2/oauth2/token', ['grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => x_redirect(), 'code_verifier' => $st['verifier'], 'client_id' => $c['id']]);
    if ($hc !== 200 || empty($tok['access_token'])) { x_log("token exchange failed ($hc) " . json_encode($tok)); $go('failed'); }
    [$uc, $u] = x_http('GET', $c['api'] . '/2/users/me?user.fields=profile_image_url,verified', null, $tok['access_token']);
    if ($uc !== 200 || empty($u['data']['id'])) { x_log("users/me failed ($uc) " . json_encode($u)); $go('failed'); }
    $pid = $st['pid'];
    $user = $u['data'];
    $kh = $st['kh'] ?? '';
    $res = with_lock(function () use ($pid, $kh, $tok, $user) {
        $all = load(XACC);
        // one X account belongs to one profile
        foreach ($all as $other => $x) if ($other !== $pid && $x['uid'] === $user['id']) return 'taken';
        $all[$pid] = ['uid' => $user['id'], 'username' => $user['username'], 'name' => $user['name'] ?? $user['username'], 'img' => $user['profile_image_url'] ?? '',
            'at' => $tok['access_token'], 'rt' => $tok['refresh_token'] ?? '', 'exp' => time() + (int)($tok['expires_in'] ?? 7200), 'ts' => time(), 'posts' => []];
        save(XACC, $all);
        // the public badge lives on the player record (a profile with no games gets an empty one, kept off the boards)
        $pl = load(PLAYERS);
        if (!isset($pl[$pid])) $pl[$pid] = blank_player($kh);
        $pl[$pid]['xu'] = $user['username'];
        save(PLAYERS, $pl);
        return 'ok';
    });
    $go($res === 'taken' ? 'taken' : 'linked');
}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$body = json_decode(file_get_contents('php://input'), true) ?: [];
$a = (string)($body['a'] ?? '');
$pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
if (!with_lock(fn() => key_ok($pid, $kh))) fail('not your profile', 403);

//MC 2026-10-12 accounts tagged in every post a person sends themselves (Admin > Players > Posting to X)
function x_always() { $o = []; foreach (preg_split('/[\s,]+/', (string)(eco_settings()['x_always'] ?? '')) as $h) if (preg_match('/^@[A-Za-z0-9_]{1,15}$/', $h)) $o[] = $h; return implode(' ', array_slice(array_unique($o), 0, 3)); }
if ($a === 'status') {
    $acc = load(XACC)[$pid] ?? null;
    $paused = (load(DATA_DIR . '/x-usage.php')['paused'] ?? 0) > time();
    $es = eco_settings();
    //MC 2026-10-11 auto: this player asked for their wins to be posted; autoOn: the admin allows it; tags: added to result posts
    out(['ok' => true, 'enabled' => x_enabled(), 'linked' => (bool)$acc, 'user' => x_public($acc), 'links' => !empty($es['x_links']), 'paused' => $paused, 'post' => !empty($es['x_post']),
        'auto' => !empty($acc['auto']), 'autoOn' => !empty($es['x_autopost']) && !empty($es['x_post']), 'tags' => x_tags(), 'always' => x_always(),
        //MC 2026-10-12 kol: one account from the admin's list, picked at random, for the share a player sends themselves
        //   (never in an automatic post: automated @mentions are what X restricts accounts for)
        'kol' => (function () use ($es) { if (empty($es['x_kol_share'])) return ''; $l = array_values(array_filter(array_map('trim', explode("\n", (string)$es['x_kols'])), fn($h) => preg_match('/^@[A-Za-z0-9_]{1,15}$/', $h))); return $l ? $l[random_int(0, count($l) - 1)] : ''; })()]);
}
//MC 2026-10-11 the player's own switch for posting their wins automatically
if ($a === 'auto') {
    $on = !empty($body['on']);
    $r = with_lock(function () use ($pid, $on) {
        $all = load(XACC);
        if (!isset($all[$pid])) return false;
        $all[$pid]['auto'] = $on; save(XACC, $all); return true;
    });
    if (!$r) fail('Connect X first.', 400);
    out(['ok' => true, 'auto' => $on]);
}

if ($a === 'start') {
    if (!x_enabled()) fail('Connecting X is not switched on yet.', 503);
    $back = (string)($body['back'] ?? '/profile');
    if (!x_back_ok($back)) $back = '/profile';
    $verifier = b64u(random_bytes(48));
    $state = b64u(random_bytes(24));
    //MC 2026-10-11 ties the sign-in to this browser (checked in the callback)
    $nonce = b64u(random_bytes(24));
    setcookie('shy_xs', $nonce, ['expires' => time() + 900, 'path' => '/api/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => x_https()]);
    $ck = hash('sha256', $nonce);
    with_lock(function () use ($state, $pid, $kh, $verifier, $back, $ck) {
        key_add($pid, $kh);   // this device's key now guards the profile, even before its first game
        $all = array_filter(load(XSTATE), fn($x) => $x['ts'] > time() - 900);
        $all[$state] = ['pid' => $pid, 'kh' => $kh, 'verifier' => $verifier, 'back' => $back, 'ts' => time(), 'ck' => $ck];
        save(XSTATE, $all);
    });
    $q = ['response_type' => 'code', 'client_id' => x_cfg()['id'], 'redirect_uri' => x_redirect(), 'scope' => X_SCOPES, 'state' => $state,
        'code_challenge' => b64u(hash('sha256', $verifier, true)), 'code_challenge_method' => 'S256'];
    out(['ok' => true, 'url' => X_AUTH . '?' . http_build_query($q, '', '&', PHP_QUERY_RFC3986)]);
}

if ($a === 'unlink') {
    $acc = load(XACC)[$pid] ?? null;
    if ($acc) {
        $c = x_cfg();
        // tell X to forget the token too (best effort)
        if (!empty($acc['rt'])) x_http('POST', $c['api'] . '/2/oauth2/revoke', ['token' => $acc['rt'], 'token_type_hint' => 'refresh_token', 'client_id' => $c['id']]);
        with_lock(function () use ($pid) {
            $all = load(XACC); unset($all[$pid]); save(XACC, $all);
            $pl = load(PLAYERS); if (isset($pl[$pid])) { unset($pl[$pid]['xu']); save(PLAYERS, $pl); }
        });
    }
    out(['ok' => true, 'linked' => false]);
}

if ($a === 'post') {
    if (empty(eco_settings()['x_post'])) fail('Posting from the site is switched off. Use Share on X instead.', 503);
    $text = trim(str_replace("\r", '', (string)($body['text'] ?? '')));
    //MC 2026-10-11 an automatic win post: only with the admin switch on and the player's own switch on, at most a few a
    //   day, and once per result card (sid), so a reload or a second tab can't post the same win twice
    $auto = !empty($body['auto']);
    if ($auto) {
        $sid = preg_replace('/[^a-f0-9]/', '', (string)($body['sid'] ?? ''));
        if (empty(eco_settings()['x_autopost'])) fail('Automatic posts are off.', 403);
        $okA = with_lock(function () use ($pid, $sid) {
            $all = load(XACC);
            if (empty($all[$pid]['auto'])) return 'off';
            $done = $all[$pid]['autos'] ?? [];
            if ($sid !== '' && in_array($sid, $done, true)) return 'dup';
            $limits = load(LIMITS);
            $ok = rate_ok($limits, 'xauto:' . $pid, max(1, (int)(eco_settings()['x_auto_day'] ?? 3)), 86400);
            save(LIMITS, $limits);
            if (!$ok) return 'cap';
            if ($sid !== '') { array_unshift($done, $sid); $all[$pid]['autos'] = array_slice($done, 0, 30); save(XACC, $all); }
            return 'ok';
        });
        if ($okA === 'off') fail('Automatic posts are off for you.', 403);
        if ($okA === 'dup') fail('This win was already posted.', 409);
        if ($okA === 'cap') fail("That's the most automatic posts for today.", 429);
    }
    // links cost X credits many times over, so unless the admin allows them they're taken out
    if (empty(eco_settings()['x_links'])) $text = trim(preg_replace("/[ \t]*https?:\/\/\S+/", '', $text));
    //MC 2026-10-12 the always-tag accounts go on automatic win posts only when the admin turned that on (X can limit the app for repeated automated @mentions)
    if ($auto && !empty(eco_settings()['x_always_auto']) && ($al = x_always()) !== '') { $miss = implode(' ', array_filter(explode(' ', $al), fn($h) => stripos($text, $h) === false)); if ($miss !== '' && mb_strlen(preg_replace('#https?://\S+#', str_repeat('x', 23), $text . ' ' . $miss)) <= 280) $text .= ' ' . $miss; }
    if ($text === '') fail('Write something to post.');
    // X counts every link as 23 characters
    $len = mb_strlen(preg_replace('#https?://\S+#', str_repeat('x', 23), $text));
    if ($len > 280) fail('That post is ' . ($len - 280) . ' characters too long for X.');
    $ok = with_lock(function () use ($pid) {
        $limits = load(LIMITS);
        $ok = rate_ok($limits, 'xpost:' . $pid, 15, 86400) && rate_ok($limits, 'xpost:' . client_ip(), 30, 86400);
        save(LIMITS, $limits);
        return $ok;
    });
    if (!$ok) fail("You've posted a lot today. Try again tomorrow, or share with the X button instead.", 429);
    // a monthly ceiling on posts across the whole site keeps the X bill predictable
    $month = gmdate('Y-m');
    $room = with_lock(function () use ($month) {
        $c = load(DATA_DIR . '/x-usage.php');
        $n = $c[$month] ?? 0;
        if ($n >= (int)(eco_settings()['x_month_cap'] ?? 300)) return false;
        $c[$month] = $n + 1; save(DATA_DIR . '/x-usage.php', $c);
        return true;
    });
    if (!$room) fail('Posting from the site is resting until next month. Share with the X button instead.', 429);
    if ((load(DATA_DIR . '/x-usage.php')['paused'] ?? 0) > time()) {
        with_lock(function () use ($month) { $c = load(DATA_DIR . '/x-usage.php'); $c[$month] = max(0, ($c[$month] ?? 1) - 1); save(DATA_DIR . '/x-usage.php', $c); });
        fail('Posting from the site is paused right now. Use Open in X to share your result instead.', 503);
    }
    $at = x_token($pid);
    if (!$at) fail('Your X connection expired. Connect X again on your profile.', 401);
    [$code, $j] = x_http('POST', x_cfg()['api'] . '/2/tweets', null, $at, ['text' => $text]);
    if ($code === 201 && !empty($j['data']['id'])) {
        $acc = load(XACC)[$pid];
        with_lock(function () use ($pid, $j) { $all = load(XACC); if (isset($all[$pid])) { array_unshift($all[$pid]['posts'], ['id' => $j['data']['id'], 't' => time()]); $all[$pid]['posts'] = array_slice($all[$pid]['posts'], 0, 20); save(XACC, $all); } });
        $xt = xt_site_post($pid, (string)$j['data']['id'], $acc['username'], $text);
        out(['ok' => true, 'id' => $j['data']['id'], 'url' => 'https://x.com/' . $acc['username'] . '/status/' . $j['data']['id'], 'xt' => $xt]);
    }
    x_log("post failed for $pid ($code) " . json_encode($j));
    // a failed post doesn't count toward the monthly limit
    with_lock(function () use ($month, $code) {
        $c = load(DATA_DIR . '/x-usage.php');
        $c[$month] = max(0, ($c[$month] ?? 1) - 1);
        if ($code === 402) $c['paused'] = time() + 3600;   // out of X credits: stop offering posts for an hour
        save(DATA_DIR . '/x-usage.php', $c);
    });
    $detail = strtolower(json_encode($j));
    if ($code === 402) fail('Posting from the site is paused right now. Use Open in X to share your result instead.', 503);
    if ($code === 403 && strpos($detail, 'duplicate') !== false) fail('X says you already posted exactly this. Change a word and try again.', 409);
    if ($code === 401) fail('Your X connection expired. Connect X again on your profile.', 401);
    if ($code === 429) fail('X is limiting posts right now. Try again in a bit, or share with the X button instead.', 429);
    fail("X didn't accept that post. Try again, or share with the X button instead.", 502);
}

fail('unknown action');
