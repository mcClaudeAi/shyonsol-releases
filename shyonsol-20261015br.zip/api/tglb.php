<?php
// The /leaderboard message in Telegram: every board, ten players a page, buttons to switch boards and pages,
// prizes next to the places that pay, and a "Me" button that tells whoever presses it where they stand.
// Included by tgbot.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }
if (!defined('DAILY')) define('DAILY', DATA_DIR . '/daily.php');

const TGLB_PER = 10;
const TGLB_BOARDS = ['league' => 'Weekly League', 'cup' => 'Holder Cup', 'season' => 'Season', 'daily' => 'Daily', 'live' => 'Live', 'all' => 'All time', 'friends' => 'Friends'];
require_once __DIR__ . '/friendslib.php';

// one board as plain rows: [pid, name, pts, sub, ok (qualified), holder]
function tglb_rows($which) {
    $players = load(PLAYERS);
    $holders = load(HOLDERS);
    if (in_array($which, ['league', 'cup', 'season'], true)) {
        return array_map(fn($r) => ['pid' => $r['pid'], 'name' => $r['name'], 'pts' => (int)$r['pts'], 'n' => (int)$r['n'], 'ok' => $r['ok'], 'w' => $r['wallet'] !== '', 'holder' => $r['tier'] !== ''],
            league_rows($players, $holders, $which));
    }
    $rows = [];
    if ($which === 'daily') {
        foreach (load(DAILY)[today()] ?? [] as $pid => $d) {
            if (!isset($players[$pid])) continue;
            $rows[] = ['pid' => $pid, 'name' => $players[$pid]['name'] ?? 'Player', 'pts' => (int)$d['points'], 'g' => (int)$d['regions'], 'r' => $d['result'], 't' => (int)$d['ts'], 'holder' => !empty($players[$pid]['holder'])];
        }
        usort($rows, fn($a, $b) => [$b['pts'], $b['g'], $a['t']] <=> [$a['pts'], $a['g'], $b['t']]);
        return $rows;
    }
    foreach ($players as $pid => $p) {
        if ($which === 'live') {
            if (empty($p['pvp_g'])) continue;
            $rows[] = ['pid' => $pid, 'name' => $p['name'] ?? '', 'pts' => (int)($p['lpts'] ?? 0), 'w' => (int)($p['pvp_w'] ?? 0), 'n' => (int)$p['pvp_g'], 'holder' => !empty($p['holder'])];
        } else {
            if (empty($p['games'])) continue;
            $rows[] = ['pid' => $pid, 'name' => $p['name'] ?? '', 'pts' => (int)($p['points'] ?? 0), 'w' => (int)($p['wins'] ?? 0), 'n' => (int)$p['games'], 'holder' => !empty($p['holder'])];
        }
    }
    usort($rows, fn($a, $b) => [$b['pts'], $b['w'], $a['n']] <=> [$a['pts'], $a['w'], $b['n']]);
    return $rows;
}

// the prize each row would get right now (prize boards only): place among qualified players => USD
function tglb_prizes($which, $rows) {
    $set = eco_settings();
    if ($which === 'league') { $split = $set['league_split']; $pool = league_pool_usd()['total']; }
    elseif ($which === 'cup') { $split = $set['cup_split']; $pool = cup_pool_usd(); }   //MC 2026-10-12 pools from shop sales
    elseif ($which === 'season') { $split = $set['season_split']; $pool = season_pool_usd(); }
    else return [[], 0];
    $out = []; $k = 0; $cash = cash_top($which);
    foreach ($rows as $i => $r) { if ($k >= count($split)) break; if (!$r['ok']) continue; $out[$i] = $k < $cash ? round($pool * $split[$k] / 100, 2) : 0; $k++; }   // Koban places show no $
    return [$out, $pool];
}

function tglb_left($ts) {
    $s = max(0, $ts - time());
    return $s >= 86400 ? floor($s / 86400) . 'd ' . floor($s % 86400 / 3600) . 'h' : floor($s / 3600) . 'h ' . floor($s % 3600 / 60) . 'm';
}
function tglb_usd($u) { return '$' . (fmod($u, 1) ? number_format($u, 2) : number_format($u, 0)); }

// one player's line on a board
function tglb_line($which, $r, $i, $prize) {
    $medal = ['🥇', '🥈', '🥉'][$i] ?? (($i + 1) . '.');
    $name = '<b>' . tg_h($r['name'] !== '' ? $r['name'] : 'Player') . '</b>' . (!empty($r['holder']) ? ' 💎' : '');
    $bits = [number_format($r['pts']) . ' pts'];
    if (in_array($which, ['league', 'cup', 'season'], true)) {
        $bits[] = $r['n'] . ($r['n'] === 1 ? ' game' : ' games') . ($r['ok'] ? ' ✓' : '');
        if ($prize) $bits[] = '💰 ' . tglb_usd($prize);
    } elseif ($which === 'daily') {
        $bits[] = $r['g'] . ($r['g'] === 1 ? ' Region' : ' Regions') . ($r['r'] === 'win' ? ', won' : ($r['r'] === 'tie' ? ', tied' : ''));
    } else {
        $bits[] = $r['w'] . ' of ' . $r['n'] . ($which === 'live' ? ' live won' : ' won');
    }
    return $medal . ' ' . $name . ' · ' . implode(' · ', $bits);
}

// the message for one board and page. $tgid: who asked (for "you" lines in private chats)
function tglb_view($which, $page, $private, $tgid = '') {
    if (!isset(TGLB_BOARDS[$which])) $which = 'league';
    if ($which === 'friends') return tglb_friends_view($page, $private, $tgid);
    $rows = tglb_rows($which);
    $pages = max(1, (int)ceil(count($rows) / TGLB_PER));
    $page = max(1, min($pages, (int)$page));
    [$prizes, $pool] = tglb_prizes($which, $rows);
    $set = eco_settings();
    $head = ['league' => '🏆 <b>Weekly League</b>', 'cup' => '💎 <b>Holder Cup</b>', 'season' => '🏯 <b>Season ' . season_no() . ' Championship</b>',
        'daily' => '🗓 <b>Daily #' . ((int)floor((strtotime(today() . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1) . '</b>', 'live' => '⚔️ <b>Live matches</b>, all time', 'all' => '📜 <b>All time</b>'][$which];
    $sub = '';
    if ($which === 'league' || $which === 'cup') $sub = tglb_usd($pool) . ' in $SHY · pays out in ' . tglb_left(week_end_ts());
    elseif ($which === 'season') { [, $end] = season_bounds(season_no()); $sub = tglb_usd($pool) . ' in $SHY · ends in ' . tglb_left($end); }
    elseif ($which === 'daily') $sub = 'Same deck for everyone · new one in ' . tglb_left(strtotime(today() . ' 00:00:00 UTC') + 86400);
    elseif ($which === 'live') $sub = 'Real players only. Winning against more of them earns more.';
    else $sub = 'Every verified game counts.';
    $n = count($rows);
    $sub .= ' · ' . $n . ' ' . ($n === 1 ? 'player' : 'players');
    // what each paid place is worth this week, on the first page of a prize board
    if ($page === 1 && in_array($which, ['league', 'cup', 'season'], true)) {
        $split = $set[['league' => 'league_split', 'cup' => 'cup_split', 'season' => 'season_split'][$which]];
        $ord = ['1st', '2nd', '3rd'];
        $sub .= "\nPaid places: " . implode(', ', array_map(fn($pct, $k) => ($ord[$k] ?? ($k + 1) . 'th') . ' ' . tglb_usd(round($pool * $pct / 100, 2)), array_slice($split, 0, 5), array_keys(array_slice($split, 0, 5)))) . (count($split) > 5 ? ' and down to ' . count($split) . 'th' : '');
    }
    $lines = [];
    foreach (array_slice($rows, ($page - 1) * TGLB_PER, TGLB_PER, true) as $i => $r) $lines[] = tglb_line($which, $r, $i, $prizes[$i] ?? 0);
    $text = $head . ($pages > 1 ? ' · page ' . $page . ' of ' . $pages : '') . "\n" . $sub . "\n\n"
        . ($lines ? implode("\n", $lines) : ($which === 'daily' ? "Nobody has played today's Daily yet. Be first." : 'Nobody on this board yet. The top spot is open.'));
    // in a private chat the asker's own place is added under the page
    if ($private && $tgid !== '') {
        $mine = tglb_me($which, $rows, $prizes, $tgid);
        if ($mine) $text .= "\n\n📍 " . $mine;
    }
    if (in_array($which, ['league', 'cup', 'season'], true))
        $text .= "\n\n✓ qualified: " . ($which === 'season' ? $set['min_games'] * 2 : $set['min_games']) . '+ League games and a connected wallet. 💎 holder.';
    // buttons: boards, pages, me, play
    $b = function ($k) use ($which) { return ['text' => ($k === $which ? '• ' : '') . TGLB_BOARDS[$k], 'callback_data' => 'lb:' . $k . ':1']; };
    $kb = [[$b('league'), $b('cup'), $b('season')], [$b('daily'), $b('live'), $b('all')]];
    $nav = [];
    if ($page > 1) $nav[] = ['text' => '◀ Page ' . ($page - 1), 'callback_data' => 'lb:' . $which . ':' . ($page - 1)];
    $nav[] = ['text' => '📍 Me', 'callback_data' => 'lb:' . $which . ':me'];
    if ($page < $pages) $nav[] = ['text' => 'Page ' . ($page + 1) . ' ▶', 'callback_data' => 'lb:' . $which . ':' . ($page + 1)];
    $kb[] = $nav;
    $kb[] = [['text' => '👥 Friends', 'callback_data' => 'lb:friends:1'], $private ? ['text' => '🎴 Play now', 'web_app' => ['url' => TG_SITE . '/play?tgapp=1']] : ['text' => '🎴 Play now', 'url' => tg_app_url()]];
    return ['text' => $text, 'kb' => ['inline_keyboard' => $kb], 'page' => $page];
}

// where a Telegram user stands on a board, in one line (null when they aren't linked)
function tglb_me($which, $rows, $prizes, $tgid) {
    $pid = tg_pid_of($tgid);
    if (!$pid) return null;
    foreach ($rows as $i => $r) {
        if ($r['pid'] !== $pid) continue;
        $s = 'You: #' . ($i + 1) . ' of ' . count($rows) . ' with ' . number_format($r['pts']) . ' pts';
        if (in_array($which, ['league', 'cup', 'season'], true)) {
            $need = ($which === 'season' ? eco_settings()['min_games'] * 2 : eco_settings()['min_games']) - $r['n'];
            if (!empty($prizes[$i])) $s .= ', in the prizes now (' . tglb_usd($prizes[$i]) . ')';
            elseif ($need > 0) $s .= ', ' . $need . ' more ' . ($need === 1 ? 'game' : 'games') . ' to qualify';
            elseif (empty($r['w'])) $s .= ', connect a wallet to win prizes';
            if ($i > 0) $s .= '. ' . number_format($rows[$i - 1]['pts'] - $r['pts'] + 1) . ' pts to pass #' . $i;
        }
        return $s . '.';
    }
    return 'You: not on this board yet.';
}

// a button under the message was pressed: switch board or page, or tell the presser where they stand
function tglb_callback($cb, $token) {
    if (!preg_match('/^lb:([a-z]+):(\d+|me)$/', (string)($cb['data'] ?? ''), $m) || !isset(TGLB_BOARDS[$m[1]])) return false;
    $chat = $cb['message']['chat'] ?? null;
    $private = ($chat['type'] ?? '') === 'private';
    $from = (string)($cb['from']['id'] ?? '');
    // a busy group can't make the bot redraw more than about once a second
    $ok = with_lock(function () use ($chat) { $l = load(LIMITS); $r = rate_ok($l, 'lbcb:' . ($chat['id'] ?? 0), 50, 60); save(LIMITS, $l); return $r; });
    if (!$ok) { tg_api($token, 'answerCallbackQuery', ['callback_query_id' => $cb['id'], 'text' => 'One moment, try again.']); return true; }
    if ($m[2] === 'me' && $m[1] === 'friends') {
        $v = tglb_friends_view(1, false, $from);
        tg_api($token, 'answerCallbackQuery', ['callback_query_id' => $cb['id'], 'text' => $v['me'] ?? 'Link your game profile first: message me privately and send /start.', 'show_alert' => true]);
        return true;
    }
    if ($m[2] === 'me') {
        $rows = tglb_rows($m[1]); [$prizes] = tglb_prizes($m[1], $rows);
        $t = tglb_me($m[1], $rows, $prizes, $from) ?? 'Link your game profile first: message me privately and send /start.';
        tg_api($token, 'answerCallbackQuery', ['callback_query_id' => $cb['id'], 'text' => TGLB_BOARDS[$m[1]] . ' · ' . $t, 'show_alert' => true]);
        return true;
    }
    tg_api($token, 'answerCallbackQuery', ['callback_query_id' => $cb['id']]);
    $v = tglb_view($m[1], (int)$m[2], $private, $from);
    if (isset($cb['message']['message_id'])) echo json_encode(['method' => 'editMessageText', 'chat_id' => $chat['id'], 'message_id' => $cb['message']['message_id'], 'text' => $v['text'], 'parse_mode' => 'HTML', 'reply_markup' => $v['kb'], 'link_preview_options' => ['is_disabled' => true]]);
    else echo '{}';
    return true;
}

// the Friends board: whoever asked and their friends, by points this week. In a group it's the friends of whoever asked.
function tglb_friends_view($page, $private, $tgid) {
    $pid = $tgid !== '' ? tg_pid_of($tgid) : null;
    $back = [[['text' => '🏆 Weekly League', 'callback_data' => 'lb:league:1'], ['text' => '👥 Friends', 'callback_data' => 'lb:friends:1']]];
    $play = [$private ? ['text' => '🎴 Play now', 'web_app' => ['url' => TG_SITE . '/play?tgapp=1&friends=1']] : ['text' => '🎴 Play now', 'url' => tg_app_url('friends')]];
    if (!$pid) return ['text' => "👥 <b>Friends</b>\n\nLink your game profile first: message me privately and send /start. Then add friends in the game and see how you stack up here.", 'kb' => ['inline_keyboard' => array_merge($back, [$play])], 'page' => 1];
    $rows = fr_board($pid);
    $players = load(PLAYERS);
    $me = null;
    foreach ($rows as $i => $r) if ($r['pid'] === $pid) $me = 'You: #' . ($i + 1) . ' of ' . count($rows) . ' with ' . number_format($r['pts']) . ' pts this week' . ($i > 0 ? ', ' . number_format($rows[$i - 1]['pts'] - $r['pts'] + 1) . ' pts to pass ' . $rows[$i - 1]['name'] : '') . '.';
    $pages = max(1, (int)ceil(count($rows) / TGLB_PER));
    $page = max(1, min($pages, (int)$page));
    $lines = [];
    foreach (array_slice($rows, ($page - 1) * TGLB_PER, TGLB_PER, true) as $i => $r)
        $lines[] = (['🥇', '🥈', '🥉'][$i] ?? ($i + 1) . '.') . ' ' . ($r['me'] ? '👉 ' : '') . '<b>' . tg_h($r['name']) . '</b>' . ($r['holder'] ? ' 💎' : '') . ' · ' . number_format($r['pts']) . ' pts';
    $text = '👥 <b>' . tg_h(fr_name($players, $pid)) . "'s friends</b>, this week" . ($pages > 1 ? ' · page ' . $page . ' of ' . $pages : '') . "\n"
        . 'Points from every verified game since Monday · resets in ' . tglb_left(week_end_ts()) . "\n\n"
        . (count($rows) > 1 ? implode("\n", $lines) : implode("\n", $lines) . "\n\nNo friends yet. Add some in the game: open Friends and share your invite link.");
    if ($private && $me) $text .= "\n\n📍 " . $me;
    $nav = [];
    if ($page > 1) $nav[] = ['text' => '◀ Page ' . ($page - 1), 'callback_data' => 'lb:friends:' . ($page - 1)];
    $nav[] = ['text' => '📍 Me', 'callback_data' => 'lb:friends:me'];
    if ($page < $pages) $nav[] = ['text' => 'Page ' . ($page + 1) . ' ▶', 'callback_data' => 'lb:friends:' . ($page + 1)];
    return ['text' => $text, 'kb' => ['inline_keyboard' => array_merge($back, [$nav, $play])], 'page' => $page, 'me' => $me];
}
