<?php
// Friends, challenges and Duels: the shared parts. Used by friends.php (the player API), lb.php (Duel games),
// tgbot.php (the Friends board) and the admin.
//   friends.php   pid => ['f' => friend pid => since, 'in' => requests to me, 'out' => my requests, 'bl' => blocked]
//   notices.php   pid => latest notices, newest first (requests, challenges, Duels)
//   presence.php  pid => last time the site was open
//   duels.php     id  => one Duel: the same deal for two friends, each plays it once
// Functions marked "locked" expect the caller to hold with_lock (it isn't reentrant).
if (!defined('SHY_API')) { http_response_code(404); exit; }
require_once __DIR__ . '/push.php';

define('FRIENDS', DATA_DIR . '/friends.php');
define('NOTICES', DATA_DIR . '/notices.php');
define('PRESENCE', DATA_DIR . '/presence.php');
define('DUELS', DATA_DIR . '/duels.php');
const FR_MAX = 200;            // friends per player
const FR_ONLINE = 150;         // seconds since the site was last open that still counts as online
const LIVE_CHALLENGE_TTL = 600;
const DUEL_TTL = 86400;        // a friend has a day to answer a Duel
const DUEL_SETUP_TTL = 21600;  // the challenger's own run has to finish within the game's 6 hours
const DUEL_OPEN_MAX = 10;      // Duels a player can have waiting at once

function fr_all() { return load(FRIENDS); }
function fr_of($all, $pid) { return ($all[$pid] ?? []) + ['f' => [], 'in' => [], 'out' => [], 'bl' => []]; }
function fr_are($all, $a, $b) { return isset(fr_of($all, $a)['f'][$b]); }
function fr_tag($pid) { return substr($pid, 0, 6); }
function fr_name($players, $pid) { $n = $players[$pid]['name'] ?? ''; return $n !== '' ? $n : 'Player ' . strtoupper(fr_tag($pid)); }
function fr_online($pres, $pid) { return (time() - (int)($pres[$pid] ?? 0)) < FR_ONLINE; }
//MC 2026-10-09 Online now: every named player with the site open in the last FR_ONLINE seconds, newest first. Players who
//turned off "Show me as online" never get a presence entry (friends.php poll skips them), so they don't show anywhere.
function fr_online_list($pres, $players) {
    $t = time(); $out = [];
    foreach ($pres as $p => $ts) if ($t - (int)$ts < FR_ONLINE && !empty($players[$p]['name']) && empty($players[$p]['hideon'])) $out[$p] = (int)$ts;
    arsort($out);
    return $out;
}
// the 6-letter tags of everyone online, for the green dots on leaderboards and player pages
function fr_online_tags($players) { $o = []; foreach (fr_online_list(load(PRESENCE), $players) as $p => $_) $o[substr($p, 0, 6)] = 1; return $o; }

// find a player from what someone typed: a player name, a 6-letter player id, or an invite link with ?friend=
function fr_find($players, $q) {
    $q = trim($q);
    if (preg_match('#[?&]friend=([a-f0-9]{6})#i', $q, $m)) $q = $m[1];
    $q = ltrim($q, '#@ ');
    if ($q === '') return null;
    if (preg_match('/^[a-f0-9]{6}$/i', $q)) foreach ($players as $pid => $p) if (fr_tag($pid) === strtolower($q) && !empty($p['name'])) return $pid;
    foreach ($players as $pid => $p) if (strcasecmp($p['name'] ?? '', $q) === 0) return $pid;
    return null;
}

// ---------------------------------------------------------------- notices (locked)
// one notice to a player: kept on the site, sent to their Telegram if they linked it and want these,
// and pushed to their browser if they turned notifications on. $tg = [html, keyboard] or null.
function fr_notify($pid, $kind, $from, $data, $tg = null, $push = null) {
    $all = load(NOTICES);
    $list = $all[$pid] ?? [];
    // one live challenge or Duel notice per friend at a time: the newest replaces the old one
    $list = array_values(array_filter($list, fn($n) => !($n['k'] === $kind && $n['from'] === $from && in_array($kind, ['live', 'req', 'duel'], true))));
    array_unshift($list, ['id' => bin2hex(random_bytes(4)), 'k' => $kind, 'from' => $from, 'd' => $data, 'ts' => time(), 'seen' => false]);
    $all[$pid] = array_slice($list, 0, 30);
    save(NOTICES, $all);
    if ($tg) {
        $u = tg_user_of($pid);
        if ($u && !empty($u['dm']) && !empty(tg_notes($u)['friends'])) tg_dm($u['id'], $tg[0], $tg[1] ?? null);
    }
    if ($push) push_queue($pid, $push);
}
// what's still worth showing: live challenges last 10 minutes, everything else a week
function fr_notices_live($list) {
    return array_values(array_filter($list, fn($n) => time() - $n['ts'] < ($n['k'] === 'live' ? LIVE_CHALLENGE_TTL : 7 * 86400)));
}

// ---------------------------------------------------------------- Duels
function duel_seed() { return random_int(0, 0xffffffff); }
// tidy the Duel list: unplayed setups and unanswered Duels run out (locked; returns the Duels)
function duels_tidy() {
    $d = load(DUELS); $now = time(); $changed = false;
    foreach ($d as $id => &$x) {
        if ($x['st'] === 'new' && $now - $x['ts'] > DUEL_SETUP_TTL) { unset($d[$id]); $changed = true; continue; }
        if ($x['st'] === 'open' && $now > $x['exp']) { $x['st'] = 'expired'; $changed = true; }
        if (in_array($x['st'], ['done', 'expired', 'declined'], true) && $now - ($x['end'] ?? $x['exp'] ?? $x['ts']) > 30 * 86400) { unset($d[$id]); $changed = true; }
    }
    unset($x);
    if ($changed) save(DUELS, $d);
    return $d;
}
// who won: more Regions, then more points, otherwise a tie. 'a' is the challenger.
function duel_winner($x) {
    $ka = [$x['ra']['g'], $x['ra']['p']]; $kb = [$x['rb']['g'], $x['rb']['p']];
    return $ka === $kb ? 'tie' : ($ka > $kb ? 'a' : 'b');
}
// head to head between two players: [my wins, their wins, ties]
function duel_record($duels, $me, $them) {
    $w = $l = $t = 0;
    foreach ($duels as $x) {
        if ($x['st'] !== 'done') continue;
        if (!(($x['a'] === $me && $x['b'] === $them) || ($x['a'] === $them && $x['b'] === $me))) continue;
        if ($x['w'] === 'tie') $t++;
        elseif (($x['w'] === 'a') === ($x['a'] === $me)) $w++; else $l++;
    }
    return [$w, $l, $t];
}
// a Duel as the player sees it
function duel_view($x, $id, $me, $players) {
    $mine = $x['a'] === $me ? 'a' : 'b'; $them = $mine === 'a' ? $x['b'] : $x['a'];
    $r = fn($s) => $x['r' . $s] ? ['g' => $x['r' . $s]['g'], 'r' => $x['r' . $s]['r'], 'p' => $x['r' . $s]['p']] : null;
    $turn = ($x['st'] === 'new' && $mine === 'a') || ($x['st'] === 'open' && $mine === 'b' && !$x['rb']);
    return ['id' => $id, 'vs' => fr_tag($them), 'vsName' => fr_name($players, $them), 'st' => $x['st'], 'mine' => $r($mine), 'theirs' => $x['st'] === 'done' ? $r($mine === 'a' ? 'b' : 'a') : null,
        'target' => $mine === 'b' && $x['ra'] ? $x['ra']['g'] : null, 'turn' => $turn, 'won' => $x['st'] === 'done' ? ($x['w'] === 'tie' ? 'tie' : ($x['w'] === $mine ? 'me' : 'them')) : null,
        'exp' => $x['exp'] ?? 0, 'ts' => $x['ts'], 'challenger' => $mine === 'a', 'off' => !empty($x['off'])];
}
// a Duel run was verified (called by lb.php's submit inside its lock). Returns what the player's end screen shows.
function duel_scored($id, $pid, $regions, $result, $points) {
    $d = load(DUELS);
    $x = $d[$id] ?? null;
    if (!$x) return null;
    $side = $x['a'] === $pid ? 'a' : ($x['b'] === $pid ? 'b' : null);
    if (!$side || !empty($x['r' . $side])) return null;
    // a Duel counts only while it's live: set up (challenger), or open (friend; a run started before the deadline gets 30 minutes more)
    if ($side === 'a' && $x['st'] !== 'new') return null;
    if ($side === 'b' && !($x['st'] === 'open' || ($x['st'] === 'expired' && time() <= ($x['exp'] ?? 0) + 1800))) return null;
    if (!fr_are(fr_all(), $x['a'], $x['b'])) return null;
    $players = load(PLAYERS);
    $x['r' . $side] = ['g' => $regions, 'r' => $result, 'p' => $points, 'ts' => time()];
    $out = ['id' => $id, 'vsName' => fr_name($players, $side === 'a' ? $x['b'] : $x['a'])];
    if ($side === 'a') {
        $x['st'] = 'open'; $x['exp'] = time() + DUEL_TTL;
        $who = fr_name($players, $x['a']);
        $url = TG_SITE . '/play?duel=' . $id . '&go=1';   //MC 2026-10-10 tapping the notification is the yes, no second "Play now"
        fr_notify($x['b'], 'duel', $x['a'], ['id' => $id, 'g' => $regions],
            ['⚔️ <b>' . tg_h($who) . '</b> challenged you to a Duel in Shilluminati Online: the same deal, one shot each. Beat <b>' . $regions . ' ' . ($regions === 1 ? 'Region' : 'Regions') . '</b> within 24 hours.', tg_kb('⚔️ Play the Duel', 'duel_' . $id)],
            ['title' => $who . ' challenged you to a Duel', 'body' => 'Same deal, one shot each. Beat ' . $regions . ' ' . ($regions === 1 ? 'Region' : 'Regions') . ' within 24 hours.', 'url' => $url]);
        $out['sent'] = true;
    } else {
        $x['st'] = 'done'; $x['end'] = time(); $x['w'] = duel_winner($x);
        $a = fr_name($players, $x['a']); $b = fr_name($players, $x['b']);
        $ga = $x['ra']['g']; $gb = $x['rb']['g'];
        $line = $x['w'] === 'tie' ? "It's a tie, $ga to $gb." : ($x['w'] === 'a' ? "You won, $ga to $gb." : "$b won, $gb to $ga.");
        fr_notify($x['a'], 'duelres', $x['b'], ['id' => $id, 'w' => $x['w'] === 'a' ? 'me' : ($x['w'] === 'tie' ? 'tie' : 'them'), 'mine' => $ga, 'theirs' => $gb],
            ['⚔️ <b>' . tg_h($b) . '</b> played your Duel. ' . tg_h($line), tg_kb('🔁 Rematch', 'duelvs_' . fr_tag($x['b']))],
            ['title' => 'Duel with ' . $b . ' is done', 'body' => $line, 'url' => TG_SITE . '/play?duelvs=' . fr_tag($x['b'])]);
        if ($x['w'] !== 'tie') duel_mission($x['w'] === 'a' ? $x['a'] : $x['b']);
        $out += ['done' => true, 'won' => $x['w'] === 'tie' ? 'tie' : ($x['w'] === 'b' ? 'me' : 'them'), 'mine' => $gb, 'theirs' => $ga];
    }
    $d[$id] = $x;
    save(DUELS, $d);
    return $out;
}
// a Duel win counts toward the weekly Duel mission when it's on this week's sheet (locked)
function duel_mission($pid) {
    $eco = load(ECO);
    $a = eco_get($eco, $pid);
    missions_week_init($a);
    foreach (array_merge($a['ms']['ids'], bounties_week()) as $id) {
        if ($id !== 'fd2') continue;
        $m = mission_def($id);
        $a['ms']['p'][$id] = min($m['goal'], (int)($a['ms']['p'][$id] ?? 0) + 1);
        mission_pay($a, $id);
    }
    $eco[$pid] = $a; save(ECO, $eco);
}

// the Friends board: a player and their friends, by points this week (locked or not, read-only)
function fr_board($pid) {
    $players = load(PLAYERS); $all = fr_all(); $wk = week_key();
    $ids = array_merge([$pid], array_keys(fr_of($all, $pid)['f']));
    $rows = [];
    foreach ($ids as $id) {
        if (!isset($players[$id])) continue;
        $p = $players[$id];
        $rows[] = ['pid' => $id, 'name' => fr_name($players, $id), 'pts' => ($p['wk'] ?? '') === $wk ? (int)($p['wpts'] ?? 0) : 0, 'w' => (int)($p['wins'] ?? 0), 'n' => (int)($p['games'] ?? 0), 'holder' => !empty($p['holder']), 'me' => $id === $pid];
    }
    usort($rows, fn($x, $y) => [$y['pts'], $y['w']] <=> [$x['pts'], $x['w']]);
    return $rows;
}

// end every unfinished Duel between two players (locked): when one removes or blocks the other
function duels_cancel($p, $q) {
    $d = load(DUELS); $n = 0;
    foreach ($d as $id => $x) if (in_array($x['st'], ['new', 'open'], true) && (($x['a'] === $p && $x['b'] === $q) || ($x['a'] === $q && $x['b'] === $p))) { $d[$id]['st'] = 'declined'; $d[$id]['off'] = 1; $d[$id]['end'] = time(); $n++; }   //MC 2026-10-10 off: nobody passed, the friendship ended
    if ($n) save(DUELS, $d);
}
