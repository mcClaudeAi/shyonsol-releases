<?php
// Digital Asset Links for the Android app (the dApp Store build): tells Android the app and shyonsol.io belong
// together, so the app opens the site full screen with no browser bar. Served at /.well-known/assetlinks.json.
//MC 2026-10-15 a script rather than a file because site updates leave the .well-known folder alone. The fingerprint
//   is the public SHA-256 of the app's signing certificate (safe to publish; the key itself never leaves the owner).
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=3600');
const APP_PACKAGE = 'io.shyonsol.twa';
const APP_SHA256 = ['39:33:53:D0:CE:9E:E1:FB:CF:74:DF:D0:45:BA:9B:58:2B:BE:B7:C6:80:94:E2:B1:6B:B3:0A:E8:2B:29:CE:E3'];
echo json_encode([['relation' => ['delegate_permission/common.handle_all_urls'],
    'target' => ['namespace' => 'android_app', 'package_name' => APP_PACKAGE, 'sha256_cert_fingerprints' => APP_SHA256]]], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
