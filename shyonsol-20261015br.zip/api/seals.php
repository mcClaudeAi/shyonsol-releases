<?php
// The five seals: a sitewide hunt. One kanji seal hides on each of five pages; find all five and the site pays
// 900 Koban, once per player. The client (assets/eggs.js) tracks the hunt; this endpoint only pays the finish.
// POST {pid, key} -> {ok, koban} once, then {ok:false, error} ever after.
//MC 2026-10-13 built with the easter egg release. The claim needs a real signed-in player with at least one finished
//   game, so a fresh browser can't farm it by clearing storage: the reward is flagged on the shop account, not the client.

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 500) fail('too large');
$body = json_decode($raw, true) ?: [];
$pid = (string)($body['pid'] ?? '');
$key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('Play one game first, then the seals will answer.', 403);

$res = with_lock(function () use ($pid, $key) {
    $limits = load(LIMITS);
    if (!rate_ok($limits, 'seals:' . client_ip(), 20, 3600)) { save(LIMITS, $limits); return ['err' => 'Slow down a little and try again.', 'code' => 429]; }
    save(LIMITS, $limits);
    $players = load(PLAYERS);
    $holders = load(HOLDERS);
    $kh = hash('sha256', $key);
    if (!isset($players[$pid]) || !key_ok($pid, $kh, $players, $holders)) return ['err' => 'Play one game first, then the seals will answer.', 'code' => 403];
    if ((int)($players[$pid]['games'] ?? 0) < 1 && empty($players[$pid]['hist'])) return ['err' => 'Play one game first, then the seals will answer.', 'code' => 403];
    $eco = load(ECO);
    $a = eco_get($eco, $pid);
    if (!empty($a['seals'])) return ['err' => 'Already claimed. The seals only join once.', 'code' => 409];
    $a['seals'] = time();
    eco_credit($a, 900, 'Found the five seals');
    $eco[$pid] = $a;
    save(ECO, $eco);
    return ['koban' => 900];
});
if (isset($res['err'])) fail($res['err'], $res['code']);
out(['ok' => true, 'koban' => $res['koban']]);
