<?php
// First visit of a browser, for the admin's player funnel: where they came from. No cookies, nothing personal:
// the random player id the game already keeps in the browser, the day, and a source like "x" or "telegram".
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$pid = (string)($b['pid'] ?? '');
$src = strtolower(preg_replace('/[^a-z0-9.-]/i', '', substr((string)($b['src'] ?? ''), 0, 40)));
if (!preg_match('/^[a-f0-9]{16}$/', $pid)) fail('bad player');
$ok = with_lock(function () use ($pid, $src) {
    $l = load(LIMITS); $r = rate_ok($l, 'fv:' . client_ip(), 30, 3600); save(LIMITS, $l);
    if (!$r) return false;
    // someone who already played before tracking began isn't a new visitor
    if (!empty(load(PLAYERS)[$pid]['games'])) return true;
    funnel_mark($pid, 'v', $src);
    return true;
});
out(['ok' => (bool)$ok]);
