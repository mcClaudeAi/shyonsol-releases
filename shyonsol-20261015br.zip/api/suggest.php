<?php
// Player suggestions: anyone can send one (with an optional screenshot), the team reads them in the admin and by email,
// and the ones the team makes public show on the Ideas board where players vote.
// POST a=send  {pid, key, cat, text, contact, page, lang (the site language), img (data URL, optional), hp}
// GET  ?a=board&me=PID6         -> public ideas
// POST a=vote  {pid, key, id}   -> toggle a vote

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/ideas.php';

//MC 2026-10-13 the board answers HERE, before the heavy shop and holder stack below ever loads, from a 30 second
//   cache. A "Cast your vote" post in Telegram sends a crowd to this endpoint inside the same minute, and on shared
//   hosting that crowd was saturating the PHP workers (the whole site answered 504, static pages included). Now the
//   first visitor builds the list and everyone behind them gets the cached copy: one cheap read, no requires beyond
//   common. Voter tags are kept in the cache (server side only) so each visitor still gets their own "mine" flags.
//   A vote or an admin status change clears the cache, so the board never lags a change by more than one request.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['a'] ?? '') === 'board') {
    $me = (string)($_GET['me'] ?? '');
    $cf = DATA_DIR . '/cache-ideas-board.php';
    $c = load($cf);
    if (empty($c['t']) || time() - (int)$c['t'] > 30) {
        $list = []; $v6 = [];
        foreach (load(IDEAS) as $id => $s) {
            if (empty($s['public'])) continue;
            $votes = $s['votes'] ?? [];
            $list[] = ['id' => $id, 'cat' => $s['cat'], 'title' => $s['title'] ?: idea_title($s['text']), 'text' => $s['ptext'] ?: $s['text'], 'status' => $s['status'],
                'reply' => $s['reply'] ?? '', 'votes' => count($votes) + 1, 'mine' => false, 'ts' => $s['ts'], 'by' => $s['credit'] ?? ''];
            $v6[$id] = array_map(fn($v) => substr($v, 0, 6), $votes);
        }
        $rank = ['vote' => 0, 'planned' => 1, 'building' => 2, 'reviewing' => 3, 'new' => 4, 'shipped' => 5, 'declined' => 6];   // community-vote ideas lead the board
        usort($list, fn($x, $y) => [$rank[$x['status']] ?? 9, -$x['votes'], -$x['ts']] <=> [$rank[$y['status']] ?? 9, -$y['votes'], -$y['ts']]);
        $c = ['t' => time(), 'list' => $list, 'v6' => $v6];
        save($cf, $c);
    }
    $list = $c['list'];
    if ($me !== '') { foreach ($list as &$x) $x['mine'] = in_array($me, $c['v6'][$x['id']] ?? [], true); unset($x); }
    header('Cache-Control: public, max-age=60');
    out(['ok' => true, 'ideas' => $list]);
}

require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/translate.php';

$a = $_GET['a'] ?? '';
$body = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    if (strlen($raw) > 3200000) fail('That screenshot is too big. Try one under 2 MB.', 413);
    $body = json_decode($raw, true) ?: [];
    $a = (string)($body['a'] ?? '');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$pid = (string)($body['pid'] ?? ''); $key = (string)($body['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);

if ($a === 'send') {
    // bots fill every field, people never see this one
    if (!empty($body['hp'])) out(['ok' => true, 'id' => 'x']);
    $cat = array_key_exists((string)($body['cat'] ?? ''), IDEA_CATS) ? $body['cat'] : 'other';
    $text = trim(preg_replace("/\r\n?/", "\n", (string)($body['text'] ?? '')));
    $text = preg_replace("/\n{3,}/", "\n\n", $text);
    if (mb_strlen($text) < 10) fail('Tell us a little more, at least a sentence.');
    if (mb_strlen($text) > 1500) fail('That one is a bit long. Keep it under 1,500 characters.');
    $contact = mb_substr(trim((string)($body['contact'] ?? '')), 0, 80);
    $page = preg_match('#^/[a-z0-9/_\-]*$#i', (string)($body['page'] ?? '')) ? $body['page'] : '';
    // optional screenshot: PNG, JPEG or WebP, re-checked from the bytes, at most 2 MB
    $img = null;
    if (!empty($body['img'])) {
        if (!preg_match('#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$#', (string)$body['img'], $m)) fail('Screenshots can be PNG, JPG or WebP.');
        $bytes = base64_decode($m[2], true);
        if ($bytes === false || strlen($bytes) > 2 * 1024 * 1024) fail('That screenshot is too big. Try one under 2 MB.', 413);
        $info = @getimagesizefromstring($bytes);
        if (!$info || !in_array($info['mime'], ['image/png', 'image/jpeg', 'image/webp'], true)) fail("That file doesn't look like an image.");
        $img = ['bytes' => $bytes, 'ext' => ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'][$info['mime']]];
    }
    $res = with_lock(function () use ($pid, $kh, $cat, $text, $contact, $page, $img) {
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'idea:' . client_ip(), 6, 3600) || !rate_ok($limits, 'idea:' . $pid, 12, 86400)) { save(LIMITS, $limits); return ['err' => "You've sent a lot of ideas today. Thank you! Try again a bit later.", 'code' => 429]; }
        save(LIMITS, $limits);
        $players = load(PLAYERS);
        if (!key_ok($pid, $kh, $players)) return ['err' => 'not your profile', 'code' => 403];
        $ideas = load(IDEAS);
        $id = bin2hex(random_bytes(5));
        $file = '';
        if ($img) {
            if (!is_dir(IDEA_FILES)) @mkdir(IDEA_FILES, 0755, true);
            $file = $id . '.' . $img['ext'];
            if (@file_put_contents(IDEA_FILES . '/' . $file, $img['bytes']) === false) $file = '';
        }
        $h = load(HOLDERS)[$pid] ?? [];
        $ideas[$id] = ['ts' => time(), 'pid' => $pid, 'name' => $players[$pid]['name'] ?? '', 'wallet' => $h['wallet'] ?? '', 'x' => $players[$pid]['xu'] ?? '',
            'cat' => $cat, 'text' => $text, 'contact' => $contact, 'page' => $page, 'file' => $file, 'status' => 'new', 'public' => false,
            'title' => '', 'ptext' => '', 'reply' => '', 'votes' => [], 'note' => ''];
        // newest first, and the store stays a sensible size
        uasort($ideas, fn($x, $y) => $y['ts'] <=> $x['ts']);
        if (count($ideas) > 2000) {
            foreach (array_slice($ideas, 2000, null, true) as $old => $o) { if (empty($o['public']) && !empty($o['file'])) @unlink(IDEA_FILES . '/' . $o['file']); }
            $ideas = array_slice($ideas, 0, 2000, true);
        }
        save(IDEAS, $ideas);
        return ['id' => $id, 'idea' => $ideas[$id]];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    // not in English: keep an English translation with it, for the email and the admin
    $ui = preg_match('/^[a-z]{2}$/', (string)($body['lang'] ?? '')) ? $body['lang'] : 'en';
    $res['idea'] = idea_translate($res['id'], $res['idea'], $ui);
    idea_email($res['id'], $res['idea']);
    track('ideas');
    out(['ok' => true, 'id' => $res['id']]);
}

if ($a === 'vote') {
    $id = (string)($body['id'] ?? '');
    $res = with_lock(function () use ($pid, $kh, $id) {
        if (!key_ok($pid, $kh)) return ['err' => 'not your profile', 'code' => 403];
        $limits = load(LIMITS);
        if (!rate_ok($limits, 'vote:' . client_ip(), 120, 3600)) { save(LIMITS, $limits); return ['err' => 'Slow down a little.', 'code' => 429]; }
        save(LIMITS, $limits);
        $ideas = load(IDEAS);
        if (empty($ideas[$id]['public'])) return ['err' => 'That idea is not on the board.', 'code' => 404];
        if ($ideas[$id]['pid'] === $pid) return ['err' => 'Your own idea already counts your vote.', 'code' => 400];
        $v = $ideas[$id]['votes'] ?? [];
        $i = array_search($pid, $v, true);
        if ($i === false) $v[] = $pid; else array_splice($v, $i, 1);
        $ideas[$id]['votes'] = $v;
        save(IDEAS, $ideas);
        @unlink(DATA_DIR . '/cache-ideas-board.php');   //MC 2026-10-13 the next board read rebuilds with this vote in it
        return ['votes' => count($v) + 1, 'mine' => $i === false];
    });
    if (isset($res['err'])) fail($res['err'], $res['code']);
    out(['ok' => true] + $res);
}

fail('unknown action');
