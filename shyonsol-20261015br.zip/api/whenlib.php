<?php
//MC 2026-10-10 When and where people play, for the Stats page and the admin Overview. Everything here is counts:
//   games by hour of the week (from the daily tallies in stats.php), games by hour for the last month, players online
//   now, and players by region from the time zone their browser reports (api/where.php). Nothing per player leaves
//   this file: a region needs RX_MIN players before it shows, and its peak hours need RX_MIN_HOURS.
//   Include after common.php and statslib.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const RX_MIN = 3;          // fewest players a region, country or language needs before it's shown on its own
const RX_MIN_HOURS = 5;    // fewest players before a region's hours are shown
const RX_ACTIVE = 90;      // only players who played in the last 90 days count toward regions
define('RX_GEO', DATA_DIR . '/geo.php');   // ['since' => first time zone saved]

// time zone -> [region, country, continent]. Big countries with several zones get a part of the country as their
// region; anything not listed falls back to its continent (the first part of the zone name).
function rx_place($tz) {
    static $map = null;
    if ($map === null) {
        $map = [];
        $put = function ($zones, $region, $country, $cont) use (&$map) { foreach (explode(' ', $zones) as $z) $map[$z] = [$region, $country, $cont]; };
        $put('America/New_York America/Detroit America/Indiana/Indianapolis America/Indianapolis America/Kentucky/Louisville America/Louisville America/Indiana/Vincennes America/Indiana/Winamac America/Indiana/Marengo America/Indiana/Petersburg America/Indiana/Vevay America/Kentucky/Monticello America/Fort_Wayne US/Eastern US/Michigan EST5EDT', 'United States (East)', 'United States', 'am');
        $put('America/Chicago America/Indiana/Knox America/Indiana/Tell_City America/Menominee America/North_Dakota/Center America/North_Dakota/New_Salem America/North_Dakota/Beulah US/Central CST6CDT', 'United States (Central)', 'United States', 'am');
        $put('America/Denver America/Boise America/Phoenix US/Mountain US/Arizona MST7MDT MST', 'United States (Mountain)', 'United States', 'am');
        $put('America/Los_Angeles US/Pacific PST8PDT', 'United States (West)', 'United States', 'am');
        $put('America/Anchorage America/Juneau America/Sitka America/Nome America/Yakutat America/Metlakatla US/Alaska Pacific/Honolulu US/Hawaii', 'Alaska and Hawaii', 'United States', 'am');
        $put('America/Toronto America/Montreal America/Vancouver America/Edmonton America/Winnipeg America/Halifax America/St_Johns America/Regina America/Moncton America/Whitehorse America/Yellowknife America/Iqaluit America/Glace_Bay America/Goose_Bay America/Swift_Current America/Dawson_Creek', 'Canada', 'Canada', 'am');
        $put('America/Mexico_City America/Cancun America/Monterrey America/Tijuana America/Chihuahua America/Hermosillo America/Mazatlan America/Merida America/Matamoros America/Bahia_Banderas America/Ciudad_Juarez America/Ojinaga', 'Mexico', 'Mexico', 'am');
        $put('America/Sao_Paulo America/Fortaleza America/Recife America/Bahia America/Belem America/Manaus America/Cuiaba America/Campo_Grande America/Porto_Velho America/Boa_Vista America/Araguaina America/Maceio America/Rio_Branco America/Noronha America/Santarem Brazil/East', 'Brazil', 'Brazil', 'am');
        $put('America/Argentina/Buenos_Aires America/Buenos_Aires America/Argentina/Cordoba America/Cordoba America/Argentina/Mendoza America/Argentina/Salta America/Argentina/Tucuman America/Argentina/Jujuy America/Argentina/San_Luis America/Argentina/Ushuaia', 'Argentina', 'Argentina', 'am');
        $put('America/Bogota', 'Colombia', 'Colombia', 'am');
        $put('America/Lima', 'Peru', 'Peru', 'am');
        $put('America/Santiago', 'Chile', 'Chile', 'am');
        $put('America/Caracas', 'Venezuela', 'Venezuela', 'am');
        $put('America/Guayaquil', 'Ecuador', 'Ecuador', 'am');
        $put('America/Puerto_Rico America/Santo_Domingo America/Havana America/Jamaica America/Port_of_Spain America/Panama America/Costa_Rica America/Guatemala America/El_Salvador America/Tegucigalpa America/Managua America/Belize America/Barbados America/Nassau America/Port-au-Prince America/Curacao America/Aruba', 'Central America and the Caribbean', 'Central America and the Caribbean', 'am');
        $put('Europe/London Europe/Belfast GB', 'United Kingdom', 'United Kingdom', 'eu');
        $put('Europe/Dublin', 'Ireland', 'Ireland', 'eu');
        $put('Europe/Lisbon Atlantic/Madeira Atlantic/Azores', 'Portugal', 'Portugal', 'eu');
        $put('Europe/Madrid Atlantic/Canary Africa/Ceuta', 'Spain', 'Spain', 'eu');
        $put('Europe/Paris', 'France', 'France', 'eu');
        $put('Europe/Brussels', 'Belgium', 'Belgium', 'eu');
        $put('Europe/Amsterdam', 'Netherlands', 'Netherlands', 'eu');
        $put('Europe/Berlin Europe/Busingen', 'Germany', 'Germany', 'eu');
        $put('Europe/Zurich', 'Switzerland', 'Switzerland', 'eu');
        $put('Europe/Vienna', 'Austria', 'Austria', 'eu');
        $put('Europe/Rome', 'Italy', 'Italy', 'eu');
        $put('Europe/Warsaw', 'Poland', 'Poland', 'eu');
        $put('Europe/Prague', 'Czechia', 'Czechia', 'eu');
        $put('Europe/Budapest', 'Hungary', 'Hungary', 'eu');
        $put('Europe/Stockholm Europe/Oslo Europe/Copenhagen Europe/Helsinki Atlantic/Reykjavik', 'Nordics', 'Nordics', 'eu');
        $put('Europe/Athens', 'Greece', 'Greece', 'eu');
        $put('Europe/Bucharest', 'Romania', 'Romania', 'eu');
        $put('Europe/Sofia', 'Bulgaria', 'Bulgaria', 'eu');
        $put('Europe/Kyiv Europe/Kiev Europe/Uzhgorod Europe/Zaporozhye', 'Ukraine', 'Ukraine', 'eu');
        $put('Europe/Istanbul Asia/Istanbul', 'Türkiye', 'Türkiye', 'eu');
        $put('Europe/Belgrade Europe/Zagreb Europe/Ljubljana Europe/Sarajevo Europe/Skopje Europe/Podgorica Europe/Tirane', 'Balkans', 'Balkans', 'eu');
        $put('Europe/Moscow Europe/Kaliningrad Europe/Samara Europe/Volgograd Europe/Saratov Europe/Ulyanovsk Europe/Astrakhan Europe/Kirov Asia/Yekaterinburg Asia/Omsk Asia/Novosibirsk Asia/Barnaul Asia/Tomsk Asia/Novokuznetsk Asia/Krasnoyarsk Asia/Irkutsk Asia/Chita Asia/Yakutsk Asia/Khandyga Asia/Vladivostok Asia/Ust-Nera Asia/Magadan Asia/Sakhalin Asia/Srednekolymsk Asia/Kamchatka Asia/Anadyr', 'Russia', 'Russia', 'eu');
        $put('Asia/Dubai Asia/Muscat', 'United Arab Emirates', 'United Arab Emirates', 'as');
        $put('Asia/Riyadh Asia/Qatar Asia/Bahrain Asia/Kuwait', 'Gulf states', 'Gulf states', 'as');
        $put('Asia/Jerusalem Asia/Tel_Aviv', 'Israel', 'Israel', 'as');
        $put('Asia/Tehran', 'Iran', 'Iran', 'as');
        $put('Asia/Karachi', 'Pakistan', 'Pakistan', 'as');
        $put('Asia/Kolkata Asia/Calcutta', 'India', 'India', 'as');
        $put('Asia/Dhaka', 'Bangladesh', 'Bangladesh', 'as');
        $put('Asia/Kathmandu Asia/Katmandu', 'Nepal', 'Nepal', 'as');
        $put('Asia/Colombo', 'Sri Lanka', 'Sri Lanka', 'as');
        $put('Asia/Bangkok', 'Thailand', 'Thailand', 'as');
        $put('Asia/Ho_Chi_Minh Asia/Saigon', 'Vietnam', 'Vietnam', 'as');
        $put('Asia/Jakarta Asia/Pontianak Asia/Makassar Asia/Jayapura', 'Indonesia', 'Indonesia', 'as');
        $put('Asia/Kuala_Lumpur Asia/Kuching', 'Malaysia', 'Malaysia', 'as');
        $put('Asia/Singapore', 'Singapore', 'Singapore', 'as');
        $put('Asia/Manila', 'Philippines', 'Philippines', 'as');
        $put('Asia/Shanghai Asia/Chongqing Asia/Chungking Asia/Harbin Asia/Urumqi PRC', 'China', 'China', 'as');
        $put('Asia/Hong_Kong Asia/Macau', 'Hong Kong and Macau', 'Hong Kong and Macau', 'as');
        $put('Asia/Taipei', 'Taiwan', 'Taiwan', 'as');
        $put('Asia/Seoul', 'South Korea', 'South Korea', 'as');
        $put('Asia/Tokyo Japan', 'Japan', 'Japan', 'as');
        $put('Africa/Lagos', 'Nigeria', 'Nigeria', 'af');
        $put('Africa/Cairo Egypt', 'Egypt', 'Egypt', 'af');
        $put('Africa/Johannesburg', 'South Africa', 'South Africa', 'af');
        $put('Africa/Nairobi', 'Kenya', 'Kenya', 'af');
        $put('Africa/Accra', 'Ghana', 'Ghana', 'af');
        $put('Africa/Casablanca', 'Morocco', 'Morocco', 'af');
        $put('Australia/Sydney Australia/Melbourne Australia/Brisbane Australia/Perth Australia/Adelaide Australia/Hobart Australia/Darwin Australia/Canberra Australia/ACT Australia/NSW Australia/Victoria Australia/Queensland Australia/West Australia/South Australia/Lindeman Australia/Broken_Hill', 'Australia', 'Australia', 'oc');
        $put('Pacific/Auckland Pacific/Chatham NZ', 'New Zealand', 'New Zealand', 'oc');
    }
    if (isset($map[$tz])) return $map[$tz];
    if ($tz === 'UTC' || $tz === 'Etc/UTC' || $tz === 'Etc/GMT' || $tz === 'GMT' || strpos($tz, 'Etc/') === 0) return ['Time zone hidden', 'Time zone hidden', 'xx'];
    $c = ['America' => 'am', 'Europe' => 'eu', 'Asia' => 'as', 'Africa' => 'af', 'Australia' => 'oc', 'Pacific' => 'oc', 'Atlantic' => 'eu', 'Indian' => 'as', 'Antarctica' => 'oc'][explode('/', $tz)[0]] ?? 'xx';
    $n = rx_cont_name($c);
    return [$n, $n, $c];
}
function rx_cont_name($c) { return ['am' => 'Elsewhere in the Americas', 'eu' => 'Elsewhere in Europe', 'as' => 'Elsewhere in Asia', 'af' => 'Africa', 'oc' => 'Oceania', 'xx' => 'Time zone hidden'][$c] ?? 'Other places'; }

// a zone name a browser could have sent: Area/City, Area/Region/City, or a short legacy name like UTC
function rx_tz_ok($tz) {
    static $ok = null;
    if (!is_string($tz) || strlen($tz) > 40 || !preg_match('#^[A-Za-z][A-Za-z0-9_+\-]*(/[A-Za-z0-9_+\-]+){0,2}$#', $tz)) return false;
    if ($ok === null) $ok = array_flip(DateTimeZone::listIdentifiers(DateTimeZone::ALL_WITH_BC));
    return isset($ok[$tz]);
}
function rx_offset($tz, $now) { try { return (int)round((new DateTimeZone($tz))->getOffset(new DateTime('@' . $now)) / 60); } catch (Exception $e) { return 0; } }

// $detail is for the admin Overview: no minimums, and the raw time zones and languages
function rx_build($players, $st, $detail = false) {
    $now = time(); $nowH = intdiv($now, 3600) * 3600;
    $days = $st['d'] ?? [];
    $since = (int)($st['since'] ?? 0);
    $sinceDay = $since ? gmdate('Y-m-d', $since) : gmdate('Y-m-d');

    // games by hour of the week (UTC, Sunday 00:00 first) over the last 4 and 12 weeks, per layer
    $heat = ['w' => [4, 12]];
    foreach ([4, 12] as $wi => $w) {
        $g = $l = $dd = array_fill(0, 168, 0); $dn = array_fill(0, 7, 0);
        for ($i = 0; $i < $w * 7; $i++) {
            $d = gmdate('Y-m-d', $now - $i * 86400);
            if ($d < $sinceDay) break;
            $dow = (int)gmdate('w', $now - $i * 86400); $dn[$dow]++;
            $x = $days[$d] ?? null; if (!$x) continue;
            for ($h = 0; $h < 24; $h++) { $k = $dow * 24 + $h; $g[$k] += (int)($x['h'][$h] ?? 0); $l[$k] += (int)($x['hl'][$h] ?? 0); $dd[$k] += (int)($x['hd'][$h] ?? 0); }
        }
        $heat['g'][$wi] = $g; $heat['l'][$wi] = $l; $heat['d'][$wi] = $dd; $heat['dn'][$wi] = $dn;
    }

    // games per hour for the last 32 days, oldest first, ending with the hour we're in
    $h0 = strtotime(gmdate('Y-m-d', $now - 31 * 86400) . ' 00:00:00 UTC');
    $hrs = [];
    for ($t = $h0; $t <= $nowH; $t += 3600) $hrs[] = (int)($days[gmdate('Y-m-d', $t)]['h'][(int)gmdate('G', $t)] ?? 0);

    // players online now: the same rule as the lobby's Online now strip (named, not hidden, seen in the last 150 seconds)
    $on = 0;
    $pres = load(DATA_DIR . '/presence.php');
    foreach ($pres as $p => $ts) if ($now - (int)$ts < 150 && !empty($players[$p]['name']) && empty($players[$p]['hideon'])) $on++;

    // where: every recently active player with a saved time zone
    $geo = load(RX_GEO);
    $grp = []; $langs = []; $zones = []; $counted = 0; $who = [];
    $cut = $now - RX_ACTIVE * 86400;
    foreach ($players as $pid => $p) {
        $tz = (string)($p['tz'] ?? '');
        if ($tz === '' || (int)($p['last'] ?? 0) < $cut) continue;
        $counted++;
        [$region, $country, $cont] = rx_place($tz);
        $who[$pid] = [$region, $country, $cont];
        $hh = array_fill(0, 24, 0);
        foreach ($p['hist'] ?? [] as $h) if ((int)($h['t'] ?? 0) > $cut) $hh[(int)gmdate('G', (int)$h['t'])]++;
        $grp[$region] = $grp[$region] ?? ['country' => $country, 'c' => $cont, 'n' => 0, 'h' => array_fill(0, 24, 0), 'z' => []];
        $grp[$region]['n']++;
        foreach ($hh as $i => $v) $grp[$region]['h'][$i] += $v;
        $grp[$region]['z'][$tz] = ($grp[$region]['z'][$tz] ?? 0) + 1;
        $lg = (string)($p['lang'] ?? (is_string($p['lg'] ?? null) ? $p['lg'] : ''));   //MC 2026-10-11 'lang' now ('lg' is the League)
        if ($lg !== '') $langs[$lg] = ($langs[$lg] ?? 0) + 1;
        if ($detail) $zones[$tz] = ($zones[$tz] ?? 0) + 1;
    }
    // too few players in a region: fold it into its country, then its continent, then "Other places"
    $min = $detail ? 1 : RX_MIN;
    $fold = function ($groups, $keyFn, $nameFn) use ($min) {
        $keep = []; $up = [];
        foreach ($groups as $name => $g) {
            if ($g['n'] >= $min) { $keep[$name] = $g; continue; }
            $k = $keyFn($name, $g);
            if (!isset($up[$k])) $up[$k] = ['country' => $g['country'], 'c' => $g['c'], 'n' => 0, 'h' => array_fill(0, 24, 0), 'z' => []];
            $up[$k]['n'] += $g['n'];
            foreach ($g['h'] as $i => $v) $up[$k]['h'][$i] += $v;
            foreach ($g['z'] as $z => $n) $up[$k]['z'][$z] = ($up[$k]['z'][$z] ?? 0) + $n;
        }
        $out = $keep;
        foreach ($up as $k => $g) { $name = $nameFn($k, $g); if (isset($out[$name])) { $out[$name]['n'] += $g['n']; foreach ($g['h'] as $i => $v) $out[$name]['h'][$i] += $v; foreach ($g['z'] as $z => $n) $out[$name]['z'][$z] = ($out[$name]['z'][$z] ?? 0) + $n; } else $out[$name] = $g; }
        return $out;
    };
    $grp = $fold($grp, fn($n, $g) => $g['country'], fn($k, $g) => $k);
    $grp = $fold($grp, fn($n, $g) => $g['c'], fn($k, $g) => rx_cont_name($k));
    $other = 0; $regions = [];
    foreach ($grp as $name => $g) {
        if ($g['n'] < $min) { $other += $g['n']; continue; }
        arsort($g['z']);
        $r = ['name' => $name, 'c' => $g['c'], 'n' => $g['n'], 'off' => rx_offset((string)array_key_first($g['z']), $now)];
        if ($detail || $g['n'] >= RX_MIN_HOURS) $r['h'] = $g['h'];
        if ($detail) $r['zones'] = $g['z'];
        $regions[] = $r;
    }
    //MC 2026-10-11 top players in each place (asked for on the stats page). Each player lands in the same place the list
    //   above shows them in, after the folding (a region too small for its own row goes to its country, then its
    //   continent). Only places shown above get a list, so a place always has at least RX_MIN players behind it.
    $n0 = []; foreach ($who as $w) $n0[$w[0]] = ($n0[$w[0]] ?? 0) + 1;
    $nm1 = function ($w) use ($n0, $min) { return $n0[$w[0]] >= $min ? $w[0] : $w[1]; };
    $n1 = []; foreach ($who as $w) { $k = $nm1($w); $n1[$k] = ($n1[$k] ?? 0) + 1; }
    $shown = array_flip(array_column($regions, 'name'));
    $lead = [];
    foreach ($who as $pid => $w) {
        $k = $nm1($w); if ($n1[$k] < $min) $k = rx_cont_name($w[2]);
        if (!isset($shown[$k])) continue;
        $p = $players[$pid];
        $wn = (int)($p['wins'] ?? 0); $lw = (int)($p['pvp_w'] ?? 0);
        if (($wn <= 0 && $lw <= 0) || empty($p['name'])) continue;
        $lead[$k][] = ['name' => (string)$p['name'], 'tag' => substr($pid, 0, 6), 'w' => $wn, 'g' => (int)($p['games'] ?? 0), 'lw' => $lw, 'lg' => (int)($p['pvp_g'] ?? 0)];
    }
    foreach ($regions as &$r) {
        $L = $lead[$r['name']] ?? [];
        $byW = $L; usort($byW, fn($a, $b) => [$b['w'], $a['g']] <=> [$a['w'], $b['g']]);
        $byL = array_values(array_filter($L, fn($x) => $x['lw'] > 0)); usort($byL, fn($a, $b) => [$b['lw'], $a['lg']] <=> [$a['lw'], $b['lg']]);
        $r['top'] = ['w' => array_slice($byW, 0, 10), 'l' => array_slice($byL, 0, 10), 'n' => count($L)];
    }
    unset($r);
    usort($regions, fn($a, $b) => $b['n'] <=> $a['n'] ?: strcmp($a['name'], $b['name']));
    arsort($langs);
    $lout = []; $lother = 0;
    foreach ($langs as $l => $n) { if ($n >= $min) $lout[] = ['l' => $l, 'n' => $n]; else $lother += $n; }

    $res = ['ok' => true, 'at' => $now, 'since' => $since,
        'heat' => $heat, 'hrs' => ['h0' => $h0, 'g' => $hrs], 'online' => $on,
        'geo' => ['since' => (int)($geo['since'] ?? 0), 'n' => $counted, 'min' => RX_MIN, 'minHours' => RX_MIN_HOURS, 'regions' => $regions, 'other' => $other, 'langs' => $lout, 'langOther' => $lother]];
    if ($detail) { arsort($zones); $res['geo']['zones'] = $zones; }
    return $res;
}
