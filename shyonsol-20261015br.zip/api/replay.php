<?php
// A Daily run to watch again: the day's deal (its seed) and the player's moves. The game plays them back in the browser,
// exactly as the server replayed them to score the run.
// GET ?d=YYYY-MM-DD&p=<6-letter player id>
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: public, max-age=300');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
if (!defined('DAILY')) define('DAILY', DATA_DIR . '/daily.php');
$day = (string)($_GET['d'] ?? ''); $tag = strtolower((string)($_GET['p'] ?? ''));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) || !preg_match('/^[a-f0-9]{6}$/', $tag)) fail('bad replay');
$daily = load(DAILY); $players = load(PLAYERS);
$run = null; $pid = '';
foreach ($daily[$day] ?? [] as $p => $r) if (strpos($p, $tag) === 0) { $run = $r; $pid = $p; break; }
if (!$run || empty($run['mv'])) fail('This run has no replay. Replays are kept for Daily runs played from this update on.', 404);
if (!empty($players[$pid]['hide'])) fail('This player keeps their games private.', 403);
$p = $players[$pid] ?? [];
$holder = !empty($p['holder']) && !empty($p['avatar']);
$no = (int)floor((strtotime($day . ' 00:00:00 UTC') - strtotime('2026-10-06 00:00:00 UTC')) / 86400) + 1;
//MC 2026-10-11 the day's deal comes from engine.php daily_seed (a server secret since the audit; the old crc32 for earlier days)
if (!defined('SHY_ENGINE')) define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';
require_once __DIR__ . '/fairlib.php';   //MC 2026-10-15 sealed days deal from fairlib.php
out(['ok' => true, 'day' => $day, 'no' => $no, 'seed' => isset($run['sd']) ? (int)$run['sd'] : fair_daily_seed($day), 'deck' => season_deck_at(strtotime($day . ' 00:00:00 UTC')),
    'name' => $p['name'] ?? 'Player', 'tag' => $tag, 'img' => $holder ? shadow_img($p['avatar']) : '', 'aura' => $holder ? shadow_aura($p['avatar']) : '',
    'regions' => (int)$run['regions'], 'result' => $run['result'], 'points' => (int)$run['points'],
    'moves' => array_map(fn($m) => $m[0] < 0 ? ['h' => -1] : ['h' => $m[0], 't' => $m[1]], $run['mv'])]);
