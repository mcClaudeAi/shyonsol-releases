<?php
//MC 2026-10-14 /c/<card>: the landing link the hype posts carry. Its whole job is the unfurl: X reads the tags here
//   and shows the card's own promo image (api/share.php?c=), so the card named in the post is the card in the picture.
//   A person who taps it is sent straight on to the game.
define('SHY_API', 1);
require __DIR__ . '/common.php';
define('SHY_ENGINE', 1);
require_once __DIR__ . '/engine.php';

function cp_h($x) { return htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8'); }

$cid = (string)($_GET['c'] ?? '');
if (!preg_match('/^[a-z0-9]{2,30}$/', $cid) || !isset(CARDS[$cid]) || (CARDS[$cid]['n'] ?? 0) < 1) {
    header('Cache-Control: no-store');
    header('Location: /play', true, 302);
    exit;
}
// the effect line, read from the game the way the Shilluminati page reads it
$text = '';
$src = (string)@file_get_contents(dirname(__DIR__) . '/assets/game.js');
if (preg_match('/^\s*' . preg_quote($cid, '/') . ':\s*\{ no: \d+, name: "(?:[^"\\\\]|\\\\.)*", kind: "\w+", target: "\w+", text: "((?:[^"\\\\]|\\\\.)*)" \}/m', $src, $m)) $text = stripcslashes($m[1]);

$h = preg_replace('/[^a-z0-9.:\-]/i', '', $_SERVER['HTTP_HOST'] ?? 'shyonsol.io') ?: 'shyonsol.io';
$site = (strpos($h, '127.0.0.1') === false ? 'https' : 'http') . '://' . $h;
$name = CARDS[$cid]['name'];
$title = $name . ' | Shilluminati Online';
$desc = trim($text . ' Free in your browser, no wallet needed.');
$img = $site . '/api/share.php?c=' . rawurlencode($cid);
$url = $site . '/c/' . rawurlencode($cid);
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=600');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
    . '<title>' . cp_h($title) . '</title>'
    . '<meta name="description" content="' . cp_h($desc) . '">'
    . '<link rel="canonical" href="' . cp_h($url) . '">'
    . '<meta property="og:type" content="website"><meta property="og:site_name" content="Shy on Solana">'
    . '<meta property="og:title" content="' . cp_h($title) . '"><meta property="og:description" content="' . cp_h($desc) . '">'
    . '<meta property="og:url" content="' . cp_h($url) . '">'
    . '<meta property="og:image" content="' . cp_h($img) . '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
    . '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="' . cp_h($title) . '">'
    . '<meta name="twitter:description" content="' . cp_h($desc) . '"><meta name="twitter:image" content="' . cp_h($img) . '">'
    . '<meta http-equiv="refresh" content="0;url=/play">'
    . '</head><body style="margin:0;background:#140d33;color:#fff;font:600 16px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh">'
    . '<p><a href="/play" style="color:#ff5d73">Taking you to the table&hellip;</a></p>'
    . '<script>location.replace("/play");</script></body></html>';
