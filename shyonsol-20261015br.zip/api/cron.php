<?php
// Timed jobs: Telegram reminders and tournament rounds. Busy pages run these on their own every couple of minutes;
// a cron job on the host makes them punctual even when the site is quiet.
// Hostinger: hPanel > Advanced > Cron Jobs, every 5 minutes, command:
//   wget -q -O /dev/null "https://shyonsol.io/api/cron.php?k=YOUR_CRON_KEY"
// The key is shown in the admin (Telegram tab). Without the right key this page does nothing.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/tourney.php';
require_once __DIR__ . '/opslib.php';   //MC 2026-10-11 backups, the nightly payment check and the health check

$k = (string)($_GET['k'] ?? '');
$want = cron_key();
if ($want === '' || !hash_equals($want, $k)) { http_response_code(403); echo '{"ok":false}'; exit; }
try { save(OPS_CRON, ['t' => time()]); } catch (Throwable $e) {}   //MC 2026-10-11 the health check shows when this last ran
//MC 2026-10-13 a site update replaces assets/art/masks with the stock files; put any custom bot masks back
require_once __DIR__ . '/artlib.php';
masks_heal();
masks_slim();   //MC 2026-10-13 shrinks any mask uploaded before the JPEG change
$n = tg_tick(true);
$hk = housekeeping();
$ops = ops_jobs();
out(['ok' => true, 'reminders' => $n, 'at' => gmdate('c')] + ($hk ? ['tidy' => $hk] : []) + ($ops ? ['ops' => $ops] : []));

//MC 2026-10-11 the operations jobs, each on its own so one failing never stops the others (or the reminders above):
//   - the backups, on the first run of each UTC day (backup-state.php remembers the day; a day with a failed copy is
//     tried again on the next run, and backup_run never copies over a copy that's already there)
//   - the nightly payment check, once a day after 03:00 UTC
//   - the health check, refreshed every 10 minutes so Admin > Overview opens quickly
function ops_jobs() {
    $o = [];
    $day = gmdate('Y-m-d');
    $bs = DATA_DIR . '/backup-state.php';
    try { if ((load($bs)['day'] ?? '') !== $day) { $b = backup_run(); $o['backup'] = $b ?: ['made' => 0]; if (empty($b['failed']) && empty($b['error'])) save($bs, ['day' => $day, 't' => time()]); } }
    catch (Throwable $e) { $o['backup'] = ['error' => $e->getMessage()]; }
    try { if (recon_due()) { $r = recon_run(); if ($r) $o['payments'] = $r; } }
    catch (Throwable $e) { $o['payments'] = ['error' => $e->getMessage()]; }
    try { $h = health_get(600); $o['health'] = $h['level']; }
    catch (Throwable $e) { $o['health'] = 'error'; }
    //MC 2026-10-15 a few Diamond hands clocks checked at random (loyaltylib.php), so a clock only runs for real holding
    try { $n = trophy_tick(8, true); if ($n) $o['trophies'] = $n; }
    catch (Throwable $e) { $o['trophies'] = 'error'; }
    try { $n = loyalty_sweep(6); if ($n) $o['loyal'] = $n; }
    catch (Throwable $e) { $o['loyal'] = 'error'; }
    return $o;
}

//MC 2026-10-11 tidying that used to happen inside player requests (or never), now once an hour from here:
//   - temp files left by a request that died mid-save (storage_sweep)
//   - share cards older than 60 days, and their lock files after a day (share.php used to scan the whole folder
//     inside the site lock on 1 create in 30)
//   - logs over 1 MB are rotated to .1 (one old copy kept)
//   - Fair Play match records older than 6 months
//   - the visitor lists of player pages not visited for 30 days (the count stays)
//   - every device key already known copied into keys.php, once (keys_migrate_once)
function housekeeping() {
    $f = DATA_DIR . '/housekeep.php';
    if (time() - (int)(load($f)['t'] ?? 0) < 3600) return null;
    save($f, ['t' => time()]);
    $done = [];
    storage_sweep();
    //MC 2026-10-14 the share pictures are only a cache: a missing one is redrawn from its record (or from live data) on
    //   the next view. So pictures now go after 30 days and the small .json records stay a full year, which keeps old
    //   share links unfurling. The old rule deleted record and picture together at 60 days and the link died with them.
    //   shy-data had grown past the health check's line (4,200 share files in 9 days); this keeps it lean for good.
    $sh = DATA_DIR . '/shares'; $n = 0; $b = 0;
    foreach (glob($sh . '/*') ?: [] as $x) {
        $age = time() - (int)@filemtime($x);
        $dot = strrpos($x, '.'); $ext = $dot !== false ? substr($x, $dot) : '';
        $kill = (substr($x, -5) === '.lock' && strpos($x, 'draw-slot') === false && $age > 86400)
            || (strpos($x, '.tmp') !== false && $age > 3600)
            || (($ext === '.jpg' || $ext === '.png') && $age > 30 * 86400)
            || $age > 365 * 86400;
        if ($kill) { $b += (int)@filesize($x); @unlink($x); $n++; }
    }
    if ($n) { $done['shares'] = $n; save($f, ['t' => time(), 'sw' => ['t' => time(), 'n' => $n, 'b' => $b]]); }
    foreach (glob(DATA_DIR . '/*.log') ?: [] as $x) if (@filesize($x) > 1000000) { @rename($x, $x . '.1'); $done['logs'][] = basename($x); }
    $cut = gmdate('Y-m', strtotime('-6 months'));
    foreach (glob(DATA_DIR . '/fairplay/*.jsonl') ?: [] as $x) if (basename($x, '.jsonl') < $cut) { @unlink($x); $done['fairplay'][] = basename($x); }
    $old = gmdate('Y-m-d', time() - 30 * 86400);
    $v = with_lock(function () use ($old) {
        $vf = DATA_DIR . '/visits.php'; $all = load($vf); $n = 0;
        foreach ($all as $pid => $x) if (is_array($x) && ($x['d'] ?? '') < $old && !empty($x['v'])) { $all[$pid]['v'] = []; $n++; }
        if ($n) save($vf, $all);
        // a language saved under 'lg' by the old where.php goes to 'lang' ('lg' is the League week)
        $pl = load(PLAYERS); $m = 0;
        foreach ($pl as $pid => $p) if (is_string($p['lg'] ?? null)) { $pl[$pid]['lang'] = $p['lg']; unset($pl[$pid]['lg']); $m++; }
        if ($m) save(PLAYERS, $pl);
        return ['visits' => $n, 'keys' => keys_migrate_once(), 'lang' => $m];
    });
    if (function_exists('lock_wait_trim')) lock_wait_trim();   //MC 2026-10-11 the lock wait samples keep two hours
    return $done + array_filter($v);
}
