<?php
//MC 2026-10-09 Admin email. Everything the team wants to hear about without opening the admin:
//   * money in: a Dojo Shop sale (paid on Solana or by card) and $SHY bought through the swap box on the site
//   * prizes owed in $SHY or SOL: Weekly League and Holder Cup winners, the Season Championship, the 15 Club bounty
//   * tournament results, prizes marked paid, and anything that needs a person (a payment claim we couldn't match)
//   * a daily report and a weekly report with the numbers, compared with the period before
// Each email is logged (Admin > Email) with whether it was opened. Alerts are queued while a request runs and sent once
// the visitor already has their answer, so a slow mail server never slows the game down.
// Counters for the reports (friend requests, peak players online, swaps...) live in track.php, one row per UTC day.
// Locking: this file uses its own lock (mail.lock), never the global one, so it can be called from inside with_lock.
if (!defined('SHY_API')) { http_response_code(404); exit; }
require_once __DIR__ . '/statslib.php';

define('MAILLOG', DATA_DIR . '/mail-log.php');      // the last 400 emails: id, type, subject, to, at, ok, opened
define('MAILQ', DATA_DIR . '/mail-queue.php');      // alerts waiting to go out at the end of the request
define('MAILSTATE', DATA_DIR . '/mail-state.php');  // when the daily and weekly reports last went out
define('TRACK', DATA_DIR . '/track.php');           // ['d' => 'Y-m-d' => [counter => n]], about four months
define('SWAPS', DATA_DIR . '/swaps.php');           // $SHY bought through the site's swap box: sig => details

// every kind of email, its label in the admin, and whether it's on until someone turns it off
const MAIL_TYPES = [
    'sale'    => ['Shop sales', 'Every paid Dojo Shop order: Koban packs, bundles, the Scroll. Paid in SOL, $SHY, USDC or by card.'],
    'swap'    => ['$SHY bought on the site', 'Someone used the swap box on the Token page and the swap checked out on Solana.'],
    'weekly'  => ['Weekly winners', 'The Weekly League and the Holder Cup are final, with who is owed what and their wallets.'],
    'season'  => ['Season winners', 'A Season Championship is final.'],
    'bounty'  => ['15 Club bounty', 'Someone won this month\'s bounty.'],
    'tourney' => ['Tournaments', 'A tournament finished, with the places and the Koban paid.'],
    'paid'    => ['Prizes paid', 'A prize was marked paid in the admin, with the transaction.'],
    'holder'  => ['New holders', 'A wallet holding a Shytoshi Shadow or $SHY was connected for the first time.'],
    'runway'  => ['Prize budget running low', 'The marketing wallet covers fewer weeks of prizes than the warning level in Rewards. Goes to the whole team.'],   //MC 2026-10-12
    'fairplay' => ['Possible farming', 'The farming check spotted a player who may be feeding themselves League points with a second account. Goes to the whole team.'],   //MC 2026-10-12
    'needs'   => ['Needs you', 'A player says they paid and we could not match it, or a payment came in short.'],
    'daily'   => ['Daily report', 'Yesterday\'s numbers, every morning.'],
    'week'    => ['Weekly report', 'Last week\'s numbers, every Monday morning.'],
];

// ---------------------------------------------------------------- settings
function mail_cfg() {
    $s = eco_settings();
    $to = trim((string)($s['mail_to'] ?? ''));
    if ($to === '') $to = trim((string)($s['idea_email'] ?? ''));
    $list = array_values(array_filter(array_map('trim', preg_split('/[,;\s]+/', $to)), fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL)));
    return ['to' => $list, 'off' => (array)($s['mail_off'] ?? []), 'hour' => (int)($s['mail_hour'] ?? 12), 'tz' => (string)($s['mail_tz'] ?? 'America/New_York')];
}
//MC 2026-10-12 who gets which email. Everyone who can get team email: the addresses in "Send to" and every admin account
//   with an email. Admin > Emails has a grid of email kind by person; 'mail_route' keeps each person's ticks. Someone with
//   no ticks saved yet keeps what they got before: the "Send to" addresses every kind, admins only the farming alert.
function mail_people() {
    $c = mail_cfg(); $out = [];
    foreach ($c['to'] as $e) $out[strtolower($e)] = ['email' => strtolower($e), 'name' => '', 'list' => 1];
    foreach (load(DATA_DIR . '/admins.php') as $u) if (is_array($u) && filter_var($u['email'] ?? '', FILTER_VALIDATE_EMAIL)) { $e = strtolower($u['email']); $out[$e] = ['email' => $e, 'name' => (string)($u['name'] ?? $u['username'] ?? ''), 'list' => !empty($out[$e]['list']) ? 1 : 0]; }
    return $out;
}
function mail_gets($person, $type) {
    $r = (array)(eco_settings()['mail_route'] ?? []);
    //MC 2026-10-12 a kind added after someone's grid was saved gets its default for them until the grid is saved again
    //   ('_k' lists the kinds the grid had when saved; grids saved before it had every kind but 'runway')
    if (isset($r[$person['email']])) { $mine = $r[$person['email']]; $known = $mine['_k'] ?? array_values(array_diff(array_keys(MAIL_TYPES), ['runway'])); if (in_array($type, $known, true)) return !empty($mine[$type]); }
    return $person['list'] ? true : in_array($type, ['fairplay', 'runway'], true);
}
function mail_recips($type) {
    $c = mail_cfg(); if (!empty($c['off'][$type])) return [];
    $out = []; foreach (mail_people() as $p) if (mail_gets($p, $type)) $out[] = $p['email'];
    return $out;
}
function mail_on($type) { if (isset($GLOBALS['MAIL_CAPTURE'])) return true; return (bool)mail_recips($type); }

// ---------------------------------------------------------------- its own lock
function mail_lock($fn) {
    $lf = @fopen(DATA_DIR . '/mail.lock', 'c');
    if (!$lf) return $fn();
    return lock_run($lf, $fn);   //MC 2026-10-11 lets go of the lock before a storage error answers (see lock_run)
}

// ---------------------------------------------------------------- tracking counters
function track($key, $n = 1, $day = null) {
    $day = $day ?? gmdate('Y-m-d');
    mail_lock(function () use ($key, $n, $day) {
        $t = load(TRACK);
        $t['d'][$day][$key] = ($t['d'][$day][$key] ?? 0) + $n;
        if (count($t['d']) > 130) { ksort($t['d']); $t['d'] = array_slice($t['d'], -120, null, true); }
        save(TRACK, $t);
    });
}
// the highest value seen in a day (players online at once)
function track_max($key, $v, $day = null) {
    $day = $day ?? gmdate('Y-m-d');
    $t = load(TRACK);
    if (($t['d'][$day][$key] ?? 0) >= $v) return;
    mail_lock(function () use ($key, $v, $day) {
        $t = load(TRACK);
        if (($t['d'][$day][$key] ?? 0) >= $v) return;
        $t['d'][$day][$key] = $v;
        $t['d'][$day][$key . '_at'] = time();
        save(TRACK, $t);
    });
}

// ---------------------------------------------------------------- formatting helpers
function m_week($ts) { return gmdate('o-W', (int)$ts); }
function mh($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function mail_site() { return defined('TG_SITE') ? TG_SITE : 'https://shyonsol.io'; }
function m_usd($v) { return '$' . number_format((float)$v, 2); }
function m_num($v, $d = 0) { return number_format((float)$v, $d); }
function m_when($ts, $tz = null) {
    if (!$ts) return '';
    $tz = $tz ?? mail_cfg()['tz'];
    try { $d = new DateTime('@' . (int)$ts); $d->setTimezone(new DateTimeZone($tz)); $local = $d->format('D, M j, g:i A T'); } catch (Exception $e) { $local = ''; }
    return $local . ' (' . gmdate('H:i', $ts) . ' UTC)';
}
function m_tx($sig, $label = 'View on Solscan') { return $sig !== '' ? '<a href="https://solscan.io/tx/' . mh(rawurlencode($sig)) . '" style="color:#7c3aed">' . mh($label) . '</a> <span class="hm" style="color:#8a8499;font-size:12px">' . mh(substr($sig, 0, 6) . '…' . substr($sig, -6)) . '</span>' : '<span style="color:#8a8499">none</span>'; }
//MC 2026-10-09 short form for tables so a full address can't push a phone screen sideways
function m_wallet($w, $short = false) { return $w !== '' ? '<a href="https://solscan.io/account/' . mh(rawurlencode($w)) . '" style="color:#7c3aed;font-family:Menlo,Consolas,monospace;font-size:12px;' . ($short ? 'white-space:nowrap' : 'word-break:break-all') . '">' . mh($short && strlen($w) > 14 ? substr($w, 0, 5) . '…' . substr($w, -5) : $w) . '</a>' : '<span style="color:#b45309">no wallet connected</span>'; }
function m_player($pid, $name = null) {
    $p = load(PLAYERS)[$pid] ?? null;
    $n = $name ?? ($p['name'] ?? '') ?: 'Player ' . strtoupper(substr($pid, 0, 6));
    $link = !empty($p['name']) ? '<a href="' . mh(mail_site() . '/p/' . rawurlencode(str_replace(' ', '_', $p['name']))) . '" style="color:#7c3aed;font-weight:700;text-decoration:none">' . mh($n) . '</a>' : '<b>' . mh($n) . '</b>';
    return $link . ' <span style="color:#8a8499;font-size:12px">#' . mh(substr($pid, 0, 6)) . '</span>';
}
function m_delta($now, $before) {
    if ($before == 0) return $now > 0 ? '<span style="color:#059669">new</span>' : '<span style="color:#8a8499">same</span>';
    $p = round(($now - $before) / $before * 100);
    if ($p == 0) return '<span style="color:#8a8499">same</span>';
    return $p > 0 ? '<span style="color:#059669">▲ ' . $p . '%</span>' : '<span style="color:#dc2626">▼ ' . abs($p) . '%</span>';
}

// ---------------------------------------------------------------- the email itself
// $blocks: ['h' => heading] | ['facts' => [[label, html], ...]] | ['stats' => [[label, value, sub], ...]]
//          | ['table' => [headers], 'rows' => [[cells html]], 'empty' => text] | ['p' => html] | ['bars' => [[label, n]], 'unit' => '']
//          | ['callout' => html, 'tone' => 'good'|'warn'|'bad']
function mail_html($kicker, $title, $intro, $blocks, $buttons = [], $id = '') {
    $site = mail_site();
    $b = '';
    foreach ($blocks as $x) {
        if (isset($x['h'])) { $b .= '<tr><td class="mx" style="padding:22px 28px 6px;font:800 13px/1.3 Arial,Helvetica,sans-serif;letter-spacing:1.2px;text-transform:uppercase;color:#7c3aed">' . mh($x['h']) . '</td></tr>'; continue; }
        if (isset($x['p'])) { $b .= '<tr><td class="mx" style="padding:6px 28px;font:15px/1.6 Arial,Helvetica,sans-serif;color:#2b2540">' . $x['p'] . '</td></tr>'; continue; }
        if (isset($x['callout'])) {
            $c = ['good' => ['#ecfdf5', '#059669'], 'warn' => ['#fffbeb', '#d97706'], 'bad' => ['#fef2f2', '#dc2626']][$x['tone'] ?? 'warn'];
            $b .= '<tr><td class="mx" style="padding:10px 28px"><div style="background:' . $c[0] . ';border-left:4px solid ' . $c[1] . ';border-radius:8px;padding:12px 14px;font:14px/1.55 Arial,Helvetica,sans-serif;color:#2b2540">' . $x['callout'] . '</div></td></tr>';
            continue;
        }
        if (isset($x['facts'])) {
            $r = '';
            foreach ($x['facts'] as $i => [$l, $v]) $r .= '<tr><td style="padding:9px 12px;width:38%;vertical-align:top;font:600 13px/1.4 Arial,Helvetica,sans-serif;color:#6b6480;' . ($i ? 'border-top:1px solid #eeeaf5;' : '') . '">' . mh($l) . '</td><td style="padding:9px 12px;vertical-align:top;font:14px/1.45 Arial,Helvetica,sans-serif;color:#1a1530;' . ($i ? 'border-top:1px solid #eeeaf5;' : '') . '">' . $v . '</td></tr>';
            $b .= '<tr><td class="mx" style="padding:6px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e6e1f0;border-radius:10px;border-collapse:separate">' . $r . '</table></td></tr>';
            continue;
        }
        if (isset($x['stats'])) {
            $cells = '';
            foreach ($x['stats'] as $i => $s) {
                if ($i && $i % 3 === 0) $cells .= '</tr><tr>';
                $cells .= '<td width="33%" style="padding:6px;vertical-align:top"><div class="sb" style="background:#f6f3fc;border-radius:10px;padding:12px 14px"><div style="font:600 11px/1.3 Arial,Helvetica,sans-serif;letter-spacing:.8px;text-transform:uppercase;color:#6b6480">' . mh($s[0]) . '</div><div class="sv" style="font:800 24px/1.2 Arial,Helvetica,sans-serif;color:#1a1530;margin-top:4px">' . $s[1] . '</div>' . (($s[2] ?? '') !== '' ? '<div style="font:12px/1.4 Arial,Helvetica,sans-serif;color:#6b6480;margin-top:3px">' . $s[2] . '</div>' : '') . '</div></td>';
            }
            $b .= '<tr><td class="mx" style="padding:4px 22px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>' . $cells . '</tr></table></td></tr>';
            continue;
        }
        if (isset($x['table'])) {
            //MC 2026-10-09 numbers line up right, words stay left
            $al = []; foreach ($x['table'] as $i => $hd) { $v = trim(html_entity_decode(strip_tags((string)($x['rows'][0][$i] ?? '')))); $al[$i] = $i && preg_match('/^[\$\-+▲▼~]?[\d.,]+(\s?(%|pts|games|\$SHY|SHY|SOL|USDC))?$/u', $v) ? 'right' : 'left'; }
            $th = ''; foreach ($x['table'] as $i => $hd) $th .= '<th align="' . $al[$i] . '" style="padding:8px 10px;font:700 11px/1.3 Arial,Helvetica,sans-serif;letter-spacing:.6px;text-transform:uppercase;color:#6b6480;background:#f6f3fc">' . mh($hd) . '</th>';
            $tr = '';
            foreach ($x['rows'] as $row) { $tr .= '<tr>'; foreach ($row as $i => $cell) $tr .= '<td class="mt" align="' . ($al[$i] ?? 'left') . '" style="padding:8px 10px;border-top:1px solid #eeeaf5;font:13px/1.4 Arial,Helvetica,sans-serif;color:#1a1530;vertical-align:top">' . $cell . '</td>'; $tr .= '</tr>'; }
            if (!$x['rows']) $tr = '<tr><td colspan="' . count($x['table']) . '" style="padding:12px 10px;font:13px Arial,Helvetica,sans-serif;color:#8a8499">' . mh($x['empty'] ?? 'Nothing yet.') . '</td></tr>';
            $b .= '<tr><td class="mx" style="padding:6px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border:1px solid #e6e1f0;border-radius:10px;border-collapse:separate;overflow:hidden">' . '<tr>' . $th . '</tr>' . $tr . '</table></td></tr>';
            continue;
        }
        if (isset($x['bars'])) {
            $max = max(1, max(array_map(fn($r) => $r[1], $x['bars']) ?: [1]));
            $rows = '';
            foreach ($x['bars'] as [$l, $n]) {
                $w = max(1, (int)round($n / $max * 100));
                $rows .= '<tr><td style="padding:3px 8px 3px 0;width:90px;font:12px Arial,Helvetica,sans-serif;color:#6b6480;white-space:nowrap">' . mh($l) . '</td><td style="padding:3px 0"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td width="' . $w . '%" style="background:#8b5cf6;height:12px;border-radius:3px;font-size:1px;line-height:12px">&nbsp;</td><td style="font-size:1px">&nbsp;</td></tr></table></td><td style="padding:3px 0 3px 8px;width:60px;text-align:right;font:700 12px Arial,Helvetica,sans-serif;color:#1a1530">' . m_num($n) . mh($x['unit'] ?? '') . '</td></tr>';
            }
            $b .= '<tr><td class="mx" style="padding:6px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">' . $rows . '</table></td></tr>';
        }
    }
    $btn = '';
    foreach ($buttons as $i => [$label, $url]) $btn .= '<a href="' . mh($url) . '" style="display:inline-block;margin:0 8px 8px 0;padding:11px 18px;border-radius:999px;font:700 14px Arial,Helvetica,sans-serif;text-decoration:none;' . ($i ? 'background:#ffffff;color:#1a1340;border:1px solid #d9d2ea' : 'background:#ff5d73;color:#ffffff') . '">' . mh($label) . '</a>';
    $pixel = $id !== '' ? '<img src="' . mh($site . '/api/mailt.php?i=' . $id . '&k=' . mail_sig($id)) . '" width="1" height="1" alt="" style="display:block;border:0;width:1px;height:1px">' : '';
    return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><style>@media (max-width:520px){.mx{padding-left:14px!important;padding-right:14px!important}.mt{padding:7px 6px!important;font-size:12px!important}.sv{font-size:19px!important}.sb{padding:10px!important}.hm{display:none!important}}</style><title>' . mh($title) . '</title></head>' .
        '<body style="margin:0;padding:0;background:#efecf6"><div style="display:none;max-height:0;overflow:hidden">' . mh(strip_tags($intro)) . '</div>' .
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#efecf6"><tr><td align="center" style="padding:24px 12px">' .
        '<table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:100%;max-width:640px;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 6px 24px rgba(26,19,64,.12)">' .
        '<tr><td style="background:#1a1340;padding:18px 28px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td style="font:800 15px Arial,Helvetica,sans-serif;color:#ffffff;letter-spacing:.5px">SHY ON SOLANA <span style="color:#ff9ab0">·</span> <span style="color:#c8bff0;font-weight:600">Admin</span></td><td align="right" style="font:12px Arial,Helvetica,sans-serif;color:#c8bff0">' . mh(gmdate('M j, Y')) . '</td></tr></table></td></tr>' .
        '<tr><td style="font-size:0;line-height:0;height:4px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td height="4" style="background:#ff5d73;width:34%"></td><td height="4" style="background:#8b5cf6;width:33%"></td><td height="4" style="background:#2ef0b0;width:33%"></td></tr></table></td></tr>' .
        '<tr><td class="mx" style="padding:24px 28px 4px"><div style="font:800 12px Arial,Helvetica,sans-serif;letter-spacing:1.4px;text-transform:uppercase;color:#ff5d73">' . mh($kicker) . '</div><div style="font:800 26px/1.25 Arial,Helvetica,sans-serif;color:#1a1530;margin-top:6px">' . mh($title) . '</div>' .
        ($intro !== '' ? '<div style="font:15px/1.6 Arial,Helvetica,sans-serif;color:#4a4360;margin-top:8px">' . $intro . '</div>' : '') . '</td></tr>' .
        $b .
        ($btn !== '' ? '<tr><td class="mx" style="padding:18px 28px 8px">' . $btn . '</td></tr>' : '') .
        '<tr><td class="mx" style="padding:18px 28px 24px;border-top:1px solid #eeeaf5;font:12px/1.6 Arial,Helvetica,sans-serif;color:#8a8499">Sent by shyonsol.io to the team. Choose which of these you get in <a href="' . mh($site . '/admin/?tab=email') . '" style="color:#7c3aed">Admin, Email</a>.' . ($id !== '' ? ' Email ' . mh($id) . '.' : '') . '</td></tr>' .
        '</table>' . $pixel . '</td></tr></table></body></html>';
}
// the same content as plain text, for mail apps that don't show HTML
function mail_text($title, $intro, $blocks, $buttons) {
    $t = [$title, str_repeat('=', min(60, mb_strlen($title))), trim(html_entity_decode(strip_tags($intro), ENT_QUOTES, 'UTF-8')), ''];
    foreach ($blocks as $x) {
        $c = fn($s) => trim(html_entity_decode(strip_tags(str_replace('<br>', ' ', (string)$s)), ENT_QUOTES, 'UTF-8'));
        if (isset($x['h'])) { $t[] = ''; $t[] = strtoupper($x['h']); }
        elseif (isset($x['p'])) $t[] = $c($x['p']);
        elseif (isset($x['callout'])) $t[] = '> ' . $c($x['callout']);
        elseif (isset($x['facts'])) foreach ($x['facts'] as [$l, $v]) $t[] = $l . ': ' . $c($v);
        elseif (isset($x['stats'])) foreach ($x['stats'] as $s) $t[] = $s[0] . ': ' . $c($s[1]) . (($s[2] ?? '') !== '' ? ' (' . $c($s[2]) . ')' : '');
        elseif (isset($x['table'])) { $t[] = implode(' | ', $x['table']); foreach ($x['rows'] as $r) $t[] = implode(' | ', array_map($c, $r)); if (!$x['rows']) $t[] = $x['empty'] ?? 'Nothing yet.'; }
        elseif (isset($x['bars'])) foreach ($x['bars'] as [$l, $n]) $t[] = $l . ': ' . m_num($n) . ($x['unit'] ?? '');
    }
    $t[] = '';
    foreach ($buttons as [$l, $u]) $t[] = $l . ': ' . $u;
    return implode("\n", $t);
}
function mail_sig($id) { return substr(hash_hmac('sha256', $id, cron_key() . 'mail'), 0, 12); }

// queue an alert; it goes out when this request is done
function mail_alert($type, $subject, $kicker, $title, $intro, $blocks, $buttons = [], $to = null) {   //MC 2026-10-12 $to: a list of its own (the farming alert goes to the whole team)
    // the admin's preview: hand the email back instead of sending it
    if (isset($GLOBALS['MAIL_CAPTURE'])) { $GLOBALS['MAIL_CAPTURE'][] = [$subject, $kicker, $title, $intro, $blocks, $buttons]; return true; }
    if ($to === null ? !mail_on($type) : !empty(mail_cfg()['off'][$type])) return false;
    mail_lock(function () use ($type, $subject, $kicker, $title, $intro, $blocks, $buttons, $to) {
        $q = load(MAILQ); $q = $q['q'] ?? [];
        $q[] = ['type' => $type, 'subject' => $subject, 'kicker' => $kicker, 'title' => $title, 'intro' => $intro, 'blocks' => $blocks, 'buttons' => $buttons, 't' => time()] + ($to ? ['to' => $to] : []);
        save(MAILQ, ['q' => array_slice($q, -50)]);
    });
    static $hooked = false;
    if (!$hooked) { $hooked = true; register_shutdown_function('mail_flush'); }
    return true;
}
// send whatever is queued. Runs after the response (the visitor isn't kept waiting) and from the timed jobs.
function mail_flush($after = true) {
    if ($after) mail_finish_response();
    $q = mail_lock(function () { $q = load(MAILQ)['q'] ?? []; if ($q) save(MAILQ, ['q' => []]); return $q; });
    foreach ($q as $m) mail_send($m['type'], $m['subject'], $m['kicker'], $m['title'], $m['intro'], $m['blocks'], $m['buttons'], $m['to'] ?? null);
}
// build and send one email now, and log it
function mail_send($type, $subject, $kicker, $title, $intro, $blocks, $buttons = [], $to = null) {
    $c = mail_cfg();
    $to = $to ?? ($type === 'test' ? array_keys(mail_people()) : mail_recips($type));   //MC 2026-10-12 each kind goes to the people ticked for it
    if (!$to || !function_exists('mail')) return false;
    $id = bin2hex(random_bytes(5));
    $html = mail_html($kicker, $title, $intro, $blocks, $buttons, $id);
    $text = mail_text($title, $intro, $blocks, $buttons);
    $host = preg_replace('/[^a-z0-9.\-]/i', '', parse_url(mail_site(), PHP_URL_HOST) ?: 'shyonsol.io');
    $bd = 'b' . bin2hex(random_bytes(8));
    $headers = "From: Shy on Solana <noreply@$host>\r\nReply-To: noreply@$host\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"$bd\"\r\nX-Shy-Mail: $type $id";
    $body = "--$bd\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) .
        "--$bd\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) . "--$bd--\r\n";
    $subj = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $ok = @mail(implode(', ', $to), $subj, $body, $headers, "-fnoreply@$host");
    if (!$ok) @file_put_contents(DATA_DIR . '/mail-errors.log', gmdate('c') . " could not send $type email $id: $subject\n", FILE_APPEND);
    mail_lock(function () use ($id, $type, $subject, $to, $ok, $html) {
        $l = load(MAILLOG); $l = $l['l'] ?? [];
        array_unshift($l, ['id' => $id, 'type' => $type, 'subject' => $subject, 'to' => implode(', ', $to), 'at' => time(), 'ok' => $ok ? 1 : 0, 'opened' => 0, 'opens' => 0, 'kb' => (int)ceil(strlen($html) / 1024)]);
        save(MAILLOG, ['l' => array_slice($l, 0, 400)]);
    });
    track('mail_' . ($ok ? 'sent' : 'fail'));
    return $ok;
}
// an email was opened (the picture at the bottom loaded)
function mail_opened($id) {
    mail_lock(function () use ($id) {
        $l = load(MAILLOG); $l = $l['l'] ?? [];
        foreach ($l as $i => $m) if ($m['id'] === $id) { if (!$m['opened']) $l[$i]['opened'] = time(); $l[$i]['opens'] = ($m['opens'] ?? 0) + 1; save(MAILLOG, ['l' => $l]); return; }
    });
}

// ---------------------------------------------------------------- alerts, one per event
function alert_sale($o, $p) {
    if (!mail_on('sale')) return;
    $pid = $o['pid']; $site = mail_site();
    $hol = load(HOLDERS)[$pid] ?? null; $tier = holder_tier($hol);
    $orders = load(ORDERS);
    $mine = array_filter($orders, fn($x) => $x['pid'] === $pid && $x['status'] === 'paid' && empty($x['selfpay']));
    $life = array_sum(array_map(fn($x) => (float)$x['usd'], $mine));
    $today = 0; $week = 0; $wk = week_key();
    foreach ($orders as $x) if ($x['status'] === 'paid' && empty($x['selfpay'])) { if (gmdate('Y-m-d', $x['paid'] ?? 0) === today()) $today += $x['usd']; if (m_week($x['paid'] ?? 0) === $wk) $week += $x['usd']; }
    $amt = ($o['cur'] ?? '') === 'CARD' ? 'Card' : rtrim(rtrim(number_format(($o['units'] ?? 0) / pow(10, $o['dec'] ?? 0), 6, '.', ','), '0'), '.') . ' ' . $o['cur'];
    $first = count($mine) <= 1;
    $facts = [
        ['Player', m_player($pid)],
        ['Bought', '<b>' . mh($p['name']) . '</b>'],
        ['Price', '<b>' . m_usd($o['usd']) . '</b>'],
        ['Paid with', mh($amt)],
        ['They got', mh(implode(', ', $o['got'] ?? []))],
        ['Paid at', mh(m_when($o['paid'] ?? time()))],
        ['Transaction', ($o['cur'] ?? '') === 'CARD' ? mh('Card payment ' . ($o['proof'] ?? '')) : m_tx((string)($o['proof'] ?? ''))],
        ['Order', '<span style="font-family:Menlo,Consolas,monospace">' . mh($o['id']) . '</span>'],
        ['Wallet', m_wallet((string)($hol['wallet'] ?? ''))],
        ['Holder', mh($tier ? ($tier === 'shadow' ? 'Shadow holder' : HOLDER_NAMES[$tier] ?? ucfirst($tier)) : 'Not a holder')],   //MC 2026-10-10 rank name
        ['Their purchases', mh(count($mine) . ' paid ' . (count($mine) === 1 ? 'order' : 'orders') . ', ' . m_usd($life) . ' in total')],
    ];
    mail_alert('sale', '💰 ' . m_usd($o['usd']) . ' sale: ' . $p['name'] . ' (' . (load(PLAYERS)[$pid]['name'] ?? 'a player') . ')', 'New sale', m_usd($o['usd']) . ' · ' . $p['name'],
        ($first ? '<b>First purchase from this player.</b> ' : '') . 'The money went straight to the community marketing wallet and the order was delivered automatically.',
        [['facts' => $facts], ['h' => 'Shop so far'], ['stats' => [['Today (UTC)', m_usd($today), ''], ['This week', m_usd($week), 'Week ' . mh($wk)], ['This player', m_usd($life), count($mine) . ' orders']]]],
        [['Open the order', $site . '/admin/?tab=shop'], ['Player page', $site . '/p/' . rawurlencode(str_replace(' ', '_', (string)(load(PLAYERS)[$pid]['name'] ?? '')))]]);
}
function alert_swap($s) {
    if (!mail_on('swap')) return;
    $site = mail_site();
    $facts = [
        ['Bought', '<b>' . m_num($s['shy']) . ' $SHY</b>' . ($s['usd'] ? ' (about ' . m_usd($s['usd']) . ')' : '')],
        ['Paid', mh($s['paid'] ?: 'not worked out')],
        ['Wallet', m_wallet($s['wallet'])],
        ['Player', $s['pid'] !== '' && isset(load(PLAYERS)[$s['pid']]) ? m_player($s['pid']) : '<span style="color:#8a8499">not signed in to the game on that browser</span>'],
        ['When', mh(m_when($s['bt'] ?: $s['t']))],
        ['Transaction', m_tx($s['sig'])],
    ];
    $all = load(SWAPS); $n = 0; $sum = 0; $wk = week_key();
    foreach ($all as $x) if (!empty($x['ok']) && m_week($x['t']) === $wk) { $n++; $sum += $x['usd'] ?? 0; }
    mail_alert('swap', '🟢 $SHY bought on the site: ' . m_num($s['shy']) . ' $SHY' . ($s['usd'] ? ' (~' . m_usd($s['usd']) . ')' : ''), 'Bought on shyonsol.io', m_num($s['shy']) . ' $SHY',
        'Someone used the swap box on the Token page. The swap is confirmed on Solana. The site never touches the funds; this is for your records.',
        [['facts' => $facts], ['h' => 'This week'], ['stats' => [['Swaps on the site', m_num($n), ''], ['Value', m_usd($sum), 'at the price when bought'], ['Week', mh($wk), '']]]],
        [['See the swap', 'https://solscan.io/tx/' . rawurlencode($s['sig'])], ['Token page', $site . '/token']]);
}
// a prize table: rows from prize_table()
function m_prize_rows($rows) {
    return array_map(fn($r) => ['<b>#' . (int)$r['place'] . '</b> ' . m_player($r['pid'], $r['name']), m_num($r['pts']) . ' pts', (int)($r['n'] ?? 0) . ' games', '<b>' . m_usd($r['usd']) . '</b>', !empty($r['wallet']) ? m_wallet($r['wallet'], true) : '<span style="color:#b45309">no wallet</span>'], $rows);
}
function alert_weekly($wk, $w) {
    if (!mail_on('weekly')) return;
    $site = mail_site();
    $lg = $w['league'] ?? []; $cup = $w['cup'] ?? [];
    $owed = array_sum(array_map(fn($r) => $r['usd'], $lg)) + array_sum(array_map(fn($r) => $r['usd'], $cup));
    $top = $lg[0] ?? null;
    $nw = count(array_filter(array_merge($lg, $cup), fn($r) => empty($r['wallet'])));
    mail_alert('weekly', '🏆 Week ' . $wk . ' is final: ' . m_usd($owed) . ' in $SHY to pay' . ($top ? ', ' . $top['name'] . ' won' : ''), 'Weekly winners', 'Week ' . $wk . ' is final',
        ($top ? '<b>' . mh($top['name']) . '</b> won the Weekly League. ' : 'Nobody qualified for the Weekly League this week. ') . 'Prizes are paid in $SHY from the marketing wallet. Koban prizes for the top 10 were added to their accounts automatically.',
        array_merge(
            [['stats' => [['To pay', m_usd($owed), 'in $SHY'], ['League pool', m_usd($w['pool']['total'] ?? 0), ''], ['Holder Cup', m_usd($w['cupPool'] ?? 0), '']]]],
            $nw ? [['callout' => mh($nw . ($nw === 1 ? ' winner has' : ' winners have') . ' no wallet connected yet. They can connect one on their profile; the prize waits for them.'), 'tone' => 'warn']] : [],
            [['h' => 'Weekly League'], ['table' => ['Winner', 'Points', 'Games', 'Prize', 'Wallet'], 'rows' => m_prize_rows($lg), 'empty' => 'No qualifying players.']],
            [['h' => 'Holder Cup'], ['table' => ['Winner', 'Points', 'Games', 'Prize', 'Wallet'], 'rows' => m_prize_rows($cup), 'empty' => 'No qualifying holders.']]
        ),
        [['Pay the winners', $site . '/admin/?tab=rewards'], ['Week ' . $wk . ' board', $site . '/admin/?tab=weekly']]);
}
function alert_season($sn, $s) {
    if (!mail_on('season')) return;
    $site = mail_site();
    $owed = array_sum(array_map(fn($r) => $r['usd'], $s['winners'] ?? []));
    mail_alert('season', '🏆 Season ' . $sn . ' Championship is final: ' . m_usd($owed) . ' to pay', 'Season winners', 'Season ' . $sn . ' is final',
        'The Season Championship results are locked in. Prizes are paid in $SHY from the marketing wallet.',
        [['stats' => [['To pay', m_usd($owed), 'in $SHY'], ['Pool', m_usd($s['pool'] ?? 0), ''], ['Winners', m_num(count($s['winners'] ?? [])), '']]],
         ['table' => ['Winner', 'Points', 'Games', 'Prize', 'Wallet'], 'rows' => m_prize_rows($s['winners'] ?? []), 'empty' => 'No qualifying players.']],
        [['Pay the winners', $site . '/admin/?tab=rewards']]);
}
function alert_bounty($pid, $name, $mode, $regions, $prize, $m) {
    if (!mail_on('bounty')) return;
    $site = mail_site();
    $hol = load(HOLDERS)[$pid] ?? null;
    $p = load(PLAYERS)[$pid] ?? [];
    $w = (string)($hol['wallet'] ?? '');
    mail_alert('bounty', '🏆 15 Club bounty won by ' . $name . ': ' . $prize . ' to pay', '15 Club bounty', $name . ' took the ' . gmdate('F', strtotime($m . '-01')) . ' bounty',
        'They won a game holding all ' . $regions . ' Regions, the rarest finish in the game. Pay ' . mh($prize) . ' from the marketing wallet, then mark it paid in the admin so it shows on the Treasury page.',
        array_merge([['facts' => [
            ['Winner', m_player($pid, $name)],
            ['Game', mh(ucfirst($mode) . ', ' . $regions . ' Regions, a win')],
            ['Prize', '<b>' . mh($prize) . '</b>'],
            ['Wallet', m_wallet($w)],
            ['Their record', mh(m_num($p['games'] ?? 0) . ' games, ' . m_num($p['wins'] ?? 0) . ' wins, ' . m_num($p['points'] ?? 0) . ' points')],
            ['When', mh(m_when(time()))],
        ]]], $w === '' ? [['callout' => 'No wallet connected yet. The game told them to connect one on their profile.', 'tone' => 'warn']] : []),
        [['Pay and mark paid', $site . '/admin/?tab=rewards#bounty']]);
}
function alert_tourney($t) {
    if (!mail_on('tourney')) return;
    $site = mail_site(); $rows = [];
    foreach (array_slice($t['places'], 0, 4) as $i => $pid) $rows[] = ['<b>#' . ($i + 1) . '</b> ' . m_player($pid, $t['players'][$pid]['name'] ?? null), !empty($t['prizes'][$i]) ? m_num($t['prizes'][$i]) . ' Koban' : '-'];
    $n = count(array_filter($t['players'], fn($p) => ($p['out'] ?? null) !== -1));
    $champ = $t['champ'] !== '' ? ($t['players'][$t['champ']]['name'] ?? '') : '';
    mail_alert('tourney', '🏯 ' . $t['name'] . ' is over' . ($champ !== '' ? ': ' . $champ . ' won' : ''), 'Tournament', $t['name'],
        ($champ !== '' ? '<b>' . mh($champ) . '</b> won. ' : '') . mh($n . ' players took part.') . ' Koban prizes were added to their accounts automatically.' . (!empty($t['partner']) ? ' This was a joint event with ' . mh($t['partner']['name'] ?? 'a partner') . '.' : ''),
        [['table' => ['Place', 'Prize'], 'rows' => $rows, 'empty' => 'No finishers.'], ['facts' => [['Started', mh(m_when($t['start']))], ['Finished', mh(m_when(time()))], ['Players', m_num($n)]]]],
        [['Open tournaments', $site . '/admin/?tab=tourneys']]);
}
function alert_paid($what, $rows, $sig) {
    if (!mail_on('paid')) return;
    $tot = array_sum(array_map(fn($r) => (float)($r['usd'] ?? 0), $rows));
    mail_alert('paid', '✅ Paid: ' . $what . ($tot ? ' (' . m_usd($tot) . ')' : ''), 'Prize paid', $what,
        'Marked paid in the admin. It shows on the public Treasury page.',
        [['table' => ['Winner', 'Prize', 'Wallet'], 'rows' => array_map(fn($r) => [mh($r['name'] ?? ''), $r['usd'] ? m_usd($r['usd']) : mh($r['amount'] ?? ''), m_wallet((string)($r['wallet'] ?? ''), true)], $rows)], ['facts' => [['Transaction', m_tx($sig)]]]],
        [['Treasury page', mail_site() . '/treasury']]);
}
function alert_needs($title, $why, $facts, $link = '/admin/?tab=shop') {
    if (!mail_on('needs')) return;
    mail_alert('needs', '⚠️ Needs you: ' . $title, 'Needs you', ucfirst($title), $why, [['facts' => $facts]], [['Open in the admin', mail_site() . $link]]);
}
function alert_holder($pid, $h) {
    if (!mail_on('holder')) return;
    $tier = holder_tier($h);
    $tn = HOLDER_NAMES[$tier] ?? ucfirst($tier);   //MC 2026-10-10 the rank's full name (keys like 'king' read oddly on their own)
    mail_alert('holder', '💎 New holder: ' . (load(PLAYERS)[$pid]['name'] ?? 'a player') . ($tier ? ' (' . $tn . ')' : ''), 'New holder', 'A new holder connected',
        'A wallet that holds a Shytoshi Shadow or $SHY was connected to a player for the first time.',
        [['facts' => [['Player', m_player($pid)], ['Rank', mh($tier && $tier !== 'shadow' ? $tn : 'Shadow holder')], ['Shadows', mh(implode(', ', array_map(fn($n) => '#' . $n, array_slice((array)($h['shadows'] ?? []), 0, 12))) ?: 'none')], ['$SHY', mh(isset($h['shy_bal']) ? m_num($h['shy_bal']) . ' (~' . m_usd($h['shy_usd'] ?? 0) . ')' : 'not checked')], ['Wallet', m_wallet((string)($h['wallet'] ?? ''))]]]],
        [['Holders', mail_site() . '/admin/?tab=holders']]);
}

// ---------------------------------------------------------------- the reports
// numbers for a run of UTC days [from, to], inclusive
function report_numbers($from, $to) {
    $st = load(STATS); $tr = load(TRACK); $fu = load(FUNNEL); $players = load(PLAYERS);
    $days = []; for ($t = strtotime($from . ' 00:00 UTC'); $t <= strtotime($to . ' 00:00 UTC'); $t += 86400) $days[] = gmdate('Y-m-d', $t);
    $n = ['days' => $days, 'games' => 0, 'wins' => 0, 'modes' => [], 'hours' => array_fill(0, 24, 0), 'players' => [], 'perday' => [], 'track' => []];
    foreach ($days as $d) {
        $x = $st['d'][$d] ?? null;
        $n['perday'][$d] = ['g' => (int)($x['g'] ?? 0), 'p' => count($x['p'] ?? []), 'usd' => 0, 'new' => 0];
        if ($x) {
            $n['games'] += $x['g']; $n['wins'] += $x['w'];
            foreach ($x['m'] ?? [] as $k => $v) $n['modes'][$k] = ($n['modes'][$k] ?? 0) + $v;
            foreach ($x['h'] ?? [] as $h => $v) $n['hours'][$h] += $v;
            foreach ($x['p'] ?? [] as $tag => $_) $n['players'][$tag] = 1;
        }
        foreach ($tr['d'][$d] ?? [] as $k => $v) { if (substr($k, -3) === '_at') continue; $n['track'][$k] = str_starts_with($k, 'peak') ? max($n['track'][$k] ?? 0, $v) : ($n['track'][$k] ?? 0) + $v; }
    }
    $n['active'] = count($n['players']);
    // new players: first played inside the range
    $n['new'] = 0; $n['newList'] = [];
    foreach ($players as $pid => $p) {
        $since = gmdate('Y-m-d', (int)($p['since'] ?? 0));
        if (!empty($p['games']) && in_array($since, $days, true)) { $n['new']++; if (isset($n['perday'][$since])) $n['perday'][$since]['new']++; if (count($n['newList']) < 12) $n['newList'][] = $pid; }
    }
    // visitors from the funnel, by where they came from
    $n['visits'] = 0; $n['src'] = []; $n['firstGames'] = 0; $n['returned'] = 0; $n['buyers'] = 0;
    foreach ($fu['p'] ?? [] as $e) {
        if (in_array($e['v'] ?? '', $days, true)) { $n['visits']++; $n['src'][$e['src'] ?? 'direct'] = ($n['src'][$e['src'] ?? 'direct'] ?? 0) + 1; }
        if (in_array($e['f'] ?? '', $days, true)) $n['firstGames']++;
        if (in_array($e['r'] ?? '', $days, true)) $n['returned']++;
        if (in_array($e['b'] ?? '', $days, true)) $n['buyers']++;
    }
    arsort($n['src']);
    // money
    $n['orders'] = []; $n['usd'] = 0; $n['byCur'] = []; $n['byProduct'] = [];
    foreach (load(ORDERS) as $o) {
        if ($o['status'] !== 'paid' || !empty($o['selfpay'])) continue;
        $d = gmdate('Y-m-d', (int)($o['paid'] ?? 0));
        if (!in_array($d, $days, true)) continue;
        $n['orders'][] = $o; $n['usd'] += $o['usd'];
        $n['perday'][$d]['usd'] += $o['usd'];
        $n['byCur'][$o['cur']] = ($n['byCur'][$o['cur']] ?? 0) + $o['usd'];
        $n['byProduct'][$o['name']] = ($n['byProduct'][$o['name']] ?? 0) + $o['usd'];
    }
    usort($n['orders'], fn($a, $b) => ($b['paid'] ?? 0) <=> ($a['paid'] ?? 0));
    $n['payers'] = count(array_unique(array_map(fn($o) => $o['pid'] ?? $o['wallet'] ?? '', $n['orders']))); //MC 2026-10-09 distinct people who paid
    arsort($n['byProduct']);
    $n['swaps'] = []; $n['swapShy'] = 0; $n['swapUsd'] = 0;
    foreach (load(SWAPS) as $s) if (!empty($s['ok']) && in_array(gmdate('Y-m-d', $s['t']), $days, true)) { $n['swaps'][] = $s; $n['swapShy'] += $s['shy']; $n['swapUsd'] += $s['usd'] ?? 0; }
    return $n;
}
function report_owed() {
    $rw = load(REWARDS); $out = [];
    foreach ($rw['weeks'] ?? [] as $wk => $w) foreach (['league' => 'Weekly League', 'cup' => 'Holder Cup'] as $k => $lab) {
        $left = array_filter($w[$k] ?? [], fn($r) => empty($r['sig']) && empty($r['skip']));
        if ($left) $out[] = [$lab . ' week ' . $wk, count($left), array_sum(array_map(fn($r) => $r['usd'], $left))];
    }
    foreach ($rw['seasons'] ?? [] as $sn => $s) { $left = array_filter($s['winners'] ?? [], fn($r) => empty($r['sig']) && empty($r['skip'])); if ($left) $out[] = ['Season ' . $sn, count($left), array_sum(array_map(fn($r) => $r['usd'], $left))]; }
    if (function_exists('bounty_db')) foreach (bounty_db()['m'] as $m => $w) if (empty($w['paid'])) $out[] = ['15 Club bounty ' . $m . ' (' . $w['name'] . ')', 1, (float)preg_replace('/[^0-9.]/', '', explode(' ', (string)$w['prize'])[0])];
    return $out;
}
function report_health($days) {
    $out = [];
    //MC 2026-10-11 the Telegram log is telegram-errors.log; this read tg-errors.log, which never exists, so it always said 0
    foreach (['storage-errors.log' => 'Storage errors', 'mail-errors.log' => 'Email errors', 'telegram-errors.log' => 'Telegram errors'] as $f => $lab) {
        $lines = is_file(DATA_DIR . '/' . $f) ? file(DATA_DIR . '/' . $f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
        $c = 0; foreach ($lines as $l) if (in_array(substr($l, 0, 10), $days, true)) $c++;
        $out[] = [$lab, $c];
    }
    $help = array_filter(load(DATA_DIR . '/pay-help.php'), fn($x) => ($x['status'] ?? '') === 'open');
    $out[] = ['Payment claims waiting', count($help)];
    return $out;
}
// a report email for the days [from, to]; $label is "daily" or "week"
function report_build($from, $to, $label) {
    $n = report_numbers($from, $to);
    $len = count($n['days']);
    $pf = gmdate('Y-m-d', strtotime($from . ' UTC') - $len * 86400); $pt = gmdate('Y-m-d', strtotime($from . ' UTC') - 86400);
    $prev = report_numbers($pf, $pt);
    $site = mail_site();
    $tr = $n['track']; $ptr = $prev['track'];
    $range = $len === 1 ? gmdate('l, F j', strtotime($from . ' UTC')) : gmdate('M j', strtotime($from . ' UTC')) . ' to ' . gmdate('M j', strtotime($to . ' UTC'));
    $vs = $len === 1 ? 'the day before' : 'the week before';
    $busy = array_keys($n['hours'], max($n['hours']))[0] ?? 0;
    $modes = ['solo' => 'Solo', 'daily' => 'Daily Challenge', 'live' => 'Live', 'duel' => 'Duels', 'tourney' => 'Tournaments', 'easy' => 'Easy'];
    $blocks = [];
    $blocks[] = ['stats' => [
        ['Revenue', m_usd($n['usd']), m_delta($n['usd'], $prev['usd']) . ' vs ' . $vs],
        ['Games played', m_num($n['games']), m_delta($n['games'], $prev['games'])],
        ['Players', m_num($n['active']), m_delta($n['active'], $prev['active'])],
        ['New players', m_num($n['new']), m_delta($n['new'], $prev['new'])],
        ['First visits', m_num($n['visits']), m_delta($n['visits'], $prev['visits'])],
        ['Most online at once', m_num($tr['peak_online'] ?? 0), 'previous ' . m_num($ptr['peak_online'] ?? 0)],
    ]];
    // money
    $blocks[] = ['h' => 'Money in'];
    $blocks[] = ['stats' => [['Shop sales', m_num(count($n['orders'])), m_usd($n['usd'])], ['$SHY bought on the site', m_num(count($n['swaps'])), m_num($n['swapShy']) . ' $SHY, ~' . m_usd($n['swapUsd'])], ['People who paid', m_num($n['payers']), m_num($n['buyers']) . ' of them for the first time']]];
    if ($n['byCur']) $blocks[] = ['p' => 'Paid with: ' . implode(' · ', array_map(fn($c, $v) => '<b>' . mh($c) . '</b> ' . m_usd($v), array_keys($n['byCur']), $n['byCur']))];
    $blocks[] = ['table' => ['When', 'Player', 'Bought', 'Price', 'Tx'], 'rows' => array_map(fn($o) => [mh(gmdate($len === 1 ? 'H:i' : 'D H:i', $o['paid'])), m_player($o['pid']), mh($o['name']), '<b>' . m_usd($o['usd']) . '</b>', ($o['cur'] ?? '') === 'CARD' ? 'card' : m_tx((string)($o['proof'] ?? ''), 'tx')], array_slice($n['orders'], 0, 25)), 'empty' => 'No sales.'];
    if ($n['swaps']) $blocks[] = ['table' => ['When', 'Wallet', '$SHY', 'Value', 'Tx'], 'rows' => array_map(fn($s) => [mh(gmdate('D H:i', $s['t'])), mh(substr($s['wallet'], 0, 4) . '…' . substr($s['wallet'], -4)), m_num($s['shy']), m_usd($s['usd'] ?? 0), m_tx($s['sig'], 'tx')], array_slice($n['swaps'], 0, 15))];
    // prizes owed
    $owed = report_owed();
    $blocks[] = ['h' => 'Prizes waiting to be paid'];
    $blocks[] = $owed ? ['table' => ['Prize', 'Winners', 'Owed'], 'rows' => array_map(fn($r) => [mh($r[0]), m_num($r[1]), '<b>' . m_usd($r[2]) . '</b>'], $owed)] : ['callout' => 'Nothing owed. Every prize is paid.', 'tone' => 'good'];
    // playing
    $blocks[] = ['h' => 'How people played'];
    arsort($n['modes']);
    $blocks[] = ['bars' => array_map(fn($k, $v) => [$modes[$k] ?? ucfirst($k), $v], array_keys($n['modes']), $n['modes']), 'unit' => ''];
    $blocks[] = ['facts' => [
        ['Busiest hour', mh(sprintf('%02d:00 UTC', $busy)) . ' <span style="color:#8a8499">(' . mh((new DateTime('@' . (strtotime($from . ' UTC') + $busy * 3600)))->setTimezone(new DateTimeZone(mail_cfg()['tz']))->format('g A T')) . ')</span>'],
        ['Win rate', $n['games'] ? round($n['wins'] / $n['games'] * 100) . '% of games won' : '-'],
        ['Players who came back', m_num($n['returned']) . ' <span style="color:#8a8499">(played again on a later day)</span>'],
        ['Live matches started', m_num($tr['live_rooms'] ?? 0)],
        ['Duels sent', m_num($tr['duels'] ?? 0)],
        ['15 Club games', m_num($tr['bounty_games'] ?? 0) . ' <span style="color:#8a8499">(games that counted for the bounty)</span>'],
    ]];
    if ($len > 1) {
        $blocks[] = ['h' => 'Day by day'];
        $blocks[] = ['table' => ['Day', 'Games', 'Players', 'New', 'Revenue'], 'rows' => array_map(fn($d, $x) => [mh(gmdate('D M j', strtotime($d . ' UTC'))), m_num($x['g']), m_num($x['p']), m_num($x['new']), m_usd($x['usd'])], array_keys($n['perday']), $n['perday'])];
    }
    // community
    $blocks[] = ['h' => 'Community'];
    $blocks[] = ['stats' => [
        ['Friend requests', m_num($tr['fr_req'] ?? 0), m_num($tr['fr_acc'] ?? 0) . ' accepted'],
        ['Invites to a match', m_num($tr['fr_live'] ?? 0), ''],
        ['Ideas sent', m_num($tr['ideas'] ?? 0), ''],
        ['Results shared', m_num($tr['shares'] ?? 0), ''],
        ['Wallets connected', m_num($tr['wallets'] ?? 0), m_num($tr['holders_new'] ?? 0) . ' new holders'],
        ['Telegram links', m_num($tr['tg_links'] ?? 0), ''],
    ]];
    if ($n['src']) $blocks[] = ['p' => 'Where first-time visitors came from: ' . implode(' · ', array_map(fn($k, $v) => '<b>' . mh($k) . '</b> ' . m_num($v), array_slice(array_keys($n['src']), 0, 8), array_slice($n['src'], 0, 8)))];
    if ($n['newList']) $blocks[] = ['p' => 'New players: ' . implode(', ', array_map(fn($pid) => m_player($pid), $n['newList'])) . ($n['new'] > count($n['newList']) ? ' and ' . ($n['new'] - count($n['newList'])) . ' more' : '')];
    // leaders
    $pl = load(PLAYERS); $wk = week_key(); $lead = [];
    foreach ($pl as $pid => $p) if (($p['wk'] ?? '') === $wk && !empty($p['wpts'])) $lead[$pid] = $p['wpts'];
    arsort($lead);
    $blocks[] = ['h' => 'This week\'s League, top 5'];
    $blocks[] = ['table' => ['Player', 'Points'], 'rows' => array_map(fn($pid) => [m_player($pid), m_num($lead[$pid])], array_slice(array_keys($lead), 0, 5)), 'empty' => 'No points yet this week.'];
    // health
    $h = report_health($n['days']);
    $bad = array_sum(array_map(fn($r) => $r[1], $h));
    $blocks[] = ['h' => 'Site health'];
    $blocks[] = $bad ? ['table' => ['Check', 'Count'], 'rows' => array_map(fn($r) => [mh($r[0]), $r[1] ? '<b style="color:#dc2626">' . m_num($r[1]) . '</b>' : '0'], $h)] : ['callout' => 'All clear: no errors logged and no payment claims waiting.', 'tone' => 'good'];
    //MC 2026-10-11 the server health check in one line, and payments the nightly check found on Solana but not delivered
    if (!function_exists('health_line') && is_file(__DIR__ . '/opslib.php')) require_once __DIR__ . '/opslib.php';
    if (function_exists('health_line')) {
        try {
            [$hl, $ht] = health_line();
            $blocks[] = ['p' => '<b style="color:' . ['ok' => '#059669', 'warn' => '#b45309', 'bad' => '#dc2626'][$hl] . '">Server health: ' . ['ok' => 'OK', 'warn' => 'needs a look', 'bad' => 'needs attention'][$hl] . '.</b> ' . mh($ht)];
            $rc = recon_open();
            if ($rc) {
                $blocks[] = ['h' => 'Paid but not delivered'];
                $blocks[] = ['table' => ['Order', 'Player', 'Item', 'What the check found'], 'rows' => array_map(fn($x) => [mh($x['id']), m_player($x['pid']), mh($x['name']) . ' ' . m_usd($x['usd']), mh($x['what']) . ' ' . m_tx((string)($x['sig'] ?? ''), 'tx')], array_slice($rc, 0, 15))];
                $blocks[] = ['p' => 'Sort these in Admin, Shop, Nightly payment check.'];
            }
        } catch (Throwable $e) {}
    }
    $mailed = load(MAILLOG)['l'] ?? []; $sent = 0; $open = 0;
    foreach ($mailed as $m) if (in_array(gmdate('Y-m-d', $m['at']), $n['days'], true)) { $sent++; if ($m['opened']) $open++; }
    $blocks[] = ['p' => '<span style="color:#8a8499;font-size:13px">Admin emails in this period: ' . $sent . ' sent, ' . $open . ' opened.</span>'];
    $title = ($len === 1 ? 'Daily report' : 'Weekly report') . ': ' . $range;
    $intro = '<b>' . m_usd($n['usd']) . '</b> in sales, <b>' . m_num($n['games']) . '</b> games by <b>' . m_num($n['active']) . '</b> players' . ($n['new'] ? ', and <b>' . m_num($n['new']) . '</b> new players' : '') . '. Days are UTC.';
    $subject = ($len === 1 ? '📊 Daily: ' : '📈 Weekly: ') . $range . ' · ' . m_usd($n['usd']) . ' · ' . m_num($n['games']) . ' games · ' . m_num($n['active']) . ' players';
    return [$subject, $len === 1 ? 'Daily report' : 'Weekly report', $title, $intro, $blocks, [['Open the admin', $site . '/admin/'], ['Shop', $site . '/admin/?tab=shop'], ['Rewards', $site . '/admin/?tab=rewards']]];
}
// the timed part: the daily report for yesterday after the chosen hour, and the weekly one on Mondays
function mail_tick() {
    $c = mail_cfg();
    if (!$c['to']) return;
    mail_flush_if_any();
    if ((int)gmdate('G') < $c['hour']) return;
    $st = load(MAILSTATE);
    $y = gmdate('Y-m-d', time() - 86400);
    $lastWeek = m_week(time() - 7 * 86400);
    $doDay = empty($c['off']['daily']) && ($st['daily'] ?? '') !== $y;
    //MC 2026-10-09 Monday normally; if Monday had no traffic and no cron, it goes out on the next tick instead of being skipped
    $doWeek = empty($c['off']['week']) && ($st['week'] ?? '') !== $lastWeek;
    if (!$doDay && !$doWeek) return;
    // claim the send first so two visitors at once can't both send it
    $claim = mail_lock(function () use ($y, $lastWeek, $doDay, $doWeek) {
        $st = load(MAILSTATE); $go = [];
        if ($doDay && ($st['daily'] ?? '') !== $y) { $st['daily'] = $y; $go[] = 'daily'; }
        if ($doWeek && ($st['week'] ?? '') !== $lastWeek) { $st['week'] = $lastWeek; $go[] = 'week'; }
        if ($go) save(MAILSTATE, $st);
        return $go;
    });
    if (!$claim) return;
    // build and send after the visitor has their page
    register_shutdown_function(function () use ($claim, $y) {
        mail_finish_response();
        if (in_array('daily', $claim, true)) { [$s, $k, $t, $i, $b, $btn] = report_build($y, $y, 'daily'); mail_send('daily', $s, $k, $t, $i, $b, $btn); }
        if (in_array('week', $claim, true)) {
            $mon = gmdate('Y-m-d', strtotime('monday last week', time()));
            [$s, $k, $t, $i, $b, $btn] = report_build($mon, gmdate('Y-m-d', strtotime($mon . ' UTC') + 6 * 86400), 'week'); mail_send('week', $s, $k, $t, $i, $b, $btn);
        }
    });
}
function mail_flush_if_any() { if (load(MAILQ)['q'] ?? []) { static $h = false; if (!$h) { $h = true; register_shutdown_function('mail_flush'); } } }
// end the visitor's request so the email work happens after they have their answer
function mail_finish_response() {
    static $done = false; if ($done) return; $done = true;
    if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
    elseif (function_exists('litespeed_finish_request')) @litespeed_finish_request();
}

// Admin > Email preview: one email of each kind, built from real data where there is some, so the team can see exactly
// what arrives. Returns [subject, html] or null.
function mail_preview($kind) {
    if ($kind === 'daily') { $y = gmdate('Y-m-d', time() - 86400); $r = report_build($y, $y, 'daily'); return [$r[0], mail_html($r[1], $r[2], $r[3], $r[4], $r[5])]; }
    if ($kind === 'week') { $mon = gmdate('Y-m-d', strtotime('monday last week')); $r = report_build($mon, gmdate('Y-m-d', strtotime($mon . ' UTC') + 6 * 86400), 'week'); return [$r[0], mail_html($r[1], $r[2], $r[3], $r[4], $r[5])]; }
    $GLOBALS['MAIL_CAPTURE'] = [];
    if ($kind === 'sale') {
        $o = null; foreach (load(ORDERS) as $x) if ($x['status'] === 'paid' && (!$o || ($x['paid'] ?? 0) > ($o['paid'] ?? 0))) $o = $x;
        if ($o) alert_sale($o, eco_product($o['product']) ?: ['name' => $o['name']]);
    }
    if ($kind === 'weekly') { $rw = load(REWARDS); $wk = array_key_first($rw['weeks'] ?? []); if ($wk) alert_weekly($wk, $rw['weeks'][$wk]); }
    if ($kind === 'swap') { $s = null; foreach (load(SWAPS) as $x) if (!empty($x['ok'])) $s = $x; alert_swap($s ?: ['sig' => str_repeat('5', 88), 't' => time(), 'bt' => time(), 'pid' => '', 'wallet' => 'ExampleWa11et1111111111111111111111111111111', 'shy' => 125000, 'usd' => 48.5, 'paid' => '0.32 SOL', 'ok' => 1]); }
    if ($kind === 'bounty') { $pl = load(PLAYERS); $pid = array_key_first($pl); alert_bounty($pid, $pl[$pid]['name'] ?? 'A player', 'normal', 15, bounty_cfg()['prize'], bounty_month()); }
    $c = $GLOBALS['MAIL_CAPTURE']; unset($GLOBALS['MAIL_CAPTURE']);
    if (!$c) return null;
    [$subj, $k, $t, $i, $b, $btn] = $c[0];
    return [$subj, mail_html($k, $t, $i, $b, $btn)];
}
