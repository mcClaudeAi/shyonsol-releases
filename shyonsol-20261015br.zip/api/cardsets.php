<?php
// Season cards on the cards page: the cards already added to the game, and the candidates for the next season's card.
// Holders see the candidates first and vote; everyone sees them once the team reveals them. Nothing here changes the deck
// in play until the season starts and its winner joins (see cardsetlib.php).
// GET  ?a=view            the season cards in play and the next set (names and rules only for holders, or everyone once revealed)
// POST {a: view|vote, pid, key, card}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require_once __DIR__ . '/cardsetlib.php';

function cs_card($id, $open = true) {
    $c = SEASON_CARDS[$id];
    return $open ? ['id' => $id] + $c : ['id' => $id, 'kind' => $c['kind'], 'kanji' => $c['kanji']];
}
function cs_view($pid) {
    $d = cs_data(); $tier = $pid ? holder_tier(load(HOLDERS)[$pid] ?? null) : '';
    $now = time();
    $inPlay = array_map(fn($a) => cs_card($a['id']) + ['season' => $a['season'], 'from' => $a['from'], 'live' => $a['from'] <= $now, 'votes' => $a['votes'], 'by' => $a['by']], cs_active($d));
    $res = ['ok' => true, 'inPlay' => $inPlay, 'holder' => $tier !== '', 'each' => VOTES_EACH, 'set' => null];
    $set = cs_next_set();
    if (!$set) return $res;
    $s = $set['season'];
    $open = !empty($d['public']) || $tier !== '';
    $votes = $d['votes'][$s] ?? [];
    $mine = []; foreach ($votes as $c => $v) if ($pid && isset($v[$pid])) $mine[] = $c;
    $bal = cs_balance($s)['cards'] ?? [];
    $cards = array_map(fn($id) => $open ? cs_card($id) + ['votes' => count($votes[$id] ?? []), 'tested' => (int)($bal[$id]['games'] ?? 0)] : cs_card($id, false), $set['cards']);
    $res['set'] = ['id' => $set['id'], 'name' => $set['name'], 'season' => $s, 'blurb' => $set['blurb'], 'count' => count($set['cards']), 'closes' => $set['opens'],
        'tested' => (int)(cs_balance($s)['games'] ?? 0)];
    return $res + ['cards' => $cards, 'open' => $open, 'public' => !empty($d['public']), 'mine' => $mine];
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    cs_maybe_finalize();
    out(cs_view(''));
}
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$pid = (string)($b['pid'] ?? ''); $key = (string)($b['key'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $pid) || !preg_match('/^[a-f0-9]{32}$/', $key)) fail('bad player');
$kh = hash('sha256', $key);
$a = (string)($b['a'] ?? 'view');
if ($a === 'view') { if (!with_lock(fn() => key_ok($pid, $kh))) fail('not your profile', 403); out(cs_view($pid)); }
if ($a === 'vote') {
    $card = (string)($b['card'] ?? '');
    $set = cs_next_set();
    if (!$set) fail('There is no vote on right now.');
    if (!in_array($card, $set['cards'], true)) fail('Pick a card.');
    $s = $set['season'];
    $r = with_lock(function () use ($pid, $kh, $card, $s) {
        $l = load(LIMITS); $ok = rate_ok($l, 'csvote:' . client_ip(), 60, 600); save(LIMITS, $l);
        if (!$ok) return 'Slow down a little and try again.';
        if (!key_ok($pid, $kh)) return 'not your profile';
        if (holder_tier(load(HOLDERS)[$pid] ?? null) === '') return 'Voting is for $SHY holders. Connect the wallet that holds your $SHY on your profile.';
        if (cs_season_start($s) <= time()) return 'This vote has closed.';
        $d = cs_data();
        if (isset($d['votes'][$s][$card][$pid])) unset($d['votes'][$s][$card][$pid]);
        else {
            $n = 0; foreach ($d['votes'][$s] ?? [] as $v) if (isset($v[$pid])) $n++;
            if ($n >= VOTES_EACH) return 'You have ' . VOTES_EACH . ' votes. Take one back to move it.';
            $d['votes'][$s][$card][$pid] = time();
        }
        save(CARDSET, $d);
        return '';
    });
    if ($r !== '') fail($r, 403);
    out(cs_view($pid));
}
fail('unknown action');
