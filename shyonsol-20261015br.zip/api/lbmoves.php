<?php
//MC 2026-10-11 rank changes on the leaderboards: the up and down arrows next to a rank. Once a UTC day, the first time a
//   board is looked at, its top LBM_TOP places are kept in shy-data/lb-ranks.php (tag => place, one copy per board,
//   replaced the next day, so the file stays a few KB). Each answer then says how far a row moved since that copy.
//   The Daily board starts empty every day, so it has no arrows. Included by lb.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('LB_MOVES', DATA_DIR . '/lb-ranks.php');
const LBM_TOP = 300;
const LBM_BOARDS = ['all', 'week', 'live', 'ranked', 'holders'];

// today's copy of this board's places: [tag => place, ...], plus whether it holds the whole board (so a missing tag is new)
function lb_moves_snap($which, $list) {
    if (!in_array($which, LBM_BOARDS, true)) return null;
    $day = today();
    $s = load(LB_MOVES)[$which] ?? null;
    if ($s && ($s['d'] ?? '') === $day) return $s;
    // the first look today: keep the places as they are now (inside the site lock, so two boards saved at the same
    // moment can't write over each other)
    return with_lock(function () use ($which, $list, $day) {
        $all = load(LB_MOVES);
        if (($all[$which]['d'] ?? '') === $day) return $all[$which];
        $r = [];
        foreach (array_slice($list, 0, LBM_TOP) as $i => $row) if (!empty($row['pid'])) $r[$row['pid']] = $i + 1;
        $all[$which] = ['d' => $day, 'r' => $r, 'full' => count($list) <= LBM_TOP];
        foreach ($all as $b => $x) if (!in_array($b, LBM_BOARDS, true)) unset($all[$b]);
        save(LB_MOVES, $all);
        return $all[$which];
    });
}
// marks the rows of a paged answer: 'mv' => places gained (negative when dropped), or 'mv' => 'new' for a row that
// wasn't on the board at all this morning. Rows that didn't move get nothing.
function lb_moves_mark(&$res, $which, $list) {
    $s = lb_moves_snap($which, $list);
    if (!$s || empty($s['r'])) return;
    $off = (($res['page'] ?? 1) - 1) * ($res['per'] ?? 10);
    $mv = function ($tag, $rank) use ($s) {
        if (isset($s['r'][$tag])) { $d = $s['r'][$tag] - $rank; return $d ? $d : null; }
        return !empty($s['full']) ? 'new' : null;
    };
    foreach ($res['top'] ?? [] as $i => $r) { $m = $mv($r['pid'] ?? '', $off + $i + 1); if ($m !== null) $res['top'][$i]['mv'] = $m; }
    if (isset($res['me']['rank'])) { $m = $mv($res['me']['pid'] ?? '', (int)$res['me']['rank']); if ($m !== null) $res['me']['mv'] = $m; }
    $res['mvDay'] = $s['d'];
}
