<?php
// Browser notifications (Web Push) for players who turn them on.
// The push itself carries nothing: it only wakes the site's service worker (/sw.js), which then asks the site
// for the player's newest notice. So nothing has to be encrypted for the browser's push service, and the only
// secret is the site's own VAPID key, made on first use and kept in shy-data/push-keys.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('PUSHKEYS', DATA_DIR . '/push-keys.php');
define('PUSHSUBS', DATA_DIR . '/push-subs.php');   // pid => [hash of endpoint => ['e' => endpoint, 'ts' => when, 'ua' => short browser name]]
function b64url($b) { return rtrim(strtr(base64_encode($b), '+/', '-_'), '='); }

// the site's VAPID key pair: [private key PEM, public key as the 65 raw bytes browsers want, base64url]
function push_keys() {
    $k = load(PUSHKEYS);
    if (empty($k['pem'])) {
        $res = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]);
        if (!$res) return null;
        openssl_pkey_export($res, $pem);
        $d = openssl_pkey_get_details($res);
        $k = ['pem' => $pem, 'pub' => b64url("\x04" . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT)), 'ts' => time()];
        save(PUSHKEYS, $k);
    }
    return $k;
}
// browsers' own push services only: the site never posts anywhere a player names
function push_host_ok($url) {
    $p = parse_url($url);
    if (($p['scheme'] ?? '') !== 'https' || empty($p['host'])) return false;
    return (bool)preg_match('/(^|\.)(fcm\.googleapis\.com|push\.services\.mozilla\.com|notify\.windows\.com|push\.apple\.com)$/i', $p['host']);
}
function push_ready() { return function_exists('openssl_pkey_new') && function_exists('curl_init'); }

// an ES256 signature from OpenSSL's DER form to the 64 raw bytes a JWT needs
function push_der_to_raw($der) {
    $o = 2; if (ord($der[1]) & 0x80) $o += ord($der[1]) & 0x7f;
    $parts = [];
    for ($i = 0; $i < 2; $i++) {
        $len = ord($der[$o + 1]); $v = substr($der, $o + 2, $len); $o += 2 + $len;
        $parts[] = str_pad(ltrim($v, "\0"), 32, "\0", STR_PAD_LEFT);
    }
    return $parts[0] . $parts[1];
}
function push_jwt($aud, $k) {
    $h = b64url(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $c = b64url(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => 'mailto:' . (shy_config()['push_contact'] ?? 'noreply@shyonsol.io')]));
    if (!openssl_sign("$h.$c", $sig, $k['pem'], OPENSSL_ALGO_SHA256)) return null;
    return "$h.$c." . b64url(push_der_to_raw($sig));
}

// remember a browser for a player (locked)
function push_save($pid, $endpoint, $ua) {
    $all = load(PUSHSUBS);
    // one browser belongs to whoever turned notifications on there last
    $h = substr(hash('sha256', $endpoint), 0, 16);
    foreach ($all as $p => $subs) if ($p !== $pid && isset($subs[$h])) { unset($all[$p][$h]); if (!$all[$p]) unset($all[$p]); }
    $mine = $all[$pid] ?? [];
    $mine[substr(hash('sha256', $endpoint), 0, 16)] = ['e' => $endpoint, 'ts' => time(), 'ua' => $ua];
    uasort($mine, fn($x, $y) => $y['ts'] <=> $x['ts']);
    $all[$pid] = array_slice($mine, 0, 5, true);   // a few devices each
    save(PUSHSUBS, $all);
}
function push_forget($pid, $endpoint) {
    $all = load(PUSHSUBS);
    unset($all[$pid][substr(hash('sha256', $endpoint), 0, 16)]);
    if (empty($all[$pid])) unset($all[$pid]);
    save(PUSHSUBS, $all);
}
// whose browser this is (the service worker only knows its own endpoint)
function push_owner($endpoint) {
    $h = substr(hash('sha256', $endpoint), 0, 16);
    foreach (load(PUSHSUBS) as $pid => $subs) if (isset($subs[$h])) return $pid;
    return null;
}

// queue a push to every browser a player turned on; sent after the request has its answer
function push_queue($pid, $msg) {
    static $hooked = false;
    $GLOBALS['PUSH_Q'][] = $pid;
    if (!$hooked) { $hooked = true; register_shutdown_function('push_flush'); }
}
function push_flush() {
    $q = array_unique($GLOBALS['PUSH_Q'] ?? []); $GLOBALS['PUSH_Q'] = [];
    if (!$q || !push_ready()) return;
    if (function_exists('litespeed_finish_request')) @litespeed_finish_request();
    elseif (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
    $subs = load(PUSHSUBS);
    $k = null; $dead = [];
    foreach ($q as $pid) foreach ($subs[$pid] ?? [] as $s) {
        $k = $k ?? load(PUSHKEYS);   // made under the lock when someone turns notifications on
        if (empty($k['pem'])) return;
        $p = parse_url($s['e']);
        if (!push_host_ok($s['e']) && empty(shy_config()['push_test'])) continue;
        $jwt = push_jwt($p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : ''), $k);
        if (!$jwt) return;
        $ch = curl_init($s['e']);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 6, CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_HTTPHEADER => ['TTL: 86400', 'Urgency: high', 'Content-Length: 0', 'Authorization: vapid t=' . $jwt . ', k=' . $k['pub']]]);
        curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code === 404 || $code === 410) $dead[] = [$pid, $s['e']];   // the browser dropped it: forget it
        elseif ($code >= 400 || $code === 0) @file_put_contents(DATA_DIR . '/push-errors.log', gmdate('c') . " $code " . $p['host'] . "\n", FILE_APPEND);
    }
    if ($dead) with_lock(function () use ($dead) { foreach ($dead as [$pid, $e]) push_forget($pid, $e); });
}
