<?php
// The community's Medium posts, read from Medium's public feed and shown on shyonsol.io.
// GET ?a=list         -> posts (no body)
// GET ?a=post&id=ID   -> one post with its cleaned-up HTML, plus the posts either side of it

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';

const MEDIUM_PROFILE = 'https://medium.com/@SHY_Community';
const MEDIUM_TTL = 1800;   // look for new posts every half hour
define('MEDIUM_CACHE', DATA_DIR . '/medium.php');

// shown if Medium can't be reached and nothing is cached yet
const MEDIUM_FALLBACK = [
    ['id' => 'saving-a-name', 'title' => 'Saving a Name', 'date' => '2026-08-31', 'excerpt' => 'The story of SHY, before it was even called SHY.', 'link' => MEDIUM_PROFILE, 'img' => '', 'tags' => [], 'mins' => 0, 'author' => 'SHY Community'],
    ['id' => 'the-2-million-dollar-decision', 'title' => 'The 2 Million Dollar Decision', 'date' => '2026-09-06', 'excerpt' => 'The real beginning of SHY. A story about trust, not money.', 'link' => MEDIUM_PROFILE, 'img' => '', 'tags' => [], 'mins' => 0, 'author' => 'SHY Community'],
];

function medium_feed_url() { $c = shy_config(); return $c['medium_feed'] ?? 'https://medium.com/feed/@SHY_Community'; }

function medium_fetch() {
    $ch = curl_init(medium_feed_url());
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; ShyOnSol/1.0; +https://shyonsol.io)', CURLOPT_HTTPHEADER => ['Accept: application/rss+xml, application/xml, text/xml']]);
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($raw !== false && $code >= 200 && $code < 300 && strpos($raw, '<rss') !== false) ? $raw : null;
}

// Keep only plain article markup: text, headings, lists, quotes, code, links and images. Everything else is unwrapped or dropped.
function medium_clean($html, $title) {
    $keep = ['p' => [], 'h1' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'strong' => [], 'b' => [], 'em' => [], 'i' => [], 'a' => ['href'], 'img' => ['src', 'alt'],
        'figure' => [], 'figcaption' => [], 'blockquote' => [], 'ul' => [], 'ol' => [], 'li' => [], 'pre' => [], 'code' => [], 'hr' => [], 'br' => []];
    $drop = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'svg', 'noscript'];
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?><div id="r">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    $root = $doc->getElementById('r');
    if (!$root) return '';
    $walk = function ($node) use (&$walk, $keep, $drop) {
        foreach (iterator_to_array($node->childNodes) as $ch) {
            if ($ch->nodeType === XML_COMMENT_NODE) { $node->removeChild($ch); continue; }
            if ($ch->nodeType !== XML_ELEMENT_NODE) continue;
            $tag = strtolower($ch->nodeName);
            if (in_array($tag, $drop, true)) { $node->removeChild($ch); continue; }
            $walk($ch);
            if (!isset($keep[$tag])) {   // unwrap: keep the text, lose the tag
                while ($ch->firstChild) $node->insertBefore($ch->firstChild, $ch);
                $node->removeChild($ch);
                continue;
            }
            foreach (iterator_to_array($ch->attributes) as $at) if (!in_array($at->name, $keep[$tag], true)) $ch->removeAttribute($at->name);
            if ($tag === 'a') {
                $href = $ch->getAttribute('href');
                if (!preg_match('#^https?://#i', $href)) $ch->removeAttribute('href');
                else { $ch->setAttribute('target', '_blank'); $ch->setAttribute('rel', 'noopener nofollow'); }
            }
            if ($tag === 'img') {
                $src = $ch->getAttribute('src');
                // Medium's view-counting pixel and anything not served over https
                if (!preg_match('#^https://#i', $src) || strpos($src, '/_/stat') !== false) { $node->removeChild($ch); continue; }
                $ch->setAttribute('loading', 'lazy');
            }
        }
    };
    $walk($root);
    // Medium repeats the title as the first heading; the page already shows it
    foreach ($root->childNodes as $ch) {
        if ($ch->nodeType !== XML_ELEMENT_NODE) continue;
        if (preg_match('/^h[1-4]$/i', $ch->nodeName) && strcasecmp(trim($ch->textContent), trim($title)) === 0) $root->removeChild($ch);
        break;
    }
    $out = '';
    foreach ($root->childNodes as $ch) $out .= $doc->saveHTML($ch);
    return trim($out);
}

function medium_parse($raw) {
    libxml_use_internal_errors(true);
    $x = simplexml_load_string($raw, 'SimpleXMLElement', LIBXML_NOCDATA);
    libxml_clear_errors();
    if (!$x || !isset($x->channel)) return null;
    $posts = [];
    foreach ($x->channel->item as $it) {
        $title = trim((string)$it->title);
        $link = strtok((string)$it->link, '?');
        $guid = (string)$it->guid;
        $id = preg_match('#/p/([a-f0-9]+)#', $guid, $m) ? $m[1] : (preg_match('#-([a-f0-9]{8,})$#', $link, $m) ? $m[1] : substr(md5($link), 0, 12));
        $content = (string)$it->children('http://purl.org/rss/1.0/modules/content/')->encoded;
        $author = trim((string)$it->children('http://purl.org/dc/elements/1.1/')->creator);
        $html = medium_clean($content, $title);
        $text = trim(preg_replace('/\s+/', ' ', strip_tags(str_replace('</p>', "</p>\n", $html))));
        $img = preg_match('#<img[^>]+src="([^"]+)"#', $html, $m) ? html_entity_decode($m[1]) : '';
        $excerpt = '';
        if (preg_match('#<p>(.*?)</p>#s', $html, $m)) $excerpt = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES, 'UTF-8'));
        if (mb_strlen($excerpt) > 190) $excerpt = rtrim(mb_substr($excerpt, 0, 187), " ,.;:") . '…';
        $when = strtotime(preg_replace('/^[A-Za-z]{3},\s*/', '', (string)$it->pubDate)) ?: 0;   // the weekday name only confuses the parser
        $tags = [];
        foreach ($it->category as $c) $tags[] = (string)$c;
        $posts[] = ['id' => $id, 'title' => $title, 'date' => gmdate('Y-m-d', $when ?: time()), 'ts' => $when,
            'link' => $link, 'author' => $author, 'img' => $img, 'excerpt' => $excerpt, 'tags' => array_slice($tags, 0, 5),
            'mins' => max(1, (int)ceil(str_word_count($text) / 230)), 'html' => $html];
    }
    usort($posts, fn($a, $b) => $b['ts'] <=> $a['ts']);
    return $posts;
}

// cached posts, refreshed in the background of a request once they're older than MEDIUM_TTL
function medium_posts() {
    $c = load(MEDIUM_CACHE);
    if (!empty($c['posts']) && time() - ($c['ts'] ?? 0) < MEDIUM_TTL) return [$c['posts'], $c['ts']];
    // only one request goes to Medium at a time; the others use what's cached
    if (!empty($c['posts']) && time() - ($c['try'] ?? 0) < 120) return [$c['posts'], $c['ts']];
    //MC 2026-10-11 only the request that wins this lock fetches; the others serve what's cached (see market.php mk_cached)
    $lf = @fopen(DATA_DIR . '/medium-fetch.lock', 'c');
    if ($lf && !flock($lf, LOCK_EX | LOCK_NB)) { fclose($lf); if (!empty($c['posts'])) return [$c['posts'], $c['ts']]; $lf = null; }
    register_shutdown_function(function () use ($lf) { if ($lf) { @flock($lf, LOCK_UN); @fclose($lf); } });
    with_lock(function () { $c = load(MEDIUM_CACHE); $c['try'] = time(); save(MEDIUM_CACHE, $c); });
    $raw = medium_fetch();
    $posts = $raw ? medium_parse($raw) : null;
    if ($posts) {
        with_lock(function () use ($posts) { save(MEDIUM_CACHE, ['ts' => time(), 'try' => time(), 'posts' => $posts]); });
        return [$posts, time()];
    }
    if (!empty($c['posts'])) return [$c['posts'], $c['ts']];
    return [MEDIUM_FALLBACK, 0];
}

$a = $_GET['a'] ?? 'list';
[$posts, $ts] = medium_posts();
header('Cache-Control: public, max-age=300');

if ($a === 'list') {
    out(['ok' => true, 'profile' => MEDIUM_PROFILE, 'updated' => $ts, 'live' => $ts > 0,
        'posts' => array_map(fn($p) => array_diff_key($p, ['html' => 1]), $posts)]);
}
if ($a === 'post') {
    $id = (string)($_GET['id'] ?? '');
    foreach ($posts as $i => $p) {
        if ($p['id'] !== $id) continue;
        $near = fn($q) => $q ? ['id' => $q['id'], 'title' => $q['title'], 'img' => $q['img'], 'date' => $q['date'], 'mins' => $q['mins']] : null;
        out(['ok' => true, 'profile' => MEDIUM_PROFILE, 'post' => $p + ['html' => $p['html'] ?? ''],
            'newer' => $near($posts[$i - 1] ?? null), 'older' => $near($posts[$i + 1] ?? null)]);
    }
    out(['ok' => false, 'error' => 'That story could not be found.'], 404);
}
fail('unknown action');
