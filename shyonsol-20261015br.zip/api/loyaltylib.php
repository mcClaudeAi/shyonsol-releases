<?php
// Diamond hands: holder perks that grow with how long a wallet has held its $SHY rank, not only how much it holds.
//
// Every time a wallet's $SHY balance is looked up, each rank it's at or above keeps its start date, and each rank it's
// fallen below loses it. So for every rank there's a "held since". Three steps, by days held continuously:
//   30 days  Steady Hands     +10% on the weekly holder stipend
//   90 days  Diamond Hands    +25%, and the Diamond Hands title
//   180 days Ancient Holder   +50%, and the Ancient Holder title
// The bonus is worked out per rank and the best one counts: buying up to a higher rank never costs you the bonus you'd
// built at the rank below (that rank's clock keeps running while you hold above it). The clock belongs to the wallet,
// so moving it to another profile keeps it, and sending the $SHY to a new wallet starts over.
// No yield, no lockup, nothing staked: it only changes perks the site already gives.
//MC 2026-10-15 the clocks start at the first lookup after this update; there's no trustworthy record of balances before
//   it. Lookups happen when a holder plays or opens the shop, and cron checks a few clocked wallets at random times, so a
//   wallet can't sell between its own visits and buy back before the next one without a random check catching it.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('HOLDTIME', DATA_DIR . '/holdtime.php');   // wallet => ['s' => [rank => since ts], 'c' => last check ts]
const LOYAL_STEPS = [[180, 'ancient', 'Ancient Holder', 50], [90, 'diamond', 'Diamond Hands', 25], [30, 'steady', 'Steady Hands', 10]];
const LOYAL_TITLE_RANK = 'cadet';   // the titles need the clock at Kusama Cadet (5,000 $SHY) or above

// a balance lookup came back: keep or end each rank's clock. Call inside with_lock.
function loyalty_note($wallet, $bal) {
    if (!$wallet || $bal === null) return;
    $all = load(HOLDTIME);
    $r = $all[$wallet] ?? ['s' => []];
    $t = eco_settings()['htiers']; $now = time();
    foreach (HOLDER_LADDER as $k) {
        if ((float)$bal >= (float)($t[$k] ?? PHP_INT_MAX)) { if (empty($r['s'][$k])) $r['s'][$k] = $now; }
        else unset($r['s'][$k]);
    }
    $r['c'] = $now;
    if (!$r['s']) unset($all[$wallet]); else $all[$wallet] = $r;
    save(HOLDTIME, $all);
}
function loyalty_days($since) { return $since ? intdiv(time() - (int)$since, 86400) : 0; }
function loyalty_step($days) { foreach (LOYAL_STEPS as $s) if ($days >= $s[0]) return $s; return null; }
// everything about one wallet's clocks, for perks and for the shop panel
function loyalty_of($h, $tier, $all = null) {
    if (!$h || empty($h['wallet']) || !holder_is_shy($tier)) return null;
    $all = $all ?? load(HOLDTIME);
    $r = $all[$h['wallet']] ?? null;
    if (!$r) return ['days' => 0, 'step' => null, 'pct' => 0, 'bonus' => 0, 'next' => ['in' => 30, 'name' => 'Steady Hands', 'pct' => 10], 'titles' => []];
    $cur = $r['s'][$tier] ?? null;
    $days = loyalty_days($cur);
    // the best bonus over every rank held up to this one
    $bonus = 0; $best = null;
    $stip = eco_settings()['hstip'];
    foreach (array_slice(HOLDER_LADDER, 0, array_search($tier, HOLDER_LADDER, true) + 1) as $k) {
        if (empty($r['s'][$k])) continue;
        $st = loyalty_step(loyalty_days($r['s'][$k]));
        if (!$st) continue;
        $b = (int)round((int)($stip[$k] ?? 0) * $st[3] / 100);
        if ($b > $bonus) { $bonus = $b; $best = ['rank' => $k, 'step' => $st, 'days' => loyalty_days($r['s'][$k])]; }
    }
    $step = loyalty_step($days);
    $next = null;
    foreach (array_reverse(LOYAL_STEPS) as $s) if ($days < $s[0]) { $next = ['in' => $s[0] - $days, 'name' => $s[2], 'pct' => $s[3]]; break; }
    $titles = [];
    $td = 0; $ti = array_search(LOYAL_TITLE_RANK, HOLDER_LADDER, true);
    foreach (HOLDER_LADDER as $i => $k) if ($i >= $ti && !empty($r['s'][$k])) $td = max($td, loyalty_days($r['s'][$k]));
    if ($td >= 90) $titles[] = 'title_diamond';
    if ($td >= 180) $titles[] = 'title_ancient';
    return ['days' => $days, 'step' => $step ? ['key' => $step[1], 'name' => $step[2], 'pct' => $step[3]] : null,
        'bonus' => $bonus, 'from' => $best ? ['rank' => $best['rank'], 'name' => HOLDER_NAMES[$best['rank']] ?? $best['rank'], 'days' => $best['days'], 'pct' => $best['step'][3]] : null,
        'next' => $next, 'titles' => $titles, 'since' => $cur ? (int)$cur : 0];
}
// the titles earned so far go into the account for good. Call inside with_account.
function loyalty_grant(&$acc, $h, $tier, $pid = '') {
    if ($h && $pid !== '') $h['pid'] = $pid;
    $l = loyalty_of($h, $tier);
    if (!$l) return [];
    $got = [];
    foreach ($l['titles'] as $id) if (!isset($acc['items'][$id]) && eco_item($id)) {
        $acc['items'][$id] = time(); $got[] = $id;
        //MC 2026-10-15 and the trophy to the wallet (trophylib.php); the clock belongs to the wallet, so one per wallet
        if (function_exists('trophy_award') && !empty($h['pid'])) trophy_award($h['pid'], $id === 'title_ancient' ? 'ancient' : 'diamond', substr($h['wallet'], 0, 12));
    }
    return $got;
}
// cron: look a few clocked wallets up again at random, so a clock only keeps running for a wallet that really held.
// Network calls happen outside the lock; the results are written inside it.
function loyalty_sweep($n = 6) {
    if (!function_exists('shy_balance')) return 0;
    $all = load(HOLDTIME);
    if (!$all) return 0;
    $due = array_keys(array_filter($all, fn($r) => time() - (int)($r['c'] ?? 0) > 3 * 3600));
    if (!$due) return 0;
    shuffle($due);
    $res = [];
    foreach (array_slice($due, 0, $n) as $w) { $sb = shy_balance($w); if ($sb) $res[$w] = $sb['bal']; }
    if (!$res) return 0;
    with_lock(function () use ($res) { foreach ($res as $w => $bal) loyalty_note($w, $bal); });
    return count($res);
}
