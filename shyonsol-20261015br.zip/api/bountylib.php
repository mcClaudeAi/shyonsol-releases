<?php
//MC 2026-10-09 The 15 Club: a monthly bounty for the rarest win in the game. Winning while holding 15 Regions ends a
//game on the spot, and it almost never happens (0 in 3,250 simulated games, even with the best-move hints playing).
//The first player each calendar month (UTC) to do it in a qualifying game takes the bounty, one winner a month.
//Qualifying: a verified solo game on Normal with hints off, a first Daily run, or any live match where the player was
//at the table to the end. Duels don't count (two people share the deal). Everyone who does it gets the 15 Club title.
//Entry is free and nothing sold in the shop changes the cards or the deal, so buying Koban never helps anyone win this.
//The bounty is paid by hand from the marketing wallet; the admin marks it paid with the transaction.
//Callers already hold with_lock (lb.php submit, livelib.php end of match), so nothing here takes the lock again.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('BOUNTY', DATA_DIR . '/bounty.php');   // ['cfg' => [on, prize], 'm' => month => winner, 'club' => pid => [n, first, last]]
const BOUNTY_AT = 15;
// the test run before launch: 3,250 full games played by bots and the best-move engine, none won holding all 15
const BOUNTY_SIM = ['games' => 3250, 'wins' => 0, 'best' => 14];
// local testing only: shy-data/config.php can lower it so a test can reach it (like tg_api for the bot)
function bounty_at() { return max(1, (int)(shy_config()['bounty_at'] ?? BOUNTY_AT)); }

function bounty_db() { $d = load(BOUNTY); return $d + ['cfg' => [], 'm' => [], 'club' => [], 'best' => []]; }
function bounty_cfg($d = null) { $d = $d ?? bounty_db(); return ($d['cfg'] ?? []) + ['on' => true, 'prize' => '$50 in $SHY']; }
function bounty_month($t = null) { return gmdate('Y-m', $t ?? time()); }
function bounty_ends($m = null) { return strtotime(($m ?? bounty_month()) . '-01 00:00:00 UTC +1 month'); }

// a qualifying game just ended. Returns null when it doesn't count, else what happened for the player.
//MC 2026-10-09 Closest to 15: every qualifying game also counts toward this month's board of the most Regions held at the
//end, so everyone can see who's closing in. One line per player (their best), ties go to whoever got there first.
const BOUNTY_BOARD = 60;   // players kept per month
function bounty_track(&$d, $pid, $name, $regions, $result, $now) {
    $m = bounty_month($now);
    $b = $d['best'][$m] ?? [];
    $cur = $b[$pid] ?? null;
    $won = $result === 'win' ? 1 : 0;
    if ($cur && [$cur['r'], $cur['w']] >= [$regions, $won]) { if ($cur['n'] !== $name) { $b[$pid]['n'] = $name; $d['best'][$m] = $b; return true; } return false; }
    $b[$pid] = ['r' => (int)$regions, 'w' => $won, 't' => $now, 'n' => $name];
    uasort($b, fn($x, $y) => [$y['r'], $y['w'], $x['t']] <=> [$x['r'], $x['w'], $y['t']]);
    $d['best'][$m] = array_slice($b, 0, BOUNTY_BOARD, true);
    // keep the last 3 months only
    if (count($d['best']) > 3) { krsort($d['best']); $d['best'] = array_slice($d['best'], 0, 3, true); }
    return true;
}
function bounty_board($d, $m, $n = 10) {
    $out = []; $i = 0;
    //MC 2026-10-11 games after the claim never count (the 17 already on October's board came in after it)
    $w = $d['m'][$m] ?? null;
    foreach ($d['best'][$m] ?? [] as $pid => $x) { if ($w && $x['t'] > $w['t'] && $pid !== $w['pid']) continue; $out[] = ['name' => $x['n'], 'r' => min(bounty_at(), (int)$x['r']), 'won' => (bool)$x['w'], 'tag' => substr($pid, 0, 6), 't' => $x['t']]; if (++$i >= $n) break; }
    return $out;
}

function bounty_claim($pid, $name, $mode, $regions, $result) {
    $now = time();
    $d = bounty_db();
    //MC 2026-10-09 how rare it is, counted from real games: every game that counts, the wins holding all of them, and
    //   the most anyone has held at the end. Shown on the bounty card next to the test-game figure.
    $m = bounty_month($now);
    //MC 2026-10-11 once this month's bounty is claimed the month is over: the "Closest to 15" board and this month's game
    //   count stop where they were (a 17 won after the claim still went up on the board, showing 17/15). Games still
    //   count toward the all-time figures, and anyone who does it still joins the 15 Club.
    $claimed = !empty($d['m'][$m]);
    $tot = ($d['tot'] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'since' => $now, 'm' => []];
    $tot['g']++; if ($regions >= bounty_at() && $result !== 'loss') $tot['w']++;
    $tot['best'] = max($tot['best'], min(bounty_at(), (int)$regions));
    if (!$claimed) $tot['m'][$m] = ($tot['m'][$m] ?? 0) + 1;
    if (count($tot['m']) > 3) { krsort($tot['m']); $tot['m'] = array_slice($tot['m'], 0, 3, true); }
    $d['tot'] = $tot;
    if (function_exists('track')) track('bounty_games');
    if (!empty(bounty_cfg($d)['on']) && !$claimed) bounty_track($d, $pid, $name, min(bounty_at(), (int)$regions), $result, $now);
    save(BOUNTY, $d);
    if ($regions < bounty_at() || $result === 'loss') return null;
    $cfg = bounty_cfg($d);
    $m = bounty_month($now);
    $c = $d['club'][$pid] ?? ['n' => 0, 'first' => $now];
    $c['n']++; $c['last'] = $now; $c['name'] = $name;
    $d['club'][$pid] = $c;
    // the 15 Club title, for everyone who does it
    $eco = load(ECO);
    if (isset($eco[$pid])) { $a = eco_get($eco, $pid); eco_grant_item($a, 'title_club15'); $eco[$pid] = $a; save(ECO, $eco); }
    trophy_award($pid, 'club15', 'once');   //MC 2026-10-15 the first 15 Club win, as a trophy
    $out = ['club' => true, 'title' => 'title_club15', 'month' => $m, 'prize' => $cfg['prize'], 'next' => bounty_ends($m)];
    if (!empty($cfg['on']) && empty($d['m'][$m])) {
        $d['m'][$m] = ['pid' => $pid, 'name' => $name, 'mode' => $mode, 'regions' => $regions, 't' => $now, 'prize' => $cfg['prize'], 'paid' => 0, 'tx' => ''];
        $out['won'] = true;
        if (function_exists('alert_bounty')) alert_bounty($pid, $name, $mode, $regions, $cfg['prize'], $m);
        if (function_exists('tg_post')) tg_post('bounty', '🏆 <b>' . tg_h($name) . ' takes the 15 Club bounty!</b>' . "\n" . 'A win holding all ' . bounty_at() . ' Regions, the rarest finish in Shilluminati. ' . tg_h($cfg['prize']) . ' is on its way.' . "\n\n" . 'The next bounty opens ' . gmdate('F j', bounty_ends($m)) . '.', 'bounty:' . $m);
        if (function_exists('tg_user_of')) { $u = tg_user_of($pid); if ($u && !empty($u['dm'])) tg_dm($u['id'], '🏆 <b>You won this month\'s 15 Club bounty!</b> ' . tg_h($cfg['prize']) . ' goes to the wallet you connect on your profile. Connect one now if you haven\'t, and the team will send it.', tg_kb_private('🎴 Open the game')); }
    } else {
        $w = $d['m'][$m] ?? null;
        if ($w) $out['winner'] = $w['name'];
    }
    save(BOUNTY, $d);
    return $out;
}

// what the lobby shows: this month's bounty, open or claimed
function bounty_public($me = '') {
    $d = bounty_db(); $cfg = bounty_cfg($d); $m = bounty_month(); $w = $d['m'][$m] ?? null;
    $mine = null;
    if (preg_match('/^[a-f0-9]{6}$/', $me)) { $k = 0; foreach ($d['best'][$m] ?? [] as $pid => $x) { if ($w && $x['t'] > $w['t'] && $pid !== $w['pid']) continue; $k++; if (substr($pid, 0, 6) === $me) { $mine = ['rank' => $k, 'r' => min(bounty_at(), (int)$x['r']), 'won' => (bool)$x['w']]; break; } } }
    $club = 0; foreach ($d['club'] as $c) if (($c['last'] ?? 0) >= strtotime($m . '-01 00:00:00 UTC')) $club++;
    return ['on' => !empty($cfg['on']), 'prize' => $cfg['prize'], 'at' => bounty_at(), 'month' => $m, 'ends' => bounty_ends($m),
        'winner' => $w ? ['name' => $w['name'], 't' => $w['t'], 'tag' => substr($w['pid'], 0, 6), 'paid' => !empty($w['paid'])] : null,
        'locked' => (bool)$w, 'club' => count($d['club']), 'clubMonth' => $club, 'board' => bounty_board($d, $m), 'mine' => $mine, 'players' => count($d['best'][$m] ?? []),
        'odds' => ['games' => (int)($d['tot']['g'] ?? 0), 'wins' => (int)($d['tot']['w'] ?? 0), 'best' => min(bounty_at(), (int)($d['tot']['best'] ?? 0)), 'since' => (int)($d['tot']['since'] ?? 0),
            'month' => (int)($d['tot']['m'][$m] ?? 0), 'sim' => BOUNTY_SIM]];
}
