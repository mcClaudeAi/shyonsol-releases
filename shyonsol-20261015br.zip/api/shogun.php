<?php
//MC 2026-10-12 shyonsol.io/shogun: the link the team shares on X (Admin > The Shogun > Share on X). Crawlers read the preview
//   tags and get the "Can you beat the Shogun?" card (share.php?b=1) with the reward as it is set now and the current record;
//   people go straight on to a match against the Shogun. The card address carries the hash of what's on it, so a new
//   record means a fresh picture. ?v= on the page link does the same for X and Telegram, which cache a preview per link.
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/bosslib.php';
$d = boss_card_data();
$S = 'https://shyonsol.io';
$img = $S . '/api/share.php?b=1&h=' . $d['h'];
$title = 'Can you beat the Shogun? | Shilluminati Online';
$rate = $d['g'] ? round($d['w'] / $d['g'] * 100) : 0;
$desc = 'The hardest bot in Shilluminati. A 1v1, you against it.' . ($d['on'] && $d['koban'] > 0 ? ' Beat it for ' . number_format($d['koban']) . ' Koban, once a ' . ($d['per'] === 'week' ? 'week' : 'day') . '.' : '') .
    ($d['g'] ? ' Players have won ' . number_format($d['w']) . ' of ' . number_format($d['g']) . ' matches (' . $rate . '%).' : '') . ' Play free.';
$go = '/play?boss=1';
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: public, max-age=300');
echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">',
    '<title>', e($title), '</title><meta name="description" content="', e($desc), '"><link rel="canonical" href="', e($S . '/shogun'), '">',
    '<meta property="og:type" content="website"><meta property="og:site_name" content="Shy on Solana"><meta property="og:url" content="', e($S . '/shogun'), '">',
    '<meta property="og:title" content="', e($title), '"><meta property="og:description" content="', e($desc), '">',
    '<meta property="og:image" content="', e($img), '"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">',
    '<meta property="og:image:alt" content="Can you beat the Shogun? The hardest bot in Shilluminati, with its record against every player.">',
    '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="', e($title), '">',
    '<meta name="twitter:description" content="', e($desc), '"><meta name="twitter:image" content="', e($img), '">',
    '<script>location.replace(', json_encode($go), ');</script>',
    '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#120b0a;color:#fbf1dc;font:600 16px system-ui,sans-serif;text-align:center;padding:24px}a{color:#f3c969}</style>',
    '</head><body><p>On to the Shogun... <a href="', e($go), '">Challenge the Shogun</a></p></body></html>';
