<?php
//MC 2026-10-09 $SHY bought through the swap box on the Token page. The swap itself happens between the buyer's wallet
//   and Jupiter; the page tells us the transaction afterwards so the team hears about it and it counts in the reports.
//   We check it on Solana before believing it: confirmed, recent, and the signer's wallet ended up with more $SHY.
// POST {sig, pid?}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$sig = (string)($b['sig'] ?? ''); $pid = (string)($b['pid'] ?? '');
if (!preg_match('/^[1-9A-HJ-NP-Za-km-z]{60,100}$/', $sig)) fail('bad signature');
if (!preg_match('/^[a-f0-9]{16}$/', $pid)) $pid = '';
$ok = with_lock(function () use ($sig) {
    $l = load(LIMITS); $r = rate_ok($l, 'swap:' . client_ip(), 20, 3600); save(LIMITS, $l);
    return $r && !isset(load(SWAPS)[$sig]);
});
if (!$ok) out(['ok' => true]);
// the swap can take a few seconds to show up on the RPC
$tx = null;
for ($i = 0; $i < 5 && !$tx; $i++) { $tx = rpc('getTransaction', [$sig, ['encoding' => 'jsonParsed', 'maxSupportedTransactionVersion' => 0, 'commitment' => 'confirmed']]); if (!$tx) sleep(2); }
$rec = ['sig' => $sig, 't' => time(), 'bt' => 0, 'pid' => $pid, 'wallet' => '', 'shy' => 0, 'usd' => 0, 'paid' => '', 'ok' => 0];
if ($tx && empty($tx['meta']['err'])) {
    $keys = $tx['transaction']['message']['accountKeys'] ?? [];
    $signer = is_array($keys[0] ?? null) ? ($keys[0]['pubkey'] ?? '') : (string)($keys[0] ?? '');
    $rec['wallet'] = $signer; $rec['bt'] = (int)($tx['blockTime'] ?? 0);
    $pre = []; $delta = [];
    foreach ($tx['meta']['preTokenBalances'] ?? [] as $x) if (($x['owner'] ?? '') === $signer) $pre[$x['accountIndex']] = [$x['mint'], (float)($x['uiTokenAmount']['uiAmountString'] ?? ($x['uiTokenAmount']['amount'] / pow(10, $x['uiTokenAmount']['decimals'] ?? 0)))];
    foreach ($tx['meta']['postTokenBalances'] ?? [] as $x) {
        if (($x['owner'] ?? '') !== $signer) continue;
        $v = (float)($x['uiTokenAmount']['uiAmountString'] ?? ($x['uiTokenAmount']['amount'] / pow(10, $x['uiTokenAmount']['decimals'] ?? 0)));
        $delta[$x['mint']] = ($delta[$x['mint']] ?? 0) + $v - ($pre[$x['accountIndex']][1] ?? 0);
        unset($pre[$x['accountIndex']]);
    }
    foreach ($pre as [$mint, $v]) $delta[$mint] = ($delta[$mint] ?? 0) - $v;   // a token account closed in the swap
    $shy = $delta[SHY_MINT] ?? 0;
    $sol = ((int)($tx['meta']['preBalances'][0] ?? 0) - (int)($tx['meta']['postBalances'][0] ?? 0)) / 1e9;
    $paid = [];
    if ($sol > 0.00001) $paid[] = rtrim(rtrim(number_format($sol, 4, '.', ''), '0'), '.') . ' SOL';
    foreach ($delta as $mint => $v) if ($mint !== SHY_MINT && $v < 0) $paid[] = rtrim(rtrim(number_format(-$v, 4, '.', ''), '0'), '.') . ' ' . ($mint === USDC_MINT ? 'USDC' : substr($mint, 0, 4) . '…');
    $recent = !$rec['bt'] || $rec['bt'] > time() - 3 * 3600;
    if ($shy > 0 && $recent) {
        $px = price_usd(SHY_MINT);
        $rec['shy'] = round($shy, 2); $rec['usd'] = $px ? round($shy * $px, 2) : 0; $rec['paid'] = implode(' + ', $paid); $rec['ok'] = 1;
    }
}
with_lock(function () use ($sig, $rec) { $s = load(SWAPS); if (isset($s[$sig])) return; $s[$sig] = $rec; if (count($s) > 3000) $s = array_slice($s, -2500, null, true); save(SWAPS, $s); });
if ($rec['ok']) { track('swaps'); track('swap_shy', (int)$rec['shy']); alert_swap($rec); }
out(['ok' => true, 'counted' => (bool)$rec['ok']]);
