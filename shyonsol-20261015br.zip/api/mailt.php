<?php
//MC 2026-10-09 the tiny picture at the bottom of every team email: when it loads, the email is marked opened in
//   Admin > Email. Signed per email, so nobody can mark emails opened by guessing ids.
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
$id = (string)($_GET['i'] ?? ''); $k = (string)($_GET['k'] ?? '');
if (preg_match('/^[a-f0-9]{10}$/', $id) && hash_equals(mail_sig($id), $k)) mail_opened($id);
header('Content-Type: image/gif');
header('Cache-Control: no-store, no-cache, must-revalidate');
echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
