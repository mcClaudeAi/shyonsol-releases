<?php
//MC 2026-10-10 Where people play from, for the When and where section on the Stats page. The browser sends its time
//   zone name (like Europe/Berlin) and the first part of its language (like de), once a day at most. They're saved on
//   the player's record, replacing what was there, and only once that player has finished a game. No IP address, no
//   location, nothing else. The Stats page only ever shows totals per region with at least 3 players.
// POST {pid, tz, lang} -> {ok, saved}. saved false means "not a player yet, ask again later".
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require_once __DIR__ . '/whenlib.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$b = json_decode((string)file_get_contents('php://input'), true) ?: [];
$pid = (string)($b['pid'] ?? '');
$tz = (string)($b['tz'] ?? '');
$lg = strtolower(substr(preg_replace('/[^a-z].*$/i', '', (string)($b['lang'] ?? '')), 0, 3));
if (!preg_match('/^[a-f0-9]{16}$/', $pid)) fail('bad player');
if (!rx_tz_ok($tz)) fail('bad time zone');
if (!preg_match('/^[a-z]{2,3}$/', $lg)) $lg = '';
// not a player yet: answer without taking the lock (most first visits end here)
if (empty(load(PLAYERS)[$pid]['games'])) out(['ok' => true, 'saved' => false]);
$r = with_lock(function () use ($pid, $tz, $lg) {
    $l = load(LIMITS); $ok = rate_ok($l, 'wh:' . $pid, 6, 3600); save(LIMITS, $l);   // keyed by the player id, not the IP
    if (!$ok) return 'slow';
    $players = load(PLAYERS);
    if (empty($players[$pid]['games'])) return false;
    $geo = load(RX_GEO);
    if (empty($geo['since'])) save(RX_GEO, ['since' => time()]);
    //MC 2026-10-11 the language is kept as 'lang'. It was saved as 'lg', the key that holds the player's League week
    //   ({wk, pts, n}), so the daily visit replaced their League points with "en" and the next League game started the
    //   week again from 0. A language left in 'lg' by the old code is moved across here.
    $old = is_string($players[$pid]['lg'] ?? null);
    if (!$old && ($players[$pid]['tz'] ?? '') === $tz && ($players[$pid]['lang'] ?? '') === $lg) return true;
    if ($old) unset($players[$pid]['lg']);
    $players[$pid]['tz'] = $tz;
    if ($lg !== '') $players[$pid]['lang'] = $lg; else unset($players[$pid]['lang']);
    save(PLAYERS, $players);
    return true;
});
if ($r === 'slow') fail('slow down', 429);
out(['ok' => true, 'saved' => (bool)$r]);
