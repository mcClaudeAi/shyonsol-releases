<?php
// Card art files, shared by the admin (uploads) and the site (serving). Every published image is kept twice:
//   card-art/          what the browser loads, inside the website folder
//   shy-data/card-art-keep/   a safe copy outside the website, which a site update can never touch
// The original uploads are in shy-data/card-art-src. If an image goes missing from card-art (say the website folder was
// emptied before a new version was unpacked), the first request for it puts it back from the safe copy, or rebuilds it
// from the original upload, so nobody has to do anything.
if (!defined('SHY_API') && !defined('SHY_ADMIN')) { http_response_code(404); exit; }
if (!defined('ART_DB')) define('ART_DB', DATA_DIR . '/card-art.php');
if (!defined('ART_SRC')) define('ART_SRC', DATA_DIR . '/card-art-src');      // the original uploads, so the focus can be changed later
if (!defined('ART_KEEP')) define('ART_KEEP', DATA_DIR . '/card-art-keep');   // a safe copy of every published image
if (!defined('ART_PUB')) define('ART_PUB', dirname(__DIR__) . '/card-art');   // what the site serves
if (!defined('ART_W')) { define('ART_W', 1040); define('ART_H', 640); }       // 13:8, twice the size the cards are drawn at
const ART_FILE_RE = '/^[a-z0-9]+-[a-f0-9]{8}\.(webp|jpg)$/';

function art_pub_dir() {
    if (!is_dir(ART_PUB)) @mkdir(ART_PUB, 0755, true);
    if (!is_file(ART_PUB . '/.htaccess')) @file_put_contents(ART_PUB . '/.htaccess', "# images only\n<FilesMatch \"\\.(php|phtml|phar|html?|js)$\">\nRequire all denied\n</FilesMatch>\n");
}
// copies a published image into the safe folder (once)
//MC 2026-10-11 the smaller sizes (card-art/w520, card-art/w260) get their safe copy too, in the same sub folders
function art_keep($f) {
    if (!preg_match(ART_FILE_RE, $f)) return;
    foreach (art_widths() as $w) {
        $p = art_size_rel($f, $w);
        if (is_file(ART_PUB . '/' . $p) && !is_file(ART_KEEP . '/' . $p)) { @mkdir(ART_KEEP . '/w' . $w, 0755, true); @copy(ART_PUB . '/' . $p, ART_KEEP . '/' . $p); }
    }
    if (!is_file(ART_PUB . '/' . $f) || is_file(ART_KEEP . '/' . $f)) return;
    if (!is_dir(ART_KEEP)) @mkdir(ART_KEEP, 0755, true);
    @copy(ART_PUB . '/' . $f, ART_KEEP . '/' . $f);
}
//MC 2026-10-11 smaller copies of every published image. The full 1040 x 640 file was sent for every thumbnail (the
// Cards page weighed 10.6 MB, a 40 px stats icon pulled 200 KB). Each image now also exists at 780, 520, 360 and 260 wide,
// in card-art/w780/, w520/, w360/ and w260/ under the same file name, and the page picks the one that fits (api/art.php).
// They are made when an image is rendered, and for older images the first request for a missing size makes it (see
// api/cardimg.php), so nothing has to be run by hand after an update. Tried putting the width in the file name
// (name-520.webp) first: it breaks ART_FILE_RE everywhere the name is checked, so sub folders it is.
function art_widths() { return [780, 520, 360, 260]; }   // 780: one-column phone grids (342 px at 2x); 360: two-column phone grids (148 px at 2x)
function art_size_rel($f, $w) { return 'w' . (int)$w . '/' . $f; }
// makes (or puts back) one smaller size from the full image. Returns true when the file is there afterwards.
function art_make_size($f, $w, $force = false) {
    if (!preg_match(ART_FILE_RE, $f) || !in_array((int)$w, art_widths(), true)) return false;
    $rel = art_size_rel($f, $w); $dst = ART_PUB . '/' . $rel;
    if (!$force && is_file($dst)) { art_keep($f); return true; }
    art_pub_dir(); @mkdir(ART_PUB . '/w' . (int)$w, 0755, true);
    // the safe copy first: a plain copy is cheaper than a resize
    if (!$force && is_file(ART_KEEP . '/' . $rel) && @copy(ART_KEEP . '/' . $rel, $dst)) return true;
    $full = is_file(ART_PUB . '/' . $f) ? ART_PUB . '/' . $f : (is_file(ART_KEEP . '/' . $f) ? ART_KEEP . '/' . $f : '');
    if ($full === '') return false;
    $im = @imagecreatefromstring((string)@file_get_contents($full));
    if (!$im) return false;
    $h = (int)round($w * imagesy($im) / max(1, imagesx($im)));
    $out = imagecreatetruecolor($w, $h);
    imagecopyresampled($out, $im, 0, 0, 0, 0, $w, $h, imagesx($im), imagesy($im));
    $tmp = $dst . '.tmp' . getmypid();
    $ok = str_ends_with($f, '.webp') ? (function_exists('imagewebp') && @imagewebp($out, $tmp, 80)) : @imagejpeg($out, $tmp, 85);
    imagedestroy($im); imagedestroy($out);
    // written under a temporary name and moved into place, so a half written file is never served
    if (!$ok || !@rename($tmp, $dst)) { @unlink($tmp); return false; }
    if ($force) @unlink(ART_KEEP . '/' . $rel);
    art_keep($f);
    return true;
}
// every smaller size of one image; returns how many were missing and got made
function art_make_sizes($f, $force = false) {
    $n = 0;
    foreach (art_widths() as $w) { $had = is_file(ART_PUB . '/' . art_size_rel($f, $w)); if (art_make_size($f, $w, $force) && !$had) $n++; }
    return $n;
}
// crop the source to 13:8 around the focus point and save it at ART_W x ART_H, in the site folder and the safe folder.
// $name keeps an existing file name (when an image is rebuilt). Returns the file name or an error.
function art_render($srcPath, $id, $fx, $fy, $name = null) {
    $raw = @file_get_contents($srcPath);
    $im = $raw !== false ? @imagecreatefromstring($raw) : false;
    if (!$im) return ['err' => 'That file isn\'t an image the server can read. Use PNG, JPG or WebP.'];
    $w = imagesx($im); $h = imagesy($im);
    $want = ART_W / ART_H;
    if ($w / $h > $want) { $cw = (int)round($h * $want); $ch = $h; } else { $cw = $w; $ch = (int)round($w / $want); }
    $cx = (int)round(max(0, min($w - $cw, $fx / 100 * $w - $cw / 2)));
    $cy = (int)round(max(0, min($h - $ch, $fy / 100 * $h - $ch / 2)));
    $out = imagecreatetruecolor(ART_W, ART_H);
    imagecopyresampled($out, $im, 0, 0, $cx, $cy, ART_W, ART_H, $cw, $ch);
    art_pub_dir();
    if ($name !== null && preg_match(ART_FILE_RE, $name)) {
        $ok = str_ends_with($name, '.webp') ? (function_exists('imagewebp') && @imagewebp($out, ART_PUB . '/' . $name, 84)) : @imagejpeg($out, ART_PUB . '/' . $name, 88);
    } else {
        $name = $id . '-' . bin2hex(random_bytes(4));
        $ok = function_exists('imagewebp') ? @imagewebp($out, ART_PUB . '/' . $name . '.webp', 84) : false;
        if ($ok) $name .= '.webp';
        else { $ok = @imagejpeg($out, ART_PUB . '/' . $name . '.jpg', 88); $name .= '.jpg'; }
    }
    imagedestroy($im); imagedestroy($out);
    if (!$ok) return ['err' => 'Couldn\'t save the image. Check that the website folder can be written to.'];
    //MC 2026-10-11 the smaller sizes are redone with every render (a new focus changes them all); force, so a rebuilt image never keeps old small copies
    art_make_sizes($name, true);
    art_keep($name);
    return ['f' => $name, 'small' => $w < ART_W / 2 || $h < ART_H / 2];
}
// the art entry (live or waiting) that uses this file name
function art_entry_for($f) {
    $id = explode('-', $f)[0];
    $e = load(ART_DB)[$id] ?? [];
    foreach (['live', 'draft'] as $k) if (($e[$k]['f'] ?? '') === $f) return [$id, $e[$k]];
    return null;
}
// can a missing image be put back? (a safe copy, or the original upload)
function art_healable($f) {
    if (is_file(ART_KEEP . '/' . $f)) return true;
    $x = art_entry_for($f);
    return $x && !empty($x[1]['src']) && is_file(ART_SRC . '/' . basename($x[1]['src']));
}
// puts a missing image back under the same name: copied from the safe folder, or rebuilt from the original upload
//MC 2026-10-11 with $w (520 or 260) it puts back that smaller size: the full image first if it's gone too, then the small
// one from its safe copy or made from the full image. Putting back a full image also puts back its smaller sizes.
function art_heal($f, $w = 0) {
    if (!preg_match(ART_FILE_RE, $f)) return false;
    if ($w) return art_heal($f) && art_make_size($f, (int)$w);
    if (is_file(ART_PUB . '/' . $f)) { art_keep($f); return true; }
    art_pub_dir();
    if (is_file(ART_KEEP . '/' . $f) && @copy(ART_KEEP . '/' . $f, ART_PUB . '/' . $f)) { art_make_sizes($f); return true; }
    $x = art_entry_for($f);
    if (!$x || empty($x[1]['src'])) return false;
    $src = ART_SRC . '/' . basename($x[1]['src']);
    if (!is_file($src)) return false;
    $r = art_render($src, $x[0], $x[1]['fx'] ?? 50, $x[1]['fy'] ?? 50, $f);
    return !isset($r['err']);
}
// removes an image from both folders (art replaced or thrown away)
function art_drop_file($f) {
    if (!$f || !preg_match(ART_FILE_RE, $f)) return;
    @unlink(ART_PUB . '/' . $f); @unlink(ART_KEEP . '/' . $f);
    //MC 2026-10-11 and its smaller sizes
    foreach (art_widths() as $w) { @unlink(ART_PUB . '/' . art_size_rel($f, $w)); @unlink(ART_KEEP . '/' . art_size_rel($f, $w)); }
}

//MC 2026-10-13 ---------------------------------------------------------------- bot masks (Admin > Card art > Bot masks)
//   The six bot masks and the Shogun's can be replaced from the admin. The master copy of a custom mask lives in
//   shy-data/masks (a site update can't touch it): <key>.svg is the in-game image (a PNG wrapped in SVG, so every
//   page keeps using the same file name), av-<key>.png is the 300px raster the Telegram victory cards are drawn from,
//   and stock-<key>.svg is the original, saved before the first replacement so Back to stock always works.
const MASK_KEYS = ['ronin', 'monk', 'tiger', 'crane', 'kitsune', 'oni', 'shogun'];
function mask_dir() { return DATA_DIR . '/masks'; }
function mask_site($key) { return dirname(__DIR__) . '/assets/art/masks/' . $key . '.svg'; }
function mask_custom($key) { return is_file(mask_dir() . '/' . $key . '.svg'); }
// after a site update replaced assets/art/masks with the stock files, put the custom ones back. Cheap when none are custom.
function masks_heal() {
    $n = 0;
    foreach (MASK_KEYS as $k) {
        $m = mask_dir() . '/' . $k . '.svg';
        if (!is_file($m)) continue;
        $site = mask_site($k);
        if (is_file($site) && md5_file($site) === md5_file($m)) continue;
        if (@copy($m, $site)) $n++;
    }
    return $n;
}
//MC 2026-10-13 slim the masks uploaded before the JPEG change: a custom mask svg over 120 KB holds a PNG; decode it,
//   re-encode as JPEG 85 and rewrite master and site copy. Cheap when nothing is oversized (one stat per custom mask).
function masks_slim() {
    $n = 0;
    foreach (MASK_KEYS as $k) {
        $m = mask_dir() . '/' . $k . '.svg';
        if (!is_file($m) || filesize($m) < 120000) continue;
        $svg = (string)@file_get_contents($m);
        if (!preg_match('/href="data:image\/(?:png|jpeg);base64,([^"]+)"/', $svg, $mm)) continue;
        $im = @imagecreatefromstring((string)base64_decode($mm[1]));
        if (!$im) continue;
        ob_start(); imagejpeg($im, null, 85); $jpg = ob_get_clean(); imagedestroy($im);
        $out = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><image width="512" height="512" href="data:image/jpeg;base64,' . base64_encode($jpg) . '"/></svg>';
        if (strlen($out) < strlen($svg) && @file_put_contents($m, $out) !== false) { @copy($m, mask_site($k)); $n++; }
    }
    return $n;
}
