<?php
// The $SHY payment transaction (TransferChecked to the marketing wallet with the order's reference, BurnChecked, memo),
// built unsigned for the buyer's wallet to sign. Used by paytx.php (Solana Pay) and actions.php (Blinks).
//MC 2026-10-15 moved here from paytx.php so the Blinks can build the same transaction
if (!defined('SHY_API')) { http_response_code(404); exit; }
if (!defined('MEMO_PROGRAM')) define('MEMO_PROGRAM', 'MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr');

// ---------------------------------------------------------------- building the transaction
// Solana's compact length ("shortvec")
function sv($n) { $o = ''; do { $b = $n & 0x7f; $n >>= 7; if ($n) $b |= 0x80; $o .= chr($b); } while ($n); return $o; }
// the payer's token account for the mint with the most in it, or null
function paytx_token_account($owner, $mint, $need = 0) {
    $r = rpc('getTokenAccountsByOwner', [$owner, ['mint' => $mint], ['encoding' => 'jsonParsed', 'commitment' => 'confirmed']]);
    $best = null; $bal = -1;
    foreach ($r['value'] ?? [] as $a) {
        $u = (int)($a['account']['data']['parsed']['info']['tokenAmount']['amount'] ?? 0);
        if ($u > $bal) { $bal = $u; $best = ['addr' => $a['pubkey'], 'units' => $u, 'prog' => $a['account']['owner'] ?? '']; }
    }
    return $best;
}
// the unsigned transaction as bytes, or why it can't be built
function paytx_build($o, $payer) {
    $src = paytx_token_account($payer, $o['mint']);
    if (!$src) return ['err' => 'This wallet holds no $SHY. Buy some on the Token page first.'];
    if ($src['units'] < $o['units']) return ['err' => 'This wallet has ' . number_format($src['units'] / pow(10, $o['dec'])) . ' $SHY. This purchase needs ' . number_format($o['units'] / pow(10, $o['dec'])) . '.'];
    $dst = paytx_token_account($o['to'], $o['mint']);
    if (!$dst) return ['err' => 'The community wallet has no $SHY account yet. Tell the team.'];
    $prog = $src['prog'] ?: (rpc('getAccountInfo', [$o['mint'], ['encoding' => 'base64']])['value']['owner'] ?? '');
    if (!valid_wallet($prog)) return ['err' => 'Couldn\'t read the token from Solana. Try again.'];
    $bh = rpc('getLatestBlockhash', [['commitment' => 'confirmed']])['value']['blockhash'] ?? '';
    if (!$bh) return ['err' => 'Couldn\'t reach Solana. Try again.'];
    $b = paytx_bytes($payer, $src['addr'], $dst['addr'], $o['mint'], $prog, $o['ref'], MEMO_PROGRAM, $bh, (int)$o['units'] - (int)$o['burn'], (int)$o['burn'], (int)$o['dec'], 'shy:' . $o['id']);
    return strlen($b) > 64 ? ['tx' => $b] : ['err' => 'Couldn\'t build the payment. Try again.'];
}
// A legacy transaction with one signature slot (the payer's, left empty for the wallet to fill):
// TransferChecked to the marketing wallet with the reference key attached, BurnChecked, and the memo.
function paytx_bytes($payer, $src, $dst, $mint, $prog, $ref, $memoProg, $blockhash, $send, $burn, $dec, $memo) {
    // accounts: the signer first, then writable, then read-only
    $keys = [$payer, $src, $dst, $mint, $prog, $ref, $memoProg];
    $bin = array_map('b58_decode', $keys);
    foreach ($bin as $b) if ($b === null || strlen($b) !== 32) return 'bad key';
    $bh = b58_decode($blockhash); if ($bh === null || strlen($bh) !== 32) return 'bad blockhash';
    $ix = function ($prog, $accts, $data) { return chr($prog) . sv(count($accts)) . implode('', array_map('chr', $accts)) . sv(strlen($data)) . $data; };
    $ixs = [
        $ix(4, [1, 3, 2, 0, 5], chr(12) . pack('P', $send) . chr($dec)),   // TransferChecked: source, mint, destination, owner (+ reference)
        $ix(6, [], $memo),
    ];
    if ($burn > 0) array_splice($ixs, 1, 0, [$ix(4, [1, 3, 0], chr(15) . pack('P', $burn) . chr($dec))]);   // BurnChecked: account, mint, owner
    // header: 1 signature, 0 read-only signers, 3 read-only accounts (token program, reference, memo program)
    $msg = chr(1) . chr(0) . chr(3) . sv(count($bin)) . implode('', $bin) . $bh . sv(count($ixs)) . implode('', $ixs);
    return sv(1) . str_repeat("\0", 64) . $msg;
}
