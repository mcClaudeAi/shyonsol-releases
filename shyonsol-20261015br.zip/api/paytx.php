<?php
//MC 2026-10-10 Solana Pay transaction request for $SHY shop orders that burn part of the price.
//   A plain Solana Pay link can only ask for one transfer, so a phone that scans the checkout QR (or taps "Other wallet
//   app") gets this URL instead. The wallet asks it for the whole transaction: the price minus the burn to the marketing
//   wallet, the burn itself, the order's reference key and memo. The wallet shows it, the buyer signs, and the shop finds
//   it on Solana by the reference like any other payment. Nothing here signs anything or holds a key.
//   GET  ?o=ORDER          -> {label, icon}
//   POST ?o=ORDER {account} -> {transaction: base64, message}
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept, Accept-Encoding');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') exit;
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';

require_once __DIR__ . '/paytxlib.php';   //MC 2026-10-15 the transaction builder lives there now (shared with the Blinks)

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    echo json_encode(['label' => 'Shilluminati Online', 'icon' => (defined('TG_SITE') ? TG_SITE : 'https://shyonsol.io') . '/assets/art/icon-192.png']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$id = (string)($_GET['o'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $id)) fail('bad order');
$body = json_decode((string)file_get_contents('php://input'), true) ?: [];
$acct = (string)($body['account'] ?? '');
if (!valid_wallet($acct)) fail('bad account');
$ok = with_lock(function () { $l = load(LIMITS); $r = rate_ok($l, 'paytx:' . client_ip(), 30, 600); save(LIMITS, $l); return $r; });
if (!$ok) fail('Slow down a little and try again.', 429);
$o = load(ORDERS)[$id] ?? null;
if (!$o || ($o['cur'] ?? '') !== 'SHY' || empty($o['burn'])) fail('That order isn\'t a $SHY payment.', 404);
if ($o['status'] === 'paid') fail('That order is already paid.', 409);
if (time() > $o['exp']) fail('The price on this order ran out. Start a new purchase in the shop.', 410);

$built = paytx_build($o, $acct);
if (isset($built['err'])) fail($built['err'], 400);
$tx = $built['tx'];
with_lock(function () use ($id, $acct) { $orders = load(ORDERS); if (isset($orders[$id])) { $orders[$id]['txreq'] = time(); $orders[$id]['txreq_by'] = $acct; save(ORDERS, $orders); } });
$fmt = fn($u) => rtrim(rtrim(number_format($u / pow(10, $o['dec']), min(6, $o['dec']), '.', ','), '0'), '.');
out(['transaction' => base64_encode($tx),
    'message' => $o['name'] . ': ' . $fmt($o['units'] - $o['burn']) . ' $SHY to the community wallet, ' . $fmt($o['burn']) . ' $SHY burned (' . (int)($o['bpct'] ?? 0) . '%).']);

