<?php
// Site-wide game stats for the public Stats page: a running tally per day (games by mode, results, players,
// hour of day) and how often each Chaos card is played and wins. Written as games are scored. Include after common.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('STATS', DATA_DIR . '/stats.php');
const STATS_DAYS = 120;

function stats_mode($m) { return $m === 'live' ? 'live' : ($m === 'daily' ? 'daily' : 'solo'); }

function stats_blank_day() { return ['g' => 0, 'w' => 0, 'l' => 0, 't' => 0, 'm' => ['solo' => 0, 'daily' => 0, 'live' => 0], 'r' => 0, 'h' => array_fill(0, 24, 0), 'p' => []]; }

// one finished game for one player. Call inside with_lock.
function stats_add($pid, $mode, $result, $regions, $cards = [], $ts = null) {
    $st = load(STATS);
    if (empty($st['back'])) $st = stats_backfill(load(PLAYERS));   // the first game after this update brings in recent history too
    if (empty($st['back2'])) stats_backfill_hours($st, load(PLAYERS));   //MC 2026-10-10 same idea for the live and Daily hour counts
    stats_add_to($st, $pid, $mode, $result, $regions, $cards, $ts ?? time());
    save(STATS, $st);
}
function stats_add_to(&$st, $pid, $mode, $result, $regions, $cards, $ts) {
    if (empty($st['since'])) $st['since'] = $ts;
    $d = gmdate('Y-m-d', $ts);
    $day = $st['d'][$d] ?? stats_blank_day();
    $day['g']++;
    $k = $result === 'win' ? 'w' : ($result === 'tie' ? 't' : 'l');
    $day[$k]++;
    $day['m'][stats_mode($mode)]++;
    $day['r'] += (int)$regions;
    $day['h'][(int)gmdate('G', $ts)]++;
    //MC 2026-10-10 live and Daily games by hour too, for the When and where heatmap on the Stats page. Only once the
    //   backfill below has run, so a game is never counted twice. Solo is the total minus these two.
    $sm = stats_mode($mode);
    if (!empty($st['back2']) && $sm !== 'solo') { $hk = $sm === 'live' ? 'hl' : 'hd'; $day[$hk] = $day[$hk] ?? array_fill(0, 24, 0); $day[$hk][(int)gmdate('G', $ts)]++; }
    $day['p'][substr($pid, 0, 6)] = 1;
    $st['d'][$d] = $day;
    if (count($st['d']) > STATS_DAYS) { ksort($st['d']); $st['d'] = array_slice($st['d'], -STATS_DAYS, null, true); }
    // cards: every play counts once per game, and once more toward wins if that game was won
    if ($cards) {
        if (empty($st['csince'])) $st['csince'] = $ts;
        foreach (array_unique(array_filter($cards)) as $c) {
            $row = $st['c'][$c] ?? [0, 0, 0];
            $row[0]++;
            if ($result === 'win') $row[1]++;
            $st['c'][$c] = $row;
        }
        foreach (array_count_values(array_filter($cards)) as $c => $n) $st['c'][$c][2] = ($st['c'][$c][2] ?? 0) + $n;   // total plays
        $st['cg'] = ($st['cg'] ?? 0) + 1;   // games with card data
        if ($result === 'win') $st['cw'] = ($st['cw'] ?? 0) + 1;
    }
}

// first run: rebuild what we can from every player's recent games
function stats_backfill($players) {
    $st = ['d' => [], 'c' => [], 'since' => 0, 'back' => 1];
    $rows = [];
    foreach ($players as $pid => $p) foreach ($p['hist'] ?? [] as $h) $rows[] = [$pid, $h];
    usort($rows, fn($a, $b) => $a[1]['t'] <=> $b[1]['t']);
    foreach ($rows as [$pid, $h]) stats_add_to($st, $pid, $h['m'] ?? 'normal', $h['r'] ?? 'loss', $h['g'] ?? 0, [], (int)$h['t']);
    return $st;
}

//MC 2026-10-10 one time: live and Daily games by hour for the days already counted. Three places know about past games
//   and none has all of them: players' last 25 games, the Daily board (7 days) and the Fair Play match log (every live
//   match since it started). For each day the bigger count wins, so a busy day isn't cut down to what fit in the 25.
//   Everything up to now comes from here, everything after from stats_add_to.
function stats_backfill_hours(&$st, $players) {
    $cut = time(); $src = ['hl' => [[], []], 'hd' => [[], []]];   // [from players' games, from the board or the log]
    $add = function ($k, $i, $ts, $n = 1) use (&$src, $cut) { if ($ts <= 0 || $ts >= $cut) return; $d = gmdate('Y-m-d', $ts); $src[$k][$i][$d] = $src[$k][$i][$d] ?? array_fill(0, 24, 0); $src[$k][$i][$d][(int)gmdate('G', $ts)] += $n; };
    foreach ($players as $p) foreach ($p['hist'] ?? [] as $h) { $m = stats_mode($h['m'] ?? ''); if ($m !== 'solo') $add($m === 'live' ? 'hl' : 'hd', 0, (int)($h['t'] ?? 0)); }
    foreach (load(DATA_DIR . '/daily.php') as $rows) if (is_array($rows)) foreach ($rows as $r) $add('hd', 1, (int)($r['ts'] ?? 0));
    // the match log can be big, so it's read a line at a time and only the two numbers needed are pulled out
    for ($i = 4; $i >= 0; $i--) {
        $f = DATA_DIR . '/fairplay/' . gmdate('Y-m', strtotime(gmdate('Y-m-01') . " -$i month")) . '.jsonl';
        if (!is_file($f) || !($fh = @fopen($f, 'r'))) continue;
        while (($line = fgets($fh)) !== false) if (preg_match('/"e":\s*(\d+)/', $line, $e) && preg_match('/"hum":\s*(\d+)/', $line, $hm)) $add('hl', 1, (int)$e[1], (int)$hm[1]);
        fclose($fh);
    }
    foreach ($st['d'] ?? [] as $d => $day) foreach (['hl', 'hd'] as $k) {
        $a = $src[$k][0][$d] ?? null; $b = $src[$k][1][$d] ?? null;
        $best = !$a ? $b : (!$b ? $a : (array_sum($b) >= array_sum($a) ? $b : $a));
        if ($best) $st['d'][$d][$k] = $best;
    }
    $st['back2'] = $cut;
}
