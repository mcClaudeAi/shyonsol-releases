<?php
//MC 2026-10-09 the 15 Club bounty, for the lobby card: GET -> this month's bounty, open or claimed
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache');
header('X-Content-Type-Options: nosniff');
define('SHY_API', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
out(['ok' => true] + bounty_public(strtolower((string)($_GET['me'] ?? ''))));   // me: a 6-letter tag, to show your own spot on the board
