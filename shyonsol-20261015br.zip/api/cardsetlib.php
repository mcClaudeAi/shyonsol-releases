<?php
// Season cards. The original 71-card deck never changes; each season adds one new card on top of it, chosen by $SHY
// holders from a set of candidates. Every candidate has to pass the balance test first (500,000 simulated games with it
// added to the deck, see admin/balance-s<N>.json); a card that fails is never put to the vote.
//   cardset.php  'public' => bool                       the candidates are shown to everyone, not only holders
//                'votes'  => [card => [pid => time]]     votes for the coming season's card
//                'active' => [['id', 'season', 'from', 'votes', 'by']]   cards in play, oldest first
// The vote closes when the season starts. Its winner joins play at that moment, a Monday at 00:00 UTC, so every Daily
// is played on one deck from start to finish. Names and rules here must match the cards in assets/game.js and engine.php.
if (!defined('SHY_API')) { http_response_code(404); exit; }
if (!defined('CARDSET')) define('CARDSET', DATA_DIR . '/cardset.php');

// every card that has been or will be put to a season vote
const SEASON_CARDS = [
    'kamikaze' => ['name' => 'Divine Wind', 'kind' => 'global', 'kanji' => '神風', 'text' => 'Every player, you too, discards 1 Chaos card. Then you draw 2 Regions.'],
    'decree'   => ['name' => "Shogun's Decree", 'kind' => 'attack', 'kanji' => '将軍', 'text' => 'Steal 1 Region from the rival with the most. If you have the fewest Regions, steal 2.'],
    'ninja'    => ['name' => 'Ninja Infiltration', 'kind' => 'attack', 'kanji' => '忍者', 'text' => "Steal 1 Region from any rival. Bunkers, domes and Lone Survivor don't stop it."],
    'paper'    => ['name' => 'Paper Fortress', 'kind' => 'defense', 'kanji' => '紙城', 'text' => 'Block the next attack on you. When it breaks, draw 1 Chaos card.'],
    'harvest'  => ['name' => 'Rice Harvest', 'kind' => 'gain', 'kanji' => '豊作', 'text' => 'Draw 1 Region now and 1 more at the start of your next turn.'],
    'ronin'    => ['name' => 'Ronin for Hire', 'kind' => 'trick', 'kanji' => '浪人', 'text' => "Take a random Chaos card from a rival's hand."],
    'truce'    => ['name' => 'Tea Ceremony Truce', 'kind' => 'global', 'kanji' => '茶道', 'text' => 'No one can attack until your next turn. Draw 1 Chaos card.'],
    'eclipse'  => ['name' => 'Eclipse', 'kind' => 'passive', 'kanji' => '日食', 'text' => 'Keep it in your hand. The next rival who steals from you loses 1 Region instead.'],
];
// the sets, by the season their winner joins. 'cards' lists only the candidates that passed the balance test.
const CARD_SETS = [
    // tested Oct 8, 2026: Paper Fortress won too often (36.7% when used, originals 20.5 to 34.6%), Ronin for Hire and
    // Tea Ceremony Truce were hardly ever worth playing (under 1% of games). The other five are on the ballot.
    2 => ['id' => 'rising-sun', 'name' => 'Rising Sun', 'blurb' => 'Five new Chaos cards from the land of the rising sun. Each one played 500,000 test games added to the deck before it was put to the vote. The winner joins the game when Season 2 starts.',
        'cards' => ['kamikaze', 'decree', 'ninja', 'harvest', 'eclipse']],
];
const VOTES_EACH = 3;

// the stored data, with votes from before seasons were tracked counted for Season 2
function cs_data() {
    $d = load(CARDSET);
    if (!empty($d['votes']) && !is_int(array_key_first($d['votes']))) $d['votes'] = [2 => $d['votes']];
    return $d;
}
function cs_epoch() { return strtotime('2026-10-05 00:00:00 UTC'); }        // same epoch and length as the ranked seasons
function cs_season_start($s) { return cs_epoch() + ($s - 1) * 28 * 86400; }
function cs_season_now($ts = null) { return max(1, intdiv(($ts ?? time()) - cs_epoch(), 28 * 86400) + 1); }

// the set being voted on right now: the first season that hasn't started yet. null when no set is planned.
function cs_next_set($ts = null) {
    $ts = $ts ?? time();
    foreach (CARD_SETS as $s => $set) if (cs_season_start($s) > $ts) return $set + ['season' => $s, 'opens' => cs_season_start($s)];
    return null;
}
function cs_balance($s) {
    static $b = [];
    if (!isset($b[$s])) $b[$s] = json_decode((string)@file_get_contents(dirname(__DIR__) . '/admin/balance-s' . (int)$s . '.json'), true) ?: [];
    return $b[$s];
}
// the winner of a season's vote: most votes; a tie goes to the card that reached its total first;
// no votes at all goes to the candidate the balance test rated closest to the original deck's middle
function cs_winner($s, $d) {
    $set = CARD_SETS[$s] ?? null; if (!$set) return null;
    $votes = $d['votes'][$s] ?? [];
    $best = null; $bn = 0; $bt = PHP_INT_MAX;
    foreach ($set['cards'] as $id) {
        $v = $votes[$id] ?? []; $n = count($v); $t = $n ? max($v) : PHP_INT_MAX;
        if ($n > $bn || ($n === $bn && $n > 0 && $t < $bt)) { $best = $id; $bn = $n; $bt = $t; }
    }
    if ($best) return ['id' => $best, 'votes' => $bn, 'by' => 'vote'];
    $bal = cs_balance($s)['cards'] ?? [];
    $pick = null; $gap = INF;
    foreach ($set['cards'] as $id) if (isset($bal[$id]['gap']) && $bal[$id]['gap'] < $gap) { $gap = $bal[$id]['gap']; $pick = $id; }
    return ['id' => $pick ?: $set['cards'][0], 'votes' => 0, 'by' => 'balance'];
}
// cards in play, oldest first, including a season that has started but hasn't been written down yet
function cs_active($d = null, $ts = null) {
    $d = $d ?? cs_data(); $ts = $ts ?? time();
    $act = []; foreach ($d['active'] ?? [] as $a) $act[(int)$a['season']] = $a;
    foreach (CARD_SETS as $s => $set) {
        if (isset($act[$s]) || cs_season_start($s) > $ts) continue;
        $w = cs_winner($s, $d);
        if ($w) $act[$s] = ['id' => $w['id'], 'season' => $s, 'from' => cs_season_start($s), 'votes' => $w['votes'], 'by' => $w['by']];
    }
    ksort($act);
    return array_values($act);
}
// the season cards in the deck at a moment: what the game, the server's replay, live matches and replays all use
function season_deck_at($ts = null) {
    $ts = $ts ?? time();
    return array_values(array_map(fn($a) => $a['id'], array_filter(cs_active(null, $ts), fn($a) => $a['from'] <= $ts)));
}
// called on ordinary traffic (game starts, the cards page): the first visit after a season starts records its card
function cs_maybe_finalize() { if (count(cs_data()['active'] ?? []) < count(cs_active())) with_lock(fn() => cs_finalize()); }
// writes a started season's winner down for good (locked: call inside with_lock). Returns the newly added entries.
function cs_finalize() {
    $d = cs_data(); $have = array_column($d['active'] ?? [], 'season'); $new = [];
    foreach (cs_active($d) as $a) if (!in_array($a['season'], $have, true)) { $d['active'][] = $a; $new[] = $a; }
    if ($new) {
        save(CARDSET, $d);
        if (function_exists('tg_post')) foreach ($new as $a) {
            $c = SEASON_CARDS[$a['id']];
            tg_post('weekly', '🎴 <b>Season ' . (int)$a['season'] . ' is here.</b> ' . tg_h($c['name']) . ' joins the deck today' . ($a['by'] === 'vote' ? ', voted in by $SHY holders' : '') . ".\n<i>" . tg_h($c['text']) . "</i>\n" . tg_link('/cards#next-set', 'See the season cards'), 'season-card:' . (int)$a['season']);
        }
    }
    return $new;
}
