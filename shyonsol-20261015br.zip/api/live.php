<?php
// Shilluminati Online live matches. The server runs every game; players only ever see their own hand.
// POST JSON {a: quick|create|join|state|start|act|react|leave, ...}

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

define('SHY_API', 1);
define('SHY_ENGINE', 1);
require __DIR__ . '/common.php';
require __DIR__ . '/holders.php';
require __DIR__ . '/economy.php';
require __DIR__ . '/livelib.php';

//MC 2026-10-11 the Telegram invite button in a room needs the mini app link on the website too (it was only known
//   inside Telegram), so a friend tapping the invite opens the game in Telegram straight into the room.
function tg_invite_base() {
    $f = DATA_DIR . '/telegram.php';
    if (!is_file($f)) return '';
    $c = load($f);
    return !empty($c['bot']) && !empty($c['app']) ? 'https://t.me/' . $c['bot'] . '/' . $c['app'] . '?startapp=join_' : '';
}

// ---------- request ----------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('use POST', 405);
$raw = file_get_contents('php://input');
if (strlen($raw) > 4000) fail('too large');
$body = json_decode($raw, true) ?: [];
$a = (string)($body['a'] ?? '');

if ($a === 'quick' || $a === 'create') {
    limit('room', 40, 600);
    $prof = player_profile($body);
    cleanup();
    if ($a === 'quick') {
        // join the newest open public room that still has seats
        $open = with_lock(function () { $l = load(LOBBY); $t = now(); $l = array_filter($l, fn($ts) => $t - $ts < QUICK_WAIT - 3); save(LOBBY, $l); arsort($l); return array_keys($l); });
        foreach ($open as $code) {
            $r = with_room($code, function (&$room) use ($prof) {
                tick($room);
                if ($room['status'] !== 'waiting') return null;
                $s = seat_add($room, $prof);
                if (!$s) return null;
                if (humans($room) >= SEATS) start_game($room);
                return ['seat' => $s[0], 'secret' => $s[1]];
            });
            if (is_array($r) && isset($r['seat'])) out(['ok' => true, 'code' => $code, 'tgInvite' => tg_invite_base()] + $r);
        }
    }
    for ($try = 0; $try < 5; $try++) {
        $code = new_code();
        if (is_file(room_file($code))) continue;
        $public = $a === 'quick';
        $r = with_room($code, function (&$room) use ($prof, $code, $public) {
            $room = new_room($public); $room['code'] = $code;
            $s = seat_add($room, $prof);
            return ['seat' => $s[0], 'secret' => $s[1]];
        }, true);
        if ($public) lobby_add($code);
        out(['ok' => true, 'code' => $code, 'tgInvite' => tg_invite_base()] + $r);
    }
    fail('Could not open a room. Try again.', 500);
}

//MC 2026-10-12 the Shogun: a 1v1 against the boss bot, started on the spot. 'bossinfo' is what the Play page shows.
function boss_open($prof) {
    $cfg = boss_cfg();
    for ($try = 0; $try < 5; $try++) {
        $code = new_code();
        if (is_file(room_file($code))) continue;
        return ['code' => $code] + with_room($code, function (&$room) use ($prof, $code, $cfg) {
            $room = new_room(false); $room['code'] = $code;
            $room['boss'] = ['edge' => $cfg['edge'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'think' => $cfg['think']];
            $s = seat_add($room, $prof);
            $room['seats'][] = ['name' => BOSS_NAME, 'avatar' => '', 'human' => false, 'boss' => true, 'style' => '', 'away' => false, 'gone' => false];
            start_game($room);
            return ['seat' => $s[0], 'secret' => $s[1]];
        }, true);
    }
    return null;
}
if ($a === 'bossinfo') {
    limit('rooms', 120, 600);
    $pid = (string)($body['pid'] ?? '');
    out(['ok' => true, 'boss' => boss_info(preg_match('/^[a-f0-9]{16}$/', $pid) ? $pid : '')]);
}
if ($a === 'boss') {
    limit('room', 40, 600);
    $prof = player_profile($body);
    $cfg = boss_cfg();
    if (!$cfg['on']) fail('The Shogun is resting right now. Try again later.', 409);
    if (!boss_start_ok($prof['pid'], $cfg['games'])) fail('That is ' . $cfg['games'] . ' matches against the Shogun today. Come back tomorrow.', 429);
    cleanup();
    $r = boss_open($prof);
    if (!$r) fail('Could not open a room. Try again.', 500);
    out(['ok' => true, 'tgInvite' => tg_invite_base()] + $r);
}

// matches anyone can watch right now: quick matches and tournament tables with real players at them
if ($a === 'rooms') {
    limit('rooms', 120, 600);
    $files = is_dir(ROOMS) ? glob(ROOMS . '/*.php') : [];
    usort($files, fn($x, $y) => filemtime($y) <=> filemtime($x));
    $out = [];
    foreach (array_slice($files, 0, 80) as $f) {
        $room = load($f);
        if (($room['status'] ?? '') !== 'playing' || (!$room['public'] && empty($room['tourney'])) || humans($room) < 1 || empty($room['g'])) continue;
        $out[] = ['code' => $room['code'], 'tourney' => $room['tourney']['name'] ?? '', 'final' => !empty($room['tourney']['final']), 'round' => (int)$room['g']['round'], 'deck' => count($room['g']['regionDeck']),
            'humans' => humans($room), 'watchers' => count(array_filter($room['watch'] ?? [], fn($t) => $t > now() - 15)),
            'seats' => array_map(fn($x, $i) => ['name' => preg_replace('/ \(bot\)$/', '', $x['name']), 'human' => !empty($x['human']), 'regions' => count($room['g']['players'][$i]['regions'] ?? [])], $room['seats'], array_keys($room['seats']))];
        if (count($out) >= 12) break;
    }
    // tournament tables first, then the busiest
    usort($out, fn($x, $y) => [$y['tourney'] !== '', $y['final'], $y['humans']] <=> [$x['tourney'] !== '', $x['final'], $x['humans']]);
    out(['ok' => true, 'rooms' => $out]);
}

$code = strtoupper((string)($body['code'] ?? ''));
if (!valid_code($code)) fail('That room code doesn\'t look right.');

// watching a match: no seat, no hand, nothing to play
if ($a === 'watch') {
    limit('watch', 900, 600);
    $wid = substr(hash('sha256', client_ip() . ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 10);
    $r = with_room($code, function (&$room) use ($body, $wid) {
        if (!$room) return ['err' => 'That match is over or the code is wrong.', 'code' => 404];
        tick($room);
        // count who's watching, without writing the room on every poll
        if (($room['watch'][$wid] ?? 0) < now() - 6) { $room['watch'][$wid] = now(); $room['watch'] = array_filter($room['watch'], fn($t) => $t > now() - 30); }
        if ((int)($body['ver'] ?? 0) === $room['ver']) return ['same' => true, 'ver' => $room['ver'], 'now' => now()];
        return view($room, -1) + ['watch' => true];
    });
    if (isset($r['err'])) fail($r['err'], $r['code']);
    out(['ok' => true] + $r);
}

if ($a === 'join') {
    limit('room', 40, 600);
    $prof = player_profile($body);
    $r = with_room($code, function (&$room) use ($prof) {
        tick($room);
        //MC 2026-10-10 an old private room still took a join (the timeout only ran on state calls), and a room the host
        //   closed said "already started". A friend tapping a stale challenge now gets told the invite is off.
        if ($room['status'] === 'waiting' && !$room['public'] && now() - $room['created'] > PRIVATE_TTL) { $room['status'] = 'closed'; $room['ver']++; }
        $s = seat_add($room, $prof);
        if (!$s) return ['err' => $room['status'] === 'waiting' ? 'That room is full.' : ($room['status'] === 'closed' ? 'That room was closed, so the invite is off.' : ($room['status'] === 'over' ? 'That match is over.' : 'That match already started.')), 'code' => 409];
        if ($room['public'] && humans($room) >= SEATS) start_game($room);
        return ['seat' => $s[0], 'secret' => $s[1]];
    });
    if (isset($r['err'])) fail($r['err'], $r['code']);
    out(['ok' => true, 'code' => $code, 'tgInvite' => tg_invite_base()] + $r);
}

$r = with_room($code, function (&$room) use ($a, $body) {
    $seat = auth($room, $body);
    if ($seat < 0) return ['err' => 'You are not in this room.', 'code' => 403];
    $s = &$room['seats'][$seat];
    $s['seen'] = now();
    fp_seen($s);   //MC 2026-10-10 Fair Play
    if (!empty($s['gone'])) { $s['gone'] = false; $room['ver']++; }
    // late to a tournament table: take the seat back from the bot
    if (!empty($s['ns'])) { unset($s['ns']); $s['away'] = false; $room['ver']++; }
    unset($s);

    if ($a === 'start') {
        if ($seat !== 0 || !empty($room['tourney'])) return ['err' => 'Only the host can start.', 'code' => 403];
        if ($room['status'] === 'waiting') start_game($room);
    } elseif ($a === 'act') {
        tick($room);
        $g = &$room['g'];
        if ($room['status'] !== 'playing' || $room['phase'] !== 'act' || $g['turn'] !== $seat) return ['err' => 'Not your turn.', 'code' => 409];
        $room['seats'][$seat]['strikes'] = 0;
        $room['seats'][$seat]['away'] = false;
        $room['firstTurnDone'][$seat] = 1;
        $room['fpt'][$seat] = ($room['fpt'][$seat] ?? 0) + 1;   //MC 2026-10-10 Fair Play: moves the player made themselves
        if (!empty($body['pass'])) {
            // ending a turn without playing claims a Region (eng_end_turn does it and logs it)
            if ($g['played']) say($g, $seat, $g['players'][$seat]['name'] . ' ends the turn.', 'info');
            finish_turn($room, AFTER_CLAIM);
        } else {
            $h = (int)($body['hand'] ?? -1);
            $target = isset($body['target']) && $body['target'] !== null ? (int)$body['target'] : null;
            $cid = $g['players'][$seat]['hand'][$h] ?? null;
            if (!eng_play($g, $seat, $h, $target)) return ['err' => "That card can't be played like that.", 'code' => 400];
            if (is_string($cid)) $room['pc'][$seat][] = $cid;   // for card mastery: only cards the player chose
            if ($target !== null && $target !== $seat && isset($room['seats'][$target])) $room['fpa'][$seat][$target] = ($room['fpa'][$seat][$target] ?? 0) + 1;   //MC 2026-10-10 Fair Play: who attacked whom
            if (eng_more_plays($g, $seat)) {
                // more plays this turn: the clock gets a little more time, the turn stays open
                $room['deadline'] = max($room['deadline'], now() + 15);
                $room['ver']++;
            } else finish_turn($room, AFTER_PLAY);
        }
        unset($g);
    } elseif ($a === 'chat') {   //MC 2026-10-12 live chat, see chat_add() in livelib.php
        if ($room['status'] === 'over' && now() - (int)($room['ended'] ?? now()) > 600) return ['err' => 'This match ended a while ago.', 'code' => 409];
        $why = chat_add($room, $seat, $body['text'] ?? '');
        if ($why !== '') return ['err' => $why, 'code' => 429];
        } elseif ($a === 'react') {
        $e = (int)($body['e'] ?? -1);
        $last = 0;
        foreach ($room['reacts'] as $x) if ($x['seat'] === $seat) $last = max($last, $x['ts']);
        $allowed = $room['seats'][$seat]['reacts'] ?? range(0, REACTIONS - 1);
        if (in_array($e, $allowed, true) && now() - $last > 1.2) {
            $room['reacts'][] = ['seat' => $seat, 'e' => $e, 'ts' => now(), 'id' => bin2hex(random_bytes(4))];
            $room['reacts'] = array_values(array_filter($room['reacts'], fn($x) => now() - $x['ts'] < 8));
            $room['ver']++;
        }
    } elseif ($a === 'rematch') {
        if ($room['status'] !== 'over') return ['err' => 'The match is still going.', 'code' => 409];
        if (!empty($room['tourney'])) return ['err' => 'Tournament tables don\'t rematch. Check the bracket for your next table.', 'code' => 409];
        if (!empty($room['boss'])) {   //MC 2026-10-12 a boss rematch is a new boss match (it counts toward the day's matches)
            $me = $room['seats'][$seat]; $cfg = boss_cfg();
            if (!$cfg['on']) return ['err' => 'The Shogun is resting right now.', 'code' => 409];
            if (!boss_start_ok($me['pid'], $cfg['games'])) return ['err' => 'That is ' . $cfg['games'] . ' matches against the Shogun today. Come back tomorrow.', 'code' => 429];
            $prof = ['pid' => $me['pid'], 'kh' => $me['kh'], 'name' => $me['name'], 'avatar' => $me['avatar'] ?? '', 'holder' => !empty($me['holder']), 'cos' => $me['cos'] ?? [], 'reacts' => $me['reacts'] ?? []];
            $nr = boss_open($prof);
            if (!$nr) return ['err' => 'Could not open a rematch.', 'code' => 500];
            return ['rematch' => $nr['code'], 'seat' => $nr['seat'], 'secret' => $nr['secret']];
        }
        if (!empty($room['rematch'])) return ['rematch' => $room['rematch']];
        $me = $room['seats'][$seat];
        $prof = ['pid' => $me['pid'], 'kh' => $me['kh'], 'name' => $me['name'], 'avatar' => $me['avatar'] ?? '', 'holder' => !empty($me['holder']), 'cos' => $me['cos'] ?? [], 'reacts' => $me['reacts'] ?? []];
        for ($try = 0; $try < 5; $try++) {
            $nc = new_code();
            if (is_file(room_file($nc))) continue;
            $made = with_room($nc, function (&$nr) use ($prof, $nc) {
                $nr = new_room(false); $nr['code'] = $nc;
                $s = seat_add($nr, $prof);
                return ['seat' => $s[0], 'secret' => $s[1]];
            }, true);
            $room['rematch'] = $nc; $room['ver']++;
            return ['rematch' => $nc] + $made;
        }
        return ['err' => 'Could not open a rematch.', 'code' => 500];
    } elseif ($a === 'hold') {
        //MC 2026-10-15 Wait for real players: a quick match waiting for its seats gives everyone a minute more to join,
        //   up to QUICK_HOLD_MAX after it opened. Anyone seated can ask; the countdown everyone sees moves with it.
        if ($room['status'] !== 'waiting' || empty($room['public']) || !empty($room['tourney'])) return ['err' => 'Only a quick match waiting for players can wait longer.', 'code' => 409];
        $room['hold'] = min($room['created'] + QUICK_HOLD_MAX, quick_starts($room) + QUICK_HOLD);
        $room['ver']++;
        $GLOBALS['HOLD_LOBBY'] = [$room['code'] ?? '', quick_starts($room)];   // the lobby list keeps it joinable (below, outside the room lock)
    } elseif ($a === 'leave') {
        if ($room['status'] === 'waiting') {
            if ($seat === 0 && !$room['public']) { $room['status'] = 'closed'; }
            else { $room['seats'][$seat]['human'] = false; $room['seats'][$seat]['style'] = 'wild'; $room['seats'][$seat]['name'] .= ' (left)'; $room['seats'][$seat]['sh'] = ''; }
            $room['ver']++;
        } else {
            $room['seats'][$seat]['away'] = true;
            // leaving a tournament table is a forfeit: the bot in that seat can't carry them through
            if (!empty($room['tourney'])) { $room['seats'][$seat]['human'] = false; $room['seats'][$seat]['tleft'] = 1; $room['seats'][$seat]['name'] .= ' (left)'; }
            $room['ver']++;
        }
        return ['left' => true];
    }
    tick($room);
    if ($room['status'] === 'waiting' && !$room['public'] && now() - $room['created'] > PRIVATE_TTL) { $room['status'] = 'closed'; $room['ver']++; }
    if ($a === 'state' && (int)($body['ver'] ?? 0) === $room['ver']) return ['same' => true, 'ver' => $room['ver'], 'now' => now()];
    return view($room, $seat);
});
if (isset($r['err'])) fail($r['err'], $r['code']);
//MC 2026-10-15 a held quick match stays in the lobby list for Find a match until its new start time
if (!empty($GLOBALS['HOLD_LOBBY'][0])) { [$hc, $hs] = $GLOBALS['HOLD_LOBBY']; with_lock(function () use ($hc, $hs) { $l = load(LOBBY); if (isset($l[$hc])) { $l[$hc] = $hs - QUICK_WAIT; save(LOBBY, $l); } }); }
out(['ok' => true] + $r);
