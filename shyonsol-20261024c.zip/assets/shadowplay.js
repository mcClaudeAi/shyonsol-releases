//MC 2026-10-24 Living Shadows, part 2: a holder's Shytoshi Shadow steps off its square and plays the card itself.
//   The figure is the real Shadow, cut out of its background once (api/shadowcut.php, cut on GitHub's machines by
//   checks/shadow_cut.py). Nothing is drawn onto the art: no arms, no hands. The cut figure is lit and moved like a
//   character on a stage instead. A rim light and a key light are masked to the figure's own outline, so when the card
//   appears in front of it the Shadow is lit by the card, the visor catches a glint, and when the card fires the whole
//   figure flashes from the side it left on. The card is summoned from a sigil at the Shadow's chest and moves on its
//   own, the way Chaos cards should: Attack charges and fires it at the war table, Defense turns it into a dome that
//   takes a hit, Global raises it into a pillar of light that bursts. Letterbox bars, a camera lean and a push-in make
//   it read as a cut-in, and it's over in about two seconds. A tap skips it. Reduce Motion and the "Shadow plays"
//   switch in the game's Settings turn it off. Until a Shadow has its cut, nothing plays for it (no half version).
(function () {
  "use strict";
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var INFO = {}, AURA = { cyan: "#3ff6ff", crimson: "#ff3b5c", lightning: "#9fd0ff", money: "#ffd166", btc: "#f7931a", none: "#b9a6ff" };
  var KIND = { attack: "#ff6a5e", defense: "#6ad3ff", global: "#ffd27a" };
  function on() { try { return localStorage.getItem("shy-sp") !== "off"; } catch (e) { return true; } }
  function setOn(v) { try { localStorage.setItem("shy-sp", v ? "on" : "off"); } catch (e) {} }
  function info(n) {
    n = String(n || "");
    if (!/^\d{1,5}$/.test(n)) return Promise.resolve(null);
    if (!INFO[n]) INFO[n] = fetch("api/shadowcut.php?n=" + n).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.has) return null;
      var src = "api/shadowcut.php?n=" + n + "&img=1&v=" + j.v;
      return new Promise(function (res) { var im = new Image(); im.onload = function () { res(Object.assign({ src: src }, j)); }; im.onerror = function () { res(null); }; im.src = src; });
    }).catch(function () { return null; });
    return INFO[n];
  }
  function within(p, ms) { return Promise.race([p, new Promise(function (r) { setTimeout(function () { r(null); }, ms); })]); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  var SIGIL = (function () {
    var r = '<svg viewBox="-50 -50 100 100"><g fill="none" stroke="currentColor"><circle r="46" stroke-width="1.2" stroke-dasharray="3 5"/><circle r="38" stroke-width=".8" opacity=".7"/><path d="M0 -38L33 19L-33 19Z" stroke-width="1.4"/><path d="M0 38L33 -19L-33 -19Z" stroke-width=".8" opacity=".6"/><circle r="8" stroke-width="1.6"/></g>';
    for (var a = 0; a < 360; a += 30) r += '<circle cx="' + (42 * Math.cos(a * Math.PI / 180)).toFixed(1) + '" cy="' + (42 * Math.sin(a * Math.PI / 180)).toFixed(1) + '" r="1.6" fill="currentColor"/>';
    return r + "</svg>";
  })();
  // o: { root, n, au, kind: attack|defense|global, card (image url), name, mirror, sfx(fn), shake(fn), target (element) }
  function play(o) {
    if (reduce || !on() || !o || !o.root) return Promise.resolve(false);
    return within(info(o.n), 600).then(function (cut) { return cut ? run(o, cut) : false; });
  }
  var cur = null;
  function run(o, cut) {
    return new Promise(function (done) {
      var vw = window.innerWidth, vh = window.innerHeight, G = o.root.getBoundingClientRect();
      var R = { left: Math.max(0, G.left), top: Math.max(0, G.top), right: Math.min(vw, G.right), bottom: Math.min(vh, G.bottom) };
      R.width = R.right - R.left; R.height = R.bottom - R.top;
      if (R.width < 240 || R.height < 240) return done(false);
      var phone = R.width < 700, mir = !!o.mirror, kind = o.kind, au = AURA[o.au] || AURA.none, kc = KIND[kind] || KIND.attack;
      // the figure: as tall as the stage allows, anchored to the bottom corner it enters from
      var H = Math.round(Math.min(phone ? R.height * .52 : R.height * .74, 560, (phone ? R.width * .78 : R.width * .5) / cut.ar)), W = Math.round(H * cut.ar);
      var st = document.createElement("div");
      st.className = "sp-stage" + (mir ? " mir" : "") + (phone ? " ph" : "");
      st.style.cssText = "left:" + R.left + "px;top:" + R.top + "px;width:" + R.width + "px;height:" + R.height + "px;--au:" + au + ";--kc:" + kc + ";--h:" + H + "px;--w:" + W + "px";
      var M = 'style="-webkit-mask-image:url(' + cut.src + ');mask-image:url(' + cut.src + ')"';
      st.innerHTML = '<div class="sp-dim"></div><div class="sp-bar t"></div><div class="sp-bar b"></div><div class="sp-rays"></div>' +
        '<div class="sp-cam"><div class="sp-fig"><div class="sp-figin">' +
        '<div class="sp-lay sp-drop" ' + M + '></div><div class="sp-lay sp-glow"></div>' +
        '<img class="sp-lay sp-ghost" src="' + cut.src + '" alt=""><img class="sp-lay sp-ghost g2" src="' + cut.src + '" alt="">' +
        '<img class="sp-bust" src="' + cut.src + '" alt="">' +
        '<div class="sp-lay sp-rim" ' + M + '></div><div class="sp-lay sp-key" ' + M + '></div><div class="sp-lay sp-glint" ' + M + '><i></i></div>' +
        '</div></div></div>' +
        '<div class="sp-sigil">' + SIGIL + '</div>' +
        '<div class="sp-card"><img src="' + esc(o.card || "") + '" alt=""><i></i></div>' +
        '<div class="sp-fx"></div>' +
        '<div class="sp-name"><small>' + (mir ? "Rival" : "Your") + " Shadow</small><b>#" + esc(o.n) + (o.name ? " · " + esc(o.name) : "") + '</b></div><div class="sp-skip">Tap to skip</div>';
      document.body.appendChild(st);
      var $ = function (c) { return st.querySelector(c); };
      var cam = $(".sp-cam"), fig = $(".sp-fig"), figin = $(".sp-figin"), card = $(".sp-card"), sigil = $(".sp-sigil"), fx = $(".sp-fx"), rays = $(".sp-rays"), key = $(".sp-key"), rim = $(".sp-rim"), glint = $(".sp-glint i"), glow = $(".sp-glow"), g1 = $(".sp-ghost"), g2 = $(".sp-ghost.g2");
      var anims = [], timers = [], ended = false;
      function A(el, frames, ms, delay, ease) { var a = el.animate(frames, { duration: ms, delay: delay || 0, easing: ease || "cubic-bezier(.4,0,.2,1)", fill: "forwards" }); anims.push(a); return a; }
      function T(ms, fn) { timers.push(setTimeout(fn, ms)); }
      function finish() {
        if (ended) return; ended = true;
        anims.forEach(function (a) { try { a.cancel(); } catch (e) {} }); timers.forEach(clearTimeout);
        st.remove(); cur = null; done(true);
      }
      cur = finish;
      st.addEventListener("pointerdown", finish);
      var sx = mir ? -1 : 1, S = R, FX = function () { return fig.getBoundingClientRect(); };
      // where the card lands: the war table if it's on screen, else the upper middle of the stage
      var tgt = (function () { var m = o.target && o.target.getBoundingClientRect(); if (m && m.width && m.bottom > S.top && m.top < S.bottom) { var t0 = Math.max(S.top, m.top), t1 = Math.min(S.bottom, m.bottom); return { x: m.left + m.width / 2 - S.left, y: (t0 + t1) / 2 - S.top }; } return { x: S.width * (mir ? .38 : .62), y: S.height * .32 }; })();
      function P(x, y) { card.style.left = x + "px"; card.style.top = y + "px"; }
      function spark(x, y, col, n, spread) {
        for (var i = 0; i < n; i++) {
          var a = Math.random() * 6.283, d = spread * (.4 + Math.random()), s = document.createElement("i"); s.className = "sp-spark"; s.style.left = x + "px"; s.style.top = y + "px"; s.style.background = col; fx.appendChild(s);
          A(s, [{ transform: "translate(0,0) scale(1)", opacity: 1 }, { transform: "translate(" + Math.cos(a) * d + "px," + (Math.sin(a) * d) + "px) scale(.2)", opacity: 0 }], 500 + Math.random() * 400, 0, "cubic-bezier(.1,.6,.3,1)");
        }
      }
      function flash(ms, op) { var f = document.createElement("i"); f.className = "sp-flash"; fx.appendChild(f); A(f, [{ opacity: op || .9 }, { opacity: 0 }], ms || 360, 0, "ease-out"); }
      function ring(x, y, col, size, ms) { var r = document.createElement("i"); r.className = "sp-ring"; r.style.left = x + "px"; r.style.top = y + "px"; r.style.borderColor = col; r.style.width = r.style.height = size + "px"; fx.appendChild(r); A(r, [{ transform: "translate(-50%,-50%) scale(.1)", opacity: 1 }, { transform: "translate(-50%,-50%) scale(1)", opacity: 0 }], ms || 600, 0, "cubic-bezier(.1,.7,.2,1)"); }
      // the card's place in front of the chest, and its raised place
      function chest() { var f = FX(); return { x: f.left - S.left + f.width * (mir ? .36 : .64), y: f.top - S.top + f.height * .66 }; }
      function raised() { var f = FX(), cw = H * (phone ? .32 : .27), x = f.left - S.left + (mir ? -cw * .35 : f.width + cw * .35); return { x: Math.max(cw * .8, Math.min(S.width - cw * .8, x)), y: f.top - S.top + f.height * .4 }; }
      // the figure is lit from wherever the card is
      function lightFrom(p) { var f = FX(); figin.style.setProperty("--lx", ((p.x + S.left - f.left) / f.width * 100).toFixed(1) + "%"); figin.style.setProperty("--ly", ((p.y + S.top - f.top) / f.height * 100).toFixed(1) + "%"); }
      var CAM0 = "perspective(1200px) rotateY(" + (sx * -9) + "deg) rotateX(2deg) scale(1)", CAM1 = "perspective(1200px) rotateY(" + (sx * -5) + "deg) rotateX(1deg) scale(1.03)";

      // ---- 1. the cut-in: bars close, the table dims, the Shadow slides in with a trail
      A($(".sp-dim"), [{ opacity: 0 }, { opacity: 1 }], 260, 0, "ease-out");
      A($(".sp-bar.t"), [{ transform: "translateY(-100%)" }, { transform: "translateY(0)" }], 300, 0, "cubic-bezier(.2,.8,.2,1)");
      A($(".sp-bar.b"), [{ transform: "translateY(100%)" }, { transform: "translateY(0)" }], 300, 0, "cubic-bezier(.2,.8,.2,1)");
      A(fig, [{ transform: "translate3d(" + (-sx * 60) + "%,6%,0) scale(.92)", opacity: 0 }, { transform: "translate3d(0,0,0) scale(1)", opacity: 1 }], 380, 40, "cubic-bezier(.15,.9,.25,1)");
      A(g1, [{ transform: "translate3d(" + (-sx * 22) + "%,0,0)", opacity: .35 }, { transform: "translate3d(0,0,0)", opacity: 0 }], 420, 140, "ease-out");
      A(g2, [{ transform: "translate3d(" + (-sx * 44) + "%,0,0)", opacity: .2 }, { transform: "translate3d(0,0,0)", opacity: 0 }], 460, 200, "ease-out");
      A(cam, [{ transform: CAM0 }, { transform: CAM1 }], 700, 300, "ease-in-out");
      A($(".sp-name"), [{ opacity: 0, transform: "translateY(8px)" }, { opacity: 1, transform: "translateY(0)" }], 300, 260);
      A($(".sp-skip"), [{ opacity: 0 }, { opacity: 1 }], 300, 700);
      // breathing, the whole time
      A(figin, [{ transform: "translateY(0) scale(1)" }, { transform: "translateY(-.6%) scale(1.012)" }, { transform: "translateY(0) scale(1)" }], 2600, 0, "ease-in-out");
      // ---- 2. the summon: a sigil at the chest, the card rises out of it, the visor catches it
      T(300, function () { var c = chest(); spark(c.x, c.y, au, 14, 70); if (o.sfx) o.sfx("select"); });
      T(340, function () {
        var c = chest(); sigil.style.left = c.x + "px"; sigil.style.top = c.y + "px";
        A(sigil, [{ opacity: 0, transform: "translate(-50%,-50%) rotate(-40deg) scale(.3)" }, { opacity: 1, transform: "translate(-50%,-50%) rotate(0deg) scale(1)", offset: .35 }, { opacity: .85, transform: "translate(-50%,-50%) rotate(90deg) scale(1.08)" }], 1200, 0, "cubic-bezier(.2,.8,.2,1)");
        P(c.x, c.y); lightFrom(c);
        A(card, [{ opacity: 0, transform: "translate(-50%,-50%) perspective(600px) rotateX(70deg) scale(.3)" }, { opacity: 1, transform: "translate(-50%,-50%) perspective(600px) rotateX(0) scale(1)" }], 420, 0, "cubic-bezier(.2,.9,.25,1.2)");
        A(key, [{ opacity: 0 }, { opacity: .85 }], 420, 60);
        A(glow, [{ opacity: .35 }, { opacity: .8 }], 500, 0);
        A(glint, [{ transform: "translateX(-140%)" }, { transform: "translateX(140%)" }], 460, 240, "cubic-bezier(.3,0,.2,1)");
      });
      var total;
      if (kind === "attack") {
        // the card rises and tilts toward the table while the camera pulls back to charge, then it fires
        T(760, function () {
          var r = raised(); A(card, [{ left: card.style.left, top: card.style.top }, { left: r.x + "px", top: r.y + "px" }], 320, 0, "cubic-bezier(.3,.6,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateX(0) rotateY(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(" + (sx * -28) + "deg) rotateZ(" + (sx * 10) + "deg) scale(1.08)" }], 320, 0);
          A(cam, [{ transform: CAM1 }, { transform: "perspective(1200px) rotateY(" + (sx * 6) + "deg) rotateX(-2deg) scale(1) translateX(" + (-sx * 2) + "%)" }], 300, 0, "ease-out");
          A(rays, [{ opacity: 0, transform: "scale(.6)" }, { opacity: .55, transform: "scale(1)" }], 320, 0);
          T(330, function () { lightFrom(raised()); });
        });
        T(1180, function () {
          var a = raised(); if (o.sfx) o.sfx("hit");
          // the Shadow lunges, the figure flashes from the side the card leaves, the card streaks away
          A(cam, [{ transform: "perspective(1200px) rotateY(" + (sx * 6) + "deg) rotateX(-2deg) scale(1) translateX(" + (-sx * 2) + "%)" }, { transform: "perspective(1200px) rotateY(" + (sx * -14) + "deg) rotateX(3deg) scale(1.07) translateX(" + (sx * 4) + "%)" }], 180, 0, "cubic-bezier(.2,.9,.2,1)");
          A(rim, [{ opacity: 0 }, { opacity: 1, offset: .25 }, { opacity: .35 }], 500, 0);
          A(sigil, [{ opacity: .85, transform: "translate(-50%,-50%) rotate(90deg) scale(1.08)" }, { opacity: 0, transform: "translate(-50%,-50%) rotate(140deg) scale(1.6)" }], 300, 0);
          var mx = (a.x + tgt.x) / 2, my = Math.min(a.y, tgt.y) - S.height * .14, f = [];
          var at = function (t) { return { x: (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * mx + t * t * tgt.x, y: (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * my + t * t * tgt.y }; };
          P(a.x, a.y);
          for (var i = 0; i <= 12; i++) { var t = i / 12, q = at(t);
            f.push({ transform: "translate(-50%,-50%) translate(" + (q.x - a.x).toFixed(1) + "px," + (q.y - a.y).toFixed(1) + "px) perspective(600px) rotateY(" + (sx * (-28 + t * 720)) + "deg) scale(" + (1.08 - t * .55) + ")" }); }
          A(card, f, 300, 0, "cubic-bezier(.4,0,.6,1)");
          // the trail follows the same path by time, so a slow frame never piles it up
          var t0 = performance.now(), tr = setInterval(function () { var k = (performance.now() - t0) / 300; if (k >= 1) { clearInterval(tr); return; } var e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2, q = at(e), g = document.createElement("i"); g.className = "sp-streak"; g.style.left = q.x + "px"; g.style.top = q.y + "px"; g.style.width = (H * .2 * (1 - e * .5)) + "px"; g.style.height = (H * .26 * (1 - e * .5)) + "px"; fx.appendChild(g); A(g, [{ opacity: .5, transform: "translate(-50%,-50%) scale(1)" }, { opacity: 0, transform: "translate(-50%,-50%) scale(.3)" }], 240); }, 24);
          timers.push(tr);
          T(300, function () {
            clearInterval(tr); A(card, [{ opacity: 1 }, { opacity: 0 }], 60);
            flash(380, .75); ring(tgt.x, tgt.y, kc, Math.min(S.width, S.height) * .9, 650); ring(tgt.x, tgt.y, "#fff", Math.min(S.width, S.height) * .5, 450); spark(tgt.x, tgt.y, kc, 26, 150); spark(tgt.x, tgt.y, "#fff", 10, 90);
            if (o.shake) o.shake();
            A(rays, [{ opacity: .55 }, { opacity: 0 }], 500, 100);
            A(key, [{ opacity: .85 }, { opacity: 0 }], 400);
          });
        });
        total = 2250;
      } else if (kind === "defense") {
        // the card turns to face out and a dome of light blooms around the Shadow; something hits it and breaks
        T(760, function () {
          var r = raised(); r.y += H * .08; A(card, [{ left: card.style.left, top: card.style.top }, { left: r.x + "px", top: r.y + "px" }], 320, 0, "cubic-bezier(.3,.6,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateX(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(" + (sx * 12) + "deg) scale(1.05)" }], 320, 0);
          T(330, function () {
            var p = { x: parseFloat(card.style.left), y: parseFloat(card.style.top) }; lightFrom(p); if (o.sfx) o.sfx("block");
            var fr = FX(), dc = { x: fr.left - S.left + fr.width * .5, y: fr.top - S.top + fr.height * .42 };
            var d = document.createElement("i"); d.className = "sp-dome"; d.style.left = dc.x + "px"; d.style.top = dc.y + "px"; d.style.width = d.style.height = (H * 1.15) + "px"; fx.appendChild(d);
            A(d, [{ opacity: 0, transform: "translate(-50%,-50%) scale(.2)" }, { opacity: 1, transform: "translate(-50%,-50%) scale(1.06)", offset: .6 }, { opacity: .95, transform: "translate(-50%,-50%) scale(1)" }], 480, 0, "cubic-bezier(.2,.9,.25,1.15)");
            spark(p.x, p.y, kc, 18, 120);
            A(rays, [{ opacity: 0, transform: "scale(.6)" }, { opacity: .4, transform: "scale(1)" }], 400, 0);
            // the hit: a bolt from the far corner breaks on the dome
            T(520, function () {
              var from = { x: mir ? S.width * .08 : S.width * .92, y: S.height * .1 }, dx = dc.x - from.x, dy = dc.y - from.y, len = Math.hypot(dx, dy), ang = Math.atan2(dy, dx) * 180 / Math.PI;
              var b = document.createElement("i"); b.className = "sp-bolt"; b.style.left = from.x + "px"; b.style.top = from.y + "px"; b.style.width = Math.max(40, len - H * .55) + "px"; fx.appendChild(b);
              A(b, [{ transform: "rotate(" + ang + "deg) scaleX(0)", opacity: 1 }, { transform: "rotate(" + ang + "deg) scaleX(1)", opacity: 1, offset: .7 }, { transform: "rotate(" + ang + "deg) scaleX(1)", opacity: 0 }], 300, 0, "ease-in");
              T(210, function () {
                var hx = dc.x - Math.cos(ang * Math.PI / 180) * H * .55, hy = dc.y - Math.sin(ang * Math.PI / 180) * H * .55;
                A(sigil, [{ opacity: .85 }, { opacity: 0 }], 400);
                flash(300, .5); ring(hx, hy, "#fff", H * .6, 500); spark(hx, hy, "#d8f2ff", 22, 110); if (o.shake) o.shake(); if (o.sfx) o.sfx("block");
                A(d, [{ transform: "translate(-50%,-50%) scale(1)", filter: "brightness(1)" }, { transform: "translate(-50%,-50%) scale(1.06)", filter: "brightness(1.8)", offset: .2 }, { transform: "translate(-50%,-50%) scale(1)", filter: "brightness(1)" }], 420);
                A(rim, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .3 }], 500);
                A(cam, [{ transform: CAM1 }, { transform: "perspective(1200px) rotateY(" + (sx * -12) + "deg) rotateX(2deg) scale(1.02) translateX(" + (-sx * 2) + "%)", offset: .3 }, { transform: CAM1 }], 500);
                T(380, function () { A(d, [{ opacity: .95 }, { opacity: 0 }], 300); A(card, [{ opacity: 1 }, { opacity: 0 }], 300); A(key, [{ opacity: .85 }, { opacity: 0 }], 300); A(rays, [{ opacity: .4 }, { opacity: 0 }], 300); });
              });
            });
          });
        });
        total = 2650;
      } else {
        // the card rises above the Shadow into a pillar of light, the Shadow is lit from above, then it bursts
        T(760, function () {
          var f = FX(), top = { x: f.left - S.left + f.width * .5, y: Math.max(S.height * .12, f.top - S.top - H * .08) };
          A(card, [{ left: card.style.left, top: card.style.top }, { left: top.x + "px", top: top.y + "px" }], 520, 0, "cubic-bezier(.3,.5,.2,1)");
          A(card, [{ transform: "translate(-50%,-50%) perspective(600px) rotateY(0) scale(1)" }, { transform: "translate(-50%,-50%) perspective(600px) rotateY(360deg) scale(1.15)" }], 520, 0, "cubic-bezier(.3,.5,.2,1)");
          A(cam, [{ transform: CAM1 }, { transform: "perspective(1200px) rotateY(" + (sx * -3) + "deg) rotateX(5deg) scale(1.06) translateY(2%)" }], 520, 0);
          var pl = document.createElement("i"); pl.className = "sp-pillar"; pl.style.left = top.x + "px"; fx.appendChild(pl);
          A(pl, [{ opacity: 0, transform: "translateX(-50%) scaleX(.1)" }, { opacity: 1, transform: "translateX(-50%) scaleX(1)" }], 480, 120, "cubic-bezier(.2,.8,.2,1)");
          A(rays, [{ opacity: 0, transform: "scale(.5)" }, { opacity: .7, transform: "scale(1.1)" }], 600, 100);
          T(300, function () { lightFrom(top); if (o.sfx) o.sfx("global"); });
          T(620, function () {
            A(sigil, [{ opacity: .85 }, { opacity: 0 }], 300);
            flash(520, .95); ring(top.x, top.y, kc, Math.min(S.width, S.height) * 1.3, 800); ring(top.x, top.y, "#fff", Math.min(S.width, S.height) * .7, 600);
            spark(top.x, top.y, kc, 30, 220); spark(top.x, top.y, "#fff8e6", 16, 140); if (o.shake) o.shake();
            A(card, [{ opacity: 1, transform: "translate(-50%,-50%) perspective(600px) rotateY(360deg) scale(1.15)" }, { opacity: 0, transform: "translate(-50%,-50%) perspective(600px) rotateY(420deg) scale(2.2)" }], 260, 0, "ease-out");
            A(rim, [{ opacity: 0 }, { opacity: 1, offset: .2 }, { opacity: .4 }], 600);
            A(pl, [{ opacity: 1 }, { opacity: 0 }], 500, 100);
            A(rays, [{ opacity: .7 }, { opacity: 0 }], 600, 200);
            A(key, [{ opacity: .85 }, { opacity: 0 }], 500, 100);
          });
        });
        total = 2500;
      }
      // ---- out: the Shadow pulls back the way it came, the bars open
      A(fig, [{ transform: "translate3d(0,0,0) scale(1)", opacity: 1 }, { transform: "translate3d(" + (-sx * 30) + "%,4%,0) scale(.94)", opacity: 0 }], 280, total - 300, "cubic-bezier(.5,0,.8,.4)");
      A($(".sp-dim"), [{ opacity: 1 }, { opacity: 0 }], 260, total - 260, "ease-in");
      A($(".sp-bar.t"), [{ transform: "translateY(0)" }, { transform: "translateY(-100%)" }], 260, total - 260, "ease-in");
      A($(".sp-bar.b"), [{ transform: "translateY(0)" }, { transform: "translateY(100%)" }], 260, total - 260, "ease-in");
      A($(".sp-name"), [{ opacity: 1 }, { opacity: 0 }], 200, total - 260);
      A($(".sp-skip"), [{ opacity: 1 }, { opacity: 0 }], 200, total - 260);
      T(total, finish);
    });
  }
  window.ShyShadowPlay = { play: play, prep: function (n) { if (!reduce && on()) info(n); }, on: on, setOn: setOn, skip: function () { if (cur) cur(); } };
})();
