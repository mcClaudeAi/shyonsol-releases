<?php
// Tournaments: a scheduled knockout of live matches. Players sign up, check in during the last 30 minutes, and at
// the start they're seated at tables of up to 4 (bots fill empty seats). The best real player at each table moves on;
// when 4 or fewer are left, they play the final table. The final table's order decides 1st to 4th, and Koban prizes
// land straight away. Rounds start on their own: a table waits a couple of minutes for its players, then plays
// with bots for anyone who didn't show. Included by economy.php; rooms come from livelib.php when needed.
if (!defined('SHY_API')) { http_response_code(404); exit; }

define('TOURNEY', DATA_DIR . '/tourney.php');
const T_CHECKIN = 30 * 60;     // check-in opens this long before the start
const T_SEAT_WAIT = 150;       // a table waits this long for its players before bots take the empty seats
const T_IDLE = 45;             // a table where every real player has gone quiet for this long plays out on its own

function tourney_lock($fn) {
    $lf = fopen(DATA_DIR . '/tourney-lock.php', 'c');
    return lock_run($lf, $fn);   //MC 2026-10-11 lets go of the lock before a storage error answers (see lock_run)
}
function tourney_db() { $d = load(TOURNEY); return $d + ['list' => []]; }

// the tournament players should see now: the one running, else the next one, else the last one finished today
function tourney_pick($db, $pid = '') {
    $now = time(); $next = null; $last = null;
    foreach ($db['list'] as $t) if ($t['status'] === 'running') return $t;
    foreach ($db['list'] as $t) if ($t['status'] === 'signup' && (!$next || $t['start'] < $next['start'])) $next = $t;
    foreach ($db['list'] as $t) if (in_array($t['status'], ['done', 'cancelled'], true) && ($t['ended'] ?? 0) > $now - 86400 && (!$last || $t['ended'] > $last['ended'])) $last = $t;
    // results stay up for a few hours after the end, then the next one takes over
    // (a player who already signed up for the next one sees that one)
    if ($last && ($last['ended'] > $now - 6 * 3600 || !$next) && !($next && $pid !== '' && isset($next['players'][$pid]))) { if ($next) $last['next'] = ['id' => $next['id'], 'name' => $next['name'], 'start' => $next['start']]; return $last; }
    return $next;
}
function tourney_new($f) {
    return ['id' => bin2hex(random_bytes(5)), 'name' => $f['name'], 'start' => (int)$f['start'], 'max' => (int)$f['max'], 'prizes' => array_values($f['prizes']), 'note' => (string)($f['note'] ?? ''),
        'repeat' => !empty($f['repeat']), 'status' => 'signup', 'players' => [], 'rounds' => [], 'round' => -1, 'sec' => [], 'places' => [], 'champ' => '', 'told' => [],
        'by' => (string)($f['by'] ?? ''), 'created' => time(), 'gate' => (string)($f['gate'] ?? ''), 'partner' => $f['partner'] ?? null,
        //MC 2026-10-13 paid events: the entry fee in $SHY (0 = free) and the share of collected fees that becomes the
        //   $SHY prize pool. The rest of each payment splits as every $SHY payment does: burn_pct burns in the buyer's
        //   own transaction and the remainder lands in the marketing wallet.
        'fee' => ($f['fc'] ?? '') === 'koban' ? max(0, min(100000, (int)($f['fee'] ?? 0))) : max(0, min(100000000, round((float)($f['fee'] ?? 0), 2))), 'pool_pct' => max(0, min(100, (int)($f['pool_pct'] ?? 60))),
        //MC 2026-10-23 what the four place prizes are paid in: 'koban' lands in the account the moment it ends, 'shy' goes
        //   on the Rewards payout list (added to any pool share) for the pay button, sent to the winner's wallet
        'pz' => ($f['pz'] ?? '') === 'shy' ? 'shy' : 'koban',
        //MC 2026-10-23 what the entry is paid in: 'shy' through the shop checkout (a ticket order), or 'koban' straight
        //   out of the player's balance when they sign up, back if they back out or the event is called off
        'fc' => ($f['fc'] ?? '') === 'koban' ? 'koban' : 'shy'];
}
function tourney_fc($t) { return ($t['fc'] ?? 'shy') === 'koban' ? 'koban' : 'shy'; }
function tourney_cur($c) { return $c === 'koban' ? 'Koban' : '$SHY'; }
// the entry in words: "500 Koban" or "250 $SHY"
function tourney_fee_label($t) { return number_format((float)($t['fee'] ?? 0)) . ' ' . tourney_cur(tourney_fc($t)); }
function tourney_pz($t) { return ($t['pz'] ?? 'koban') === 'shy' ? 'shy' : 'koban'; }
// one place's prize in words: "2,000 Koban" or "50,000 $SHY" ('' when there is none)
function tourney_prize_label($t, $i) { $k = (float)($t['prizes'][$i] ?? 0); return $k > 0 ? number_format($k) . (tourney_pz($t) === 'shy' ? ' $SHY' : ' Koban') : ''; }
//MC 2026-10-23 the event's share card and its link (/t/<id>, api/tpage.php): the card follows what's on it, so a new pool
//   total or a changed prize gives a new picture address and X and Telegram fetch the fresh one
function tourney_card_hash($t) { $pl = tourney_pool($t); return substr(sha1(json_encode([$t['name'], $t['start'], $t['prizes'], tourney_pz($t), (float)($t['fee'] ?? 0), (int)($t['pool_pct'] ?? 0), $t['max'], tourney_gate($t), $t['partner']['name'] ?? '', (int)$pl['amt'], tourney_fc($t), $t['note'] ?? '', 'tn2'])), 0, 10); }
function tourney_card_url($t) { return 'https://shyonsol.io/api/share.php?tn=' . $t['id'] . '&h=' . tourney_card_hash($t); }
function tourney_link($t) { return 'https://shyonsol.io/t/' . $t['id']; }
// the words that sell it, for the X post, the Telegram share and the chat announcement
function tourney_pitch($t, $html = false) {
    $e = $html ? 'tg_h' : fn($x) => $x;
    $pz = array_filter(array_map(fn($i) => tourney_prize_label($t, $i), [0, 1, 2, 3]));
    $first = tourney_prize_label($t, 0);
    $pool = tourney_pool($t);
    $bits = [];
    if ($first !== '') $bits[] = 'Winner takes ' . $first . (count($pz) > 1 ? ', top 4 paid' : '');
    if (!empty($t['fee'])) $bits[] = 'Entry ' . tourney_fee_label($t) . ', ' . (int)$t['pool_pct'] . '% into the prize pool' . ($pool['amt'] > 0 ? ' (' . number_format($pool['amt']) . ' ' . tourney_cur($pool['cur']) . ' so far)' : '');
    else $bits[] = 'Free to enter';
    return $e($t['name']) . ': ' . gmdate('D, M j', $t['start']) . ' at ' . gmdate('H:i', $t['start']) . ' UTC. ' . $t['max'] . ' players, knockout live matches of Shilluminati. ' . $e(implode('. ', $bits)) . '.';
}
// post the event to our Telegram chat with its card (the schedule form's Announce, and the Post again button)
function tourney_announce($t, $once = '') {
    $pzs = array_filter(array_map(fn($i) => tourney_prize_label($t, $i) !== '' ? ['🥇', '🥈', '🥉', '4.'][$i] . ' ' . tourney_prize_label($t, $i) : '', [0, 1, 2, 3]));
    $html = '🏯 <b>' . tg_h($t['name']) . '</b>: ' . gmdate('l, M j', $t['start']) . ' at ' . gmdate('H:i', $t['start']) . ' UTC.'
        . "\n" . $t['max'] . ' seats. A knockout of live matches: the best real player at each table moves on, until the final table. With two tables left, the top two from each make the final.'
        . (!empty($t['fee']) ? "\n💰 Entry: " . tourney_fee_label($t) . '. ' . (int)$t['pool_pct'] . '% of every entry goes into the ' . tourney_cur(tourney_fc($t)) . ' prize pool, and the entry is refunded if the event is called off.' : "\n🎟 Free to enter.")
        . ($pzs ? "\n" . implode('  ', $pzs) : '') . ($t['note'] !== '' ? "\n" . tg_h($t['note']) : '')
        . (tourney_gate($t) === 'partner' ? "\n🤝 A joint event with " . tg_h($t['partner']['name'] ?? '') . ': open to $SHY holders and ' . tg_h($t['partner']['sym'] ?? '') . ' holders.' : (tourney_gate($t) !== '' ? "\n💎 " . tg_h(TOURNEY_GATES[tourney_gate($t)] ?? '') . '.' : ''))
        . "\n" . tg_link('/t/' . $t['id'], 'Sign up');
    tg_post('tourney', $html, $once !== '' ? $once : 'tnew:' . $t['id'], null, tourney_card_url($t));
}
//MC 2026-10-23 bracket sizes that come out even: tables of 4 with one moving on, so 4, 16 and 64 fill every round
const TOURNEY_SIZES = [4 => 'One final table', 6 => '2 tables of 3, the top 2 from each make the final', 8 => '2 tables of 4, the top 2 from each make the final', 16 => '4 tables, then the final table', 64 => '16 tables, then 4, then the final table'];
//MC 2026-10-13 how a paid event's pool and places split: half to the champion, then 25 / 15 / 10
const TOURNEY_POOL_SPLIT = [50, 25, 15, 10];
// the paid entry ticket for this player, read from the shop's orders (the chain-checked source of truth)
function tourney_ticket_order($tid, $pid) {
    foreach (load(ORDERS) as $oid => $o) if ($o['status'] === 'paid' && ($o['product'] ?? '') === 'tk:' . $tid && $o['pid'] === $pid) return $oid;
    return null;
}
// how many paid entries are in, and the pool their fees built: $SHY from ticket orders, or Koban paid at sign-up
//MC 2026-10-23 'amt' and 'cur' say the pool in its own currency; 'shy' and 'koban' stay for whoever reads one of them
function tourney_pool($t) {
    $fc = tourney_fc($t);
    if (empty($t['fee'])) return ['n' => 0, 'shy' => 0, 'koban' => 0, 'amt' => 0, 'cur' => $fc];
    $n = count(array_filter($t['players'], fn($p) => $fc === 'koban' ? !empty($p['kp']) : !empty($p['tk'])));
    $amt = floor($t['fee'] * $n * ($t['pool_pct'] ?? 0) / 100);
    return ['n' => $n, 'shy' => $fc === 'shy' ? $amt : 0, 'koban' => $fc === 'koban' ? (int)$amt : 0, 'amt' => $amt, 'cur' => $fc];
}
//MC 2026-10-23 give back Koban entries (backing out, or the event called off). Clears 'kp' on the roster so it's only ever once.
function tourney_koban_back(&$t, $pids, $why) {
    $back = [];
    foreach ($pids as $pid) { $k = (int)($t['players'][$pid]['kp'] ?? 0); if ($k > 0) { $back[$pid] = $k; $t['players'][$pid]['kp'] = 0; } }
    if (!$back) return 0;
    with_lock(function () use ($back, $why) {
        $eco = load(ECO);
        foreach ($back as $pid => $k) { $a = eco_get($eco, $pid); eco_credit($a, $k, $why); $eco[$pid] = $a; }
        save(ECO, $eco);
    });
    return count($back);
}
// every paid ticket for this event, one refund row per order, written once into the payout lists (Rewards pays them).
//MC 2026-10-23 Koban entries go straight back into each account instead
function tourney_refunds(&$t) {
    if (empty($t['fee'])) return;
    if (tourney_fc($t) === 'koban') { tourney_koban_back($t, array_keys($t['players']), 'Tournament entry refund: ' . mb_substr((string)$t['name'], 0, 30)); return; }
    $rows = [];
    foreach (load(ORDERS) as $o) {
        if ($o['status'] !== 'paid' || ($o['product'] ?? '') !== 'tk:' . $t['id']) continue;
        $rows[] = ['name' => $t['players'][$o['pid']]['name'] ?? substr($o['wallet'], 0, 4) . '…' . substr($o['wallet'], -4), 'pid' => $o['pid'], 'wallet' => $o['wallet'],
            'usd' => (float)$o['usd'], 'shy' => (float)$t['fee'], 'units' => (string)$o['units'], 'dec' => (int)$o['dec'], 'order' => $o['id']];
    }
    if (!$rows) return;
    with_lock(function () use ($t, $rows) {
        $rw = load(REWARDS);
        if (isset($rw['tourneys'][$t['id']])) return;   // built once, ever
        $rw['tourneys'][$t['id']] = ['label' => $t['name'] . ' refunds', 'kind' => 'refunds', 'at' => time(), 'status' => 'pending', 'list' => $rows];
        save(REWARDS, $rw);
    });
    if (function_exists('alert_needs')) @alert_needs('tournament refunds', count($rows) . ' entry ' . (count($rows) === 1 ? 'fee' : 'fees') . ' for ' . $t['name'] . ' to refund in $SHY. "Pay everything owed" on the Rewards tab sends them.', [['Entries', (string)count($rows)], ['Each', number_format($t['fee']) . ' $SHY']], '/admin/?tab=rewards');
}
// who may sign up: '' everyone, holder ($SHY or a Shadow), a rank and up, or partner (a joint event: $SHY holders and a partner token's holders)
//MC 2026-10-10 gates follow the $SHY Army Ranks. Gates saved before the switch (silver, gold, jade, shogun) are read
//   through holder_key_new(): Jade is now Commander and Shogun is King / Queen.
const TOURNEY_GATES = ['' => 'Open to everyone', 'holder' => '$SHY holders only', 'scout' => 'Shy Scout and up', 'knight' => 'Kusama Knight and up', 'champion' => 'Shy Champion and up',
    'commander' => 'Kusama Commander and up', 'sovereign' => 'Shy Sovereign and up', 'king' => 'Kusama King / Queen and up', 'supreme' => 'Shytoshi Supreme only', 'partner' => 'Joint event'];
function tier_rank($tier) { return holder_rank($tier); }
function tourney_gate($t) { return holder_key_new((string)($t['gate'] ?? '')); }
// '' when this player may sign up, else what they need (checked before taking the tournament lock: it may ask Solana)
function tourney_gate_problem($t, $pid) {
    $g = tourney_gate($t);
    if ($g === '') return '';
    $h = load(HOLDERS)[$pid] ?? null;
    $rank = tier_rank(holder_tier($h));
    if ($g === 'holder' && $rank >= 1) return '';
    if (in_array($g, HOLDER_LADDER, true) && $rank >= holder_rank($g)) return '';   //MC 2026-10-10 any step of the ladder can gate
    if ($g === 'partner') {
        if ($rank >= 1) return '';
        $pt = $t['partner'] ?? [];
        if (!empty($h['wallet']) && !empty($pt['mint']) && function_exists('rpc')) {
            $r = rpc('getTokenAccountsByOwner', [$h['wallet'], ['mint' => $pt['mint']], ['encoding' => 'jsonParsed']]);
            $amt = 0.0;
            foreach ($r['value'] ?? [] as $acc) $amt += (float)($acc['account']['data']['parsed']['info']['tokenAmount']['uiAmountString'] ?? 0);
            if ($amt > 0 && $amt >= (float)($pt['min'] ?? 0)) return '';
        }
        $sym = $pt['sym'] ?? ($pt['name'] ?? 'partner');
        return 'This joint event is for $SHY holders and ' . $sym . ' holders' . (!empty($pt['min']) ? ' (' . number_format((float)$pt['min']) . ' or more)' : '') . '. Connect a wallet that holds either on your profile, then sign up.';
    }
    if (empty($h['wallet'])) return 'This one is for $SHY holders. Connect the wallet that holds your $SHY on your profile, then sign up.';
    //MC 2026-10-10 says how much $SHY the step takes, now that tiers count coins
    //MC 2026-10-10 rank names in place of the old tiers
    if ($g === 'holder') return 'This one is for $SHY holders. Hold $SHY or a Shytoshi Shadow in your connected wallet to join.';
    if (in_array($g, HOLDER_LADDER, true)) return 'This one is for ' . HOLDER_NAMES[$g] . ' and up: ' . number_format((float)eco_settings()['htiers'][$g]) . ' $SHY or more in your connected wallet.';
    return 'You can\'t sign up for this one.';
}
//MC 2026-10-23 a round of two tables sends its top two from each, so the final is a full table
function tourney_adv_per($tables) { return $tables === 2 ? 2 : 1; }
function tourney_rounds_needed($n) { $r = 1; while ($n > 4) { $tb = (int)ceil($n / 4); $n = $tb * tourney_adv_per($tb); $r++; } return $r; }

// what a player sees. $pid gets their own status and, when their table is ready, the seat to sit in.
function tourney_public($t, $pid = '') {
    if (!$t) return null;
    $now = time();
    $names = fn($list) => array_values(array_map(fn($p) => $t['players'][$p]['name'] ?? '?', $list));
    $rounds = [];
    // a table being played right now can be watched (only once its match has started, so nobody can take a seat)
    $watch = function ($tb) use ($t) { if ($tb['done'] || $t['status'] !== 'running' || empty($tb['code'])) return ''; $r = load(DATA_DIR . '/rooms/' . $tb['code'] . '.php'); return ($r['status'] ?? '') === 'playing' ? $tb['code'] : ''; };
    foreach ($t['rounds'] as $ri => $tables) $rounds[] = array_map(fn($tb) => ['seats' => $names($tb['seats']), 'win' => $tb['win'] !== '' ? ($t['players'][$tb['win']]['name'] ?? '?') : '', 'adv' => $names(array_values(array_filter($tb['adv'] ?? [$tb['win']]))), 'done' => (bool)$tb['done'], 'watch' => $watch($tb),
        'final' => $ri === count($t['rounds']) - 1 && count($tables) === 1 && $t['status'] !== 'running' ? true : (count($tables) === 1 && count($tb['seats']) <= 4 && $ri > 0)], $tables);
    $in = count(array_filter($t['players'], fn($p) => !empty($p['in'])));
    $v = ['id' => $t['id'], 'name' => $t['name'], 'start' => $t['start'], 'status' => $t['status'], 'max' => $t['max'], 'count' => count($t['players']), 'checkedIn' => $in,
        'checkin' => $t['start'] - T_CHECKIN, 'checkinOpen' => $t['status'] === 'signup' && $now >= $t['start'] - T_CHECKIN, 'prizes' => $t['prizes'], 'note' => $t['note'],
        'round' => $t['round'], 'rounds' => $rounds, 'places' => $names(array_slice($t['places'], 0, 4)), 'champ' => $t['champ'] !== '' ? ($t['players'][$t['champ']]['name'] ?? '') : '',
        'why' => $t['why'] ?? '', 'next' => $t['next'] ?? null, 'now' => $now, 'began' => $t['began'] ?? 0, 'ended' => $t['ended'] ?? 0,
        'fee' => (float)($t['fee'] ?? 0), 'poolPct' => (int)($t['pool_pct'] ?? 0), 'pool' => tourney_pool($t),   //MC 2026-10-13 paid events
        'pz' => tourney_pz($t),   //MC 2026-10-23 the place prizes are Koban or $SHY
        'fc' => tourney_fc($t),   //MC 2026-10-23 and so is the entry
        'burnPct' => (int)eco_settings()['burn_pct'],
        'gate' => tourney_gate($t), 'gateLabel' => TOURNEY_GATES[tourney_gate($t)] ?? '',
        'partner' => !empty($t['partner']) ? array_intersect_key($t['partner'], array_flip(['name', 'url', 'logo', 'sym', 'min'])) : null];
    // who's in: faces for the sign-up stack and the bracket (names are public on the board anyway)
    $img = fn($p) => !empty($p['avatar']) && function_exists('shadow_img') ? shadow_img($p['avatar']) : '';
    $ros = $t['players']; uasort($ros, fn($a, $b) => ($a['at'] ?? 0) <=> ($b['at'] ?? 0));
    $v['roster'] = array_values(array_map(fn($p) => ['n' => $p['name'], 'img' => $img($p), 'in' => !empty($p['in'])], array_slice($ros, 0, 24)));
    $v['imgs'] = [];
    if ($rounds) foreach ($t['players'] as $p) if (($i = $img($p)) !== '') $v['imgs'][$p['name']] = $i;
    if ($pid !== '' && isset($t['players'][$pid])) {
        $p = $t['players'][$pid];
        $you = ['joined' => true, 'in' => !empty($p['in']), 'out' => $p['out'] ?? null, 'place' => array_search($pid, $t['places'], true)];
        if ($you['place'] !== false) $you['place']++; else $you['place'] = 0;
        if ($t['status'] === 'running' && $t['round'] >= 0) {
            foreach ($t['rounds'][$t['round']] as $tb) if (in_array($pid, $tb['seats'], true) && !$tb['done']) {
                $you['table'] = ['code' => $tb['code'], 'seat' => array_search($pid, $tb['seats'], true), 'secret' => $t['sec'][$pid][$tb['code']] ?? '', 'round' => $t['round'] + 1];
            }
        }
        $v['you'] = $you;
    } elseif ($pid !== '') $v['you'] = ['joined' => false];
    return $v;
}

// ---------------------------------------------------------------- signing up
function tourney_join($id, $prof) {
    return tourney_lock(function () use ($id, $prof) {
        $db = tourney_db(); $t = $db['list'][$id] ?? null;
        if (!$t || $t['status'] !== 'signup') return ['err' => 'Sign-ups for this tournament are closed.'];
        //MC 2026-10-13 a paid ticket always seats you, even past the cap: the bracket scales, and tickets stop selling when it's full
        if (!isset($t['players'][$prof['pid']]) && count($t['players']) >= $t['max'] && empty($prof['tk'])) return ['err' => 'This tournament is full.'];
        foreach ($t['players'] as $q => $p) if ($q !== $prof['pid'] && strcasecmp($p['name'], $prof['name']) === 0) return ['err' => 'Someone in this tournament already uses that name.'];
        $old = $t['players'][$prof['pid']] ?? null;
        //MC 2026-10-23 a Koban entry comes out of the player's balance on sign-up, once (signing up again changes nothing)
        $kp = (int)($old['kp'] ?? 0);
        if (!empty($t['fee']) && tourney_fc($t) === 'koban' && $kp <= 0) {
            $fee = (int)$t['fee'];
            $short = with_lock(function () use ($prof, $fee, $t) {
                $eco = load(ECO); $a = eco_get($eco, $prof['pid']);
                if ((int)$a['koban'] < $fee) return (int)$a['koban'];
                eco_credit($a, -$fee, 'Tournament entry: ' . mb_substr((string)$t['name'], 0, 30));
                $eco[$prof['pid']] = $a; save(ECO, $eco);
                return -1;
            });
            if ($short >= 0) return ['err' => 'The entry is ' . number_format($fee) . ' Koban and you have ' . number_format($short) . '. Win a few games or open the shop to top up, then sign up.', 'needKoban' => $fee - $short];
            $kp = $fee;
        }
        $t['players'][$prof['pid']] = ['name' => $prof['name'], 'avatar' => $prof['avatar'], 'holder' => !empty($prof['holder']), 'kh' => $prof['kh'], 'cos' => $prof['cos'] ?? [], 'reacts' => $prof['reacts'] ?? [0, 1, 2, 3, 4, 5],
            'at' => $old['at'] ?? time(), 'in' => $old['in'] ?? (time() >= $t['start'] - T_CHECKIN ? time() : 0), 'out' => null, 'tk' => $prof['tk'] ?? ($old['tk'] ?? ''), 'kp' => $kp];
        $db['list'][$id] = $t; save(TOURNEY, $db);
        return ['ok' => true, 't' => $t];
    });
}
function tourney_checkin($id, $pid) {
    return tourney_lock(function () use ($id, $pid) {
        $db = tourney_db(); $t = $db['list'][$id] ?? null;
        if (!$t || $t['status'] !== 'signup' || !isset($t['players'][$pid])) return ['err' => 'You\'re not signed up for this one.'];
        if (time() < $t['start'] - T_CHECKIN) return ['err' => 'Check-in opens 30 minutes before the start.'];
        $t['players'][$pid]['in'] = time();
        $db['list'][$id] = $t; save(TOURNEY, $db);
        return ['ok' => true, 't' => $t];
    });
}
function tourney_leave($id, $pid) {
    return tourney_lock(function () use ($id, $pid) {
        $db = tourney_db(); $t = $db['list'][$id] ?? null;
        if (!$t || $t['status'] !== 'signup') return ['err' => 'The tournament already started.'];
        if (isset($t['players'][$pid])) tourney_koban_back($t, [$pid], 'Backed out of ' . mb_substr((string)$t['name'], 0, 30));   //MC 2026-10-23 a Koban entry comes back
        unset($t['players'][$pid]);
        $db['list'][$id] = $t; save(TOURNEY, $db);
        return ['ok' => true, 't' => $t];
    });
}

// ---------------------------------------------------------------- running it
// seat a round: tables as even as possible, at most 4 each. Call inside tourney_lock with $t loaded.
function tourney_seat_round(&$t, $pids) {
    require_once __DIR__ . '/livelib.php';
    mt_srand((int)sprintf('%u', crc32($t['id'] . '-' . count($t['rounds']))));
    $pids = array_values($pids);
    for ($i = count($pids) - 1; $i > 0; $i--) { $j = mt_rand(0, $i); [$pids[$i], $pids[$j]] = [$pids[$j], $pids[$i]]; }
    mt_srand();
    $n = count($pids); $tables = (int)ceil($n / 4);
    $groups = array_fill(0, $tables, []);
    foreach ($pids as $k => $p) $groups[$k % $tables][] = $p;
    $round = [];
    $ri = count($t['rounds']);
    foreach ($groups as $ti => $seats) {
        for ($try = 0; $try < 8; $try++) { $code = new_code(); if (!is_file(room_file($code))) break; }
        $final = count($groups) === 1;
        $made = with_room($code, function (&$room) use ($code, $seats, &$t, $ri, $ti, $final) {
            $room = new_room(false); $room['code'] = $code;
            $room['tourney'] = ['id' => $t['id'], 'round' => $ri, 'table' => $ti, 'name' => $t['name'], 'final' => $final];
            $room['tstart'] = now() + T_SEAT_WAIT;
            foreach ($seats as $pid) {
                $p = $t['players'][$pid];
                $secret = bin2hex(random_bytes(16));
                $t['sec'][$pid][$code] = $secret;
                $room['seats'][] = ['name' => $p['name'], 'avatar' => $p['avatar'], 'holder' => !empty($p['holder']), 'pid' => $pid, 'kh' => $p['kh'], 'human' => true, 'cos' => $p['cos'] ?? [], 'reacts' => $p['reacts'] ?? [0, 1, 2, 3, 4, 5],
                    'sh' => hash('sha256', $secret), 'seen' => 0, 'gone' => true, 'away' => false, 'strikes' => 0, 'tseat' => 1];
            }
            return true;
        }, true);
        $round[] = ['code' => $code, 'seats' => $seats, 'win' => '', 'done' => 0, 'stand' => []];
    }
    $t['rounds'][] = $round;
    $t['round'] = $ri;
    return $round;
}
function tourney_start(&$t) {
    $in = array_keys(array_filter($t['players'], fn($p) => !empty($p['in'])));
    if (count($in) < 2) {
        $t['status'] = 'cancelled'; $t['ended'] = time(); $t['why'] = count($in) ? 'Only one player checked in.' : 'Nobody checked in.';
        $ref = !empty($t['fee']) ? (tourney_fc($t) === 'koban' ? ' Every Koban entry is back in its account.' : ' Entry fees are refunded in $SHY to the wallet that paid.') : ' See you at the next one.';   //MC 2026-10-13 paid events refund
        tg_post('tourney', '🏯 <b>' . tg_h($t['name']) . '</b> is off: ' . tg_h(lcfirst($t['why'])) . tg_h($ref), 'tcancel:' . $t['id']);
        tp_post($t, '🏯 <b>' . tg_h($t['name']) . '</b> is off: ' . tg_h(lcfirst($t['why'])) . tg_h($ref), 'cancel:' . $t['id']);
        tourney_refunds($t);
        return;
    }
    // anyone who signed up but never checked in is out before it starts
    foreach ($t['players'] as $pid => &$p) if (empty($p['in'])) $p['out'] = -1;
    unset($p);
    $t['status'] = 'running'; $t['began'] = time();
    $round = tourney_seat_round($t, $in);
    tg_post('tourney', '🏯 <b>' . tg_h($t['name']) . ' is on.</b> ' . count($in) . ' players, ' . count($round) . ' ' . (count($round) === 1 ? 'table' : 'tables') . ' in round 1. ' . (count($round) === 2 ? 'The top two at each table make the final.' : 'The best real player at each table moves on.'), 'tstart:' . $t['id']);
    tp_post($t, '🏯 <b>' . tg_h($t['name']) . ' is on.</b> ' . count($in) . ' players at ' . count($round) . ' ' . (count($round) === 1 ? 'table' : 'tables') . '. Good luck, ' . tg_h(tp_sym($t)) . ' holders!', 'start:' . $t['id']);
    tourney_dm_tables($t, $round, 1);
}
function tourney_dm_tables($t, $round, $no) {
    $final = count($round) === 1;
    foreach ($round as $tb) foreach ($tb['seats'] as $pid) {
        $u = tg_user_of($pid);
        if (!$u || empty($u['dm']) || empty((($u['n'] ?? []) + TG_NOTES_ON)['tourney'])) continue;
        tg_dm($u['id'], '🏯 <b>' . tg_h($t['name']) . '</b>: ' . ($final ? 'you made the <b>final table</b>.' : "your round $no table is ready.") . ' It starts in about 2 minutes, with a bot in any empty seat.', tg_kb_private('🏯 Take my seat'));
    }
}
// a table finished (called by livelib's end_game). The best real player at the table moves on.
function tourney_table_done($room) {
    $info = $room['tourney'];
    $stand = $room['result']['standings'] ?? [];
    $order = [];
    foreach ($stand as $x) { $s = $room['seats'][$x['i']] ?? null; if ($s && !empty($s['tseat']) && !empty($s['human']) && !empty($s['pid'])) $order[] = $s['pid']; }
    tourney_lock(function () use ($info, $order, $room) {
        $db = tourney_db(); $t = $db['list'][$info['id']] ?? null;
        if (!$t || $t['status'] !== 'running') return;
        $tb = &$t['rounds'][$info['round']][$info['table']];
        if ($tb['done'] || $tb['code'] !== $room['code']) return;
        $tb['done'] = time(); $tb['stand'] = $order; $tb['win'] = $order[0] ?? '';
        $tb['adv'] = array_slice($order, 0, tourney_adv_per(count($t['rounds'][$info['round']])));   //MC 2026-10-23 who moves on (two when the round has two tables)
        foreach ($tb['seats'] as $pid) if (!in_array($pid, $tb['adv'], true)) $t['players'][$pid]['out'] = $info['round'];
        unset($tb);
        tourney_advance($t);
        $db['list'][$info['id']] = $t; save(TOURNEY, $db);
    });
}
// when every table in the round is done: seat the next round, or crown the champion
function tourney_advance(&$t) {
    $r = $t['round'];
    foreach ($t['rounds'][$r] as $tb) if (!$tb['done']) return;
    $win = [];
    foreach ($t['rounds'][$r] as $tb) foreach ($tb['adv'] ?? [$tb['win']] as $p) if ($p !== '') $win[] = $p;
    $wasFinal = count($t['rounds'][$r]) === 1;
    if (count($win) >= 2 && !$wasFinal) {
        $round = tourney_seat_round($t, $win);
        $no = count($t['rounds']);
        tg_post('tourney', '🏯 <b>' . tg_h($t['name']) . '</b>: ' . (count($round) === 1 ? 'the final table is set. ' . implode(', ', array_map(fn($p) => '<b>' . tg_h($t['players'][$p]['name']) . '</b>', $win)) . ' play for the title.' : count($win) . " players are through to round $no."), 'tround:' . $t['id'] . ':' . $no);
        tourney_dm_tables($t, $round, $no);
        return;
    }
    // done: final table order first, then everyone else by how far they got
    $places = $wasFinal ? $t['rounds'][$r][0]['stand'] : $win;
    for ($k = $r; $k >= 0; $k--) {
        $rest = [];
        foreach ($t['rounds'][$k] as $tb) foreach ($tb['stand'] as $i => $pid) if (!in_array($pid, $places, true)) $rest[] = [$i, $pid];
        usort($rest, fn($a, $b) => $a[0] <=> $b[0]);
        foreach ($rest as [, $pid]) $places[] = $pid;
    }
    $t['places'] = $places; $t['champ'] = $places[0] ?? '';
    $t['status'] = 'done'; $t['ended'] = time();
    tourney_pay($t);
}
function tourney_pay(&$t) {
    if (function_exists('alert_tourney') && ($t['champ'] ?? '') !== '') alert_tourney($t);   //MC 2026-10-09 results by email
    $paid = [];
    //MC 2026-10-23 Koban prizes only when the event pays in Koban; the champion's title and trophy come either way
    //   (they used to ride on a Koban prize, so a champion of an event with no Koban prize got neither)
    $pzKoban = tourney_pz($t) === 'koban';
    //MC 2026-10-23 a Koban entry pool splits 50 / 25 / 15 / 10 in Koban, on top of any Koban place prize
    $kpool = tourney_pool($t)['koban'];
    with_lock(function () use (&$t, &$paid, $pzKoban, $kpool) {
        $eco = load(ECO);
        foreach (array_slice($t['places'], 0, 4) as $i => $pid) {
            $k = ($pzKoban ? (int)($t['prizes'][$i] ?? 0) : 0) + (int)floor($kpool * TOURNEY_POOL_SPLIT[$i] / 100);
            if ($k <= 0 && $i > 0) continue;
            $a = eco_get($eco, $pid);
            if ($k > 0) { eco_credit($a, $k, 'Tournament prize, place ' . ($i + 1)); $paid[$pid] = $k; }
            if ($i === 0) { eco_grant_item($a, 'title_cup'); trophy_award($pid, 'cup', $t['id'] ?? (string)time(), mb_substr((string)($t['name'] ?? ''), 0, 24)); }   //MC 2026-10-15
            $eco[$pid] = $a;
        }
        save(ECO, $eco);
    });
    //MC 2026-10-13 a paid event's $SHY pool: one prize row per place (50 / 25 / 15 / 10), wallets from the ticket orders,
    //   written once into the payout lists. The team sends them with the Rewards payout button, like every $SHY prize.
    $pool = tourney_pool($t);
    $shyPz = [];
    //MC 2026-10-23 a $SHY event's fixed place prizes join the pool share on the same row, one row per place
    $fixed = tourney_pz($t) === 'shy' ? array_map('floatval', array_slice($t['prizes'], 0, 4)) : [0, 0, 0, 0];
    if ($pool['shy'] > 0 || array_sum($fixed) > 0) {
        $orders = load(ORDERS); $holders = load(HOLDERS); $px = price_usd(SHY_MINT); $dec = mint_decimals(SHY_MINT);
        $prows = [];
        foreach (array_slice($t['places'], 0, count(TOURNEY_POOL_SPLIT)) as $i => $pid) {
            $shy = floor($pool['shy'] * TOURNEY_POOL_SPLIT[$i] / 100) + floor($fixed[$i] ?? 0);
            if ($shy < 1) continue;
            $wal = '';
            $tk = $t['players'][$pid]['tk'] ?? '';
            if ($tk !== '' && isset($orders[$tk])) $wal = $orders[$tk]['wallet'];
            if ($wal === '') $wal = (string)($holders[$pid]['wallet'] ?? '');
            $row = ['name' => $t['players'][$pid]['name'] ?? '?', 'pid' => $pid, 'wallet' => $wal, 'usd' => $px ? round($shy * $px, 2) : 0.0, 'shy' => (float)$shy];
            if ($dec !== null) { $row['units'] = sprintf('%.0f', $shy * pow(10, $dec)); $row['dec'] = $dec; $row['px'] = $px; }
            $prows[] = $row;
            $shyPz[$pid] = $shy;
        }
        if ($prows) with_lock(function () use ($t, $prows) {
            $rw = load(REWARDS);
            if (isset($rw['tourneys'][$t['id']])) return;   // written once, ever
            $rw['tourneys'][$t['id']] = ['label' => $t['name'] . ' prizes', 'kind' => 'prizes', 'at' => time(), 'status' => 'pending', 'list' => $prows];
            save(REWARDS, $rw);
        });
        $tot = array_sum(array_column($prows, 'shy'));
        if ($prows && function_exists('alert_needs')) @alert_needs('tournament prizes', 'The ' . $t['name'] . ' prizes, ' . number_format($tot) . ' $SHY, are ready to pay. "Pay everything owed" on the Rewards tab sends them.', [['Prizes', number_format($tot) . ' $SHY'], ['Winners', (string)count($prows)]], '/admin/?tab=rewards');
    }
    $medal = ['🥇', '🥈', '🥉', '4.'];
    $rows = [];
    foreach (array_slice($t['places'], 0, 4) as $i => $pid) {
        $won = array_filter([!empty($paid[$pid]) ? number_format($paid[$pid]) . ' Koban' : '', isset($shyPz[$pid]) ? number_format($shyPz[$pid]) . ' $SHY' : '']);
        $rows[] = $medal[$i] . ' ' . tg_h($t['players'][$pid]['name']) . ($won ? ': ' . implode(' + ', $won) : '');
    }
    if ($t['champ'] !== '') tg_post('tourney', '🏆 <b>' . tg_h($t['players'][$t['champ']]['name']) . ' wins ' . tg_h($t['name']) . '!</b> ' . count(array_filter($t['players'], fn($p) => ($p['out'] ?? null) !== -1)) . " players took part.\n\n" . implode("\n", $rows) . ($t['note'] !== '' ? "\n\n" . tg_h($t['note']) : ''), 'tdone:' . $t['id']);
    if ($t['champ'] !== '') tp_post($t, '🏆 <b>' . tg_h($t['players'][$t['champ']]['name']) . ' wins ' . tg_h($t['name']) . "!</b>\n\n" . implode("\n", $rows) . ($t['note'] !== '' ? "\n\n" . tg_h($t['note']) : '') . "\n\nThanks for playing, " . tg_h(tp_sym($t)) . (!empty($t['repeat']) ? '. Same time next week.' : '.'), 'done:' . $t['id']);
    foreach (array_slice($t['places'], 0, 4) as $i => $pid) {
        $u = tg_user_of($pid);
        if ($u && !empty($u['dm']) && !empty((($u['n'] ?? []) + TG_NOTES_ON)['tourney'])) tg_dm($u['id'], ($i === 0 ? '🏆 <b>You won ' . tg_h($t['name']) . '!</b>' : '🏯 You finished <b>#' . ($i + 1) . '</b> in ' . tg_h($t['name']) . '.') . (!empty($paid[$pid]) ? ' ' . number_format($paid[$pid]) . ' Koban are in your account.' : '') . (isset($shyPz[$pid]) ? ' Your ' . number_format($shyPz[$pid]) . ' $SHY prize is sent by the team to your connected wallet.' : ''));
    }
}
// a weekly tournament books the next one when it ends
function tourney_repeat(&$db, $t) {
    if (empty($t['repeat'])) return;
    $next = $t['start'] + 7 * 86400;
    while ($next < time() + 3600) $next += 7 * 86400;
    foreach ($db['list'] as $x) if ($x['name'] === $t['name'] && $x['start'] === $next) return;
    //MC 2026-10-23 the entry fee, pool share and prize currency carry over too (a weekly paid event came back free)
    $n = tourney_new(['name' => $t['name'], 'start' => $next, 'max' => $t['max'], 'prizes' => $t['prizes'], 'note' => $t['note'], 'repeat' => true, 'by' => $t['by'], 'gate' => tourney_gate($t), 'partner' => $t['partner'] ?? null,
        'fee' => $t['fee'] ?? 0, 'pool_pct' => $t['pool_pct'] ?? 60, 'pz' => tourney_pz($t), 'fc' => tourney_fc($t)]);
    $db['list'][$n['id']] = $n;
    $t2 = &$db['list'][$t['id']]; $t2['repeat'] = false; unset($t2);   // only one follow-up
}

// Keeps tournaments moving: announcements, check-in reminders, the start, tables nobody came to, and tables where
// everyone left. Cheap when nothing is due. Called from busy pages, the tournament page and the cron job.
function tourney_tick($force = false) {
    if (!is_file(TOURNEY)) return;
    $stamp = DATA_DIR . '/tourney-tick.php';
    if (!$force && is_file($stamp) && time() - filemtime($stamp) < 8) return;
    @touch($stamp);
    $now = time();
    $db = tourney_db();
    foreach ($db['list'] as $id => $t) {
        if ($t['status'] === 'signup') {
            $due = [];
            if ($now >= $t['start'] - 3600 && $now < $t['start'] && !isset($t['told']['hour'])) $due[] = 'hour';
            if (!empty($t['partner']['chat']) && $now >= $t['start'] - 86400 && $now < $t['start'] - 3600 && !isset($t['told']['pday'])) $due[] = 'pday';
            if ($now >= $t['start'] - T_CHECKIN && !isset($t['told']['checkin'])) $due[] = 'checkin';
            if ($now >= $t['start']) $due[] = 'start';
            if (!$due) continue;
            tourney_lock(function () use ($id, $due, $now) {
                $db = tourney_db(); $t = $db['list'][$id] ?? null;
                if (!$t || $t['status'] !== 'signup') return;
                if (in_array('hour', $due, true) && !isset($t['told']['hour'])) {
                    $t['told']['hour'] = $now;
                    tg_post('tourney', '🏯 <b>' . tg_h($t['name']) . '</b> starts in 1 hour. ' . count($t['players']) . ' signed up so far. Sign up, then check in during the last 30 minutes.', 't1h:' . $id);
                    tp_post($t, '🏯 <b>' . tg_h($t['name']) . '</b> starts in 1 hour. ' . tp_count($t) . tg_h(tp_sym($t)) . ' holders: connect your wallet, sign up, then check in during the last 30 minutes.', 'hour:' . $id);
                }
                if (in_array('pday', $due, true) && !isset($t['told']['pday'])) {
                    $t['told']['pday'] = $now;
                    tp_post($t, '⏰ <b>' . tg_h($t['name']) . '</b> is coming up: ' . tp_when($t) . '. ' . tp_count($t) . tg_h(tp_sym($t)) . ' holders, connect the wallet that holds it on your profile and sign up. ' . tp_prizes($t), 'day:' . $id);
                }
                if (in_array('checkin', $due, true) && !isset($t['told']['checkin'])) {
                    $t['told']['checkin'] = $now;
                    foreach ($t['players'] as $pid => $p) {
                        if (!empty($p['in'])) continue;
                        $u = tg_user_of($pid);
                        if ($u && !empty($u['dm']) && !empty((($u['n'] ?? []) + TG_NOTES_ON)['tourney'])) tg_dm($u['id'], '🏯 Check-in for <b>' . tg_h($t['name']) . '</b> is open. Check in within 30 minutes to keep your spot.', tg_kb_private('✅ Check in'));
                    }
                }
                if (in_array('start', $due, true)) tourney_start($t);
                $db['list'][$id] = $t;
                if ($t['status'] === 'cancelled') tourney_repeat($db, $t);
                save(TOURNEY, $db);
            });
            continue;
        }
        if ($t['status'] !== 'running') continue;
        // drive tables nobody is looking at: no-shows, and tables everyone left
        require_once __DIR__ . '/livelib.php';
        foreach ($t['rounds'][$t['round']] ?? [] as $tb) {
            if ($tb['done']) continue;
            $gone = with_room($tb['code'], function (&$room) {
                tick($room);
                if ($room['status'] === 'playing') {
                    $quiet = true;
                    foreach ($room['seats'] as $s) if (!empty($s['human']) && now() - ($s['seen'] ?? 0) < T_IDLE) $quiet = false;
                    if ($quiet && now() - ($room['started'] ?? now()) > 20) tourney_fast_finish($room);
                }
                return false;
            });
            // the room vanished (cleaned up, or closed by an admin): nobody moves on from that table
            if (is_array($gone) && isset($gone['err'])) tourney_lock(function () use ($id, $tb) {
                $db = tourney_db(); $t = &$db['list'][$id];
                foreach ($t['rounds'][$t['round']] as &$x) if ($x['code'] === $tb['code'] && !$x['done']) { $x['done'] = time(); $x['win'] = ''; $x['adv'] = []; foreach ($x['seats'] as $pid) $t['players'][$pid]['out'] = $t['round']; }
                unset($x);
                tourney_advance($t);
                if ($t['status'] === 'done') tourney_repeat($db, $t);
                unset($t);
                save(TOURNEY, $db);
            });
        }
    }
    // a finished weekly one books the next
    tourney_lock(function () {
        $db = tourney_db(); $ch = false;
        foreach ($db['list'] as $t) if (in_array($t['status'], ['done', 'cancelled'], true) && !empty($t['repeat'])) { tourney_repeat($db, $t); $ch = true; }
        // keep the last 30
        if (count($db['list']) > 30) { uasort($db['list'], fn($a, $b) => $b['start'] <=> $a['start']); $db['list'] = array_slice($db['list'], 0, 30, true); $ch = true; }
        if ($ch) save(TOURNEY, $db);
    });
}
// play a table out with bots when every real player there has left
function tourney_fast_finish(&$room) {
    foreach ($room['seats'] as &$s) if (!empty($s['human'])) { $s['away'] = true; $s['gone'] = true; }
    unset($s);
    for ($i = 0; $i < 4000 && $room['status'] === 'playing'; $i++) { $room['next'] = 0; $room['deadline'] = 0; tick($room); }
}

// ---------------------------------------------------------------- partner groups
//MC 2026-10-09 partner groups. A partner community's admin adds our bot to their Telegram group and types /partner CODE
//(the code sits on the joint event in our admin). From then on that group gets that event's posts by itself: the
//announcement, a reminder the day before and an hour before, the start and the winners. Only groups that asked get
//anything: the code ties one group to one partner's events, only a group admin can link it, and removing the bot or
//typing /partner off stops it. Weekly repeats carry the link over, so a partner sets it up once.
//Mass posting into groups that never asked was ruled out on purpose: Telegram bans bots and accounts for it.
//MC 2026-10-15 redrawn if it spells a rude word (api/codeclean.php)
function tp_code() {
    require_once __DIR__ . '/codeclean.php';
    $a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    for ($t = 0; $t < 50; $t++) { $s = ''; for ($i = 0; $i < 6; $i++) $s .= $a[random_int(0, strlen($a) - 1)]; if (code_clean($s)) return $s; }
    return $s;
}
function tp_slug($t) { $s = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower((string)($t['partner']['name'] ?? ''))), '-'); return substr($s !== '' ? $s : 'partner', 0, 30); }
function tp_url($t) { return TG_SITE . '/play?ref=partner-' . tp_slug($t); }
function tp_sym($t) { return (string)($t['partner']['sym'] ?? ($t['partner']['name'] ?? 'partner')); }
// a partner group only hears the sign-up count once there is one: "0 signed up" reads as a dead event
function tp_count($t) { $n = count($t['players']); return $n ? $n . ' signed up so far. ' : ''; }
function tp_when($t) { return gmdate('l, M j', $t['start']) . ' at ' . gmdate('H:i', $t['start']) . ' UTC'; }
// queue a post for the event's partner group, if one is linked (sent after the request, like every other post)
function tp_post($t, $html, $once) {
    $chat = (string)($t['partner']['chat'] ?? '');
    if ($chat === '' || !function_exists('tg_hook')) return;
    tg_hook();
    $GLOBALS['TG_PQ'][] = ['c' => $chat, 'h' => $html, 'o' => 'p:' . $once . ':' . $chat, 'kb' => tg_kb('🎴 Sign up and play', 'src_partner-' . tp_slug($t))];
}
function tp_prizes($t) {
    $p = array_filter(array_map(fn($k, $i) => $k ? ['1st', '2nd', '3rd', '4th'][$i] . ' ' . tourney_prize_label($t, $i) : '', $t['prizes'], array_keys($t['prizes'])));
    return ($p ? 'Prizes: ' . implode(', ', $p) . '.' : '') . ($t['note'] !== '' ? ' ' . tg_h($t['note']) : '');
}
function tp_intro($t) {
    $sym = tg_h(tp_sym($t)); $min = (float)($t['partner']['min'] ?? 0);
    return '🤝 <b>$SHY x ' . $sym . ': ' . tg_h($t['name']) . "</b>\n" . tp_when($t) . '. A free knockout tournament of Shilluminati Online, the $SHY card game, open to ' . $sym . ' holders' . ($min > 0 ? ' (' . number_format($min) . ' or more)' : '') . " and \$SHY holders.\n\n"
        . 'To join: open the game, connect the wallet that holds your ' . $sym . " on your profile, then sign up on the Play page. Check in during the last 30 minutes before the start.\n" . tp_prizes($t)
        . "\n\n" . '<a href="' . tg_h(tp_url($t)) . '">Sign up on the web</a>';
}
// a group admin typed /partner CODE: link that group to every upcoming joint event with that code
function tp_link_chat($code, $chat, $title) {
    $code = strtoupper(trim($code));
    return tourney_lock(function () use ($code, $chat, $title) {
        $db = tourney_db(); $hit = null;
        foreach ($db['list'] as $id => &$t) {
            if (($t['gate'] ?? '') !== 'partner' || !in_array($t['status'], ['signup', 'running'], true) || !hash_equals((string)($t['partner']['code'] ?? ''), $code)) continue;
            $t['partner']['chat'] = (string)$chat; $t['partner']['chat_title'] = mb_substr((string)$title, 0, 80);
            if (!$hit || $t['start'] < $hit['start']) $hit = $t;
        }
        unset($t);
        if ($hit) save(TOURNEY, $db);
        return $hit;
    });
}
// the bot was removed from a group, the group is gone, or its admin typed /partner off
function tp_unlink_chat($chat) {
    $chat = (string)$chat; $n = 0;
    tourney_lock(function () use ($chat, &$n) {
        $db = tourney_db();
        foreach ($db['list'] as &$t) if ((string)($t['partner']['chat'] ?? '') === $chat) { unset($t['partner']['chat'], $t['partner']['chat_title']); $n++; }
        unset($t);
        if ($n) save(TOURNEY, $db);
    });
    return $n;
}
