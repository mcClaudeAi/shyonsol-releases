//MC 2026-10-17 Shy Exchange's own swap. Pick two tokens and an amount, get the best route across every Solana DEX from
//   Jupiter (through api/swap.php, which adds our fee for the marketing wallet), and approve it in your own wallet.
//   Wallets are found through the Solana Wallet Standard (Phantom, Solflare, Backpack and the rest announce themselves
//   to the page), so no wallet library is loaded: the wallet signs the transaction bytes Jupiter built, and the signed
//   swap goes back through api/swap.php to Jupiter, which lands it. Nothing here can move funds on its own.
//   If Jupiter can't be reached through us, the page swaps over to Jupiter's own swap box (assets/exchange.js).
(function () {
  "use strict";
  var EX = window.SHY_EX || {}, SHY = EX.ca, SOL = EX.sol;
  var $ = function (id) { return document.getElementById(id); };
  if (!$("sx-go") || !SHY) return;
  var API = "/api/swap.php";
  var FEE_SOL = 0.012;   // SOL kept back on Max for network fees and a new token account
  var REFRESH = 20;      // seconds between fresh quotes
  var st = {
    tin: { id: SOL, symbol: "SOL", name: "Solana", decimals: 9, icon: "" },
    tout: { id: SHY, symbol: "SHY", name: "Shy", decimals: 6, icon: EX.logo || "" },
    amt: "", quote: null, qn: 0, loading: false, busy: false, slip: "", fee: 0, search: false,
    wallets: [], w: null, acct: null, addr: "", bal: null, tokens: [], picking: "in", left: REFRESH, err: ""
  };
  var KNOWN = {};
  KNOWN[SOL] = st.tin; KNOWN[SHY] = st.tout;

  // ---------------------------------------------------------------- numbers
  // amounts move as whole units of the token's smallest part (BigInt), never as floats
  function toRaw(s, dec) {
    s = String(s || "").replace(/,/g, ".").trim();
    if (!/^\d*\.?\d*$/.test(s) || s === "" || s === ".") return 0n;
    var p = s.split("."), w = p[0] || "0", f = (p[1] || "").slice(0, dec);
    while (f.length < dec) f += "0";
    try { return BigInt(w) * (10n ** BigInt(dec)) + BigInt(f || "0"); } catch (e) { return 0n; }
  }
  function fromRaw(r, dec) {
    r = BigInt(r || 0); var neg = r < 0n; if (neg) r = -r;
    var d = 10n ** BigInt(dec), w = r / d, f = (r % d).toString().padStart(dec, "0").replace(/0+$/, "");
    return (neg ? "-" : "") + w.toString() + (f ? "." + f : "");
  }
  function nice(str, max) {
    var n = parseFloat(str); if (!isFinite(n) || n === 0) return "0";
    var a = Math.abs(n), d = a >= 1000 ? 2 : a >= 1 ? 4 : Math.min(10, -Math.floor(Math.log10(a)) + 3);
    if (max != null) d = Math.min(d, max);
    return n.toLocaleString("en-US", { maximumFractionDigits: d });
  }
  function pct(bps) { return String(Math.round(bps) / 100) + "%"; }
  function usd(n) { if (!(n > 0)) return ""; return "$" + n.toLocaleString("en-US", { minimumFractionDigits: n < 1 ? 2 : 2, maximumFractionDigits: n < 1 ? 4 : 2 }); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function b64ToBytes(b) { var s = atob(b), u = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
  function bytesToB64(u) { var s = ""; for (var i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
  function short(a) { return a ? a.slice(0, 4) + "..." + a.slice(-4) : ""; }
  function sym(t) { return t.id === SHY ? "$SHY" : t.symbol; }

  function api(params) {
    var q = Object.keys(params).filter(function (k) { return params[k] !== "" && params[k] != null; }).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]); }).join("&");
    return fetch(API + "?" + q, { cache: "no-store" }).then(function (r) { return r.json().catch(function () { return { ok: false, error: "Something went wrong. Try again." }; }); });
  }

  // ---------------------------------------------------------------- tokens on screen
  function tokImg(img, t) {
    img.src = t.icon || "/assets/art/icon-192.png";
    img.onerror = function () { img.onerror = null; img.src = "/assets/art/icon-192.png"; };
  }
  function drawTokens() {
    tokImg($("sx-tok-in-i"), st.tin); tokImg($("sx-tok-out-i"), st.tout);
    $("sx-tok-in-s").textContent = sym(st.tin); $("sx-tok-out-s").textContent = sym(st.tout);
    document.querySelectorAll(".sx-route").forEach(function (b) { b.classList.toggle("on", b.dataset.in === st.tin.id && b.dataset.out === st.tout.id); });
    drawBal();
  }
  function balRaw(t) {
    if (!st.bal) return null;
    if (t.id === SOL) return BigInt(st.bal.sol || "0");
    var x = st.bal.tokens.filter(function (k) { return k.id === t.id; })[0];
    return x ? BigInt(x.raw) : 0n;
  }
  function drawBal() {
    var a = balRaw(st.tin), b = balRaw(st.tout);
    $("sx-bal-in-w").hidden = a === null; $("sx-bal-out-w").hidden = b === null;
    if (a !== null) $("sx-bal-in").textContent = nice(fromRaw(a, st.tin.decimals));
    if (b !== null) $("sx-bal-out").textContent = nice(fromRaw(b, st.tout.decimals));
  }

  // ---------------------------------------------------------------- the quote
  var qTimer = 0;
  function want() { clearTimeout(qTimer); qTimer = setTimeout(quote, 320); }
  function quote() {
    var raw = toRaw(st.amt, st.tin.decimals);
    st.quote = null; st.err = "";
    if (raw <= 0n) { st.loading = false; drawQuote(); return; }
    var n = ++st.qn; st.loading = true; drawQuote();
    api({ a: "order", inputMint: st.tin.id, outputMint: st.tout.id, amount: raw.toString(), slippageBps: st.slip }).then(function (j) {
      if (n !== st.qn) return;
      st.loading = false; st.left = REFRESH;
      if (j && j.outAmount && !j.error) { st.quote = j; noteTokens(j); }
      else { st.err = friendly(j); if (j && (j.code === 401 || /api key|unauthor/i.test(String(j.error || j.errorMessage || "")))) fallback(); }
      drawQuote();
    }).catch(function () { if (n !== st.qn) return; st.loading = false; st.err = "Can't reach the swap right now. Check your connection."; drawQuote(); netFails(); });
  }
  var fails = 0;
  function netFails() { if (++fails >= 3) fallback(); }
  function fallback() { if (window.ShyEx && ShyEx.loadPlugin) { ShyEx.loadPlugin(st.tin.id, st.tout.id); $("sx-swap").classList.add("plugin"); } }
  function friendly(j) {
    var m = String((j && (j.errorMessage || j.error)) || "");
    if (/no route|could not find|not tradable|no routes/i.test(m)) return "No route for this pair right now. Try a different amount or token.";
    if (/insufficient/i.test(m)) return "Not enough in your wallet for this swap and its network fee.";
    if (/slow down/i.test(m)) return m;
    return m ? m.replace(/\s+/g, " ").slice(0, 160) : "Couldn't get a price. Try again.";
  }
  function noteTokens(q) {
    // Jupiter tells us each side's USD value; keep a per-token price for the USD lines
    var ia = parseFloat(fromRaw(q.inAmount || "0", st.tin.decimals)), oa = parseFloat(fromRaw(q.outAmount || "0", st.tout.decimals));
    if (q.inUsdValue && ia > 0) st.tin.usd = q.inUsdValue / ia;
    if (q.outUsdValue && oa > 0) st.tout.usd = q.outUsdValue / oa;
  }
  function drawQuote() {
    var q = st.quote, out = $("sx-out");
    out.classList.toggle("loading", st.loading);
    var ia = parseFloat(st.amt || "0");
    $("sx-usd-in").textContent = ia > 0 && st.tin.usd ? usd(ia * st.tin.usd) : " ";
    if (q) {
      var oa = fromRaw(q.outAmount, st.tout.decimals);
      out.textContent = nice(oa); out.classList.remove("zero");
      $("sx-usd-out").textContent = q.outUsdValue ? usd(q.outUsdValue) : " ";
      var per = parseFloat(oa) / ia;
      $("sx-rate-t").textContent = "1 " + sym(st.tin) + " = " + nice(String(per)) + " " + sym(st.tout);
      $("sx-rate").hidden = false;
      //MC 2026-10-17 Jupiter gives the impact signed: below zero the route beats the market price, which costs nothing
      var impRaw = parseFloat(q.priceImpact != null ? q.priceImpact : (q.priceImpactPct || 0) * 100) || 0, imp = impRaw > 0 ? impRaw : 0;
      var dImp = $("sx-d-imp"); dImp.textContent = imp < 0.01 ? "None" : imp.toFixed(2) + "%"; dImp.className = imp >= 10 ? "bad" : imp >= 3 ? "warn" : "good";
      $("sx-d-min").textContent = q.otherAmountThreshold ? nice(fromRaw(q.otherAmountThreshold, st.tout.decimals)) + " " + sym(st.tout) : "-";
      $("sx-d-slip").textContent = st.slip === "" ? (q.slippageBps ? pct(q.slippageBps) + " (auto)" : "Auto") : pct(st.slip);
      //MC 2026-10-17 the whole swap fee as Jupiter takes it: ours when the referral fee is on, otherwise Jupiter's own
      var fb = +(q.feeBps || 0), ours = q.shyFee || 0;
      $("sx-d-fee").textContent = fb ? pct(fb) + (ours ? " (Shy Exchange)" : " (Jupiter)") : "None";
      var net = (q.signatureFeeLamports || 0) + (q.prioritizationFeeLamports || 0) + (q.rentFeeLamports || 0);
      $("sx-d-net").textContent = net ? "about " + nice(String(net / 1e9), 6) + " SOL" : "a tiny amount of SOL";
      var labels = []; (q.routePlan || []).forEach(function (s) { var l = s.swapInfo && s.swapInfo.label; if (l && labels.indexOf(l) < 0) labels.push(l); });
      $("sx-d-route").textContent = labels.length ? labels.join(" → ") : (q.router ? q.router : "Jupiter");
      var w = $("sx-warn");
      if (st.err) { w.hidden = false; w.className = "sx-warn bad"; w.textContent = st.err; }   // a failed or cancelled swap says so first
      else if (imp >= 3) { w.hidden = false; w.className = "sx-warn " + (imp >= 10 ? "bad" : ""); w.textContent = imp >= 10 ? "Very high price impact (" + imp.toFixed(1) + "%). You'd get much less than the market price. Try a smaller amount." : "Price impact is " + imp.toFixed(1) + "%. A smaller amount gets a better price."; }
      else w.hidden = true;
    } else {
      out.textContent = st.loading ? out.textContent : "0"; out.classList.toggle("zero", !st.loading);
      $("sx-usd-out").textContent = " ";
      $("sx-rate").hidden = true; $("sx-det").hidden = true; $("sx-det-b").setAttribute("aria-expanded", "false");
      var w2 = $("sx-warn");
      if (st.err) { w2.hidden = false; w2.className = "sx-warn bad"; w2.textContent = st.err; } else w2.hidden = true;
    }
    drawGo();
  }
  function drawGo() {
    var b = $("sx-go"), t = $("sx-go-t"), raw = toRaw(st.amt, st.tin.decimals), have = balRaw(st.tin);
    var label, ok = false;
    if (st.busy) { label = st.busy; }
    else if (!st.addr) { label = "Connect wallet"; ok = true; }
    else if (raw <= 0n) label = "Enter an amount";
    else if (have !== null && raw > have) label = "Not enough " + sym(st.tin);
    else if (st.loading && !st.quote) label = "Finding the best price...";
    else if (!st.quote) label = st.err ? "Try a different amount" : "Enter an amount";
    else { label = "Swap " + sym(st.tin) + " for " + sym(st.tout); ok = true; }
    t.textContent = label; b.disabled = !ok || !!st.busy;
    b.classList.toggle("busy", !!st.busy);
  }

  // the ring that counts down to the next fresh quote
  var ring = $("sx-ring-fg"), C = 2 * Math.PI * 15;
  if (ring) { ring.style.strokeDasharray = C; }
  setInterval(function () {
    if (document.hidden || st.busy) return;
    if (!st.quote || st.loading) { if (ring) ring.style.strokeDashoffset = C; return; }
    st.left--;
    if (ring) ring.style.strokeDashoffset = String(C * (1 - st.left / REFRESH));
    if (st.left <= 0) quote();
  }, 1000);
  $("sx-refresh").addEventListener("click", function () { if (!st.busy) { this.classList.remove("spin"); void this.offsetWidth; this.classList.add("spin"); quote(); } });

  // ---------------------------------------------------------------- amount, flip, quick pairs, slippage
  var amt = $("sx-amt");
  amt.addEventListener("input", function () {
    var v = amt.value.replace(/,/g, ".").replace(/[^\d.]/g, ""), i = v.indexOf(".");
    if (i >= 0) v = v.slice(0, i + 1) + v.slice(i + 1).replace(/\./g, "").slice(0, st.tin.decimals);
    if (v !== amt.value) amt.value = v;
    st.amt = v; st.quote = null; st.err = ""; drawQuote(); want();
  });
  document.querySelectorAll("[data-pct]").forEach(function (b) {
    b.addEventListener("click", function () {
      var have = balRaw(st.tin); if (have === null) return;
      var r = have * BigInt(b.dataset.pct) / 100n;
      if (st.tin.id === SOL && b.dataset.pct === "100") { var keep = toRaw(String(FEE_SOL), 9); r = r > keep ? r - keep : 0n; }
      st.amt = fromRaw(r, st.tin.decimals); amt.value = st.amt; st.quote = null; drawQuote(); quote();
    });
  });
  $("sx-flip").addEventListener("click", function () {
    var a = st.tin; st.tin = st.tout; st.tout = a;
    if (st.quote) { st.amt = fromRaw(st.quote.outAmount, st.tin.decimals); amt.value = st.amt; }
    this.classList.remove("turn"); void this.offsetWidth; this.classList.add("turn");
    drawTokens(); st.quote = null; drawQuote(); quote(); remember();
  });
  document.querySelectorAll(".sx-route").forEach(function (b) {
    b.addEventListener("click", function () {
      setPair(b.dataset.in, b.dataset.out);
    });
  });
  function setPair(inId, outId) {
    Promise.all([tokenById(inId), tokenById(outId)]).then(function (r) {
      if (!r[0] || !r[1]) return;
      if (r[0].id !== st.tin.id) { st.amt = ""; amt.value = ""; }   // the number was in the old token
      st.tin = r[0]; st.tout = r[1]; drawTokens(); st.quote = null; st.err = ""; drawQuote(); quote(); remember();
    });
  }
  function slipText() { return st.slip === "" ? "Auto" : (st.slip / 100) + "%"; }
  $("sx-slip-b").addEventListener("click", function () { var p = $("sx-slip"); p.hidden = !p.hidden; this.setAttribute("aria-expanded", p.hidden ? "false" : "true"); drawSlip(); });
  function drawSlip() { document.querySelectorAll("[data-slip]").forEach(function (b) { b.classList.toggle("on", b.dataset.slip === String(st.slip)); }); $("sx-slip-v").textContent = slipText(); }
  document.querySelectorAll("[data-slip]").forEach(function (b) { b.addEventListener("click", function () { st.slip = b.dataset.slip; $("sx-slip-in").value = ""; drawSlip(); quote(); remember(); }); });
  $("sx-slip-in").addEventListener("input", function () {
    var v = parseFloat(this.value.replace(",", "."));
    if (v > 0 && v <= 50) { st.slip = String(Math.round(v * 100)); drawSlip(); want(); remember(); }
  });
  $("sx-det-b").addEventListener("click", function () { var d = $("sx-det"); d.hidden = !d.hidden; this.setAttribute("aria-expanded", d.hidden ? "false" : "true"); this.classList.toggle("open", !d.hidden); });

  // ---------------------------------------------------------------- the token picker
  var pick = $("sx-pick"), list = $("sx-list"), qIn = $("sx-q"), sTimer = 0, sn = 0;
  function tokenById(id) {
    if (KNOWN[id]) return Promise.resolve(KNOWN[id]);
    var x = st.tokens.concat(st.bal ? st.bal.tokens : []).filter(function (t) { return t.id === id; })[0];
    if (x) { KNOWN[id] = x; return Promise.resolve(x); }
    return api({ a: "search", q: id }).then(function (j) { var t = j && j.tokens && j.tokens[0]; if (t) KNOWN[t.id] = t; return t || null; }).catch(function () { return null; });
  }
  function row(t) {
    var b = st.bal ? (t.id === SOL ? { raw: st.bal.sol } : st.bal.tokens.filter(function (k) { return k.id === t.id; })[0]) : null;
    var amtTxt = b && b.raw && b.raw !== "0" ? nice(fromRaw(b.raw, t.decimals)) : "";
    return '<button class="sx-trow" role="option" data-id="' + esc(t.id) + '"><img alt="" src="' + esc(t.icon || "/assets/art/icon-192.png") + '" onerror="this.onerror=null;this.src=\'/assets/art/icon-192.png\'"><span><b>' + esc(sym(t)) + (t.verified ? ' <i class="sx-ver" title="Verified by Jupiter"></i>' : "") + '</b><small>' + esc(t.name) + ' &middot; ' + esc(short(t.id)) + '</small></span>' + (amtTxt ? '<em>' + esc(amtTxt) + '</em>' : "") + '</button>';
  }
  function openPick(side) {
    st.picking = side;
    $("sx-pick-h").textContent = side === "in" ? "You pay with" : "You receive";
    qIn.value = ""; drawPickList(); open(pick);
    setTimeout(function () { if (window.matchMedia("(min-width: 700px)").matches) qIn.focus(); }, 60);
    if (!st.tokens.length) api({ a: "tokens" }).then(function (j) { if (j && j.tokens) { st.tokens = j.tokens; j.tokens.forEach(function (t) { if (!KNOWN[t.id] || !KNOWN[t.id].icon) KNOWN[t.id] = t; }); fixKnownIcons(); drawPickList(); } }).catch(function () {});
  }
  function fixKnownIcons() { [st.tin, st.tout].forEach(function (t) { var k = KNOWN[t.id]; if (k && k.icon && !t.icon) t.icon = k.icon; }); drawTokens(); }
  function drawPickList() {
    var pop = st.tokens.slice(0, 8);
    $("sx-pop").innerHTML = pop.map(function (t) { return '<button data-id="' + esc(t.id) + '"><img alt="" src="' + esc(t.icon || "/assets/art/icon-192.png") + '">' + esc(sym(t)) + '</button>'; }).join("");
    var seen = {}, rows = [];
    (st.bal ? [{ id: SOL, symbol: "SOL", name: "Solana", decimals: 9, icon: (KNOWN[SOL] && KNOWN[SOL].icon) || "" }].concat(st.bal.tokens) : []).concat(st.tokens).forEach(function (t) { if (!seen[t.id]) { seen[t.id] = 1; rows.push(t); } });
    list.innerHTML = rows.length ? (st.bal ? '<p class="sx-lh">Your tokens and popular ones</p>' : '<p class="sx-lh">Popular tokens</p>') + rows.map(row).join("") : '<div class="sx-load"><i></i><i></i><i></i><span>Loading tokens</span></div>';
    $("sx-pick-n").hidden = true;
  }
  qIn.addEventListener("input", function () {
    clearTimeout(sTimer);
    var q = qIn.value.trim();
    if (!q) { drawPickList(); return; }
    var local = st.tokens.concat(st.bal ? st.bal.tokens : []).filter(function (t) { return (t.symbol + " " + t.name + " " + t.id).toLowerCase().indexOf(q.toLowerCase()) >= 0; });
    list.innerHTML = local.length ? local.map(row).join("") : '<div class="sx-load"><i></i><i></i><i></i><span>Searching</span></div>';
    sTimer = setTimeout(function () {
      var n = ++sn;
      api({ a: "search", q: q }).then(function (j) {
        if (n !== sn) return;
        var seen = {}, all = [];
        local.concat((j && j.tokens) || []).forEach(function (t) { if (!seen[t.id]) { seen[t.id] = 1; all.push(t); KNOWN[t.id] = KNOWN[t.id] || t; } });
        list.innerHTML = all.map(row).join("");
        var note = $("sx-pick-n");
        if (!all.length) { note.hidden = false; note.textContent = j && j.need === "mint" ? "Paste the token's address (its mint) to find any token." : "No token found. Check the name, or paste the token's address."; }
        else note.hidden = true;
      }).catch(function () {});
    }, 300);
  });
  function choose(id) {
    tokenById(id).then(function (t) {
      if (!t) return;
      if (st.picking === "in") { if (t.id === st.tout.id) st.tout = st.tin; if (t.id !== st.tin.id) { st.amt = ""; amt.value = ""; } st.tin = t; }
      else { if (t.id === st.tin.id) st.tin = st.tout; st.tout = t; }
      close(pick); drawTokens(); st.quote = null; st.err = ""; drawQuote(); quote(); remember();
    });
  }
  list.addEventListener("click", function (e) { var b = e.target.closest("[data-id]"); if (b) choose(b.dataset.id); });
  $("sx-pop").addEventListener("click", function (e) { var b = e.target.closest("[data-id]"); if (b) choose(b.dataset.id); });
  $("sx-tok-in").addEventListener("click", function () { openPick("in"); });
  $("sx-tok-out").addEventListener("click", function () { openPick("out"); });

  // ---------------------------------------------------------------- dialogs
  var opener = null;
  function open(m) { opener = document.activeElement; m.hidden = false; requestAnimationFrame(function () { m.classList.add("in"); }); document.documentElement.classList.add("sx-lock"); }
  function close(m) { m.classList.remove("in"); setTimeout(function () { m.hidden = true; }, 200); document.documentElement.classList.remove("sx-lock"); if (opener && opener.focus) try { opener.focus({ preventScroll: true }); } catch (e) {} }
  [pick, $("sx-wal")].forEach(function (m) {
    m.addEventListener("click", function (e) { if (e.target === m || e.target.closest("[data-close]")) close(m); });
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") [pick, $("sx-wal")].forEach(function (m) { if (!m.hidden) close(m); }); });

  // ---------------------------------------------------------------- wallets (the Solana Wallet Standard)
  function addWallet(w) {
    try {
      if (!w || !w.features || !w.features["standard:connect"] || !w.features["solana:signTransaction"]) return;
      if (!(w.chains || []).some(function (c) { return String(c).indexOf("solana:") === 0; })) return;
      if (st.wallets.some(function (x) { return x === w || x.name === w.name; })) return;
      st.wallets.push(w); drawWallets();
      autoReconnect(w);
    } catch (e) {}
  }
  var reg = { register: function () { for (var i = 0; i < arguments.length; i++) addWallet(arguments[i]); return function () {}; } };
  window.addEventListener("wallet-standard:register-wallet", function (e) { try { e.detail(reg); } catch (err) {} });
  try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: reg })); } catch (e) {}
  function drawWallets() {
    var l = $("sx-wlist");
    l.innerHTML = st.wallets.map(function (w, i) { return '<button class="sx-wrow" data-w="' + i + '"><img alt="" src="' + esc(w.icon || "") + '"><b>' + esc(w.name) + '</b><span>Detected</span></button>'; }).join("");
    $("sx-wnone").hidden = st.wallets.length > 0;
    var ph = $("sx-wnone-ph"), mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (mobile && window.ShyEx && ShyEx.phantomLink) { ph.href = ShyEx.phantomLink; ph.textContent = "Open in Phantom"; ph.removeAttribute("target"); }
  }
  $("sx-wlist").addEventListener("click", function (e) { var b = e.target.closest("[data-w]"); if (b) connect(st.wallets[+b.dataset.w]); });
  function connect(w, silent) {
    if (!w) return Promise.resolve();
    return w.features["standard:connect"].connect(silent ? { silent: true } : undefined).then(function (r) {
      var acct = (r && r.accounts && r.accounts[0]) || (w.accounts && w.accounts[0]);
      if (!acct) return;
      st.w = w; st.acct = acct; st.addr = acct.address;
      try { localStorage.setItem("shy-sx-wallet", w.name); } catch (e) {}
      if (!silent) close($("sx-wal"));
      drawMe(); loadBal(); drawGo();
      if (w.features["standard:events"]) try { w.features["standard:events"].on("change", function (p) { if (p && p.accounts) { var a = p.accounts[0]; if (!a) disconnect(true); else if (a.address !== st.addr) { st.acct = a; st.addr = a.address; drawMe(); loadBal(); } } }); } catch (e) {}
    }).catch(function (e) { if (!silent) toast(/reject|cancel|denied/i.test(String(e && e.message)) ? "You cancelled the connection." : "That wallet didn't connect. Try again."); });
  }
  function autoReconnect(w) {
    var last = ""; try { last = localStorage.getItem("shy-sx-wallet") || ""; } catch (e) {}
    if (!st.addr && last && w.name === last) connect(w, true);
  }
  function disconnect(quiet) {
    var w = st.w; st.w = null; st.acct = null; st.addr = ""; st.bal = null;
    try { localStorage.removeItem("shy-sx-wallet"); } catch (e) {}
    if (!quiet && w && w.features["standard:disconnect"]) try { w.features["standard:disconnect"].disconnect(); } catch (e) {}
    drawMe(); drawBal(); drawGo();
  }
  function drawMe() {
    var m = $("sx-me");
    m.hidden = !st.addr;
    if (st.addr) m.innerHTML = (st.w && st.w.icon ? '<img alt="" src="' + esc(st.w.icon) + '">' : "") + esc(short(st.addr)) + ' <i title="Disconnect">&times;</i>';
  }
  $("sx-me").addEventListener("click", function () { disconnect(); toast("Wallet disconnected."); });
  function loadBal() {
    if (!st.addr) return;
    var a = st.addr;
    api({ a: "balances", owner: a }).then(function (j) {
      if (a !== st.addr || !j || !j.ok) return;
      st.bal = { sol: j.sol || "0", tokens: j.tokens || [] };
      if (j.solUsd) st.tin.id === SOL ? (st.tin.usd = j.solUsd) : (KNOWN[SOL].usd = j.solUsd);
      j.tokens.forEach(function (t) { if (!KNOWN[t.id]) KNOWN[t.id] = t; });
      drawBal(); drawGo();
    }).catch(function () {});
  }

  // ---------------------------------------------------------------- the swap
  $("sx-go").addEventListener("click", function () {
    if (!st.addr) { drawWallets(); open($("sx-wal")); return; }
    swap();
  });
  function swap() {
    var raw = toRaw(st.amt, st.tin.decimals); if (raw <= 0n || st.busy) return;
    var tin = st.tin, tout = st.tout, acct = st.acct, w = st.w, rid = "";
    busy("Getting your swap ready...");
    api({ a: "order", inputMint: tin.id, outputMint: tout.id, amount: raw.toString(), slippageBps: st.slip, taker: st.addr }).then(function (q) {
      if (!q || !q.transaction) throw new Error(friendly(q));
      st.quote = q; drawQuote(); rid = q.requestId;
      busy("Approve it in your wallet...");
      return w.features["solana:signTransaction"].signTransaction({ account: acct, transaction: b64ToBytes(q.transaction), chain: "solana:mainnet" });
    }).then(function (res) {
      var out = Array.isArray(res) ? res[0] : res;
      var signed = out && (out.signedTransaction || out.transaction);
      if (!signed) throw new Error("Your wallet didn't return the signed swap.");
      busy("Swapping...");
      return fetch(API, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ a: "execute", signedTransaction: bytesToB64(new Uint8Array(signed)), requestId: rid }) }).then(function (r) { return r.json(); });
    }).then(function (x) {
      busy("");
      if (x && x.status === "Success" && x.signature) {
        var got = x.outputAmountResult || x.totalOutputAmount || (st.quote && st.quote.outAmount);
        var txt = got ? "You got " + nice(fromRaw(got, tout.decimals)) + " " + sym(tout) + "." : "";
        if (window.ShyEx && ShyEx.done) ShyEx.done(x.signature, tout.id === SHY, tout.id === SHY ? txt + " Welcome to the Shy Army. Connect this wallet in Shilluminati Online to unlock holder perks: shop discounts, weekly Koban and holder-only events." : txt + " It's on Solana for good, and you can check it any time.");
        st.amt = ""; amt.value = ""; st.quote = null; drawQuote();
        setTimeout(loadBal, 2500); setTimeout(loadBal, 9000);
      } else {
        st.err = x && x.error ? friendly({ error: x.error }) : "The swap didn't go through" + (x && x.code != null ? " (code " + x.code + ")" : "") + ". Nothing was taken except possibly a tiny network fee. Get a new price and try again.";
        drawQuote();   // the message stays until they change something; the ring brings a fresh price
      }
    }).catch(function (e) {
      busy("");
      var m = String(e && e.message || "");
      st.err = /reject|cancel|denied|declined|user/i.test(m) ? "You cancelled it in your wallet. Nothing was spent." : (m || "Something went wrong. Nothing was spent. Try again.");
      drawQuote();
    });
  }
  function busy(t) { st.busy = t; drawGo(); $("sx-swap").classList.toggle("working", !!t); }
  function toast(t) { var el = $("toast"); if (!el) return; var was = el.textContent; el.textContent = t; el.classList.add("show"); setTimeout(function () { el.classList.remove("show"); el.textContent = was; }, 2200); }

  // ---------------------------------------------------------------- remember the pair and slippage, links in
  function remember() { try { localStorage.setItem("shy-sx", JSON.stringify({ i: st.tin.id, o: st.tout.id, s: st.slip })); } catch (e) {} }
  (function start() {
    var p = {}; try { p = JSON.parse(localStorage.getItem("shy-sx") || "{}") || {}; } catch (e) {}
    var m = /[?&]out=([1-9A-HJ-NP-Za-km-z]{32,44})/.exec(location.search), mi = /[?&]in=([1-9A-HJ-NP-Za-km-z]{32,44})/.exec(location.search);
    if (p.s != null) st.slip = String(p.s);
    drawSlip(); drawTokens(); drawQuote();
    var inId = mi ? mi[1] : (p.i || SOL), outId = m ? m[1] : (p.o || SHY);
    if (inId !== SOL || outId !== SHY) setPair(inId, outId);
    api({ a: "cfg" }).then(function (j) { if (j && j.ok) { st.fee = j.fee || 0; st.search = !!j.search; } }).catch(function () {});
    api({ a: "tokens" }).then(function (j) { if (j && j.tokens) { st.tokens = j.tokens; j.tokens.forEach(function (t) { if (!KNOWN[t.id] || !KNOWN[t.id].icon) { if (KNOWN[t.id]) { KNOWN[t.id].icon = t.icon; KNOWN[t.id].name = t.name; } else KNOWN[t.id] = t; } }); fixKnownIcons(); } }).catch(function () {});
    // a first quote for 1 SOL so the rate shows straight away
    if (!st.amt) { amt.value = ""; }
  })();
  window.ShySwap = { pair: function () { return { in: st.tin.id, out: st.tout.id }; } };
})();
