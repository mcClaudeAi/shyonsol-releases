//MC 2026-10-12 The Shogun on the Stats page, from api/stats.php?a=boss. Rebuilt to read at a glance: one scoreboard (the
//   Shogun's wins against the players'), one plain sentence ("Players win 1 match in 8"), the reward as it is set now, four
//   numbers, then how matches end in five plain groups instead of 31 thin bars, the last 30 days and the Hall of victors.
//   The first version had a win-rate ring, a tug of war and a 31-column chart side by side; people asked what it meant.
(function () {
  "use strict";
  var root = document.getElementById("sg");
  if (!root) return;
  var $ = function (id) { return document.getElementById(id); };
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var LANG = ((window.SHYI18N && SHYI18N.locale) || document.documentElement.lang) || "en";
  var D = null, view = "recent", shown = false;
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString("en-US"); }
  function slug(n) { return String(n).replace(/ /g, "_"); }
  function ago(t) {
    var s = Math.max(0, Math.floor(Date.now() / 1000 - t)), f;
    try { f = new Intl.RelativeTimeFormat(LANG, { numeric: "auto", style: "narrow" }); } catch (e) { return ""; }
    if (s < 3600) return f.format(-Math.max(1, Math.floor(s / 60)), "minute");
    if (s < 86400) return f.format(-Math.floor(s / 3600), "hour");
    return f.format(-Math.floor(s / 86400), "day");
  }
  function day(d) { try { return new Date(d + "T12:00:00Z").toLocaleDateString(LANG, { month: "short", day: "numeric" }); } catch (e) { return d; } }
  function countUp(el, to) {
    if (reduce || !to) { el.textContent = fmt(to); return; }
    var t0 = performance.now();
    (function step(t) { var k = Math.min(1, (t - t0) / 1100), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(to * e)); if (k < 1) requestAnimationFrame(step); })(t0);
  }
  function who(n) { return '<a href="/p/' + encodeURIComponent(slug(n)) + '" data-i18n-skip>' + esc(n) + '</a>'; }

  function top() {
    var sw = D.g - D.w, pw = D.w;
    countUp($("sg-sw"), sw); countUp($("sg-pw"), pw);
    var tot = Math.max(1, D.g);
    $("sg-bs").style.width = (D.g ? 100 * sw / tot : 50) + "%";
    $("sg-bp").style.width = (D.g ? 100 * pw / tot : 50) + "%";
    root.classList.toggle("lead-s", sw > pw); root.classList.toggle("lead-p", pw > sw);
    var line;
    if (!D.g) line = "Nobody has played it yet. Be the first.";
    else if (!pw) line = "Nobody has beaten it yet. " + (D.g === 1 ? "1 match so far." : fmt(D.g) + " matches so far.");
    else { var one = Math.max(1, Math.round(D.g / pw)); line = "Players win about 1 match in " + one + " (" + Math.round(100 * pw / D.g) + "%)."; }
    $("sg-line").textContent = line;
    $("sg-reward").innerHTML = !D.on ? "The Shogun is resting right now." : D.koban ? '<i class="kb-coin"></i>' + (D.per === "week" ? "Beat it for " + fmt(D.koban) + " Koban, once a week." : "Beat it for " + fmt(D.koban) + " Koban, once a day" + (D.wcap ? ", " + D.wcap + " bounties a week." : ".")) : "Beat it for glory and a place in the Hall of victors.";
    root.querySelectorAll("[data-sg]").forEach(function (el) {
      var k = el.dataset.sg;
      if (k === "big") el.textContent = D.big ? D.big.r + "-" + D.big.b : "None yet";
      else if (k === "bigwho") el.innerHTML = D.big ? who(D.big.n) : "";
      else countUp(el, D[k] || 0);
    });
  }
  // five plain groups: how far apart each match finished
  function ends() {
    var d = D.diff || [], sum = function (a, b) { var s = 0; for (var k = a; k <= b; k++) s += d[k + 15] || 0; return s; };
    var G = [["Shogun won by 4 or more", sum(-15, -4), "s2"], ["Shogun won by 1 to 3", sum(-3, -1), "s1"], ["Level on Regions", sum(0, 0), "t"], ["Player won by 1 to 3", sum(1, 3), "p1"], ["Player won by 4 or more", sum(4, 15), "p2"]];
    var tot = G.reduce(function (a, g) { return a + g[1]; }, 0);
    if (!tot) { $("sg-ends").innerHTML = '<p class="st-empty">No boss matches yet.</p>'; return; }
    $("sg-ends").innerHTML = '<div class="sg-stack">' + G.map(function (g) { return g[1] ? '<i class="' + g[2] + '" style="flex:' + g[1] + '"></i>' : ""; }).join("") + '</div>' +
      '<ul class="sg-rows">' + G.map(function (g) { var p = Math.round(100 * g[1] / tot); return '<li class="' + g[2] + '"><i></i><span>' + g[0] + '</span><b data-i18n-skip>' + fmt(g[1]) + '</b><em data-i18n-skip>' + p + '%</em></li>'; }).join("") + '</ul>' +
      '<p class="st-note">' + (G[2][1] ? "A match level on Regions goes to whoever holds more cards." : "") + '</p>';
  }
  function days() {
    var list = D.days || [], max = 1; list.forEach(function (x) { max = Math.max(max, x[1]); });
    var any = list.some(function (x) { return x[1] > 0; });
    $("sg-days").innerHTML = '<div class="sg-bars">' + list.map(function (x) {
      var h = 100 * x[1] / max, hw = x[1] ? h * x[2] / x[1] : 0;
      return '<span title="' + esc(day(x[0])) + ': ' + x[1] + ' / ' + x[2] + '"><i class="m" style="height:' + h.toFixed(1) + '%"></i><i class="w" style="height:' + hw.toFixed(1) + '%"></i></span>';
    }).join("") + '</div><div class="sg-ax"><span data-i18n-skip>' + esc(day(list[0] ? list[0][0] : "")) + '</span><span>Today</span></div>' + (any ? "" : '<p class="st-empty sg-none">No boss matches in the last 30 days.</p>');
  }
  function hall() {
    var el = $("sg-list"), rows = view === "recent" ? D.recent : D.top;
    if (!rows.length) { el.innerHTML = '<li class="st-empty">Nobody has beaten the Shogun yet. Be the first.</li>'; return; }
    el.innerHTML = rows.map(function (x, i) {
      if (view === "recent") return '<li><span class="sg-chip" data-i18n-skip>' + x.r + '-' + x.b + '</span><span class="st-li-n">' + who(x.n) + '<small><span data-i18n-skip>' + esc(ago(x.t)) + '</span>' + (x.k ? ' &middot; +' + fmt(x.k) + ' Koban' : "") + '</small></span></li>';
      return '<li><span class="st-pos">' + (i + 1) + '</span><span class="st-li-n">' + who(x.n) + '<small>Best ' + x.best + ' Regions</small></span><b class="st-li-v" data-i18n-skip>' + x.w + '-' + (x.g - x.w) + '</b></li>';
    }).join("");
  }
  function draw() { top(); ends(); days(); hall(); root.classList.add("on"); }
  root.addEventListener("click", function (e) {
    var b = e.target.closest("[data-sgv]"); if (!b || !D) return;
    b.parentNode.querySelectorAll("button").forEach(function (x) { x.classList.toggle("on", x === b); });
    view = b.dataset.sgv; hall();
  });
  function load() {
    fetch("/api/stats.php?a=boss", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) { if (!j || !j.ok) return; D = j; if (shown) draw(); }).catch(function () {});
  }
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { shown = true; io.disconnect(); if (D) draw(); } }); }, { rootMargin: "0px 0px -10% 0px" });
    io.observe(root);
  } else shown = true;
  load();
  setInterval(function () { if (!document.hidden && shown) load(); }, 60000);
})();
