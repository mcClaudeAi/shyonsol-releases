//MC 2026-10-17 Shy Exchange (/exchange). The swap is the Jupiter Plugin (https://plugin.jup.ag/plugin-v1.js, loaded in the
//   page head with data-preload defer), started here once the page has loaded. It runs in the visitor's browser with
//   their own wallet: no backend, no RPC and no API key on our side. $SHY is preselected as the token to buy but not
//   locked, so any Solana token can be swapped. Around it: the quick pairs, the live $SHY numbers (api/market.php, the
//   site's cached DexScreener data), the DexScreener chart, the contract copy button, an Open in Phantom prompt for
//   phones outside a wallet app, and a burst of coins when a swap goes through.
(function () {
  "use strict";
  var EX = window.SHY_EX || {}, CA = EX.ca, SOL = EX.sol;
  var $ = function (id) { return document.getElementById(id); };
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var box = $("jupiter-plugin");
  if (!box || !CA) return;

  // ---------------------------------------------------------------- the swap
  var started = false, failed = false, current = { in: SOL, out: CA };
  function swapConfig(inMint, outMint) {
    return {
      displayMode: "integrated",
      integratedTargetId: "jupiter-plugin",
      formProps: {
        initialInputMint: inMint,
        initialOutputMint: outMint
        // A referral fee can go here later. Make a referral account at https://referral.jup.ag, then add:
        // referralAccount: "YOUR_REFERRAL_ACCOUNT_ADDRESS",
        // referralFee: 50,   // in basis points: 50 = 0.5%, the most is 255
      },
      branding: { logoUri: EX.logo, name: "Shy Exchange" },
      containerStyles: { width: "100%", height: "100%", borderRadius: "20px", overflow: "hidden" },
      defaultExplorer: "Solscan",
      onSuccess: function (r) { done(r && (r.txid || (r.swapResult && r.swapResult.txid))); },
      onSwapError: function () {}
    };
  }
  function fail() {
    if (started) return;
    failed = true;
    box.hidden = true; $("sx-fail").hidden = false;
  }
  function start(inMint, outMint) {
    if (!window.Jupiter || typeof window.Jupiter.init !== "function") return false;
    try {
      // a new pair: start over in the same box
      if (started) { try { if (window.Jupiter.close) window.Jupiter.close(); } catch (e) {} box.innerHTML = ""; }
      window.Jupiter.init(swapConfig(inMint, outMint));
      started = true; current = { in: inMint, out: outMint };
      box.classList.add("on");
      $("sx-swap").classList.add("ready");
      return true;
    } catch (e) { return false; }
  }
  function boot() {
    var tries = 0;
    (function wait() {
      if (start(current.in, current.out)) return;
      if (++tries > 75) { fail(); return; }   // 15 seconds
      setTimeout(wait, 200);
    })();
  }
  if (document.readyState === "complete") boot(); else window.addEventListener("load", boot);

  // the quick pairs above the swap
  document.querySelectorAll(".sx-route").forEach(function (b) {
    b.addEventListener("click", function () {
      if (failed || b.classList.contains("on")) return;
      if (start(b.dataset.in, b.dataset.out)) {
        document.querySelectorAll(".sx-route").forEach(function (x) { x.classList.toggle("on", x === b); });
      }
    });
  });

  // after a swap: log it for the team's reports (the server checks it on Solana), then the celebration
  function logSwap(txid) {
    if (!txid) return;
    var pid = ""; try { pid = localStorage.getItem("shy-lb-pid") || ""; } catch (e) {}
    try { fetch("/api/buylog.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sig: String(txid), pid: pid, src: "exchange" }), keepalive: true }).catch(function () {}); } catch (e) {}
  }
  function done(txid) {
    logSwap(txid);
    var d = $("sx-done"), tx = $("sx-done-tx"), toShy = current.out === CA;
    $("sx-done-h").textContent = toShy ? "Welcome to the Shy Army." : "Swap complete.";
    $("sx-done-p").textContent = toShy ? "Your $SHY is in your wallet. Connect this wallet in Shilluminati Online to unlock holder perks: shop discounts, weekly Koban and holder-only events." : "Your swap went through. It's on Solana for good, and you can check it any time.";
    if (txid) { tx.href = "https://solscan.io/tx/" + encodeURIComponent(txid); tx.hidden = false; } else tx.hidden = true;
    d.hidden = false;
    requestAnimationFrame(function () { d.classList.add("in"); });
    burst();
  }
  function closeDone() { var d = $("sx-done"); d.classList.remove("in"); setTimeout(function () { d.hidden = true; }, 260); }
  $("sx-done-x").addEventListener("click", closeDone);
  $("sx-done").addEventListener("click", function (e) { if (e.target === this) closeDone(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !$("sx-done").hidden) closeDone(); });

  // coins thrown up from the card
  function burst() {
    var c = $("sx-burst"); if (!c || reduce) return;
    var r = c.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = r.width * dpr; c.height = r.height * dpr;
    var x = c.getContext("2d"); x.scale(dpr, dpr);
    var ps = [], cols = ["#ffd166", "#ff9f43", "#ff5d73", "#f2c35b", "#ffffff"];
    for (var i = 0; i < 90; i++) ps.push({ x: r.width / 2, y: r.height * .42, vx: (Math.random() - .5) * 9, vy: -Math.random() * 10 - 3, s: 3 + Math.random() * 6, c: cols[i % cols.length], r: Math.random() * 6, vr: (Math.random() - .5) * .3, coin: i % 3 === 0 });
    var t0 = performance.now();
    (function f(t) {
      var k = (t - t0) / 1000; x.clearRect(0, 0, r.width, r.height);
      ps.forEach(function (p) {
        p.vy += .32; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        x.save(); x.globalAlpha = Math.max(0, 1 - k / 2.2); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c;
        if (p.coin) { x.beginPath(); x.ellipse(0, 0, p.s * 1.3, p.s * 1.3 * Math.abs(Math.cos(p.r)), 0, 0, Math.PI * 2); x.fill(); }
        else x.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
        x.restore();
      });
      if (k < 2.3) requestAnimationFrame(f); else x.clearRect(0, 0, r.width, r.height);
    })(t0);
  }

  // ---------------------------------------------------------------- the live numbers
  function money(n) {
    if (!(n > 0)) return "$0";
    if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
    if (n >= 1e6) return "$" + (n / 1e6).toFixed(2) + "M";
    if (n >= 1e3) return "$" + (n / 1e3).toFixed(1) + "K";
    return "$" + n.toFixed(0);
  }
  function price(n) {
    if (!(n > 0)) return "$0";
    if (n >= 1) return "$" + n.toFixed(3);
    var d = Math.max(2, Math.min(10, -Math.floor(Math.log10(n)) + 3));
    return "$" + n.toFixed(d);
  }
  function set(key, txt) { document.querySelectorAll('[data-sx="' + key + '"]').forEach(function (el) { el.textContent = txt; }); }
  var lastPrice = 0;
  function loadMarket() {
    fetch("/api/market.php?a=pair", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || !j.ok || !j.pair) return;
      var p = j.pair, el = document.querySelector('[data-sx="price"]');
      set("price", price(p.price));
      if (el && lastPrice && p.price !== lastPrice) { el.classList.remove("up", "down"); void el.offsetWidth; el.classList.add(p.price > lastPrice ? "up" : "down"); }
      lastPrice = p.price;
      var ch = document.querySelector('[data-sx="change"]');
      if (ch) { ch.textContent = (p.change >= 0 ? "+" : "") + (+p.change).toFixed(2) + "% 24h"; ch.className = "sx-chg " + (p.change >= 0 ? "up" : "down"); }
      set("mcap", money(p.mcap)); set("liq", money(p.liq)); set("vol", money(p.vol));
      set("buys", String(p.buys)); set("sells", String(p.sells));
      var tot = (p.buys || 0) + (p.sells || 0), bar = document.querySelector('[data-sx="buybar"]');
      if (bar) bar.style.width = (tot ? Math.round(p.buys / tot * 100) : 50) + "%";
      $("sx-ticks").classList.add("on");
    }).catch(function () {});
  }
  loadMarket();
  setInterval(function () { if (!document.hidden) loadMarket(); }, 60000);

  // ---------------------------------------------------------------- the chart
  var frame = $("sx-frame"), tf = "60", chartOn = false;
  function chartSrc(iv) { return "https://dexscreener.com/solana/" + frame.dataset.pair + "?embed=1&loadChartSettings=0&trades=0&tabs=0&info=0&chartLeftToolbar=0&chartTheme=dark&theme=dark&chartStyle=1&chartType=usd&interval=" + iv; }
  function showChart() {
    if (chartOn) return; chartOn = true;
    var f = document.createElement("iframe");
    f.src = chartSrc(tf); f.title = "$SHY chart on DexScreener"; f.loading = "lazy"; f.setAttribute("allow", "clipboard-write");
    f.addEventListener("load", function () { frame.classList.add("on"); });
    frame.appendChild(f);
  }
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) { if (es.some(function (e) { return e.isIntersecting; })) { io.disconnect(); showChart(); } }, { rootMargin: "300px" });
    io.observe(frame);
  } else showChart();
  document.querySelectorAll(".sx-tf button").forEach(function (b) {
    b.addEventListener("click", function () {
      tf = b.dataset.tf;
      document.querySelectorAll(".sx-tf button").forEach(function (x) { x.classList.toggle("on", x === b); x.setAttribute("aria-selected", x === b ? "true" : "false"); });
      var f = frame.querySelector("iframe");
      if (f) { frame.classList.remove("on"); f.src = chartSrc(tf); } else showChart();
    });
  });

  // ---------------------------------------------------------------- the contract address
  var caBtn = $("sx-ca"), toast = $("toast");
  caBtn.addEventListener("click", function () {
    function ok() {
      caBtn.classList.add("ok"); caBtn.querySelector("em").textContent = "Copied";
      if (toast) toast.classList.add("show");
      if (navigator.vibrate) try { navigator.vibrate(18); } catch (e) {}
      setTimeout(function () { caBtn.classList.remove("ok"); caBtn.querySelector("em").textContent = "Copy"; if (toast) toast.classList.remove("show"); }, 1800);
    }
    function old() { var t = document.createElement("textarea"); t.value = CA; t.setAttribute("readonly", ""); t.style.position = "fixed"; t.style.opacity = "0"; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); } catch (e) {} t.remove(); ok(); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(CA).then(ok, old); else old();
  });

  // ---------------------------------------------------------------- phones outside a wallet app
  //   The Phantom app's own browser has its wallet built in. In Safari or Chrome on a phone there's no wallet to connect,
  //   so offer to open this page inside Phantom (its universal link opens the app's browser at this address).
  (function () {
    var mobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    var hasWallet = !!(window.phantom && window.phantom.solana) || !!window.solana || !!window.solflare || !!window.backpack;
    var tg = !!(window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initData);
    if (!mobile || hasWallet || tg) return;
    var url = location.origin + location.pathname;
    $("sx-phantom-go").href = "https://phantom.app/ul/browse/" + encodeURIComponent(url) + "?ref=" + encodeURIComponent(location.origin);
    $("sx-phantom").hidden = false;
  })();

  // ---------------------------------------------------------------- the light on the swap card
  var card = $("sx-swap");
  if (card && window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches && !reduce) {
    card.addEventListener("pointermove", function (e) {
      var r = card.getBoundingClientRect();
      card.style.setProperty("--mx", ((e.clientX - r.left) / r.width * 100).toFixed(1) + "%");
      card.style.setProperty("--my", ((e.clientY - r.top) / r.height * 100).toFixed(1) + "%");
    });
  }

  // ---------------------------------------------------------------- gold coins drifting up behind the page top
  (function () {
    var c = $("sx-coins"); if (!c || reduce) return;
    var x = c.getContext("2d"), coins = [], w = 0, h = 0, run = true, dpr = Math.min(2, window.devicePixelRatio || 1);
    var small = window.innerWidth < 700, N = small ? 14 : 26;
    function size() { var r = c.getBoundingClientRect(); w = r.width; h = r.height; c.width = w * dpr; c.height = h * dpr; x.setTransform(dpr, 0, 0, dpr, 0, 0); }
    function coin(y) { return { x: Math.random() * w, y: y == null ? Math.random() * h : h + 20, s: 4 + Math.random() * (small ? 6 : 9), v: .15 + Math.random() * .45, a: Math.random() * 6.28, va: .01 + Math.random() * .03, o: .18 + Math.random() * .35 }; }
    size(); for (var i = 0; i < N; i++) coins.push(coin());
    window.addEventListener("resize", size);
    document.addEventListener("visibilitychange", function () { run = !document.hidden; if (run) requestAnimationFrame(f); });
    if ("IntersectionObserver" in window) new IntersectionObserver(function (es) { var v = es[0].isIntersecting; if (v && !run) { run = true; requestAnimationFrame(f); } else if (!v) run = false; }).observe(c);
    function f() {
      if (!run) return;
      x.clearRect(0, 0, w, h);
      coins.forEach(function (p, i) {
        p.y -= p.v; p.a += p.va;
        if (p.y < -20) coins[i] = p = coin(1);
        var sx = Math.abs(Math.cos(p.a));
        x.globalAlpha = p.o;
        x.fillStyle = "#f2c35b"; x.beginPath(); x.ellipse(p.x, p.y, p.s * sx + .6, p.s, 0, 0, Math.PI * 2); x.fill();
        x.fillStyle = "#ffe29a"; x.beginPath(); x.ellipse(p.x, p.y, (p.s * .55) * sx + .3, p.s * .55, 0, 0, Math.PI * 2); x.fill();
      });
      x.globalAlpha = 1;
      requestAnimationFrame(f);
    }
    requestAnimationFrame(f);
  })();
})();
