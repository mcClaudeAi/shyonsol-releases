//MC 2026-10-23 one wallet layer for the game's wallet connect and Shy Swap. Phantom, Solflare, Trust Wallet and
//   MetaMask on a computer (their extensions, through the Solana Wallet Standard) and on a phone, where the wallet app
//   only opens to approve and the player comes straight back to the game:
//   - wallets in the page: every Wallet Standard wallet the browser has (extensions, or a wallet's own browser)
//   - Trust Wallet on a phone: WalletConnect (assets/vendor/wwc.js, loaded only when picked; needs the project id
//     from Admin > Shy Swap). Trust opens for each approval, the page keeps its place.
//   - MetaMask on a phone, or a computer without the extension: MetaMask Connect (assets/vendor/wmm.js)
//   Both are wrapped as Wallet Standard wallets and announced the normal way, so Shy Swap and the game use them like
//   any extension. Phones only open another app from a tap, so every hand-off to a wallet app is a real button in a
//   small sheet (ShyWallets.tap), and inside Telegram the link goes through Telegram's own openLink.
//   Solflare on a phone keeps its deeplink flow (Shy Swap: api/swap.php; the game: api/wallet.php), no relay needed.
(function () {
  "use strict";
  var MAIN = "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp", V = (document.currentScript && /[?&]v=([\w]+)/.exec(document.currentScript.src) || [])[1] || "1";
  var A58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  function b58e(bytes) {
    var d = [], z = 0, out = "";
    while (z < bytes.length && bytes[z] === 0) z++;
    for (var i = 0; i < bytes.length; i++) { var c = bytes[i]; for (var k = 0; k < d.length; k++) { c += d[k] << 8; d[k] = c % 58; c = (c / 58) | 0; } while (c) { d.push(c % 58); c = (c / 58) | 0; } }
    for (var j = 0; j < z; j++) out += "1";
    for (var m = d.length - 1; m >= 0; m--) out += A58[d[m]];
    return out;
  }
  function b58d(s) {
    s = String(s || ""); var b = [], z = 0;
    while (z < s.length && s[z] === "1") z++;
    for (var i = 0; i < s.length; i++) { var c = A58.indexOf(s[i]); if (c < 0) throw new Error("bad base58"); for (var k = 0; k < b.length; k++) { c += b[k] * 58; b[k] = c & 255; c >>= 8; } while (c) { b.push(c & 255); c >>= 8; } }
    var out = new Uint8Array(z + b.length); for (var j = 0; j < b.length; j++) out[z + j] = b[b.length - 1 - j];
    return out;
  }
  function b64e(bytes) { var s = ""; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); }
  function b64d(s) { var r = atob(String(s || "")), o = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) o[i] = r.charCodeAt(i); return o; }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function isPhone() { return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent); }
  function inTg() { return document.documentElement.classList.contains("tgapp"); }
  function tgW() { return window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.openLink ? window.Telegram.WebApp : null; }
  // open a wallet app: inside Telegram through its own openLink (web links only), anywhere else the page itself goes
  function openUrl(u) { var W = tgW(); if (inTg() && W && /^https:/.test(u)) { W.openLink(u); return; } location.href = u; }
  function loadScript(src) {
    return new Promise(function (ok, bad) {
      if (document.querySelector('script[data-wk="' + src + '"]')) { var t = setInterval(function () { if (window[src === "wwc" ? "ShyWC" : "ShyMM"]) { clearInterval(t); ok(); } }, 50); setTimeout(function () { clearInterval(t); bad(new Error("The wallet kit didn't load. Check your connection.")); }, 20000); return; }
      var s = document.createElement("script"); s.src = "/assets/vendor/" + src + ".js?v=" + V; s.async = true; s.setAttribute("data-wk", src);
      s.onload = function () { ok(); }; s.onerror = function () { bad(new Error("The wallet kit didn't load. Check your connection.")); };
      document.head.appendChild(s);
    });
  }
  var cfg = null, cfgP = fetch("/api/wallet.php?a=cfg").then(function (r) { return r.json(); }).then(function (j) { cfg = j && j.ok ? j : { wc: "" }; return cfg; }).catch(function () { cfg = { wc: "" }; return cfg; });

  // ---------------------------------------------------------------- the hand-off sheet: one tap to open the wallet
  var sheet = null;
  function sheetEl() {
    if (sheet) return sheet;
    sheet = document.createElement("div"); sheet.className = "wk-sheet"; sheet.hidden = true;
    sheet.setAttribute("role", "dialog"); sheet.setAttribute("aria-modal", "true");
    document.body.appendChild(sheet);
    return sheet;
  }
  // o: {title, text, label, url (opened on the tap), onTap (runs inside the tap), qr (shown on a computer), wait}
  // returns {tapped: Promise, done(), say(text)}; Cancel rejects tapped with "cancelled"
  function tap(o) {
    var el = sheetEl(), ctl = {}, ok, bad;
    ctl.tapped = new Promise(function (a, b) { ok = a; bad = b; });
    ctl.tapped.catch(function () {});
    var btn = o.url || o.onTap ? '<a class="btn btn-gold wk-go" href="' + esc(o.url || "#") + '"' + (o.url && !inTg() ? "" : ' data-js="1"') + ">" + esc(o.label || "Open the wallet") + "</a>" : "";
    el.innerHTML = '<div class="wk-card"><b class="wk-h">' + esc(o.title || "") + '</b><p class="wk-t">' + esc(o.text || "") + "</p>" + (o.qr ? '<div class="wk-qr" aria-label="Scan with your phone"></div>' : "") +
      (o.wait ? "" : btn) + '<p class="wk-wait"' + (o.wait ? "" : " hidden") + '><i class="wk-spin" aria-hidden="true"></i><span>' + esc(o.wait || "Waiting for the wallet...") + "</span></p>" +
      '<button type="button" class="wk-x">Cancel</button></div>';
    el.hidden = false; requestAnimationFrame(function () { el.classList.add("in"); });
    if (o.qr) loadQR(o.qr, el.querySelector(".wk-qr"));
    var go = el.querySelector(".wk-go");
    if (go) go.addEventListener("click", function (e) {
      if (go.getAttribute("data-js") || o.onTap) e.preventDefault();
      try { if (o.onTap) o.onTap(); } catch (x) {}
      if (o.url && (go.getAttribute("data-js") || o.onTap)) openUrl(o.url);
      go.hidden = true; el.querySelector(".wk-wait").hidden = false;
      ok(true);
    });
    el.querySelector(".wk-x").addEventListener("click", function () { ctl.done(); bad(new Error("cancelled")); if (ctl.onCancel) ctl.onCancel(); });
    ctl.done = function () { el.classList.remove("in"); setTimeout(function () { if (!el.classList.contains("in")) { el.hidden = true; el.innerHTML = ""; } }, 220); };
    ctl.say = function (t) { var w = el.querySelector(".wk-wait span"); if (w) w.textContent = t; };
    if (o.wait) ok(true);
    return ctl;
  }
  function loadQR(text, box) {
    var draw = function () { try { var q = window.qrcode(0, "M"); q.addData(text); q.make(); box.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true }); } catch (e) {} };
    if (window.qrcode) return draw();
    var s = document.createElement("script"); s.src = "/assets/vendor/qrcode.js"; s.onload = draw; document.head.appendChild(s);
  }

  // ---------------------------------------------------------------- wallets in the page (the Solana Wallet Standard)
  var found = [], subs = [];
  function addFound(w) {
    try {
      if (!w || !w.features || !w.features["standard:connect"]) return;
      if (!(w.chains || []).some(function (c) { return String(c).indexOf("solana:") === 0; })) return;
      if (found.some(function (x) { return x === w || x.name === w.name; })) return;
      found.push(w); subs.forEach(function (f) { try { f(w); } catch (e) {} });
    } catch (e) {}
  }
  var reg = { register: function () { for (var i = 0; i < arguments.length; i++) addFound(arguments[i]); return function () {}; } };
  window.addEventListener("wallet-standard:register-wallet", function (e) { try { e.detail(reg); } catch (x) {} });
  try { window.dispatchEvent(new CustomEvent("wallet-standard:app-ready", { detail: reg })); } catch (e) {}
  // announce one of ours to every app on the page (Shy Swap's list listens for this too)
  function announce(w) { try { window.dispatchEvent(new CustomEvent("wallet-standard:register-wallet", { detail: function (api) { api.register(w); } })); } catch (e) {} }
  function acct(addr, label) { return { address: addr, publicKey: b58d(addr), chains: [MAIN, "solana:mainnet"], features: ["solana:signMessage", "solana:signTransaction"], label: label }; }
  // a signature into the first slot of a serialized transaction (the fee payer's), for wallets that hand back only the signature
  function putSig(tx, sig) {
    var o = new Uint8Array(tx), n = 0, sh = 0, i = 0, b;
    do { b = o[i++]; n |= (b & 127) << sh; sh += 7; } while (b & 128);
    if (n < 1 || sig.length !== 64) throw new Error("Your wallet didn't return the signed transaction.");
    o.set(sig, i); return o;
  }

  // ---------------------------------------------------------------- Trust Wallet on a phone: WalletConnect
  var TRUST = { name: "Trust Wallet", ul: "https://link.trustwallet.com/wc?uri=",
    icon: "data:image/svg+xml;utf8," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="12" fill="#0500FF"/><path d="M24 9l12 4.5v9.3c0 7.7-5 13.6-12 16.2-7-2.6-12-8.5-12-16.2v-9.3z" fill="none" stroke="#fff" stroke-width="3.2" stroke-linejoin="round"/><path d="M24 9v30" stroke="#48FF91" stroke-width="3.2"/></svg>') };
  var wc = null, wcP = null;
  function wcInit() {
    if (wcP) return wcP;
    wcP = cfgP.then(function (c) {
      if (!c.wc) throw new Error("Trust Wallet on a phone isn't switched on yet.");
      return loadScript("wwc");
    }).then(function () {
      return window.ShyWC.SignClient.init({ projectId: cfg.wc, metadata: { name: "Shy on Solana", description: "Shilluminati Online and Shy Swap", url: location.origin, icons: [location.origin + "/assets/art/app-any-192.png"] } });
    }).then(function (c) { wc = c; return c; });
    wcP.catch(function () { wcP = null; });
    return wcP;
  }
  function wcSession() {
    if (!wc) return null;
    var all = wc.session.getAll().filter(function (s) { return s.namespaces && s.namespaces.solana && s.namespaces.solana.accounts && s.namespaces.solana.accounts.length && s.expiry * 1000 > Date.now(); });
    return all.length ? all[all.length - 1] : null;
  }
  function wcWake(s) { return TRUST.ul + encodeURIComponent("wc:" + s.topic + "@2"); }
  function wcConnect(silent) {
    return wcInit().then(function () {
      var s = wcSession(); if (s) return s;
      if (silent) throw new Error("not connected");   // a quiet reconnect on page load never opens anything
      return wc.connect({ optionalNamespaces: { solana: { chains: [MAIN], methods: ["solana_signMessage", "solana_signTransaction", "solana_signAndSendTransaction"], events: [] } } }).then(function (r) {
        var t = tap(isPhone() ? { title: "Connect Trust Wallet", text: "Trust Wallet opens to approve the connection, then come back here.", label: "Open Trust Wallet", url: TRUST.ul + encodeURIComponent(r.uri) }
          : { title: "Connect Trust Wallet", text: "Scan this with Trust Wallet on your phone, then approve the connection there.", qr: r.uri, wait: "Waiting for Trust Wallet..." });
        return Promise.race([r.approval(), t.tapped.then(function () { return new Promise(function () {}); })]).then(function (s2) { t.done(); return s2; }, function (e) { t.done(); throw e; });
      });
    });
  }
  function wcRequest(method, params, title, text) {
    return wcInit().then(function () {
      var s = wcSession(); if (!s) throw new Error("Connect Trust Wallet again.");
      var req = function () { return wc.request({ topic: s.topic, chainId: MAIN, request: { method: method, params: params } }); };
      var p = null;
      var t = tap(isPhone() ? { title: title, text: text, label: "Open Trust Wallet", url: wcWake(s), onTap: function () { p = req(); } }
        : { title: title, text: "Approve it in Trust Wallet on your phone.", wait: "Waiting for Trust Wallet..." });
      if (!isPhone()) p = req();
      return t.tapped.then(function () { return p; }).then(function (res) { t.done(); return res; }, function (e) { t.done(); throw e; });
    });
  }
  var trustW = null;
  function trustWallet() {
    if (trustW) return trustW;
    var w = { version: "1.0.0", name: TRUST.name, icon: TRUST.icon, chains: [MAIN, "solana:mainnet"], accounts: [], shyKit: "wc" };
    w.features = {
      "standard:connect": { version: "1.0.0", connect: function (inp) { return wcConnect(!!(inp && inp.silent)).then(function (s) { var a = acct(s.namespaces.solana.accounts[0].split(":").pop(), TRUST.name); w.accounts = [a]; return { accounts: [a] }; }); } },
      "standard:disconnect": { version: "1.0.0", disconnect: function () { var s = wcSession(); w.accounts = []; return s ? wc.disconnect({ topic: s.topic, reason: { code: 6000, message: "User disconnected" } }).catch(function () {}) : Promise.resolve(); } },
      "standard:events": { version: "1.0.0", on: function () { return function () {}; } },
      "solana:signMessage": { version: "1.0.0", signMessage: function (inp) {
        return wcRequest("solana_signMessage", { message: b58e(inp.message), pubkey: inp.account.address }, "Sign in Trust Wallet", "Sign the message in Trust Wallet. It's free and not a transaction.")
          .then(function (r) { return [{ signedMessage: inp.message, signature: b58d(r && r.signature) }]; });
      } },
      "solana:signTransaction": { version: "1.0.0", supportedTransactionVersions: ["legacy", 0], signTransaction: function (inp) {
        return wcRequest("solana_signTransaction", { transaction: b64e(inp.transaction), pubkey: inp.account.address }, "Approve in Trust Wallet", "Check the details in Trust Wallet and approve.")
          .then(function (r) { return [{ signedTransaction: r && r.transaction ? b64d(r.transaction) : putSig(inp.transaction, b58d(r && r.signature)) }]; });
      } }
    };
    trustW = w; return w;
  }

  // ---------------------------------------------------------------- MetaMask: MetaMask Connect
  var MM = { name: "MetaMask", icon: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCAzMCAzMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjIzIiBoZWlnaHQ9IjIzIiB4PSIzLjUiIHk9IjMuNSIgdmlld0JveD0iMCAwIDE0MS41MSAxMzYuNDIiPjxwYXRoIGZpbGw9IiNGRjVDMTYiIGQ9Im0xMzIuMjQgMTMxLjc1LTMwLjQ4LTkuMDctMjIuOTkgMTMuNzQtMTYuMDMtLjAxLTIzLTEzLjc0LTMwLjQ3IDkuMDhMMCAxMDAuNDdsOS4yNy0zNC43M0wwIDM2LjQgOS4yNyAwbDQ3LjYgMjguNDRoMjcuNzZMMTMyLjI0IDBsOS4yNyAzNi4zOC05LjI3IDI5LjM2IDkuMjcgMzQuNzItOS4yNyAzMS4zWiIvPjxwYXRoIGZpbGw9IiNGRjVDMTYiIGQ9Im05LjI3IDAgNDcuNjEgMjguNDZMNTQuOTggNDggOS4yOSAwWm0zMC40NyAxMDAuNDggMjAuOTUgMTUuOTUtMjAuOTUgNi4yNHYtMjIuMlpNNTkuMDEgNzQuMSA1NSA0OCAyOS4yMiA2NS43NWgtLjAybC4wOCAxOC4yNyAxMC40NS05LjkyaDE5LjI5Wk0xMzIuMjUgMGwtNDcuNiAyOC40Nkw4Ni41MSA0OGw0NS43Mi00OFptLTMwLjQ3IDEwMC40OC0yMC45NCAxNS45NSAyMC45NCA2LjI0di0yMi4yWm0xMC41My0zNC43M0w4Ni41MyA0OCA4Mi41IDc0LjFoMTkuMjdsMTAuNDYgOS45LjA3LTE4LjI2WiIvPjxwYXRoIGZpbGw9IiNFMzQ4MDciIGQ9Im0zOS43MyAxMjIuNjctMzAuNDYgOS4wOEwwIDEwMC40OGgzOS43M3YyMi4yWk01OS4wMiA3NC4xbDUuODIgMzcuNzEtOC4wNy0yMC45Ny0yNy40OS02LjgyIDEwLjQ2LTkuOTJINTlabTQyLjc2IDQ4LjU5IDMwLjQ3IDkuMDcgOS4yNy0zMS4yN2gtMzkuNzR6TTgyLjUgNzQuMDlsLTUuODIgMzcuNzEgOC4wNi0yMC45NyAyNy41LTYuODItMTAuNDctOS45MnoiLz48cGF0aCBmaWxsPSIjRkY4RDVEIiBkPSJtMCAxMDAuNDcgOS4yNy0zNC43M0gyOS4ybC4wNyAxOC4yNyAyNy41IDYuODIgOC4wNiAyMC45Ny00LjE1IDQuNjItMjAuOTQtMTUuOTZIMFptMTQxLjUgMC05LjI2LTM0LjczaC0xOS45M2wtLjA3IDE4LjI3LTI3LjUgNi44Mi04LjA2IDIwLjk3IDQuMTUgNC42MiAyMC45NC0xNS45NmgzOS43NFpNODQuNjQgMjguNDRINTYuODhsLTEuODkgMTkuNTQgOS44NCA2My44aDExLjg1bDkuODUtNjMuOC0xLjktMTkuNTRaIi8+PHBhdGggZmlsbD0iIzY2MTgwMCIgZD0iTTkuMjcgMCAwIDM2LjM4bDkuMjcgMjkuMzZIMjkuMkw1NC45OCA0OHptNDMuOTggODEuNjdoLTkuMDNsLTQuOTIgNC44MSAxNy40NyA0LjMzLTMuNTItOS4xNVpNMTMyLjI0IDBsOS4yNyAzNi4zOC05LjI3IDI5LjM2aC0xOS45M0w4Ni41MyA0OHpNODguMjcgODEuNjdoOS4wNGw0LjkyIDQuODItMTcuNDkgNC4zNCAzLjUzLTkuMTdabS05LjUgNDIuMyAyLjA2LTcuNTQtNC4xNS00LjYySDY0LjgybC00LjE0IDQuNjIgMi4wNSA3LjU0Ii8+PHBhdGggZmlsbD0iI0MwQzRDRCIgZD0iTTc4Ljc3IDEyMy45N3YxMi40NUg2Mi43NHYtMTIuNDVoMTYuMDJaIi8+PHBhdGggZmlsbD0iI0U3RUJGNiIgZD0ibTM5Ljc0IDEyMi42NiAyMyAxMy43NnYtMTIuNDZsLTIuMDUtNy41NHptNjIuMDMgMC0yMyAxMy43NnYtMTIuNDZsMi4wNi03LjU0eiIvPjwvc3ZnPjwvc3ZnPg==" };
  var mmP = null, mmSheet = null;
  function mmOpen(link) {
    var u = String(link || "").replace(/^metamask:\/\//, "https://metamask.app.link/");
    if (mmSheet) mmSheet.done();
    mmSheet = tap({ title: "Open MetaMask", text: "MetaMask opens to approve, then come back here.", label: "Open MetaMask", url: u });
    mmSheet.onCancel = function () { mmSheet = null; };
  }
  function mmInit() {
    if (mmP) return mmP;
    mmP = loadScript("wmm").then(function () {
      return window.ShyMM.client({ dapp: { name: "Shy on Solana", url: location.origin, iconUrl: location.origin + "/assets/art/app-any-192.png" }, open: isPhone() ? mmOpen : null });
    });
    mmP.catch(function () { mmP = null; });
    return mmP;
  }
  // MetaMask's own wallet, with its sheet closed whenever a request finishes
  var mmW = null;
  function mmWallet() {
    if (mmW) return mmW;
    var w = { version: "1.0.0", name: MM.name, icon: MM.icon, chains: [MAIN, "solana:mainnet"], accounts: [], shyKit: "mm" };
    var close = function (x) { if (mmSheet) { mmSheet.done(); mmSheet = null; } return x; };
    var fail = function (e) { close(); throw e; };
    var via = function (feat, fn) { return function (inp) { return mmInit().then(function (c) { var f = c.wallet.features[feat]; if (!f) throw new Error("MetaMask can't do that here."); return f[fn](inp); }).then(close, fail); }; };
    w.features = {
      "standard:connect": { version: "1.0.0", connect: function (inp) {
        if (inp && inp.silent) return mmInit().then(function (c) { if (!c.restored) throw new Error("not connected"); return c.wallet.features["standard:connect"].connect(); }).then(function (r) { w.accounts = (r && r.accounts) || []; return r; });
        return via("standard:connect", "connect")(inp).then(function (r) { w.accounts = (r && r.accounts) || []; return r; }); } },
      "standard:disconnect": { version: "1.0.0", disconnect: function () { w.accounts = []; return mmInit().then(function (c) { return c.disconnect(); }).catch(function () {}); } },
      "standard:events": { version: "1.0.0", on: function () { return function () {}; } },
      "solana:signMessage": { version: "1.0.0", signMessage: via("solana:signMessage", "signMessage") },
      "solana:signTransaction": { version: "1.0.0", supportedTransactionVersions: ["legacy", 0], signTransaction: via("solana:signTransaction", "signTransaction") }
    };
    mmW = w; return w;
  }

  // ---------------------------------------------------------------- what the pages use
  function has(name) { var n = name.toLowerCase(); return found.some(function (w) { return String(w.name || "").toLowerCase().indexOf(n) >= 0 && !w.shyKit; }); }
  // the wallets this kit adds where the browser has none of its own: Trust Wallet (when switched on) and MetaMask
  function extras() {
    var out = [];
    if (!has("trust") && cfg && cfg.wc) out.push({ id: "trust", name: TRUST.name, icon: TRUST.icon, sub: isPhone() ? "Approve in the app" : "Scan with your phone" });
    if (!has("metamask")) out.push({ id: "metamask", name: MM.name, icon: MM.icon, sub: isPhone() ? "Approve in the app" : "Scan with your phone" });
    return out;
  }
  function kitWallet(id) { var w = id === "trust" ? trustWallet() : mmWallet(); announce(w); return w; }
  // the kit wallet behind a remembered name ("Trust Wallet", "MetaMask"), for a quiet reconnect
  function kitFor(name) { return name === TRUST.name ? "trust" : name === MM.name ? "metamask" : ""; }
  // a Wallet Standard wallet as the shape the game's connect code has always used (Phantom's)
  function provider(w) {
    var a = null;
    return { name: w.name, icon: w.icon, std: w,
      connect: function () { return w.features["standard:connect"].connect().then(function (r) { a = (r && r.accounts && r.accounts[0]) || (w.accounts && w.accounts[0]); if (!a) throw new Error("The wallet didn't share an address."); return { publicKey: { toString: function () { return a.address; } } }; }); },
      signMessage: function (bytes) { var f = w.features["solana:signMessage"]; if (!f) return Promise.reject(new Error(w.name + " can't sign a message here.")); return f.signMessage({ account: a, message: bytes }).then(function (o) { var x = Array.isArray(o) ? o[0] : o; return { signature: x && x.signature }; }); },
      disconnect: function () { var f = w.features["standard:disconnect"]; return f ? f.disconnect() : Promise.resolve(); } };
  }
  window.ShyWallets = {
    found: function () { return found.slice(); }, onFound: function (f) { subs.push(f); },
    extras: extras, kit: kitWallet, kitFor: kitFor, provider: provider, ready: function () { return cfgP; },
    tap: tap, open: openUrl, isPhone: isPhone, inTg: inTg, b58e: b58e, b58d: b58d, b64e: b64e, b64d: b64d
  };
})();
