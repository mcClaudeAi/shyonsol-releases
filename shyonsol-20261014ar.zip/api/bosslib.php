<?php
//MC 2026-10-12 The Shogun: a 1v1 boss match against the hardest bot in Shilluminati. Players start it from the Play page
//   or with /shilluminatiboss in Telegram, the server plays the Shogun's side (the same live room code as every live
//   match, so nothing a player sends can fake a win), and a win pays boss Koban (Admin > Economy > The Shogun).
//   How it plays: the normal bots look one card ahead with a score for each card. The Shogun tries every move it could
//   make, then plays each one out to the end of the game many times, with the cards it can't see dealt at random from
//   what's left (so it never peeks at your hand), and picks the move that won most often. It only knows what a player
//   at the table would know.
if (!defined('SHY_API')) { http_response_code(404); exit; }

const BOSS_NAME = 'The Shogun';
const BOSS_AVATAR = 'assets/art/masks/shogun.svg';

function boss_cfg() {
    $s = eco_settings();
    return ['on' => !isset($s['boss_on']) || !empty($s['boss_on']),
        'koban' => max(0, (int)($s['boss_koban'] ?? 500)),
        'per' => ($s['boss_per'] ?? 'day') === 'week' ? 'week' : 'day',
        'edge' => max(0, min(3, (int)($s['boss_edge'] ?? 0))),          // extra cards the Shogun starts with
        'think' => max(200, min(2500, (int)($s['boss_think'] ?? 700))), // ms it may think per card
        'games' => max(1, min(200, (int)($s['boss_games'] ?? 25)))];     // boss matches a player may start a day
}
// the reward period a win falls in: today, or this week
function boss_period($per) { return $per === 'week' ? 'w' . week_key() : 'd' . today(); }

// one move for the Shogun: ['hand' => i, 'target' => t], or null to end the turn (claiming a Region if nothing was played)
function boss_pick($g, $pi, $budgetMs = 700) {
    $hand = $g['players'][$pi]['hand'];
    $cands = [null]; $seen = [];
    foreach ($hand as $h => $id) {
        if (!can_play($id) || isset($seen[$id])) continue;
        $seen[$id] = 1;
        $tg = CARDS[$id]['target'] === 'pick' ? rivals_of($g, $pi) : [null];
        foreach ($tg as $t) { $try = $g; $try['log'] = []; if (eng_play($try, $pi, $h, $t)) $cands[] = ['hand' => $h, 'target' => $t]; }
    }
    if ($g['plays'] <= 0 || count($cands) === 1) return null;
    $keep = $GLOBALS['SHY_SEED'] ?? null;
    rnd_seed(random_int(1, 0x7fffffff));   // the seeded generator is far quicker than random_int for thousands of shuffles
    $sum = array_fill(0, count($cands), 0.0); $n = array_fill(0, count($cands), 0);
    $t0 = microtime(true); $budget = $budgetMs / 1000; $round = 0;
    while (true) {
        foreach ($cands as $i => $c) { $sum[$i] += boss_rollout($g, $pi, $c); $n[$i]++; }
        $round++;
        if ($round >= 6 && microtime(true) - $t0 > $budget) break;
        if ($round >= 400) break;
    }
    rnd_seed($keep);
    $best = 0; $bv = -1;
    foreach ($cands as $i => $c) { $v = $sum[$i] / max(1, $n[$i]); if ($v > $bv + 1e-9) { $bv = $v; $best = $i; } }
    $GLOBALS['BOSS_LAST'] = ['cands' => count($cands), 'rounds' => $round, 'ms' => (int)round((microtime(true) - $t0) * 1000), 'win' => round($bv, 3)];
    return $cands[$best];
}
// deal what the Shogun can't see at random: the other hands come from the unseen cards, the decks are reshuffled
function boss_determinize(&$s, $pi) {
    $pool = $s['chaosDeck'];
    foreach ($s['players'] as $i => $p) if ($i !== $pi) foreach ($p['hand'] as $c) $pool[] = $c;
    $pool = shuf($pool);
    foreach ($s['players'] as $i => $p) if ($i !== $pi) { $k = count($p['hand']); $s['players'][$i]['hand'] = array_splice($pool, 0, $k); }
    $s['chaosDeck'] = $pool;
    $s['regionDeck'] = shuf($s['regionDeck']);
}
// play one move, then the rest of the game with the normal bots on both sides; 1 a win, 0 a loss, between for close ones
function boss_rollout($g, $pi, $c) {
    $s = $g; $s['log'] = [];
    boss_determinize($s, $pi);
    if ($c !== null) {
        eng_play($s, $pi, $c['hand'], $c['target']);
        if (eng_more_plays($s, $pi)) eng_bot_turn($s, $pi, 0.25);
    }
    $s['log'] = [];
    $over = eng_end_turn($s);
    for ($guard = 0; !$over && $guard < 90; $guard++) {
        if (!eng_start_turn($s)) eng_bot_turn($s, $s['turn'], 0.4);
        if (count($s['log']) > 40) $s['log'] = [];
        $over = eng_end_turn($s);
    }
    $mine = count($s['players'][$pi]['regions']); $top = 0;
    foreach ($s['players'] as $i => $p) if ($i !== $pi) $top = max($top, count($p['regions']));
    if ($s['over']) {
        $w = eng_winners($s);
        $r = in_array($pi, $w, true) ? (count($w) > 1 ? 0.5 : 1.0) : 0.0;
        return $r * 0.9 + 0.1 / (1 + exp(-($mine - $top) / 2));   // a bigger win scores a little higher, so it never coasts
    }
    return 1 / (1 + exp(-($mine - $top) / 2));
}

// ---------------------------------------------------------------- matches, records and the reward
define('BOSS_DB', DATA_DIR . '/boss.php');   // {t: {g, w, koban}, p: {pid: {g, w, best, paid: {period: koban}}}, s: {pid: [day, starts]}, recent: [...]}

// can this player start another boss match today? counts the start
function boss_start_ok($pid, $max) {
    return with_lock(function () use ($pid, $max) {
        $db = load(BOSS_DB); $d = today();
        $s = $db['s'][$pid] ?? ['', 0];
        if ($s[0] !== $d) $s = [$d, 0];
        if ($s[1] >= $max) return false;
        $s[1]++; $db['s'][$pid] = $s;
        foreach ($db['s'] ?? [] as $k => $v) if (($v[0] ?? '') !== $d) unset($db['s'][$k]);   // only today's counts are kept
        save(BOSS_DB, $db);
        return true;
    });
}
// a finished boss match: the record, and the Koban when it's a win the player played all of themselves and this
// period's reward is still open. Called inside end_game's lock.
function boss_result($room, $i, $pid, $name, $r) {
    $cfg = $room['boss'];
    $won = $r['result'] === 'win';
    $own = empty($room['covered'][$i]) && empty($room['seats'][$i]['away']) && empty($room['seats'][$i]['gone']);
    $db = load(BOSS_DB) + ['t' => ['g' => 0, 'w' => 0, 'koban' => 0], 'p' => [], 'recent' => []];
    $me = ($db['p'][$pid] ?? []) + ['g' => 0, 'w' => 0, 'best' => 0, 'paid' => []];
    $me['g']++; $db['t']['g']++;
    //MC 2026-10-12 for the Stats page: name for the boards, matches and wins by day, and how far apart each match ended
    $me['n'] = $name;
    $d = today(); $db['days'][$d] = ($db['days'][$d] ?? [0, 0]); $db['days'][$d][0]++;
    if (count($db['days']) > 120) { ksort($db['days']); $db['days'] = array_slice($db['days'], -120, null, true); }
    $out = ['won' => $won, 'koban' => 0, 'why' => '', 'per' => $cfg['per'] ?? 'day'];
    $bossRegions = 0; foreach ($room['seats'] as $j => $s) if (!empty($s['boss'])) $bossRegions = count($room['g']['players'][$j]['regions']);
    $diff = max(-15, min(15, (int)$r['regions'] - $bossRegions)); $db['diff'][(string)$diff] = (int)($db['diff'][(string)$diff] ?? 0) + 1;
    $prevBig = 0; foreach ($db['recent'] ?? [] as $x) $prevBig = max($prevBig, (int)$x['r'] - (int)$x['b']);
    if ($won) {
        $db['days'][$d][1]++;
        $me['w']++; $db['t']['w']++; $me['best'] = max($me['best'], $r['regions']);
        $me['big'] = max((int)($me['big'] ?? 0), $diff);
        $per = boss_period($out['per']);
        if (!$own) $out['why'] = 'covered';
        elseif (!empty($me['paid'][$per])) $out['why'] = 'already';
        elseif ((int)($cfg['koban'] ?? 0) > 0) { $out['koban'] = (int)$cfg['koban']; $me['paid'][$per] = $out['koban']; $db['t']['koban'] += $out['koban']; }
        $me['paid'] = array_slice($me['paid'], -10, null, true);
        array_unshift($db['recent'], ['t' => time(), 'pid' => $pid, 'name' => $name, 'r' => $r['regions'], 'b' => $bossRegions, 'k' => $out['koban']]);
        $db['recent'] = array_slice($db['recent'], 0, 30);
    }
    $db['p'][$pid] = $me;
    save(BOSS_DB, $db);
    $out['record'] = [$me['w'], $me['g']];
    //MC 2026-10-12 a loss or draw always posts; a win only when the player played every turn (a bot covering a timed-out
    //   turn used to stop the loss post too, so a lost match with one slow turn never reached the chat)
    if (($own || !$won) && function_exists('tg_post')) boss_tg($pid, $name, $won, $r['result'] === 'tie', (int)$r['regions'], $bossRegions, $me, $db, $out, $prevBig ?? 0);
    return $out;
}
//MC 2026-10-12 every boss match goes to the Telegram chat. A win is an accomplishment post with the player's profile card
//   as the picture and is pinned (Admin > Telegram > Pin these, on by default; the last win is unpinned so only the latest
//   stays). It says when it is the first win ever, their first, a flawless one or the biggest margin so far. A loss or a
//   tie is a short line under its own switch, "Losses to the Shogun", not held back by the hourly cap for game posts
//   (a skipped loss looked like a bug). A win is posted only when the player played every turn themselves; a loss or draw is always posted.
//   The profile card URL carries the time so Telegram fetches it fresh; if Telegram can't load it the words still go out.
function boss_tg($pid, $name, $won, $tie, $mine, $boss, $me, $db, $out, $prevBig) {
    $n = '<b>' . tg_h($name ?: 'A player') . '</b>';
    $t = $db['t']; $rate = $t['g'] ? round($t['w'] / $t['g'] * 100) : 0;
    $rec = 'Shogun record: ' . number_format($t['g'] - $t['w']) . ' ' . (($t['g'] - $t['w']) === 1 ? 'win' : 'wins') . ', ' . number_format($t['w']) . ' ' . ($t['w'] === 1 ? 'loss' : 'losses') . '.';
    $go = tg_link('/play?boss=1', 'Challenge the Shogun');
    if (!$won) {
        //MC 2026-10-12 level on Regions goes to whoever holds more cards, so "fell 14 to 14" read like a bug: say it was the tiebreak
        $head = $tie ? "🏯 $n fought the Shogun to a draw, $mine to $boss." : ($mine === $boss ? "🏯 The Shogun holds. $n lost on the tiebreak, $mine Regions each, with the Shogun holding more cards." : "🏯 The Shogun holds. $n fell $mine to $boss.");
        $line = $me['w'] > 0 ? 'Still ' . $me['w'] . ' ' . ($me['w'] === 1 ? 'win' : 'wins') . ' against it from ' . $me['g'] . ' matches.' : 'Match ' . $me['g'] . ' against the Shogun. Their first win is still out there.';
        //MC 2026-10-13 the Shogun's own victory card rides on the post (share.php?sw=, drawn server side), asked for by
        //   the team: a bot win has one now, and the Shogun of all bots should gloat in pictures
        $cfg = boss_cfg();
        $img = function_exists('tg_shogun_img') ? tg_shogun_img(['n' => (string)$name, 'mine' => (int)$mine, 'boss' => (int)$boss, 'tie' => (bool)$tie,
            'pw' => (int)$me['w'], 'pg' => (int)$me['g'], 'sw' => (int)$t['g'] - (int)$t['w'], 'sl' => (int)$t['w'],
            'koban' => $cfg['on'] ? (int)$cfg['koban'] : 0, 'per' => (string)$cfg['per']]) : '';
        tg_post('boss_loss', "$head\n$line\n$rec\n\n$go", '', null, $img ?: '');
        return;
    }
    $notes = [];
    if ((int)$t['w'] === 1) $notes[] = '🥇 The first player ever to beat the Shogun.';
    elseif ((int)$me['w'] === 1) $notes[] = '🎖 Their first win against the Shogun.';
    else $notes[] = '🎖 Win number ' . $me['w'] . ' against the Shogun, from ' . $me['g'] . ' matches.';
    if ($boss === 0) $notes[] = '💎 Flawless: the Shogun ended with no Regions at all.';
    elseif ($mine - $boss > $prevBig && $t['w'] > 1) $notes[] = '🔥 The biggest win against it so far, by ' . ($mine - $boss) . ' Regions.';
    if ($out['koban'] > 0) $notes[] = '💰 +' . number_format($out['koban']) . ' Koban reward.';
    $html = "🏯 <b>THE SHOGUN HAS FALLEN</b>\n\n⚔️ $n beat the Shogun <b>$mine to $boss</b> in a 1v1 against the hardest bot in Shilluminati.\n\n" . implode("\n", $notes) .
        "\n\nPlayers have won " . number_format($t['w']) . ' of ' . number_format($t['g']) . ($t['g'] === 1 ? ' match' : ' matches') . " against it ($rate%).\n\n$go";
    $img = defined('TG_SITE') && preg_match('/^[a-f0-9]{16}$/', $pid) ? TG_SITE . '/api/share.php?p=' . substr($pid, 0, 6) . '&w=' . time() : '';
    tg_post('boss', $html, 'boss:' . $pid . ':' . time(), null, $img);
}
// what the Play page shows: the reward, whether yours is still open, your record and the Shogun's
function boss_info($pid) {
    $cfg = boss_cfg(); $db = load(BOSS_DB);
    $me = $db['p'][$pid] ?? null;
    //MC 2026-10-12 the player's own last win over the Shogun, within a day, so the Play page can offer "Share your win"
    //   after the end screen is long gone (a player asked how to share one again). Score only, never other players' ids.
    $last = null;
    foreach ($db['recent'] ?? [] as $x) if (($x['pid'] ?? '') === $pid && (int)$x['t'] > time() - 86400) { $last = ['r' => (int)$x['r'], 'b' => (int)$x['b'], 't' => (int)$x['t']]; break; }
    //MC 2026-10-13 the day's matches against the cap the team set (boss_games), so the card can say 3/10 today
    $s = $db['s'][$pid] ?? ['', 0];
    return ['on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'],
        'open' => $cfg['koban'] > 0 && empty($me['paid'][boss_period($cfg['per'])]),
        'me' => $me ? [(int)$me['w'], (int)$me['g']] : [0, 0],
        'today' => $s[0] === today() ? (int)$s[1] : 0, 'max' => (int)$cfg['games'],
        'maskv' => (int)@filemtime(dirname(__DIR__) . '/' . BOSS_AVATAR),   //MC 2026-10-13 the panel refetches the mask when it changes

        'last' => $last,
        'all' => [(int)($db['t']['w'] ?? 0), (int)($db['t']['g'] ?? 0)],
        'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0))];
}

//MC 2026-10-12 the Shogun section on the Stats page (stats.php?a=boss): totals, the last 30 days, how close matches end,
//   the latest players to beat it and the most wins against it. Names only, never ids or wallets.
function boss_public() {
    $cfg = boss_cfg(); $db = load(BOSS_DB);
    $t = ($db['t'] ?? []) + ['g' => 0, 'w' => 0, 'koban' => 0];
    $days = []; for ($i = 29; $i >= 0; $i--) { $d = gmdate('Y-m-d', time() - $i * 86400); $days[] = [$d, (int)($db['days'][$d][0] ?? 0), (int)($db['days'][$d][1] ?? 0)]; }
    $diff = []; for ($k = -15; $k <= 15; $k++) $diff[] = (int)($db['diff'][(string)$k] ?? 0);
    $ppl = array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0 && !empty($x['n']));
    uasort($ppl, fn($a, $b) => [$b['w'], -$b['g'], $b['best'] ?? 0] <=> [$a['w'], -$a['g'], $a['best'] ?? 0]);
    $top = array_values(array_map(fn($x) => ['n' => $x['n'], 'w' => (int)$x['w'], 'g' => (int)$x['g'], 'best' => (int)($x['best'] ?? 0), 'big' => (int)($x['big'] ?? 0)], array_slice($ppl, 0, 10)));
    $recent = array_map(fn($x) => ['n' => $x['name'], 'r' => (int)$x['r'], 'b' => (int)$x['b'], 't' => (int)$x['t'], 'k' => (int)$x['k']], array_slice($db['recent'] ?? [], 0, 12));
    $big = null; foreach ($db['recent'] ?? [] as $x) if (!$big || $x['r'] - $x['b'] > $big['m']) $big = ['n' => $x['name'], 'r' => (int)$x['r'], 'b' => (int)$x['b'], 'm' => $x['r'] - $x['b']];
    return ['ok' => true, 'at' => time(), 'on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'],
        'g' => (int)$t['g'], 'w' => (int)$t['w'], 'paid' => (int)$t['koban'], 'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0)),
        'players' => count($db['p'] ?? []), 'days' => $days, 'diff' => $diff, 'top' => $top, 'recent' => $recent, 'big' => $big];
}

//MC 2026-10-12 the "Can you beat the Shogun?" card for X (Admin > The Shogun > Share on X). What's on it: the reward as it is
//   set now and the Shogun's record. The hash of those goes in the card's file name and in the link, so a new record or a new
//   reward gives a new address and X and Telegram fetch a fresh picture instead of the one they cached.
function boss_card_data() {
    $cfg = boss_cfg(); $db = load(BOSS_DB); $t = ($db['t'] ?? []) + ['g' => 0, 'w' => 0, 'koban' => 0];
    $d = ['on' => $cfg['on'], 'koban' => $cfg['koban'], 'per' => $cfg['per'], 'edge' => $cfg['edge'], 'g' => (int)$t['g'], 'w' => (int)$t['w'],
        'beaten' => count(array_filter($db['p'] ?? [], fn($x) => ($x['w'] ?? 0) > 0)), 'players' => count($db['p'] ?? []),
        'mv' => (int)@filemtime(DATA_DIR . '/masks/av-shogun.png')];   //MC 2026-10-13 a new mask changes the hash, so the promo card redraws with it
    $d['h'] = substr(sha1(json_encode($d) . 'bc1'), 0, 10);
    return $d;
}
function boss_card_url($d) { return 'https://shyonsol.io/shogun?v=' . $d['h']; }
